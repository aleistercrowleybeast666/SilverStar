/* Counterexamples execute generated 0b98 FC driver and frozen Ground50 driver.
 * Only physical SX1280/GPIO/time ports are supplied by the existing Host fixture.
 * No radio scheduler or queue is reimplemented here. NOT hardware evidence. */
#include <stdio.h>
#include <string.h>
#define TEST_SX1281_PORTS_ONLY 1
#define SX1280SendPayload Test_PreviousRadioSend
#include "test_sx1281_device.c"
#undef SX1280SendPayload
void SX1280SendPayload(uint8_t instance, uint8_t *data, uint8_t length, TickTime_t timeout);
#include "sx1281_device.c"
LoraInitResult Ground50_Lora_Init(uint8_t instance);
void Ground50_Lora_StartRx(uint8_t instance);
void Ground50_Lora_Process(uint8_t instance);
LoraTxEnqueueResult Ground50_Lora_TxEnqueue(uint8_t instance, const uint8_t *data, uint8_t length);
static unsigned int s_endpoint;
static unsigned int s_sends[2];
static uint32_t s_last_send_ms[2];
void SX1280SendPayload(uint8_t instance, uint8_t *data, uint8_t length, TickTime_t timeout)
{
    (void)instance; (void)timeout;
    s_sends[s_endpoint]++;
    s_last_send_ms[s_endpoint] = s_tick_ms;
    printf("PHYSICAL_SEND endpoint=%s ms=%lu bytes=%u first=%02x raw_irq=%04x\n",
        s_endpoint == 0U ? "FC_0b98" : "Ground50", (unsigned long)s_tick_ms,
        length, data[0], s_raw_irq);
}
static void Witness_Process(unsigned int endpoint, uint32_t now_ms, uint16_t irq, uint8_t dio)
{
    s_endpoint = endpoint; s_tick_ms = now_ms; s_raw_irq = irq; s_dio1_pending = dio;
    if (endpoint == 0U) { Lora_Process(0U); }
    else { Ground50_Lora_Process(0U); }
}
static void Witness_Init(void)
{
    TEST_CHECK(Lora_Init(0U) == LORA_INIT_OK);
    TEST_CHECK(Ground50_Lora_Init(0U) == LORA_INIT_OK);
    s_tick_ms = 0U;
    Lora_StartRx(0U); Ground50_Lora_StartRx(0U);
}
static void Witness_Phase(void)
{
    uint8_t downlink[26] = {0x11U};
    uint8_t command[9] = {0x20U};
    Witness_Init();
    TEST_CHECK(Lora_TxEnqueue(0U, downlink, sizeof(downlink)) == LORA_TX_ENQUEUE_OK);
    TEST_CHECK(Lora_TxEnqueue(0U, downlink, sizeof(downlink)) == LORA_TX_ENQUEUE_OK);
    Witness_Process(0U, 120U, 0U, 0U);
    TEST_CHECK(s_sends[0] == 1U);
    Witness_Process(0U, 194U, IRQ_TX_DONE, 1U);
    s_host_receive_enabled = 1U;
    Witness_Process(1U, 194U, IRQ_RX_DONE, 1U);
    s_tick_ms = 200U;
    TEST_CHECK(Ground50_Lora_TxEnqueue(0U, command, sizeof(command)) == LORA_TX_ENQUEUE_OK);
    Witness_Process(0U, 313U, 0U, 0U); Witness_Process(1U, 313U, 0U, 0U);
    TEST_CHECK(s_sends[0] == 1U); TEST_CHECK(s_sends[1] == 0U);
    Witness_Process(0U, 314U, 0U, 0U); Witness_Process(1U, 314U, 0U, 0U);
    printf("SIMULTANEOUS_TX fc=%lu ground=%lu (stimulus: downlink120-194, command_enqueue200)\n",
        (unsigned long)s_last_send_ms[0], (unsigned long)s_last_send_ms[1]);
    TEST_CHECK(s_last_send_ms[0] != s_last_send_ms[1]);
}
static void Witness_LateRx(uint8_t forced_dio, uint8_t header_case)
{
    uint8_t downlink[26] = {0x11U};
    Witness_Init();
    TEST_CHECK(Lora_TxEnqueue(0U, downlink, sizeof(downlink)) == LORA_TX_ENQUEUE_OK);
    /* 9 bytes take48.207ms. Case1 starts100: preamble indication110,
     * completion149. Case2 starts80: explicit header complete116,
     * completion129. Both are still receiving at the120ms TX grant.
     * Current mask gives no DIO; forced delivery additionally proves the
     * existing IRQ handler ignores both supported indications. */
    uint16_t indication = header_case != 0U ? IRQ_HEADER_VALID : IRQ_PREAMBLE_DETECTED;
    uint32_t indication_ms = header_case != 0U ? 116U : 110U;
    Witness_Process(0U, indication_ms, indication, forced_dio);
    Witness_Process(0U, 120U, indication, forced_dio);
    printf("LATE_RX pending_expected_done%u tx_count=%u tx_ms=%lu forced_dio=%u indication=%04x\n",
        header_case != 0U ? 129U : 149U, s_sends[0],
        (unsigned long)s_last_send_ms[0], forced_dio, indication);
    TEST_CHECK(s_sends[0] == 0U);
}
int main(int argc, char **argv)
{
    if (argc != 2) { return 2; }
    if (strcmp(argv[1], "phase") == 0) { Witness_Phase(); }
    else if (strcmp(argv[1], "late_rx") == 0) { Witness_LateRx(0U, 0U); }
    else if (strcmp(argv[1], "late_rx_forced_dio") == 0) { Witness_LateRx(1U, 0U); }
    else if (strcmp(argv[1], "header_valid_forced_dio") == 0) { Witness_LateRx(1U, 1U); }
    else { return 2; }
    return Test_Finish(argv[1]);
}
