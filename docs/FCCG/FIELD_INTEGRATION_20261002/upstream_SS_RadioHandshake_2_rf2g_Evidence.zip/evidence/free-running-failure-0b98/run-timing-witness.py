import hashlib
import json
from pathlib import Path
import re
import subprocess

root = Path.cwd()
out = root / '.work/evidence/free-running-failure-0b98'
record = json.loads((root / '.work/evidence/post-compile-command.json').read_text(encoding='utf8'))
old = record['command']
fixture_index = next(i for i, value in enumerate(old) if value.endswith('radio_handshake_host.c'))
flags = [value.replace('\\.work\\post\\', '\\.work\\post10\\') for value in old[:fixture_index]]
ground_source = out / 'ground50-sx1281_device.c'
names = sorted(set(re.findall(r'\bLora_\w+', ground_source.read_text(encoding='utf8'))))
object_path = out / 'ground50-prefixed.o'
compile_ground = flags + [f'-D{name}=Ground50_{name}' for name in names] + ['-c', str(ground_source), '-o', str(object_path)]
project = root / '.work/post10/Flight_Controller'
exe = out / 'timing-witness.exe'
compile_witness = flags + [str(out / 'timing-witness.c'), str(object_path),
    str(project / 'Generated/Src/project_resources.c'),
    str(project / 'Common/Src/silverstar_assert.c'), '-lm', '-o', str(exe)]
results = []
for label, command in [('compile_ground', compile_ground), ('compile_witness', compile_witness)]:
    result = subprocess.run(command, cwd=root, capture_output=True, text=True, encoding='utf8')
    (out / f'{label}.log').write_text(result.stdout + result.stderr, encoding='utf8')
    results.append({'label': label, 'command': command, 'cwd': str(root), 'exit_code': result.returncode})
    print(label, result.returncode, result.stdout, result.stderr)
    if result.returncode:
        (out / 'timing-witness-results.json').write_text(json.dumps(results, indent=2), encoding='utf8')
        raise SystemExit(result.returncode)
for case in ['phase', 'late_rx', 'late_rx_forced_dio', 'header_valid_forced_dio']:
    command = [str(exe), case]
    result = subprocess.run(command, cwd=root, capture_output=True, text=True, encoding='utf8')
    (out / f'{case}.log').write_text(result.stdout + result.stderr, encoding='utf8')
    results.append({'label': case, 'command': command, 'cwd': str(root), 'exit_code': result.returncode,
                    'expectation': 'Known missing arbitration contract must fail; not hardware validation'})
    print(case, result.returncode, result.stdout, result.stderr)
results.append({'source_commit_fc': '0b98f498f1d2eb27f96bf17d1442c884c9052bb1',
    'source_commit_ground': '50cc2d3', 'gcc_version': subprocess.check_output(['gcc', '--version'], cwd=root, text=True, encoding='utf8'),
    'sha256': {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in [ground_source,
        project / 'Devices/Telemetry/SX1281/Src/sx1281_device.c', out / 'timing-witness.c', object_path, exe]}})
(out / 'timing-witness-results.json').write_text(json.dumps(results, indent=2), encoding='utf8')
