# SS_0_5_TEST_4

This standalone embedded project was assembled by SilverStar_FCCG from declarative source plugins.
It does not require FCCG or Python to build.

- Default / Release build: `mingw32-make TARGET_PROFILE=SilverStar_F407 CONFIG=Release all`
- Debug build: `mingw32-make TARGET_PROFILE=SilverStar_F407 CONFIG=Debug all`
- Host tests: `mingw32-make host-tests`
- Architecture check: `mingw32-make architecture-check`
- Power of Ten project gate: `mingw32-make power10-check`
- GCC `-fanalyzer` static analysis: `mingw32-make CONFIG=Release static-analysis`
- Artifact check: `mingw32-make TARGET_PROFILE=SilverStar_F407 CONFIG=Release artifact-check`
- Log decoder profile: `SS_0_5_TEST_4.ssdecoder`
- Generation profile SHA-256: `5c2923a5780918a16c95aae3b643f4b06d50519762fd4ec7cef4540b91259247`
- Log decoder package SHA-256: `b623788802e6a65aa1f2953e933929177a1a5f96bec16893ada275c1abe85b58`

Component sources are ordinary project-owned files. FCCG may overwrite `Generated/`,
`SilverStar.ssproject`, `SilverStar_Configuration.md`, and generated editor/build metadata.

Make and native EIDE are rendered from the same resolved source graph. VS Code tasks invoke
the generated standalone project and do not modify global editor settings.

Power of Ten is a project compliance gate, not formal verification or safety certification.
Static analysis is the real Arm GNU GCC `-fanalyzer` pass over first-party firmware sources;
it is not a substitute for runtime tests, hardware tests, or formal verification.
