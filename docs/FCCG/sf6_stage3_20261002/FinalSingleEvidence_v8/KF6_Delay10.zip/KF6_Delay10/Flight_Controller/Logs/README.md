# SilverStar flight logs

Use `SS_0_5_TEST_4.ssdecoder` from the project root as the declarative
decoder profile for logs produced by this exact generated configuration. The package contains
the record catalog, project semantics, checksums, and no executable code.

- Generation profile SHA-256: `5c2923a5780918a16c95aae3b643f4b06d50519762fd4ec7cef4540b91259247`
- Package SHA-256: `b623788802e6a65aa1f2953e933929177a1a5f96bec16893ada275c1abe85b58`

Task logs may be stored below `Logs/`. Running the generated Host Tests creates
`Golden/SS_0_5_TEST_4_golden.sslog` with the real SSLOG C codec;
`Golden/expected.json` records the expected Record and channel identities.
The `.ssdecoder` file may also be copied beside a log
or to its parent task directory; SilverStar_FLP can search the current directory, child
directories, and the parent for a matching profile. Archive the package with its firmware.

`period_us = 0` means that a non-periodic stream does not use a periodic interval; it never
means a zero-period continuous logging loop. A DECIMATION stream records once per configured
decimation factor of source updates.
