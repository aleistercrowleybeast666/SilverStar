# SilverStar flight logs

Use `SS_0_5_TEST_4.ssdecoder` from the project root as the declarative
decoder profile for logs produced by this exact generated configuration. The package contains
the record catalog, project semantics, checksums, and no executable code.

- Generation profile SHA-256: `d73d7ee7d2230dca33af5f535b860698ac4cb16a83fee48d18c683a95a8553f3`
- Package SHA-256: `a928acbce2bfad8d45ee25395c83b46fe74bb1c5dc71f3e290bf81a5980e09b5`

Task logs may be stored below `Logs/`. Running the generated Host Tests creates
`Golden/SS_0_5_TEST_4_golden.sslog` with the real SSLOG C codec;
`Golden/expected.json` records the expected Record and channel identities.
The `.ssdecoder` file may also be copied beside a log
or to its parent task directory; SilverStar_FLP can search the current directory, child
directories, and the parent for a matching profile. Archive the package with its firmware.

`period_us = 0` means that a non-periodic stream does not use a periodic interval; it never
means a zero-period continuous logging loop. A DECIMATION stream records once per configured
decimation factor of source updates.
