# SS_0_5_TEST_4

This standalone embedded project was assembled by SilverStar_FCCG from declarative source plugins.
It does not require FCCG or Python to build.

- Default / Release build: `mingw32-make TARGET_PROFILE=SilverStar_F407 CONFIG=Release all`
- Debug build: `mingw32-make TARGET_PROFILE=SilverStar_F407 CONFIG=Debug all`
- Host tests: `mingw32-make host-tests`
- Architecture check: `mingw32-make architecture-check`
- Power of Ten project gate: `mingw32-make power10-check`
- GCC `-fanalyzer` static analysis: `mingw32-make CONFIG=Release static-analysis`
- Artifact check: `mingw32-make TARGET_PROFILE=SilverStar_F407 CONFIG=Release artifact-check`
- Log decoder profile: `SS_0_5_TEST_4.ssdecoder`
- Generation profile SHA-256: `d73d7ee7d2230dca33af5f535b860698ac4cb16a83fee48d18c683a95a8553f3`
- Log decoder package SHA-256: `a928acbce2bfad8d45ee25395c83b46fe74bb1c5dc71f3e290bf81a5980e09b5`

Component sources are ordinary project-owned files. FCCG may overwrite `Generated/`,
`SilverStar.ssproject`, `SilverStar_Configuration.md`, and generated editor/build metadata.

Make and native EIDE are rendered from the same resolved source graph. VS Code tasks invoke
the generated standalone project and do not modify global editor settings.

Power of Ten is a project compliance gate, not formal verification or safety certification.
Static analysis is the real Arm GNU GCC `-fanalyzer` pass over first-party firmware sources;
it is not a substitute for runtime tests, hardware tests, or formal verification.
