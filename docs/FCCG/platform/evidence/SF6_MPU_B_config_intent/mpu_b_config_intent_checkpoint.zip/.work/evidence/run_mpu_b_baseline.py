from pathlib import Path
import json,re,subprocess,hashlib,datetime,sys
root=Path.cwd(); project=root/'.work/generated_ret6'; out=root/'.work/evidence/mpu_b_baseline'
mk=(project/'Generated/project_sources.mk').read_text()
paths=re.findall(r'^\s+([\w/]+\.c)\s*(?:\\)?\s*$',mk,re.M)
selected=[]
prefixes=('Algorithm/','System/Calibration/','System/Alignment/','System/Inertial/',
          'Devices/SensorBus/','Devices/IMU/MPU6050/','Devices/Barometer/BMP280/','Protocol/SSLOG/')
names={'estimator_bus.c','estimator_barometer_pending.c','flight_task.c','imu_sample_bus.c',
       'logger_bus.c','common_spsc_queue.c','common_format.c','silverstar_assert.c','debug_log.c',
       'system_time.c','system_health.c','system_capabilities.c','system_profile.c',
       'system_log_policy.c','system_navigation_profile.c','system_navigation_health.c',
       'system_estimator_profile.c','system_estimator_diagnostics.c','system_gnss_quality.c',
       'system_source_selector.c','system_user_inertial_config.c','system_startup.c',
       'system_barometer.c','system_barometer_cold.c','project_device_instances.c',
       'project_metadata.c','project_resources.c','project_log_config.c','project_log_decoder_profile.c','silverstar_flight_cycle.c'}
for path in paths:
 if path.startswith(prefixes) or Path(path).name in names: selected.append(project/path)
selected += [project/'Tests/Host/host_platform_mock.c',out/'baseline.c',out/'ins_inputs.c',out/'mag_inputs.c',out/'storage_inputs.c',out/'baro_inputs.c']
includes=[out,project,project/'Tests/Host',project/'Generated/Inc']
includes += [p for p in project.rglob('Inc') if not any(x in p.parts for x in ('Drivers','Middlewares','build','.fccg'))]
includes += [project/'System/User',project/'Devices/Storage/SdSdioFatFs/Adapter/Inc']
defs=re.findall(r'^\s+(SYSTEM_(?:ALIGNMENT_BUILD|BUILD)_[A-Z0-9_]+=[A-Z0-9_]+)\s*(?:\\)?\s*$',mk,re.M)
optimization=sys.argv[1] if len(sys.argv)>1 else '-O2'
assert optimization in ('-O2','-O1','-Og','-O0')
command=['D:/msys64/ucrt64/bin/gcc.exe','-std=c11',optimization,
 '-fno-lto' if optimization=='-O0' else '-flto','-Wall','-Wextra','-Werror','-pedantic',
 '-ffunction-sections','-fdata-sections','-Wl,--gc-sections',
 '-Wl,--wrap=PlatformI2c_MemoryRead','-Wl,--wrap=PlatformI2c_MemoryWrite',
 '-Wl,--wrap=SystemImu_ConfigApply','-Wl,--wrap=SystemImu_ConfigVerify',
 '-include',str(project/'Generated/Inc/project_flight_config.h')]
command += ['-D'+d for d in defs]+['-I'+str(p) for p in includes]+[str(s) for s in selected]+['-o',str(out/'baseline.exe')]
row={'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'argv':command,'inputs':[{'path':str(p.relative_to(root)), 'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in selected],
 'compiler_version':subprocess.check_output([command[0],'--version'],text=True)}
result=subprocess.run(command,capture_output=True,text=True,timeout=90)
row.update(exit=result.returncode,stdout=result.stdout,stderr=result.stderr)
attempt=len(list(out.glob('compile_attempt_*.json')))+1
(out/f'compile_attempt_{attempt:02}.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
(out/'compile.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
print(result.stderr); print('COMPILE_EXIT',result.returncode)
if result.returncode: raise SystemExit(result.returncode)
cases=[]
for case in (1,2,3):
 r=subprocess.run([str(out/'baseline.exe'),str(case)],capture_output=True,text=True,timeout=15)
 cases.append({'case':case,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
 print(json.dumps(cases[-1],ensure_ascii=False))
(out/f'cases_attempt_{attempt:02}.json').write_text(json.dumps(cases,indent=2),encoding='utf-8')
(out/'cases.json').write_text(json.dumps(cases,indent=2),encoding='utf-8')
raise SystemExit(0 if all(r['exit']==0 for r in cases) else 1)
