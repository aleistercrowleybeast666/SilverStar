from pathlib import Path
import re

root=Path.cwd()
out=root/'.work/evidence/mpu_b_baseline'
out.mkdir(exist_ok=True)
project=root/'.work/generated_ret6'
old=(project/'Tests/Host/test_optional_gnss_start.c').read_text()
head=old[:old.index('static void Test_Collect')]
# The actual generated facades, MPU, selector, inertial bridge and startup
# replace the prior fixture implementations. External peripheral inputs remain
# explicitly identified below. No CAL/ALIGN/health/START readiness is mocked.
names=['SystemImu_CapabilitiesGet','SystemBarometer_CapabilitiesGet','SystemBarometer_NameGet',
 'SystemSourceSelector_ImuSelectAndLock','SystemSourceSelector_ImuActiveInstanceGet',
 'SystemSourceSelector_GnssActiveInstanceGet','SystemStartup_GetReport',
 'SystemImu_HealthGet','SystemGnss_HealthGet','SystemBarometer_HealthGet',
 'SystemMagnetometer_HealthGet','SystemHardwareQuaternion_HealthGet','SystemPower_HealthGet',
 'SystemTelemetry_HealthGet','SystemInertial_LatestGet','SystemGnss_CapabilitiesGet',
 'SystemMagnetometer_CapabilitiesGet','SystemHardwareQuaternion_CapabilitiesGet',
 'SystemHardwareQuaternion_LatestSampleGet','SystemMagnetometer_LatestSampleGet',
 'SystemGnss_TimeGet','SystemGnss_LatestSampleGet','SystemGnss_NameGet','SystemHardwareQuaternion_NameGet']
for name in names:
 pat=rf'^[^\n]*\b{name}\([^;]*?\)\s*\{{.*?^?\}}\s*'
 # All removed input functions in this prefix have single-line bodies.
 head=re.sub(rf'^[^\n]*\b{name}\([^;]*?\)\s*\{{[^}}]*\}}\s*', '',head,flags=re.M)
head=head.replace('static SystemStartupReport s_startup_report;','')
head=head.replace('static SystemGnssSample s_test_gnss;','')
head=head.replace('static SystemDeviceResult Test_DeviceHealth(SystemDeviceHealth *health)\n{ memset(health, 0, sizeof(*health)); health->initialized = 1U; health->online = 1U; health->healthy = 1U; return SYSTEM_DEVICE_OK; }','')
head=head.replace('#include "../../APP/Src/estimator_task.c"','#include "APP/Src/estimator_task.c"')
head=head.replace('static uint8_t s_storage_ready = 1U;','static uint8_t s_storage_ready;')
head=head.replace('health->healthy = s_storage_ready;', 'health->healthy = s_storage_ready; health->initial_probe_complete = 1U; health->initial_medium_unavailable = (uint8_t)!s_storage_ready;')
head=re.sub(r'(SystemDeviceResult SystemLogSink_HealthGet.*?\{.*?)health->initial_probe_complete.*?return SYSTEM_DEVICE_OK;',r'\1return SYSTEM_DEVICE_OK;',head,flags=re.S)
(out/'baseline.c').write_text(head+'''\n#include <assert.h>
#include <stdlib.h>
#include "mpu6050_instance.h"
#include "platform_i2c.h"
#include "bmp280_instance.h"
#include "sx1281_instance.h"
#include "system_inertial.h"
#include "system_source_selector.h"
#include "system_log_policy.h"
#include "system_mag_calibration_storage_if.h"
#include "persistent_storage.h"
#include "system_flight_recovery.h"
#include "system_mission_snapshot_if.h"

SystemDeviceResult __real_SystemImu_ConfigApply(const SystemImuConfig *c,SystemDeviceConfigReport *r);
SystemDeviceResult __real_SystemImu_ConfigVerify(const SystemImuConfig *c,SystemDeviceConfigReport *r);
SystemDeviceResult __wrap_SystemImu_ConfigApply(const SystemImuConfig *c,SystemDeviceConfigReport *r)
{
    SystemDeviceResult result=__real_SystemImu_ConfigApply(c,r);
    printf("CONFIG_APPLY time=%llu result=%u\\n",(unsigned long long)s_test_now,(unsigned)result);
    return result;
}
SystemDeviceResult __wrap_SystemImu_ConfigVerify(const SystemImuConfig *c,SystemDeviceConfigReport *r)
{
    static unsigned calls; SystemDeviceResult result=__real_SystemImu_ConfigVerify(c,r);
    if (calls<5U || result!=SYSTEM_DEVICE_BUSY)
    { printf("CONFIG_VERIFY time=%llu result=%u\\n",(unsigned long long)s_test_now,(unsigned)result); }
    calls++; return result;
}

/* These linked-but-unexercised services must never supply fabricated READY.
 * A call aborts the Host run, including snapshot creation on the no-TF path. */
static __attribute__((noreturn)) void Test_UnexpectedService(const char *name)
{ fprintf(stderr,"OUT_OF_SCOPE_SERVICE %s\\n",name); abort(); }
SystemDeviceResult SystemFlightRecovery_Init(void) { Test_UnexpectedService("FlightRecovery_Init"); }
SystemDeviceResult SystemFlightRecovery_Process(const SystemFlightRecoveryInput *input)
{ (void)input; Test_UnexpectedService("FlightRecovery_Process"); }
SystemDeviceResult SystemFlightRecovery_StatusGet(SystemFlightRecoveryStatus *s)
{ (void)s; Test_UnexpectedService("FlightRecovery_StatusGet"); }
void SystemIndicator_Process(void) { Test_UnexpectedService("Indicator_Process"); }
SystemDeviceResult SystemLogSink_Init(void) { Test_UnexpectedService("LogSink_Init"); }
SystemDeviceResult SystemLogSink_SessionBegin(const SystemLogSessionInfo *s)
{ (void)s; Test_UnexpectedService("LogSink_SessionBegin"); }
SystemDeviceResult SystemLogSink_Write(const uint8_t *b, uint32_t n, uint32_t *w)
{ (void)b; (void)n; (void)w; Test_UnexpectedService("LogSink_Write"); }
SystemDeviceResult SystemLogSink_Flush(void) { Test_UnexpectedService("LogSink_Flush"); }
SystemDeviceResult SystemLogSink_SessionEnd(void) { Test_UnexpectedService("LogSink_SessionEnd"); }
SystemMissionSnapshotResult SystemMissionSnapshot_Create(SystemMissionSnapshotStatus *s)
{ (void)s; Test_UnexpectedService("MissionSnapshot_Create"); }
SystemMissionSnapshotResult SystemMissionSnapshot_FinalStatusWrite(uint64_t t,uint8_t f)
{ (void)t; (void)f; Test_UnexpectedService("MissionSnapshot_FinalStatusWrite"); }
SystemDeviceResult Bmp280I2cBarometerInstance_SelfTestRun(uint8_t i,SystemDeviceSelfTestResult *r)
{ (void)i; (void)r; Test_UnexpectedService("Bmp_SelfTest"); }
SystemDeviceResult Bmp280I2cBarometerInstance_EffectiveConfigGet(uint8_t i,SystemBarometerConfig *c)
{ (void)i; (void)c; Test_UnexpectedService("Bmp_EffectiveConfig"); }
SystemDeviceResult Sx1281TelemetryInstance_Send(uint8_t i,const uint8_t *b,uint16_t n)
{ (void)i; (void)b; (void)n; Test_UnexpectedService("E28_Send"); }
SystemDeviceResult Sx1281TelemetryInstance_SendControl(uint8_t i,const uint8_t *b,uint16_t n,uint32_t *t)
{ (void)i; (void)b; (void)n; (void)t; Test_UnexpectedService("E28_SendControl"); }
SystemDeviceResult Sx1281TelemetryInstance_TxResultGet(uint8_t i,uint32_t t,uint32_t *a)
{ (void)i; (void)t; (void)a; Test_UnexpectedService("E28_TxResult"); }
SystemDeviceResult Sx1281TelemetryInstance_Receive(uint8_t i,uint8_t *b,uint16_t c,uint16_t *n)
{ (void)i; (void)b; (void)c; (void)n; Test_UnexpectedService("E28_Receive"); }
SystemDeviceResult Sx1281TelemetryInstance_IoDiagnosticsGet(uint8_t i,SystemDeviceIoDiagnostics *d)
{ (void)i; (void)d; Test_UnexpectedService("E28_Diagnostics"); }
SystemDeviceResult Sx1281TelemetryInstance_SelfTestRun(uint8_t i,SystemDeviceSelfTestResult *r)
{ (void)i; (void)r; Test_UnexpectedService("E28_SelfTest"); }
SystemDeviceResult Sx1281TelemetryInstance_MtuGet(uint8_t i,uint16_t *m)
{ (void)i; (void)m; Test_UnexpectedService("E28_Mtu"); }

/* Physical responses for unqualified Host peripherals. BMP origin samples are
 * separately supplied below; this is not a BMP/E28 or SD hardware test. */
const char *SystemStorage_NameGet(void) { return "Host absent medium"; }
SystemDeviceResult SystemStorage_Init(void) { return SYSTEM_DEVICE_NOT_READY; }
const char *SystemOutput_NameGet(void) { return "Host safe output"; }
SystemDeviceResult SystemOutput_Init(void) { return SYSTEM_DEVICE_OK; }
void SystemOutput_Process(void) { }
SystemDeviceResult Bmp280I2cBarometerInstance_Init(uint8_t i) { (void)i; return SYSTEM_DEVICE_NOT_READY; }
SystemDeviceResult Bmp280I2cBarometerInstance_Start(uint8_t i) { (void)i; return SYSTEM_DEVICE_NOT_READY; }
SystemDeviceResult Bmp280I2cBarometerInstance_Stop(uint8_t i) { (void)i; return SYSTEM_DEVICE_OK; }
SystemDeviceResult Bmp280I2cBarometerInstance_Process(uint8_t i) { (void)i; return SYSTEM_DEVICE_NOT_READY; }
SystemDeviceResult Bmp280I2cBarometerInstance_InfoGet(uint8_t i, SystemDeviceInfo *info)
{ (void)i; memset(info, 0, sizeof(*info)); info->device_name = "Host BMP input"; return SYSTEM_DEVICE_OK; }
SystemDeviceResult Bmp280I2cBarometerInstance_HealthGet(uint8_t i, SystemDeviceHealth *health)
{ (void)i; memset(health, 0, sizeof(*health)); return SYSTEM_DEVICE_OK; }
SystemDeviceResult Bmp280I2cBarometerInstance_CapabilitiesGet(uint8_t i, uint32_t *mask)
{ (void)i; *mask = SYSTEM_BARO_VALID_PRESSURE | SYSTEM_BARO_VALID_ALTITUDE; return SYSTEM_DEVICE_OK; }
SystemDeviceResult Bmp280I2cBarometerInstance_ConfigApply(uint8_t i, const SystemBarometerConfig *c, SystemDeviceConfigReport *r)
{ (void)i; (void)c; memset(r, 0, sizeof(*r)); return SYSTEM_DEVICE_NOT_READY; }
SystemDeviceResult Bmp280I2cBarometerInstance_ConfigVerify(uint8_t i, const SystemBarometerConfig *c, SystemDeviceConfigReport *r)
{ return Bmp280I2cBarometerInstance_ConfigApply(i,c,r); }
SystemDeviceResult Bmp280I2cBarometerInstance_LatestSampleGet(uint8_t i, SystemBarometerSample *s)
{ (void)i; memset(s, 0, sizeof(*s)); return SYSTEM_DEVICE_NOT_READY; }
SystemDeviceResult Bmp280I2cBarometerInstance_NoiseCharacteristicsGet(uint8_t i, SystemBarometerNoiseCharacteristics *n)
{ (void)i; memset(n, 0, sizeof(*n)); return SYSTEM_DEVICE_UNSUPPORTED; }
const char *Sx1281TelemetryInstance_NameGet(uint8_t i) { (void)i; return "Host absent E28"; }
SystemDeviceResult Sx1281TelemetryInstance_Init(uint8_t i) { (void)i; return SYSTEM_DEVICE_NOT_READY; }
SystemDeviceResult Sx1281TelemetryInstance_Start(uint8_t i) { (void)i; return SYSTEM_DEVICE_NOT_READY; }
SystemDeviceResult Sx1281TelemetryInstance_Stop(uint8_t i) { (void)i; return SYSTEM_DEVICE_OK; }
SystemDeviceResult Sx1281TelemetryInstance_Process(uint8_t i) { (void)i; return SYSTEM_DEVICE_NOT_READY; }
SystemDeviceResult Sx1281TelemetryInstance_InfoGet(uint8_t i, SystemDeviceInfo *info)
{ (void)i; memset(info, 0, sizeof(*info)); return SYSTEM_DEVICE_NOT_READY; }
SystemDeviceResult Sx1281TelemetryInstance_HealthGet(uint8_t i, SystemTelemetryHealth *health)
{ (void)i; memset(health, 0, sizeof(*health)); return SYSTEM_DEVICE_OK; }
SystemDeviceResult Sx1281TelemetryInstance_CapabilitiesGet(uint8_t i, uint32_t *mask)
{ (void)i; *mask=0U; return SYSTEM_DEVICE_NOT_READY; }

static uint8_t s_registers[256], s_probe_fail;
static uint8_t s_bmp_registers[256];
PlatformResult __wrap_PlatformI2c_MemoryRead(PlatformI2cId id, uint16_t address, uint16_t reg,
    PlatformI2cMemoryAddressSize size, uint8_t *data, uint16_t length, uint32_t timeout)
{
    if (address==0x76U)
    {
        TEST_CHECK(id==PLATFORM_I2C_1 && size==PLATFORM_I2C_MEMORY_ADDRESS_8_BIT);
        TEST_CHECK(timeout==2U && reg+length<=256U);
        memcpy(data,&s_bmp_registers[reg],length); return PLATFORM_OK;
    }
    TEST_CHECK(id == PLATFORM_I2C_1 && address == 0x68U && size == PLATFORM_I2C_MEMORY_ADDRESS_8_BIT);
    TEST_CHECK(timeout == 2U && reg + length <= 256U);
    if (reg == 117U && s_probe_fail) { return PLATFORM_IO_ERROR; }
    memcpy(data, &s_registers[reg], length); return PLATFORM_OK;
}
PlatformResult __wrap_PlatformI2c_MemoryWrite(PlatformI2cId id, uint16_t address, uint16_t reg,
    PlatformI2cMemoryAddressSize size, const uint8_t *data, uint16_t length, uint32_t timeout)
{
    if (address==0x76U)
    {
        TEST_CHECK(id==PLATFORM_I2C_1 && size==PLATFORM_I2C_MEMORY_ADDRESS_8_BIT);
        TEST_CHECK(timeout==2U && reg+length<=256U);
        memcpy(&s_bmp_registers[reg],data,length); return PLATFORM_OK;
    }
    TEST_CHECK(id == PLATFORM_I2C_1 && address == 0x68U && size == PLATFORM_I2C_MEMORY_ADDRESS_8_BIT);
    TEST_CHECK(timeout == 2U && reg + length <= 256U);
    memcpy(&s_registers[reg], data, length);
    if (reg == 107U && data[0] == 128U) { s_registers[reg] = 0U; }
    return PLATFORM_OK;
}
void Test_ActualInsFeed(void);
void Test_ActualNoStorageAdmission(void);
void Test_MagStorageInputsLoad(void);

static void Test_Tick(uint32_t ms)
{ s_test_now += (uint64_t)ms * 1000ULL; HostPlatformMock_TimeSetUs(s_test_now); SystemImu_Process(); (void)SystemBarometer_Process(); }
static void Test_PhysicalReady(void)
{
    SystemImuSample sample;
    for (uint16_t index=0U; index<3400U; index++)
    { Test_Tick(10U); if (SystemImu_LatestSampleGet(&sample)==SYSTEM_DEVICE_OK) { return; } }
    TEST_CHECK(0);
}
static void Test_Collect(void)
{
    for (uint16_t index=0U; index<200U; index++)
    {
        SystemBarometerSample raw={0}; SystemDeviceHealth baro_health={0};
        Test_Tick(50U); Test_ActualInsFeed();
        TEST_CHECK(SystemBarometer_LatestSampleGet(&raw)==SYSTEM_DEVICE_OK);
        TEST_CHECK(SystemBarometer_HealthGet(&baro_health)==SYSTEM_DEVICE_OK);
        memset(&s_test_pressure, 0, sizeof(s_test_pressure));
        s_test_pressure.altitude_m=raw.altitude_m; s_test_pressure.pressure_pa=raw.pressure_pa;
        s_test_pressure.variance_m2=raw.altitude_variance_m2;
        s_test_pressure.healthy=baro_health.healthy;
        s_test_pressure.sequence=raw.sequence; s_test_pressure.timestamp_us=raw.sample_timestamp_us;
        s_test_pressure.receive_timestamp_us=raw.receive_timestamp_us;
        s_test_pressure.valid=(uint8_t)((raw.valid_fields & SYSTEM_BARO_FIELD_ALTITUDE)!=0U);
        s_test_pressure.supported_fields=raw.supported_fields;
        s_test_pressure.valid_fields=raw.valid_fields;
        TEST_CHECK(EstimatorBus_PressurePublish(&s_test_pressure)==ESTIMATOR_BUS_RESULT_OK);
        Estimator_OriginWindowCollect();
        TEST_CHECK(SystemAlignment_Process()==SYSTEM_DEVICE_OK);
    }
}
static void Test_Observe(const char *phase)
{
    SystemDeviceHealth imu={0}; SystemImuIoDetail io={0}; SystemAlignmentSummary align={0};
    SystemHealthSnapshot health={0}; SystemCalibrationStatus cal={0};
    SystemAlignmentBarometerStatus baro={0}; uint8_t owner=255U;
    TEST_CHECK(SystemImu_HealthGet(&imu)==SYSTEM_DEVICE_OK);
    TEST_CHECK(SystemImu_IoDetailGet(&io)==SYSTEM_DEVICE_OK);
    TEST_CHECK(SystemAlignment_SummaryGet(&align)==SYSTEM_DEVICE_OK);
    TEST_CHECK(SystemCalibration_StatusGet(&cal)==SYSTEM_DEVICE_OK);
    TEST_CHECK(EstimatorTask_BarometerAlignmentStatusGet(&baro)==SYSTEM_DEVICE_OK);
    TEST_CHECK(SystemSourceSelector_ImuActiveInstanceGet(&owner)==SYSTEM_DEVICE_OK);
    SystemHealth_Process(); SystemHealth_GetSnapshot(&health);
    printf("OBS %s state=%u boot=%u failed=0x%lx imu_init=%u online=%u healthy=%u owner=%u epoch=%lu verified=%u CAL=%u CALgen=%lu ALIGN=%u ALIGNgen=%lu baro=%u health=%u blocks=0x%lx storage=%u\\n",
      phase,(unsigned)SystemLifecycle_GetState(),SystemStartup_GetReport()->mission_capable,
      (unsigned long)SystemStartup_GetReport()->required_failure_mask,imu.initialized,imu.online,imu.healthy,owner,
      (unsigned long)io.config_generation,io.config_generation_valid,SystemCalibration_IsReady(),
      (unsigned long)SystemCalibration_GenerationGet(),SystemAlignment_IsReady(),(unsigned long)align.start_sequence,
      baro.ready,health.ready,(unsigned long)health.start_blocking_mask,SystemLifecycleBackend_StorageReadyGet());
}
int main(int argc, char **argv)
{
    SystemStartupReport history; SystemImuIoDetail before={0},after={0}; SystemDeviceHealth health={0};
    unsigned which; TEST_CHECK(argc==2); which=(unsigned)strtoul(argv[1],NULL,10);
    HostPlatformMock_Reset(); HostPlatformMock_TimeSetUs(s_test_now);
    {
        const uint16_t trim[12]={27504U,26435U,(uint16_t)-1000,36477U,(uint16_t)-10685,
            3024U,2855U,140U,(uint16_t)-7,15500U,(uint16_t)-14600,6000U};
        s_bmp_registers[0xD0]=0x58U;
        for (uint8_t i=0U;i<12U;i++)
        { s_bmp_registers[0x88U+2U*i]=(uint8_t)trim[i]; s_bmp_registers[0x89U+2U*i]=(uint8_t)(trim[i]>>8U); }
        s_bmp_registers[0xF7]=0x65U; s_bmp_registers[0xF8]=0x5AU; s_bmp_registers[0xF9]=0xC0U;
        s_bmp_registers[0xFA]=0x7EU; s_bmp_registers[0xFB]=0xEDU;
    }
    s_registers[117]=104U; s_registers[58]=1U;
    s_registers[63]=0x08U; /* actual MPU configured +-16g: stationary 1g */
    s_probe_fail=(uint8_t)(which==1U);
    TEST_CHECK(ImuSampleBus_Init()==IMU_SAMPLE_BUS_RESULT_OK);
    TEST_CHECK(EstimatorBus_Init()==ESTIMATOR_BUS_RESULT_OK);
    TEST_CHECK(LoggerBus_Init()==LOGGER_BUS_RESULT_OK);
    TEST_CHECK(SystemStartup_Run()==SYSTEM_STARTUP_OK);
    for (uint16_t index=0U; index<15000U && !SystemStartup_GetReport()->completed; index++)
    { s_test_now+=10000ULL; HostPlatformMock_TimeSetUs(s_test_now); SystemStartup_ProcessDevices(); }
    TEST_CHECK(SystemStartup_GetReport()->completed!=0U);
    {
        const SystemStartupDeviceReport *d=SystemStartup_GetDeviceReport(SYSTEM_STARTUP_DEVICE_IMU);
        printf("BOOT_IMU init=%u start=%u config=%u verify=%u comm=%u mask=0x%lx\\n",
          (unsigned)d->init_result,(unsigned)d->start_result,(unsigned)d->config_result,
          (unsigned)d->verify_result,(unsigned)d->communication_result,(unsigned long)d->failed_mask);
    }
    history=*SystemStartup_GetReport();
    s_probe_fail=0U; Test_PhysicalReady();
    TEST_CHECK(SystemImu_RuntimeOwnerActivate()==SYSTEM_DEVICE_OK);
    TEST_CHECK(SystemInertial_Init()==SYSTEM_DEVICE_OK);
    SystemCalibration_Init(); SystemAlignment_Init();
    TEST_CHECK(SystemLifecycle_GetState()==SYSTEM_STATE_PREFLIGHT);
    TEST_CHECK(SystemCalibration_Start(SYSTEM_CALIBRATION_MODE_NONE)==SYSTEM_DEVICE_OK);
    TEST_CHECK(SystemAlignment_Start()==SYSTEM_DEVICE_OK);
    Test_MagStorageInputsLoad(); Test_ActualNoStorageAdmission();
    Test_Collect(); Test_Observe("fresh_collection");
    TEST_CHECK(SystemCalibration_IsReady()!=0U && SystemAlignment_IsReady()!=0U);
    TEST_CHECK(SystemImu_IoDetailGet(&before)==SYSTEM_DEVICE_OK);
    if (which==1U)
    {
        TEST_CHECK(SystemStartup_GetReport()->mission_capable==0U);
        TEST_CHECK(SystemLifecycle_StartTransaction()==SYSTEM_LIFECYCLE_START_NOT_READY);
    }
    else
    {
        TEST_CHECK(SystemStartup_GetReport()->mission_capable!=0U);
        TEST_CHECK(SystemLifecycle_EnterReady()==SYSTEM_DEVICE_OK);
        if (which==3U)
        {
            if (!SystemHealth_IsReady())
            { printf("NOT_RUN postSTART: normal startup/qualification baseline failed\\n"); return Test_Finish("compact_mpu_actual_qualification_baseline"); }
            TEST_CHECK(SystemLifecycle_StartTransaction()==SYSTEM_LIFECYCLE_START_OK);
        }
        Test_Observe("before_fault");
        s_probe_fail=1U; Test_Tick(151U); Test_Tick(1U);
        Test_Observe("fault"); s_probe_fail=0U; Test_PhysicalReady();
        TEST_CHECK(SystemImu_IoDetailGet(&after)==SYSTEM_DEVICE_OK);
        TEST_CHECK(after.config_generation>before.config_generation);
        TEST_CHECK(SystemImu_HealthGet(&health)==SYSTEM_DEVICE_OK && !health.healthy);
        Test_Observe("physical_recovery_without_requalification");
        if (which==2U)
        {
            TEST_CHECK(SystemLifecycle_StartTransaction()==SYSTEM_LIFECYCLE_START_NOT_READY);
            TEST_CHECK(SystemCalibration_Start(SYSTEM_CALIBRATION_MODE_NONE)==SYSTEM_DEVICE_OK);
            TEST_CHECK(SystemAlignment_Start()==SYSTEM_DEVICE_OK); Test_Collect();
            Test_Observe("explicit_new_alignment");
            TEST_CHECK(SystemAlignment_IsReady()!=0U);
            TEST_CHECK(SystemLifecycle_StartTransaction()==SYSTEM_LIFECYCLE_START_NOT_READY);
        }
        else
        {
            TEST_CHECK(SystemLifecycle_GetState()==SYSTEM_STATE_FLIGHT);
            TEST_CHECK(SystemCalibration_Start(SYSTEM_CALIBRATION_MODE_NONE)==SYSTEM_DEVICE_BAD_STATE);
            TEST_CHECK(SystemAlignment_Start()==SYSTEM_DEVICE_BAD_STATE);
            TEST_CHECK(SystemLifecycle_StartTransaction()==SYSTEM_LIFECYCLE_START_LOCKED);
        }
    }
    TEST_CHECK(memcmp(&history,SystemStartup_GetReport(),sizeof(history))==0);
    return Test_Finish("compact_mpu_actual_qualification_baseline");
}
''',encoding='utf-8')
(out/'ins_inputs.c').write_text('''#include "APP/Src/ins_task.c"
#include <assert.h>
void Test_ActualInsFeed(void)
{
    SystemInertialSample raw; InsImuSample sample;
    assert(SystemInertial_LatestGet(&raw)==SYSTEM_DEVICE_OK);
    memset(&sample,0,sizeof(sample));
    sample.sample_timestamp_us=raw.sample_timestamp_us;
    sample.receive_timestamp_us=raw.receive_timestamp_us; sample.sequence=raw.sequence;
    memcpy(sample.accel_b_mps2,raw.accel_b_mps2,sizeof(sample.accel_b_mps2));
    memcpy(sample.gyro_b_radps,raw.gyro_b_radps,sizeof(sample.gyro_b_radps));
    sample.valid_mask=raw.valid_mask; sample.quality_flags=raw.quality_flags;
    InsTask_AlignmentProcess(&sample);
}
''')
(out/'storage_inputs.c').write_text('''#include "APP/Src/logger_task.c"
#include <assert.h>
void Test_ActualNoStorageAdmission(void)
{
    /* Real optional absent-medium admission; no snapshot-ready field is set.
     * Logging remains compiled/enabled. Successful on-disk snapshot NOT RUN. */
    assert(LoggerTask_NoStorageLatch()!=0U);
    assert(s_diagnostics.snapshot_ready==0U);
}
''')
mag=(project/'Tests/Host/optional_start_mag_inputs.c').read_text()
mag=mag.replace('../../Devices/Storage/SdSdioFatFs/Adapter/Src/mag_calibration_storage.c','Devices/Storage/SdSdioFatFs/Adapter/Src/mag_calibration_storage.c')
mag=mag.replace('uint8_t ProjectMagnetometerInstance_CountGet(void) { return 1U; }','')
(out/'mag_inputs.c').write_text(mag)
baseline=(out/'baseline.c').read_text()
baseline=re.sub(r'^SystemDeviceResult Bmp280I2cBarometerInstance_[A-Za-z]+\([^;]*?\)\s*\{[^}]*\}\s*','',baseline,flags=re.M)
baseline=baseline.replace(old[:old.index('#include')], '/* Real generated MPU/BMP drivers, CAL_NONE, INS alignment, barometer origin,\n * health and Flight START. Only physical I2C/time/output/persistence inputs\n * are Host models. SD snapshots and the permanent scheduler are out of scope. */\n')
(out/'baseline.c').write_text(baseline)
baseline=(out/'baseline.c').read_text()
begin=baseline.index('static void Test_Collect(void)')
end=baseline.index('static void Test_Observe',begin)
baseline=baseline[:begin]+'''void Test_ActualBarometerPublish(void);
static void Test_Collect(void)
{
    for (uint16_t index=0U;index<200U;index++)
    {
        Test_Tick(50U); Test_ActualInsFeed(); Test_ActualBarometerPublish();
        Estimator_OriginWindowCollect();
        TEST_CHECK(SystemAlignment_Process()==SYSTEM_DEVICE_OK);
    }
}
'''+baseline[end:]
baseline=baseline.replace('static EstimatorPressureSnapshot s_test_pressure;','')
(out/'baseline.c').write_text(baseline)
# Execute the exact bounded DeviceTask projection helper without invoking its
# permanent scheduler loop or unrelated logging/telemetry producers.
device=(project/'APP/Src/device_task.c').read_bytes()
start=device.index(b'static void DeviceTask_PublishBarometer(void)')
finish=device.index(b'\n#if (SILVERSTAR_PROTOCOL_LOGGING_ENABLED',start)
body=device[start:finish]
(out/'baro_inputs.c').write_bytes(b'#include <string.h>\n#include "system_barometer.h"\n#include "system_barometer_if.h"\n#include "estimator_bus.h"\n#include "silverstar_assert.h"\n'+body+b'\nvoid Test_ActualBarometerPublish(void) { DeviceTask_PublishBarometer(); }\n')
import hashlib,json
(out/'baro_extraction.json').write_text(json.dumps({'source':'APP/Src/device_task.c','source_sha256':hashlib.sha256(device).hexdigest(),
 'helper':'DeviceTask_PublishBarometer','exact_raw_sha256':hashlib.sha256(body).hexdigest(),'edited':False},indent=2))
print(out)
