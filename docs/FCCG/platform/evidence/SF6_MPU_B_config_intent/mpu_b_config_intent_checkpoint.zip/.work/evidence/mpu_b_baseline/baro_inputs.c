#include <string.h>
#include "system_barometer.h"
#include "system_barometer_if.h"
#include "estimator_bus.h"
#include "silverstar_assert.h"
static void DeviceTask_PublishBarometer(void)
{
    static uint32_t last_sequence;
    SystemBarometerSample sample;
    SystemDeviceHealth health;
    EstimatorPressureSnapshot snapshot;

    if ((SystemBarometer_LatestSampleGet(&sample) != SYSTEM_DEVICE_OK) ||
        (sample.sequence == last_sequence))
    {
        return;
    }
    SILVERSTAR_ASSERT((sample.valid_fields & ~sample.supported_fields) == 0U,
        SILVERSTAR_ASSERT_MODULE_APP, SILVERSTAR_ASSERT_REASON_STATE_INVARIANT);
    SILVERSTAR_ASSERT(sample.measurement_timestamp_trusted <= 1U,
        SILVERSTAR_ASSERT_MODULE_APP, SILVERSTAR_ASSERT_REASON_STATE_INVARIANT);
    last_sequence = sample.sequence;
    snapshot.timestamp_us = sample.sample_timestamp_us;
    snapshot.receive_timestamp_us = sample.receive_timestamp_us;
    snapshot.measurement_timestamp_trusted = sample.measurement_timestamp_trusted;
    snapshot.sequence = sample.sequence;
    snapshot.pressure_raw_pa = sample.pressure_raw_pa;
    snapshot.height_raw_cm = sample.altitude_raw_cm;
    snapshot.pressure_pa = sample.pressure_pa;
    snapshot.altitude_m = sample.altitude_m;
    snapshot.variance_m2 = sample.altitude_variance_m2;
    snapshot.supported_fields = sample.supported_fields;
    snapshot.valid_fields = sample.valid_fields;
    if (SYSTEM_BUILD_BAROMETER_COLD_ENABLED != 0U)
    {
        /* Raw pressure/height remain unchanged; the navigation/landing altitude
         * is derived on the same pressure datum for every selected source. */
        snapshot.valid_fields &= ~(uint32_t)SYSTEM_BARO_FIELD_ALTITUDE;
    }
    if (((snapshot.valid_fields & SYSTEM_BARO_FIELD_ALTITUDE) == 0U) &&
        ((snapshot.valid_fields & SYSTEM_BARO_FIELD_PRESSURE) != 0U) &&
        (SystemBarometer_AltitudeResolve(&sample, &snapshot.altitude_m) ==
            SYSTEM_DEVICE_OK))
    {
        snapshot.supported_fields |= SYSTEM_BARO_FIELD_ALTITUDE;
        snapshot.valid_fields |= SYSTEM_BARO_FIELD_ALTITUDE;
    }
    (void)memset(&health, 0, sizeof(health));
    snapshot.healthy = (uint8_t)(
        (SystemBarometer_HealthGet(&health) == SYSTEM_DEVICE_OK) &&
        (health.online != 0U) && (health.healthy != 0U));
    snapshot.valid = (uint8_t)((sample.valid_fields &
        (SYSTEM_BARO_FIELD_PRESSURE | SYSTEM_BARO_FIELD_ALTITUDE)) != 0U);
    (void)EstimatorBus_PressurePublish(&snapshot);
}

void Test_ActualBarometerPublish(void) { DeviceTask_PublishBarometer(); }
