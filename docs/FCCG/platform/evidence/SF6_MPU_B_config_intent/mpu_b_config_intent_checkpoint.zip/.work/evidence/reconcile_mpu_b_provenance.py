from pathlib import Path
import json, hashlib, subprocess, datetime
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.generator.assembler import ProjectAssembler
from silverstar_fccg.core.workspace import WorkspacePolicy
from silverstar_fccg.project.model import ProjectModel_Load

root=Path.cwd(); project=root/'.work/generated_ret6'; out=root/'.work/evidence/mpu_b_baseline'
path=project/'SilverStar.ssproject'; before=path.read_bytes()
model=ProjectModel_Load(path); service=FccgService(root/'apps/SCG')
reconciled=service.ProjectConfiguration_Reconcile(model)
catalog=service.catalog.ProjectView_Get(reconciled.model)
assembler=ProjectAssembler(WorkspacePolicy(root/'.work'),catalog)
desired,ownership=assembler._DesiredFiles_Get(reconciled.model,project)
normal_saved=json.loads(desired['SilverStar.ssproject'])
deleted='Common/Inc/silverstar_build_mode.h'; component='silverstar.core.0_1_0'
def record(provenance): return provenance.get(component,{}).get('files',{}).get(deleted)
current=ownership['upstream_components'][component]['files']
report={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'operation':'FccgService.ProjectConfiguration_Reconcile then normal assembler desired-file plan; read only',
 'project_file_sha256':hashlib.sha256(before).hexdigest(),
 'project_file_unchanged':path.read_bytes()==before,
 'deleted_path':deleted,'saved_old_record':record(model.component_provenance),
 'reconciled_old_record':record(reconciled.model.component_provenance),
 'normal_apply_would_keep_record':record(normal_saved['component_provenance']),
 'current_upstream_contains_deleted_path':deleted in current,
 'actual_generated_deleted_file_exists':(project/deleted).exists(),
 'identity_status':'NOT PROVEN: recorded historical payload provenance remains intentionally preserved; no adoption or manual hash rewrite'}
(out/'provenance_reconcile.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
