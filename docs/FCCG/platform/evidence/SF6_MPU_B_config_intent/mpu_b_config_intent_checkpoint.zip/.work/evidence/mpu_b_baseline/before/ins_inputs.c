#include "APP/Src/ins_task.c"
#include <assert.h>
void Test_ActualInsFeed(void)
{
    SystemInertialSample raw; InsImuSample sample;
    assert(SystemInertial_LatestGet(&raw)==SYSTEM_DEVICE_OK);
    memset(&sample,0,sizeof(sample));
    sample.sample_timestamp_us=raw.sample_timestamp_us;
    sample.receive_timestamp_us=raw.receive_timestamp_us; sample.sequence=raw.sequence;
    memcpy(sample.accel_b_mps2,raw.accel_b_mps2,sizeof(sample.accel_b_mps2));
    memcpy(sample.gyro_b_radps,raw.gyro_b_radps,sizeof(sample.gyro_b_radps));
    sample.valid_mask=raw.valid_mask; sample.quality_flags=raw.quality_flags;
    InsTask_AlignmentProcess(&sample);
}
