#include "APP/Src/logger_task.c"
#include <assert.h>
void Test_ActualNoStorageAdmission(void)
{
    /* Real optional absent-medium admission; no snapshot-ready field is set.
     * Logging remains compiled/enabled. Successful on-disk snapshot NOT RUN. */
    assert(LoggerTask_NoStorageLatch()!=0U);
    assert(s_diagnostics.snapshot_ready==0U);
}
