from pathlib import Path
import json,os,subprocess,time,hashlib,datetime,sys
root=Path.cwd(); project=root/'.work/generated_ret6'; evidence=root/'.work/evidence/mpu_ret6_b_startup_gates'; evidence.mkdir(exist_ok=True)
env=dict(os.environ);env['PATH']='D:/python_software/SilverStar/apps/FLP/.venv/Scripts;D:/msys64/ucrt64/bin;'+env['PATH']
make='D:/msys64/ucrt64/bin/mingw32-make.exe'; toolchain='D:/Arm GNU Toolchain/14.3 rel1/bin'
base=[make,'GCC_PATH='+toolchain,'CONFIG=Release','HOST_CC=D:/msys64/ucrt64/bin/gcc.exe']
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
jobs=[('arm',base+['-B','-j2','all']),('analyzer',base+['-B','-j2','static-analysis']),
      ('architecture',base+['architecture-check']),('power10',base+['power10-check']),
      ('artifact',base+['artifact-check']),('stack',base+['stack-report']),('official_host',base+['host-tests']),
      ('linked_sources',base+['list-sources'])]
if len(sys.argv)>1: jobs=[j for j in jobs if j[0]==sys.argv[1]]
rows=json.loads((evidence/'results.json').read_text()) if (evidence/'results.json').exists() else []
for name,argv in jobs:
 log=evidence/(name+'.log');start=time.monotonic();began=datetime.datetime.now(datetime.timezone.utc).isoformat()
 print('START '+name,flush=True)
 try:
  with log.open('w',encoding='utf-8') as out:
   out.write('COMMAND_ARGV='+json.dumps(argv)+'\nSOURCE_COMMIT='+source+'\nUTC_START='+began+'\n');out.flush()
   r=subprocess.run(argv,cwd=project,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=600)
   exitcode=r.returncode
 except subprocess.TimeoutExpired: exitcode='TIMEOUT_600S'
 row={'name':name,'argv':argv,'source_commit':source,'utc_start':began,'exit':exitcode,
      'seconds':time.monotonic()-start,'log':str(log.relative_to(root)), 'sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 rows.append(row);(evidence/'results.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
 print(json.dumps(row),flush=True)
print('COMPLETE '+str(len(rows)),flush=True)
