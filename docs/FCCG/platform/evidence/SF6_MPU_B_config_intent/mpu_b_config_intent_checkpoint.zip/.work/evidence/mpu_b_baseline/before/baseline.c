/* Actual generated Alignment, lifecycle transaction, origin collector and
 * selected estimator kernel. Sensor/attitude and storage inputs are fixtures;
 * neither readiness, FreezeOrigins nor START is replaced. Actual selected
 * INS/alignment, health, logging-enabled storage admission and task interfaces
 * execute; raw storage projections are inputs, not new SD qualification. */
#include "APP/Src/estimator_task.c"
#include "test_common.h"
#include "host_platform_mock.h"
#include "system_health.h"
#include "system_startup.h"
#include "system_alignment_backend.h"
#include "system_gnss_quality.h"
#include "system_imu_if.h"
#include "system_magnetometer_if.h"
#include "system_hardware_quaternion_if.h"
#include "system_storage_if.h"
#include "system_log_sink_if.h"
#include "system_console_if.h"
#include "system_telemetry_transport_if.h"
#include "system_power_if.h"
#include "system_mag_calibration.h"
#include "system_mag_calibration_storage_if.h"
#include "system_log_policy.h"
#include "optional_start_inputs.h"
#include "system_profile.h"
#include "system_output_if.h"
#include "system_lifecycle_backend.h"
#include "imu_sample_bus.h"

static uint64_t s_test_now = 1000000ULL;

static EstimatorPressureSnapshot s_test_pressure;
static uint8_t s_storage_ready;

void vTaskDelay(TickType_t ticks)
{ s_test_now += (uint64_t)ticks * 1000ULL; HostPlatformMock_TimeSetUs(s_test_now); }
SystemDeviceResult SystemOutput_SafeSet(void) { return SYSTEM_DEVICE_OK; }


SystemDeviceResult SystemConsoleDevice_HealthGet(SystemConsoleHealth *health)
{ memset(health, 0, sizeof(*health)); health->initialized = 1U; health->healthy = 1U; return SYSTEM_DEVICE_OK; }
SystemDeviceResult SystemOutput_StatusGet(uint8_t channel, SystemOutputStatus *status)
{ memset(status, 0, sizeof(*status)); status->channel = channel; status->state = SYSTEM_OUTPUT_SAFE; return SYSTEM_DEVICE_OK; }
SystemDeviceResult SystemStorage_HealthGet(SystemStorageHealth *health)
{ memset(health, 0, sizeof(*health)); health->initialized = 1U; health->mounted = s_storage_ready; health->healthy = s_storage_ready; health->initial_probe_complete = 1U; health->initial_medium_unavailable = (uint8_t)!s_storage_ready; return SYSTEM_DEVICE_OK; }
SystemDeviceResult SystemStorage_MissionIdGet(uint32_t *mission_id) { *mission_id = 1U; return SYSTEM_DEVICE_OK; }
SystemDeviceResult SystemLogSink_HealthGet(SystemLogSinkHealth *health)
{ memset(health, 0, sizeof(*health)); health->initialized = 1U; health->session_active = 1U; health->healthy = s_storage_ready; return SYSTEM_DEVICE_OK; }

#include <assert.h>
#include <stdlib.h>
#include "mpu6050_instance.h"
#include "platform_i2c.h"
#include "bmp280_instance.h"
#include "sx1281_instance.h"
#include "system_inertial.h"
#include "system_source_selector.h"
#include "system_log_policy.h"
#include "system_mag_calibration_storage_if.h"
#include "persistent_storage.h"
#include "system_flight_recovery.h"
#include "system_mission_snapshot_if.h"

SystemDeviceResult __real_SystemImu_ConfigApply(const SystemImuConfig *c,SystemDeviceConfigReport *r);
SystemDeviceResult __real_SystemImu_ConfigVerify(const SystemImuConfig *c,SystemDeviceConfigReport *r);
SystemDeviceResult __wrap_SystemImu_ConfigApply(const SystemImuConfig *c,SystemDeviceConfigReport *r)
{
    SystemDeviceResult result=__real_SystemImu_ConfigApply(c,r);
    printf("CONFIG_APPLY time=%llu result=%u\n",(unsigned long long)s_test_now,(unsigned)result);
    return result;
}
SystemDeviceResult __wrap_SystemImu_ConfigVerify(const SystemImuConfig *c,SystemDeviceConfigReport *r)
{
    static unsigned calls; SystemDeviceResult result=__real_SystemImu_ConfigVerify(c,r);
    if (calls<5U || result!=SYSTEM_DEVICE_BUSY)
    { printf("CONFIG_VERIFY time=%llu result=%u\n",(unsigned long long)s_test_now,(unsigned)result); }
    calls++; return result;
}

/* These linked-but-unexercised services must never supply fabricated READY.
 * A call aborts the Host run, including snapshot creation on the no-TF path. */
static __attribute__((noreturn)) void Test_UnexpectedService(const char *name)
{ fprintf(stderr,"OUT_OF_SCOPE_SERVICE %s\n",name); abort(); }
SystemDeviceResult SystemFlightRecovery_Init(void) { Test_UnexpectedService("FlightRecovery_Init"); }
SystemDeviceResult SystemFlightRecovery_Process(const SystemFlightRecoveryInput *input)
{ (void)input; Test_UnexpectedService("FlightRecovery_Process"); }
SystemDeviceResult SystemFlightRecovery_StatusGet(SystemFlightRecoveryStatus *s)
{ (void)s; Test_UnexpectedService("FlightRecovery_StatusGet"); }
void SystemIndicator_Process(void) { Test_UnexpectedService("Indicator_Process"); }
SystemDeviceResult SystemLogSink_Init(void) { Test_UnexpectedService("LogSink_Init"); }
SystemDeviceResult SystemLogSink_SessionBegin(const SystemLogSessionInfo *s)
{ (void)s; Test_UnexpectedService("LogSink_SessionBegin"); }
SystemDeviceResult SystemLogSink_Write(const uint8_t *b, uint32_t n, uint32_t *w)
{ (void)b; (void)n; (void)w; Test_UnexpectedService("LogSink_Write"); }
SystemDeviceResult SystemLogSink_Flush(void) { Test_UnexpectedService("LogSink_Flush"); }
SystemDeviceResult SystemLogSink_SessionEnd(void) { Test_UnexpectedService("LogSink_SessionEnd"); }
SystemMissionSnapshotResult SystemMissionSnapshot_Create(SystemMissionSnapshotStatus *s)
{ (void)s; Test_UnexpectedService("MissionSnapshot_Create"); }
SystemMissionSnapshotResult SystemMissionSnapshot_FinalStatusWrite(uint64_t t,uint8_t f)
{ (void)t; (void)f; Test_UnexpectedService("MissionSnapshot_FinalStatusWrite"); }
SystemDeviceResult Bmp280I2cBarometerInstance_SelfTestRun(uint8_t i,SystemDeviceSelfTestResult *r)
{ (void)i; (void)r; Test_UnexpectedService("Bmp_SelfTest"); }
SystemDeviceResult Bmp280I2cBarometerInstance_EffectiveConfigGet(uint8_t i,SystemBarometerConfig *c)
{ (void)i; (void)c; Test_UnexpectedService("Bmp_EffectiveConfig"); }
SystemDeviceResult Sx1281TelemetryInstance_Send(uint8_t i,const uint8_t *b,uint16_t n)
{ (void)i; (void)b; (void)n; Test_UnexpectedService("E28_Send"); }
SystemDeviceResult Sx1281TelemetryInstance_SendControl(uint8_t i,const uint8_t *b,uint16_t n,uint32_t *t)
{ (void)i; (void)b; (void)n; (void)t; Test_UnexpectedService("E28_SendControl"); }
SystemDeviceResult Sx1281TelemetryInstance_TxResultGet(uint8_t i,uint32_t t,uint32_t *a)
{ (void)i; (void)t; (void)a; Test_UnexpectedService("E28_TxResult"); }
SystemDeviceResult Sx1281TelemetryInstance_Receive(uint8_t i,uint8_t *b,uint16_t c,uint16_t *n)
{ (void)i; (void)b; (void)c; (void)n; Test_UnexpectedService("E28_Receive"); }
SystemDeviceResult Sx1281TelemetryInstance_IoDiagnosticsGet(uint8_t i,SystemDeviceIoDiagnostics *d)
{ (void)i; (void)d; Test_UnexpectedService("E28_Diagnostics"); }
SystemDeviceResult Sx1281TelemetryInstance_SelfTestRun(uint8_t i,SystemDeviceSelfTestResult *r)
{ (void)i; (void)r; Test_UnexpectedService("E28_SelfTest"); }
SystemDeviceResult Sx1281TelemetryInstance_MtuGet(uint8_t i,uint16_t *m)
{ (void)i; (void)m; Test_UnexpectedService("E28_Mtu"); }

/* Physical responses for unqualified Host peripherals. BMP origin samples are
 * separately supplied below; this is not a BMP/E28 or SD hardware test. */
const char *SystemStorage_NameGet(void) { return "Host absent medium"; }
SystemDeviceResult SystemStorage_Init(void) { return SYSTEM_DEVICE_NOT_READY; }
const char *SystemOutput_NameGet(void) { return "Host safe output"; }
SystemDeviceResult SystemOutput_Init(void) { return SYSTEM_DEVICE_OK; }
void SystemOutput_Process(void) { }
SystemDeviceResult Bmp280I2cBarometerInstance_Init(uint8_t i) { (void)i; return SYSTEM_DEVICE_NOT_READY; }
SystemDeviceResult Bmp280I2cBarometerInstance_Start(uint8_t i) { (void)i; return SYSTEM_DEVICE_NOT_READY; }
SystemDeviceResult Bmp280I2cBarometerInstance_Stop(uint8_t i) { (void)i; return SYSTEM_DEVICE_OK; }
SystemDeviceResult Bmp280I2cBarometerInstance_Process(uint8_t i) { (void)i; return SYSTEM_DEVICE_NOT_READY; }
SystemDeviceResult Bmp280I2cBarometerInstance_InfoGet(uint8_t i, SystemDeviceInfo *info)
{ (void)i; memset(info, 0, sizeof(*info)); info->device_name = "Host BMP input"; return SYSTEM_DEVICE_OK; }
SystemDeviceResult Bmp280I2cBarometerInstance_HealthGet(uint8_t i, SystemDeviceHealth *health)
{ (void)i; memset(health, 0, sizeof(*health)); return SYSTEM_DEVICE_OK; }
SystemDeviceResult Bmp280I2cBarometerInstance_CapabilitiesGet(uint8_t i, uint32_t *mask)
{ (void)i; *mask = SYSTEM_BARO_VALID_PRESSURE | SYSTEM_BARO_VALID_ALTITUDE; return SYSTEM_DEVICE_OK; }
SystemDeviceResult Bmp280I2cBarometerInstance_ConfigApply(uint8_t i, const SystemBarometerConfig *c, SystemDeviceConfigReport *r)
{ (void)i; (void)c; memset(r, 0, sizeof(*r)); return SYSTEM_DEVICE_NOT_READY; }
SystemDeviceResult Bmp280I2cBarometerInstance_ConfigVerify(uint8_t i, const SystemBarometerConfig *c, SystemDeviceConfigReport *r)
{ return Bmp280I2cBarometerInstance_ConfigApply(i,c,r); }
SystemDeviceResult Bmp280I2cBarometerInstance_LatestSampleGet(uint8_t i, SystemBarometerSample *s)
{ (void)i; memset(s, 0, sizeof(*s)); return SYSTEM_DEVICE_NOT_READY; }
SystemDeviceResult Bmp280I2cBarometerInstance_NoiseCharacteristicsGet(uint8_t i, SystemBarometerNoiseCharacteristics *n)
{ (void)i; memset(n, 0, sizeof(*n)); return SYSTEM_DEVICE_UNSUPPORTED; }
const char *Sx1281TelemetryInstance_NameGet(uint8_t i) { (void)i; return "Host absent E28"; }
SystemDeviceResult Sx1281TelemetryInstance_Init(uint8_t i) { (void)i; return SYSTEM_DEVICE_NOT_READY; }
SystemDeviceResult Sx1281TelemetryInstance_Start(uint8_t i) { (void)i; return SYSTEM_DEVICE_NOT_READY; }
SystemDeviceResult Sx1281TelemetryInstance_Stop(uint8_t i) { (void)i; return SYSTEM_DEVICE_OK; }
SystemDeviceResult Sx1281TelemetryInstance_Process(uint8_t i) { (void)i; return SYSTEM_DEVICE_NOT_READY; }
SystemDeviceResult Sx1281TelemetryInstance_InfoGet(uint8_t i, SystemDeviceInfo *info)
{ (void)i; memset(info, 0, sizeof(*info)); return SYSTEM_DEVICE_NOT_READY; }
SystemDeviceResult Sx1281TelemetryInstance_HealthGet(uint8_t i, SystemTelemetryHealth *health)
{ (void)i; memset(health, 0, sizeof(*health)); return SYSTEM_DEVICE_OK; }
SystemDeviceResult Sx1281TelemetryInstance_CapabilitiesGet(uint8_t i, uint32_t *mask)
{ (void)i; *mask=0U; return SYSTEM_DEVICE_NOT_READY; }

static uint8_t s_registers[256], s_probe_fail;
PlatformResult __wrap_PlatformI2c_MemoryRead(PlatformI2cId id, uint16_t address, uint16_t reg,
    PlatformI2cMemoryAddressSize size, uint8_t *data, uint16_t length, uint32_t timeout)
{
    TEST_CHECK(id == PLATFORM_I2C_1 && address == 0x68U && size == PLATFORM_I2C_MEMORY_ADDRESS_8_BIT);
    TEST_CHECK(timeout == 2U && reg + length <= 256U);
    if (reg == 117U && s_probe_fail) { return PLATFORM_IO_ERROR; }
    memcpy(data, &s_registers[reg], length); return PLATFORM_OK;
}
PlatformResult __wrap_PlatformI2c_MemoryWrite(PlatformI2cId id, uint16_t address, uint16_t reg,
    PlatformI2cMemoryAddressSize size, const uint8_t *data, uint16_t length, uint32_t timeout)
{
    TEST_CHECK(id == PLATFORM_I2C_1 && address == 0x68U && size == PLATFORM_I2C_MEMORY_ADDRESS_8_BIT);
    TEST_CHECK(timeout == 2U && reg + length <= 256U);
    memcpy(&s_registers[reg], data, length);
    if (reg == 107U && data[0] == 128U) { s_registers[reg] = 0U; }
    return PLATFORM_OK;
}
void Test_ActualInsFeed(void);
void Test_ActualNoStorageAdmission(void);
void Test_MagStorageInputsLoad(void);

static void Test_Tick(uint32_t ms)
{ s_test_now += (uint64_t)ms * 1000ULL; HostPlatformMock_TimeSetUs(s_test_now); SystemImu_Process(); }
static void Test_PhysicalReady(void)
{
    SystemImuSample sample;
    for (uint16_t index=0U; index<3400U; index++)
    { Test_Tick(10U); if (SystemImu_LatestSampleGet(&sample)==SYSTEM_DEVICE_OK) { return; } }
    TEST_CHECK(0);
}
static void Test_Collect(void)
{
    for (uint16_t index=0U; index<200U; index++)
    {
        Test_Tick(50U); Test_ActualInsFeed();
        memset(&s_test_pressure, 0, sizeof(s_test_pressure));
        s_test_pressure.altitude_m=10.0f; s_test_pressure.pressure_pa=101325.0f;
        s_test_pressure.sequence=index+1U; s_test_pressure.timestamp_us=s_test_now;
        s_test_pressure.receive_timestamp_us=s_test_now; s_test_pressure.valid=1U;
        s_test_pressure.supported_fields=SYSTEM_BARO_FIELD_PRESSURE | SYSTEM_BARO_FIELD_ALTITUDE;
        s_test_pressure.valid_fields=s_test_pressure.supported_fields;
        TEST_CHECK(EstimatorBus_PressurePublish(&s_test_pressure)==ESTIMATOR_BUS_RESULT_OK);
        Estimator_OriginWindowCollect();
        TEST_CHECK(SystemAlignment_Process()==SYSTEM_DEVICE_OK);
    }
}
static void Test_Observe(const char *phase)
{
    SystemDeviceHealth imu={0}; SystemImuIoDetail io={0}; SystemAlignmentSummary align={0};
    SystemHealthSnapshot health={0}; SystemCalibrationStatus cal={0};
    SystemAlignmentBarometerStatus baro={0}; uint8_t owner=255U;
    TEST_CHECK(SystemImu_HealthGet(&imu)==SYSTEM_DEVICE_OK);
    TEST_CHECK(SystemImu_IoDetailGet(&io)==SYSTEM_DEVICE_OK);
    TEST_CHECK(SystemAlignment_SummaryGet(&align)==SYSTEM_DEVICE_OK);
    TEST_CHECK(SystemCalibration_StatusGet(&cal)==SYSTEM_DEVICE_OK);
    TEST_CHECK(EstimatorTask_BarometerAlignmentStatusGet(&baro)==SYSTEM_DEVICE_OK);
    TEST_CHECK(SystemSourceSelector_ImuActiveInstanceGet(&owner)==SYSTEM_DEVICE_OK);
    SystemHealth_Process(); SystemHealth_GetSnapshot(&health);
    printf("OBS %s state=%u boot=%u failed=0x%lx imu_init=%u online=%u healthy=%u owner=%u epoch=%lu verified=%u CAL=%u CALgen=%lu ALIGN=%u ALIGNgen=%lu baro=%u health=%u blocks=0x%lx storage=%u\n",
      phase,(unsigned)SystemLifecycle_GetState(),SystemStartup_GetReport()->mission_capable,
      (unsigned long)SystemStartup_GetReport()->required_failure_mask,imu.initialized,imu.online,imu.healthy,owner,
      (unsigned long)io.config_generation,io.config_generation_valid,SystemCalibration_IsReady(),
      (unsigned long)SystemCalibration_GenerationGet(),SystemAlignment_IsReady(),(unsigned long)align.start_sequence,
      baro.ready,health.ready,(unsigned long)health.start_blocking_mask,SystemLifecycleBackend_StorageReadyGet());
}
int main(int argc, char **argv)
{
    SystemStartupReport history; SystemImuIoDetail before={0},after={0}; SystemDeviceHealth health={0};
    unsigned which; TEST_CHECK(argc==2); which=(unsigned)strtoul(argv[1],NULL,10);
    HostPlatformMock_Reset(); HostPlatformMock_TimeSetUs(s_test_now);
    s_registers[117]=104U; s_registers[58]=1U;
    s_registers[63]=0x08U; /* actual MPU configured +-16g: stationary 1g */
    s_probe_fail=(uint8_t)(which==1U);
    TEST_CHECK(ImuSampleBus_Init()==IMU_SAMPLE_BUS_RESULT_OK);
    TEST_CHECK(EstimatorBus_Init()==ESTIMATOR_BUS_RESULT_OK);
    TEST_CHECK(LoggerBus_Init()==LOGGER_BUS_RESULT_OK);
    TEST_CHECK(SystemStartup_Run()==SYSTEM_STARTUP_OK);
    for (uint16_t index=0U; index<15000U && !SystemStartup_GetReport()->completed; index++)
    { s_test_now+=10000ULL; HostPlatformMock_TimeSetUs(s_test_now); SystemStartup_ProcessDevices(); }
    TEST_CHECK(SystemStartup_GetReport()->completed!=0U);
    {
        const SystemStartupDeviceReport *d=SystemStartup_GetDeviceReport(SYSTEM_STARTUP_DEVICE_IMU);
        printf("BOOT_IMU init=%u start=%u config=%u verify=%u comm=%u mask=0x%lx\n",
          (unsigned)d->init_result,(unsigned)d->start_result,(unsigned)d->config_result,
          (unsigned)d->verify_result,(unsigned)d->communication_result,(unsigned long)d->failed_mask);
    }
    history=*SystemStartup_GetReport();
    s_probe_fail=0U; Test_PhysicalReady();
    TEST_CHECK(SystemImu_RuntimeOwnerActivate()==SYSTEM_DEVICE_OK);
    TEST_CHECK(SystemInertial_Init()==SYSTEM_DEVICE_OK);
    SystemCalibration_Init(); SystemAlignment_Init();
    TEST_CHECK(SystemLifecycle_GetState()==SYSTEM_STATE_PREFLIGHT);
    TEST_CHECK(SystemCalibration_Start(SYSTEM_CALIBRATION_MODE_NONE)==SYSTEM_DEVICE_OK);
    TEST_CHECK(SystemAlignment_Start()==SYSTEM_DEVICE_OK);
    Test_MagStorageInputsLoad(); Test_ActualNoStorageAdmission();
    Test_Collect(); Test_Observe("fresh_collection");
    TEST_CHECK(SystemCalibration_IsReady()!=0U && SystemAlignment_IsReady()!=0U);
    TEST_CHECK(SystemImu_IoDetailGet(&before)==SYSTEM_DEVICE_OK);
    if (which==1U)
    {
        TEST_CHECK(SystemStartup_GetReport()->mission_capable==0U);
        TEST_CHECK(SystemLifecycle_StartTransaction()==SYSTEM_LIFECYCLE_START_NOT_READY);
    }
    else
    {
        TEST_CHECK(SystemStartup_GetReport()->mission_capable!=0U);
        TEST_CHECK(SystemLifecycle_EnterReady()==SYSTEM_DEVICE_OK);
        if (which==3U)
        {
            if (!SystemHealth_IsReady())
            { printf("NOT_RUN postSTART: normal startup/qualification baseline failed\n"); return Test_Finish("compact_mpu_actual_qualification_baseline"); }
            TEST_CHECK(SystemLifecycle_StartTransaction()==SYSTEM_LIFECYCLE_START_OK);
        }
        Test_Observe("before_fault");
        s_probe_fail=1U; Test_Tick(151U); Test_Tick(1U);
        Test_Observe("fault"); s_probe_fail=0U; Test_PhysicalReady();
        TEST_CHECK(SystemImu_IoDetailGet(&after)==SYSTEM_DEVICE_OK);
        TEST_CHECK(after.config_generation>before.config_generation);
        TEST_CHECK(SystemImu_HealthGet(&health)==SYSTEM_DEVICE_OK && !health.healthy);
        Test_Observe("physical_recovery_without_requalification");
        if (which==2U)
        {
            TEST_CHECK(SystemLifecycle_StartTransaction()==SYSTEM_LIFECYCLE_START_NOT_READY);
            TEST_CHECK(SystemAlignment_Start()==SYSTEM_DEVICE_OK); Test_Collect();
            Test_Observe("explicit_new_alignment");
            TEST_CHECK(SystemAlignment_IsReady()!=0U);
            TEST_CHECK(SystemLifecycle_StartTransaction()==SYSTEM_LIFECYCLE_START_NOT_READY);
        }
        else
        {
            TEST_CHECK(SystemLifecycle_GetState()==SYSTEM_STATE_FLIGHT);
            TEST_CHECK(SystemCalibration_Start(SYSTEM_CALIBRATION_MODE_NONE)==SYSTEM_DEVICE_BAD_STATE);
            TEST_CHECK(SystemAlignment_Start()==SYSTEM_DEVICE_BAD_STATE);
            TEST_CHECK(SystemLifecycle_StartTransaction()==SYSTEM_LIFECYCLE_START_LOCKED);
        }
    }
    TEST_CHECK(memcmp(&history,SystemStartup_GetReport(),sizeof(history))==0);
    return Test_Finish("compact_mpu_actual_qualification_baseline");
}
