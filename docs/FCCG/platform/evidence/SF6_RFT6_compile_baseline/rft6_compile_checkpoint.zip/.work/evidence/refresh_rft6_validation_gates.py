from pathlib import Path
import json,hashlib,subprocess,sys
root=Path.cwd();project=(root/'.work/generated_rft6').resolve()
assert project.is_relative_to((root/'.work').resolve())
assert json.loads((project/'SilverStar.ssproject').read_text(encoding='utf-8'))['project']['name']=='SF6_RFT6_Baseline'
base='apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/'
rows=[]
for rel in ('Tools/check_architecture.ps1','Tools/check_firmware_artifact.ps1'):
    target=project/rel; source=root/base/rel
    prior=sys.argv[1] if len(sys.argv)>1 else '2745c8f'
    old=subprocess.check_output(['git','show',prior+':'+base+rel])
    actual=target.read_bytes(); new=source.read_bytes()
    assert actual.replace(b'\r\n',b'\n')==old.replace(b'\r\n',b'\n'),rel
    rows.append({'file':rel,'before_sha256':hashlib.sha256(actual).hexdigest(),
                 'current_template_sha256':hashlib.sha256(new).hexdigest()})
    target.write_bytes(new)
result={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
        'scope':'Explicit disposable RFT6 validation tree only; normal Apply preserved payload; no user firmware or ownership hash edits',
        'checker_change':'Exact F103RF target facts; CM3/F1 selection and F1 SD scratch checks apply to RET6+RFT6. Other thresholds unchanged.',
        'files':rows}
(root/'.work/evidence/rft6_baseline/validation_gate_refresh.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
