from pathlib import Path
import subprocess,json,hashlib
root=Path.cwd(); evidence=root/'.work/evidence/rft6_baseline'; project=root/'.work/generated_rft6'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
log=root/'.work/evidence/generate_rft6_2.log'
assert 'PLAN True' in log.read_text(encoding='utf-8')
assert 'files_added=1526' in log.read_text(encoding='utf-8')
paths=[Path(p) for p in subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()]
paths += [Path(p) for p in subprocess.check_output(['git','ls-files','--others','--exclude-standard','apps/SCG'],text=True).splitlines()]
snapshot={p.as_posix():digest(root/p) for p in paths}
(evidence/'dirty_source_snapshot.json').write_text(json.dumps(snapshot,indent=2)+'\n',encoding='utf-8')
config={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'dirty_source_snapshot_sha256':digest(evidence/'dirty_source_snapshot.json'),
    'target':'STM32F103RFT6','compact_mode':True,'logging_profile':'all_streams',
    'arm_flags':['-mcpu=cortex-m3','-mthumb','-mfloat-abi=soft'],
    'official_cube_log_sha256':digest(root/'.work/evidence/cubemx_rft6_resolve.log'),
    'cube_ioc_sha256':digest(root/'.work/cubemx_rft6/SF6_RFT6_Hardware/SF6_RFT6_Hardware.ioc'),
    'normal_plan_valid':True,'apply_files_added':1526,
    'post_apply_receipt_writer_exception':'AttributeError: ApplyResult.applied; actual Apply completed',
    'serialized_model_sha256':digest(evidence/'model.json')}
(evidence/'generation.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
print(json.dumps(config))
