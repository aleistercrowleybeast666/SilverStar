from pathlib import Path
import re,json,hashlib,subprocess
from collections import defaultdict
root=Path.cwd();project=root/'.work/generated_rft6'; evidence=root/'.work/evidence/rft6_baseline'
build=project/'build/FCCG/SilverStar_F103RF/Release'; mapfile=build/'SilverStar_0_1_1.map'
s=mapfile.read_text(encoding='utf-8');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sections={n:int(re.search(r'^'+re.escape(n)+r'\s+0x[0-9a-f]+\s+0x([0-9a-f]+)',s,re.M)[1],16) for n in ('.text','.data','.bss')}
stack=re.search(r'^\._user_heap_stack\s+0x([0-9a-f]+)\s+0x([0-9a-f]+)',s,re.M)
msp=int(stack[2],16);ram=int(stack[1],16)+msp-0x20000000
region=s[s.index('\n.data '):s.index('\n._user_heap_stack')]
rows=[(int(m[3],16),m[1],m[4]) for m in re.finditer(r'^ (\.(?:bss|data)\S*)\s+0x([0-9a-f]+)\s+0x([0-9a-f]+)\s+([^\n]+\.o)',region,re.M)]
groups=defaultdict(int)
for size,name,owner in rows:
    if '_stack' in name: group='static_task_stacks_already_in_bss'
    elif ('/APP/Src/logger_bus.o' in owner and 'storage' in name) or (('/APP/Src/estimator_bus.o' in owner or '/APP/Src/imu_sample_bus.o' in owner) and name=='.bss.s_queue'):group='sample_and_log_queues'
    elif 'logger_' in owner or '/Protocol/SSLOG/' in owner:group='other_logging'
    elif '/Algorithm/' in owner or '/APP/Src/estimator_task.o' in owner or '/APP/Src/ins_task.o' in owner:group='algorithm_and_origin_state'
    elif '/Platform/' in owner or '/Drivers/' in owner or '/HardwareGenerated/' in owner or '/FreeRTOS' in owner:group='platform_vendor_rtos'
    elif '/Devices/' in owner:group='device_state'
    else:group='other'
    groups[group]+=size
groups['alignment_fill_or_unparsed']=ram-msp-sum(groups.values());groups['main_msp_reservation']=msp
nm=subprocess.check_output(['D:/Arm GNU Toolchain/14.3 rel1/bin/arm-none-eabi-nm.exe','-S','--size-sort',str(build/'SilverStar_0_1_1.elf')],text=True)
(evidence/'symbols_nm.log').write_text(nm,encoding='utf-8')
old=json.loads((root/'.work/evidence/mpu_ret6_b_startup_gates/map_resources.json').read_text())
capacity=98304; goal=capacity*4//5
report={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'dirty_source_snapshot_sha256':sha(evidence/'dirty_source_snapshot.json'),
    'target':'STM32F103RFT6','configuration':'MPU6050+NEO-M9N+E28-2G4M12SX+BMP280; SF6; all_streams SSLOG; maintenance disabled',
    **sections,'main_msp_reservation':msp,'ram_capacity':capacity,'ram_used':ram,'ram_spare':capacity-ram,
    'ram_spare_percent':(capacity-ram)*100/capacity,'twenty_percent_goal_used_max':goal,'twenty_percent_goal_gap':max(0,ram-goal),
    'flash_load_bytes':(build/'SilverStar_0_1_1.bin').stat().st_size,'flash_capacity':786432,
    'net_ram_delta_vs_ret6_no_gnss_sf6_minimal':ram-old['ram_used'],
    'net_flash_delta_vs_ret6_no_gnss_sf6_minimal':(build/'SilverStar_0_1_1.bin').stat().st_size-old['flash_load_bytes'],
    'comparison_boundary':'This is a measured total configuration/target delta, not isolated GNSS or algorithm savings.',
    'groups':{k:{'bytes':v,'percent_of_ram':v*100/capacity} for k,v in groups.items()},
    'largest_symbols':[{'bytes':a,'symbol':n,'object':o} for a,n,o in sorted(rows,reverse=True)[:30]],
    'hashes':{p.name:sha(p) for p in build.glob('SilverStar_0_1_1.*') if p.suffix in ('.elf','.map','.bin','.hex')},
    'counting_boundary':'Static task/idle stacks counted once in BSS; MSP separate. This is not complete stack margin/WCET proof.'}
assert sum(v['bytes'] for v in report['groups'].values())==ram
report['actual_compiler_stack_frames_not_whole_call_path']=[{'file':p.relative_to(project).as_posix(),'record':line}
    for p in build.rglob('*.su') for line in p.read_text().splitlines()
    if any(name in line for name in ('Mpu6050','SensorImu_Verify','NeoM9n','SystemImu_Process'))]
(evidence/'map_resources.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k not in ('largest_symbols','actual_compiler_stack_frames_not_whole_call_path','hashes')},indent=2))
