from pathlib import Path
import json,re
from collections import defaultdict
r=Path.cwd();b=r/'.work/generated_rft6/build/FCCG/SilverStar_F103RF/Release'
s=(b/'SilverStar_0_1_1.map').read_text();s=s[s.index('\n.text '):s.index('\n.data ')]
groups=defaultdict(int);rows=[]
for m in re.finditer(r'^ (\.\S+)\s+0x([0-9a-f]+)\s+0x([0-9a-f]+)\s+([^\n]+)',s,re.M):
 name,addr,size,owner=m[1],int(m[2],16),int(m[3],16),m[4]
 if not name.startswith('.text') or not 0x08000000<=addr<0x080c0000 or not (owner.endswith('.o') or '.a(' in owner):continue
 if '/Algorithm/' in owner or '/APP/Src/estimator_task.o' in owner or '/APP/Src/ins_task.o' in owner:group='algorithm'
 elif 'logger_' in owner or '/Protocol/SSLOG/' in owner:group='logging'
 elif '/Platform/' in owner or '/Drivers/' in owner or '/HardwareGenerated/' in owner or '/FreeRTOS' in owner:group='platform_hal_rtos'
 elif '/Devices/' in owner:group='devices'
 elif '.a(' in owner:group='linked_runtime_libraries'
 else:group='other_first_party'
 groups[group]+=size;rows.append({'bytes':size,'section':name,'owner':owner,'address':hex(addr)})
total=(b/'SilverStar_0_1_1.bin').stat().st_size
assert sum(groups.values())<=total
groups['rodata_vectors_fill_data_load_and_unparsed']=total-sum(groups.values())
report={'scope':'Disjoint retained .text input sections only; merged .rodata is deliberately not summed per object. Remaining BIN load bytes include rodata, vectors, fill and data load. No duplicate stack/RAM inclusion.','flash_load_bytes':total,'groups':{k:{'bytes':v,'percent_of_capacity':round(v*100/786432,3),'percent_of_load':round(v*100/total,3)} for k,v in groups.items()},'largest_sections':sorted(rows,key=lambda x:x['bytes'],reverse=True)[:20]}
(r/'.work/evidence/rft6_baseline/flash_symbols.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='largest_sections'},indent=2))

