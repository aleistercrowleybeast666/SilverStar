from pathlib import Path
import json,os,subprocess,time,hashlib,datetime,sys
root=Path.cwd(); project=root/'.work/generated_rft6'; evidence=root/'.work/evidence/rft6_gates'; evidence.mkdir(exist_ok=True)
env=dict(os.environ);env['PATH']='D:/python_software/SilverStar/apps/FLP/.venv/Scripts;D:/msys64/ucrt64/bin;'+env['PATH']
base=['D:/msys64/ucrt64/bin/mingw32-make.exe','GCC_PATH=D:/Arm GNU Toolchain/14.3 rel1/bin','CONFIG=Release','HOST_CC=D:/msys64/ucrt64/bin/gcc.exe']
jobs=[('arm',base+['-B','-j2','all']),('analyzer',base+['-B','-j2','static-analysis']),
      ('architecture',base+['architecture-check']),('power10',base+['power10-check']),
      ('artifact',base+['artifact-check']),('stack',base+['stack-report']),
      ('official_host',base+['host-tests']),('linked_sources',base+['list-sources'])]
if len(sys.argv)>1: jobs=[j for j in jobs if j[0]==sys.argv[1]]
for name,argv in jobs:
    log=evidence/(name+'.log');start=time.monotonic();began=datetime.datetime.now(datetime.timezone.utc).isoformat()
    source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
    snapshot=root/'.work/evidence/rft6_baseline/dirty_source_snapshot.json'
    for rel,sha in json.loads(snapshot.read_text()).items():
        assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==sha,rel
    print('START '+name,flush=True)
    with log.open('w',encoding='utf-8') as out:
        out.write('COMMAND_ARGV='+json.dumps(argv)+'\nSOURCE_COMMIT='+source+'\nUTC_START='+began+'\n');out.flush()
        try:r=subprocess.run(argv,cwd=project,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=600);code=r.returncode
        except subprocess.TimeoutExpired:code='TIMEOUT_600S'
    row={'name':name,'argv':argv,'source_commit':source,'dirty_snapshot_sha256':hashlib.sha256(snapshot.read_bytes()).hexdigest(),
         'utc_start':began,'exit':code,'seconds':time.monotonic()-start,'log':str(log.relative_to(root)),
         'sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
    (evidence/(name+'.json')).write_text(json.dumps(row,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(row),flush=True)
