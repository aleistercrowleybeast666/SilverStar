from pathlib import Path
import subprocess,os,json,hashlib,datetime,time
root=Path.cwd();out=root/'.work/evidence/rft6_baseline';out.mkdir(exist_ok=True)
argv=['D:/python_software/SilverStar/apps/FLP/.venv/Scripts/python.exe','-X','utf8','-m','pytest',
      'tests/test_compact_mode.py','tests/test_compact_logging.py','tests/test_compact_mpu_recovery.py',
      'tests/test_f1_i2c_deadline.py','tests/test_f1_sd_clock.py','tests/test_hardware_and_variants.py',
      'tests/test_static_memory_layout.py','tests/test_auto_memory_layout.py','-q']
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
env=dict(os.environ);env['PATH']='D:/msys64/ucrt64/bin;'+env['PATH']
log=out/'scg_regressions.log';began=datetime.datetime.now(datetime.timezone.utc).isoformat();start=time.monotonic()
with log.open('w',encoding='utf-8') as f:
    f.write('COMMAND_ARGV='+json.dumps(argv)+'\nSOURCE_COMMIT='+source+'\nUTC_START='+began+'\n');f.flush()
    try:r=subprocess.run(argv,cwd=root/'apps/SCG',env=env,stdout=f,stderr=subprocess.STDOUT,timeout=600);code=r.returncode
    except subprocess.TimeoutExpired:code='TIMEOUT_600S'
report={'argv':argv,'cwd':'apps/SCG','source_commit':source,'utc_start':began,'exit':code,
        'seconds':time.monotonic()-start,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
(out/'scg_regressions.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report),flush=True)
