from pathlib import Path
import hashlib, json
root=Path.cwd()
p=root/'.work/cubemx_rft6/SF6_RFT6_Hardware/SF6_RFT6_Hardware.ioc'
before=p.read_bytes()
d=dict(line.split('=',1) for line in before.decode().splitlines() if '=' in line)
assert d['Mcu.CPN']=='STM32F103RFT6'
source=root/'.work/cubemx_flight/SF6_RET6_Hardware/SF6_RET6_Hardware.ioc'
reference=dict(line.split('=',1) for line in source.read_text().splitlines() if '=' in line)
# Cube CLI accepted the clock enum but omitted SYSCLKSource. Transfer only the
# existing validated 64MHz HSI clock parameter group, then run official CubeMX.
for k in list(d):
    if k.startswith('RCC.'):
        del d[k]
d.update({k:v for k,v in reference.items() if k.startswith('RCC.')})
p.write_text('#MicroXplorer Configuration settings - do not modify\n'+
             '\n'.join(k+'='+v for k,v in sorted(d.items()))+'\n')
out={'before_sha256':hashlib.sha256(before).hexdigest(),
     'configured_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
     'reference_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
     'changed_groups':['RCC'],'mcu_cpn':d['Mcu.CPN'],
     'official_generation_required':True}
(root/'.work/evidence/rft6_clock_configuration.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
