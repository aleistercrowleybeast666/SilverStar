from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path.cwd(); ev=root/'.work/evidence';g=root/'.work/generated_ret6'
base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
tracked=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
new=subprocess.check_output(['git','ls-files','--others','--exclude-standard','apps/SCG','docs/FCCG/platform/details'],text=True).splitlines()
paths=sorted(set(tracked+new)); manifest=[]
out=root/'docs/FCCG/platform/evidence/SF6_RET6_sdio_clock/sdio_clock_evidence.zip'
out.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    def add(p,n):
        b=p.read_bytes();z.writestr(n,b)
        manifest.append({'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
    for rel in paths: add(root/rel,'source_snapshot/'+rel)
    z.writestr('base_to_dirty.patch',subprocess.check_output(['git','diff','--binary']))
    for p in sorted(ev.glob('ret6_sd_clock_*.log')):add(p,'logs/'+p.name)
    for name in ['cubemx_sd_clock_safe.log','cubemx_sd_clock_safe.script','ret6_generation_sd_clock.log','generate_ret6.py','sd_clock_regression.py','package_sd_clock.py']:
        add(ev/name,'execution/'+name)
    cube=root/'.work/cubemx_flight/SF6_RET6_Hardware'
    for name in ['SF6_RET6_Hardware.ioc','Core/Src/sdio.c','Core/Src/main.c']:add(cube/name,'official_cubemx/'+name)
    for directory in ['build/FCCG/SilverStar_F103RE/Release','build/FCCG/SilverStar_F103RE/StaticAnalysis/Release']:
        for p in sorted((g/directory).rglob('*')):
            if p.is_file() and p.suffix in {'.elf','.bin','.map','.su'}:add(p,'generated/'+p.relative_to(g).as_posix())
    for name in ['Generated/project_sources.mk','Generated/Inc/project_flight_config.h','Targets/SilverStar_F103RE/target.mk','Targets/SilverStar_F103RE/STM32F103RETx_FLASH.ld','Makefile']:
        p=g/name
        if p.exists():add(p,'generated/'+name)
    # Verify generated owner bytes actually used by the compiler match source.
    owner='apps/SCG/plugins/builtin/silverstar_mcu_family_stm32f1_flight/payload'
    for rel in ['Platform/STM32F1Flight/Src/platform_sd_clock.c','Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_sd.c']:
        assert (root/owner/rel).read_bytes().replace(b'\r\n',b'\n')==(g/rel).read_bytes().replace(b'\r\n',b'\n'),rel
    z.writestr('MANIFEST.json',json.dumps({'base_commit':base,'snapshot':'tracked diff plus exact new/modified owner/test/report files above','execution_date':'2026-10-05 UTC','results':{'before_actual_mmio':1,'after_actual_mmio':0,'pytest':0,'arm':0,'static_analysis':0,'power10':0,'architecture':2,'artifact':0,'stack':2},'limits':'critical contracts NOT PROVEN; logger/full Host failures inherited and not rerun; I2C pending; hardware NOT RUN','files':manifest},indent=2))
print(json.dumps({'path':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()},indent=2))
