from pathlib import Path
import hashlib, importlib.util, io, subprocess, sys, tarfile
root=Path.cwd();app=root/'apps/SCG';family=app/'plugins/builtin/silverstar_mcu_family_stm32f1_flight/payload'
relative='apps/SCG/plugins/builtin/silverstar_mcu_family_stm32f1_flight/payload/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_sd.c'
mode=sys.argv[1];output=root/'.work/evidence'/('sd_clock_'+mode);output.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('clock_test',app/'tests/test_f1_sd_clock.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
original_run=subprocess.run
if mode=='before':
    archive=subprocess.check_output(['git','archive','--format=tar','53e34eb',relative],cwd=root)
    with tarfile.open(fileobj=io.BytesIO(archive)) as t:data=t.extractfile(relative).read()
    baseline=output/'stm32f1xx_hal_sd_before.c';baseline.write_bytes(data)
    selected=str(family/'Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_sd.c')
    def run_actual_before(command,*args,**kwargs):
        command=[str(baseline) if item==selected else item for item in command]
        print('ACTUAL_COMMAND',command,flush=True)
        return original_run(command,*args,**kwargs)
    module.subprocess.run=run_actual_before
    print('BASELINE_COMMIT 53e34eb SHA256',hashlib.sha256(data).hexdigest(),flush=True)
module.test_f1_sd_clock_actual_hal_mmio(output)
