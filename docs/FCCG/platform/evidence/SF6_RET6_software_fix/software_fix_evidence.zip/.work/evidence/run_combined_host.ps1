$ErrorActionPreference = 'Stop'
& (Join-Path (Get-Location) '.work/generated_ret6/Tests/Host/run_tests.ps1') -HostCompiler 'D:/msys64/ucrt64/bin/gcc.exe' -Only @('system_alignment_explicit_required_gnss','capability_required_gnss_missing','sf6_backend_actual','sf6_backend_cold_pressure_actual','logger_alignment_actual','logger_snapshot_actual','logger_streaming_actual')
