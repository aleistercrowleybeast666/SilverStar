from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json,hashlib,subprocess,sys
r=Path.cwd();e=r/'.work/evidence';p=r/'.work/generated_ret6';head='1fcf9b20fb5250f27367cf6b71e493d197185f45'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
assert subprocess.call(['git','diff','--quiet','HEAD','--','apps/SCG'])==0
out=r/'docs/FCCG/platform/evidence/SF6_RET6_software_fix';out.mkdir(parents=True,exist_ok=True)
def sha(data):return hashlib.sha256(data).hexdigest()
def run(argv):return subprocess.check_output(argv,text=True)
tools={'python':sys.version,'host_gcc':run(['D:/msys64/ucrt64/bin/gcc.exe','--version']),'arm_gcc':run(['D:/Arm GNU Toolchain/14.3 rel1/bin/arm-none-eabi-gcc.exe','--version']),'make':run(['D:/msys64/ucrt64/bin/mingw32-make.exe','--version']),'powershell':run(['pwsh','-NoProfile','-Command','$PSVersionTable.PSVersion.ToString()']),'CubeMX':'6.15.0, installed official Java CLI actually run; preserved logs','CubeFW':'F1 V1.8.7'}
(e/'combined_verified_tool_versions.json').write_text(json.dumps(tools,indent=2)+'\n')
commands={'source_commit':head,'base':'7fa06c4155661e40847c0af78f4b23f3659b995d','worktree':str(r),'generation':'regenerate_selected_ret6.ps1 -Label combined_final_verified (official existing Cube import, fresh generated tree; prior SSLOG/decoder archived)','arm':'mingw32-make -C .work/generated_ret6 -j4 GCC_PATH=D:/Arm GNU Toolchain/14.3 rel1/bin all','analyzer':'same make static-analysis (actual -fanalyzer compile/link, separate StaticAnalysis directory)','gates':'emitted make architecture-check power10-check artifact-check stack-report; original emitted files unchanged','selected_host':'FLP .venv/Scripts on PATH; .work/evidence/run_combined_host.ps1 -> emitted Tests/Host/run_tests.ps1 -Only, actual storage four phases','strict_slots':'FLP .venv python .work/evidence/run_combined_slots.py, exact compiler argv retained in log','FLP':'FLP .venv python .work/evidence/flp_open_sf6_combined_final.py; original FLP source7fa; recorded_configuration and recorded_inertial_increment','identity':'make list-sources, PYTHONPATH=apps/SCG/src python verify_combined_final_source.py; raw exit1 two metadata identities preserved','resource':'map_ret6_combined_verified.py, map_flash_ret6.py; actual Release map/BIN','full_suite':'historical complete emitted run at7ab exit2 after30exes, current complete suite NOTRUN; selected cases never relabeled full suite','test_only':'Host setjmp/longjmp trap interception only; no MCU recovery or hardware qualification'}
(e/'combined_verified_commands.json').write_text(json.dumps(commands,indent=2)+'\n')
(e/'combined_verified_history.txt').write_text(run(['git','log','--format=fuller','7ab1c7d..'+head]))
files={}
def add(f,name=None):
 if f.is_file():files[name or f.relative_to(r).as_posix()]=f
add(r/'docs/FCCG/platform/details/SF6_RET6_SOFTWARE_FIX_REVIEW.md','REPORT.md')
for f in e.glob('ret6_combined_verified*.log'):add(f)
for f in e.glob('ret6_combined*.json'):add(f)
for name in ('adapter_fix_corrected_pytest.log','ret6_optional_gui_isolated.log','ret6_adapter_ownership.log','ret6_combined_profile_pytest.log','ret6_host_selection_full_host.log','ret6_softwarefix_flp_prefix.log','ret6_softwarefix_flp_post.log','ret6_combined_host.log','ret6_combined_final_host.log','ret6_combined_include_host.log','ret6_combined_logger_generation.log','ret6_storage_dispatch_unresolved_callback_review.json','ret6_combined_final_generated_source_identity.json','ret6_combined_final_map_symbols.json','ret6_combined_final_linked_source_list.log','combined_verified_tool_versions.json','combined_verified_commands.json','combined_verified_history.txt','current_cube_snapshot_package.json','library_cube_snapshot_upload.json','combined_verified_source_addendum_package.json','SilverStar_SF6_COMBINED_1fcf9b2_SOURCE_BYTES_ADDENDUM.zip','combined_final_current_render_SilverStar.ssproject','combined_final_current_render_ownership.json','generate_ret6.py','regenerate_selected_ret6.ps1','run_combined_host.ps1','run_combined_slots.py','verify_combined_final_source.py','map_ret6_combined_verified.py','map_flash_ret6.py','flp_open_sf6_combined_final.py','package_current_cube_snapshot.py','package_final_software_review.py'):add(e/name)
for name in ('prefixed.json','postfixed.json','combined_final_postfixed.json'):add(e/'flp_reopen'/name)
for pattern in ('cubemx*.script','cubemx*.log'):
 for f in e.glob(pattern):add(f)
add(r/'.work/cubemx_flight/SF6_RET6_Hardware/SF6_RET6_Hardware.ioc','official_cube/SF6_RET6_Hardware.ioc')
for name in ('Makefile','SilverStar.ssproject','.fccg/ownership.json','.fccg/hardware-preparation.json','Generated/project_sources.mk','Generated/Inc/project_flight_config.h','Generated/Inc/project_log_config.h','Generated/Src/project_log_config.c','Generated/Src/project_log_decoder_profile.c','Tools/check_power_of_ten.ps1','Tools/check_architecture.ps1','Tools/check_task_stacks.py','Tests/Host/run_tests.ps1','Tests/Host/test_logger_alignment.c','Tests/Host/storage_integrity/test_sf6_compact_storage.h','Tests/Host/storage_integrity/run_storage_integrity.py'):
 add(p/name,'generated/'+name)
for f in p.glob('*.ssdecoder'):add(f,'generated/'+f.name)
for f in p.rglob('*.ld'):add(f,'generated/'+f.relative_to(p).as_posix())
for profile in (p/'build/FCCG/SilverStar_F103RE/Release',p/'build/FCCG/SilverStar_F103RE/StaticAnalysis/Release'):
 for f in profile.rglob('*'):
  if f.is_file() and f.suffix in ('.elf','.map','.bin','.hex','.su'):add(f,'artifacts/'+f.relative_to(p/'build/FCCG').as_posix())
for f in (p/'build/FCCG/Host/Tests/StorageIntegrity').glob('*.sslog'):add(f,'immutable_current_logs/'+f.name)
manifest={'source_commit':head,'status':'COMPILE_CANDIDATE_ACCEPTANCE_BLOCKED','current_run_prefix':'ret6_combined_verified','historical_logs':'Other labels retain their actual earlier source/failure scope; no stitched suite pass. Conflicted intermediate generation was discarded.','cube_snapshot_external_library_id':'libfile_b0db328d87d88191b0ec89b1d1b92e23','files':[{'path':n,'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())} for n,f in sorted(files.items())]}
archive=out/'software_fix_evidence.zip'
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=6) as z:
 for n,f in sorted(files.items()):z.write(f,n)
 z.writestr('MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
with ZipFile(archive) as z:
 for x in manifest['files']:assert sha(z.read(x['path']))==x['sha256']
digest=sha(archive.read_bytes());meta={'archive_bytes':archive.stat().st_size,'archive_sha256':digest,**manifest}
(out/'software_fix_manifest.json').write_text(json.dumps(meta,indent=2)+'\n');(out/'software_fix_evidence.sha256').write_text(digest+'  software_fix_evidence.zip\n')
print(json.dumps({'path':str(archive),'bytes':archive.stat().st_size,'sha256':digest,'verified_files':len(files),'source_commit':head}))
