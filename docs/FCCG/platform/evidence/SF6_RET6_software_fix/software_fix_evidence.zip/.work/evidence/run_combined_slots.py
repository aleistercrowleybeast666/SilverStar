from pathlib import Path
import shlex,subprocess
root=Path.cwd();line=(root/'.work/evidence/ret6_final_slots.log').read_text().splitlines()[0]
a=shlex.split(line,posix=False)
assert a[0]=='D:/msys64/ucrt64/bin/gcc.exe'
output=Path(a[-1]);output.parent.mkdir(parents=True,exist_ok=True)
for token in a[1:]:
 if token.endswith('.c'): assert Path(token).is_file(),token
print('COMMAND_ARGV='+repr(a),flush=True)
subprocess.run(a,check=True,cwd=root)
subprocess.run([str(output.resolve())],check=True,cwd=root)
