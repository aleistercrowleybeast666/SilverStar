param([Parameter(Mandatory=$true)][string]$Label)
$ErrorActionPreference='Stop'
if ($Label -notmatch '^[a-z0-9_]+$') { throw 'Invalid evidence label' }
$root=(Get-Location).Path
$generated=[IO.Path]::GetFullPath((Join-Path $root '.work/generated_ret6'))
if ($generated -ne 'D:\python_software\SilverStar\.work\sf6_compact_ret6\.work\generated_ret6') { throw 'Path mismatch' }
if (Test-Path -LiteralPath $generated) {
 if (-not (Test-Path -LiteralPath (Join-Path $generated '.fccg'))) { throw 'Ownership missing' }
 if ((Get-Item -LiteralPath $generated).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Reparse point' }
 $env:SF6_EVIDENCE_LABEL=$Label
 & 'D:\python_software\SilverStar\apps\FLP\.venv\Scripts\python.exe' -c "from pathlib import Path;import os,zipfile,json,hashlib;r=Path.cwd();g=r/'.work/generated_ret6';o=r/'.work/evidence'/('preserved_'+os.environ['SF6_EVIDENCE_LABEL']+'.zip');assert not o.exists();ps=[p for p in g.rglob('*') if p.is_file() and p.suffix in {'.sslog','.ssdecoder'}];z=zipfile.ZipFile(o,'w',zipfile.ZIP_DEFLATED);m=[];[(z.write(p,p.relative_to(g).as_posix()),m.append({'path':p.relative_to(g).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})) for p in ps];z.writestr('MANIFEST.json',json.dumps(m));z.close();print('Preserved',len(ps),'immutable log/decoder outputs')"
 if ($LASTEXITCODE -ne 0) { throw 'Preservation failed' }
 Remove-Item -LiteralPath $generated -Recurse -Force
}
$env:PYTHONPATH=$root+'\apps\SCG\src'
& 'D:\python_software\SilverStar\apps\FLP\.venv\Scripts\python.exe' .work/evidence/generate_ret6.py *> ".work/evidence/$Label`_generation.log"
Write-Output "GEN_EXIT=$LASTEXITCODE"
Get-Content ".work/evidence/$Label`_generation.log" -Tail 4
