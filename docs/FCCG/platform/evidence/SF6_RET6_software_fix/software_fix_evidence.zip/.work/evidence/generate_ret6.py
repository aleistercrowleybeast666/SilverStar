from pathlib import Path
from dataclasses import replace
import json
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.core.workspace import WorkspacePolicy
from silverstar_fccg.hardware.cubemx import CubeMxImporter
from silverstar_fccg.generator.assembler import ProjectAssembler
from silverstar_fccg.project.model import DeviceInstance
from silverstar_fccg.project.configuration import ProjectConfiguration_Reconcile
from silverstar_fccg.project.validation import Project_Validate
root=Path.cwd(); service=FccgService(root/'apps/SCG');c=service.catalog
policy=WorkspacePolicy(root/'.work');imp=CubeMxImporter(policy)
h=imp.Project_Import(root/'.work/cubemx_flight/SF6_RET6_Hardware',expected_mcu='STM32F103RET6',risk_acknowledged=True)
print('IMPORT',h.warnings);print(json.dumps(h.inventory.Dictionary_Get(),indent=2))
m=service.ReferenceProject_Create('SF6_RET6_Compact')
m.board='';m.mcu='silverstar.mcu.stm32f103ret6';m.mcu_family='silverstar.mcu_family.stm32f1_flight';m.os='silverstar.os.freertos_11_3_0_cm3'
m.hardware=h.hardware
m.build=replace(m.build,compact_mode=True,logging_profile="sf6_minimal",target_profile='SilverStar_F103RE',gcc_path='D:/Arm GNU Toolchain/14.3 rel1/bin/arm-none-eabi-gcc.exe',make_command='D:/msys64/ucrt64/bin/mingw32-make.exe')
m.protocols['maintenance']=None
m.device_instances=[DeviceInstance('imu0','silverstar.device.imu.mpu6050'),DeviceInstance('telemetry0','silverstar.device.telemetry.sx1281',module_variant='e28_2g4m12sx',tx_power_dbm=12),DeviceInstance('barometer0','silverstar.device.barometer.bmp280'),DeviceInstance('storage0','silverstar.device.storage.sd_sdio_fatfs_f1'),DeviceInstance('launch_ignition0','silverstar.device.actuator.launch_ignition'),DeviceInstance('parachute_pyro0','silverstar.device.actuator.parachute_pyro'),DeviceInstance('system_indicator0','silverstar.device.indicator.system_status')]
m.strategies['estimator']='silverstar.algorithm.estimator.sf6'
m.resource_assignments={'imu0:data':'I2C1','imu0:time':'SYSTEM_TIME','barometer0:data':'I2C1','barometer0:time':'SYSTEM_TIME','telemetry0:radio_bus':'SPI1','telemetry0:radio_nss':'PA4','telemetry0:radio_reset':'PB0','telemetry0:radio_busy':'PB1','telemetry0:radio_dio1':'PB2','telemetry0:time':'SYSTEM_TIME','storage0:storage':'SDIO','storage0:time':'SYSTEM_TIME','launch_ignition0:output':'PB13','launch_ignition0:time':'SYSTEM_TIME','parachute_pyro0:output':'PB12','parachute_pyro0:time':'SYSTEM_TIME','system_indicator0:output':'PB14'}
r=ProjectConfiguration_Reconcile(m,c);m=r.model
print('NOTICES',r.notices)
v=Project_Validate(m,c);print('VALIDATION',v)
(root/'.work/evidence/ret6_model.json').write_text(json.dumps(m.Dictionary_Get(),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
p=ProjectAssembler(policy,c).Plan(m,root/'.work/generated_ret6');print('PLAN',p.valid)
if p.valid: print('APPLY',ProjectAssembler(policy,c).Apply(m,p))
elif all(issue.code == 'TIMING_PROFILE_UNQUALIFIED' for issue in v.issues if issue.level == 'error'):
 # Compilation of a rejected draft is diagnostic evidence, never gate acceptance.
 output=root/'.work/ret6_compile_draft';assembler=ProjectAssembler(policy,c)
 files,ownership=assembler._DesiredFiles_Get(m,output,assembler._HardwareFiles_Get(m))
 for component_id in m.ComponentIds_Get():
  manifest=c.ProjectView_Get(m).Component_Get(component_id)
  for source in manifest.PayloadFiles_Get():
   rel=source.relative_to(manifest.payload_root).as_posix();data=source.read_bytes()
   if rel in files and files[rel] != data: raise RuntimeError('payload collision: '+rel)
   files[rel]=data
 files.update(assembler._HardwareFiles_Get(m))
 for rel,data in files.items():
  target=policy.Path_Resolve(output/rel);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 print('COMPILE_DRAFT_ONLY',output,'VALIDATION_REMAINS_FAILED')

