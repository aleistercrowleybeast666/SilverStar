from pathlib import Path
from zipfile import ZipFile
import json,hashlib,sys,traceback
root=Path.cwd();sys.path.insert(0,str(root/'apps/FLP/src'))
from silverstar_flp.log_open import LogOpenCoordinator,LogOpenRequest
from silverstar_flp.decoder_profiles.discovery import DecoderProfileCache
from silverstar_flp.plugins.registry import builtin_registry
from silverstar_flp.plugins.api.algorithm import ReplayRequest
out=root/'.work/evidence/flp_reopen';out.mkdir(exist_ok=True)
registry=builtin_registry();coordinator=LogOpenCoordinator(registry,DecoderProfileCache(out/'cache'))
if len(sys.argv)>1 and sys.argv[1]=='old':
 with ZipFile(root/'docs/FCCG/platform/evidence/SF6_RET6_logging_profile/logging_profile_evidence.zip') as z:
  for name in ('generated/SF6_RET6_Compact.ssdecoder','immutable_final_logs/sf6-compact-startup-burst.sslog','immutable_final_logs/sf6-compact-startup-burst-overload.sslog'):
   target=out/Path(name).name
   if not target.exists(): target.write_bytes(z.read(name))
 logs=sorted(out.glob('*.sslog'));decoder=out/'SF6_RET6_Compact.ssdecoder';label='prefixed'
else:
 project=root/'.work/generated_ret6';logs=sorted((project/'build/FCCG/Host/Tests/StorageIntegrity').glob('sf6-compact-*.sslog'));decoder=next(project.glob('*.ssdecoder'));label='combined_final_postfixed'
results=[]
for log in logs:
 item={'log':str(log.relative_to(root)),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'decoder_sha256':hashlib.sha256(decoder.read_bytes()).hexdigest(),'FLP_source_HEAD': '7fa06c4155661e40847c0af78f4b23f3659b995d'}
 try:
  opened=coordinator.Open(LogOpenRequest(log,decoder));dataset=opened.dataset
  item.update(open='PASS',match_mode=opened.match_mode,parse_diagnostics=opened.parse_diagnostics.to_dict(),records={k:len(v) for k,v in dataset.records.items()})
  replay=registry.Algorithm_Get('silverstar.algorithm.sf6').run(dataset,ReplayRequest(input_source='recorded_inertial_increment'))
  item.update(replay='PASS',fidelity=str(replay.fidelity),warnings=list(replay.warnings),missing_inputs=list(replay.missing_inputs),diagnostics=dict(replay.diagnostics),channels={k:len(v.timestamp_us) for k,v in replay.channels.items()})
 except Exception as ex:
  item.update(error=type(ex).__name__+':'+str(ex));traceback.print_exc()
 results.append(item)
 print(json.dumps({k:item[k] for k in ('log','open','replay','fidelity','channels','error') if k in item},ensure_ascii=True,default=str),flush=True)
(out/f'{label}.json').write_text(json.dumps(results,indent=2,ensure_ascii=False,default=str)+'\n')
if label=='combined_final_postfixed' and (len(results)!=2 or not all(x.get('replay')=='PASS' for x in results)):sys.exit(1)
