from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json,hashlib,subprocess
r=Path.cwd();ev=r/'.work/evidence';p=r/'.work/generated_ret6';h=json.loads((p/'SilverStar.ssproject').read_bytes())['hardware'];sid=h['snapshot_id']
snap=r/'.work/.fccg/hardware_imports'/sid;cube=r/'.work/cubemx_flight/SF6_RET6_Hardware'
def sha(b):return hashlib.sha256(b).hexdigest()
paths=subprocess.check_output(['git','ls-files','apps/SCG'],text=True).splitlines();byhash={}
for path in paths:
 f=r/path
 if f.is_file():byhash.setdefault(sha(f.read_bytes()),[]).append(path)
files={};entries=[];omitted=0
for f in sorted(snap.rglob('*')):
 if not f.is_file():continue
 rel=f.relative_to(r).as_posix();data=f.read_bytes();digest=sha(data);sub=f.relative_to(snap).parts
 vendor=len(sub)>1 and sub[1]=='Drivers';candidates=byhash.get(digest,[]) if vendor else []
 if candidates:omitted+=1
 else:files[rel]=f
 entries.append({'path':rel,'bytes':len(data),'sha256':digest,'included':not bool(candidates),'reuse_exact_raw_source_path':candidates[0] if candidates else None})
# Original application output and IDE metadata are separate from imported snapshot.
for f in sorted(cube.rglob('*')):
 if f.is_file() and f.relative_to(cube).parts[0] not in ('Drivers','Middlewares'):
  files[f.relative_to(r).as_posix()]=f
for rel in ('SilverStar.ssproject','.fccg/hardware-preparation.json','.fccg/ownership.json'):
 f=p/rel;files[f.relative_to(r).as_posix()]=f
for pattern in ('cubemx*.script','cubemx*.log'):
 for f in ev.glob(pattern):files[f.relative_to(r).as_posix()]=f
manifest={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'snapshot_id':sid,'workspace_root_layout':'Extract archive paths into isolated worktree root. Exact snapshot is .work/.fccg/hardware_imports/<snapshot_id>/STM32CubeMX. Fill omitted vendor files only from listed raw source paths after SHA verification; no synthetic import identity. Current saved project .work/generated_ret6/SilverStar.ssproject. Public assembler WorkspacePolicy root is .work.','snapshot_files':entries,'omitted_exact_vendor_matches':omitted,'files':[{'path':n,'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())} for n,f in sorted(files.items())]}
out=ev/'SilverStar_SF6_RET6_OFFICIAL_CUBE_SNAPSHOT_1fcf9b2.zip'
with ZipFile(out,'w',ZIP_DEFLATED,compresslevel=6) as z:
 for n,f in sorted(files.items()):z.write(f,n)
 z.writestr('SNAPSHOT_MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
with ZipFile(out) as z:
 for x in manifest['files']:assert sha(z.read(x['path']))==x['sha256']
result={'path':str(out),'bytes':out.stat().st_size,'sha256':sha(out.read_bytes()),'included_files':len(files),'snapshot_files':len(entries),'omitted_exact_vendor_matches':omitted,'snapshot_id':sid}
(ev/'current_cube_snapshot_package.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
