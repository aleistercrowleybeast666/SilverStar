$ErrorActionPreference = 'Stop'
& (Join-Path (Get-Location) '.work/generated_ret6/Tests/Host/run_tests.ps1') -HostCompiler 'D:/msys64/ucrt64/bin/gcc.exe' -Only @('optional_gnss_start_actual','logger_snapshot_actual','logger_streaming_actual','sf6_backend_actual')
