from pathlib import Path
import re,json,hashlib
from collections import defaultdict
root=Path.cwd();b=root/'.work/generated_ret6/build/FCCG/SilverStar_F103RE/Release'
p=b/'SilverStar_0_1_1.map';s=p.read_text()
sections={n:int(re.search(r'^'+re.escape(n)+r'\s+0x[0-9a-f]+\s+0x([0-9a-f]+)',s,re.M)[1],16) for n in ('.text','.data','.bss')}
m=re.search(r'^\._user_heap_stack\s+0x([0-9a-f]+)\s+0x([0-9a-f]+)',s,re.M)
msp=int(m[2],16);ram=int(m[1],16)+msp-0x20000000
region=s[s.index('\n.data '):s.index('\n._user_heap_stack')]
rows=[(int(m[3],16),m[1],m[4]) for m in re.finditer(r'^ (\.(?:bss|data)\S*)\s+0x([0-9a-f]+)\s+0x([0-9a-f]+)\s+([^\n]+\.o)',region,re.M)]
groups=defaultdict(int)
for size,name,owner in rows:
    if '_stack' in name: group='static_task_stacks_already_in_bss'
    elif ('/APP/Src/logger_bus.o' in owner and 'storage' in name) or (('/APP/Src/estimator_bus.o' in owner or '/APP/Src/imu_sample_bus.o' in owner) and name=='.bss.s_queue'):group='sample_and_log_queues'
    elif 'logger_' in owner or '/Protocol/SSLOG/' in owner:group='other_logging'
    elif '/Algorithm/' in owner or '/APP/Src/estimator_task.o' in owner or '/APP/Src/ins_task.o' in owner:group='algorithm_and_origin_state'
    elif '/Platform/' in owner or '/Drivers/' in owner or '/HardwareGenerated/' in owner or '/FreeRTOS' in owner:group='platform_vendor_rtos'
    elif '/Devices/' in owner:group='device_state'
    else:group='other'
    groups[group]+=size
groups['alignment_fill_or_unparsed']=ram-msp-sum(groups.values());groups['main_msp_reservation']=msp
report={'status':'LINKED_ELF','source_commit':'23829514ac5119ad97f1db0fb53ae04ff7e7bf9a',**sections,'main_msp_reservation':msp,'ram_used':ram,'ram_capacity':65536,'ram_spare':65536-ram,'ram_spare_percent':round((65536-ram)*100/65536,3),'twenty_percent_spare_target_used_max':52428,'twenty_percent_target_gap':ram-52428,'historical_four_module_phase2_ram_required':75120,'historical_comparison_warning':'Different source revisions; this difference is NOT a measurement of GNSS removal alone.','same_cube_no_gnss_integrated_all_streams_ram_required':65896,'explicit_profile_net_ram_reduction':65896-ram,'flash_load_bytes':(b/'SilverStar_0_1_1.bin').stat().st_size,'flash_capacity':524288,'groups':{k:{'bytes':v,'percent_of_ram':round(v*100/65536,3)} for k,v in groups.items()},'largest_symbols':[{'bytes':a,'symbol':n,'object':o} for a,n,o in sorted(rows,reverse=True)[:24]],'hashes':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in b.glob('SilverStar_0_1_1.*') if f.suffix in ('.elf','.map','.hex','.bin')}}
(root/'.work/evidence/ret6_final_map_symbols.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2)[:3000])
