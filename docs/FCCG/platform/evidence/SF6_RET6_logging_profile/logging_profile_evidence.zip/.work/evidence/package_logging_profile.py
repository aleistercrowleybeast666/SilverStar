from pathlib import Path
import hashlib,json,subprocess,zipfile,sys,platform,re
root=Path.cwd(); ev=root/'.work/evidence'; project=root/'.work/generated_ret6'
out=root/'docs/FCCG/platform/evidence/SF6_RET6_logging_profile';out.mkdir(parents=True,exist_ok=True)
commit='23829514ac5119ad97f1db0fb53ae04ff7e7bf9a'; base='e810fd2cf38d6c7ef68aaa2d365dfaaa1f84c4be'
def git(*args): return subprocess.check_output(['git',*args],cwd=root)
patch=ev/'source_e810_to_2382951.patch';patch.write_bytes(git('diff','--binary',base,commit,'--','apps/SCG'))
(ev/'source_commit_history.txt').write_bytes(git('log','--format=fuller',base+'..'+commit))
tracked=git('ls-files','apps/SCG').decode().splitlines()
(ev/'current_scg_source_sha256.json').write_text(json.dumps({'source_commit':commit,'files':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in tracked if (root/p).is_file()}},indent=2)+'\n',encoding='utf-8')
generated={p.relative_to(project).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in project.rglob('*') if p.is_file() and 'build' not in p.relative_to(project).parts and p.suffix.lower() in ('.c','.h','.s','.ld','.mk','.json','.ssproject','.ssdecoder','.ioc','.yml')}
(ev/'actual_generated_file_sha256.json').write_text(json.dumps({'source_commit':commit,'files':generated},indent=2)+'\n',encoding='utf-8')
tools={'python':sys.version,'powershell':subprocess.check_output(['pwsh','-NoProfile','-Command','$PSVersionTable.PSVersion.ToString()'],text=True).strip(),'arm':subprocess.check_output([r'D:\Arm GNU Toolchain\14.3 rel1\bin\arm-none-eabi-gcc.exe','--version'],text=True),'host':subprocess.check_output([r'D:\msys64\ucrt64\bin\gcc.exe','--version'],text=True),'make':subprocess.check_output([r'D:\msys64\ucrt64\bin\mingw32-make.exe','--version'],text=True),'cubemx':'Official installed 6.15.0; actual CLI generation log and script preserved; reused without new hardware actions','cube_package':'STM32Cube_FW_F1_V1.8.7'}
(ev/'final_tool_versions.json').write_text(json.dumps(tools,indent=2)+'\n',encoding='utf-8')
commands={'source_commit':commit,'worktree':str(root),'base':base,'generation':'PYTHONPATH=apps/SCG/src; python .work/evidence/generate_ret6.py; clean owner-verified generation recorded in capacity56_generation.log','arm':'mingw32-make -C .work/generated_ret6 -j4 "GCC_PATH=D:/Arm GNU Toolchain/14.3 rel1/bin" "PYTHON=D:/python_software/SilverStar/apps/FLP/.venv/Scripts/python.exe"','gates':['power10-check','static-analysis','architecture-check','artifact-check','stack-report','host-tests HOST_CC=D:/msys64/ucrt64/bin/gcc.exe'],'selected_host':'powershell -NoProfile -ExecutionPolicy Bypass -File .work/evidence/run_final_selected.ps1','slots':'python apps/SCG/tests/run_compact_log_slots.py .work/generated_ret6 .work/generated_ret6/build/FCCG/Host/CompactSlots --compiler D:/msys64/ucrt64/bin/gcc.exe','sf6_pressure':'python .work/generated_ret6/Tests/Host/storage_integrity/run_storage_integrity.py --project .work/generated_ret6 --compiler D:/msys64/ucrt64/bin/gcc.exe --sf6-compact','pytest':'PYTHONPATH=apps/SCG/src;apps/SCG; QT_QPA_PLATFORM=offscreen; python -m pytest apps/SCG/tests/test_compact_logging.py apps/SCG/tests/test_compact_mode.py -q','test_code_boundary':'Host test-only setjmp/longjmp intercepts terminal trap; actual FaultCapture remains. No MCU recovery claim.','source_identity':'python .work/evidence/verify_final_source.py; raw exit 1 retained for two metadata serialization hashes; all linked compilation inputs compared explicitly in report.'}
(ev/'final_commands.json').write_text(json.dumps(commands,indent=2)+'\n',encoding='utf-8')
files={}
def add(p,name=None):
    if p.is_file(): files[name or p.relative_to(root).as_posix()]=p
for p in ev.iterdir():
    if p.suffix=='.log' and (p.name.startswith(('ret6_final_','ret6_profile_','ret6_logger_integrated','compact_','profile_normal_storage')) or p.name in ('cubemx_i2c_deadline.log','cubemx_sd_clock_safe.log')): add(p)
for name in ('generate_ret6.py','regenerate_selected_ret6.ps1','map_ret6_final.py','verify_final_source.py','run_final_selected.ps1','package_logging_profile.py','package_profile_source_review.py','sf6_profile_review_configuration.json','library_profile_source_upload.json','ret6_model.json','ret6_final_map_symbols.json','ret6_final_generated_source_identity.json','current_render_SilverStar.ssproject','current_render_ownership.json','source_profile_c046622_to_2382951.patch','source_e810_to_2382951.patch','source_commit_history.txt','current_scg_source_sha256.json','actual_generated_file_sha256.json','final_tool_versions.json','final_commands.json','cubemx_i2c_deadline.script','cubemx_sd_clock_safe.script','ret6_logger_integrated_failed.map'): add(ev/name)
add(root/'docs/FCCG/platform/details/SF6_RET6_LOGGING_PROFILE.md','REPORT.md')
add(root/'.work/cubemx_flight/SF6_RET6_Hardware/SF6_RET6_Hardware.ioc','official_cube/SF6_RET6_Hardware.ioc')
for name in ('Makefile','SilverStar.ssproject','.fccg/ownership.json','.fccg/hardware-preparation.json','Generated/project_sources.mk','Generated/Inc/project_flight_config.h','Generated/Inc/project_log_config.h','Generated/Src/project_log_config.c','Generated/Src/project_log_decoder_profile.c','Targets/SilverStar_F103RE/STM32F103RETx_FLASH.ld','Tools/check_power_of_ten.ps1','Tests/Host/storage_integrity/test_sf6_compact_storage.h','Tests/Host/test_compact_log_slots.c','Tests/Host/compact_assert_trap.c'):
    add(project/name,'generated/'+name)
for p in project.glob('*.ssdecoder'): add(p,'generated/'+p.name)
for p in project.rglob('*.ld'): add(p,'generated/'+p.relative_to(project).as_posix())
for profile in (project/'build/FCCG/SilverStar_F103RE/Release',project/'build/FCCG/SilverStar_F103RE/StaticAnalysis/Release'):
    for p in profile.rglob('*'):
        if p.is_file() and p.suffix in ('.elf','.map','.bin','.hex','.su'): add(p,'artifacts/'+p.relative_to(project/'build/FCCG').as_posix())
for p in (project/'build/FCCG/Host/Tests/StorageIntegrity').glob('*.sslog'):add(p,'immutable_final_logs/'+p.name)
for p in (root/'.work/pytest/profile_storage_correct_path/storage-integrity0/build/FCCG/Host/Tests/StorageIntegrity').glob('*'):
    if p.suffix in ('.sslog','.log'):add(p,'normal_all_streams/'+p.name)
normal=root/'.work/pytest/profile_storage_correct_path/storage-integrity0'
for p in normal.glob('*.ssdecoder'):add(p,'normal_all_streams/'+p.name)
for name in ('SilverStar.ssproject','Generated/Inc/project_flight_config.h'): add(normal/name,'normal_all_streams/'+name)
manifest={'source_commit':commit,'status':'COMPILE_CANDIDATE_ACCEPTANCE_BLOCKED','files':[{'path':name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for name,p in sorted(files.items())]}
archive=out/'logging_profile_evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,p in sorted(files.items()):z.write(p,name)
    z.writestr('MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
sha=hashlib.sha256(archive.read_bytes()).hexdigest()
(out/'logging_profile_evidence.sha256').write_text(sha+'  logging_profile_evidence.zip\n',encoding='utf-8')
(out/'logging_profile_manifest.json').write_text(json.dumps({'archive_bytes':archive.stat().st_size,'archive_sha256':sha,**manifest},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'path':str(archive),'bytes':archive.stat().st_size,'sha256':sha,'files':len(files)},indent=2))
