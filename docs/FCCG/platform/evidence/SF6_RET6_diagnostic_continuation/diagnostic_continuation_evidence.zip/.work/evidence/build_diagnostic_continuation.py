from pathlib import Path
import hashlib
r=Path.cwd();original=r/'.work/generated_ret6/Tests/Host/run_tests.ps1';source=original.read_text(encoding='utf-8-sig')
marker='foreach ($job in $plannedJobs) {';assert source.count(marker)==1
prefix=source.split(marker)[0]
old="$repoRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..\\..')).Path";assert prefix.count(old)==1
prefix=prefix.replace(old,"$repoRoot = 'D:\\python_software\\SilverStar\\.work\\sf6_compact_ret6\\.work\\generated_ret6'")
old="$outputDir = Join-Path $repoRoot 'build\\FCCG\\Host\\Tests'";assert prefix.count(old)==1
prefix=prefix.replace(old,"$outputDir = Join-Path $repoRoot 'build\\FCCG\\Host\\DiagnosticContinuation'")
assert prefix.count('function Invoke-HostCompiler {')==1
prefix=prefix.replace('function Invoke-HostCompiler {','function Invoke-DiagnosticOriginalHostCompiler {')
tail=(r/'.work/evidence/diagnostic_continuation_tail.ps1').read_text(encoding='utf-8-sig')
wrapper,body=tail.split('$diagnosticRoot =',1)
prefix=prefix.replace('function Write-HostCompileDiagnostic {',wrapper+'\nfunction Write-HostCompileDiagnostic {',1)
tail='$diagnosticRoot ='+body
output=r/'.work/evidence/run_diagnostic_continuation.ps1';output.write_text(prefix+'\n'+tail,encoding='utf-8')
print('Diagnostic scheduling only; original runner untouched. SHA256='+hashlib.sha256(original.read_bytes()).hexdigest())
