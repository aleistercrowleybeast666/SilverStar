from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,json,subprocess,csv,io
r=Path.cwd();e=r/'.work/evidence';p=r/'.work/generated_ret6';previous='42579c8fd2bdd7606d75b743254f57acc4434d9d';source='1bf72f1530f79a04f6dc7ded688d770c421a4072'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==previous
assert subprocess.call(['git','diff','--quiet','HEAD','--','apps/SCG'])==0
classification=json.loads((e/'ret6_diagnostic_continuation_classified.json').read_text());assert classification['RemainingCasesAttempted']==67
files={}
def sha(b):return hashlib.sha256(b).hexdigest()
def add(f,n=None):
 if f.is_file():files[n or f.relative_to(r).as_posix()]=f.read_bytes()
add(r/'docs/FCCG/platform/details/SF6_RET6_DIAGNOSTIC_CONTINUATION.md','REPORT.md')
for pattern in ('ret6_diagnostic*.log','ret6_diagnostic*.json'):
 for f in e.glob(pattern):add(f)
for n in ('diagnostic_selector_failed_count_contexts.json','build_diagnostic_continuation.py','diagnostic_continuation_tail.ps1','run_diagnostic_continuation.ps1','watch_diagnostic_timeouts.ps1','classify_diagnostic_continuation.py','package_diagnostic_continuation.py','ret6_fixture_closure_complete_host.log','fixture_closure_stack_callback_review.json'):add(e/n)
for f in (p/'build/FCCG/Host/DiagnosticContinuation').glob('*.log'):add(f,'case_logs/'+f.name)
for f in (r/'apps/SCG/.work/diagnostic_selected_sensors_20261006').rglob('*.txt'):add(f,'sensor_regressions/'+f.relative_to(r/'apps/SCG/.work/diagnostic_selected_sensors_20261006').as_posix())
for x in classification['SourceEvidence']:add(p/x['path'],'source_evidence/'+x['path'])
for f in (p/'Logs/Golden').glob('*.sslog'):add(f,'diagnostic_golden_fixture/'+f.name)
csv_text=io.StringIO(newline='');fields=('Index','Name','Kind','Status','DiagnosticExit','CompilerExit','NativeLastExit','Classification','FirstFailureSourceOrInference')
writer=csv.DictWriter(csv_text,fieldnames=fields,extrasaction='ignore');writer.writeheader();writer.writerows(classification['Results']);files['MATRIX.csv']=csv_text.getvalue().encode('utf-8')
files['SUMMARY.json']=(json.dumps({k:v for k,v in classification.items() if k not in ('Results','SourceEvidence','OriginalExcludedUnavailableJobs')},indent=2)+'\n').encode()
commands={'official_gate':'FAIL, unchanged emitted runner SHA e99b91167552efe0841e545c6d8e2f44b252906aca23c9c2a87894f865c6372b; historical/current official full log included','diagnostic':'FLP venv/Scripts on PATH; FLP venv python build_diagnostic_continuation.py then pwsh -NoProfile -File run_diagnostic_continuation.ps1 -HostCompiler D:/msys64/ucrt64/bin/gcc.exe; final script exit1 by design','watchdog':'pwsh -NoProfile -File watch_diagnostic_timeouts.ps1; exact own path/PID/starttime check, only1 termination, actual elapsed171.1634852s recorded','classification':'FLP venv python classify_diagnostic_continuation.py; matrix retains all67 exits and failed predicates, sixteen original unavailable jobs explicit','selected_sensor_regressions':'PYTHONPATH=apps/SCG/src PATH=D:/msys64/ucrt64/bin;venv QT_QPA_PLATFORM=offscreen; FLP venv python -m pytest apps/SCG/tests/test_joint_sensor_library.py::test_joint_imu_actual_c_mock apps/SCG/tests/test_round4_bmp280.py::test_bmp280_core_and_both_bus_adapters_host -q --basetemp apps/SCG/.work/diagnostic_selected_sensors_20261006;2passed5.71s','source_change':'NONE in production/GUI/Tests; only disposable diagnostic schedule/watch/scripts and documentation. No new ARM/static-analysis/WCET/hardware claims','tool_versions':'Host GCC16.1.0 target x86_64-w64-mingw32 and exact version stderr in final run log; PowerShell7.6.5; FLPvenv Python3.14; original per-case compile flags and binary argv in matrix; sensor compiler argv/stdout in txt files'}
files['COMMANDS.json']=(json.dumps(commands,indent=2)+'\n').encode()
manifest={'source_commit':source,'previous_documentation_HEAD':previous,'status':'DIAGNOSTIC_ONLY_OFFICIAL_GATE_FAIL_ACCEPTANCE_BLOCKED','production_gui_and_tests_changed':False,'case_counts':{'attempted':67,'pass':49,'fail':18},'files':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())]}
out=r/'docs/FCCG/platform/evidence/SF6_RET6_diagnostic_continuation';out.mkdir(parents=True,exist_ok=True);archive=out/'diagnostic_continuation_evidence.zip'
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=6) as z:
 for n,b in files.items():z.writestr(n,b)
 z.writestr('MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
with ZipFile(archive) as z:
 for x in manifest['files']:assert sha(z.read(x['path']))==x['sha256']
digest=sha(archive.read_bytes());(out/'diagnostic_continuation_evidence.sha256').write_text(digest+'  diagnostic_continuation_evidence.zip\n');(out/'diagnostic_continuation_manifest.json').write_text(json.dumps({'archive_bytes':archive.stat().st_size,'archive_sha256':digest,**manifest},indent=2)+'\n');(out/'diagnostic_continuation_matrix.csv').write_bytes(files['MATRIX.csv']);(out/'diagnostic_continuation_classified.json').write_bytes((e/'ret6_diagnostic_continuation_classified.json').read_bytes())
print(json.dumps({'path':str(archive),'bytes':archive.stat().st_size,'sha256':digest,'verified_files':len(files),'source_commit':source}))
