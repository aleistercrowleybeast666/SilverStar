# DIAGNOSTIC ONLY. Original official full runner failed and remains FAIL.
# Prefix contains original job collection/compile/assert functions. The compiler
# wrapper observes their exact argv/result without changing their behavior.
function Invoke-HostCompiler {
    param([Parameter(Mandatory=$true)][string[]]$CompilerArgs)
    $result = Invoke-DiagnosticOriginalHostCompiler -CompilerArgs $CompilerArgs
    $script:diagnosticLastCompiler = [pscustomobject]@{
        Args=@($CompilerArgs); ExitCode=$result.ExitCode
        Output=@($result.Output | ForEach-Object { [string]$_ })
    }
    return $result
}
$diagnosticRoot = 'D:\python_software\SilverStar\.work\sf6_compact_ret6\.work\evidence'
$officialLog = Join-Path $diagnosticRoot 'ret6_fixture_closure_complete_host.log'
$officialText = Get-Content -LiteralPath $officialLog -Raw
$officialCompleted = @([regex]::Matches($officialText,
    'FCCG_PROGRESS\|HOST_TEST\|DONE\|\d+\|\d+\|([^\r\n]+)') | ForEach-Object {$_.Groups[1].Value})
if ($officialCompleted.Count -ne 30) { throw 'Unexpected official baseline scope' }
if ($officialText -notmatch 'TASK_EXIT=2') { throw 'Official failure evidence missing' }
$officialSet = @{}
foreach ($name in $officialCompleted) { $officialSet[$name]=$true }
$remainingJobs = @($plannedJobs | Where-Object { -not $officialSet.ContainsKey($_.Name) })
$unavailableJobs = @($script:hostJobs | Where-Object {
    ($_.Kind -eq 'HOST_TEST') -and
    (@($_.Sources | Where-Object { -not (Test-Path -LiteralPath $_) }).Count -ne 0)
} | ForEach-Object {
    [pscustomobject]@{Name=$_.Name;Kind=$_.Kind;Status='UNAVAILABLE_UNSELECTED_SOURCE';
        MissingSources=@($_.Sources | Where-Object {-not (Test-Path -LiteralPath $_)})}
})
$results=[System.Collections.Generic.List[object]]::new()
$matrixPath=Join-Path $diagnosticRoot 'ret6_diagnostic_continuation_matrix.json'
$planPath=Join-Path $diagnosticRoot 'ret6_diagnostic_continuation_plan.json'
[pscustomobject]@{OfficialGate='FAIL';OriginalRunnerSha256=(Get-FileHash -LiteralPath (Join-Path $repoRoot 'Tests\Host\run_tests.ps1') -Algorithm SHA256).Hash;
    OfficialCompleted=$officialCompleted;RemainingJobs=$remainingJobs;UnavailableJobs=$unavailableJobs} |
    ConvertTo-Json -Depth 15 | Set-Content -LiteralPath $planPath -Encoding utf8
$index=0
foreach ($job in $remainingJobs) {
    $index++
    $script:diagnosticLastCompiler=$null
    $logPath=Join-Path $outputDir ($job.Name+'.log')
    $errorText=$null; $errorPosition=$null; $errorStack=$null; $jobExit=0
    Write-Output "DIAGNOSTIC_BEGIN|$index|$($remainingJobs.Count)|$($job.Kind)|$($job.Name)"
    try {
        & {
            switch ($job.Kind) {
                'HOST_TEST' { Invoke-HostTest -Name $job.Name -Sources $job.Sources -ExtraCompilerArgs $job.ExtraCompilerArgs }
                'HOST_COMPILE_PASS' { Invoke-ExpectedCompileSuccess -Name $job.Name -Source $job.Source -ExtraCompilerArgs $job.ExtraCompilerArgs }
                'HOST_EXPECTED_FAILURE' { Invoke-ExpectedCompileFailure -Name $job.Name -Source $job.Source -ExtraCompilerArgs $job.ExtraCompilerArgs }
                default { throw 'Unknown job kind' }
            }
        } *> $logPath
    }
    catch {
        $jobExit=1; $errorText=$_.Exception.Message
        $errorPosition=$_.InvocationInfo.PositionMessage; $errorStack=$_.ScriptStackTrace
        Add-Content -LiteralPath $logPath -Value ("DIAGNOSTIC_CAUGHT_FAILURE: "+$errorText)
        Add-Content -LiteralPath $logPath -Value $errorPosition
    }
    $executionExit = $LASTEXITCODE
    $compiler = $script:diagnosticLastCompiler
    if ($null -eq $compiler) { throw "Job did not reach original compiler: $($job.Name)" }
    $text=Get-Content -LiteralPath $logPath -Raw
    $sourceDiagnostic=@($compiler.Output | Where-Object {
        $_ -match '(?i)(:[0-9]+(?::[0-9]+)?:.*(error|warning)|fatal error|static assertion failed|#error)'
    } | Select-Object -First 1)
    $missingHeader=@($compiler.Output | ForEach-Object {
        if ($_ -match 'fatal error:\s*([^:]+): No such file or directory') {$Matches[1]}
    } | Select-Object -First 1)
    $checks=@([regex]::Matches($text,':\s+(\d+) checks,\s+(\d+) failures') | ForEach-Object {
        [pscustomobject]@{Checks=[int]$_.Groups[1].Value;Failures=[int]$_.Groups[2].Value}
    })
    $row=[pscustomobject]@{Index=$index;Name=$job.Name;Kind=$job.Kind;DiagnosticExit=$jobExit;
        Status=$(if($jobExit -eq 0){'DIAGNOSTIC_CASE_PASS'}else{'DIAGNOSTIC_CASE_FAIL'});
        CompilerExit=$compiler.ExitCode;NativeLastExit=$executionExit;CompilerArgs=$compiler.Args;
        FirstSourceDiagnostic=$sourceDiagnostic;MissingHeader=$missingHeader;Checks=$checks;
        Error=$errorText;Position=$errorPosition;Stack=$errorStack;Log=$logPath;
        LogSha256=(Get-FileHash -LiteralPath $logPath -Algorithm SHA256).Hash}
    $results.Add($row)
    [pscustomobject]@{DiagnosticOnly=$true;OfficialGate='FAIL';SourceCommit='1bf72f1530f79a04f6dc7ded688d770c421a4072';
        PlannedRemaining=$remainingJobs.Count;Completed=$results.Count;OfficialCompleted=$officialCompleted;
        UnavailableJobs=$unavailableJobs;Results=@($results.ToArray())} |
        ConvertTo-Json -Depth 15 | Set-Content -LiteralPath $matrixPath -Encoding utf8
    Write-Output "DIAGNOSTIC_DONE|$index|$($remainingJobs.Count)|$($job.Name)|exit=$jobExit|compiler=$($compiler.ExitCode)|native=$executionExit"
}
$failed=@($results | Where-Object {$_.DiagnosticExit -ne 0}).Count
Write-Output "DIAGNOSTIC_COMPLETE|cases=$($results.Count)|failures=$failed|official_gate=FAIL"
# Even complete diagnostic coverage must not turn the recorded official gate green.
exit 1
