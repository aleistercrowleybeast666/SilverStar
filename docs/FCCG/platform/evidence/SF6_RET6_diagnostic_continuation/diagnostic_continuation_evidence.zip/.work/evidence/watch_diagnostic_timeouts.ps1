$ErrorActionPreference='Stop'
$root='D:\python_software\SilverStar\.work\sf6_compact_ret6\.work\evidence'
$allowed='D:\python_software\SilverStar\.work\sf6_compact_ret6\.work\generated_ret6\build\FCCG\Host\DiagnosticContinuation'
$plan=Get-Content (Join-Path $root 'ret6_diagnostic_continuation_plan.json') -Raw | ConvertFrom-Json
$names=@($plan.RemainingJobs | Where-Object {$_.Kind -eq 'HOST_TEST'} | ForEach-Object {$_.Name})
$events=[System.Collections.Generic.List[object]]::new()
$clock=[Diagnostics.Stopwatch]::StartNew()
while ($clock.Elapsed.TotalMinutes -lt 20) {
    $matrix=Get-Content (Join-Path $root 'ret6_diagnostic_continuation_matrix.json') -Raw | ConvertFrom-Json
    if ($matrix.Completed -eq $matrix.PlannedRemaining) { break }
    foreach ($name in $names) {
        foreach ($process in @(Get-Process -Name $name -ErrorAction SilentlyContinue)) {
            if ([string]::IsNullOrWhiteSpace($process.Path)) { continue }
            if ($process.Path -ne (Join-Path $allowed ($name+'.exe'))) { continue }
            $elapsed=([DateTime]::Now-$process.StartTime).TotalSeconds
            if ($elapsed -lt 60) { continue }
            $id=$process.Id; $path=$process.Path; $started=$process.StartTime
            $verified=Get-Process -Id $id -ErrorAction Stop
            if ($verified.Path -ne $path -or $verified.StartTime -ne $started) { throw 'Process identity changed' }
            Stop-Process -Id $id -Force -ErrorAction Stop
            $events.Add([pscustomobject]@{Name=$name;PID=$id;Path=$path;StartTime=$started.ToString('o');
                TerminatedAt=[DateTime]::UtcNow.ToString('o');ObservedSeconds=$elapsed;TimeoutSeconds=60;
                Reason='Diagnostic process exceeded finite deadline; own executable path and start time verified. Original assertions/compile unchanged; timeout does not identify fault source.'})
            @($events.ToArray()) | ConvertTo-Json -Depth 6 -AsArray |
                Set-Content (Join-Path $root 'ret6_diagnostic_timeout_terminations.json') -Encoding utf8
            Write-Output "DIAGNOSTIC_TIMEOUT|$name|pid=$id|seconds=$elapsed"
        }
    }
    Start-Sleep -Seconds 5
}
Write-Output "DIAGNOSTIC_WATCH_FINISHED|terminations=$($events.Count)"
