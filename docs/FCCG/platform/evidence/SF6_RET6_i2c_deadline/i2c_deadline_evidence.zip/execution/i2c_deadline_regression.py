from pathlib import Path
import hashlib,importlib.util,io,subprocess,sys,tarfile
root=Path.cwd();app=root/'apps/SCG';family=app/'plugins/builtin/silverstar_mcu_family_stm32f1_flight/payload'
rel='apps/SCG/plugins/builtin/silverstar_mcu_family_stm32f1_flight/payload/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_i2c.c'
mode=sys.argv[1];out=root/'.work/evidence'/('i2c_deadline_'+mode);out.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('i2c_test',app/'tests/test_f1_i2c_deadline.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
original_run=subprocess.run
if mode=='before':
    baseline_commit=sys.argv[2] if len(sys.argv)>2 else '3edb2bc'
    archive=subprocess.check_output(['git','archive','--format=tar',baseline_commit,rel])
    with tarfile.open(fileobj=io.BytesIO(archive)) as t:data=t.extractfile(rel).read()
    baseline=out/'stm32f1xx_hal_i2c_before.c';baseline.write_bytes(data)
    selected=str(family/'Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_i2c.c')
    def before_run(command,*args,**kwargs):
        command=[str(baseline) if item==selected else item for item in command]
        print('ACTUAL_COMMAND',command,flush=True);return original_run(command,*args,**kwargs)
    module.subprocess.run=before_run
    print('BASELINE_COMMIT',baseline_commit,'SHA256',hashlib.sha256(data).hexdigest(),flush=True)
module.test_f1_i2c_actual_hal_whole_transaction_deadline(out)
