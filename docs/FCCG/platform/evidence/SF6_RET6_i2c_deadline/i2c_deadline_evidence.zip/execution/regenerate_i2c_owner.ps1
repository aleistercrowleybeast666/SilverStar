$ErrorActionPreference='Stop'
$root=(Get-Location).Path
$generated=[IO.Path]::GetFullPath((Join-Path $root '.work/generated_ret6'))
if ($generated -ne 'D:\python_software\SilverStar\.work\sf6_compact_ret6\.work\generated_ret6' -or -not (Test-Path -LiteralPath (Join-Path $generated '.fccg'))) { throw 'Ownership/path mismatch' }
if ((Get-Item -LiteralPath $generated).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Reparse point' }
& 'D:\python_software\SilverStar\apps\FLP\.venv\Scripts\python.exe' -c "from pathlib import Path;import zipfile,json,hashlib;r=Path.cwd();g=r/'.work/generated_ret6';o=r/'.work/evidence/i2c_738_pre_owner_guard_artifacts.zip';assert not o.exists();ps=[p for p in g.rglob('*') if p.is_file() and (p.suffix in {'.sslog','.ssdecoder'} or (p.suffix in {'.elf','.bin','.map','.su'} and 'Release' in p.parts))];z=zipfile.ZipFile(o,'w',zipfile.ZIP_DEFLATED);records=[];[(z.write(p,p.relative_to(g).as_posix()),records.append({'path':p.relative_to(g).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})) for p in ps];z.writestr('MANIFEST.json',json.dumps({'implementation':'738edb045ad92b94cbe6a9d0267c7db014e1a749','files':records},indent=2));z.close();print('Preserved',len(ps),'old linked artifacts and decoder outputs')"
if ($LASTEXITCODE -ne 0) { throw 'Archive failed' }
Remove-Item -LiteralPath $generated -Recurse -Force
$env:PYTHONPATH=$root+'\apps\SCG\src'
& 'D:\python_software\SilverStar\apps\FLP\.venv\Scripts\python.exe' .work/evidence/generate_ret6.py *> .work/evidence/ret6_i2c_owner_generation.log
Write-Output "GEN_EXIT=$LASTEXITCODE"
Get-Content .work/evidence/ret6_i2c_owner_generation.log -Tail 4
