from pathlib import Path
from collections import defaultdict
from datetime import datetime,timezone
import hashlib,io,json,re,subprocess,tarfile,zipfile

r=Path.cwd();g=r/'.work/generated_ret6';e=r/'.work/evidence'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='eaa11484995eb8978f8eac09ace87a7bc0b5edcb'
assert subprocess.run(['git','diff','--quiet','HEAD','--','apps/SCG']).returncode==0
base='3edb2bc830b4ed577a419be656c457b146a983f2'
out=r/'docs/FCCG/platform/evidence/SF6_RET6_i2c_deadline/i2c_deadline_evidence.zip'
out.parent.mkdir(parents=True,exist_ok=True)
manifest=[]
def sha(b):return hashlib.sha256(b).hexdigest()
linked=g/'build/FCCG/SilverStar_F103RE/Release'
map_text=(linked/'SilverStar_0_1_1.map').read_text()
map_text=map_text[map_text.index('Linker script and memory map'):]
joined=re.sub(r'\n (\.\S+)\n\s+(0x[0-9a-f]+)',r'\n \1 \2',map_text)
groups=defaultdict(int);rows=[]
for m in re.finditer(r'^ (\.\S+)\s+0x([0-9a-f]+)\s+0x([0-9a-f]+)\s+([^\n]+)',joined,re.M):
    sec,addr,size,owner=m[1],int(m[2],16),int(m[3],16),m[4]
    if not 0x08000000<=addr<0x08080000 or '.o' not in owner:continue
    if any(x in owner for x in ['libm.a(','libgcc.a(','libc.a(','libc_nano.a(','libnosys.a(']):group='toolchain_libraries'
    elif '/APP/Src/logger_' in owner or '/Protocol/SSLOG/' in owner:group='logger_and_sslog_code'
    elif any(x in owner for x in ['/APP/Src/imu_sample_bus.o','/APP/Src/estimator_bus.o','/Common/Src/common_spsc_queue.o']):group='sample_queue_code'
    elif '/Algorithm/' in owner or any(x in owner for x in ['/APP/Src/estimator_task.o','/APP/Src/ins_task.o']):group='algorithm_code'
    elif any(x in owner for x in ['/Platform/','/Drivers/','/HardwareGenerated/','/FreeRTOS']):group='platform_hal_rtos_code'
    elif any(x in owner for x in ['/Devices/','/SX1280lib/','/FatFs/']):group='device_radio_fatfs_code'
    else:group='other_code'
    groups[group]+=size;rows.append({'section':sec,'bytes':size,'owner':owner})
flash={'flash_load_bytes':(linked/'SilverStar_0_1_1.bin').stat().st_size,'disjoint_component_attribution':'NOT PROVEN: merged GNU strings may overlap raw input section sizes','raw_input_contributions_do_not_sum':dict(groups),'largest_raw_inputs':sorted(rows,key=lambda x:x['bytes'],reverse=True)[:24]}
commands=[
 {'command':'official bundled Java -jar STM32CubeMX.exe -q .work/evidence/cubemx_i2c_deadline.script','exit':0,'log':'cubemx_i2c_deadline.log'},
 {'command':'PYTHONPATH=apps/SCG/src python .work/evidence/generate_ret6.py','exit':0,'log':'ret6_i2c_owner_generation.log','result':'Plan True, Apply 1508 new files'},
 {'command':'python .work/evidence/i2c_deadline_regression.py before 3edb2bc','exit':1,'log':'ret6_i2c_owner_busy_prefailure_01.log','scope':'unchanged old HAL failure at model26000us'},
 {'command':'python .work/evidence/i2c_deadline_regression.py before 738edb0','exit':1,'log':'ret6_i2c_owner_prefailure_01.log','scope':'unchanged initial deadline HAL returns success after losing active state'},
 {'command':'python .work/evidence/i2c_deadline_regression.py after','exit':0,'log':'ret6_i2c_owner_post_01.log','scope':'47 modeled transaction cases plus rejection cases and six expected assertion trap exits'},
 {'command':'PYTHONPATH=apps/SCG/src python -m pytest apps/SCG/tests/test_f1_i2c_deadline.py apps/SCG/tests/test_f1_sd_clock.py apps/SCG/tests/test_compact_mode.py apps/SCG/tests/test_joint_sensor_library.py::test_joint_imu_actual_c_mock apps/SCG/tests/test_round4_bmp280.py apps/SCG/tests/test_barometer_cold.py -q -s','exit':0,'log':'ret6_i2c_owner_pytest.log','result':'20 passed, single latest run'},
]
for target,exit_code in [('all',0),('static-analysis',0),('power10-check',0),('architecture-check',2),('artifact-check',0),('stack-report',2),('host-tests',2)]:
    commands.append({'command':'mingw32-make -j4 '+target+' GCC_PATH="D:/Arm GNU Toolchain/14.3 rel1/bin" PYTHON="D:/python_software/SilverStar/apps/FLP/.venv/Scripts/python.exe" HOST_CC="D:/msys64/ucrt64/bin/gcc.exe"','exit':exit_code,'log':'ret6_i2c_owner_'+('arm' if target=='all' else target)+'.log'})
source=[]
archive=subprocess.check_output(['git','archive','--format=tar',head,'apps/SCG'])
with tarfile.open(fileobj=io.BytesIO(archive)) as t:
    for m in t:
        if m.isfile():
            b=t.extractfile(m).read();source.append({'path':m.name,'git_canonical_sha256':sha(b),'bytes':len(b)})
generated=[]
for p in sorted(g.rglob('*')):
    if p.is_file() and 'build' not in p.relative_to(g).parts:
        b=p.read_bytes();generated.append({'path':p.relative_to(g).as_posix(),'sha256':sha(b),'bytes':len(b)})
# Normalize only working-tree CRLF for owner/generated identity verification.
owner=r/'apps/SCG/plugins/builtin/silverstar_mcu_family_stm32f1_flight/payload'
for rel in ['Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_i2c.c','Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_i2c.h','Platform/STM32F1Flight/Src/platform_i2c_deadline.c','Platform/STM32F1Flight/Inc/platform_i2c_deadline.h']:
    assert (owner/rel).read_bytes().replace(b'\r\n',b'\n')==(g/rel).read_bytes().replace(b'\r\n',b'\n'),rel
assert '215528' in (e/'ret6_i2c_owner_artifact-check.log').read_text(errors='replace')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    def add(p,n):
        b=p.read_bytes();z.writestr(n,b);manifest.append({'path':n,'sha256':sha(b),'bytes':len(b)})
    for p in sorted(e.glob('ret6_i2c_*.log')):add(p,'logs/'+p.name)
    add(e/'cubemx_i2c_deadline.log','logs/cubemx_i2c_deadline.log')
    for n in ['cubemx_i2c_deadline.script','generate_ret6.py','i2c_deadline_regression.py','modify_i2c_deadline.py','regenerate_i2c_owner.ps1','package_i2c_evidence.py']:
        add(e/n,'execution/'+n)
    cube=r/'.work/cubemx_flight/SF6_RET6_Hardware'
    for n in ['SF6_RET6_Hardware.ioc','Core/Src/i2c.c','Core/Src/sdio.c','Core/Src/main.c','Core/Src/stm32f1xx_it.c','Core/Src/stm32f1xx_hal_timebase_tim.c']:
        add(cube/n,'official_cubemx/'+n)
    for scope in ['Release','StaticAnalysis/Release']:
        for p in sorted((g/'build/FCCG/SilverStar_F103RE'/scope).rglob('*')):
            if p.is_file() and p.suffix in {'.elf','.bin','.hex','.map','.su'}:add(p,'latest_generated/'+p.relative_to(g).as_posix())
    for n in ['Makefile','Generated/project_sources.mk','Generated/Inc/project_flight_config.h','Targets/SilverStar_F103RE/target.mk','Tools/check_power_of_ten.ps1','Tools/check_task_stacks.py','Tests/Host/run_tests.ps1']:
        add(g/n,'latest_generated/'+n)
    for p in (g/'Targets/SilverStar_F103RE').glob('*.ld'):add(p,'latest_generated/'+p.relative_to(g).as_posix())
    add(e/'ret6_final_map_symbols.json','ram_symbols.json')
    z.writestr('flash_symbols.json',json.dumps(flash,indent=2))
    add(e/'parent_review/SilverStar_SF6_RET6_53e34eb_independent_review_evidence.zip','parent_review/unchanged_review.zip')
    add(e/'i2c_738_pre_owner_guard_artifacts.zip','historical_738_checkpoint/linked_artifacts.zip')
    z.writestr('sdio_base_to_implementation.patch',subprocess.check_output(['git','diff','--binary',base,head]))
    z.writestr('source_and_execution_manifest.json',json.dumps({'implementation_commit':head,'base_commit':base,'branch':'codex/sf6-compact-ret6','packed_utc':datetime.now(timezone.utc).isoformat(),'versions':{'ARM_GCC':'14.3.1 20250623','Host_GCC':'16.1.0 Rev5 MSYS2','make':'4.4.1','Python':'3.14.0','PowerShell':'7.6.5','CubeMX':'6.15.0','FW_F1':'V1.8.7','FreeRTOS':'V11.3.0 CM3'},'commands':commands,'git_canonical_scg':source,'generated_files':generated,'acceptance':'BLOCKED','critical_contract_review':'NOT PROVEN','failed':['architecture','stack','full Host job8; 9-70 NOT RUN'],'not_run':['logger/storage rerun for this platform batch','hardware','wire timing','RET6 wall-time/WCET','whole-program task/main/MSP/ISR stack proof'],'logger':'75c48ad NOT integrated; additional1136B estimates combined65992B,456B overflow, NOT executed','source_owner_generated_identity':'PASS, CRLF normalization only','link_warnings':['nosys _close','nosys _lseek','nosys _read','nosys _write'],'all_archive_files':manifest},indent=2))
print(json.dumps({'path':str(out),'bytes':out.stat().st_size,'sha256':sha(out.read_bytes()),'implementation_commit':head},indent=2))
