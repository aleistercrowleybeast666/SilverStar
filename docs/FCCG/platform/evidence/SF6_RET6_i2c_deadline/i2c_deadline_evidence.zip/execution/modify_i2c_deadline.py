from pathlib import Path
p=Path('apps/SCG/plugins/builtin/silverstar_mcu_family_stm32f1_flight/payload/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_i2c.c')
s=p.read_text()
assert 'I2C_MemoryReadTransaction' not in s
start=s.index('HAL_StatusTypeDef HAL_I2C_Mem_Write(')
end=s.index('HAL_StatusTypeDef HAL_I2C_Mem_Write_IT(',start)
block=s[start:end]
for old,new in [('HAL_I2C_Mem_Write','I2C_MemoryWriteTransaction'),('HAL_I2C_Mem_Read','I2C_MemoryReadTransaction')]:
    block=block.replace('HAL_StatusTypeDef '+old+'(', 'static HAL_StatusTypeDef '+new+'(',1)
assert block.count('__HAL_LOCK(hi2c);')==2
block=block.replace('__HAL_LOCK(hi2c);','/* Outer blocking-memory wrapper already owns the lock. */')
block=block.replace('__HAL_UNLOCK(hi2c);','/* Outer wrapper retains lock through deadline cleanup. */')
# The IRQ-masked three-last-byte poll must use this same hardware deadline.
# The old fixed iteration limit remains a second independent fail-closed bound.
assert block.count('if (count == 0U)')==1
block=block.replace('if (count == 0U)','if ((count == 0U) || (I2C_MemoryPollCheck(hi2c) != HAL_OK))')
prefix=r'''
/* SilverStar controlled adaptation of STM32Cube FW_F1 V1.8.7.
 * One per-handle CYCCNT deadline owns the complete blocking-memory transaction;
 * shared vendor wait helpers preserve their old behavior for other operations.
 * Preserve ST license and original receive hardware sequencing. */
static HAL_StatusTypeDef I2C_MemoryPollCheck(I2C_HandleTypeDef *hi2c)
{
  uint32_t errors;
  if (hi2c->MemoryDeadline.active == 0U) { return HAL_OK; }
  if (PlatformI2cDeadline_Expired(&hi2c->MemoryDeadline) != 0U)
  {
    hi2c->ErrorCode |= HAL_I2C_ERROR_TIMEOUT;
    return HAL_TIMEOUT;
  }
  errors = hi2c->Instance->SR1 & (I2C_SR1_BERR | I2C_SR1_ARLO | I2C_SR1_AF | I2C_SR1_OVR);
  if (errors == 0U) { return HAL_OK; }
  if ((errors & I2C_SR1_BERR) != 0U) { hi2c->ErrorCode |= HAL_I2C_ERROR_BERR; }
  if ((errors & I2C_SR1_ARLO) != 0U) { hi2c->ErrorCode |= HAL_I2C_ERROR_ARLO; }
  if ((errors & I2C_SR1_AF) != 0U) { hi2c->ErrorCode |= HAL_I2C_ERROR_AF; }
  if ((errors & I2C_SR1_OVR) != 0U) { hi2c->ErrorCode |= HAL_I2C_ERROR_OVR; }
  return HAL_ERROR;
}

static HAL_StatusTypeDef I2C_MemoryBegin(I2C_HandleTypeDef *hi2c, uint16_t address,
    uint16_t mem_size, const uint8_t *data, uint16_t size, uint32_t timeout)
{
  if ((hi2c == NULL) || (hi2c->Instance == NULL) || (data == NULL) ||
      (size == 0U) || (address < 0x10U) || (address > 0xEEU) ||
      ((address & 1U) != 0U) || !IS_I2C_MEMADD_SIZE(mem_size) ||
      (timeout == 0U) || (timeout > 1000U) ||
      (__get_IPSR() != 0U) || (__get_PRIMASK() != 0U))
  { return HAL_ERROR; }
  if (hi2c->State != HAL_I2C_STATE_READY) { return HAL_BUSY; }
  __HAL_LOCK(hi2c);
  hi2c->ErrorCode = HAL_I2C_ERROR_NONE;
  if (PlatformI2cDeadline_Start(&hi2c->MemoryDeadline, timeout) !=
      PlatformI2cDeadlineResult_Ok)
  {
    hi2c->ErrorCode = HAL_I2C_ERROR_TIMEOUT;
    __HAL_UNLOCK(hi2c);
    return HAL_TIMEOUT;
  }
  return HAL_OK;
}

static HAL_StatusTypeDef I2C_MemoryFinish(I2C_HandleTypeDef *hi2c,
    HAL_StatusTypeDef result, uint32_t original_ack_pos)
{
  if ((result == HAL_OK) && (I2C_MemoryPollCheck(hi2c) != HAL_OK))
  { result = HAL_ERROR; }
  if (result != HAL_OK)
  {
    /* Never issue STOP after losing arbitration, or for somebody else's BUSY. */
    if (((hi2c->ErrorCode & HAL_I2C_ERROR_ARLO) == 0U) &&
        ((hi2c->Instance->SR2 & I2C_SR2_MSL) != 0U))
    { SET_BIT(hi2c->Instance->CR1, I2C_CR1_STOP); }
    CLEAR_BIT(hi2c->Instance->CR1, I2C_CR1_START);
    CLEAR_BIT(hi2c->Instance->SR1, I2C_SR1_BERR | I2C_SR1_ARLO | I2C_SR1_AF | I2C_SR1_OVR);
    if ((hi2c->ErrorCode & HAL_I2C_ERROR_TIMEOUT) != 0U)
    { result = HAL_TIMEOUT; }
  }
  MODIFY_REG(hi2c->Instance->CR1, I2C_CR1_ACK | I2C_CR1_POS, original_ack_pos);
  hi2c->PreviousState = I2C_STATE_NONE;
  hi2c->State = HAL_I2C_STATE_READY; /* HAL available; not controller/device READY. */
  hi2c->Mode = HAL_I2C_MODE_NONE;
  hi2c->MemoryDeadline.active = 0U;
  __HAL_UNLOCK(hi2c);
  return result;
}

'''
suffix=r'''
HAL_StatusTypeDef HAL_I2C_Mem_Write(I2C_HandleTypeDef *hi2c, uint16_t DevAddress,
    uint16_t MemAddress, uint16_t MemAddSize, uint8_t *pData, uint16_t Size, uint32_t Timeout)
{
  HAL_StatusTypeDef result = I2C_MemoryBegin(hi2c, DevAddress, MemAddSize, pData, Size, Timeout);
  uint32_t original_ack_pos;
  if (result != HAL_OK) { return result; }
  original_ack_pos = hi2c->Instance->CR1 & (I2C_CR1_ACK | I2C_CR1_POS);
  result = I2C_MemoryWriteTransaction(hi2c, DevAddress, MemAddress, MemAddSize, pData, Size, Timeout);
  return I2C_MemoryFinish(hi2c, result, original_ack_pos);
}

HAL_StatusTypeDef HAL_I2C_Mem_Read(I2C_HandleTypeDef *hi2c, uint16_t DevAddress,
    uint16_t MemAddress, uint16_t MemAddSize, uint8_t *pData, uint16_t Size, uint32_t Timeout)
{
  HAL_StatusTypeDef result = I2C_MemoryBegin(hi2c, DevAddress, MemAddSize, pData, Size, Timeout);
  uint32_t original_ack_pos;
  if (result != HAL_OK) { return result; }
  original_ack_pos = hi2c->Instance->CR1 & (I2C_CR1_ACK | I2C_CR1_POS);
  result = I2C_MemoryReadTransaction(hi2c, DevAddress, MemAddress, MemAddSize, pData, Size, Timeout);
  return I2C_MemoryFinish(hi2c, result, original_ack_pos);
}

'''
# insert suffix BEFORE following function's Doxygen, rather than splitting it
marker=block.rfind('/**')
block=block[:marker]+suffix+block[marker:]
s=s[:start]+prefix+block+s[end:]
# Only helpers that are actually reachable from memory transactions.
helper_start=s.index('static HAL_StatusTypeDef I2C_WaitOnFlagUntilTimeout(',s.index('HAL_StatusTypeDef HAL_I2C_Mem_Read('))
for name in ['I2C_WaitOnFlagUntilTimeout','I2C_WaitOnMasterAddressFlagUntilTimeout','I2C_WaitOnTXEFlagUntilTimeout','I2C_WaitOnBTFFlagUntilTimeout','I2C_WaitOnRXNEFlagUntilTimeout','I2C_IsAcknowledgeFailed']:
    a=s.index('static HAL_StatusTypeDef '+name+'(',helper_start)
    a=s.index('{',a);depth=1;b=a+1
    while depth:
        if s[b]=='{':depth+=1
        elif s[b]=='}':depth-=1
        b+=1
    part=s[a:b]
    part=part.replace('__HAL_UNLOCK(hi2c);','if (hi2c->MemoryDeadline.active == 0U) { __HAL_UNLOCK(hi2c); }')
    part=part.replace('return HAL_OK;','return I2C_MemoryPollCheck(hi2c);')
    # Entry check and loop-body checks catch READY flags arriving after expiry.
    check='\n  if (I2C_MemoryPollCheck(hi2c) != HAL_OK) { return HAL_ERROR; }\n'
    part=part[:1]+check+part[1:]
    import re
    part=re.sub(r'(while \([^\n]+\)\n  \{)',r'\1'+check,part)
    s=s[:a]+part+s[b:]
# reset deadline in the HAL reset-state initialization branch, before callbacks
s=s.replace('hi2c->Lock = HAL_UNLOCKED;','hi2c->Lock = HAL_UNLOCKED;\n    hi2c->MemoryDeadline.active = 0U;',1)
p.write_text(s,newline='\n')
print('Modified owning F1 Flight HAL, preserved vendor license and hardware receive sequencing.')
