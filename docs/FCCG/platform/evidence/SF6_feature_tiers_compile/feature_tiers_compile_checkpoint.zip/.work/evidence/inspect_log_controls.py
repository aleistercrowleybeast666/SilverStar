import os
os.environ['QT_QPA_PLATFORM'] = 'offscreen'
import json
from pathlib import Path
from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel
from PySide6.QtGui import QPalette, QFont, QFontDatabase
import sys
from silverstar_fccg.core.i18n import Translator
from silverstar_fccg.core.view_models import LoggingStreamView
from silverstar_fccg.ui.pages.components import FlightConfigurationPage
from silverstar_fccg.ui.widgets import StandardCheckBox, StandardComboBox
from silverstar_fccg.ui.theme import Theme_Apply

app = QApplication([])
QFontDatabase.addApplicationFont('C:/Windows/Fonts/msyh.ttc')
QFontDatabase.addApplicationFont('C:/Windows/Fonts/arial.ttf')
app.setFont(QFont('Microsoft YaHei', 9))
phase = sys.argv[1] if len(sys.argv) > 1 else 'before'
out = Path('.work/evidence/feature_tiers'); out.mkdir(parents=True, exist_ok=True)
states = []
for theme in ('light', 'dark'):
    Theme_Apply(app, theme)
    if phase == 'before_readable':
        # Reproduce the captured pre-fix stylesheet with readable local fonts;
        # the original pre-fix screenshots and state receipt remain preserved.
        import re
        app.setStyleSheet(re.sub(r'QCheckBox#standardCheckBox\[logStreamControl="true"\]::indicator:[^}]+}\n', '', app.styleSheet()))
    for language in ('zh_CN', 'en_US'):
        translator = Translator(language)
        page = FlightConfigurationPage(translator)
        page.Streams_Set([
            LoggingStreamView('checked', '已选禁用 / Checked disabled', True, 'flight', editable=False),
            LoggingStreamView('unchecked', '未选禁用 / Unchecked disabled', False, 'flight', editable=False),
            LoggingStreamView('required', '必需 / Required', True, 'flight', required=True),
            LoggingStreamView('unavailable', '不可用 / Unavailable', False, 'flight', available=False),
        ])
        root = QWidget(); layout = QVBoxLayout(root)
        layout.addWidget(QLabel('Same theme / same class reference'))
        for checked in (False, True):
            reference = StandardCheckBox('Reference disabled')
            reference.setChecked(checked); reference.setEnabled(False)
            layout.addWidget(reference)
        combo = StandardComboBox(); combo.addItem('Reference disabled'); combo.setEnabled(False)
        layout.addWidget(combo)
        page.logging_table.setMinimumHeight(220)
        layout.addWidget(page.logging_table)
        root.resize(1050, 390); root.show(); app.processEvents()
        root.grab().save(str(out / f'ui_{phase}_{theme}_{language}.png'))
        for check in root.findChildren(StandardCheckBox):
            states.append(dict(theme=theme, language=language, stream=check.property('streamId'),
                checked=check.isChecked(), enabled=check.isEnabled(), locked=check.property('locked'),
                disabled_text=check.palette().color(QPalette.ColorGroup.Disabled, QPalette.ColorRole.WindowText).name()))
        root.close(); root.deleteLater(); page.deleteLater(); app.processEvents()
(out / f'ui_{phase}_states.json').write_text(json.dumps(states, indent=2), encoding='utf-8')
print(json.dumps(states[:6], indent=2))
