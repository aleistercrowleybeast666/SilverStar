import os, json, hashlib
os.environ['QT_QPA_PLATFORM']='offscreen'
from pathlib import Path
from PySide6.QtCore import QTimer, QEventLoop
from PySide6.QtGui import QFont, QFontDatabase
from PySide6.QtWidgets import QApplication
from silverstar_fccg.core.i18n import Translator
from silverstar_fccg.ui.pages.components import DevicesPage
from silverstar_fccg.ui.theme import Theme_Apply
app=QApplication([])
QFontDatabase.addApplicationFont('C:/Windows/Fonts/msyh.ttc')
app.setFont(QFont('Microsoft YaHei',9));Theme_Apply(app,'light')
page=DevicesPage(Translator('en_US'))
page.resize(1000,550);page.show();app.processEvents()
page.FeatureTier_Set('compact')
loop=QEventLoop();QTimer.singleShot(350,loop.quit);loop.exec()
app.processEvents()
label=page.feature_tier_description
image=Path('.work/evidence/feature_tiers/global_light_en_US_stable.png')
page.feature_tier_combo.parentWidget().grab().save(str(image))
row={'viewport':[1000,550],'settle_ms':350,'label_width':label.width(),'label_height':label.height(),
     'label_height_for_width':label.heightForWidth(label.width()),'text':label.text(),
     'image_sha256':hashlib.sha256(image.read_bytes()).hexdigest()}
Path('.work/evidence/feature_tiers/global_light_en_US_stable.json').write_text(json.dumps(row,indent=2)+'\n',encoding='utf-8')
print(json.dumps(row));page.close()
