from pathlib import Path
from collections import defaultdict
import re, json, hashlib, subprocess
root = Path.cwd()
for short, target, capacity, flash in [('rft6', 'SilverStar_F103RF', 98304, 786432),
                                      ('ret6', 'SilverStar_F103RE', 65536, 524288)]:
    project = root / f'.work/generated_{short}_tiers'
    evidence = root / f'.work/evidence/{short}_tiers_gates'
    build = project / 'build/FCCG' / target / 'Release'
    mapfile = build / 'SilverStar_0_1_1.map'
    content = mapfile.read_text(encoding='utf-8')
    section = lambda name: re.search(r'^' + re.escape(name) + r'\s+0x([0-9a-f]+)\s+0x([0-9a-f]+)', content, re.M)
    sizes = {name: int(section(name)[2], 16) for name in ('.text', '.data', '.bss')}
    msp = int(section('._user_heap_stack')[2], 16)
    used = int(section('._user_heap_stack')[1], 16) + msp - 0x20000000
    region = content[content.index('\n.data '):content.index('\n._user_heap_stack')]
    rows = [(int(m[3], 16), m[1], m[4]) for m in re.finditer(
        r'^ (\.(?:bss|data)\S*)\s+0x([0-9a-f]+)\s+0x([0-9a-f]+)\s+([^\n]+\.o)', region, re.M)]
    groups = defaultdict(int)
    for size, name, owner in rows:
        if '_stack' in name:
            group = 'static_task_stacks_in_bss'
        elif ('/APP/Src/logger_bus.o' in owner and 'storage' in name) or (
            ('/APP/Src/estimator_bus.o' in owner or '/APP/Src/imu_sample_bus.o' in owner) and name == '.bss.s_queue'):
            group = 'sample_and_log_queues'
        elif 'logger_' in owner or '/Protocol/SSLOG/' in owner:
            group = 'other_logging'
        elif '/Algorithm/' in owner or '/APP/Src/estimator_task.o' in owner or '/APP/Src/ins_task.o' in owner:
            group = 'algorithm_and_origin_state'
        elif any(value in owner for value in ('/Platform/', '/Drivers/', '/HardwareGenerated/', '/FreeRTOS')):
            group = 'platform_vendor_rtos'
        elif '/Devices/' in owner:
            group = 'device_state'
        else:
            group = 'other'
        groups[group] += size
    groups['alignment_fill_or_unparsed'] = used - msp - sum(groups.values())
    groups['main_msp'] = msp
    binary = build / 'SilverStar_0_1_1.bin'; elf = build / 'SilverStar_0_1_1.elf'
    receipt = json.loads((evidence / 'arm.json').read_text())
    result = {'source_commit': receipt['source_commit'], 'arm_exit': receipt['exit'],
        'target': target, 'tier': 'compact' if short == 'rft6' else 'minimal',
        **sizes, 'ram_used': used, 'ram_capacity': capacity, 'ram_spare': capacity-used,
        'ram_spare_percent': (capacity-used)*100/capacity,
        'twenty_percent_goal_gap': max(0, used-capacity*4//5), 'flash_capacity': flash,
        'flash_binary_load_bytes': binary.stat().st_size if binary.is_file() else None,
        'map_flash_load_span': int(re.search(r'^\.data\s+.*load address 0x([0-9a-f]+)',content,re.M)[1],16)+sizes['.data']-0x08000000,
        'usable_elf': elf.is_file() and receipt['exit'] == 0,
        'groups': {key: {'bytes': value, 'percent_of_ram': value*100/capacity} for key,value in groups.items()},
        'largest_symbols': [{'bytes': size, 'symbol': name, 'object': owner} for size,name,owner in sorted(rows,reverse=True)[:30]],
        'hashes': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (mapfile, binary, elf) if p.is_file()},
        'counting_boundary': 'Task/idle stacks are counted once in BSS; MSP separately. Map layout is not call-path stack/WCET proof.'}
    assert sum(value['bytes'] for value in result['groups'].values()) == used
    (evidence/'map_resources.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    if elf.is_file():
        symbols = subprocess.check_output(['D:/Arm GNU Toolchain/14.3 rel1/bin/arm-none-eabi-nm.exe', '-S', '--size-sort', str(elf)], text=True)
        (evidence/'symbols_nm.log').write_text(symbols,encoding='utf-8')
    print(json.dumps({key:value for key,value in result.items() if key not in ('largest_symbols', 'groups', 'hashes')}))
