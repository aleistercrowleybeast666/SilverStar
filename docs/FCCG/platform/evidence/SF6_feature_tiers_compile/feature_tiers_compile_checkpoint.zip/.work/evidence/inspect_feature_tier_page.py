import os
os.environ['QT_QPA_PLATFORM'] = 'offscreen'
from pathlib import Path
from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QFont, QFontDatabase
from silverstar_fccg.core.i18n import Translator
from silverstar_fccg.ui.pages.components import DevicesPage
from silverstar_fccg.ui.theme import Theme_Apply
app = QApplication([])
QFontDatabase.addApplicationFont('C:/Windows/Fonts/msyh.ttc')
app.setFont(QFont('Microsoft YaHei', 9))
for theme in ('light', 'dark'):
    Theme_Apply(app, theme)
    for language in ('zh_CN', 'en_US'):
        page = DevicesPage(Translator(language))
        page.resize(1000, 550); page.show(); app.processEvents()
        page.FeatureTier_Set('compact'); app.processEvents()
        page.feature_tier_combo.parentWidget().grab().save(
            str(Path('.work/evidence/feature_tiers') / f'global_{theme}_{language}.png'))
        page.close(); page.deleteLater(); app.processEvents()
print('Actual first-page Global configuration controls captured in four theme/language combinations.')
