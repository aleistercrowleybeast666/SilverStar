from pathlib import Path
from dataclasses import replace
import json, hashlib, subprocess
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.core.workspace import WorkspacePolicy
from silverstar_fccg.hardware.cubemx import CubeMxImporter
from silverstar_fccg.generator.assembler import ProjectAssembler
from silverstar_fccg.project.model import DeviceInstance
from silverstar_fccg.project.configuration import ProjectConfiguration_Reconcile
from silverstar_fccg.project.validation import Project_Validate
root=Path.cwd(); service=FccgService(root/'apps/SCG'); catalog=service.catalog
policy=WorkspacePolicy(root/'.work'); importer=CubeMxImporter(policy)
hardware=importer.Project_Import(root/'.work/cubemx_rft6/SF6_RFT6_Hardware',
                                expected_mcu='STM32F103RFT6',risk_acknowledged=True)
print('IMPORT',hardware.warnings)
print(json.dumps(hardware.inventory.Dictionary_Get(),indent=2))
m=service.ReferenceProject_Create('SF6_RFT6_Compact_Tiers')
m.board=''; m.mcu='silverstar.mcu.stm32f103rft6'
m.mcu_family='silverstar.mcu_family.stm32f1_flight';m.os='silverstar.os.freertos_11_3_0_cm3'
m.hardware=hardware.hardware
# Reuse the compact same-instance recovery contract with all-stream logging.
# No new queue, logger, stack, RF or protocol reduction is introduced here.
m.build=replace(m.build,feature_tier='compact',
                target_profile='SilverStar_F103RF',
                gcc_path='D:/Arm GNU Toolchain/14.3 rel1/bin/arm-none-eabi-gcc.exe',
                make_command='D:/msys64/ucrt64/bin/mingw32-make.exe')
m.protocols['maintenance']=None
m.device_instances=[DeviceInstance('imu0','silverstar.device.imu.mpu6050'),
    DeviceInstance('gnss0','silverstar.device.gnss.neo_m9n'),
    DeviceInstance('telemetry0','silverstar.device.telemetry.sx1281',module_variant='e28_2g4m12sx',tx_power_dbm=12),
    DeviceInstance('barometer0','silverstar.device.barometer.bmp280'),
    DeviceInstance('storage0','silverstar.device.storage.sd_sdio_fatfs_f1'),
    DeviceInstance('launch_ignition0','silverstar.device.actuator.launch_ignition'),
    DeviceInstance('parachute_pyro0','silverstar.device.actuator.parachute_pyro'),
    DeviceInstance('system_indicator0','silverstar.device.indicator.system_status')]
m.strategies['estimator']='silverstar.algorithm.estimator.sf6'
m.resource_assignments={'imu0:data':'I2C1','imu0:time':'SYSTEM_TIME',
    'gnss0:data':'USART1','gnss0:reset':'PA1','gnss0:timepulse':'PA3','gnss0:time':'SYSTEM_TIME',
    'barometer0:data':'I2C1','barometer0:time':'SYSTEM_TIME',
    'telemetry0:radio_bus':'SPI1','telemetry0:radio_nss':'PA4','telemetry0:radio_reset':'PB0',
    'telemetry0:radio_busy':'PB1','telemetry0:radio_dio1':'PB2','telemetry0:time':'SYSTEM_TIME',
    'storage0:storage':'SDIO','storage0:time':'SYSTEM_TIME',
    'launch_ignition0:output':'PB13','launch_ignition0:time':'SYSTEM_TIME',
    'parachute_pyro0:output':'PB12','parachute_pyro0:time':'SYSTEM_TIME','system_indicator0:output':'PB14'}
reconciled=ProjectConfiguration_Reconcile(m,catalog);m=reconciled.model
print('NOTICES',reconciled.notices)
valid=Project_Validate(m,catalog); print('VALIDATION',valid)
evidence=root/'.work/evidence/rft6_tiers'; evidence.mkdir(exist_ok=True)
(evidence/'model.json').write_text(json.dumps(m.Dictionary_Get(),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assembler=ProjectAssembler(policy,catalog)
plan=assembler.Plan(m,root/'.work/generated_rft6_tiers');print('PLAN',plan.valid)
if not plan.valid:
    raise SystemExit('NORMAL PLAN REJECTED; no diagnostic bypass generation')
result=assembler.Apply(m,plan); print('APPLY',result)
(evidence/'generation.json').write_text(json.dumps({
    'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'source_status':subprocess.check_output(['git','status','--short'],text=True),
    'target':'STM32F103RFT6','hardware_mode':m.hardware.mode,
    'cube_ioc_sha256':hashlib.sha256((root/'.work/cubemx_rft6/SF6_RFT6_Hardware/SF6_RFT6_Hardware.ioc').read_bytes()).hexdigest(),
    'feature_tier':'compact','logging_profile':'all_streams','arm_flags':['-mcpu=cortex-m3','-mthumb','-mfloat-abi=soft'],
    'applied':True},indent=2)+'\n')

