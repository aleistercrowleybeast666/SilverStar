from pathlib import Path
import json,hashlib
from silverstar_fccg.hardware.cubemx import CubeMxImporter
from silverstar_fccg.core.workspace import WorkspacePolicy
r=Path.cwd();i=CubeMxImporter(WorkspacePolicy(r/'.work'));sid='b582e89bf934a92fce53c2c704e1ede4be4a42417b031c9321ceb6f8130072ee';c=r/'.work/cubemx_flight/SF6_RET6_Hardware';s=r/'.work/.fccg/hardware_imports'/sid/'STM32CubeMX';files=i._SourceFiles_Get(c);digest=hashlib.sha256();rows=[]
for f in files:
 n=f.relative_to(c).as_posix();target=s/n;extended=Path('\\\\?\\'+str(target));a=f.read_bytes();b=extended.read_bytes();assert a==b
 h=hashlib.sha256(b).digest();digest.update(n.encode('utf-8'));digest.update(b'\0');digest.update(h)
 rows.append({'path':n,'sha256':h.hex(),'bytes':len(b),'normal_is_file':target.is_file(),'absolute_path_length':len(str(target))})
assert digest.hexdigest()==sid
rep={'status':'CANONICAL_ORIGINAL_INPUT_IDENTITY_PROVEN','source_id':sid,'computed_digest':digest.hexdigest(),'original_input_files':len(files),'note':'Uses CubeMxImporter original sorted input list and exact same digest algorithm. Post-import README is not an original input. Two long path files exist and are identical; Windows ordinary path enumeration omitted them. No snapshot/source mutation, new generator invocation, ID rewrite, permissions or OS settings change.','files':rows}
(r/'.work/evidence/snapshot_canonical_identity_proof.json').write_text(json.dumps(rep,indent=2)+'\n');print(json.dumps({k:v for k,v in rep.items() if k!='files'},indent=2))
