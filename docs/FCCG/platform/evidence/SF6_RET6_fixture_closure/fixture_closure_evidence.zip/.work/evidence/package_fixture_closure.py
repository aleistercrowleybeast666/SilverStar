from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json,hashlib,subprocess,sys
r=Path.cwd();e=r/'.work/evidence';p=r/'.work/generated_ret6';head='1bf72f1530f79a04f6dc7ded688d770c421a4072';base='29f0abdd918f1ae038cea8e722aaf9a0946839f9'
def git(*a):return subprocess.check_output(['git',*a])
def sha(b):return hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==head
assert subprocess.call(['git','diff','--quiet','HEAD','--','apps/SCG'])==0
paths=git('diff','--name-only',base,head,'--','apps/SCG').decode().splitlines();assert len(paths)==3 and all('/Tests/Host/' in x for x in paths)
files={};raw=[]
def add(f,n=None):
 if f.is_file():files[n or f.relative_to(r).as_posix()]=f.read_bytes()
for n in paths:
 data=(r/n).read_bytes();blob=git('show',head+':'+n);files[n]=data;raw.append({'path':n,'bytes':len(data),'raw_sha256':sha(data),'git_blob_oid':git('rev-parse',head+':'+n).decode().strip(),'git_blob_sha256':sha(blob),'raw_equals_git_blob':data==blob})
files['SOURCE_PATCH.diff']=git('diff','--binary',base,head,'--','apps/SCG')
add(r/'docs/FCCG/platform/details/SF6_RET6_FIXTURE_CLOSURE.md','REPORT.md')
for pattern in ('ret6_fixture*.log','ret6_snapshot*.log','union_stats_*.json'):
 for f in e.glob(pattern):add(f)
for n in ('preserved_fixture_closure.zip','fixture_closure_complete_host_classification.json','fixture_closure_stack_callback_review.json','snapshot_canonical_identity_proof.json','current_snapshot_digest_readonly.json','snapshot_identity_addendum_package.json','SilverStar_SF6_RET6_SNAPSHOT_CANONICAL_IDENTITY_ADDENDUM.zip','library_snapshot_identity_addendum_upload.json','audit_union_stats.py','audit_snapshot_digest.py','prove_snapshot_canonical_identity.py','restore_official_snapshot_missing.py','audit_current_stack_callbacks.py','audit_current_stack_callbacks_corrected.py','audit_current_stack_callbacks_final.py','package_snapshot_identity_addendum.py','package_fixture_closure.py'):add(e/n)
for f in (e/'stack_readonly').iterdir():
 if f.suffix in ('.asm','.txt'):add(f)
for f in p.glob('*.ssdecoder'):add(f,'current_decoder/'+f.name)
for f in (p/'build/FCCG/Host/Tests/StorageIntegrity').glob('sf6-compact-*.sslog'):add(f,'immutable_current_logs/'+f.name)
for n in ('SilverStar.ssproject','Tests/Host/run_tests.ps1','Tests/Host/test_logger_alignment.c','Tests/Host/storage_integrity/test_sf6_compact_storage.h','Tests/Host/storage_integrity/test_logger_storage.c','Tests/Host/storage_integrity/run_storage_integrity.py','Tools/check_task_stacks.py','Generated/project_sources.mk'):add(p/n,'generated/'+n)
commands={'source_commit':head,'production_unchanged':True,'python':sys.version,'generation':'regenerate_selected_ret6.ps1 -Label fixture_closure; official Cube output reuse, old immutable SSLOG/decoder preserved','complete_host':'emitted mingw32-make -C .work/generated_ret6 GCC_PATH=D:/Arm GNU Toolchain/14.3 rel1/bin PYTHON=D:/python_software/SilverStar/apps/FLP/.venv/Scripts/python.exe HOST_CC=D:/msys64/ucrt64/bin/gcc.exe host-tests -> exit2 first JY positive fixture failure','alignment_and_storage':'FLP venv/Scripts on PATH; generated Tests/Host/run_tests.ps1 -HostCompiler D:/msys64/ucrt64/bin/gcc.exe -Only logger_alignment_actual -> exit0 and actual four storage phases','FLP_before':'FLP venv python audit_union_stats.py before, prior generated logs captured in preserved_fixture_closure.zip; corrected helper count assumptions retained','FLP_after':'FLP venv python audit_union_stats.py after -> final exit0; official LogOpenCoordinator exact decoder, recorded mode/increments, full diagnostics','snapshot':'PYTHONPATH=apps/SCG/src FLP venv python prove_snapshot_canonical_identity.py; 920 original inputs, byte comparison then exact digest -> declared b582; read-only extended paths','stack':'FLP venv python audit_current_stack_callbacks_final.py -> exact prior ELF from immutable earlier ZIP, current144linked sources byte-identical, real nm/objdump; no numeric bound or gate change','current_firmware_build':'NOT RERUN: fixture-only delta; previous measured source1fc map/gate scope preserved with144input hash identity proof','GUI':'NOT RERUN/NOT MODIFIED; previous1failure remains','hardware':'NOTRUN; no hardware/serial/probe/flash actions'}
files['COMMANDS.json']=(json.dumps(commands,indent=2)+'\n').encode()
manifest={'source_commit':head,'base_documented_commit':base,'status':'FIXTURE_CLOSURE_PASSED_FULL_HOST_FAIL_ACCEPTANCE_BLOCKED','raw_source_identity':raw,'parent_final_evidence_sha256':'2e9d06c3b1527f5b653755a2db7142a8a491a638edc3dbbbd7ea56b087e83dc7','parent_final_library_id':'libfile_1595c3a3ca508191948d25fb81382fbf','files':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())]}
out=r/'docs/FCCG/platform/evidence/SF6_RET6_fixture_closure';out.mkdir(parents=True,exist_ok=True);archive=out/'fixture_closure_evidence.zip'
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=6) as z:
 for n,b in files.items():z.writestr(n,b)
 z.writestr('MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
with ZipFile(archive) as z:
 for x in manifest['files']:assert sha(z.read(x['path']))==x['sha256']
digest=sha(archive.read_bytes());(out/'fixture_closure_evidence.sha256').write_text(digest+'  fixture_closure_evidence.zip\n');(out/'fixture_closure_manifest.json').write_text(json.dumps({'archive_sha256':digest,'archive_bytes':archive.stat().st_size,**manifest},indent=2)+'\n')
print(json.dumps({'path':str(archive),'bytes':archive.stat().st_size,'sha256':digest,'verified_files':len(files),'source_commit':head}))
