from pathlib import Path
import json,hashlib
from silverstar_fccg.hardware.cubemx import CubeMxImporter
from silverstar_fccg.core.workspace import WorkspacePolicy
r=Path.cwd();i=CubeMxImporter(WorkspacePolicy(r/'.work'));sid='b582e89bf934a92fce53c2c704e1ede4be4a42417b031c9321ceb6f8130072ee';c=r/'.work/cubemx_flight/SF6_RET6_Hardware';s=r/'.work/.fccg/hardware_imports'/sid/'STM32CubeMX';rep=json.loads((r/'.work/evidence/current_snapshot_digest_readonly.json').read_text())
assert rep['original_digest']==sid and not rep['changed_paths'] and len(rep['missing_paths'])==2
restored=[]
for name in rep['missing_paths']:
 source=c/name;target=s/name;target.resolve().relative_to(s.resolve());assert not target.exists()
 data=source.read_bytes();target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 assert target.read_bytes()==data
 restored.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
cf=i._SourceFiles_Get(c);snapshot_original_order=tuple(s/f.relative_to(c) for f in cf)
assert all(a.read_bytes()==b.read_bytes() for a,b in zip(cf,snapshot_original_order))
actual=i._SnapshotDigest_Get(s,snapshot_original_order);assert actual==sid
result={'status':'ORIGINAL_INPUT_IDENTITY_RESTORED','declared_id':sid,'canonical_digest_using_exact_original_input_list':actual,'original_files':len(cf),'post_import_README_excluded':True,'restored':restored,'cause_of_prior_missing_files':'NOT_PROVEN; no shared-file mutations found. Restore is from existing official output, not a new generator run or ID rewrite.'}
(r/'.work/evidence/current_snapshot_restored_identity.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
