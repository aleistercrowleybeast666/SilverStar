
D:\python_software\SilverStar\.work\sf6_compact_ret6\.work\evidence\stack_readonly\source_1fcf9b2.elf:     file format elf32-littlearm


Disassembly of section .text:

08024f98 <SensorRegister_Write>:
 8024f98:	b198      	cbz	r0, 8024fc2 <SensorRegister_Write+0x2a>
 8024f9a:	b530      	push	{r4, r5, lr}
 8024f9c:	6885      	ldr	r5, [r0, #8]
 8024f9e:	b083      	sub	sp, #12
 8024fa0:	b165      	cbz	r5, 8024fbc <SensorRegister_Write+0x24>
 8024fa2:	b15a      	cbz	r2, 8024fbc <SensorRegister_Write+0x24>
 8024fa4:	f103 3cff 	add.w	ip, r3, #4294967295
 8024fa8:	f1bc 0f3f 	cmp.w	ip, #63	@ 0x3f
 8024fac:	d806      	bhi.n	8024fbc <SensorRegister_Write+0x24>
 8024fae:	f44f 64fa 	mov.w	r4, #2000	@ 0x7d0
 8024fb2:	6800      	ldr	r0, [r0, #0]
 8024fb4:	9400      	str	r4, [sp, #0]
 8024fb6:	47a8      	blx	r5
 8024fb8:	b003      	add	sp, #12
 8024fba:	bd30      	pop	{r4, r5, pc}
 8024fbc:	2001      	movs	r0, #1
 8024fbe:	b003      	add	sp, #12
 8024fc0:	bd30      	pop	{r4, r5, pc}
 8024fc2:	2001      	movs	r0, #1
 8024fc4:	4770      	bx	lr
