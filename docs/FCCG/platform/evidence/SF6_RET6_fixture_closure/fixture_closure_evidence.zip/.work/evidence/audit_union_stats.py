from pathlib import Path
import json,sys,hashlib
root=Path.cwd();sys.path.insert(0,str(root/'apps/FLP/src'))
from silverstar_flp.log_open import LogOpenCoordinator,LogOpenRequest
from silverstar_flp.decoder_profiles.discovery import DecoderProfileCache
from silverstar_flp.plugins.registry import builtin_registry
from silverstar_flp.plugins.api.algorithm import ReplayRequest
label=sys.argv[1];out=root/'.work/evidence';reg=builtin_registry();c=LogOpenCoordinator(reg,DecoderProfileCache(out/'flp_reopen/cache'));p=root/'.work/generated_ret6';decoder=next(p.glob('*.ssdecoder'));results=[]
for f in sorted((p/'build/FCCG/Host/Tests/StorageIntegrity').glob('sf6-compact-*.sslog')):
 o=c.Open(LogOpenRequest(f,decoder));stats=o.dataset.records['STATS'];replay=reg.Algorithm_Get('silverstar.algorithm.sf6').run(o.dataset,ReplayRequest(input_source='recorded_inertial_increment'))
 row={'name':f.name,'log_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'decoder_sha256':hashlib.sha256(decoder.read_bytes()).hexdigest(),'match_mode':o.match_mode,'parse_diagnostics':o.parse_diagnostics.to_dict(),'warnings':list(replay.warnings),'fidelity':str(replay.fidelity),'missing_inputs':list(replay.missing_inputs),'channels':{k:len(v.timestamp_us) for k,v in replay.channels.items()},'stats':[{'timestamp_us':x.timestamp_us,**dict(x.payload)} for x in stats]}
 overload='overload' in f.name
 expected_stats=193 if overload else 194
 if label=='before':
  assert len(stats)==expected_stats
  assert all(x.payload['imu_queue_overflow_count']==x.timestamp_us-5000 and x.payload['ins_update_count']==x.timestamp_us for x in stats[:-1])
  assert 'source_log_has_integrity_or_sequence_gaps' in row['warnings']
 else:
  assert len(stats)==expected_stats and all(x.payload['imu_queue_overflow_count']==0 for x in stats)
  assert all(a.payload['ins_update_count']<b.payload['ins_update_count'] for a,b in zip(stats,stats[1:]))
  assert all(0<x.payload['ins_update_count']<=38788 for x in stats)
  assert stats[-1].payload['ins_update_count']==(38589 if overload else 38788)
  assert row['parse_diagnostics']['sequence_missing_count']==(444 if overload else 0)
  assert stats[-1].payload['logger_queue_overflow_count']==(444 if overload else 0)
  assert ('source_log_has_integrity_or_sequence_gaps' in row['warnings'])==overload
  health=o.dataset.records['HEALTH'];telemetry=o.dataset.records['TELEMETRY_DIAG']
  assert all(x.payload['ready']==1 and x.payload['warning_mask']==0 for x in health)
  assert all(all(v==0 for v in x.payload.values()) for x in telemetry)
  row['health_records']=len(health);row['telemetry_records']=len(telemetry)
 row['replay_diagnostics']=dict(replay.diagnostics)
 results.append(row);print(json.dumps({k:v for k,v in row.items() if k not in ('stats','parse_diagnostics','replay_diagnostics')},ensure_ascii=True),flush=True)
(out/f'union_stats_{label}.json').write_text(json.dumps(results,indent=2)+'\n')
assert len(results)==2
