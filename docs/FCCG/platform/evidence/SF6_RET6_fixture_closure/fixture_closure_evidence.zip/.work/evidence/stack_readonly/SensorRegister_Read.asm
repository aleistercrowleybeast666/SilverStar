
D:\python_software\SilverStar\.work\sf6_compact_ret6\.work\evidence\stack_readonly\source_1fcf9b2.elf:     file format elf32-littlearm


Disassembly of section .text:

08024f68 <SensorRegister_Read>:
 8024f68:	b198      	cbz	r0, 8024f92 <SensorRegister_Read+0x2a>
 8024f6a:	b530      	push	{r4, r5, lr}
 8024f6c:	6845      	ldr	r5, [r0, #4]
 8024f6e:	b083      	sub	sp, #12
 8024f70:	b165      	cbz	r5, 8024f8c <SensorRegister_Read+0x24>
 8024f72:	b15a      	cbz	r2, 8024f8c <SensorRegister_Read+0x24>
 8024f74:	f103 3cff 	add.w	ip, r3, #4294967295
 8024f78:	f1bc 0f3f 	cmp.w	ip, #63	@ 0x3f
 8024f7c:	d806      	bhi.n	8024f8c <SensorRegister_Read+0x24>
 8024f7e:	f44f 64fa 	mov.w	r4, #2000	@ 0x7d0
 8024f82:	6800      	ldr	r0, [r0, #0]
 8024f84:	9400      	str	r4, [sp, #0]
 8024f86:	47a8      	blx	r5
 8024f88:	b003      	add	sp, #12
 8024f8a:	bd30      	pop	{r4, r5, pc}
 8024f8c:	2001      	movs	r0, #1
 8024f8e:	b003      	add	sp, #12
 8024f90:	bd30      	pop	{r4, r5, pc}
 8024f92:	2001      	movs	r0, #1
 8024f94:	4770      	bx	lr
