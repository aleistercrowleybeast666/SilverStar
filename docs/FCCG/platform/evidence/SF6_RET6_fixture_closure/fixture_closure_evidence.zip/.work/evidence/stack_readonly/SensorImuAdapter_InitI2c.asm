
D:\python_software\SilverStar\.work\sf6_compact_ret6\.work\evidence\stack_readonly\source_1fcf9b2.elf:     file format elf32-littlearm


Disassembly of section .text:

08026318 <SensorImuAdapter_InitI2c>:
 8026318:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
 802631c:	b086      	sub	sp, #24
 802631e:	f8bd 8030 	ldrh.w	r8, [sp, #48]	@ 0x30
 8026322:	2800      	cmp	r0, #0
 8026324:	d046      	beq.n	80263b4 <SensorImuAdapter_InitI2c+0x9c>
 8026326:	460e      	mov	r6, r1
 8026328:	2900      	cmp	r1, #0
 802632a:	d043      	beq.n	80263b4 <SensorImuAdapter_InitI2c+0x9c>
 802632c:	2a02      	cmp	r2, #2
 802632e:	4615      	mov	r5, r2
 8026330:	d840      	bhi.n	80263b4 <SensorImuAdapter_InitI2c+0x9c>
 8026332:	2b02      	cmp	r3, #2
 8026334:	461f      	mov	r7, r3
 8026336:	d83d      	bhi.n	80263b4 <SensorImuAdapter_InitI2c+0x9c>
 8026338:	f1a8 0308 	sub.w	r3, r8, #8
 802633c:	2b6f      	cmp	r3, #111	@ 0x6f
 802633e:	d839      	bhi.n	80263b4 <SensorImuAdapter_InitI2c+0x9c>
 8026340:	234a      	movs	r3, #74	@ 0x4a
 8026342:	4604      	mov	r4, r0
 8026344:	2205      	movs	r2, #5
 8026346:	2108      	movs	r1, #8
 8026348:	9300      	str	r3, [sp, #0]
 802634a:	4b1d      	ldr	r3, [pc, #116]	@ (80263c0 <SensorImuAdapter_InitI2c+0xa8>)
 802634c:	f7df f9ba 	bl	80056c4 <SilverStarAssert_ObjectCheck>
 8026350:	f44f 7280 	mov.w	r2, #256	@ 0x100
 8026354:	2100      	movs	r1, #0
 8026356:	4620      	mov	r0, r4
 8026358:	f008 f85e 	bl	802e418 <memset>
 802635c:	f246 0360 	movw	r3, #24672	@ 0x6060
 8026360:	f8a4 3077 	strh.w	r3, [r4, #119]	@ 0x77
 8026364:	2300      	movs	r3, #0
 8026366:	4917      	ldr	r1, [pc, #92]	@ (80263c4 <SensorImuAdapter_InitI2c+0xac>)
 8026368:	f884 5070 	strb.w	r5, [r4, #112]	@ 0x70
 802636c:	4d16      	ldr	r5, [pc, #88]	@ (80263c8 <SensorImuAdapter_InitI2c+0xb0>)
 802636e:	9103      	str	r1, [sp, #12]
 8026370:	f88d 3014 	strb.w	r3, [sp, #20]
 8026374:	4632      	mov	r2, r6
 8026376:	4620      	mov	r0, r4
 8026378:	9b0d      	ldr	r3, [sp, #52]	@ 0x34
 802637a:	f884 7071 	strb.w	r7, [r4, #113]	@ 0x71
 802637e:	f8a4 8072 	strh.w	r8, [r4, #114]	@ 0x72
 8026382:	a902      	add	r1, sp, #8
 8026384:	9504      	str	r5, [sp, #16]
 8026386:	9402      	str	r4, [sp, #8]
 8026388:	f7ff f86a 	bl	8025460 <SensorImu_Init>
 802638c:	4605      	mov	r5, r0
 802638e:	b988      	cbnz	r0, 80263b4 <SensorImuAdapter_InitI2c+0x9c>
 8026390:	f7f2 fa58 	bl	8018844 <PlatformTime_Us>
 8026394:	460b      	mov	r3, r1
 8026396:	2101      	movs	r1, #1
 8026398:	4602      	mov	r2, r0
 802639a:	9100      	str	r1, [sp, #0]
 802639c:	4620      	mov	r0, r4
 802639e:	f7ff f96d 	bl	802567c <SensorImu_BeginConfigure>
 80263a2:	2801      	cmp	r0, #1
 80263a4:	bf14      	ite	ne
 80263a6:	2508      	movne	r5, #8
 80263a8:	f884 00fc 	strbeq.w	r0, [r4, #252]	@ 0xfc
 80263ac:	4628      	mov	r0, r5
 80263ae:	b006      	add	sp, #24
 80263b0:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
 80263b4:	2505      	movs	r5, #5
 80263b6:	4628      	mov	r0, r5
 80263b8:	b006      	add	sp, #24
 80263ba:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
 80263be:	bf00      	nop
 80263c0:	0803389c 	.word	0x0803389c
 80263c4:	0802623d 	.word	0x0802623d
 80263c8:	080262c9 	.word	0x080262c9
