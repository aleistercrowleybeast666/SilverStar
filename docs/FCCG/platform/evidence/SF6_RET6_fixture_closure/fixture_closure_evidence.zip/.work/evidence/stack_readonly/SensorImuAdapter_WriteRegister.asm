
D:\python_software\SilverStar\.work\sf6_compact_ret6\.work\evidence\stack_readonly\source_1fcf9b2.elf:     file format elf32-littlearm


Disassembly of section .text:

080262c8 <SensorImuAdapter_WriteRegister>:
 80262c8:	b320      	cbz	r0, 8026314 <SensorImuAdapter_WriteRegister+0x4c>
 80262ca:	b510      	push	{r4, lr}
 80262cc:	b084      	sub	sp, #16
 80262ce:	468c      	mov	ip, r1
 80262d0:	9906      	ldr	r1, [sp, #24]
 80262d2:	f5b1 6ffa 	cmp.w	r1, #2000	@ 0x7d0
 80262d6:	d002      	beq.n	80262de <SensorImuAdapter_WriteRegister+0x16>
 80262d8:	2001      	movs	r0, #1
 80262da:	b004      	add	sp, #16
 80262dc:	bd10      	pop	{r4, pc}
 80262de:	6901      	ldr	r1, [r0, #16]
 80262e0:	2900      	cmp	r1, #0
 80262e2:	d0f9      	beq.n	80262d8 <SensorImuAdapter_WriteRegister+0x10>
 80262e4:	2402      	movs	r4, #2
 80262e6:	f41c 7f80 	tst.w	ip, #256	@ 0x100
 80262ea:	bf0d      	iteet	eq
 80262ec:	f8b0 1072 	ldrheq.w	r1, [r0, #114]	@ 0x72
 80262f0:	7989      	ldrbne	r1, [r1, #6]
 80262f2:	f890 0071 	ldrbne.w	r0, [r0, #113]	@ 0x71
 80262f6:	f890 0070 	ldrbeq.w	r0, [r0, #112]	@ 0x70
 80262fa:	9301      	str	r3, [sp, #4]
 80262fc:	9200      	str	r2, [sp, #0]
 80262fe:	2300      	movs	r3, #0
 8026300:	fa5f f28c 	uxtb.w	r2, ip
 8026304:	9402      	str	r4, [sp, #8]
 8026306:	f7f2 fb29 	bl	801895c <PlatformI2c_MemoryWrite>
 802630a:	2800      	cmp	r0, #0
 802630c:	bf18      	it	ne
 802630e:	2003      	movne	r0, #3
 8026310:	b004      	add	sp, #16
 8026312:	bd10      	pop	{r4, pc}
 8026314:	2001      	movs	r0, #1
 8026316:	4770      	bx	lr
