
D:\python_software\SilverStar\.work\sf6_compact_ret6\.work\evidence\stack_readonly\source_1fcf9b2.elf:     file format elf32-littlearm


Disassembly of section .text:

0802623c <SensorImuAdapter_ReadRegister>:
 802623c:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
 8026240:	b096      	sub	sp, #88	@ 0x58
 8026242:	b120      	cbz	r0, 802624e <SensorImuAdapter_ReadRegister+0x12>
 8026244:	461d      	mov	r5, r3
 8026246:	9b1c      	ldr	r3, [sp, #112]	@ 0x70
 8026248:	f5b3 6ffa 	cmp.w	r3, #2000	@ 0x7d0
 802624c:	d004      	beq.n	8026258 <SensorImuAdapter_ReadRegister+0x1c>
 802624e:	2401      	movs	r4, #1
 8026250:	4620      	mov	r0, r4
 8026252:	b016      	add	sp, #88	@ 0x58
 8026254:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
 8026258:	2318      	movs	r3, #24
 802625a:	4604      	mov	r4, r0
 802625c:	9300      	str	r3, [sp, #0]
 802625e:	460e      	mov	r6, r1
 8026260:	4b18      	ldr	r3, [pc, #96]	@ (80262c4 <SensorImuAdapter_ReadRegister+0x88>)
 8026262:	4617      	mov	r7, r2
 8026264:	2108      	movs	r1, #8
 8026266:	2205      	movs	r2, #5
 8026268:	f7df fa2c 	bl	80056c4 <SilverStarAssert_ObjectCheck>
 802626c:	6923      	ldr	r3, [r4, #16]
 802626e:	2b00      	cmp	r3, #0
 8026270:	d0ed      	beq.n	802624e <SensorImuAdapter_ReadRegister+0x12>
 8026272:	2d40      	cmp	r5, #64	@ 0x40
 8026274:	d8eb      	bhi.n	802624e <SensorImuAdapter_ReadRegister+0x12>
 8026276:	f893 8005 	ldrb.w	r8, [r3, #5]
 802627a:	f1b8 0f02 	cmp.w	r8, #2
 802627e:	d8e6      	bhi.n	802624e <SensorImuAdapter_ReadRegister+0x12>
 8026280:	05f2      	lsls	r2, r6, #23
 8026282:	bf48      	it	mi
 8026284:	7999      	ldrbmi	r1, [r3, #6]
 8026286:	f04f 0302 	mov.w	r3, #2
 802628a:	bf4e      	itee	mi
 802628c:	f894 0071 	ldrbmi.w	r0, [r4, #113]	@ 0x71
 8026290:	f8b4 1072 	ldrhpl.w	r1, [r4, #114]	@ 0x72
 8026294:	f894 0070 	ldrbpl.w	r0, [r4, #112]	@ 0x70
 8026298:	9302      	str	r3, [sp, #8]
 802629a:	eb08 0305 	add.w	r3, r8, r5
 802629e:	b2f2      	uxtb	r2, r6
 80262a0:	b29b      	uxth	r3, r3
 80262a2:	ae05      	add	r6, sp, #20
 80262a4:	9301      	str	r3, [sp, #4]
 80262a6:	9600      	str	r6, [sp, #0]
 80262a8:	2300      	movs	r3, #0
 80262aa:	f7f2 fb8b 	bl	80189c4 <PlatformI2c_MemoryRead>
 80262ae:	4604      	mov	r4, r0
 80262b0:	b108      	cbz	r0, 80262b6 <SensorImuAdapter_ReadRegister+0x7a>
 80262b2:	2403      	movs	r4, #3
 80262b4:	e7cc      	b.n	8026250 <SensorImuAdapter_ReadRegister+0x14>
 80262b6:	462a      	mov	r2, r5
 80262b8:	4638      	mov	r0, r7
 80262ba:	eb06 0108 	add.w	r1, r6, r8
 80262be:	f008 f8d7 	bl	802e470 <memcpy>
 80262c2:	e7c5      	b.n	8026250 <SensorImuAdapter_ReadRegister+0x14>
 80262c4:	0803389c 	.word	0x0803389c
