from pathlib import Path
import json,hashlib
from silverstar_fccg.hardware.cubemx import CubeMxImporter
from silverstar_fccg.core.workspace import WorkspacePolicy
r=Path.cwd();i=CubeMxImporter(WorkspacePolicy(r/'.work'));sid=json.loads((r/'.work/generated_ret6/SilverStar.ssproject').read_bytes())['hardware']['snapshot_id'];c=r/'.work/cubemx_flight/SF6_RET6_Hardware';s=r/'.work/.fccg/hardware_imports'/sid/'STM32CubeMX'
cf=i._SourceFiles_Get(c);sf=i._SourceFiles_Get(s);cp={x.relative_to(c).as_posix():x for x in cf};sp={x.relative_to(s).as_posix():x for x in sf}
missing=sorted(set(cp)-set(sp));added=sorted(set(sp)-set(cp));changed=[k for k in cp.keys()&sp.keys() if cp[k].read_bytes()!=sp[k].read_bytes()]
rep={'status':'READ_ONLY_DIAGNOSTIC','declared':sid,'original_count':len(cf),'original_digest':i._SnapshotDigest_Get(c,cf),'snapshot_count':len(sf),'snapshot_digest':i._SnapshotDigest_Get(s,sf),'snapshot_without_importer_README_digest':i._SnapshotDigest_Get(s,tuple(x for x in sf if x.relative_to(s).as_posix()!='README.md')),'missing_paths':missing,'added_paths':added,'changed_paths':changed,'changed':[{'path':k,'original_sha256':hashlib.sha256(cp[k].read_bytes()).hexdigest(),'snapshot_sha256':hashlib.sha256(sp[k].read_bytes()).hexdigest()} for k in changed]}
(r/'.work/evidence/current_snapshot_digest_readonly.json').write_text(json.dumps(rep,indent=2)+'\n');print(json.dumps(rep,indent=2))
