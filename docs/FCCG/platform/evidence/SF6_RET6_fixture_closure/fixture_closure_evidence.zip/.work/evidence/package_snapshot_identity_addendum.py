from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json,hashlib
r=Path.cwd();e=r/'.work/evidence';proof=json.loads((e/'snapshot_canonical_identity_proof.json').read_text());sid=proof['source_id'];names=[x['path'] for x in proof['files'] if not x['normal_is_file']]
assert len(names)==2;zpath=e/'SilverStar_SF6_RET6_SNAPSHOT_CANONICAL_IDENTITY_ADDENDUM.zip';files={}
for n in names:
 rel=f'.work/.fccg/hardware_imports/{sid}/STM32CubeMX/{n}';p=Path('\\\\?\\'+str(r/rel));files[rel]=p.read_bytes()
for n in ('snapshot_canonical_identity_proof.json','current_snapshot_digest_readonly.json','ret6_snapshot_long_path_probe.log','ret6_snapshot_canonical_identity_proof.log','prove_snapshot_canonical_identity.py','audit_snapshot_digest.py'):
 files['evidence/'+n]=(e/n).read_bytes()
manifest={'snapshot_id':sid,'status':'CANONICAL_IDENTITY_PROVEN','instructions':'Apply two actual existing files at archive paths in original snapshot package. Canonical source input list in proof has 920 entries; post-import README excluded. Hash per path then hash path UTF-8 + NUL + SHA256 binary in exact listed order, using original importer. Two absent prior archive paths are 268/261 absolute Windows characters. No actual snapshot files were missing or mutated.','files':[{'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in sorted(files.items())]}
with ZipFile(zpath,'w',ZIP_DEFLATED,compresslevel=6) as z:
 for n,b in files.items():z.writestr(n,b)
 z.writestr('MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
with ZipFile(zpath) as z:
 for x in manifest['files']:assert hashlib.sha256(z.read(x['path'])).hexdigest()==x['sha256']
result={'path':str(zpath),'bytes':zpath.stat().st_size,'sha256':hashlib.sha256(zpath.read_bytes()).hexdigest(),'snapshot_id':sid};(e/'snapshot_identity_addendum_package.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
