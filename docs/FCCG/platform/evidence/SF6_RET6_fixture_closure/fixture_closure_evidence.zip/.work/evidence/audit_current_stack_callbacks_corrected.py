from pathlib import Path
from zipfile import ZipFile
import subprocess,json,hashlib,re
r=Path.cwd();p=r/'.work/generated_ret6';e=r/'.work/evidence';a=e/'stack_readonly';a.mkdir(exist_ok=True);zpath=r/'docs/FCCG/platform/evidence/SF6_RET6_software_fix/software_fix_evidence.zip'
with ZipFile(zpath) as z:
 n='artifacts/SilverStar_F103RE/Release/SilverStar_0_1_1.elf';elf=a/'source_1fcf9b2.elf';elf.write_bytes(z.read(n));old=json.loads(z.read('.work/evidence/ret6_combined_final_generated_source_identity.json'));linked=z.read('.work/evidence/ret6_combined_final_linked_source_list.log').decode('utf-8-sig').splitlines()
 sources=[x.strip().removeprefix('Assembly: ') for x in linked if x.strip().endswith(('.c','.s'))];known={x['path']:x['generated_sha256'] for x in old['records']};mismatch=[n for n in sources if hashlib.sha256((p/n).read_bytes()).hexdigest()!=known[n]];assert not mismatch
nm=subprocess.check_output(['D:/Arm GNU Toolchain/14.3 rel1/bin/arm-none-eabi-nm.exe','-a',str(elf)],text=True);(a/'nm.txt').write_text(nm)
names=('SensorRegister_Read','SensorRegister_Write','SensorImuAdapter_ReadRegister','SensorImuAdapter_WriteRegister','SensorImuSpi_Read','SensorImuSpi_Write','SensorImuAdapter_InitI2c','SensorImuAdapter_InitSpi')
dis={n:subprocess.check_output(['D:/Arm GNU Toolchain/14.3 rel1/bin/arm-none-eabi-objdump.exe','-d','--disassemble='+n,str(elf)],text=True) for n in names if re.search(r'\b'+n+r'$',nm,re.M)}
for n,s in dis.items():(a/(n+'.asm')).write_text(s)
paths=('Devices/SensorBus/Src/sensor_register_bus.c','Devices/SensorBus/Src/sensor_imu.c','Devices/SensorBus/Adapter/Src/sensor_imu_adapter.c','Devices/SensorBus/Adapter/Src/sensor_imu_spi_adapter.c','Devices/IMU/MPU6050/Adapter/Src/mpu6050_instance.c','Tools/check_task_stacks.py');audit=[]
for n in paths:
 data=(p/n).read_bytes();lines=data.decode().splitlines();terms=r'bus\.read\s*=|bus\.write\s*=|bus->read|bus->write|imu->bus\s*=|InitI2c|InitSpi|SensorImuAdapter_Create|indirect.add|name in indirect|Unresolved stack usage'
 audit.append({'path':n,'sha256':hashlib.sha256(data).hexdigest(),'lines':[{'line':i+1,'text':s} for i,s in enumerate(lines) if re.search(terms,s)]})
report={'status':'NOT_PROVEN','ELF_source_commit':'1fcf9b20fb5250f27367cf6b71e493d197185f45','current_fixture_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'ELF_sha256':hashlib.sha256(elf.read_bytes()).hexdigest(),'current_generated_linked_sources_byte_identical_to_prior_ELF_inputs':len(sources),'mismatches':mismatch,'source_possible_callees':{'SensorRegister_Read':['SensorImuAdapter_ReadRegister','SensorImuSpi_Read'],'SensorRegister_Write':['SensorImuAdapter_WriteRegister','SensorImuSpi_Write']},'present_symbols':{n:n in dis for n in names},'selected_MPU6050_route':'Mpu6050Instance_Init -> SensorImuAdapter_InitI2c -> SensorImu_Init copies bus into driver; generated selected IMU is I2C. SPI constructors/callbacks are present in generated source but absent from actual linked ELF.','resolver_limit':'Disassembly register bx/blx has no symbol operand; gate detects indirect use but only resolves named FatFs and immutable startup tables, no SensorRegisterBus points-to model. Non-null guards do not establish callback identity, lifecycle invariance, caller ownership or nesting. No gate changes, numeric upper bound or complete call-graph/stack proof introduced.','files':audit}
(e/'fixture_closure_stack_callback_review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='files'},indent=2))

