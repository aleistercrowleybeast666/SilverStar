from pathlib import Path
import json,subprocess,hashlib,zipfile
root=Path.cwd();source='3188bfb33a5e52c2a1d0e5baa7c5ce2b5e5af6a9';baseline='543e673e4aa8be390061ff6a1665728fe204a853'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
e=root/'.work/evidence';g=e/'mpu_ret6_device_contract_gates';project=root/'.work/generated_ret6'
d=root/'docs/FCCG/platform/evidence/SF6_RET6_mpu_build_mode_contract';d.mkdir(parents=True,exist_ok=True)
files={};sha=lambda b:hashlib.sha256(b).hexdigest()
def add(name,path):files[name]=Path(path).read_bytes()
changed=subprocess.check_output(['git','diff','--name-only',baseline,source,'--','apps/SCG'],text=True).splitlines()
for path in changed:
 if (root/path).is_file():add('source/'+path,root/path)
 files['baseline/'+path]=subprocess.check_output(['git','show',baseline+':'+path])
files['source/change.patch']=subprocess.check_output(['git','diff','--binary',baseline,source,'--','apps/SCG'])
add('review/SF6_RET6_MPU_BUILD_MODE_CONTRACT.md',root/'docs/FCCG/platform/details/SF6_RET6_MPU_BUILD_MODE_CONTRACT.md')
for p in g.iterdir():
 if p.is_file():add('final_gates/'+p.name,p)
for p in (e/'mpu_device_contract_ordinary').iterdir():
 if p.is_file():add('ordinary/'+p.name,p)
for label in ('mpu_device_contract_post','mpu_device_contract_generator'):
 for p in (root/'.work'/label).rglob('*'):
  if p.is_file() and p.suffix in ('.json','.txt','.c','.h'):add('native/'+label+'/'+p.relative_to(root/'.work'/label).as_posix(),p)
for p in e.iterdir():
 if p.is_file() and p.suffix=='.log' and not p.name.startswith('package_') and ('device_contract' in p.name or 'device_build_contract' in p.name):add('logs/'+p.name,p)
for name in ('refresh_mpu_validation_device_contract.py','run_mpu_ret6_device_contract_gates.py','verify_mpu_device_contract_source.py',
 'mpu_map_device_contract.py','audit_mpu_device_contract_boundaries.py','compare_mpu_device_contract_ordinary.py',
 'compare_mpu_device_contract_arm_ordinary.py','audit_mpu_device_build_contract.py','package_mpu_device_contract.py'):
 add('commands/'+name,e/name)
for name in ('mpu_validation_refresh_contract.json','mpu_validation_refresh_device_contract.json','mpu_contract_old_common_header.raw'):
 add('generation/'+name,e/name)
for name in ('results.json','architecture.log','generated_source_identity.json','map_resources.json'):
 add('intermediate_failed_architecture/'+name,e/'mpu_ret6_contract_gates'/name)
files['intermediate_failed_architecture/change.patch']=subprocess.check_output(['git','diff','--binary',baseline,'43bc86893de019d1a034e4bcf6ed28fe1babb387','--','apps/SCG'])
for label,path in (('Release',project/'build/FCCG/SilverStar_F103RE/Release'),('StaticAnalysis',project/'build/FCCG/SilverStar_F103RE/StaticAnalysis/Release')):
 for ext in ('.elf','.map','.bin'):add('artifacts/'+label+'/SilverStar_0_1_1'+ext,path/('SilverStar_0_1_1'+ext))
 for p in path.rglob('*.su'):
  if p.stem in ('mpu6050_instance','system_source_selector','system_startup','sensor_imu'):
   add('changed_or_unresolved_frames/'+label+'/'+p.relative_to(path).as_posix(),p)
for path in ('SilverStar.ssproject','Generated/Inc/project_device_build_capabilities.h','Generated/Inc/project_device_instances.h',
 'Generated/Inc/project_flight_config.h','Generated/project_sources.mk','Tools/check_power_of_ten.ps1','Tools/check_architecture.ps1','Tools/check_task_stacks.py'):
 add('generated/'+path,project/path)
results=json.loads((g/'results.json').read_text());identity=json.loads((g/'generated_source_identity.json').read_text())
assert len(results)==8 and all(r['source_commit']==source for r in results)
assert not identity['mismatches'] and identity['linked_sources_count']==144 and not identity['linked_sources_without_current_byte_comparison']
assert {r['name']:r['exit'] for r in results}=={'arm':0,'analyzer':0,'architecture':0,'power10':0,'artifact':0,'stack':2,'official_host':2,'linked_sources':0}
versions={}
for name,argv in {'arm_gcc':['D:/Arm GNU Toolchain/14.3 rel1/bin/arm-none-eabi-gcc.exe','--version'],
 'host_gcc':['D:/msys64/ucrt64/bin/gcc.exe','--version'],'make':['D:/msys64/ucrt64/bin/mingw32-make.exe','--version'],
 'python':['D:/python_software/SilverStar/apps/FLP/.venv/Scripts/python.exe','--version'],
 'powershell':['powershell','-NoProfile','-Command','$PSVersionTable.PSVersion.ToString()']}.items():
 r=subprocess.run(argv,capture_output=True,text=True);versions[name]={'argv':argv,'exit':r.returncode,'output':r.stdout+r.stderr}
files['tool_versions.json']=json.dumps(versions,indent=2).encode()
summary={'source_commit':source,'review_base_commit':baseline,'changed_source_paths':changed,
 'gate_exits':{r['name']:r['exit'] for r in results},'focused_pytest_items':4,'compact_sequences':14,'ordinary_sequences':3,'generation_pytest':14,
 'configuration_negative':'Actual independent MPU missing device build contract compiler exit1, expected; see full argv/log.',
 'checker_changes':False,'expanded_generated_path_set':False,'new_flag_selection_conditionals':0,
 'resources':json.loads((g/'map_resources.json').read_text()),'source_identity_records':identity['checked_files'],'linked_source_inputs':144,
 'source_identity_dirty_status':identity['git_dirty'],'dirty_boundary':'Only the new untracked review prose at identity capture; all compiled source tracked at source_commit and byte-verified.',
 'prior_A_library_file_id':'libfile_0a3f24a1993881918e57740cef242867','prior_A_version':1,'prior_A_archive_sha256':'f19dd88885b024ed9bcba75ccf1165eb43e3671dbbcace859ddc6f034e6c31ef',
 'intermediate':'43bc868 architecture FAIL retained; interim binaries overwritten by own subsequent validation build, historical map/hashes retained without current binary identity claim.',
 'qualification':'No READY/readmission clear or B implementation; revoked qualification remains sticky.',
 'acceptance':'BLOCKED: stack/full Host FAIL; critical contracts, full call paths/MSP/ISR/IRQ/RF timing, hardware and B NOT PROVEN; 20% RAM gap remains.',
 'scope':'No hardware/serial/probe/flashing, stable/GSHC/FLP/ordinary GUI/NRF changes, checker/path expansion, merge/push.'}
files['summary.json']=json.dumps(summary,indent=2).encode();(d/'summary.json').write_bytes(files['summary.json'])
manifest={'source_commit':source,'files':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())]}
files['manifest.json']=json.dumps(manifest,indent=2).encode();(d/'manifest.json').write_bytes(files['manifest.json'])
archive=d/'mpu_build_mode_contract_increment.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(files.items()):z.writestr(n,b)
with zipfile.ZipFile(archive) as z:
 for row in manifest['files']:assert sha(z.read(row['path']))==row['sha256']
digest=sha(archive.read_bytes());(d/'mpu_build_mode_contract_increment.sha256').write_text(digest+'  '+archive.name+'\n')
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':digest,'verified_files':len(manifest['files']),'source_commit':source}))
