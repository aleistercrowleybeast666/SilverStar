from pathlib import Path
import json,hashlib,subprocess,re,os
from dataclasses import replace
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.project.model import ProjectModel_Load
from silverstar_fccg.generator.render import _DeviceBuildCapabilitiesHeader_Render
root=Path.cwd();e=root/'.work/evidence/mpu_ret6_device_contract_gates';sha=lambda b:hashlib.sha256(b).hexdigest()
service=FccgService(root/'apps/SCG');model=ProjectModel_Load(root/'.work/generated_ret6/SilverStar.ssproject');catalog=service.catalog.ProjectView_Get(model)
records=[]
for compact,label in ((False,'test_ordinary_mpu_behavior_unc0'),(True,'test_compact_mpu_fault_sequenc0')):
 model.build=replace(model.build,compact_mode=compact)
 p=root/'.work/mpu_device_contract_post'/label/'project_device_build_capabilities.h';actual=p.read_bytes();expected=_DeviceBuildCapabilitiesHeader_Render(model,catalog).encode()
 assert actual==expected.replace(b'\n',os.linesep.encode())
 compiler=json.loads((p.parent/'compile.json').read_text());assert compiler['build_mode']['compact_mode']==compact and compiler['build_mode']['header_sha256']==sha(actual)
 lines=[line for line in actual.decode().splitlines() if 'SILVERSTAR_BUILD_COMPACT_ENABLED' in line]
 assert lines==[f'#define SILVERSTAR_BUILD_COMPACT_ENABLED {int(compact)}U']
 assert '#include' not in actual.decode()
 records.append({'compact_mode':compact,'path':p.relative_to(root).as_posix(),'actual_sha256':sha(actual),'raw_header':actual.decode(),
  'caller_text_io_eol':repr(os.linesep),'flag_associated_directives':lines,'flag_selection_conditionals':0,'no_app_or_other_includes':True})
model.build=replace(model.build,compact_mode=True)
target=root/'.work/generated_ret6/Generated/Inc/project_device_build_capabilities.h';assert target.read_bytes()==_DeviceBuildCapabilitiesHeader_Render(model,catalog).encode()
prior=json.loads((root/'.work/evidence/mpu_ret6_stage_a_gates/generated_source_identity.json').read_text())
prior_cap=next(r['generated_sha256'] for r in prior['records'] if r['path']=='Generated/Inc/project_device_build_capabilities.h')
without_flag=re.sub(br'^#define SILVERSTAR_BUILD_COMPACT_ENABLED 1U\n',b'',target.read_bytes(),flags=re.M)
assert sha(without_flag)==prior_cap
assert not (root/'.work/generated_ret6/Generated/Inc/project_build_mode.h').exists()
assert not (root/'.work/generated_ret6/Common/Inc/silverstar_build_mode.h').exists()
assert not (root/'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Common/Inc/silverstar_build_mode.h').exists()
missing=root/'.work/mpu_device_contract_post/test_joint_sensor_adapters_com0/missing_build_mode.json';failure=json.loads(missing.read_text());assert failure['exit']==1 and 'fatal error: project_device_build_capabilities.h: No such file' in failure['stderr']
report={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'records':records,
 'actual_generated_target_sha256':sha(target.read_bytes()),'old_mode_selection_header_absent':True,'no_new_generated_path':True,
 'remaining_capability_header_byte_equal_A_after_removing_only_new_numeric_line':True,'prior_capability_header_sha256':prior_cap,
 'new_flag_selection_conditional_count':0,'containing_header_existing_conditions':'Unchanged existing capability defaults/guard; no claim of all-header Rule8 compliance.',
 'missing_contract_compiler_exit':failure['exit'],'missing_contract_evidence_sha256':sha(missing.read_bytes()),
 'manual_rule8_scope':'Unconditional scalar numeric macro in existing Generated device capability contract; selected by BuildOptions before target compilation. No inferred default, APP dependency, checker change or expanded path set. Not overall compliance.'}
(e/'build_mode_contract_audit.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='records'},indent=2))
