from pathlib import Path
import subprocess,json,shlex,hashlib
root=Path.cwd();e=root/'.work/evidence/mpu_device_contract_ordinary';project=root/'.work/generated_ret6'
lines=(root/'.work/evidence/mpu_ret6_device_contract_gates/arm.log').read_text().splitlines()
line=next(l for l in lines if l.startswith('"D:/Arm GNU') and ' -c ' in l and ' -std=c11 ' in l and ' -Wstrict-prototypes ' in l)
args=shlex.split(line);prefix=args[:-3]
prefix=[x for x in prefix if x not in ('-MMD','-MP','-DSILVERSTAR_COMPACT_MODE=1','-O2') and not x.startswith('-MF')]
prefix[prefix.index('Generated/Inc/project_flight_config.h')]=str(root/'.work/mpu_device_contract_post/test_ordinary_mpu_behavior_unc0/project_flight_config.h')
prefix.insert(1,'-I'+str(root/'.work/mpu_device_contract_post/test_ordinary_mpu_behavior_unc0'))
names={'mpu6050_instance.c':root/'apps/SCG/plugins/builtin/silverstar_device_imu_mpu6050/payload/Devices/IMU/MPU6050/Adapter/Src/mpu6050_instance.c',
 'system_source_selector.c':root/'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/System/Src/system_source_selector.c'}
rows=[]
for name,current in names.items():
 for opt in ('-O2','-Og'):
  pair=[]
  for label,source in (('before',e/('baseline_'+name)),('after',current)):
   obj=e/(Path(name).stem+'_arm_'+opt[1:]+'_'+label+'.o');argv=prefix+[opt,str(source),'-o',str(obj)]
   r=subprocess.run(argv,cwd=project,capture_output=True,text=True,timeout=60)
   row={'source':name,'label':label,'optimization':opt,'argv':argv,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
   if r.returncode==0:
    nm=subprocess.check_output(['D:/Arm GNU Toolchain/14.3 rel1/bin/arm-none-eabi-nm.exe','-S','--size-sort',str(obj)],text=True)
    obj.with_suffix('.nm').write_text(nm)
    row['bss_symbols']={parts[3]:int(parts[1],16) for l in nm.splitlines() if len(parts:=l.split())==4 and parts[2].lower()=='b'}
    row['bss_bytes']=sum(row['bss_symbols'].values());row['object_sha256']=hashlib.sha256(obj.read_bytes()).hexdigest()
   rows.append(row);pair.append(row)
  (e/'arm_report.json').write_text(json.dumps({'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
   'boundary':'CM3 softfloat actual ordinary MPU and selector O2/Og objects; no ordinary full-image/link or hardware claim','rows':rows},indent=2))
  assert all(x['exit']==0 for x in pair),pair
  assert pair[0]['bss_symbols']==pair[1]['bss_symbols'],pair
print(json.dumps([{k:v for k,v in r.items() if k not in ('argv','stdout','stderr')} for r in rows],indent=2))
