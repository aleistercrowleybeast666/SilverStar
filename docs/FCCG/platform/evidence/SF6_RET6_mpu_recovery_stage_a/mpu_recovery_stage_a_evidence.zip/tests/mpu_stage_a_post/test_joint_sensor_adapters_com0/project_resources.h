#ifndef __PROJECT_RESOURCES_H
#define __PROJECT_RESOURCES_H
#include "system_device_types.h"
#include "platform_i2c.h"
#include "platform_uart.h"
#include "platform_time.h"
#include "platform_spi.h"
#include "platform_gpio.h"
#define PROJECT_MPU6000_INSTANCE_COUNT 2U
typedef struct { PlatformI2cId i2c; PlatformTimeId time; int8_t axis_map[3]; } ProjectMpu6000Resources;
SystemDeviceResult ProjectMpu6000Resources_Get(uint8_t instance, ProjectMpu6000Resources *resources);
#define PROJECT_MPU6050_INSTANCE_COUNT 2U
typedef struct { PlatformI2cId i2c; PlatformTimeId time; int8_t axis_map[3]; } ProjectMpu6050Resources;
SystemDeviceResult ProjectMpu6050Resources_Get(uint8_t instance, ProjectMpu6050Resources *resources);
#define PROJECT_MPU6500_INSTANCE_COUNT 2U
typedef struct { PlatformI2cId i2c; PlatformTimeId time; int8_t axis_map[3]; } ProjectMpu6500Resources;
SystemDeviceResult ProjectMpu6500Resources_Get(uint8_t instance, ProjectMpu6500Resources *resources);
#define PROJECT_MPU9250_INSTANCE_COUNT 2U
typedef struct { PlatformI2cId i2c; PlatformTimeId time; int8_t axis_map[3]; } ProjectMpu9250Resources;
SystemDeviceResult ProjectMpu9250Resources_Get(uint8_t instance, ProjectMpu9250Resources *resources);
#define PROJECT_LSM6DSV32X_INSTANCE_COUNT 2U
typedef struct { PlatformI2cId i2c; PlatformTimeId time; int8_t axis_map[3]; } ProjectLsm6Dsv32XResources;
SystemDeviceResult ProjectLsm6Dsv32XResources_Get(uint8_t instance, ProjectLsm6Dsv32XResources *resources);
#define PROJECT_LSM6DSV320X_INSTANCE_COUNT 2U
typedef struct { PlatformI2cId i2c; PlatformTimeId time; int8_t axis_map[3]; } ProjectLsm6Dsv320XResources;
SystemDeviceResult ProjectLsm6Dsv320XResources_Get(uint8_t instance, ProjectLsm6Dsv320XResources *resources);
#define PROJECT_ICM42605_INSTANCE_COUNT 2U
typedef struct { PlatformI2cId i2c; PlatformTimeId time; int8_t axis_map[3]; } ProjectIcm42605Resources;
SystemDeviceResult ProjectIcm42605Resources_Get(uint8_t instance, ProjectIcm42605Resources *resources);
#define PROJECT_ICM42688P_INSTANCE_COUNT 2U
typedef struct { PlatformI2cId i2c; PlatformTimeId time; int8_t axis_map[3]; } ProjectIcm42688PResources;
SystemDeviceResult ProjectIcm42688PResources_Get(uint8_t instance, ProjectIcm42688PResources *resources);
#define PROJECT_BMI088_INSTANCE_COUNT 2U
typedef struct { PlatformI2cId i2c; PlatformI2cId gyro_i2c; PlatformTimeId time; int8_t axis_map[3]; } ProjectBmi088Resources;
SystemDeviceResult ProjectBmi088Resources_Get(uint8_t instance, ProjectBmi088Resources *resources);
#define PROJECT_BMI323_INSTANCE_COUNT 2U
typedef struct { PlatformI2cId i2c; PlatformTimeId time; int8_t axis_map[3]; } ProjectBmi323Resources;
SystemDeviceResult ProjectBmi323Resources_Get(uint8_t instance, ProjectBmi323Resources *resources);
#define PROJECT_ICM45686_INSTANCE_COUNT 2U
typedef struct { PlatformI2cId i2c; PlatformTimeId time; int8_t axis_map[3]; } ProjectIcm45686Resources;
SystemDeviceResult ProjectIcm45686Resources_Get(uint8_t instance, ProjectIcm45686Resources *resources);
#define PROJECT_MPU6000_SPI_INSTANCE_COUNT 2U
typedef struct { PlatformSpiId spi; PlatformGpioId cs; PlatformGpioId drdy; PlatformTimeId time; int8_t axis_map[3]; } ProjectMpu6000SpiResources;
SystemDeviceResult ProjectMpu6000SpiResources_Get(uint8_t instance, ProjectMpu6000SpiResources *resources);
#define PROJECT_MPU6500_SPI_INSTANCE_COUNT 2U
typedef struct { PlatformSpiId spi; PlatformGpioId cs; PlatformGpioId drdy; PlatformTimeId time; int8_t axis_map[3]; } ProjectMpu6500SpiResources;
SystemDeviceResult ProjectMpu6500SpiResources_Get(uint8_t instance, ProjectMpu6500SpiResources *resources);
#define PROJECT_MPU9250_SPI_INSTANCE_COUNT 2U
typedef struct { PlatformSpiId spi; PlatformGpioId cs; PlatformGpioId drdy; PlatformTimeId time; int8_t axis_map[3]; } ProjectMpu9250SpiResources;
SystemDeviceResult ProjectMpu9250SpiResources_Get(uint8_t instance, ProjectMpu9250SpiResources *resources);
#define PROJECT_LSM6DSV32X_SPI_INSTANCE_COUNT 2U
typedef struct { PlatformSpiId spi; PlatformGpioId cs; PlatformGpioId drdy; PlatformTimeId time; int8_t axis_map[3]; } ProjectLsm6Dsv32XSpiResources;
SystemDeviceResult ProjectLsm6Dsv32XSpiResources_Get(uint8_t instance, ProjectLsm6Dsv32XSpiResources *resources);
#define PROJECT_LSM6DSV320X_SPI_INSTANCE_COUNT 2U
typedef struct { PlatformSpiId spi; PlatformGpioId cs; PlatformGpioId drdy; PlatformTimeId time; int8_t axis_map[3]; } ProjectLsm6Dsv320XSpiResources;
SystemDeviceResult ProjectLsm6Dsv320XSpiResources_Get(uint8_t instance, ProjectLsm6Dsv320XSpiResources *resources);
#define PROJECT_ICM42605_SPI_INSTANCE_COUNT 2U
typedef struct { PlatformSpiId spi; PlatformGpioId cs; PlatformGpioId drdy; PlatformTimeId time; int8_t axis_map[3]; } ProjectIcm42605SpiResources;
SystemDeviceResult ProjectIcm42605SpiResources_Get(uint8_t instance, ProjectIcm42605SpiResources *resources);
#define PROJECT_ICM42688P_SPI_INSTANCE_COUNT 2U
typedef struct { PlatformSpiId spi; PlatformGpioId cs; PlatformGpioId drdy; PlatformTimeId time; int8_t axis_map[3]; } ProjectIcm42688PSpiResources;
SystemDeviceResult ProjectIcm42688PSpiResources_Get(uint8_t instance, ProjectIcm42688PSpiResources *resources);
#define PROJECT_BMI088_SPI_INSTANCE_COUNT 2U
typedef struct { PlatformSpiId spi; PlatformGpioId cs; PlatformGpioId drdy; PlatformTimeId time; PlatformGpioId auxiliary_cs; PlatformGpioId auxiliary_drdy; int8_t axis_map[3]; } ProjectBmi088SpiResources;
SystemDeviceResult ProjectBmi088SpiResources_Get(uint8_t instance, ProjectBmi088SpiResources *resources);
#define PROJECT_BMI323_SPI_INSTANCE_COUNT 2U
typedef struct { PlatformSpiId spi; PlatformGpioId cs; PlatformGpioId drdy; PlatformTimeId time; int8_t axis_map[3]; } ProjectBmi323SpiResources;
SystemDeviceResult ProjectBmi323SpiResources_Get(uint8_t instance, ProjectBmi323SpiResources *resources);
#define PROJECT_ICM45686_SPI_INSTANCE_COUNT 2U
typedef struct { PlatformSpiId spi; PlatformGpioId cs; PlatformGpioId drdy; PlatformTimeId time; int8_t axis_map[3]; } ProjectIcm45686SpiResources;
SystemDeviceResult ProjectIcm45686SpiResources_Get(uint8_t instance, ProjectIcm45686SpiResources *resources);
#define PROJECT_BMI088_SYNC400_INSTANCE_COUNT 2U
typedef struct { PlatformI2cId i2c; PlatformI2cId gyro_i2c; PlatformTimeId time; PlatformGpioId drdy; PlatformGpioId auxiliary_drdy; int8_t axis_map[3]; } ProjectBmi088Sync400Resources;
SystemDeviceResult ProjectBmi088Sync400Resources_Get(uint8_t instance, ProjectBmi088Sync400Resources *resources);
#define PROJECT_BMI088_SYNC400_SPI_INSTANCE_COUNT 2U
typedef struct { PlatformSpiId spi; PlatformGpioId cs; PlatformGpioId drdy; PlatformTimeId time; PlatformGpioId auxiliary_cs; PlatformGpioId auxiliary_drdy; int8_t axis_map[3]; } ProjectBmi088Sync400SpiResources;
SystemDeviceResult ProjectBmi088Sync400SpiResources_Get(uint8_t instance, ProjectBmi088Sync400SpiResources *resources);
#define PROJECT_NEO_M8N_INSTANCE_COUNT 2U
typedef struct { PlatformUartId uart; PlatformTimeId time; } ProjectNeoM8nResources;
SystemDeviceResult ProjectNeoM8nResources_Get(uint8_t instance, ProjectNeoM8nResources *resources);
#define PROJECT_MAX_M10S_INSTANCE_COUNT 2U
typedef struct { PlatformUartId uart; PlatformTimeId time; } ProjectMaxM10sResources;
SystemDeviceResult ProjectMaxM10sResources_Get(uint8_t instance, ProjectMaxM10sResources *resources);
#define PROJECT_NEO_F10N_INSTANCE_COUNT 2U
typedef struct { PlatformUartId uart; PlatformTimeId time; } ProjectNeoF10nResources;
SystemDeviceResult ProjectNeoF10nResources_Get(uint8_t instance, ProjectNeoF10nResources *resources);
#endif
