from pathlib import Path
import json,hashlib
e=Path.cwd()/'.work/evidence/mpu_stage_a_ordinary';p=e/'report.json';report=json.loads(p.read_text())
rows=[r for r in report['rows'] if 'optimization' in r]
for r in rows:
 name=Path(r['source']).stem+'_'+r['optimization'][1:]+'_'+r['label']
 obj=e/(name+'.o');assert hashlib.sha256(obj.read_bytes()).hexdigest()==r['object_sha256']
 nm=(e/(name+'.nm')).read_text()
 r['runtime_state_symbols']={parts[3]:int(parts[1],16) for l in nm.splitlines() if len(parts:=l.split())==4 and parts[2].lower() in ('b','d') and not parts[3].startswith('.')}
 r['runtime_state_bytes']=sum(r['runtime_state_symbols'].values())
for before,after in zip(rows[::2],rows[1::2],strict=True):assert before['runtime_state_symbols']==after['runtime_state_symbols']
report['host_coff_note']='Zero-initialized -fdata-sections objects are marked d by this COFF tool. Report both b/d storage without double-counting section aliases; ARM ELF BSS independently compared.'
p.write_text(json.dumps(report,indent=2));print(json.dumps([{k:v for k,v in r.items() if k in ('source','label','optimization','runtime_state_symbols','runtime_state_bytes')} for r in rows],indent=2))
