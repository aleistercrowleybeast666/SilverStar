from pathlib import Path
import json,subprocess,hashlib,zipfile
root=Path.cwd();e=root/'.work/evidence/mpu_ret6_stage_a_gates';project=root/'.work/generated_ret6'
base='c1adfc3834bdd9bb396837522c08938d5ec4912b';sha=lambda b:hashlib.sha256(b).hexdigest()
checker=root/'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tools/check_power_of_ten.ps1'
old=subprocess.check_output(['git','show',base+':'+checker.relative_to(root).as_posix()]);current=checker.read_bytes();generated=(project/'Tools/check_power_of_ten.ps1').read_bytes()
assert old.replace(b'\r\n',b'\n')==current.replace(b'\r\n',b'\n') and generated==current
previous=root/'docs/FCCG/platform/evidence/SF6_RET6_mpu_recovery_prototype/mpu_recovery_prototype_evidence.zip'
build=project/'build/FCCG/SilverStar_F103RE/Release';frames={}
with zipfile.ZipFile(previous) as z:
 for name in z.namelist():
  if name.startswith('frames/Release/') and name.endswith('.su'):
   relative=name.removeprefix('frames/Release/');p=build/relative
   if p.exists():
    def parse(text):
     return {parts[0].rsplit(':',1)[1]:parts[1:] for line in text.splitlines() if len(parts:=line.split('\t'))>=3}
    before=parse(z.read(name).decode());after=parse(p.read_text())
    if 'mpu6050_instance.su' in relative or 'system_source_selector.su' in relative or 'system_startup.su' in relative:
     frames[relative]={'before':before,'after':after}
dump=subprocess.check_output(['D:/Arm GNU Toolchain/14.3 rel1/bin/arm-none-eabi-objdump.exe','-d','--disassemble=SensorImu_Verify',str(build/'SilverStar_0_1_1.elf')],text=True)
(e/'SensorImu_Verify_actual_elf.log').write_text(dump)
report={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'baseline_commit':base,
 'checker_unchanged_ignoring_only_git_crlf':True,'generated_checker_byte_equal_current_payload':True,
 'checker_current_raw_sha256':sha(current),'checker_git_baseline_sha256':sha(old),'checker_generated_sha256':sha(generated),
 'previous_evidence_zip_sha256':sha(previous.read_bytes()),'direct_frames_only':frames,
 'unresolved_indirect_blx_r3_still_present':'blx\tr3' in dump or 'blx\t' in dump,
 'acceptance':'NOT PROVEN: indirect library call paths, complete task/MSP/ISR stack, IRQ timing, RF HALDelay90ms yielding, hardware, preSTART generation-bound readmission. No exemptions or checker modifications.'}
(e/'boundary_audit.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='direct_frames_only'},indent=2))
