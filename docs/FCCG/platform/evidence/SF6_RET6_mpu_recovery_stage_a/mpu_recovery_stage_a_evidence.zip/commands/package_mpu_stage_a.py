from pathlib import Path
import json,subprocess,hashlib,zipfile
root=Path.cwd();source='f76383e966421a9b755b4b29ccab140b573ed95f';baseline='c1adfc3834bdd9bb396837522c08938d5ec4912b'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
e=root/'.work/evidence';g=e/'mpu_ret6_stage_a_gates';project=root/'.work/generated_ret6'
d=root/'docs/FCCG/platform/evidence/SF6_RET6_mpu_recovery_stage_a';d.mkdir(parents=True,exist_ok=True)
files={};sha=lambda b:hashlib.sha256(b).hexdigest()
def add(name,path):files[name]=Path(path).read_bytes()
changed=subprocess.check_output(['git','diff','--name-only',baseline,source,'--','apps/SCG'],text=True).splitlines()
for path in changed:
 add('source/'+path,root/path)
 if not path.endswith('silverstar_build_mode.h'):
  files['baseline/'+path]=subprocess.check_output(['git','show',baseline+':'+path])
files['source/change.patch']=subprocess.check_output(['git','diff','--binary',baseline,source,'--','apps/SCG'])
for path in ('apps/SCG/tests/test_compact_mpu_recovery.py','apps/SCG/tests/fixtures/mpu_recovery/project_resources.h','apps/SCG/tests/fixtures/mpu_recovery/test_mpu_recovery.c'):
 add('focused_fixture/'+path,root/path)
add('review/SF6_RET6_MPU_RECOVERY_STAGE_A.md',root/'docs/FCCG/platform/details/SF6_RET6_MPU_RECOVERY_STAGE_A.md')
for p in g.iterdir():
 if p.is_file():add('gates/'+p.name,p)
for p in (e/'mpu_stage_a_ordinary').iterdir():
 if p.is_file():add('ordinary/'+p.name,p)
for label in ('mpu_stage_a_post','mpu_stage_a_generator'):
 for p in (root/'.work'/label).rglob('*'):
  if p.is_file() and p.suffix in ('.json','.txt','.c','.h'):add('tests/'+label+'/'+p.relative_to(root/'.work'/label).as_posix(),p)
for p in e.iterdir():
 if p.is_file() and p.suffix=='.log' and ('stage_a' in p.name or p.name=='mpu_ret6_stage_a_gate_run.log'):add('logs/'+p.name,p)
for name in ('refresh_mpu_validation_stage_a.py','run_mpu_ret6_stage_a_gates.py','verify_mpu_stage_a_source.py',
 'mpu_map_stage_a.py','audit_mpu_stage_a_boundaries.py','compare_mpu_stage_a_ordinary.py',
 'compare_mpu_stage_a_arm_ordinary.py','annotate_mpu_stage_a_host_states.py','package_mpu_stage_a.py'):
 add('commands/'+name,e/name)
add('generation/mpu_validation_refresh_stage_a.json',e/'mpu_validation_refresh_stage_a.json')
add('parent_reference/materialization_failure.log',e/'library_mpu_stage_a_20261006/materialize.log')
for label,path in (('Release',project/'build/FCCG/SilverStar_F103RE/Release'),('StaticAnalysis',project/'build/FCCG/SilverStar_F103RE/StaticAnalysis/Release')):
 for ext in ('.elf','.map','.bin'):add('artifacts/'+label+'/SilverStar_0_1_1'+ext,path/('SilverStar_0_1_1'+ext))
 for p in path.rglob('*.su'):add('frames/'+label+'/'+p.relative_to(path).as_posix(),p)
for path in ('SilverStar.ssproject','Generated/Inc/project_device_instances.h','Generated/Src/project_device_instances.c',
 'Generated/Inc/project_flight_config.h','Generated/project_sources.mk','Tools/check_power_of_ten.ps1','Tools/check_task_stacks.py','Tests/Host/run_tests.ps1'):
 add('generated/'+path,project/path)
for path in changed:
 relative=path.split('/payload/',1)[1];add('generated/'+relative,project/relative)
add('official_cube/SF6_RET6_Hardware.ioc',root/'.work/cubemx_flight/SF6_RET6_Hardware/SF6_RET6_Hardware.ioc')
add('official_cube/prior_identity_proof.json',e/'snapshot_canonical_identity_proof.json')
add('pre_gate_actual/power10.log',e/'mpu_ret6_final_gates/power10.log')
add('pre_gate_actual/results.json',e/'mpu_ret6_final_gates/results.json')
add('pre_resources/map_resources.json',e/'mpu_ret6_final_gates/map_resources.json')
results=json.loads((g/'results.json').read_text());identity=json.loads((g/'generated_source_identity.json').read_text())
assert len(results)==8 and all(r['source_commit']==source for r in results)
assert not identity['mismatches'] and identity['linked_sources_count']==144 and not identity['linked_sources_without_current_byte_comparison']
versions={}
for name,argv in {'arm_gcc':['D:/Arm GNU Toolchain/14.3 rel1/bin/arm-none-eabi-gcc.exe','--version'],
 'host_gcc':['D:/msys64/ucrt64/bin/gcc.exe','--version'],'make':['D:/msys64/ucrt64/bin/mingw32-make.exe','--version'],
 'python':['D:/python_software/SilverStar/apps/FLP/.venv/Scripts/python.exe','--version'],
 'powershell':['powershell','-NoProfile','-Command','$PSVersionTable.PSVersion.ToString()']}.items():
 r=subprocess.run(argv,capture_output=True,text=True);versions[name]={'argv':argv,'exit':r.returncode,'output':r.stdout+r.stderr}
files['tool_versions.json']=json.dumps(versions,indent=2).encode()
summary={'source_commit':source,'baseline_commit':baseline,'changed_source_files':changed,
 'gate_exits':{r['name']:r['exit'] for r in results},'focused_pytest_items_pass':4,'compact_fault_cases':14,'ordinary_cases':3,'generator_pytest_pass':12,
 'resources':json.loads((g/'map_resources.json').read_text()),'checked_files':identity['checked_files'],'linked_sources':144,
 'checker_changed':False,'normal_storage':'Actual Host O2/Og b/d state and CM3 softfloat O2/Og BSS before/after equal; linked normal Host text/data/BSS equal. See complete commands and object hashes.',
 'ordinary_extra_failure':'Unchanged barometer-origin qualification prevents separate baseline/current startup compile. Not weakened; original failure log preserved.',
 'reference_library_file_id':'libfile_dc1fd091c3088191a26624616b97b032','reference_status':'regular helper download failed; no bytes/hash/patch obtained',
 'stage_b':'NOT IMPLEMENTED; qualification revoked remains sticky and fail-closed, await parent A review',
 'acceptance':'BLOCKED: full Host FAIL; stack FAIL; critical contracts/readmission/IRQ/RF timing/hardware NOT PROVEN; 20% RAM target missed',
 'scope':'No hardware/serial/probe/flashing, GSHC/FLP/stable/ordinary GUI edits, protocol changes, checker exceptions, resource cuts, merge/push.'}
files['summary.json']=json.dumps(summary,indent=2).encode();(d/'summary.json').write_bytes(files['summary.json'])
manifest={'source_commit':source,'files':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())]}
files['manifest.json']=json.dumps(manifest,indent=2).encode();(d/'manifest.json').write_bytes(files['manifest.json'])
archive=d/'mpu_recovery_stage_a_evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(files.items()):z.writestr(n,b)
with zipfile.ZipFile(archive) as z:
 for row in manifest['files']:assert sha(z.read(row['path']))==row['sha256']
digest=sha(archive.read_bytes());(d/'mpu_recovery_stage_a_evidence.sha256').write_text(digest+'  '+archive.name+'\n')
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':digest,'verified_files':len(manifest['files']),'source_commit':source}))
