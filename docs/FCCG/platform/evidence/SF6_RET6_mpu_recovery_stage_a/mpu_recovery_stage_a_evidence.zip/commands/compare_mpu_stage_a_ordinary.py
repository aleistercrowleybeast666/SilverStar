from pathlib import Path
import subprocess,json,hashlib
root=Path.cwd();baseline='c1adfc3834bdd9bb396837522c08938d5ec4912b';e=root/'.work/evidence/mpu_stage_a_ordinary';e.mkdir(exist_ok=True)
fixture=root/'.work/mpu_stage_a_post/test_ordinary_mpu_behavior_unc0'
command=json.loads((fixture/'compile.json').read_text())['argv']
first=command.index(str(fixture/'project_device_instances.c'))
prefix=[x for x in command[:first] if x not in ('-flto','-Wl,--gc-sections','-O2')]
names=['apps/SCG/plugins/builtin/silverstar_device_imu_mpu6050/payload/Devices/IMU/MPU6050/Adapter/Src/mpu6050_instance.c',
 'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/System/Src/system_source_selector.c']
rows=[]
for relative in names:
 p=root/relative;old=e/('baseline_'+p.name);old.write_bytes(subprocess.check_output(['git','show',baseline+':'+relative]))
 for optimization in ('-O2','-Og'):
  pair=[]
  for label,source in (('before',old),('after',p)):
   obj=e/(p.stem+'_'+optimization[1:]+'_'+label+'.o');argv=prefix+[optimization,'-c',str(source),'-o',str(obj)]
   r=subprocess.run(argv,capture_output=True,text=True,timeout=60)
   row={'source':relative,'label':label,'optimization':optimization,'argv':argv,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
   if r.returncode==0:
    nm=subprocess.check_output(['D:/msys64/ucrt64/bin/nm.exe','-S','--size-sort',str(obj)],text=True)
    (obj.with_suffix('.nm')).write_text(nm)
    row['bss_symbols']={parts[3]:int(parts[1],16) for l in nm.splitlines() if len(parts:=l.split())==4 and parts[2].lower()=='b'}
    row['runtime_state_symbols']={parts[3]:int(parts[1],16) for l in nm.splitlines() if len(parts:=l.split())==4 and parts[2].lower() in ('b','d') and not parts[3].startswith('.')}
    row['runtime_state_bytes']=sum(row['runtime_state_symbols'].values())
    row['bss_bytes']=sum(row['bss_symbols'].values());row['object_sha256']=hashlib.sha256(obj.read_bytes()).hexdigest()
   rows.append(row);pair.append(row)
  assert all(x['exit']==0 for x in pair),pair
  assert pair[0]['bss_symbols']==pair[1]['bss_symbols'],pair
  assert pair[0]['runtime_state_symbols']==pair[1]['runtime_state_symbols'],pair
# Full ordinary fixture link and real normal cases, using exactly baseline source
# bytes for the changed driver and selector; not a full ordinary F407 image.
argv=list(command)
for relative in names[:2]:argv[argv.index(str(root/relative))]=str(e/('baseline_'+Path(relative).name))
argv[-1]=str(e/'baseline_ordinary.exe');r=subprocess.run(argv,capture_output=True,text=True,timeout=60)
rows.append({'label':'baseline_fixture_link','argv':argv,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr});assert r.returncode==0,r.stderr
for number in (15,16,17):
 r=subprocess.run([argv[-1],str(number)],capture_output=True,text=True,timeout=10)
 rows.append({'label':'baseline_case','number':number,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr});assert r.returncode==0,r.stderr
for label,binary in (('before',Path(argv[-1])),('after',fixture/'mpu_recovery.exe')):
 size=subprocess.check_output(['D:/msys64/ucrt64/bin/size.exe',str(binary)],text=True)
 rows.append({'label':label+'_linked_size','output':size})
report={'baseline_commit':baseline,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'boundary':'Host GCC actual ordinary driver/selector O2 and Og objects, unchanged BSS; ordinary real C fixture cases 15-17 before/after. Does not establish a full F407 image. The separate original startup attempt failed before and after on the unchanged required Barometer origin validation; retained in mpu_stage_a_ordinary.log, not waived.', 'rows':rows}
(e/'report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
