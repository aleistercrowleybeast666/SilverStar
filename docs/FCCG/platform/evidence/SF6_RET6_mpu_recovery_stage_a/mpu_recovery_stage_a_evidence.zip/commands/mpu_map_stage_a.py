from pathlib import Path
import re,json,hashlib,subprocess
from collections import defaultdict
root=Path.cwd(); project=root/'.work/generated_ret6'; evidence=root/'.work/evidence/mpu_ret6_stage_a_gates'
build=project/'build/FCCG/SilverStar_F103RE/Release'; mapfile=build/'SilverStar_0_1_1.map'; s=mapfile.read_text()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sections={n:int(re.search(r'^'+re.escape(n)+r'\s+0x[0-9a-f]+\s+0x([0-9a-f]+)',s,re.M)[1],16) for n in ('.text','.data','.bss')}
stack=re.search(r'^\._user_heap_stack\s+0x([0-9a-f]+)\s+0x([0-9a-f]+)',s,re.M);msp=int(stack[2],16);ram=int(stack[1],16)+msp-0x20000000
region=s[s.index('\n.data '):s.index('\n._user_heap_stack')]
rows=[(int(m[3],16),m[1],m[4]) for m in re.finditer(r'^ (\.(?:bss|data)\S*)\s+0x([0-9a-f]+)\s+0x([0-9a-f]+)\s+([^\n]+\.o)',region,re.M)]
groups=defaultdict(int)
for size,name,owner in rows:
 if '_stack' in name:group='static_task_stacks_already_in_bss'
 elif ('/APP/Src/logger_bus.o' in owner and 'storage' in name) or (('/APP/Src/estimator_bus.o' in owner or '/APP/Src/imu_sample_bus.o' in owner) and name=='.bss.s_queue'):group='sample_and_log_queues'
 elif 'logger_' in owner or '/Protocol/SSLOG/' in owner:group='other_logging'
 elif '/Algorithm/' in owner or '/APP/Src/estimator_task.o' in owner or '/APP/Src/ins_task.o' in owner:group='algorithm_and_origin_state'
 elif '/Platform/' in owner or '/Drivers/' in owner or '/HardwareGenerated/' in owner or '/FreeRTOS' in owner:group='platform_vendor_rtos'
 elif '/Devices/' in owner:group='device_state'
 else:group='other'
 groups[group]+=size
groups['alignment_fill_or_unparsed']=ram-msp-sum(groups.values());groups['main_msp_reservation']=msp
old=json.loads((root/'.work/evidence/mpu_ret6_final_gates/map_resources.json').read_text())
report={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),**sections,'ram_used':ram,'ram_spare':65536-ram,
 'ram_spare_percent':(65536-ram)*100/65536,'twenty_percent_goal_used_max':52428,'twenty_percent_goal_gap':ram-52428,
 'flash_load_bytes':(build/'SilverStar_0_1_1.bin').stat().st_size,'baseline_source_commit':old['source_commit'],
 'net_ram_delta':ram-old['ram_used'],'net_flash_delta':(build/'SilverStar_0_1_1.bin').stat().st_size-old['flash_load_bytes'],
 'groups':dict(groups),'baseline_groups':old['groups'],'largest_symbols':[{'bytes':a,'symbol':n,'object':o} for a,n,o in sorted(rows,reverse=True)[:30]],
 'hashes':{p.name:sha(p) for p in build.glob('SilverStar_0_1_1.*') if p.suffix in ('.elf','.map','.bin','.hex')},
 'counting_boundary':'Static task/idle stacks are included once in BSS; MSP separately reserved. No stack/WCET proof inferred.'}
symbols=subprocess.check_output(['D:/Arm GNU Toolchain/14.3 rel1/bin/arm-none-eabi-nm.exe','-S','--size-sort',str(build/'SilverStar_0_1_1.elf')],text=True)
(evidence/'symbols_nm.log').write_text(symbols,encoding='utf-8')
report['recovery_symbols']=[line for line in symbols.splitlines() if re.search('s_recovery|s_imu$|Mpu6050Recovery_|PrepareI2c|ConfigRequest',line)]
frames=[]
for p in build.rglob('*.su'):
 for line in p.read_text().splitlines():
  if 'Mpu6050' in line or 'SensorImuAdapter_Prepare' in line or 'SystemImu_Process' in line:
   frames.append({'file':p.relative_to(project).as_posix(),'record':line})
report['actual_compiler_stack_frames_not_whole_call_path']=frames
(evidence/'map_resources.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k not in ('largest_symbols','baseline_groups','hashes')},indent=2))
