from pathlib import Path
import subprocess,json,hashlib,zipfile,csv,io
root=Path.cwd();source='018ff76bdb5701541ae7545556a4318bf2203107';baseline='0a58c4e25909f2e1af5acf641a8b0aec9e507074'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
evidence=root/'.work/evidence';gates=evidence/'mpu_ret6_final_gates';project=root/'.work/generated_ret6'
destination=root/'docs/FCCG/platform/evidence/SF6_RET6_mpu_recovery_prototype';destination.mkdir(parents=True,exist_ok=True)
files={};sha=lambda b:hashlib.sha256(b).hexdigest()
def add(name,path):
 data=Path(path).read_bytes()
 if name in files and files[name]!=data: raise RuntimeError('duplicate '+name)
 files[name]=data
changed=subprocess.check_output(['git','diff','--name-only',baseline,source,'--','apps/SCG'],text=True).splitlines()
for relative in changed:add('source/'+relative,root/relative)
files['source/change.patch']=subprocess.check_output(['git','diff','--binary',baseline,source,'--','apps/SCG'])
add('review/SF6_RET6_MPU_RECOVERY_PROTOTYPE.md',root/'docs/FCCG/platform/details/SF6_RET6_MPU_RECOVERY_PROTOTYPE.md')
for path in gates.iterdir():
 if path.is_file():add('final_gates/'+path.name,path)
for label in ('mpu_validation_refresh','mpu_validation_refresh_final'):
 add('generation/'+label+'.json',evidence/(label+'.json'))
for name in ('mpu_validation_refresh.log','mpu_validation_refresh2.log','mpu_validation_refresh_final.log',
 'mpu_recovery_qualified_post.log','mpu_recovery_qualified_pre.log','mpu_generator_regression.log','mpu_generator_regression2.log','mpu_ret6_final_gate_run.log'):
 add('logs/'+name,evidence/name)
for name in ('refresh_mpu_validation.py','refresh_mpu_validation_final.py','run_mpu_ret6_final_gates.py',
 'run_mpu_prefix_qualified.py','mpu_map_final.py','audit_mpu_frames_final.py','verify_mpu_final_source.py','package_mpu_recovery.py'):
 add('commands/'+name,evidence/name)
add('library_input/materialization_failure.log',evidence/'library_mpu_recovery_20261006/materialize.log')
pre=root/'.work/mpu_recovery_qualified_pre'
for p in pre.iterdir():
 if p.suffix in ('.json','.c','.h'):add('pre_fix/'+p.name,p)
post=root/'.work/mpu_recovery_qualified_post'
for p in post.rglob('*'):
 if p.is_file() and p.suffix in ('.json','.txt'):add('post_fix/'+p.relative_to(post).as_posix(),p)
for directory,label in ((project/'build/FCCG/SilverStar_F103RE/Release','Release'),(project/'build/FCCG/SilverStar_F103RE/StaticAnalysis/Release','StaticAnalysis')):
 for extension in ('.elf','.map','.bin'):
  add('artifacts/'+label+'/SilverStar_0_1_1'+extension,directory/('SilverStar_0_1_1'+extension))
 for p in directory.rglob('*.su'):add('frames/'+label+'/'+p.relative_to(directory).as_posix(),p)
for relative in ('SilverStar.ssproject','Generated/Inc/project_device_instances.h','Generated/Src/project_device_instances.c',
 'Generated/Inc/project_flight_config.h','Generated/project_sources.mk','Tools/check_power_of_ten.ps1','Tools/check_task_stacks.py','Tests/Host/run_tests.ps1'):
 add('generated/'+relative,project/relative)
identity=json.loads((gates/'generated_source_identity.json').read_text())
assert not identity['mismatches'] and identity['linked_sources_count']==144 and not identity['linked_sources_without_current_byte_comparison']
refresh=json.loads((evidence/'mpu_validation_refresh.json').read_text())
for entry in refresh['reviewed_validation_payload_refresh']:add('generated/'+entry['generated_path'],project/entry['generated_path'])
add('official_cube/SF6_RET6_Hardware.ioc',root/'.work/cubemx_flight/SF6_RET6_Hardware/SF6_RET6_Hardware.ioc')
add('official_cube/prior_canonical_identity_proof.json',evidence/'snapshot_canonical_identity_proof.json')
pre_rows=json.loads((pre/'sequences.json').read_text())
post_rows=json.loads(next(post.rglob('sequences.json')).read_text())
matrix=[]
for previous,current in zip(pre_rows,post_rows,strict=True):
 assert previous['number']==current['number'] and current['exit']==0
 matrix.append({'number':current['number'],'sequence':current['sequence'],'pre_native_exit':previous['exit'],
  'post_native_exit':current['exit'],'post_observation':current['stdout'].strip(),'pre_first_failure':previous['stderr'].strip(),
  'boundary':'Host mocked peripherals; calibration/alignment/report boundaries mocked, no hardware or full START qualification'})
buf=io.StringIO(newline='');writer=csv.DictWriter(buf,fieldnames=list(matrix[0]));writer.writeheader();writer.writerows(matrix)
files['matrix/focused_matrix.csv']=buf.getvalue().encode();files['matrix/focused_matrix.json']=json.dumps(matrix,indent=2).encode()
(destination/'focused_matrix.csv').write_bytes(files['matrix/focused_matrix.csv'])
resources=json.loads((gates/'map_resources.json').read_text());results=json.loads((gates/'results.json').read_text())
assert len(results)==8 and all(row['source_commit']==source for row in results)
versions={}
for name,argv in {'arm_gcc':['D:/Arm GNU Toolchain/14.3 rel1/bin/arm-none-eabi-gcc.exe','--version'],
 'host_gcc':['D:/msys64/ucrt64/bin/gcc.exe','--version'],'make':['D:/msys64/ucrt64/bin/mingw32-make.exe','--version'],
 'python':['D:/python_software/SilverStar/apps/FLP/.venv/Scripts/python.exe','--version'],'powershell':['powershell','-NoProfile','-Command','$PSVersionTable.PSVersion.ToString()']}.items():
 r=subprocess.run(argv,capture_output=True,text=True);versions[name]={'argv':argv,'exit':r.returncode,'output':r.stdout+r.stderr}
files['tool_versions.json']=json.dumps(versions,indent=2).encode()
summary={'source_commit':source,'previous_checkpoint':baseline,'gate_exits':{r['name']:r['exit'] for r in results},
 'focused_cases':14,'pre_fail_cases':[r['number'] for r in pre_rows if r['exit']!=0], 'post_fail_cases':[],
 'ordinary_cases':3,'selected_pytest':'4 passed','generator_pytest':'12 passed','resources':resources,
 'input_library_id':'libfile_1ed125f404dc8191b56457eee0986b58','input_materialization':'download failed; no bytes read',
 'qualification':'physical retry only; qualification_revoked sticky, no current-ready clear path',
 'acceptance':'BLOCKED: Power10/stack/official Host FAIL, qualification readmission missing, critical contract/hardware/timing/stack NOT PROVEN, RAM20% missed',
 'scope':'No hardware/serial/probe, flashing, stable/ordinary GUI/GSHC/FLP edits, merge/push, new gate exceptions or RAM cuts'}
files['summary.json']=json.dumps(summary,indent=2).encode()
(destination/'summary.json').write_bytes(files['summary.json'])
manifest={'source_commit':source,'files':[{'path':name,'bytes':len(data),'sha256':sha(data)} for name,data in sorted(files.items())]}
files['manifest.json']=json.dumps(manifest,indent=2).encode();(destination/'manifest.json').write_bytes(files['manifest.json'])
archive=destination/'mpu_recovery_prototype_evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
 for entry in manifest['files']:assert sha(z.read(entry['path']))==entry['sha256']
digest=sha(archive.read_bytes());(destination/'mpu_recovery_prototype_evidence.sha256').write_text(digest+'  '+archive.name+'\n')
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':digest,'verified_files':len(manifest['files']),'source_commit':source}))
