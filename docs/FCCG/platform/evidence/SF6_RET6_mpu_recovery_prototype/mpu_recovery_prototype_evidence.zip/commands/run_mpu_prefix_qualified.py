from pathlib import Path
import sys,json,subprocess,hashlib
root=Path.cwd();sys.path.insert(0,str(root/'apps/SCG/tests'))
from test_compact_mpu_recovery import compile_fixture,SEQUENCES
directory=root/'.work/mpu_recovery_qualified_pre';directory.mkdir(exist_ok=False)
binary=compile_fixture(directory,compact=True,baseline=True)
compiled=json.loads((directory/'compile.json').read_text());argv=compiled['argv'];records=[]
selected=('system_source_selector.c','sensor_imu_adapter.c','mpu6050_instance.c')
for index,arg in enumerate(argv):
 if Path(arg).name in selected:
  rel=Path(arg).relative_to(root).as_posix()
  data=subprocess.check_output(['git','show','0a58c4e:'+rel])
  p=directory/Path(arg).name;p.write_bytes(data);argv[index]=str(p)
  records.append({'original_path':rel,'baseline_commit':'0a58c4e25909f2e1af5acf641a8b0aec9e507074','sha256':hashlib.sha256(data).hexdigest()})
r=subprocess.run(argv,capture_output=True,text=True,timeout=60)
compiled={'argv':argv,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'baseline_implementation':records,
 'boundary':'Current final fixture, headers and rendered selected facade; new unused recovery query is garbage-collected. Actual three pre-fix owning implementation sources are pinned to 0a58c4e.'}
(directory/'compile.json').write_text(json.dumps(compiled,indent=2),encoding='utf-8')
assert r.returncode==0,r.stderr
rows=[]
for number,name in enumerate(SEQUENCES,1):
 r=subprocess.run([str(binary),str(number)],capture_output=True,text=True,timeout=10)
 rows.append({'number':number,'name':name,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
(directory/'sequences.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
fixture=root/'apps/SCG/tests/fixtures/mpu_recovery/test_mpu_recovery.c'
(directory/fixture.name).write_bytes(fixture.read_bytes())
print(json.dumps(rows,indent=2));raise SystemExit(int(any(r['exit'] for r in rows)))
