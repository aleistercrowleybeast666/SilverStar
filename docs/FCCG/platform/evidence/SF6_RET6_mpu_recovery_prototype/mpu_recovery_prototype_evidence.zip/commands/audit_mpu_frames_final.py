from pathlib import Path
import zipfile,hashlib,json,subprocess
root=Path.cwd();build=root/'.work/generated_ret6/build/FCCG/SilverStar_F103RE/Release';out=root/'.work/evidence/mpu_ret6_final_gates'
archive=root/'docs/FCCG/platform/evidence/SF6_RET6_software_fix/software_fix_evidence.zip'
rows=[]
with zipfile.ZipFile(archive) as z:
 for suffix in ('Devices/IMU/MPU6050/Adapter/Src/mpu6050_instance.su','Devices/SensorBus/Adapter/Src/sensor_imu_adapter.su','System/Src/system_source_selector.su'):
  old=z.read('artifacts/SilverStar_F103RE/Release/'+suffix);new=(build/suffix).read_bytes()
  def parse(data):
   result={}
   for line in data.decode().splitlines():
    parts=line.split('\t');result[parts[0].rsplit(':',1)[-1]]=parts[1:]
   return result
  a=parse(old);b=parse(new)
  for name in sorted(a.keys()|b.keys()):
   if a.get(name)!=b.get(name):rows.append({'file':suffix,'function':name,'prior':a.get(name),'current':b.get(name)})
elf=build/'SilverStar_0_1_1.elf';command=['D:/Arm GNU Toolchain/14.3 rel1/bin/arm-none-eabi-objdump.exe','-d','--disassemble=SensorImu_Verify',str(elf)]
r=subprocess.run(command,capture_output=True,text=True);(out/'SensorImu_Verify_objdump.log').write_text(json.dumps(command)+'\n'+r.stdout+r.stderr+'\nEXIT='+str(r.returncode),encoding='utf-8')
(out/'stack_frame_delta.json').write_text(json.dumps({'baseline_archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
 'scope':'Compiler direct frames only; never summed into task/MSP/ISR/WCET proof. SensorImu_Verify indirect/unbounded gate failure remains.',
 'changed_or_new_frames':rows,'objdump_exit':r.returncode},indent=2),encoding='utf-8')
print(json.dumps(rows,indent=2))
