from pathlib import Path
import hashlib,json,subprocess,dataclasses
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.core.workspace import WorkspacePolicy
from silverstar_fccg.generator.assembler import ProjectAssembler
from silverstar_fccg.project.model import ProjectModel_Load
root=Path.cwd(); output=root/'.work/generated_ret6'; baseline='0a58c4e25909f2e1af5acf641a8b0aec9e507074'
service=FccgService(root/'apps/SCG'); model=ProjectModel_Load(output/'SilverStar.ssproject')
catalog=service.catalog.ProjectView_Get(model); assembler=ProjectAssembler(WorkspacePolicy(root/'.work'),catalog)
before_plan=assembler.Plan(model,output)
records=[]; pending=[]
sha=lambda b:hashlib.sha256(b).hexdigest()
prior=json.loads((root/'.work/evidence/ret6_combined_final_generated_source_identity.json').read_text())
known_raw={entry['path']:entry['generated_sha256'] for entry in prior['records']}
for component in model.ComponentIds_Get():
 manifest=catalog.Component_Get(component)
 for source in manifest.PayloadFiles_Get():
  relative=source.relative_to(manifest.payload_root).as_posix(); target=output/relative
  current=source.read_bytes(); previous=target.read_bytes()
  if current!=previous:
   repository_path=source.relative_to(root).as_posix()
   old=subprocess.check_output(['git','show',baseline+':'+repository_path])
   if old.replace(b'\r\n',b'\n')!=previous.replace(b'\r\n',b'\n') or sha(previous)!=known_raw.get(relative):
    raise RuntimeError('Unreviewed generated payload differs from previous commit or recorded raw input: '+relative)
   pending.append((target,current))
   records.append({'repository_path':repository_path,'generated_path':relative,'old_sha256':sha(previous),
       'old_git_sha256':sha(old),'old_equal_ignoring_crlf_only':True,'old_matches_prior_raw_evidence':True,'new_sha256':sha(current)})
# Explicit authorized refresh of this own disposable validation project only.
# Normal Apply's preservation behavior is neither changed nor bypassed for user projects.
for target,data in pending: target.write_bytes(data)
plan=assembler.Plan(model,output)
if not plan.valid: raise RuntimeError(str(plan))
result=assembler.Apply(model,plan)
report={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'baseline_commit':baseline,'output':str(output),'before_plan':dataclasses.asdict(before_plan),
 'reviewed_validation_payload_refresh':records,'after_apply':dataclasses.asdict(result)}
(root/'.work/evidence/mpu_validation_refresh.json').write_text(json.dumps(report,indent=2,default=str),encoding='utf-8')
print(json.dumps({'source_commit':report['source_commit'],'refreshed_payload_files':len(records),'after_apply':report['after_apply']},default=str))
