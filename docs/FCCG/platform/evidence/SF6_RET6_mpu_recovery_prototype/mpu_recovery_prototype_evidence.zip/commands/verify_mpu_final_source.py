from pathlib import Path
import hashlib,json,subprocess
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.core.workspace import WorkspacePolicy
from silverstar_fccg.generator.assembler import ProjectAssembler
from silverstar_fccg.project.model import ProjectModel_Load
root=Path.cwd(); project=root/'.work/generated_ret6'
service=FccgService(root/'apps/SCG')
model=ProjectModel_Load(project/'SilverStar.ssproject')
catalog=service.catalog.ProjectView_Get(model)
assembler=ProjectAssembler(WorkspacePolicy(root/'.work'),catalog)
hardware=assembler._HardwareFiles_Get(model)
desired,ownership=assembler._DesiredFiles_Get(model,project,hardware)
records=[]; mismatches=[]; metadata_differences=[]
def jsondiff(a,b,prefix=''):
    if isinstance(a,dict) and isinstance(b,dict):
        for k in sorted(a.keys()|b.keys()):
            yield from jsondiff(a.get(k),b.get(k),prefix+'/'+k)
    elif a!=b:
        yield {'path':prefix,'current_render':a,'saved_generated':b}
def check(relative,data,kind):
    p=project/relative
    actual=p.read_bytes() if p.is_file() else b''
    expected=hashlib.sha256(data).hexdigest(); got=hashlib.sha256(actual).hexdigest()
    records.append({'path':relative,'kind':kind,'expected_sha256':expected,'generated_sha256':got})
    if data!=actual:
        mismatches.append({'path':relative,'kind':kind})
        if relative in ('.fccg/ownership.json','SilverStar.ssproject'):
            metadata_differences.extend({'file':relative,**d} for d in jsondiff(json.loads(data),json.loads(actual)))
for relative,data in sorted(desired.items()): check(relative,data,'mpu_final_current_render_or_hardware')
for relative,data in sorted(hardware.items()): check(relative,data,'actual_imported_official_cube')
for component in model.ComponentIds_Get():
    manifest=catalog.Component_Get(component)
    for p in manifest.PayloadFiles_Get(): check(p.relative_to(manifest.payload_root).as_posix(),p.read_bytes(),'current_component_payload')
report={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'git_dirty':subprocess.check_output(['git','status','--porcelain'],text=True),'checked_files':len(records),'mismatches':mismatches,'metadata_differences':metadata_differences,'records':records}
report['saved_project_semantically_equal']=json.loads(desired['SilverStar.ssproject'])==json.loads((project/'SilverStar.ssproject').read_bytes())
listed=(root/'.work/evidence/mpu_ret6_final_gates/linked_sources.log').read_text(encoding='utf-8-sig').splitlines()
linked=[line.strip().removeprefix('Assembly: ') for line in listed if line.strip().endswith(('.c','.s'))]
matched={r['path'] for r in records if r['expected_sha256']==r['generated_sha256']}
report['linked_sources_count']=len(linked)
report['linked_sources_without_current_byte_comparison']=[p for p in linked if p not in matched]
(root/'.work/evidence/mpu_final_current_render_SilverStar.ssproject').write_bytes(desired['SilverStar.ssproject'])
(root/'.work/evidence/mpu_final_current_render_ownership.json').write_bytes(desired['.fccg/ownership.json'])
(root/'.work/evidence/mpu_ret6_final_gates/generated_source_identity.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='records'},indent=2))
raise SystemExit(bool(mismatches))
