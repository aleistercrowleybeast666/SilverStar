import ctypes
ctypes.windll.kernel32.SetErrorMode(3)
import hashlib,json,subprocess,zipfile
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path.cwd();BASE=ROOT/'.work/GUI_UserFlow_20261002_v1';OUT=ROOT/'docs/FCCG/gui_userflow_20261002/final_v1';OUT.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert source=='17bc6ce8351773bd036f4f52b93b2e4bf0acde16'
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],text=True).strip()
gates=json.loads((BASE/'workflow_gates_final.json').read_text());assert len(gates)==14 and all(x['exit_code']==0 for x in gates)
workflow=json.loads((BASE/'Workflow_Final_v1/workflow.json').read_text());assert workflow['source_commit']==source and len(workflow['cases'])==4
dual=json.loads((BASE/'Dual_Final_v2/results.json').read_text());assert len(dual)==2
frozen=[]
for row in json.loads((ROOT/'.work/SoftwareCandidates_20261002_Single_v1/freeze_index.json').read_text()):
 p=Path(row['zip']);assert sha(p)==row['zip_sha256'];checks={str(p):sha(p)}
 for name,expected in row['firmware_sha256'].items():
  matches=list(Path(row['directory']).rglob(name));assert matches and all(sha(p)==expected for p in matches)
  checks.update({str(p):sha(p) for p in matches})
 frozen.append({'name':row['name'],'unchanged':True,'hashes':checks})
auto=[]
with zipfile.ZipFile(ROOT/'docs/FCCG/auto_memory_layout_20261002/integrated_v2/sources_artifacts.zip') as z:
 for algo in ['PureINS','KF6','ESKF15','SF6']:
  for layout in ['auto','legacy']:
   prefix=algo+'_'+layout+'/Source/Flight_Controller/'
   entries=[n for n in z.namelist() if n.startswith(prefix) and Path(n).suffix.lower() in ['.c','.h','.s','.ld']]
   for n in entries:
    p=ROOT/'.work/AutoMemory_Integrated_20261002_v2'/(algo+'_'+layout+'_v1')/'Flight_Controller'/n[len(prefix):]
    assert p.is_file() and sha(p)==hashlib.sha256(z.read(n)).hexdigest(),str(p)
   auto.append({'project':algo+'_'+layout,'files':len(entries),'unchanged_against_frozen_archive':True})
versions={}
for name,command in [('Python',[str(ROOT/'.venv/Scripts/python.exe'),'--version']),('ARM',['arm-none-eabi-gcc','--version']),('Host',['D:/msys64/ucrt64/bin/gcc.exe','--version']),('Make',['mingw32-make','--version']),('Qt',[str(ROOT/'.venv/Scripts/python.exe'),'-c','import PySide6; from PySide6.QtCore import qVersion; print(PySide6.__version__, qVersion())']),('PowerShell',['powershell','-NoProfile','-Command','$PSVersionTable.PSVersion.ToString()'])]:
 r=subprocess.run(command,capture_output=True,text=True,timeout=30);versions[name]={'command':command,'exit_code':r.returncode,'output':r.stdout+r.stderr}
with zipfile.ZipFile(OUT/'evidence_final.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in BASE.iterdir():
  if p.is_file() and p.suffix in ['.log','.xml','.py','.json','.patch']:z.write(p,'Runs/'+p.name)
 for dirname in ['FCCG_Pages_Final_v1','FCCG_Details_Final_v1','FCCG_Details_Final_v2','GSHC_Comparison_Final_v1']:
  for p in (BASE/dirname).iterdir():
   if p.is_file() and p.suffix in ['.png','.jpg','.json','.csv']:z.write(p,dirname+'/'+p.name)
 for dirname,metadata in [('Workflow_v9','workflow.json'),('Workflow_Final_v1','workflow.json'),('Dual_Final_v2','results.json')]:
  z.write(BASE/dirname/metadata,dirname+'/'+metadata)
 for p in (ROOT/'apps/FCCG/.work/GUI_UserFlow_20261002_CustomArch_v3/custom_architecture0/custom').glob('*.log'):z.write(p,'ArchitectureNegative/'+p.name)
 for relative in ['apps/FCCG/plugins/builtin/silverstar_core_0_1_0/payload/Tools/check_architecture.ps1','apps/FCCG/src/silverstar_fccg/generator/source_graph.py','apps/FCCG/tests/test_custom_hardware_architecture.py']:
  z.write(ROOT/relative,'ReviewedSource/'+relative)
 for row in workflow['cases']:
  target=Path(row['target']);z.write(Path(row['root'])/'SilverStar.ssproject','FinalConfiguration/'+row['name']+'.ssproject')
  for relative in ['Tools/check_architecture.ps1','Tools/check_power_of_ten.ps1','Makefile','.eide/eide.yml','Generated/project_sources.mk']:
   p=target/relative
   if p.is_file():z.write(p,'FinalEmitted/'+row['name']+'/'+relative)
for filename in ['workflow_gates_final.json','workflow_artifacts_final.json']:(OUT/filename).write_bytes((BASE/filename).read_bytes())
(OUT/'preservation.json').write_text(json.dumps({'frozen_single':frozen,'auto_source':auto,'main':subprocess.check_output(['git','rev-parse','main'],text=True).strip()},indent=2),encoding='utf-8')
manifest={'utc':datetime.now(timezone.utc).isoformat(),'source_commit':source,'branch':subprocess.check_output(['git','branch','--show-current'],text=True).strip(),'tools':versions,'native_scope':'one actually executed complete 14-command matrix, 4 fresh single-target projects; 2 dual-target generation/preservation-only cases','manual_critical_contract_review':'NOT_PROVEN','hardware':'NOT_PERFORMED in this GUI slice','gui':'offscreen Qt with real event loop; no OS mouse, GL or transport/controller instantiated','files':{p.name:sha(p) for p in OUT.iterdir() if p.is_file()}}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8');print('ARCHIVED',source,sha(OUT/'evidence_final.zip'),(OUT/'evidence_final.zip').stat().st_size,auto,flush=True)
