import hashlib, importlib.util, json, os, pathlib, subprocess, sys
ROOT=pathlib.Path(__file__).resolve().parents[2]
OUT=pathlib.Path(__file__).parent/'GSHC_Comparison_Final_v1'
OUT.mkdir(exist_ok=False)
sys.path[:0]=[str(ROOT/'apps/GSHC'),str(ROOT/'apps/GSHC/tests')]
os.environ['QT_QPA_PLATFORM']='offscreen'
from PySide6.QtCore import QSettings,QPoint,QEvent,QEventLoop,QTimer
from PySide6.QtGui import QFont,QFontDatabase
from PySide6.QtWidgets import QApplication,QGroupBox
from services.i18n import I18n,Language
from services.preferences import Theme
from services.state_model import EventHistory
from test_ui_workflow import ready_state
from ui.main_window import MainWindow as Current
raw=subprocess.check_output(['git','-C','D:/python_software/SilverStar_GSHC','show','cbee51e1f259d56a8e9dcdb7c3b236f9b054e4fb:ui/main_window.py'])
source=OUT/'historical_main_window.py';source.write_bytes(raw)
spec=importlib.util.spec_from_file_location('ui.historical_main_window',source)
module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
app=QApplication([])
def drain():
 loop=QEventLoop();QTimer.singleShot(30,loop.quit);loop.exec()
for font in ['msyh.ttc','msyhbd.ttc','segoeui.ttf','segoeuib.ttf']:
 QFontDatabase.addApplicationFont(str(pathlib.Path('C:/Windows/Fonts')/font))
app.setFont(QFont('Microsoft YaHei',9))
records=[]
for variant,Window in [('historical_cbee51e1',module.MainWindow),('current',Current)]:
 for language,theme,width,height in [('zh_CN','light',1280,720),('zh_CN','light',1536,816),('en_US','dark',1536,816)]:
  label=f'{variant}_{language}_{theme}_{width}x{height}'
  i18n=I18n(QSettings(str(OUT/(label+'.ini')),QSettings.IniFormat));i18n.set_language(language)
  window=Window(i18n);window.render_timer.stop();window.gl_view.hide()
  state=ready_state();window.bind_runtime_model(state,EventHistory())
  window.theme_combo.setCurrentIndex(window.theme_combo.findData(theme))
  window.resize(width,height);window.show();drain()
  record={'variant':variant,'language':language,'theme':theme,'source_sha256':hashlib.sha256(raw if variant.startswith('historical') else (ROOT/'apps/GSHC/ui/main_window.py').read_bytes()).hexdigest(),'window_size':[window.width(),window.height()],'method':'exact historical layout module with current shared dependencies; Qt offscreen; GL view hidden in both; no transport/controller instantiated','pages':{}}
  for name in ['preflight','flight']:
   page=getattr(window,name+'_page');window.pages.setCurrentWidget(page);drain()
   boxes=[]
   for box in page.findChildren(QGroupBox):
    point=box.mapTo(window,QPoint(0,0));boxes.append({'title':box.title(),'geometry':[point.x(),point.y(),box.width(),box.height()],'visible':box.isVisible()})
   record['pages'][name]={'groups':boxes,'image':label+'_'+name+'.png','scroll_maximum':page.verticalScrollBar().maximum() if hasattr(page,'verticalScrollBar') else None}
   assert window.grab().save(str(OUT/record['pages'][name]['image']))
  records.append(record)
  window.close();window.deleteLater();drain()
(OUT/'results.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
print('COMPLETE',len(records)*2,flush=True)
