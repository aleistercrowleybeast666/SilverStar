import os,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
os.environ['QT_QPA_PLATFORM']='offscreen'
sys.path[:0]=[str(ROOT/'apps/GSHC'),str(ROOT/'apps/GSHC/tests')]
from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QFont,QFontDatabase
app=QApplication([])
for font in ['msyh.ttc','msyhbd.ttc','segoeui.ttf','segoeuib.ttf']:
 QFontDatabase.addApplicationFont(str(Path('C:/Windows/Fonts')/font))
app.setFont(QFont('Microsoft YaHei',9))
import pytest
raise SystemExit(pytest.main(['apps/GSHC/tests/test_release_layout.py','apps/GSHC/tests/test_navigation_gui.py','-vv','-ra','--basetemp=apps/GSHC/.work/GUI_UserFlow_20261002_PostLayout_Fonts_v3','--junitxml=.work/GUI_UserFlow_20261002_v1/gshc_layout_post_fonts_v3.xml']))
