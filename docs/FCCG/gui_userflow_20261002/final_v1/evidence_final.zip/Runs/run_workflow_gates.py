from concurrent.futures import ThreadPoolExecutor
import hashlib,json,os,subprocess,threading,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
workflow=json.loads((OUT/'Workflow_v9/workflow.json').read_text(encoding='utf-8'))
assert len(workflow['cases'])==4
results=[];lock=threading.Lock();env=dict(os.environ);env['PATH']=str(ROOT/'.venv/Scripts')+os.pathsep+env['PATH']
def run(case):
 project=Path(case['target']);role=case['role']
 gates=[('arm',['-j4','CONFIG=Release','artifact-check']),('architecture',['architecture-check']),('power10',['power10-check'])]
 if role=='flight':gates.append(('resources',['CONFIG=Release','memory-report','stack-report']))
 for gate,args in gates:
  name=case['name']+'_'+gate;command=['mingw32-make',*args];log=OUT/(name+'.log');start=time.monotonic();print('BEGIN',name,flush=True)
  with log.open('wb') as stream:
   try:code=subprocess.run(command,cwd=project,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=900).returncode
   except subprocess.TimeoutExpired:code='TIMEOUT'
  with lock:
   results.append({'name':name,'command':command,'cwd':str(project),'source_commit':workflow['source_commit'],'exit_code':code,'seconds':time.monotonic()-start,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
   (OUT/'workflow_gates.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
  print('END',name,code,flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,workflow['cases']))
artifacts={str(p.resolve()):hashlib.sha256(p.read_bytes()).hexdigest() for p in (OUT/'Workflow_v9').rglob('*') if p.is_file() and p.suffix.lower() in ['.elf','.bin','.hex','.map','.ssproject','.ssdecoder']}
(OUT/'workflow_artifacts.json').write_text(json.dumps(artifacts,indent=2),encoding='utf-8')
print('COMPLETE',len(results),sum(r['exit_code']==0 for r in results),flush=True)
