import copy, hashlib, json, os, shutil, subprocess, sys, time
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch
ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).parent/"Workflow_v2"
OUT.mkdir(exist_ok=False)
sys.path.insert(0, str(ROOT/'apps/FCCG/src'))
os.environ['QT_QPA_PLATFORM']='offscreen'
from PySide6.QtWidgets import QApplication, QDialog, QMessageBox
from PySide6.QtGui import QFont, QFontDatabase
from PySide6.QtTest import QTest
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.core.settings import SettingsStore
from silverstar_fccg.project.reference import ReferenceProject_Create
from silverstar_fccg.project.model import HardwareConfiguration
from silverstar_fccg.project.resources import BoardResourceProvisions_Get
from silverstar_fccg.ui.main_window import MainWindow
app=QApplication([])
for font in ['msyh.ttc','msyhbd.ttc','segoeui.ttf','segoeuib.ttf']:
 QFontDatabase.addApplicationFont(str(Path('C:/Windows/Fonts')/font))
app.setFont(QFont('Microsoft YaHei',9))
service=FccgService(ROOT/'apps/FCCG')
report=[]
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
def persist():
 (OUT/'workflow.json').write_text(json.dumps({'source_commit':source,'method':'offscreen Qt, real application new/save/open/generate entry points; wizard text injected; configured reference fixture; no OS mouse/hardware','cases':report},ensure_ascii=False,indent=2),encoding='utf-8')
def wait(window):
 deadline=time.monotonic()+180
 while window._active_worker is not None and time.monotonic()<deadline:
  app.processEvents();QTest.qWait(10)
 app.processEvents()
 assert window._active_worker is None,'worker timeout'
for role,kind in [('flight','existing'),('ground','existing'),('flight','ioc'),('ground','ioc')]:
 name=role+'_'+kind
 root=OUT/name
 assert not root.exists(),root
 errors=[]
 window=MainWindow(SettingsStore(service.workspace_root/'.work/GUI_UserFlow_20261002_Settings'/ (name+'.ini')),service=service,language='zh_CN',theme='light')
 window._toolchain_checked=True
 window._Error_Show=lambda *args: errors.append([str(arg) for arg in args])
 window._MessageBox_Exec=lambda *args,**kw: QMessageBox.StandardButton.Ok
 with patch('silverstar_fccg.ui.main_window.NewProjectWizard') as wizard:
  wizard.return_value.exec.return_value=QDialog.DialogCode.Accepted
  wizard.return_value.WizardData_Get.return_value={'name':name,'output_directory':str(root)}
  window._NewProject_Show()
 assert not errors,errors
 assert all((root/p).is_dir() for p in ['Flight_Controller','Ground_Station','Log'])
 assert window._model.strategies['estimator']=='silverstar.algorithm.estimator.kf6'
 initial=window._model.Dictionary_Get()
 window._model=ReferenceProject_Create(name,catalog=service.catalog)
 if role=='ground':
  window._model.ground_target=replace(window._model.ground_target,enabled=True,board='silverstar.board.ground_station_0_5',mcu='silverstar.mcu.stm32f103c8t6',hardware=HardwareConfiguration(mode='board_plugin'),radio_plugin='silverstar.device.telemetry.sx1281',module_variant='e28_2g4m12sx',pc_interface='uart')
 window._model=service.ProjectConfiguration_Reconcile(window._model).model
 window._Project_Refresh()
 board=service.catalog.Component_Get('silverstar.board.'+('silverstar_0_5' if role=='flight' else 'ground_station_0_5'))
 mapping={p.resource_id:p.metadata['physical_resource'] for p in BoardResourceProvisions_Get(board)}
 imported_evidence=None
 if kind=='ioc':
  inputs=OUT/'Inputs'/role
  shutil.copytree(board.payload_root,inputs)
  inputs_hash={p.relative_to(inputs).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs.rglob('*') if p.is_file()}
  ioc=next(inputs.glob('*.ioc'))
  result=service.CubeMxProject_Import(ioc,window._model,risk_acknowledged=True)
  assert all(v in {r.resource_id for r in result.hardware.resources} for v in mapping.values()),mapping
  if role=='flight':
   assignments={k:mapping[v] for k,v in window._model.resource_assignments.items()}
   window._CubeMxImport_Complete(result)
   window._ProjectConfiguration_Change(lambda candidate:setattr(candidate,'resource_assignments',assignments))
  else:
   assignments={k:mapping[v] for k,v in window._model.ground_target.resource_assignments.items()}
   pc=mapping[window._model.ground_target.pc_resource]
   window._GroundCubeMxImport_Complete(result)
   window._ProjectConfiguration_Change(lambda candidate:setattr(candidate,'ground_target',replace(candidate.ground_target,resource_assignments=assignments,pc_resource=pc)))
  assert {p.relative_to(inputs).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs.rglob('*') if p.is_file()}==inputs_hash
  imported_evidence={'ioc':str(ioc),'snapshot':result.hardware.snapshot_id,'mapping':mapping,'input_hashes':inputs_hash,'scope':'repository full-board CubeMX software fixture, not new PCB or hardware validation'}
 window._Project_Save()
 assert not errors,errors
 saved=copy.deepcopy(window._model.Dictionary_Get())
 window._Project_Open(root)
 assert window._model.Dictionary_Get()==saved
 window._Targets_Generate('generate_'+role)
 wait(window)
 assert not errors,errors
 target=root/('Flight_Controller' if role=='flight' else 'Ground_Station')
 assert (target/'Makefile').is_file(),target
 opposite=root/('Ground_Station' if role=='flight' else 'Flight_Controller')
 assert not (opposite/'Makefile').exists()
 window._Project_Save()
 saved=copy.deepcopy(window._model.Dictionary_Get())
 window._Project_Open(root)
 assert window._model.Dictionary_Get()==saved
 report.append({'name':name,'root':str(root),'target':str(target),'role':role,'kind':kind,'new_project_folders':True,'default_kf6':True,'save_reopen_equal':True,'opposite_not_generated':True,'configuration':saved,'ioc':imported_evidence,'file_hashes':{p.relative_to(target).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in target.rglob('*') if p.is_file()}})
 persist();print('GENERATED',name,flush=True)
 window._project_state=type(window._project_state).DRAFT
 window.close();window.deleteLater();app.processEvents()
print('COMPLETE',flush=True)
