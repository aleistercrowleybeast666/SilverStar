import ctypes
ctypes.windll.kernel32.SetErrorMode(3)
import pytest
raise SystemExit(pytest.main(['-q','apps/FCCG/tests/test_custom_hardware_architecture.py','--basetemp=apps/FCCG/.work/GUI_UserFlow_20261002_CustomArch_v2','--junitxml=.work/GUI_UserFlow_20261002_v1/custom_architecture_tests_v2.xml']))
