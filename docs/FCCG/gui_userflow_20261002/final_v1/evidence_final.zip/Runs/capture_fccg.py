import hashlib,json,os,sys,copy
from pathlib import Path
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent/'FCCG_Pages'
OUT.mkdir(exist_ok=False)
sys.path.insert(0,str(ROOT/'apps/FCCG/src'));os.environ['QT_QPA_PLATFORM']='offscreen'
from PySide6.QtWidgets import QApplication,QScrollArea,QLabel,QCheckBox,QGroupBox
from PySide6.QtGui import QFont,QFontDatabase
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.core.settings import SettingsStore
from silverstar_fccg.ui.main_window import MainWindow
from silverstar_fccg.project.model import HardwareConfiguration
app=QApplication([])
for font in ['msyh.ttc','msyhbd.ttc','segoeui.ttf','segoeuib.ttf']:
 QFontDatabase.addApplicationFont(str(Path('C:/Windows/Fonts')/font))
app.setFont(QFont('Microsoft YaHei',9))
s=FccgService(ROOT/'apps/FCCG');source_root=ROOT/'.work/AutoMemory_Integrated_20261002_v2/KF6_auto_v1'
fixture=OUT/'GroundEnabledProject';model=copy.deepcopy(s.Project_Open(source_root))
model.identity=replace(model.identity,name='GUI_UserFlow_GroundEnabled')
model.ground_target=replace(model.ground_target,enabled=True,board='silverstar.board.ground_station_0_5',mcu='silverstar.mcu.stm32f103c8t6',hardware=HardwareConfiguration(mode='board_plugin'),radio_plugin='silverstar.device.telemetry.sx1281',module_variant='e28_2g4m12sx',pc_interface='uart')
model=s.ProjectConfiguration_Reconcile(model).model;s.ProjectRoot_Save(model,fixture,create_new=True)
report=[]
for language in ['zh_CN','en_US']:
 for theme in ['light','dark']:
  label=language+'_'+theme
  w=MainWindow(SettingsStore(s.workspace_root/'.work/GUI_UserFlow_20261002_CaptureSettings'/(label+'.ini')),service=s,language=language,theme=theme)
  w._toolchain_checked=True;w._Project_Open(fixture);w.resize(1360,920);w.show();app.processEvents()
  assert w._project_root==fixture.resolve()
  assert w._model.ground_target.pc_resource and w._model.ground_target.resource_assignments
  for index,code in enumerate(w.PAGE_CODES):
   w.navigation_list.setCurrentRow(index);app.processEvents()
   page=w.pages.currentWidget();image=label+'_'+code+'.png';assert w.grab().save(str(OUT/image))
   record={'language':language,'theme':theme,'page':code,'image':image,'root':str(w._project_root),'project_open':'MainWindow._Project_Open','sidebar_width':w.navigation_sidebar.width(),'visible_labels':[x.text() for x in page.findChildren(QLabel) if x.isVisible()],'visible_groups':[x.title() for x in page.findChildren(QGroupBox) if x.isVisible()],'checkboxes':[{'text':x.text(),'checked':x.isChecked(),'enabled':x.isEnabled(),'visible':x.isVisible()} for x in page.findChildren(QCheckBox)]}
   report.append(record)
  w._project_state=type(w._project_state).DRAFT;w.close();w.deleteLater();app.processEvents()
(OUT/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print('COMPLETE',len(report),flush=True)
