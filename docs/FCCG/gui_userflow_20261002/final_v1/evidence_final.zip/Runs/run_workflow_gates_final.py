import ctypes
ctypes.windll.kernel32.SetErrorMode(3)
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,os,subprocess,threading,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
workflow=json.loads((OUT/'Workflow_Final_v1/workflow.json').read_text(encoding='utf-8'))
assert len(workflow['cases'])==4
results=[];lock=threading.Lock();env=dict(os.environ);env['PATH']=str(ROOT/'.venv/Scripts')+os.pathsep+env['PATH']
def run(case):
 project=Path(case['target']);role=case['role']
 gates=[('arm',['-j4','CONFIG=Release','artifact-check']),('architecture',['architecture-check']),('power10',['power10-check'])]
 if role=='flight':gates.append(('resources',['CONFIG=Release','memory-report','stack-report']))
 for gate,args in gates:
  name='final_'+case['name']+'_'+gate;command=['mingw32-make',*args];log=OUT/(name+'.log');start=time.monotonic();print('BEGIN',name,flush=True)
  with log.open('wb') as stream:
   process=subprocess.Popen(command,cwd=project,env=env,stdout=stream,stderr=subprocess.STDOUT)
   try:code=process.wait(timeout=900)
   except subprocess.TimeoutExpired:
    stream.write(b'\nOWNED PROCESS TREE TIMEOUT; preserving failure.\n');stream.flush()
    subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],stdout=stream,stderr=subprocess.STDOUT,timeout=30)
    process.wait(timeout=30);code='TIMEOUT' 
  with lock:
   results.append({'name':name,'command':command,'cwd':str(project),'source_commit':workflow['source_commit'],'exit_code':code,'seconds':time.monotonic()-start,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
   (OUT/'workflow_gates_final.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
  print('END',name,code,flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,workflow['cases']))
artifacts={str(p.resolve()):hashlib.sha256(p.read_bytes()).hexdigest() for p in (OUT/'Workflow_Final_v1').rglob('*') if p.is_file() and p.suffix.lower() in ['.elf','.bin','.hex','.map','.ssproject','.ssdecoder']}
(OUT/'workflow_artifacts_final.json').write_text(json.dumps(artifacts,indent=2),encoding='utf-8')
print('COMPLETE',len(results),sum(r['exit_code']==0 for r in results),flush=True)
