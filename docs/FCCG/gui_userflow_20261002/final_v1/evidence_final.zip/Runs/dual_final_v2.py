import ctypes
ctypes.windll.kernel32.SetErrorMode(3)
import copy,hashlib,json,os,subprocess,sys,time
from dataclasses import replace
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent/'Dual_Final_v2';OUT.mkdir(exist_ok=False)
sys.path.insert(0,str(ROOT/'apps/FCCG/src'));os.environ['QT_QPA_PLATFORM']='offscreen'
from PySide6.QtCore import QEventLoop,QTimer
from PySide6.QtWidgets import QApplication,QMessageBox
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.core.settings import SettingsStore
from silverstar_fccg.ui.main_window import MainWindow
app=QApplication([]);service=FccgService(ROOT/'apps/FCCG');rows=[]
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
def wait(w):
 loop=QEventLoop();timer=QTimer();deadline=time.monotonic()+600
 timer.timeout.connect(lambda:loop.quit() if w._active_worker is None or time.monotonic()>deadline else None);timer.start(25);loop.exec();timer.stop()
 assert w._active_worker is None,'owned worker timeout'
for kind in ['existing','ioc']:
 root=OUT/('dual_'+kind)
 previous=Path(__file__).parent/'Workflow_Final_v1'
 model=copy.deepcopy(service.Project_Open(previous/('flight_'+kind)))
 ground=service.Project_Open(previous/('ground_'+kind))
 model.ground_target=copy.deepcopy(ground.ground_target);model.identity=replace(model.identity,name='dual_'+kind)
 service.ProjectRoot_Save(model,root,create_new=True)
 w=MainWindow(SettingsStore(service.workspace_root/'.work/GUI_UserFlow_20261002_DualSettings'/(kind+'.ini')),service=service,language='zh_CN',theme='light');w._toolchain_checked=True
 errors=[];w._Error_Show=lambda *a:errors.append([str(x) for x in a]);w._MessageBox_Exec=lambda *a,**kw:QMessageBox.StandardButton.Ok;w._DangerousPlan_Confirm=lambda plan:True
 w._Project_Open(root);w._Targets_Generate('generate_all');wait(w);assert not errors,errors
 assert all((root/target/'Makefile').is_file() for target in ['Flight_Controller','Ground_Station'])
 originals={}
 for relative in ['Flight_Controller/APP/UserNotes.txt','Ground_Station/APP/UserNotes.txt','Log/RecordedFixture.txt']:
  p=root/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b'isolated user-owned preservation fixture\n');originals[relative]=hashlib.sha256(p.read_bytes()).hexdigest()
 w._Targets_Generate('generate_all');wait(w);assert not errors,errors
 assert {r:hashlib.sha256((root/r).read_bytes()).hexdigest() for r in originals}==originals
 w._Project_Save();saved=json.loads(json.dumps(w._model.Dictionary_Get()));w._Project_Open(root);assert json.loads(json.dumps(w._model.Dictionary_Get()))==saved
 rows.append({'kind':kind,'root':str(root),'source_commit':source,'both_generated':True,'regeneration_preserved_user_payloads':originals,'save_reopen_equal':True,'method':'real Qt Project_Open, Targets_Generate(generate_all), Project_Save; offscreen, no OS mouse/hardware','configuration':saved})
 (OUT/'results.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8');print('COMPLETE',kind,flush=True)
 w._project_state=type(w._project_state).DRAFT;w.close();w.deleteLater();app.processEvents()
