import ctypes
ctypes.windll.kernel32.SetErrorMode(3)
import json,os,sys,hashlib
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[2];BASE=Path(__file__).parent;OUT=BASE/'FCCG_Details_Final_v2';OUT.mkdir(exist_ok=False)
sys.path.insert(0,str(ROOT/'apps/FCCG/src'));os.environ['QT_QPA_PLATFORM']='offscreen'
from PySide6.QtCore import QEventLoop,QTimer
from PySide6.QtWidgets import QApplication,QScrollArea,QFileDialog,QPlainTextEdit
from PySide6.QtGui import QFont,QFontDatabase
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.core.settings import SettingsStore
from silverstar_fccg.ui.main_window import MainWindow
from silverstar_fccg.build.runner import BuildAction,BuildResult
app=QApplication([])
for f in ['msyh.ttc','msyhbd.ttc','segoeui.ttf','segoeuib.ttf']:QFontDatabase.addApplicationFont(str(Path('C:/Windows/Fonts')/f))
app.setFont(QFont('Microsoft YaHei',9));service=FccgService(ROOT/'apps/FCCG');records=[]
def drain():
 loop=QEventLoop();QTimer.singleShot(50,loop.quit);loop.exec()
def reveal(widget):
 ancestor=widget.parentWidget()
 while ancestor is not None:
  if isinstance(ancestor,QScrollArea):ancestor.ensureWidgetVisible(widget,0,60)
  ancestor=ancestor.parentWidget()
 drain()
for theme in ['light','dark']:
 w=MainWindow(SettingsStore(service.workspace_root/'.work/GUI_UserFlow_20261002_DetailSettings'/(theme+'.ini')),service=service,language='zh_CN',theme=theme);w._toolchain_checked=True
 w._Project_Open(BASE/'FCCG_Pages_Final_v1/GroundEnabledProject');w.resize(1360,920);w.show();drain()
 w.navigation_list.setCurrentRow(w.PAGE_CODES.index('page.telemetry_configuration'));drain()
 for name,widget in [('crc',w.air_link_page.crc),('ground_enabled_uart',w.ground_target_page.enabled)]:
  reveal(widget);w.grab().save(str(OUT/(theme+'_'+name+'.png')));records.append({'image':theme+'_'+name+'.png','checked':widget.isChecked(),'visible':widget.isVisible(),'style_object':widget.objectName()})
 reveal(w.ground_target_page.pc_resource);w.grab().save(str(OUT/(theme+'_pc_uart_bottom.png')))
 w._Project_Open(BASE/'Workflow_Final_v1/flight_existing');w._MessageBox_Exec=lambda *a,**k:None;w._Error_Show=lambda *a:None
 for action,log in [(BuildAction.ARTIFACT_CHECK,'final_flight_existing_arm.log'),(BuildAction.POWER10_CHECK,'final_flight_existing_power10.log')]:
  data=(BASE/log).read_text(encoding='utf-8',errors='replace');w._Build_Complete(BuildResult(action,('mingw32-make',action.MakeTarget_Get()),0,data))
 w.navigation_list.setCurrentRow(w.PAGE_CODES.index('page.build'));drain();w.grab().save(str(OUT/(theme+'_actual_artifact_power10.png')))
 w.system_log_button.click();drain();dialog=w._system_log_dialog;text=dialog.findChild(QPlainTextEdit,'systemLogOutput').toPlainText()
 assert 'NOT_PROVEN' in text and 'full_path,file,line' in text and 'SystemTime_GetUtc' in text
 dialog.grab().save(str(OUT/(theme+'_system_log.png')))
 dialog.findChild(QPlainTextEdit,'systemLogOutput').verticalScrollBar().setValue(dialog.findChild(QPlainTextEdit,'systemLogOutput').verticalScrollBar().maximum());drain();dialog.grab().save(str(OUT/(theme+'_system_log_review.png')))
 export=OUT/(theme+'_actual_review.csv')
 with patch.object(QFileDialog,'getSaveFileName',return_value=(str(export),'CSV')):w._Power10Report_Export()
 assert export.is_file() and 'SystemTime_GetUtc' in export.read_text(encoding='utf-8-sig')
 records.append({'theme':theme,'method':'GUI result handler replay of actually executed fresh native gates; no invented PASS','native_log_sha256':{n:hashlib.sha256((BASE/n).read_bytes()).hexdigest() for n in ['final_flight_existing_arm.log','final_flight_existing_power10.log']},'power10_level':w.build_page.quality_result_labels['power10_check'].property('statusLevel'),'manual':'NOT_PROVEN','csv_sha256':hashlib.sha256(export.read_bytes()).hexdigest()})
 dialog.close();w._project_state=type(w._project_state).DRAFT;w.close();w.deleteLater();drain()
(OUT/'results.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8');print('COMPLETE',len(records),flush=True)
