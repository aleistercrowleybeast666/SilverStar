#include "system_project_parameters_if.h"
#include <stddef.h>
#include "silverstar_assert.h"

/* Generated from the selected manifest parameters and their actual values. */
#define PROJECT_MISSION_PARAMETER_COUNT 2U
static const SystemProjectParameter s_parameters[] =
{
    {0x0FA47BF5UL, 0x411C7AE1UL, SystemProjectParameterKind_Float32},
    {0x57E79461UL, 0x00000002UL, SystemProjectParameterKind_Int32},
};

uint16_t SystemProjectParameter_CountGet(void)
{ return PROJECT_MISSION_PARAMETER_COUNT; }

SystemProjectParameterResult SystemProjectParameter_Get(
    uint16_t index, SystemProjectParameter *parameter)
{
    if (parameter == NULL)
    { return SystemProjectParameterResult_InvalidArgument; }
    if (index >= PROJECT_MISSION_PARAMETER_COUNT)
    { return SystemProjectParameterResult_NotFound; }
    SILVERSTAR_ASSERT_OBJECT(parameter, SystemProjectParameter,
        SILVERSTAR_ASSERT_MODULE_GENERATED);
    *parameter = s_parameters[index];
    return SystemProjectParameterResult_Ok;
}
