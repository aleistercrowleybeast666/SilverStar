# SS_0_5_TEST_4

This standalone embedded project was assembled by SilverStar_FCCG from declarative source plugins.
Legacy and manual layouts build without FCCG or Python. Explicit auto linking requires Python 3.

The saved default memory layout is `legacy`. Old configurations without this
field default to `legacy`; existing manual `eskf_window_sram` behavior is preserved. Select `auto`
in FCCG's Build page or pass `MEMORY_LAYOUT=auto` to Make. Auto outputs use a separate build
directory and `memory_layout/decision.json` records every real link candidate and the decision.
At most 32 deterministic candidates place exact audited CPU-only static BSS groups; DMA buffers,
initialized data and task stack sizes remain fixed. No heap or runtime object movement is added.

Real physical region overflow remains a link error. Spare below 10% is red, over 20% is green,
and intermediate spare is yellow; low spare warns without blocking generation. Moving objects
does not add RAM or prove stack margin. In explicit auto mode the historical 100 KiB main-SRAM
logging regression budget is advisory; legacy/manual budget checks remain blocking. Current
dual-region support is F407 only; no-CCM uses ordinary SRAM without inventing another region.

- Default / Release build: `mingw32-make TARGET_PROFILE=SilverStar_F407 CONFIG=Release all`
- Debug build: `mingw32-make TARGET_PROFILE=SilverStar_F407 CONFIG=Debug all`
- Host tests: `mingw32-make host-tests`
- Architecture check: `mingw32-make architecture-check`
- Power of Ten project gate: `mingw32-make power10-check`
- GCC `-fanalyzer` static analysis: `mingw32-make CONFIG=Release static-analysis`
- Artifact check: `mingw32-make TARGET_PROFILE=SilverStar_F407 CONFIG=Release artifact-check`
- Log decoder profile: `SS_0_5_TEST_4.ssdecoder`
- Generation profile SHA-256: `d43f49a4a4daa7f104f0d0dce04282b91bf4022c66ad915a75980b977e6b6730`
- Log decoder package SHA-256: `dbd3dbff0423cb37cdd60e6d76ad2ed6f49a8d59682ac355426421db2faecf7c`

Component sources are ordinary project-owned files. FCCG may overwrite `Generated/`,
`SilverStar.ssproject`, `SilverStar_Configuration.md`, and generated editor/build metadata.

Make and native EIDE are rendered from the same resolved source graph. VS Code tasks invoke
the generated standalone project and do not modify global editor settings.

Power of Ten is a project compliance gate, not formal verification or safety certification.
Static analysis is the real Arm GNU GCC `-fanalyzer` pass over first-party firmware sources;
it is not a substitute for runtime tests, hardware tests, or formal verification.
