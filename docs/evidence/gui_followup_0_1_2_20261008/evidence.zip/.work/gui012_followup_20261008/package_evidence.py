from pathlib import Path
import hashlib,json,subprocess,zipfile,sys,datetime
import numpy,PySide6,shiboken6
r=Path.cwd();w=r/'.work/gui012_followup_20261008';e=r/'docs/evidence/gui_followup_0_1_2_20261008';e.mkdir(parents=True,exist_ok=False)
h=lambda b:hashlib.sha256(b).hexdigest();base='d601042b41cb0066f1442d8c82351c44f76fcace'
files=[*sorted(w.glob('*.py')),*sorted(w.glob('*.log')),w/'measurement_summary.json',*sorted((w/'gates').glob('*'))]
for folder in ['flp_before','flp_after','scg_eventloop','native_faults','native_sources_followup']:
 for f in (w/folder).iterdir():
  if f.suffix in ('.json','.txt','.png') and f.name not in ('paths.json',):files.append(f)
files += [r/'.work/gui012_20261008/run_pytest.py',r/'docs/evidence/nightly_software_20261008/normal_test_paths.py',r/'docs/evidence/nightly_software_20261008/closeout_test_paths.py']
sources=['apps/FLP/src/silverstar_flp/core/artifacts.py','apps/FLP/src/silverstar_flp/ui/main_window.py','apps/FLP/tests/test_open_refresh_once.py','apps/FLP/tests/test_serialization_progress.py','tests/integration/test_monorepo_baseline.py','docs/architecture/ARCHIVED_DOCUMENT_ORIGINS.json','docs/GUI_FOLLOWUP_0_1_2_20261008.md','docs/README.md']
snap={p:{'sha256_raw':h((r/p).read_bytes()),'sha256_lf':h((r/p).read_bytes().replace(b'\r\n',b'\n'))} for p in sources}
(e/'source_hashes.json').write_text(json.dumps(snap,indent=2),encoding='utf-8')
commands={
 'FLP43':"$env:QT_QPA_PLATFORM='offscreen'; apps/FLP/.venv/Scripts/python.exe .work/gui012_followup_20261008/run_pytest.py --basetemp=.work/fg9 -q apps/FLP/tests/test_open_refresh_once.py apps/FLP/tests/test_serialization_progress.py apps/FLP/tests/test_progress_visible_counts.py apps/FLP/tests/test_artifact_byte_progress.py apps/FLP/tests/test_project_stage_progress.py apps/FLP/tests/test_project_stage_progress_gui.py apps/FLP/tests/test_project_artifacts.py apps/FLP/tests/test_artifact_alias_reuse.py",
 'lifecycle7':'apps/FLP/.venv/Scripts/python.exe .work/gui012_followup_20261008/run_pytest.py --basetemp=.work/fr12 -q apps/FLP/tests/test_worker_retirement.py apps/FLP/tests/test_plot_menu_lifetime.py apps/FLP/tests/test_task_publication_thread_affinity.py',
 'integration':'apps/FLP/.venv/Scripts/python.exe .work/gui012_followup_20261008/run_pytest.py --basetemp=.work/mb14 -q tests/integration',
 'native':[f'apps/FLP/.venv/Scripts/python.exe .work/gui012_followup_20261008/{p}' for p in ['scg_eventloop.py','flp_loop_measure.py before','flp_loop_measure.py after','native_faults.py','native_sources_followup.py']],
 'gates':'apps/FLP/.venv/Scripts/python.exe .work/gui012_followup_20261008/gates.py'}
interrupt={'status':'INTERRUPTED / NOT COMPLETED','sessions':[16611,83125],'owned_python_pids':[33516,7992],'owned_wrapper_pids':[7136,36040],'reason':'Observed idle CPU and no fixture progress after long Windows basetemp paths; no native root-cause stack acquired. Only exact owned processes stopped. Short-basetemp run subsequently completed.','bad_filename_collection':'green_progress1.log','integration_initial_collection':'monorepo_all.log'}
manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_head':base,'branch':'fix/nightly-user-ready-20261003','product_version':'0.1.2','final_commit_binding':'Local final commit contains byte-equivalent LF-normalized sources in source_hashes.json; base_head is the measured starting revision, not final HEAD. No source edits after successful regression batches except report/index.','tool_versions':{'python':sys.version,'numpy':numpy.__version__,'pyside6':PySide6.__version__,'shiboken6':shiboken6.__version__},'commands':commands,'results':{'FLP_combined':{'exit':0,'passed':43,'seconds':262.05},'lifecycle_separate':{'exit':0,'passed':7,'seconds':19.95},'integration':{'exit':1,'passed':10,'failed':1,'seconds':20.73},'baseline':{'exit':1,'passed':7,'failed':1},'native_faults':{'exit':0},'native_sources':{'exit':0},'SCG_eventloop':{'exit':0,'stages':14},'architecture':json.loads((w/'gates/architecture-check.json').read_text()),'power10':json.loads((w/'gates/power10-check.json').read_text())},'interruptions':interrupt,'critical_contract':'NOT PROVEN','historical_native_abort':'FAIL / NOT PROVEN','stack_metadata':'FAIL, unauthorized hash not added','ARM_Host_analyzer_this_phase':'NOT_RUN, unchanged owning C sources; earlier results belong to earlier snapshots','hardware':False,'field_candidate_generated':False,'no_math_queue_protocol_ack_changes':True,'files':{},'inputs':{},'preserved_inventory':{}}
for p in [r/'.work/gui012_20261008/native3/actual.ssflp',r/'.work/gui012_20261008/native3/larger.ssflp',r/'.work/tf51_release_readonly_20261008/p51_v2/mission51.ssflp']:
 manifest['inputs'][p.relative_to(r).as_posix()]={'sha256':h(p.read_bytes()),'size':p.stat().st_size,'unchanged_input':True}
for p in r.glob('work_*_20261006.*'):manifest['preserved_inventory'][p.name]=h(p.read_bytes())
with zipfile.ZipFile(e/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:
  name=p.relative_to(r).as_posix();b=p.read_bytes();manifest['files'][name]={'sha256':h(b),'size':len(b)};z.writestr(name,b)
 for p in sources:z.writestr('source_snapshot/'+p,(r/p).read_bytes())
 for p in sources[:2]:z.writestr('before_source/'+p,subprocess.check_output(['git','show',base+':'+p]))
 z.writestr('commands.json',json.dumps(commands,indent=2));z.writestr('interruptions.json',json.dumps(interrupt,indent=2));z.writestr('source_hashes.json',json.dumps(snap,indent=2))
manifest['evidence_zip']={'sha256':h((e/'evidence.zip').read_bytes()),'size':(e/'evidence.zip').stat().st_size}
(e/'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8');(e/'.gitattributes').write_text('*.json -text\n*.zip -text\n',encoding='ascii')
print(json.dumps({'zip':manifest['evidence_zip'],'files':len(files),'inventories':manifest['preserved_inventory']},indent=2))
