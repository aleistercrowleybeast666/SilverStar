from pathlib import Path
import os,subprocess,json,time,datetime,hashlib
r=Path.cwd();o=r/'.work/gui012_followup_20261008/gates';o.mkdir(exist_ok=False)
p=r/'.work/gui012_20261008/software/project/Flight_Controller';make='D:/msys64/ucrt64/bin/mingw32-make.exe'
env=dict(os.environ,PATH=str(r/'apps/FLP/.venv/Scripts')+';D:/msys64/ucrt64/bin;D:/Arm GNU Toolchain/14.3 rel1/bin;'+os.environ['PATH'])
for n in ['architecture-check','power10-check']:
 cmd=[make,n];s=time.monotonic();record={'command':cmd,'cwd':str(p),'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fixture_reused':True,'no_generation':True,'base_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()}
 with (o/(n+'.log')).open('xb') as f:result=subprocess.run(cmd,cwd=p,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120)
 record.update(exit_code=result.returncode,seconds=time.monotonic()-s,log_sha256=hashlib.sha256((o/(n+'.log')).read_bytes()).hexdigest())
 (o/(n+'.json')).write_text(json.dumps(record,indent=2),encoding='utf-8');print(n,result.returncode,flush=True)
