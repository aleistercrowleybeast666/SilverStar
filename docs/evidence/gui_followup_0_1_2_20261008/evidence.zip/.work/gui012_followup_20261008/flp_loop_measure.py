from pathlib import Path
import os,sys,time,json,traceback,cProfile,pstats,io
os.environ['QT_QPA_PLATFORM']='windows';os.environ['OPENBLAS_NUM_THREADS']='1'
repo=Path.cwd();kind=sys.argv[1];out=Path(__file__).resolve().parent/('flp_'+kind);out.mkdir(exist_ok=False)
sys.path[:0]=[str(repo/'apps/FLP/src'),str(repo/'apps/FLP')]
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QTimer,QSettings,Qt
from silverstar_flp.ui import main_window as module
from silverstar_flp.plugins.registry import builtin_registry
from silverstar_flp.core.path_preferences import PathPreferences
from silverstar_flp.plugins.container_packages import TrustedContainerPluginManager
from silverstar_flp.decoder_profiles.discovery import DecoderProfileCache
app=QApplication([]);app.setQuitOnLastWindowClosed(False)
module.QSettings=lambda *a,**k:QSettings(str(out/'settings.ini'),QSettings.Format.IniFormat)
w=module.MainWindow(builtin_registry(),language='zh_CN',path_preferences=PathPreferences(out/'paths.json'),plugin_manager=TrustedContainerPluginManager(out/'plugins'))
w._log_open_coordinator.cache=DecoderProfileCache(out/'decoder');errors=[];w._Error_Show=lambda e:errors.append(str(e));w.show()
beats=[];progress=[];publications=[];profile=cProfile.Profile();original_publish=w._Task_ResultPublish
def publish(*args,**kwargs):
    started=time.perf_counter();value=profile.runcall(original_publish,*args,**kwargs);publications.append({'phase':phase[0],'seconds':time.perf_counter()-started});return value
w._Task_ResultPublish=publish
original_start=w._Task_Start
def start(worker,*args,**kwargs):
    original_start(worker,*args,**kwargs)
    worker.signals.progress.connect(lambda value,code:progress.append({'phase':phase[0],'time':time.perf_counter(),'value':value,'code':code,'bar':w.progress_bar.text(),'status':w.status_label.text()}),Qt.ConnectionType.QueuedConnection)
w._Task_Start=start
timer=QTimer();timer.setInterval(20);timer.timeout.connect(lambda:beats.append({'phase':phase[0],'time':time.perf_counter()}));timer.start()
phase=['startup'];steps=[('open_actual',lambda:w._Project_Open(repo/'.work/gui012_20261008/native3/actual.ssflp')),('save_actual',lambda:w._Project_Write(out/'actual.ssflp',background=True,save_data=True)),('open_large',lambda:w._Project_Open(repo/'.work/gui012_20261008/native3/larger.ssflp')),('save_large',lambda:w._Project_Write(out/'large.ssflp',background=True,save_data=True))];started={};durations=[];failure=[]
def next_step():
    if phase[0] in started:
        durations.append({'phase':phase[0],'seconds':time.perf_counter()-started[phase[0]],'runs':len(w._replay_store.Entries_Get()),'progress_value':w.progress_bar.value()})
    if errors:failure.extend(errors);finish();return
    if not steps:finish();return
    name,fn=steps.pop(0);phase[0]=name;started[name]=time.perf_counter()
    try:
        fn();QTimer.singleShot(20,poll)
    except Exception:failure.append(traceback.format_exc());finish()
def poll():
    if w._active_worker is None:QTimer.singleShot(150,next_step)
    else:QTimer.singleShot(20,poll)
def finish():
    timer.stop();result={'normal_event_loop':True,'durations':durations,'publications_profiled':publications,'beats':beats,'progress':progress,'failures':failure}
    (out/'result.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8');stream=io.StringIO();pstats.Stats(profile,stream=stream).sort_stats('cumulative').print_stats(35);(out/'publication_profile.txt').write_text(stream.getvalue(),encoding='utf-8');w._Project_SetDirty(False);w.close();app.quit();print(json.dumps({'durations':durations,'publications':publications,'failures':failure},indent=2),flush=True)
QTimer.singleShot(250,next_step);QTimer.singleShot(240000,lambda:(w._Task_Cancel(),failure.append('deadline'),QTimer.singleShot(1000,poll)))
app.exec();raise SystemExit(bool(failure))
