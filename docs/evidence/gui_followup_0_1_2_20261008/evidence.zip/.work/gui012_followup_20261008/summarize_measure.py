from pathlib import Path
import json
root=Path(__file__).resolve().parent;summary={}
for kind in ['before','after']:
    data=json.loads((root/('flp_'+kind)/'result.json').read_text(encoding='utf-8'));phases=[]
    for item in data['durations']:
        phase=item['phase'];beats=[row['time'] for row in data['beats'] if row['phase']==phase];progress=[row for row in data['progress'] if row['phase']==phase];nine=[row for row in progress if .09<=row['value']<.10]
        pairs=list(zip(progress,progress[1:]));worst=max(pairs,key=lambda p:p[1]['time']-p[0]['time']) if pairs else None
        phases.append({**item,'heartbeat_max_gap_s':max((b-a for a,b in zip(beats,beats[1:])),default=0),'progress_max_gap_s':worst[1]['time']-worst[0]['time'] if worst else None,'progress_events':len(progress),'distinct_bar_values':len({int(row['value']*1000) for row in progress}),'nine_percent_span_s':nine[-1]['time']-nine[0]['time'] if nine else 0,'nine_percent_events':len(nine),'publication_s':next(row['seconds'] for row in data['publications_profiled'] if row['phase']==phase)})
    summary[kind]={'phases':phases,'failures':data['failures']}
(root/'measurement_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(json.dumps(summary,indent=2))
