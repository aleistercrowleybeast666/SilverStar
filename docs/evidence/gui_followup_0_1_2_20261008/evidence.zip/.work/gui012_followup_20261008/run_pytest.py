from pathlib import Path
import sys,faulthandler,runpy
sys.path.insert(0, str(Path.cwd()))
faulthandler.enable()
faulthandler.dump_traceback_later(90, repeat=True)
try:
    runpy.run_path(str(Path(__file__).resolve().parents[1]/'gui012_20261008/run_pytest.py'),run_name='__main__')
finally:
    faulthandler.cancel_dump_traceback_later()
