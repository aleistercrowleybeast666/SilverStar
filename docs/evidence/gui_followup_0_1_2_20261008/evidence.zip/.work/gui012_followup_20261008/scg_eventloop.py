from pathlib import Path
import os,sys,time,json,traceback,dataclasses
os.environ['QT_QPA_PLATFORM']='windows'
repo=Path.cwd();out=Path(__file__).resolve().parent/'scg_eventloop';out.mkdir(exist_ok=False)
sys.path.insert(0,str(repo/'apps/SCG/src'))
from PySide6.QtWidgets import QApplication,QMessageBox,QFormLayout
from PySide6.QtCore import Qt,QTimer,QPoint,QCoreApplication,QEvent
from PySide6.QtTest import QTest
from silverstar_fccg.ui.main_window import MainWindow
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.core.settings import SettingsStore
from silverstar_fccg.project.reference import ReferenceProject_Create
from silverstar_fccg.project.model import ProjectModel_Save
app=QApplication([]);assert app.platformName()=='windows'
settings=repo/'apps/SCG/.work/gui012-followup-eventloop/settings.ini';settings.parent.mkdir(parents=True,exist_ok=False)
w=MainWindow(SettingsStore(settings),service=FccgService(repo/'apps/SCG'));errors=[];w._Error_Show=lambda e:errors.append(str(e));w._MessageBox_Exec=lambda *a,**k:QMessageBox.StandardButton.Discard
w._model=ReferenceProject_Create(catalog=w._service.catalog);first=w._model.DeviceInstance_Get('imu0');w._Project_Refresh();w.show()
observations=[];durations=[];failure=[]
def check(name):
    QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete)
    page=w.devices_page
    forms=[page.feature_tier_combo.parentWidget().layout(),page.primary_form,page.other_form]
    row_geometry=[];overlaps=[]
    for fi,form in enumerate(forms):
        widgets=[]
        for i in range(form.count()):
            item=form.itemAt(i);widget=item.widget()
            if widget is not None and widget.isVisible():
                rect=widget.geometry();widgets.append((i,widget,rect));row_geometry.append({'form':fi,'item':i,'type':type(widget).__name__,'rect':rect.getRect(),'size_hint':widget.sizeHint().toTuple(),'minimum':widget.minimumSizeHint().toTuple()})
        for i,a,ra in widgets:
            for j,b,rb in widgets:
                if i<j and ra.intersects(rb):overlaps.append({'form':fi,'items':[i,j],'intersection':ra.intersected(rb).getRect()})
    w.grab().save(str(out/(name+'.png')))
    observations.append({'stage':name,'tier':w._model.build.feature_tier,'instances':[i.instance_id for i in w._model.device_instances],'forms':row_geometry,'overlaps':overlaps,'errors':list(errors)})
def add():QTest.mouseClick(w.devices_page.add_buttons['imu'],Qt.MouseButton.LeftButton)
def remove():
    extra=next(i.instance_id for i in w._model.device_instances if i.instance_id!='imu0' and w._service.Plugin_Get(i.plugin).component_class=='imu')
    w.devices_page.device_combos[extra].setCurrentIndex(0)
def tier(value):w.devices_page.feature_tier_combo.setCurrentIndex(w.devices_page.feature_tier_combo.findData(value))
def compact_check():
    assert w._model.DeviceInstance_Get('imu0')==first and w._model.DeviceInstance_Get('imu1') is None
def minimal_check():
    compact_check();assert not any(w._service.Plugin_Get(i.plugin).component_class=='gnss' for i in w._model.device_instances)
def restored_check():minimal_check()
project=settings.parent/'project'
def save():
    project.mkdir();ProjectModel_Save(w._model,project/'SilverStar.ssproject',w._service.policy);w._project_root=project;w._Project_Save()
steps=[('initial',lambda:None),('two_imu',add),('compact',lambda:tier('compact')),('compact_check',compact_check),('minimal',lambda:tier('minimal')),('minimal_check',minimal_check),('full_return',lambda:tier('full')),('full_check',restored_check)]
steps += [(f'rapid_{i}',lambda:(add(),remove(),add(),remove(),tier('compact'),tier('minimal'),tier('full'))) for i in range(3)]
steps += [('save',save),('reopen',lambda:w._Project_Open(project)),('reopen_check',restored_check)]
def next_step():
    if not steps:
        finish();return
    name,fn=steps.pop(0)
    try:
        t=time.perf_counter();fn();durations.append({'stage':name,'callback_s':time.perf_counter()-t});assert not errors,errors
        QTimer.singleShot(250,lambda:observed(name))
    except Exception:failure.append(traceback.format_exc());finish()
def observed(name):
    try:check(name);QTimer.singleShot(0,next_step)
    except Exception:failure.append(traceback.format_exc());finish()
def finish():
    result={'platform':app.platformName(),'normal_QApplication_exec':True,'explicit_DeferredDelete':True,'observations':observations,'durations':durations,'failures':failure}
    (out/'result.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8');print(json.dumps({'overlap_stages':[o['stage'] for o in observations if o['overlaps']],'failures':failure},indent=2),flush=True)
    w.close();QTimer.singleShot(0,app.quit)
QTimer.singleShot(250,next_step);QTimer.singleShot(180000,lambda:(failure.append('timeout'),finish()))
app.exec();raise SystemExit(bool(failure))
