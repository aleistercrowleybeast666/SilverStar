from pathlib import Path
import os,sys,time,json,hashlib,dataclasses,threading,errno
os.environ['QT_QPA_PLATFORM']='windows'
os.environ['OPENBLAS_NUM_THREADS']='1'
repo=Path.cwd();root=Path(__file__).resolve().parent/'native_faults'
root.mkdir(exist_ok=False)
sys.path[:0]=[str(repo/'apps/SCG/src'),str(repo/'apps/FLP/src'),str(repo/'apps/FLP')]
import numpy as np
from PySide6.QtCore import Qt,QTimer,QSettings,QEventLoop,QCoreApplication,QEvent
from PySide6.QtWidgets import QApplication,QMessageBox
from PySide6.QtTest import QTest
from silverstar_fccg.ui.main_window import MainWindow as ScgWindow
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.core.settings import SettingsStore
from silverstar_fccg.project.reference import ReferenceProject_Create
from silverstar_fccg.project.model import ProjectModel_Save
from silverstar_fccg.generator.source_graph import SourceGraph_Resolve

app=QApplication([]);assert app.platformName()=='windows'
errors=[]
import silverstar_flp.ui.main_window as module
import silverstar_flp.core.artifacts as artifacts
from silverstar_flp.plugins.registry import builtin_registry
from silverstar_flp.decoder_profiles.discovery import DecoderProfileCache
from silverstar_flp.core.path_preferences import PathPreferences
from silverstar_flp.plugins.container_packages import TrustedContainerPluginManager
from silverstar_flp.core.project import Project_Load
from tests.test_project_artifacts import _Assert_Result
module.QSettings=lambda *a,**k:QSettings(str(root/'flp.ini'),QSettings.Format.IniFormat)
w=module.MainWindow(builtin_registry(),language='zh_CN',path_preferences=PathPreferences(root/'paths.json'),plugin_manager=TrustedContainerPluginManager(root/'plugins'))
w._log_open_coordinator.cache=DecoderProfileCache(root/'decoder')
w._Error_Show=errors.append;w.show();app.processEvents()
observations=[];beats=[];timer=QTimer();timer.setInterval(50);timer.timeout.connect(lambda:beats.append(time.perf_counter()));timer.start()
original_start=w._Task_Start
def start(worker,*args,**kwargs):
    original_start(worker,*args,**kwargs)
    worker.signals.progress.connect(lambda value,code:observations.append({'t':time.perf_counter(),'value':value,'code':code,'text':w.progress_bar.text(),'status':w.status_label.text()}),Qt.ConnectionType.QueuedConnection)
w._Task_Start=start
def finish(timeout=120):
    if w._active_worker is None:return
    loop=QEventLoop();poll=QTimer();poll.setInterval(10)
    poll.timeout.connect(lambda:loop.quit() if w._active_worker is None else None)
    poll.start();QTimer.singleShot(int(timeout*1000),loop.quit);loop.exec();poll.stop()
    QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete)
    assert w._active_worker is None,'timeout'
source=repo/'.work/tf51_release_readonly_20261008/p51_v2/mission51.ssflp'
w._Project_Open(source);finish();assert not errors,errors
assert len(w._replay_store.Entries_Get())==2
real_entries=w._replay_store.Entries_Get()
path=root/'actual.ssflp'
assert w._Project_Write(path,background=True,save_data=True);finish();assert not errors,errors
w._Project_Open(path);finish();assert not errors,errors
for a,b in zip(real_entries,w._replay_store.Entries_Get()):_Assert_Result(a.result,b.result)
# Reuse the exact existing ten-run persistence-only sample. No new numerical work.
w._Project_Open(repo/'.work/gui012_20261008/native3/larger.ssflp');finish();assert not errors,errors
synthetic_bytes=271843328
large_entries=w._replay_store.Entries_Get();assert len(large_entries)==10
large=root/'larger.ssflp';before=len(observations);started=time.perf_counter()
assert w._Project_Write(large,background=True,save_data=True);finish(180);assert not errors,errors
large_observations=observations[before:];large_seconds=time.perf_counter()-started
w._Project_Open(large);finish(180);assert not errors,errors
assert len(w._replay_store.Entries_Get())==10
for a,b in zip(large_entries,w._replay_store.Entries_Get()):_Assert_Result(a.result,b.result)
assert all('%' in row['text'] for row in observations if '|' in row['code'])
assert w.progress_bar.value()==1000
# Cancellation and deferred close during a real artifact write must preserve the
# prior atomic project. The bounded hold is test fault injection, never fake progress.
original_write=artifacts._ProgressStream.write
faults=[]
for mode in ['cancel','close']:
    before_hash=hashlib.sha256(large.read_bytes()).hexdigest();entered=threading.Event();release=threading.Event()
    def held(stream,data):
        if not entered.is_set():
            entered.set();assert release.wait(5)
        return original_write(stream,data)
    artifacts._ProgressStream.write=held
    try:
        w._Project_SetDirty(False)
        assert w._Project_Write(large,background=True,save_data=True)
        deadline=time.monotonic()+4
        while not entered.is_set() and time.monotonic()<deadline:app.processEvents();QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete);time.sleep(.005)
        assert entered.is_set()
        if mode=='cancel':w._Task_Cancel()
        else:w.close()
        release.set();finish()
        if mode=='cancel':
            assert hashlib.sha256(large.read_bytes()).hexdigest()==before_hash
            assert w.progress_bar.value()<1000
            faults.append({'mode':mode,'prior_project_preserved':True})
        else:
            assert w.progress_bar.value()==1000
            assert w._project.project_path==large
            faults.append({'mode':mode,'atomic_commit_completed_before_close':True})
    finally:release.set();artifacts._ProgressStream.write=original_write
    w.show();app.processEvents()
before_hash=hashlib.sha256(large.read_bytes()).hexdigest()
def full_disk(stream,data):raise OSError(errno.ENOSPC,'Controlled disk-full write')
artifacts._ProgressStream.write=full_disk
try:
    assert w._Project_Write(large,background=True,save_data=True);finish()
    assert errors and w.progress_bar.value()<1000
    assert hashlib.sha256(large.read_bytes()).hexdigest()==before_hash
    faults.append({'mode':'disk_full','prior_project_preserved':True,'errors':[str(e) for e in errors]});errors.clear()
finally:artifacts._ProgressStream.write=original_write
# Configuration-only reopen may retain history parameters, but never replay.
config=root/'configuration.ssflp'
assert w._Project_Write(config,background=True,save_data=False);finish()
w._Project_Open(config);finish();QTest.qWait(50)
assert errors and all(str(e).startswith('project_result_recompute_required:') for e in errors),errors
configuration_notices=list(errors);errors.clear()
assert w._dataset is not None
assert not w._replay_store.Entries_Get()
assert not Project_Load(config).save_data_and_results
timer.stop();w.grab().save(str(root/'flp.png'))
result={'native_platform':app.platformName(),'real_mission':51,'actual_two_runs_roundtrip':True,'controlled_run_count':10,'controlled_array_bytes':synthetic_bytes,'large_save_seconds':large_seconds,'large_progress_event_count':len(large_observations),'large_progress_numeric':True,'ui_heartbeat_max_gap_s':max(np.diff(beats)) if len(beats)>1 else None,'faults':faults,'configuration_only_no_replay':True,'configuration_notices':configuration_notices,'errors':errors,'observations':observations}
(root/'flp_result.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8')
w._Project_SetDirty(False);w.close();app.processEvents()
print(json.dumps({key:value for key,value in result.items() if key!='observations'},indent=2),flush=True)
