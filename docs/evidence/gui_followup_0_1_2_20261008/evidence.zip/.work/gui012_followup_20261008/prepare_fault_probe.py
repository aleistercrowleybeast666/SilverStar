from pathlib import Path
repo=Path.cwd();out=Path(__file__).resolve().parent
source=(repo/'.work/gui012_20261008/native_acceptance_v3.py').read_text(encoding='utf-8')
prefix=source[:source.index('settings=repo/')]
prefix=prefix.replace("root=Path(__file__).resolve().parent/'native3'","root=Path(__file__).resolve().parent/'native_faults'")
prefix=prefix.replace('QSettings','QSettings,QEventLoop,QCoreApplication,QEvent',1)
body=source[source.index('import silverstar_flp.ui.main_window as module'):]
start=body.index('# Controlled larger sample:')
end=body.index("large_entries=w._replay_store.Entries_Get()",start)
body=body[:start]+"# Reuse the exact existing ten-run persistence-only sample. No new numerical work.\nw._Project_Open(repo/'.work/gui012_20261008/native3/larger.ssflp');finish();assert not errors,errors\nsynthetic_bytes=271843328\n"+body[end:]
body=body.replace('app.processEvents();time.sleep(.005)','app.processEvents();QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete);time.sleep(.005)')
# Use a normal Qt event loop while awaiting worker completion, preserving its
# real cancellation/publication path and allowing normal timer/paint dispatch.
a=body.index('def finish(timeout=120):');b=body.index('source=repo/',a)
body=body[:a]+'''def finish(timeout=120):
    if w._active_worker is None:return
    loop=QEventLoop();poll=QTimer();poll.setInterval(10)
    poll.timeout.connect(lambda:loop.quit() if w._active_worker is None else None)
    poll.start();QTimer.singleShot(int(timeout*1000),loop.quit);loop.exec();poll.stop()
    QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete)
    assert w._active_worker is None,'timeout'
'''+body[b:]
body=body.replace("w._Project_Open(config);finish();app.processEvents()","w._Project_Open(config);finish();QTest.qWait(50)")
(out/'native_faults.py').write_text(prefix+'errors=[]\n'+body,encoding='utf-8')
