#include "system_project_parameters_if.h"
#include <stddef.h>
#include "silverstar_assert.h"

/* Generated from the selected manifest parameters and their actual values. */
#define PROJECT_MISSION_PARAMETER_COUNT 41U
static const SystemProjectParameter s_parameters[] =
{
    {0x0FA47BF5UL, 0x411C7AE1UL, SystemProjectParameterKind_Float32},
    {0x57E79461UL, 0x00000002UL, SystemProjectParameterKind_Int32},
    {0x5D30FAEEUL, 0x411C7AE1UL, SystemProjectParameterKind_Float32},
    {0x4C6942EDUL, 0x40800000UL, SystemProjectParameterKind_Float32},
    {0x4169319CUL, 0x40800000UL, SystemProjectParameterKind_Float32},
    {0x3C6929BDUL, 0x41100000UL, SystemProjectParameterKind_Float32},
    {0x3802CBB1UL, 0x3E800000UL, SystemProjectParameterKind_Float32},
    {0x2D02BA60UL, 0x3E800000UL, SystemProjectParameterKind_Float32},
    {0x4802E4E1UL, 0x3E800000UL, SystemProjectParameterKind_Float32},
    {0xF98E17FBUL, 0x3FC00000UL, SystemProjectParameterKind_Float32},
    {0xF28E0CF6UL, 0x3FC00000UL, SystemProjectParameterKind_Float32},
    {0xE98DFECBUL, 0x40000000UL, SystemProjectParameterKind_Float32},
    {0xCA215657UL, 0x3FC00000UL, SystemProjectParameterKind_Float32},
    {0x6F455839UL, 0x40200000UL, SystemProjectParameterKind_Float32},
    {0x7C39123EUL, 0x3E19999AUL, SystemProjectParameterKind_Float32},
    {0x65B3C3BDUL, 0x40200000UL, SystemProjectParameterKind_Float32},
    {0xBF1932C8UL, 0x40D451ECUL, SystemProjectParameterKind_Float32},
    {0x94289DEDUL, 0x412D3F7DUL, SystemProjectParameterKind_Float32},
    {0xADE166B9UL, 0x41135C29UL, SystemProjectParameterKind_Float32},
    {0x854FE1B0UL, 0x415D0E56UL, SystemProjectParameterKind_Float32},
    {0x76C54CF2UL, 0x4135851FUL, SystemProjectParameterKind_Float32},
    {0x4D0685A7UL, 0x418220C5UL, SystemProjectParameterKind_Float32},
    {0xC56A9B30UL, 0x41200000UL, SystemProjectParameterKind_Float32},
    {0xBDC538F2UL, 0x3FE00000UL, SystemProjectParameterKind_Float32},
    {0xB261CA89UL, 0x0000012CUL, SystemProjectParameterKind_Int32},
    {0x0E35E0F8UL, 0x00000000UL, SystemProjectParameterKind_Int32},
    {0xC497E0BCUL, 0x0000010EUL, SystemProjectParameterKind_Int32},
    {0x8A2C4375UL, 0x00000000UL, SystemProjectParameterKind_Int32},
    {0x5B38B4A8UL, 0x00000001UL, SystemProjectParameterKind_Int32},
    {0x34E7E19DUL, 0x00000078UL, SystemProjectParameterKind_Int32},
    {0x3B96025BUL, 0x41200000UL, SystemProjectParameterKind_Float32},
    {0x5E52EF14UL, 0x40800000UL, SystemProjectParameterKind_Float32},
    {0x45F62A5EUL, 0x000007D0UL, SystemProjectParameterKind_Int32},
    {0x7F1D2BDAUL, 0x00001388UL, SystemProjectParameterKind_Int32},
    {0x9ACF9962UL, 0x00001F40UL, SystemProjectParameterKind_Int32},
    {0x5005F5C0UL, 0x40800000UL, SystemProjectParameterKind_Float32},
    {0x66F6775FUL, 0x40C00000UL, SystemProjectParameterKind_Float32},
    {0x38E50BD9UL, 0x3F99999AUL, SystemProjectParameterKind_Float32},
    {0x1523DFA8UL, 0x00000001UL, SystemProjectParameterKind_Int32},
    {0x443F7165UL, 0x00000001UL, SystemProjectParameterKind_Int32},
    {0x44D0C042UL, 0x00000000UL, SystemProjectParameterKind_Int32},
};

uint16_t SystemProjectParameter_CountGet(void)
{ return PROJECT_MISSION_PARAMETER_COUNT; }

SystemProjectParameterResult SystemProjectParameter_Get(
    uint16_t index, SystemProjectParameter *parameter)
{
    if (parameter == NULL)
    { return SystemProjectParameterResult_InvalidArgument; }
    if (index >= PROJECT_MISSION_PARAMETER_COUNT)
    { return SystemProjectParameterResult_NotFound; }
    SILVERSTAR_ASSERT_OBJECT(parameter, SystemProjectParameter,
        SILVERSTAR_ASSERT_MODULE_GENERATED);
    *parameter = s_parameters[index];
    return SystemProjectParameterResult_Ok;
}
