build/FCCG/SilverStar_F407/Release/APP/Src/estimator_bus.o: \
 APP/Src/estimator_bus.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 APP/Inc/estimator_bus.h Interfaces/Inc/system_device_types.h \
 Common/Inc/silverstar_compiler.h Platform/Inc/platform_critical.h \
 Platform/Inc/platform_memory.h Common/Inc/silverstar_assert.h \
 Common/Inc/silverstar_compiler.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
APP/Inc/estimator_bus.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
Platform/Inc/platform_critical.h:
Platform/Inc/platform_memory.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
