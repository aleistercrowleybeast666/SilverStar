build/FCCG/SilverStar_F407/Release/auto/Algorithm/Estimator/ESKF15/Src/navigation_eskf_backend.o: \
 Algorithm/Estimator/ESKF15/Src/navigation_eskf_backend.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 Interfaces/Inc/system_navigation_backend.h \
 Interfaces/Inc/system_device_types.h Common/Inc/silverstar_compiler.h \
 Interfaces/Inc/system_gnss_if.h APP/Inc/estimator_task.h \
 Interfaces/Inc/system_device_types.h \
 System/Inc/system_estimator_diagnostics.h \
 System/Alignment/Inc/system_alignment.h \
 System/Inc/system_configuration_types.h Platform/Inc/platform_memory.h \
 Algorithm/Estimator/ESKF15/Inc/navigation_eskf_replay.h \
 Algorithm/Estimator/ESKF15/Inc/navigation_eskf.h \
 Algorithm/Estimator/ESKF15/Inc/navigation_eskf_horizon.h \
 Algorithm/Estimator/ESKF15/Inc/navigation_eskf_replay.h \
 Algorithm/Estimator/ESKF15/Inc/navigation_eskf_config.h \
 Algorithm/Common/Inc/navigation_quality.h \
 Algorithm/Common/Inc/geodesy_local.h APP/Inc/estimator_bus.h \
 System/Inc/system_navigation_health.h \
 System/Inc/system_source_selector.h System/Inc/system_time.h \
 System/Calibration/Inc/system_calibration.h \
 Algorithm/Calibration/Inc/imu_six_face_calibration.h \
 System/Inertial/Inc/system_inertial_types.h \
 Interfaces/Inc/system_imu_epoch_if.h System/Inc/system_gnss_quality.h \
 Interfaces/Inc/system_gnss_if.h System/User/system_user_config.h \
 System/User/system_user_flight_config.h \
 Targets/SilverStar_F407/Inc/target_system_config.h \
 System/Inc/system_capabilities.h \
 System/User/system_user_alignment_config.h \
 System/User/system_user_capability_validation.h \
 System/User/system_user_platform_capabilities.h \
 System/Inc/system_fusion_timing.h \
 Generated/Inc/project_device_instances.h \
 Interfaces/Inc/system_barometer_if.h \
 Interfaces/Inc/system_descriptor_if.h \
 Interfaces/Inc/system_hardware_quaternion_if.h \
 Interfaces/Inc/system_imu_if.h Interfaces/Inc/system_imu_epoch_if.h \
 Interfaces/Inc/system_magnetometer_if.h Interfaces/Inc/system_power_if.h \
 Interfaces/Inc/system_telemetry_transport_if.h \
 Common/Inc/silverstar_assert.h Common/Inc/silverstar_compiler.h \
 APP/Inc/logger_bus.h Protocol/SSLOG/Inc/sslog_protocol.h \
 Protocol/SSLOG/Inc/sslog_records.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
Interfaces/Inc/system_navigation_backend.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
Interfaces/Inc/system_gnss_if.h:
APP/Inc/estimator_task.h:
Interfaces/Inc/system_device_types.h:
System/Inc/system_estimator_diagnostics.h:
System/Alignment/Inc/system_alignment.h:
System/Inc/system_configuration_types.h:
Platform/Inc/platform_memory.h:
Algorithm/Estimator/ESKF15/Inc/navigation_eskf_replay.h:
Algorithm/Estimator/ESKF15/Inc/navigation_eskf.h:
Algorithm/Estimator/ESKF15/Inc/navigation_eskf_horizon.h:
Algorithm/Estimator/ESKF15/Inc/navigation_eskf_replay.h:
Algorithm/Estimator/ESKF15/Inc/navigation_eskf_config.h:
Algorithm/Common/Inc/navigation_quality.h:
Algorithm/Common/Inc/geodesy_local.h:
APP/Inc/estimator_bus.h:
System/Inc/system_navigation_health.h:
System/Inc/system_source_selector.h:
System/Inc/system_time.h:
System/Calibration/Inc/system_calibration.h:
Algorithm/Calibration/Inc/imu_six_face_calibration.h:
System/Inertial/Inc/system_inertial_types.h:
Interfaces/Inc/system_imu_epoch_if.h:
System/Inc/system_gnss_quality.h:
Interfaces/Inc/system_gnss_if.h:
System/User/system_user_config.h:
System/User/system_user_flight_config.h:
Targets/SilverStar_F407/Inc/target_system_config.h:
System/Inc/system_capabilities.h:
System/User/system_user_alignment_config.h:
System/User/system_user_capability_validation.h:
System/User/system_user_platform_capabilities.h:
System/Inc/system_fusion_timing.h:
Generated/Inc/project_device_instances.h:
Interfaces/Inc/system_barometer_if.h:
Interfaces/Inc/system_descriptor_if.h:
Interfaces/Inc/system_hardware_quaternion_if.h:
Interfaces/Inc/system_imu_if.h:
Interfaces/Inc/system_imu_epoch_if.h:
Interfaces/Inc/system_magnetometer_if.h:
Interfaces/Inc/system_power_if.h:
Interfaces/Inc/system_telemetry_transport_if.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
APP/Inc/logger_bus.h:
Protocol/SSLOG/Inc/sslog_protocol.h:
Protocol/SSLOG/Inc/sslog_records.h:
