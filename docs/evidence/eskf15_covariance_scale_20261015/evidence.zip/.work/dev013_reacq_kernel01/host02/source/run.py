"""Owned, unique-run evidence capture; no git, source changes or cleanup."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

TASK = Path(__file__).resolve().parent
ROOT = TASK.parents[1]
KERNEL = ROOT / "apps/SCG/plugins/builtin/silverstar_algorithm_estimator_eskf15/payload/Algorithm/Estimator/ESKF15"
SOURCES = [KERNEL / "Src/navigation_eskf.c", KERNEL / "Inc/navigation_eskf.h",
           ROOT / "apps/SCG/tests/test_eskf15_covariance_scale.py",
           ROOT / "apps/SCG/tests/fixtures/eskf15_covariance_scale.c", TASK / "task.md", Path(__file__)]


def file_record(path):
    data = path.read_bytes()
    return {"path": str(path.relative_to(ROOT)), "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest()}


def main():
    run_id, *arguments = sys.argv[1:]
    if not run_id.isidentifier():
        raise ValueError("run_id must be a simple unique identifier")
    directory = TASK / run_id
    directory.mkdir(exist_ok=False)
    temporary = directory / "tmp"
    temporary.mkdir()
    environment = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONDONTWRITEBYTECODE="1",
                       QT_QPA_PLATFORM="offscreen", TEMP=str(temporary), TMP=str(temporary),
                       TMPDIR=str(temporary))
    command = [str(ROOT / ".venv/Scripts/python.exe"), "-m", "pytest",
               "tests/test_eskf15_covariance_scale.py", "-q", "-o", "addopts=",
               "-o", "cache_dir=" + str(directory / "cache"),
               "--basetemp", str(directory / "pytest"), *arguments]
    before = [file_record(path) for path in SOURCES]
    snapshots = directory / "source"
    snapshots.mkdir()
    for path in SOURCES:
        (snapshots / path.name).write_bytes(path.read_bytes())
    started = datetime.now(timezone.utc).isoformat()
    completed = subprocess.run(command, cwd=ROOT / "apps/SCG", env=environment,
                               capture_output=True, text=True, encoding="utf-8", timeout=300)
    log = directory / "pytest.log"
    log.write_text(completed.stdout + completed.stderr, encoding="utf-8")
    inventory = {
        "owner": "/root/fusion_delay_design", "purpose": "covariance scale kernel Host evidence",
        "started_utc": started, "finished_utc": datetime.now(timezone.utc).isoformat(),
        "cwd": str(ROOT / "apps/SCG"), "command": command, "exit_code": completed.returncode,
        "environment": {key: environment[key] for key in (
            "PYTHONIOENCODING", "PYTHONDONTWRITEBYTECODE", "QT_QPA_PLATFORM", "TEMP", "TMP", "TMPDIR")},
        "python_version": subprocess.check_output([command[0], "--version"], text=True).strip(),
        "source_before": before, "source_after": [file_record(path) for path in SOURCES],
        "log": file_record(log), "cleanup_authorized": False,
    }
    (directory / "result.json").write_text(json.dumps(inventory, indent=2), encoding="utf-8")
    print(completed.stdout[-8000:] + completed.stderr[-2000:])
    print(json.dumps({"run": str(directory), "exit_code": completed.returncode,
                      "log_sha256": inventory["log"]["sha256"]}))
    return completed.returncode


if __name__ == "__main__":
    raise SystemExit(main())
