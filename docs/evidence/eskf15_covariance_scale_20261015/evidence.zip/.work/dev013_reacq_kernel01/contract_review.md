# Covariance scale kernel: scoped review and evidence

Owner: /root/fusion_delay_design. 2026-10-15 UTC. Product writes were released by
root after the preparation phase; only owning navigation_eskf.c/.h were changed.
The two new SCG test files are the only test-source writes in this batch.

## Operation and failure contract

Public result is a separate NavigationEskfCovarianceScaleResult enum. There is no
measurement outcome, recovery attempt counter, source transition or logger effect.
Scale factors are dimensionless [1,2], so each diagonal variance grows by a factor
in [1,4] per call, subject to its caller-supplied cap. Repeated calls carry no hidden
budget. The caller owns policy, physical qualification and effective fusion proof.

Null pointers and initialized != 1 return InvalidArgument. Valid typed object
addresses receive the existing object/alignment checks. Before any scratch write,
the parameter helper rejects overlapping state/workspace or either read-only input
array with either mutable object. uintptr_t subtraction compares address intervals
without pointer-end addition or relational comparisons between unrelated pointers.
scale/cap may overlap each other because both remain read-only. The API still
requires properly sized, live typed C objects; it cannot validate object lifetime
or accessible allocation size from a pointer alone.

Parameter ranges are checked for every coordinate. Exact triangle representation
equality is checked before the existing diagnostic Cholesky reads original P. A
signed-zero-only mismatch is a conservative representation rejection, not proof
of mathematical asymmetry, non-SPD or corruption. The helper never averages P.

Every lower-triangle value is computed as (Pij * scale_i) * scale_j and checked
finite, then its identical float bits are copied to the other triangle. All 225
mathematical entries, including correlations between position/velocity/attitude/
bias coordinates, remain represented. The same existing Cholesky diagnoses the
complete candidate. Finite excess over any inclusive cap returns AtCap without
clamping or partial scale. Exact unchanged candidate returns NoChange after all
validation. A single final memcpy is the only authoritative state write.

Failure/no-change byte snapshots cover nominal, all P, timestamp, source,
generation, initialized and padding. Input arrays, guard regions and a second
state/workspace pair are checked. F/candidate_p are disposable scratch; other
workspace fields are unchanged in these tests. There is no whole-workspace copy
in product C. sizeof(NavigationEskfWorkspace) remains 3140 bytes on this Host ABI.

Mathematical DPD-transpose preserves SPD for positive D. Float32 arithmetic can
lose this property; the candidate validator must and does reject such a case
without committing. The focused fixture uses P01=P10=0.9999999403953552 and scales
1.8009313344955444, 1.7172355651855469: original P passes the actual kernel and
float64 reference, the float64 congruence is SPD, but the finite float32 candidate
fails actual Cholesky at both O0/O2. This is a numerical rejection, not permission
to repair covariance or weaken a gate.

Only uniform D=sI establishes P'-P=(s*s-1)P positive semidefinite in every direction.
Selective factors >=1 can preserve correlations/SPD while P'-P is indefinite;
the independent reference test demonstrates that distinction.

## Local code review

New loops have fixed bounds <=15 (nested <=225). No recursion, indirect calls,
dynamic allocation, variable-length arrays, policy state, callback registry or new
preprocessor exception is introduced. Helpers divide parameter/representation/
construction responsibilities, not assertion density. Their guard dominance is
the checked public entry. No assertion is added merely to achieve a count.

All fallible helper results are checked; no rejected candidate is published.
memcmp results control explicit branches. memcpy returns its already-known valid
destination and has no separate recoverable status; ignoring that return does not
discard a fallible operation. Existing libc/math/assert dependencies are reused.
The caller must serialize a state/workspace pair; this API adds no internal locking
or ISR-safe ownership proof. Concurrent distinct pairs have no new shared mutable
kernel state. The Host fixture itself is intentionally serial and uses static
test storage; its pair-isolation test is not a simultaneous-thread proof.

This review covers the new kernel boundary only. It does not validate all nominal
state physics, provide GNSS lifecycle/replay integration, prove finite system stack
or WCET, or certify whole-program Power of Ten compliance. Downstream integration
critical-contract review and hardware evidence remain NOT PROVEN.

## Executed evidence

- prepare01: selector error, 4 passed / 24 future-API setup errors; preserved and
  explicitly not a pre-fix defect. prepare02/03: 4 reference/baseline passed.
- host01: 184 passed, O0/O2, full original reviewed matrix.
- host02: 196 passed, O0/O2, includes 12 additional alias/finite-Cholesky tests.
  No skips. All strict compilation stdout/stderr are retained in compile.json.
- validation01: full old C and header text unchanged after removing only new
  declarations/functions (newline-normalized comparison). Baseline is the saved
  preparation snapshot, not a reconstructed or edited algorithm.
- validation01: aliases/stationary/motion/faults x O0/O2 = 8 full trace pairs equal,
  including state/covariance/outcome/history bytes. This is scoped behavioral
  evidence, not exhaustive trajectory or navigation-accuracy validation.
- validation01: actual GCC 16.1.0 -fanalyzer -O2 -c compilation, exit 0, no stderr;
  ruff 0.16.9 check of the new Python test, exit 0. This is not syntax-only.
- arm_object01: actual Arm GNU 14.3.Rel1 Cortex-M4F hard-float -O2 -c with
  strict warnings and -fstack-usage, exit 0, no diagnostics. This is a representative
  translation unit, not a generated firmware link. Its .su reports 72 static bytes
  for NavigationEskf_CovarianceScale and 40 for Eskf_CovarianceValidate. Those
  individual frames do not prove a complete path including math/assert libraries,
  task/MSP/ISR nesting, or safe stack margin.
- Python 3.14.0, pytest 9.1.1, no installed dependencies. No git or hardware action.

## Frozen source identity

- navigation_eskf.c: 6c18d3afbecd1d1d38ef8afc8bef6adeb74c021e2bd7e3af40bc21d836542782
- navigation_eskf.h: 258259fcae71b46bfca6283328c5d9bd5355e577afabdf951951ec11a2aa2919
- test_eskf15_covariance_scale.py: 2251cffc127e1bb6abc1337a7a07c789d1c4023595c4e0892bb2dfbb476e24c7
- eskf15_covariance_scale.c fixture: c3eea9e08612ddf554cdd192bf7d846c349af45d526bc2253cec4c2d17adaed4
- host02/result.json: d4f1045c110e307a99f60ebfd51f24bc98a3dc5e9d2be93ee62a0c3b2c386ba8
- validation01/result.json: ab030e869e52e61a54aa17747de221d3ec43a2883a1339f6ef3b79c260eb4a90

Root reported parent performance commit 5af1efa1 before this batch; this batch
claims exact dirty-source hashes and saved snapshots rather than a new commit.
Fresh generation/Power10/ARM/link/source-graph evidence is coordinated with
/root/navigation_performance under .work/dev013_timing_firmware01 and is pending.
That will be a shared snapshot including its backend work, not kernel-only full
firmware evidence. No GNSS reacquisition is implemented or claimed by this kernel.
