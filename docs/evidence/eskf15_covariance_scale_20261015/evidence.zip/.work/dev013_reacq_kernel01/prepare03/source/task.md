# ESKF15 covariance scale kernel 01

Owner: /root/fusion_delay_design. Created 2026-10-15 UTC.

This batch adds a generic bounded covariance congruence only. It does not implement
GNSS recovery, qualification, outage detection, receive deduplication, replay state,
current/no-replay backend routing, log schema, or a firmware policy. No hardware,
network download, git operation, commit, push, tag, release or cleanup is authorized.

## Scope and sequence

1. Prepare `apps/SCG/tests/test_eskf15_covariance_scale.py` and dedicated
   `apps/SCG/tests/fixtures/eskf15_covariance_scale.c`; run independent reference and
   existing-API synthetic NIS trace. Missing new symbol is NOT pre-fix failure.
2. Await root's explicit signal that its full FLP run stopped reading kernel C.
3. Modify only owning ESKF15 `navigation_eskf.c/.h`: add public
   `NavigationEskfCovarianceScaleResult NavigationEskf_CovarianceScale(state, work,
   scale[15], variance_cap[15])`; preserve existing Initialize/Update/Predict behavior.
4. Run full focused Host O0/O2 matrix, existing affected equivalence, fresh generation,
   generated power10-check, real analyzer compile and actual ARM compile/link, with
   parent coordination for shared output/ownership. Record all failures/skips.

## Contract fixed before C implementation

- `scale[i]` finite and in [1, 2]; `variance_cap[i]` finite and positive, in the
  matching error-state coordinate's squared units. State is initialized (exactly 1).
- Validate original full covariance using existing Cholesky validator plus strict
  bitwise symmetry; even a one-ULP asymmetry inside old validator tolerance is an
  error, never silently averaged/repaired. Signed-zero asymmetry is also rejected.
- Compute all mathematical entries of D P D-transpose, D diagonal. Computing one
  triangle then copying its bits is allowed; clearing any cross term is not.
- Finite SPD candidate, all diagonal variances <= inclusive cap, exact triangle
  bit agreement before one authoritative P publication. Nonfinite arithmetic is
  NumericError; finite cap exceedance is AtCap, with no clamp or partial scale.
- Applied, NoChange, AtCap, InvalidArgument, NumericError are distinct public enum
  results, separate from measurement accepted/rejected results. All-one scale still
  validates original P and caps. NoChange does not publish.
- Failure leaves entire NavigationEskfState, including nominal, P, timestamp,
  source, generation, initialized and padding, byte unchanged. Read-only input
  arrays remain unchanged. Existing F/candidate_p workspace scratch semantics stay;
  no full-state/workspace transaction copies or dynamic allocation in product C.
- Caller serializes its state/workspace pair; separate pairs have no hidden shared
  policy. API arguments are normal typed valid objects; overlapping state/workspace
  objects are outside the existing kernel object ownership contract.
- Positive D preserves SPD and correlation coefficients mathematically. Only
  uniform D=sI with s>=1 proves P'-P PSD in every direction. Selective scale >=1
  does NOT prove this: P=[[1,.9],[.9,1]], D=diag(2,1) gives det(P'-P)=-.81.

## Matrix

O0/O2 actual GCC, strict warnings, no fast-math/contraction. Standard-library Python
float64 general matrix-product and independent Cholesky references (no new package).
Dense all-cross-term P, uniform/nonuniform scales, endpoint and invalid scale/cap,
inclusive cap and no clamping, original nonfinite/asymmetric/singular/indefinite P,
overflow and finite near-FLT_MAX candidate, no-change validation, null/uninitialized
arguments, byte snapshots and allocation guards, instance isolation, repeated calls.

The baseline trace invokes existing Update eight times with physically-valid but
synthetically inconsistent position observations. It records NIS rejection and
unchanged state only; it does not simulate 1/5/30/120-second outages, model true GNSS
receive timing, or prove that a recovery strategy works.

## Evidence / retention

This directory exclusively owns new small logs, JSON inventories, source snapshots,
Host fixture binaries and later coordinated generated test outputs. Each run uses a
fresh versioned subdirectory and records command/env/tool versions, exact source
hashes, exit code and complete output. No preexisting output is overwritten.
Evidence and source fixtures are retained; no cleanup permission is implied.

Initial status: tests prepared; product C/h write not yet allowed. No safety or
hardware qualification claim. Full critical-contract review, ARM timing/stack and
hardware evidence remain NOT PROVEN until separately established.
