from pathlib import Path
root=Path(__file__).resolve().parent
text=(root/'baseline.py').read_text(encoding='utf-8').split('import silverstar_flp.ui.main_window as flp_module')[0]
text=text.replace("repo = root.parents[1]", "repo = root.parents[1]\nroot = root/'final_profile'\nroot.mkdir(exist_ok=False)")
text=text.replace('apps/SCG/.work/gui012_20261008/scg.ini','apps/SCG/.work/gui012-finalprofile/scg.ini')
text += "print('SCG profiler completed',flush=True)\n"
(root/'final_profile.py').write_text(text,encoding='utf-8')
