from pathlib import Path
root=Path(__file__).resolve().parent
text=(root/'native_acceptance_v2.py').read_text(encoding='utf-8').replace("/'native2'","/'native3'").replace('gui012-native2','gui012-native3')
text=text.replace("w._Project_Open(config);finish();assert not errors,errors", "w._Project_Open(config);finish();app.processEvents()\nassert errors and all(str(e).startswith('project_result_recompute_required:') for e in errors),errors\nconfiguration_notices=list(errors);errors.clear()\nassert w._dataset is not None")
text=text.replace("'configuration_only_no_replay':True,'errors':errors", "'configuration_only_no_replay':True,'configuration_notices':configuration_notices,'errors':errors")
(root/'native_acceptance_v3.py').write_text(text,encoding='utf-8')
