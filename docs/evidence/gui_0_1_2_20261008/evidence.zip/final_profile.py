from pathlib import Path
import os, sys, json, time, cProfile, pstats, io
os.environ['QT_QPA_PLATFORM'] = 'windows'
os.environ['OPENBLAS_NUM_THREADS'] = '1'
root = Path(__file__).resolve().parent
repo = root.parents[1]
root = root/'final_profile'
root.mkdir(exist_ok=False)
sys.path[:0] = [str(repo/'apps/SCG/src'), str(repo/'apps/FLP/src')]
from PySide6.QtWidgets import QApplication, QMessageBox
from PySide6.QtCore import Qt, QSettings
from PySide6.QtTest import QTest
from silverstar_fccg.ui.main_window import MainWindow as ScgWindow
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.core.settings import SettingsStore
from silverstar_fccg.project.reference import ReferenceProject_Create

app = QApplication([])
assert app.platformName() == 'windows'
scg_settings = repo/'apps/SCG/.work/gui012-finalprofile/scg.ini'
scg_settings.parent.mkdir(parents=True, exist_ok=True)
window = ScgWindow(SettingsStore(scg_settings), service=FccgService(repo/'apps/SCG'))
window._MessageBox_Exec = lambda *a, **k: QMessageBox.StandardButton.Discard
errors = []; window._Error_Show = errors.append
window._model = ReferenceProject_Create(catalog=window._service.catalog)
window._Project_Refresh(); window.show(); app.processEvents()
metrics = []
profile = cProfile.Profile()
def measure(name, action):
    profile.enable(); start=time.perf_counter(); action(); elapsed=time.perf_counter()-start; profile.disable()
    app.processEvents()
    metrics.append({'action': name, 'ui_call_seconds': elapsed, 'instances':[i.instance_id for i in window._model.device_instances]})
measure('add_imu_mouse', lambda: QTest.mouseClick(window.devices_page.add_buttons['imu'], Qt.MouseButton.LeftButton))
extra = next(i.instance_id for i in window._model.device_instances if i.instance_id != 'imu0' and window._service.Plugin_Get(i.plugin).component_class == 'imu')
measure('remove_imu_combo', lambda: window.devices_page.device_combos[extra].setCurrentIndex(0))
measure('add_imu_mouse_again', lambda: QTest.mouseClick(window.devices_page.add_buttons['imu'], Qt.MouseButton.LeftButton))
measure('switch_compact_combo', lambda: window.devices_page.feature_tier_combo.setCurrentIndex(window.devices_page.feature_tier_combo.findData('compact')))
measure('switch_minimal_combo', lambda: window.devices_page.feature_tier_combo.setCurrentIndex(window.devices_page.feature_tier_combo.findData('minimal')))
profile.dump_stats(str(root/'scg_baseline.prof'))
stream=io.StringIO();pstats.Stats(profile, stream=stream).sort_stats('cumulative').print_stats(35)
(root/'scg_baseline_profile.txt').write_text(stream.getvalue(), encoding='utf-8')
(root/'scg_baseline.json').write_text(json.dumps({'metrics':metrics,'errors':[str(e) for e in errors]},indent=2),encoding='utf-8')
window.close();app.processEvents()

print('SCG profiler completed',flush=True)
