from pathlib import Path
import sys,os,json,time,threading,hashlib
os.environ['QT_QPA_PLATFORM']='windows';os.environ['OPENBLAS_NUM_THREADS']='1'
repo=Path.cwd();root=Path(__file__).resolve().parent/'native_sources';root.mkdir(exist_ok=False)
sys.path[:0]=[str(repo/'apps/FLP/src'),str(repo/'apps/FLP')]
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QSettings
from silverstar_flp.ui import main_window as module
from silverstar_flp.core import artifacts
from silverstar_flp.plugins.registry import builtin_registry
from silverstar_flp.decoder_profiles.discovery import DecoderProfileCache
from silverstar_flp.core.path_preferences import PathPreferences
from silverstar_flp.plugins.container_packages import TrustedContainerPluginManager
from tests.test_project_artifacts import _Assert_Result
app=QApplication([]);assert app.platformName()=='windows'
module.QSettings=lambda *a,**k:QSettings(str(root/'settings.ini'),QSettings.Format.IniFormat)
w=module.MainWindow(builtin_registry(),language='zh_CN',path_preferences=PathPreferences(root/'paths.json'),plugin_manager=TrustedContainerPluginManager(root/'plugins'))
w._log_open_coordinator.cache=DecoderProfileCache(root/'decoder');errors=[];w._Error_Show=errors.append;w.show()
def finish():
    deadline=time.monotonic()+120
    while w._active_worker is not None and time.monotonic()<deadline:app.processEvents();time.sleep(.005)
    assert w._active_worker is None
    app.processEvents()
source=repo/'.work/gui012_20261008/native3/actual.ssflp'
w._Project_Open(source);finish();assert not errors,errors
entries=w._replay_store.Entries_Get();assert len(entries)==2
w._AnalysisSource_Set(entries[1].source_id);w._SecondarySource_Set(entries[0].source_id)
for cls in {type(p) for p in w._registry.algorithms}:
    cls.run=lambda *a,**k:(_ for _ in ()).throw(AssertionError('Automatic replay forbidden'))
target=root/'two_sources.ssflp';entered=threading.Event();release=threading.Event();original=artifacts._ProgressStream.write
def held(stream,data):
    if not entered.is_set():entered.set();assert release.wait(8)
    return original(stream,data)
artifacts._ProgressStream.write=held
try:
    assert w._Project_Write(target,background=True,save_data=True)
    deadline=time.monotonic()+5
    while not entered.is_set() and time.monotonic()<deadline:app.processEvents();time.sleep(.005)
    assert entered.is_set()
    worker=w._active_worker
    assert not w._Project_Write(root/'duplicate.ssflp',background=True,save_data=True)
    w._Project_Open(source)
    assert w._active_worker is worker
    assert errors and all(str(e)=='another_background_task_is_running' for e in errors),errors
    busy_errors=list(errors);errors.clear();release.set();finish();assert not errors,errors
finally:release.set();artifacts._ProgressStream.write=original
w._Project_Open(target);finish();assert not errors,errors
assert w._replay_store.ActiveSource_Get().source_id==entries[1].source_id
assert w._secondary_source_id==entries[0].source_id
for old,new in zip(entries,w._replay_store.Entries_Get()):_Assert_Result(old.result,new.result)
w.grab().save(str(root/'two_sources.png'))
result={'native_platform':app.platformName(),'primary':entries[1].source_id,'secondary':entries[0].source_id,'all_arrays_equal':True,'automatic_replay_forbidden':True,'repeated_operations_rejected':busy_errors,'errors':errors,'project_sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
(root/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2),flush=True)
w._Project_SetDirty(False);w.close();app.processEvents()
