from pathlib import Path
import json
root=Path(__file__).resolve().parent
data=json.loads((root/'native3/flp_result.json').read_text(encoding='utf-8'));rows=data['observations']
tasks=[];current=[]
for row in rows:
    if row['code'] in ('progress.open.project','progress.save.prepare'):
        if current:tasks.append(current)
        current=[]
    current.append(row)
if current:tasks.append(current)
summary=[]
for index,task in enumerate(tasks):
    pairs=list(zip(task,task[1:]));nine=[r for r in task if .09<=r['value']<.10]
    worst=max(pairs,key=lambda p:p[1]['t']-p[0]['t']) if pairs else None
    nine_pairs=[p for p in pairs if .09<=p[0]['value']<.10]
    nine_worst=max(nine_pairs,key=lambda p:p[1]['t']-p[0]['t']) if nine_pairs else None
    summary.append({'task_index':index,'kind':task[0]['code'],'event_count':len(task),'observed_span_s':task[-1]['t']-task[0]['t'],'max_progress_gap_s':worst[1]['t']-worst[0]['t'] if worst else None,'worst_gap_codes':[r['code'] for r in worst] if worst else [],'nine_percent_span_s':nine[-1]['t']-nine[0]['t'] if nine else None,'nine_percent_event_count':len(nine),'nine_percent_max_gap_s':nine_worst[1]['t']-nine_worst[0]['t'] if nine_worst else None,'nine_percent_first':nine[0] if nine else None,'nine_percent_last':nine[-1] if nine else None})
(root/'progress_summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps([{k:v for k,v in row.items() if not k.endswith('_first') and not k.endswith('_last')} for row in summary],indent=2))
