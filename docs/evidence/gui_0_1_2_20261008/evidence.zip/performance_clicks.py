from pathlib import Path
import os,sys,time,json
os.environ['QT_QPA_PLATFORM']='windows';os.environ['OPENBLAS_NUM_THREADS']='1'
repo=Path.cwd();root=Path(__file__).resolve().parent;kind=sys.argv[1]
source=(root/'baseline_source/apps/SCG/src') if kind=='before' else repo/'apps/SCG/src'
sys.path.insert(0,str(source))
from PySide6.QtWidgets import QApplication,QMessageBox
from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
from silverstar_fccg.ui.main_window import MainWindow
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.core.settings import SettingsStore
from silverstar_fccg.project.reference import ReferenceProject_Create
app=QApplication([]);assert app.platformName()=='windows'
settings=repo/f'apps/SCG/.work/gui012-performance-{kind}/settings.ini';settings.parent.mkdir(parents=True,exist_ok=True)
w=MainWindow(SettingsStore(settings),service=FccgService(repo/'apps/SCG'));errors=[];w._Error_Show=errors.append
w._MessageBox_Exec=lambda *a,**k:QMessageBox.StandardButton.Discard
w._model=ReferenceProject_Create(catalog=w._service.catalog);w._Project_Refresh();w.show();app.processEvents()
metrics=[]
def measure(name,fn):
    started=time.perf_counter();fn();call=time.perf_counter()-started;app.processEvents()
    metrics.append({'action':name,'callback_s':call,'including_event_drain_s':time.perf_counter()-started})
for index in range(3):
    measure('add_imu',lambda:QTest.mouseClick(w.devices_page.add_buttons['imu'],Qt.MouseButton.LeftButton))
    extra=next(i.instance_id for i in w._model.device_instances if i.instance_id!='imu0' and w._service.Plugin_Get(i.plugin).component_class=='imu')
    measure('remove_imu',lambda:w.devices_page.device_combos[extra].setCurrentIndex(0))
assert not errors,errors
record={'source_kind':kind,'base_head':'b2fae225155a925dac475a2e95f8b978d76dde99','profiler':False,'platform':app.platformName(),'python':sys.executable,'source_root':str(source),'plugin_workspace':str(repo/'apps/SCG'),'configuration':'same ReferenceProject full tier; three add/remove cycles; native QtTest clicks/combo; no algorithm recompute','metrics':metrics,'errors':errors}
(root/f'performance_{kind}.json').write_text(json.dumps(record,indent=2),encoding='utf-8');print(json.dumps(record,indent=2),flush=True)
w.close();app.processEvents()
