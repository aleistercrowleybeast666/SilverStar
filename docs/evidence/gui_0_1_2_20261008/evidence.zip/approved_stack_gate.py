from pathlib import Path
import subprocess,hashlib,sys,os,json,time
repo=Path.cwd();out=Path(__file__).resolve().parent/'software';target=out/'project/Flight_Controller'
sys.path.insert(0,str(repo/'apps/SCG/src'))
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.project.model import ProjectModel_Load
from silverstar_fccg.generator.multi_target import TargetGeneration_Apply,TargetScope
owner=repo/'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload'
header=owner/'System/User/system_user_config.h'
old=subprocess.check_output(['git','show','b2fae225155a925dac475a2e95f8b978d76dde99:apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/System/User/system_user_config.h']).decode('utf-8').replace('\r\n','\n')
expected=old.replace('#define SILVERSTAR_VERSION_PATCH     0','#define SILVERSTAR_VERSION_PATCH     2').replace('"SILV0100"','"SILV0102"')
assert header.read_text(encoding='utf-8')==expected
assert hashlib.sha256(expected.encode()).hexdigest()=='ffb28f9bf8e08e73c80a16c1121e8c37954f7bb7ade95f2aa47a5226787cc840'
checker=target/'Tools/check_task_stacks.py'
assert checker.resolve().is_relative_to(out.resolve())
old_checker=subprocess.check_output(['git','show','b2fae225155a925dac475a2e95f8b978d76dde99:apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tools/check_task_stacks.py']).decode('utf-8').replace('\r\n','\n')
# The first regeneration deliberately refused a missing project-owned tool.
# Explicitly refresh only this disposable fixture's tool from the authorized
# owner, then rerun normal generation, retaining its source-preservation policy.
assert not checker.exists()
checker.write_bytes((owner/'Tools/check_task_stacks.py').read_bytes())
service=FccgService(repo/'apps/SCG');model=ProjectModel_Load(repo/'docs/evidence/logger_health_retest_20261008/generated_config.ssproject')
TargetGeneration_Apply(model,service.catalog,service.policy,out/'project',TargetScope.FLIGHT)
assert checker.read_bytes()==(owner/'Tools/check_task_stacks.py').read_bytes()
assert (target/'System/User/system_user_config.h').read_bytes()==header.read_bytes()
env=dict(os.environ,PATH=str(repo/'apps/FLP/.venv/Scripts')+';D:/msys64/ucrt64/bin;D:/Arm GNU Toolchain/14.3 rel1/bin;'+os.environ.get('PATH',''))
results=[]
for name,args in [('architecture_v2',['architecture-check']),('power10_v2',['power10-check']),('release_v2',['-j2','all','artifact-check','memory-report','GCC_PATH=D:/Arm GNU Toolchain/14.3 rel1/bin']),('stack_v2',['-j2','stack-report','GCC_PATH=D:/Arm GNU Toolchain/14.3 rel1/bin'])]:
    command=['D:/msys64/ucrt64/bin/mingw32-make.exe',*args];started=time.monotonic()
    with (out/(name+'.log')).open('xb') as log:result=subprocess.run(command,cwd=target,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
    row={'name':name,'command':command,'cwd':str(target),'exit_code':result.returncode,'elapsed_s':time.monotonic()-started,'checker_sha256':hashlib.sha256(checker.read_bytes()).hexdigest(),'header_normalized_sha256':hashlib.sha256(expected.encode()).hexdigest(),'version_only_diff_verified':True,'approval':'Explicit user approval delivered through parent thread on 2026-10-08; this one header hash only.'}
    (out/(name+'_result.json')).write_text(json.dumps(row,indent=2));results.append(row);print(json.dumps(row),flush=True)
raise SystemExit(max(row['exit_code'] for row in results))
