from pathlib import Path
import json,hashlib,subprocess,zipfile,datetime,re,sys
repo=Path.cwd();work=Path(__file__).resolve().parent;dest=repo/'docs/evidence/gui_0_1_2_20261008';dest.mkdir(exist_ok=False)
paths=[]
for directory in [work,work/'software',work/'final_profile']:
    paths += [p for p in directory.iterdir() if p.is_file() and p.suffix in ('.py','.json','.log','.txt','.patch')]
for relative in ['native3/scg_result.json','native3/flp_result.json','native3/scg.png','native3/flp.png','native_sources/result.json','native_sources/two_sources.png']:
    paths.append(work/relative)
archive=dest/'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as stream:
    for path in sorted(set(paths)):
        stream.write(path,path.relative_to(work).as_posix())
modified=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
source_paths=[p for p in modified+untracked if not p.startswith('work_') and not p.startswith('docs/evidence/gui_0_1_2_20261008/')]
sources=[]
for name in sorted(set(source_paths)):
    path=repo/name;data=path.read_bytes();row={'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
    try:row['normalized_text_sha256']=hashlib.sha256(path.read_text(encoding='utf-8').encode()).hexdigest()
    except UnicodeError:pass
    sources.append(row)
(dest/'source_hashes.json').write_text(json.dumps(sources,indent=2),encoding='utf-8')
inputs=[]
for name in ['work_build_candidates_20261006.csv','work_inventory_20261006.txt','work_subtree_classification_20261006.csv','docs/evidence/logger_health_retest_20261008/generated_config.ssproject','docs/evidence/logger_health_retest_20261008/candidate.ssdecoder']:
    path=repo/name;inputs.append({'path':name,'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
artifacts=[]
for path in (work/'software/project/Flight_Controller/build/FCCG/SilverStar_F407/Release').rglob('*'):
    if path.is_file() and path.suffix in ('.elf','.bin','.hex','.map'):
        artifacts.append({'path':str(path.relative_to(repo)),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
links=[]
for name in ['README.md','docs/README.md','docs/USER_WORKFLOW.md','docs/FCCG/USER_GUIDE.md','docs/GUI_ACCEPTANCE_0_1_2_20261008.md']:
    path=repo/name
    for target in re.findall(r'\[[^\]\n]*\]\(([^\s)]+)\)',path.read_text(encoding='utf-8')):
        if not target.startswith(('http:','https:','#')):
            links.append({'source':name,'target':target,'exists':(path.parent/target.split('#')[0]).exists()})
manifest={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'branch':subprocess.check_output(['git','branch','--show-current'],text=True).strip(),'checkpoint':True,'release_acceptance':False,'hardware_actions':False,'owned_processes_all_exited':True,'untouched_existing_python_pid':33432,'evidence_zip_bytes':archive.stat().st_size,'evidence_zip_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'evidence_members':[str(p.relative_to(work)) for p in sorted(set(paths))],'inputs':inputs,'artifacts':artifacts,'current_doc_links':links,'current_doc_missing_links':[r for r in links if not r['exists']],'remaining_stack_failure':'Generated/Src/project_metadata.c; bba3aed1cc73043a10cfd126a7759728a10de53e3769e2563fb209a4b12feadf; NOT AUTHORIZED','python':sys.version}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
(dest/'.gitattributes').write_text('* -text\n',encoding='ascii')
print(json.dumps({'archive_bytes':archive.stat().st_size,'source_count':len(sources),'missing_links':manifest['current_doc_missing_links'],'own_processes_running':False},indent=2))
