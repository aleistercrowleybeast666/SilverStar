from pathlib import Path
import os, sys, json, time, cProfile, pstats, io
os.environ['QT_QPA_PLATFORM'] = 'windows'
os.environ['OPENBLAS_NUM_THREADS'] = '1'
root = Path(__file__).resolve().parent
repo = root.parents[1]
sys.path[:0] = [str(repo/'apps/SCG/src'), str(repo/'apps/FLP/src')]
from PySide6.QtWidgets import QApplication, QMessageBox
from PySide6.QtCore import Qt, QSettings
from PySide6.QtTest import QTest
from silverstar_fccg.ui.main_window import MainWindow as ScgWindow
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.core.settings import SettingsStore
from silverstar_fccg.project.reference import ReferenceProject_Create

app = QApplication([])
assert app.platformName() == 'windows'
scg_settings = repo/'apps/SCG/.work/gui012_20261008/scg.ini'
scg_settings.parent.mkdir(parents=True, exist_ok=True)
window = ScgWindow(SettingsStore(scg_settings), service=FccgService(repo/'apps/SCG'))
window._MessageBox_Exec = lambda *a, **k: QMessageBox.StandardButton.Discard
errors = []; window._Error_Show = errors.append
window._model = ReferenceProject_Create(catalog=window._service.catalog)
window._Project_Refresh(); window.show(); app.processEvents()
metrics = []
profile = cProfile.Profile()
def measure(name, action):
    profile.enable(); start=time.perf_counter(); action(); elapsed=time.perf_counter()-start; profile.disable()
    app.processEvents()
    metrics.append({'action': name, 'ui_call_seconds': elapsed, 'instances':[i.instance_id for i in window._model.device_instances]})
measure('add_imu_mouse', lambda: QTest.mouseClick(window.devices_page.add_buttons['imu'], Qt.MouseButton.LeftButton))
extra = next(i.instance_id for i in window._model.device_instances if i.instance_id != 'imu0' and window._service.Plugin_Get(i.plugin).component_class == 'imu')
measure('remove_imu_combo', lambda: window.devices_page.device_combos[extra].setCurrentIndex(0))
measure('add_imu_mouse_again', lambda: QTest.mouseClick(window.devices_page.add_buttons['imu'], Qt.MouseButton.LeftButton))
measure('switch_compact_combo', lambda: window.devices_page.feature_tier_combo.setCurrentIndex(window.devices_page.feature_tier_combo.findData('compact')))
measure('switch_minimal_combo', lambda: window.devices_page.feature_tier_combo.setCurrentIndex(window.devices_page.feature_tier_combo.findData('minimal')))
profile.dump_stats(str(root/'scg_baseline.prof'))
stream=io.StringIO();pstats.Stats(profile, stream=stream).sort_stats('cumulative').print_stats(35)
(root/'scg_baseline_profile.txt').write_text(stream.getvalue(), encoding='utf-8')
(root/'scg_baseline.json').write_text(json.dumps({'metrics':metrics,'errors':[str(e) for e in errors]},indent=2),encoding='utf-8')
window.close();app.processEvents()

import silverstar_flp.ui.main_window as flp_module
from silverstar_flp.plugins.registry import builtin_registry
from silverstar_flp.decoder_profiles.discovery import DecoderProfileCache
from silverstar_flp.core.path_preferences import PathPreferences
from silverstar_flp.plugins.container_packages import TrustedContainerPluginManager
flp_module.QSettings=lambda *a,**k:QSettings(str(root/'flp.ini'),QSettings.Format.IniFormat)
window=flp_module.MainWindow(builtin_registry(),language='zh_CN',path_preferences=PathPreferences(root/'paths.json'),plugin_manager=TrustedContainerPluginManager(root/'plugins'))
window._log_open_coordinator.cache=DecoderProfileCache(root/'decoder_cache')
window._Error_Show=errors.append
window.show();app.processEvents()
observations=[];original=window._Task_Start
def observe(worker,*args,**kwargs):
    original(worker,*args,**kwargs)
    worker.signals.progress.connect(lambda value,code:observations.append({'t':time.perf_counter(),'value':value,'code':code,'bar_format':window.progress_bar.format(),'bar_value':window.progress_bar.value(),'status':window.status_label.text()}),Qt.ConnectionType.QueuedConnection)
window._Task_Start=observe
def finish():
    deadline=time.monotonic()+180
    while window._active_worker is not None and time.monotonic()<deadline:
        app.processEvents();time.sleep(.005)
    assert window._active_worker is None
    assert not errors, errors
source=repo/'.work/tf51_release_readonly_20261008/p51_v2/mission51.ssflp'
window._Project_Open(source);finish()
opened_count=len(observations)
assert len(window._replay_store.Entries_Get())==2
save_profile=cProfile.Profile();save=flp_module.Project_Save
def profiled_save(*args,**kwargs):
    return save_profile.runcall(save,*args,**kwargs)
flp_module.Project_Save=profiled_save
assert window._Project_Write(root/'baseline.ssflp',background=True,save_data=True);finish()
save_profile.dump_stats(str(root/'flp_save_baseline.prof'))
stream=io.StringIO();pstats.Stats(save_profile,stream=stream).sort_stats('cumulative').print_stats(35)
(root/'flp_save_baseline_profile.txt').write_text(stream.getvalue(),encoding='utf-8')
(root/'flp_baseline_progress.json').write_text(json.dumps({'open':observations[:opened_count],'save':observations[opened_count:],'errors':[str(e) for e in errors]},indent=2,ensure_ascii=False),encoding='utf-8')
window._Project_SetDirty(False);window.close();app.processEvents()
print(json.dumps({'scg':metrics,'flp_open_events':opened_count,'flp_save_events':len(observations)-opened_count,'errors':errors},indent=2))
