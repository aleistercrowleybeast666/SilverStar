from pathlib import Path
p=Path('docs/USER_WORKFLOW.md'); lines=p.read_text(encoding='utf-8').splitlines()
assert '0.1.1' in lines[2]
lines[2]='本文面向当前 0.1.2 候选软件；新 GUI 行为、软件门禁和未完成项见[0.1.2 验收记录](GUI_ACCEPTANCE_0_1_2_20261008.md)。先前软件与板测记录保留原身份；[000051 静态复测](LOGGER_HEALTH_RETEST_20261008.md)不能代替 0.1.2 的硬件验收。'
for i,line in enumerate(lines):
    if line.startswith('切换档位会提示'):
        lines[i]='用户明确切换到轻量/最简时，按当前列表顺序保留各传感器类及遥测的第一个实例和原参数，移除后续超额实例；最简还移除 GNSS，且不能重新加入。移除实例的来源/资源绑定同步撤下，仍须审核剩余资源和其他冲突。回到完整/标准可以再次添加设备，但不会恢复已移除实例；原档策略、参数和协议预设仍可恢复。直接载入已有冲突配置不会自动删设备，生成必须拒绝，需明确切档或手动修改。多功能 IMU 内置气压与独立气压的所有权规则保持不变，不等于禁选 JY901B 气压。历史四档契约中的“切档保留冲突”由本次用户明确要求更新，见 0.1.2 记录。'
    if line.startswith('依次核对'):
        lines[i]=line.replace('依次核对','依次核对[当前 0.1.2 验收](GUI_ACCEPTANCE_0_1_2_20261008.md)、',1).replace('当前软件收尾','先前软件收尾')
p.write_text('\n'.join(lines)+'\n',encoding='utf-8')
p=Path('docs/FCCG/USER_GUIDE.md');text=p.read_text(encoding='utf-8')
text=text.replace('Project format 12；`.ssdecoder` / project-semantics 1.2，拒绝 decoder 1.1；\nPlatform 仍为 0.0.12，Record Catalog 与协议布局不变。','产品版本由根 `VERSION` 提供，当前为 0.1.2；project 格式保留 14/15/16/17 各自兼容边界，四档预设使用 17；`.ssdecoder` / project-semantics 1.2，拒绝 decoder 1.1。\nRecord Catalog 与协议布局不随产品补丁版本变化；历史证据和旧 decoder 保留原身份。新生成固件的版本头为 0.1.2；普通再生成仍保护用户拥有的旧 payload，不能仅凭新模型版本认定旧工程实际二进制已升级。')
text=text.replace('## 3. Flight Configuration','明确切换轻量/最简时，各传感器类及遥测按列表保留第一个实例和参数，移除后续超额实例；最简还移除并禁用 GNSS。切回完整/标准不会恢复已移除设备。直接载入旧冲突配置不会自动删设备，须修正后生成。详见[当前流程](../USER_WORKFLOW.md)和[0.1.2 验收](../GUI_ACCEPTANCE_0_1_2_20261008.md)。\n\n## 3. Flight Configuration',1)
p.write_text(text,encoding='utf-8')
p=Path('docs/README.md');text=p.read_text(encoding='utf-8');text=text.replace('- [FCCG documentation]','- [当前 0.1.2：四档归一化、原生 GUI、真实进度、软件门禁及剩余阻塞](GUI_ACCEPTANCE_0_1_2_20261008.md)\n- [FCCG documentation]',1);p.write_text(text,encoding='utf-8')
