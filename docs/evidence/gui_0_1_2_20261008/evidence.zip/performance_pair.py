from pathlib import Path
import subprocess,zipfile,io,json,hashlib
repo=Path.cwd();root=Path(__file__).resolve().parent;source=root/'baseline_source';source.mkdir(exist_ok=False)
archive=subprocess.check_output(['git','archive','--format=zip','b2fae225155a925dac475a2e95f8b978d76dde99','apps/SCG/src'])
with zipfile.ZipFile(io.BytesIO(archive)) as packed:
    for item in packed.infolist():
        assert (source/item.filename).resolve().is_relative_to(source.resolve())
    packed.extractall(source)
(root/'performance_archive.json').write_text(json.dumps({'git_archive_sha256':hashlib.sha256(archive).hexdigest(),'archive_bytes':len(archive),'scope':'Python app source only; no vendor, no git checkout changes'},indent=2))
for kind in ['before','after']:
    result=subprocess.run([str(repo/'apps/FLP/.venv/Scripts/python.exe'),str(root/'performance_clicks.py'),kind],cwd=repo,timeout=180)
    assert result.returncode==0,(kind,result.returncode)
