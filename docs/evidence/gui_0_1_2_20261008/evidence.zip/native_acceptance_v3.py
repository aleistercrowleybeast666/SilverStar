from pathlib import Path
import os,sys,time,json,hashlib,dataclasses,threading,errno
os.environ['QT_QPA_PLATFORM']='windows'
os.environ['OPENBLAS_NUM_THREADS']='1'
repo=Path.cwd();root=Path(__file__).resolve().parent/'native3'
root.mkdir(exist_ok=False)
sys.path[:0]=[str(repo/'apps/SCG/src'),str(repo/'apps/FLP/src'),str(repo/'apps/FLP')]
import numpy as np
from PySide6.QtCore import Qt,QTimer,QSettings
from PySide6.QtWidgets import QApplication,QMessageBox
from PySide6.QtTest import QTest
from silverstar_fccg.ui.main_window import MainWindow as ScgWindow
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.core.settings import SettingsStore
from silverstar_fccg.project.reference import ReferenceProject_Create
from silverstar_fccg.project.model import ProjectModel_Save
from silverstar_fccg.generator.source_graph import SourceGraph_Resolve

app=QApplication([]);assert app.platformName()=='windows'
settings=repo/'apps/SCG/.work/gui012-native3/settings.ini';settings.parent.mkdir(parents=True,exist_ok=False)
w=ScgWindow(SettingsStore(settings),service=FccgService(repo/'apps/SCG'))
w._MessageBox_Exec=lambda *a,**k:QMessageBox.StandardButton.Discard
errors=[];w._Error_Show=errors.append
w._model=ReferenceProject_Create(catalog=w._service.catalog)
first=w._model.DeviceInstance_Get('imu0')
w._Project_Refresh();w.show();app.processEvents()
measurements=[]
def action(name, fn):
    before=time.perf_counter();fn();elapsed=time.perf_counter()-before;app.processEvents()
    measurements.append({'name':name,'ui_call_seconds':elapsed})
for cycle in range(3):
    action('add '+str(cycle),lambda:QTest.mouseClick(w.devices_page.add_buttons['imu'],Qt.MouseButton.LeftButton))
    extra=next(i.instance_id for i in w._model.device_instances if i.instance_id!='imu0' and w._service.Plugin_Get(i.plugin).component_class=='imu')
    action('delete '+str(cycle),lambda:w.devices_page.device_combos[extra].setCurrentIndex(0))
action('add before compact',lambda:QTest.mouseClick(w.devices_page.add_buttons['imu'],Qt.MouseButton.LeftButton))
for tier in ['compact','minimal','full','standard','compact']:
    action('switch '+tier,lambda:w.devices_page.feature_tier_combo.setCurrentIndex(w.devices_page.feature_tier_combo.findData(tier)))
    assert w._model.DeviceInstance_Get('imu0')==first
    assert w._model.DeviceInstance_Get('imu1') is None
    if tier=='minimal':
        assert not any(w._service.Plugin_Get(i.plugin).component_class=='gnss' for i in w._model.device_instances)
        w._DeviceInstance_Change('gnss0','silverstar.device.gnss.neo_m9n')
        assert errors and not any(w._service.Plugin_Get(i.plugin).component_class=='gnss' for i in w._model.device_instances)
        errors.clear()
    if tier in ['full','standard']:
        assert not any(w._service.Plugin_Get(i.plugin).component_class=='gnss' for i in w._model.device_instances)
    assert not errors,errors
    SourceGraph_Resolve(w._model,w._service.catalog)
project=settings.parent/'project';project.mkdir()
ProjectModel_Save(w._model,project/'SilverStar.ssproject',w._service.policy)
w._project_root=project
action('production save',w._Project_Save)
action('production reopen',lambda:w._Project_Open(project))
assert w._model.DeviceInstance_Get('imu0')==first and w._model.DeviceInstance_Get('imu1') is None
assert not errors,errors
w.grab().save(str(root/'scg.png'));w.close();app.processEvents()
(root/'scg_result.json').write_text(json.dumps({'measurements':measurements,'first_instance':dataclasses.asdict(first),'source_graph_all_tiers':True,'save_reopen':True,'errors':errors},indent=2),encoding='utf-8')
print('SCG PASS',flush=True)

import silverstar_flp.ui.main_window as module
import silverstar_flp.core.artifacts as artifacts
from silverstar_flp.plugins.registry import builtin_registry
from silverstar_flp.decoder_profiles.discovery import DecoderProfileCache
from silverstar_flp.core.path_preferences import PathPreferences
from silverstar_flp.plugins.container_packages import TrustedContainerPluginManager
from silverstar_flp.core.project import Project_Load
from tests.test_project_artifacts import _Assert_Result
module.QSettings=lambda *a,**k:QSettings(str(root/'flp.ini'),QSettings.Format.IniFormat)
w=module.MainWindow(builtin_registry(),language='zh_CN',path_preferences=PathPreferences(root/'paths.json'),plugin_manager=TrustedContainerPluginManager(root/'plugins'))
w._log_open_coordinator.cache=DecoderProfileCache(root/'decoder')
w._Error_Show=errors.append;w.show();app.processEvents()
observations=[];beats=[];timer=QTimer();timer.setInterval(50);timer.timeout.connect(lambda:beats.append(time.perf_counter()));timer.start()
original_start=w._Task_Start
def start(worker,*args,**kwargs):
    original_start(worker,*args,**kwargs)
    worker.signals.progress.connect(lambda value,code:observations.append({'t':time.perf_counter(),'value':value,'code':code,'text':w.progress_bar.text(),'status':w.status_label.text()}),Qt.ConnectionType.QueuedConnection)
w._Task_Start=start
def finish(timeout=120):
    deadline=time.monotonic()+timeout
    while w._active_worker is not None and time.monotonic()<deadline:
        app.processEvents();time.sleep(.005)
    assert w._active_worker is None,'timeout'
source=repo/'.work/tf51_release_readonly_20261008/p51_v2/mission51.ssflp'
w._Project_Open(source);finish();assert not errors,errors
assert len(w._replay_store.Entries_Get())==2
real_entries=w._replay_store.Entries_Get()
path=root/'actual.ssflp'
assert w._Project_Write(path,background=True,save_data=True);finish();assert not errors,errors
w._Project_Open(path);finish();assert not errors,errors
for a,b in zip(real_entries,w._replay_store.Entries_Get()):_Assert_Result(a.result,b.result)
# Controlled larger sample: eight saved test runs, expanding actual result arrays
# for persistence/UI testing only. No new numerical computation or truth claim.
base=w._replay_store.Entries_Get()[1]
synthetic_bytes=0
for run in range(8):
    channels={}
    for key,series in base.result.channels.items():
        n=32768;indices=np.arange(n)%max(1,series.count)
        timestamps=np.linspace(int(series.timestamp_us[0]),int(series.timestamp_us[-1]),n,dtype=series.timestamp_us.dtype)
        values=np.asarray(series.values[indices]).copy()
        # Distinct finite values prevent an all-zero or identical storage workload.
        values=values + run*1e-8
        valid=np.asarray(series.valid[indices]).copy()
        channels[key]=dataclasses.replace(series,timestamp_us=timestamps,values=values,valid=valid)
        synthetic_bytes+=timestamps.nbytes+values.nbytes+valid.nbytes
    w._replay_store.Result_Add(dataclasses.replace(base.result,channels=channels),algorithm_name='Controlled persistence sample')
large_entries=w._replay_store.Entries_Get();assert len(large_entries)==10
large=root/'larger.ssflp';before=len(observations);started=time.perf_counter()
assert w._Project_Write(large,background=True,save_data=True);finish(180);assert not errors,errors
large_observations=observations[before:];large_seconds=time.perf_counter()-started
w._Project_Open(large);finish(180);assert not errors,errors
assert len(w._replay_store.Entries_Get())==10
for a,b in zip(large_entries,w._replay_store.Entries_Get()):_Assert_Result(a.result,b.result)
assert all('%' in row['text'] for row in observations if '|' in row['code'])
assert w.progress_bar.value()==1000
# Cancellation and deferred close during a real artifact write must preserve the
# prior atomic project. The bounded hold is test fault injection, never fake progress.
original_write=artifacts._ProgressStream.write
faults=[]
for mode in ['cancel','close']:
    before_hash=hashlib.sha256(large.read_bytes()).hexdigest();entered=threading.Event();release=threading.Event()
    def held(stream,data):
        if not entered.is_set():
            entered.set();assert release.wait(5)
        return original_write(stream,data)
    artifacts._ProgressStream.write=held
    try:
        w._Project_SetDirty(False)
        assert w._Project_Write(large,background=True,save_data=True)
        deadline=time.monotonic()+4
        while not entered.is_set() and time.monotonic()<deadline:app.processEvents();time.sleep(.005)
        assert entered.is_set()
        if mode=='cancel':w._Task_Cancel()
        else:w.close()
        release.set();finish()
        if mode=='cancel':
            assert hashlib.sha256(large.read_bytes()).hexdigest()==before_hash
            assert w.progress_bar.value()<1000
            faults.append({'mode':mode,'prior_project_preserved':True})
        else:
            assert w.progress_bar.value()==1000
            assert w._project.project_path==large
            faults.append({'mode':mode,'atomic_commit_completed_before_close':True})
    finally:release.set();artifacts._ProgressStream.write=original_write
    w.show();app.processEvents()
before_hash=hashlib.sha256(large.read_bytes()).hexdigest()
def full_disk(stream,data):raise OSError(errno.ENOSPC,'Controlled disk-full write')
artifacts._ProgressStream.write=full_disk
try:
    assert w._Project_Write(large,background=True,save_data=True);finish()
    assert errors and w.progress_bar.value()<1000
    assert hashlib.sha256(large.read_bytes()).hexdigest()==before_hash
    faults.append({'mode':'disk_full','prior_project_preserved':True,'errors':[str(e) for e in errors]});errors.clear()
finally:artifacts._ProgressStream.write=original_write
# Configuration-only reopen may retain history parameters, but never replay.
config=root/'configuration.ssflp'
assert w._Project_Write(config,background=True,save_data=False);finish()
w._Project_Open(config);finish();app.processEvents()
assert errors and all(str(e).startswith('project_result_recompute_required:') for e in errors),errors
configuration_notices=list(errors);errors.clear()
assert w._dataset is not None
assert not w._replay_store.Entries_Get()
assert not Project_Load(config).save_data_and_results
timer.stop();w.grab().save(str(root/'flp.png'))
result={'native_platform':app.platformName(),'real_mission':51,'actual_two_runs_roundtrip':True,'controlled_run_count':10,'controlled_array_bytes':synthetic_bytes,'large_save_seconds':large_seconds,'large_progress_event_count':len(large_observations),'large_progress_numeric':True,'ui_heartbeat_max_gap_s':max(np.diff(beats)) if len(beats)>1 else None,'faults':faults,'configuration_only_no_replay':True,'configuration_notices':configuration_notices,'errors':errors,'observations':observations}
(root/'flp_result.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8')
w._Project_SetDirty(False);w.close();app.processEvents()
print(json.dumps({key:value for key,value in result.items() if key!='observations'},indent=2),flush=True)
