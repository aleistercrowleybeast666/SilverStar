from pathlib import Path
import hashlib,json,difflib
root=Path(__file__).resolve().parent
old=Path('.work/finalized_health_20261008_v2/project/Flight_Controller/Generated/Src/project_metadata.c')
new=root/'software/project/Flight_Controller/Generated/Src/project_metadata.c'
before=old.read_text(encoding='utf-8');after=new.read_text(encoding='utf-8')
diff=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(old),tofile=str(new)))
(root/'extra_binding_metadata.patch').write_text(diff,encoding='utf-8')
result={'path':'Generated/Src/project_metadata.c','old_source':str(old),'old_sha256':hashlib.sha256(before.encode()).hexdigest(),'new_source':str(new),'new_sha256':hashlib.sha256(after.encode()).hexdigest(),'approval':False,'diff':diff}
(root/'extra_binding_metadata.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
