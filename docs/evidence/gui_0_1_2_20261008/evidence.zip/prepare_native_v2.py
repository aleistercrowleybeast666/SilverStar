from pathlib import Path
root=Path(__file__).resolve().parent
text=(root/'native_acceptance.py').read_text(encoding='utf-8')
text=text.replace("parent/'native'", "parent/'native2'")
text=text.replace('apps/SCG/.work/gui012-native/settings.ini','apps/SCG/.work/gui012-native2/settings.ini')
old="""assert hashlib.sha256(large.read_bytes()).hexdigest()==before_hash
        assert w.progress_bar.value()<1000
        faults.append({'mode':mode,'prior_project_preserved':True})"""
new="""if mode=='cancel':
            assert hashlib.sha256(large.read_bytes()).hexdigest()==before_hash
            assert w.progress_bar.value()<1000
            faults.append({'mode':mode,'prior_project_preserved':True})
        else:
            assert w.progress_bar.value()==1000
            assert w._project.project_path==large
            faults.append({'mode':mode,'atomic_commit_completed_before_close':True})"""
assert old in text
text=text.replace(old,new)
target=root/'native_acceptance_v2.py';assert not target.exists()
target.write_text(text,encoding='utf-8')
