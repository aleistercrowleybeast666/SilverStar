from pathlib import Path
import hashlib,json,subprocess,os,time,sys
repo=Path.cwd();out=Path(__file__).resolve().parent/'software'
source=repo/'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tests/Host/test_console.c'
target=out/'project/Flight_Controller/Tests/Host/test_console.c'
assert target.resolve().is_relative_to((repo/'.work/gui012_20261008/software').resolve())
# Explicit synchronization of this disposable fixture from the modified owner.
# Normal regeneration continues to preserve user payloads.
target.write_bytes(source.read_bytes())
assert target.read_bytes()==source.read_bytes()
env=dict(os.environ,PATH=str(repo/'apps/FLP/.venv/Scripts')+';D:/msys64/ucrt64/bin;D:/Arm GNU Toolchain/14.3 rel1/bin;'+os.environ.get('PATH',''))
command=['D:/msys64/ucrt64/bin/mingw32-make.exe','host-tests','HOST_CC=D:/msys64/ucrt64/bin/gcc.exe']
started=time.monotonic()
with (out/'host_v2.log').open('xb') as stream:
    result=subprocess.run(command,cwd=out/'project/Flight_Controller',env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=900)
(out/'host_v2_result.json').write_text(json.dumps({'owner_sync':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'generated_equal_owner':True,'command':command,'cwd':str(out/'project/Flight_Controller'),'exit_code':result.returncode,'elapsed_s':time.monotonic()-started},indent=2))
raise SystemExit(result.returncode)
