from pathlib import Path
import sys,os,json,subprocess,datetime,time,hashlib,runpy
repo=Path.cwd();out=Path(__file__).resolve().parent/'software'
out.mkdir(exist_ok=False)
sys.path.insert(0,str(repo/'apps/SCG/src'))
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.core.workspace import WorkspacePolicy
from silverstar_fccg.generator.assembler import ProjectAssembler
from silverstar_fccg.generator.multi_target import TargetGeneration_Apply,TargetScope
from silverstar_fccg.project.model import ProjectModel_Load
source=repo/'docs/evidence/logger_health_retest_20261008/generated_config.ssproject'
original=source.read_bytes();model=ProjectModel_Load(source)
assert model.identity.firmware_version=='0.1.2'
assert model.build.feature_tier=='full' and model.strategies['estimator']=='silverstar.algorithm.estimator.kf6'
assert model.modes['deployment']==['Delay'] and model.mode_parameters['deployment']['Delay']['delay']==10
target=out/'project';service=FccgService(repo/'apps/SCG')
assembler=ProjectAssembler(service.policy,service.catalog,WorkspacePolicy(target))
plan=assembler.Plan(model,target/'Flight_Controller');assert plan.valid and not plan.dangerous
TargetGeneration_Apply(model,service.catalog,service.policy,target,TargetScope.FLIGHT)
assert source.read_bytes()==original
project=target/'Flight_Controller'
owner=repo/'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload'
assert (project/'System/User/system_user_config.h').read_bytes()==(owner/'System/User/system_user_config.h').read_bytes()
config=(project/'System/User/system_user_config.h').read_text(encoding='utf-8')
assert '#define SILVERSTAR_VERSION_PATCH     2' in config and '"SILV0102"' in config
checker=runpy.run_path(str(project/'Tools/check_task_stacks.py'))
header_hash=checker['BindingSourceHash_Get'](config)
snapshot=out/'dirty_snapshot.patch';snapshot.write_bytes(subprocess.check_output(['git','diff','--binary']))
generation={'source':str(source),'source_sha256':hashlib.sha256(original).hexdigest(),'hardware':False,'final_field_candidate':False,'fixture':'One bounded previously accepted F407/KF6 Delay10 software fixture, now product0.1.2; no hardware config decisions.','header_normalized_sha256':header_hash,'header_binding_known':header_hash in checker['BindingSourceVersions_Get']('System/User/system_user_config.h'),'dirty_snapshot_sha256':hashlib.sha256(snapshot.read_bytes()).hexdigest(),'base_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()}
(out/'generation.json').write_text(json.dumps(generation,indent=2),encoding='utf-8')
print('GENERATED '+json.dumps(generation),flush=True)
make='D:/msys64/ucrt64/bin/mingw32-make.exe'
env=dict(os.environ,PATH=str(repo/'apps/FLP/.venv/Scripts')+';D:/msys64/ucrt64/bin;D:/Arm GNU Toolchain/14.3 rel1/bin;'+os.environ.get('PATH',''))
steps=[('architecture',[make,'architecture-check'],120),('power10',[make,'power10-check'],120),
       ('release',[make,'-j2','all','artifact-check','memory-report','GCC_PATH=D:/Arm GNU Toolchain/14.3 rel1/bin'],900),
       ('stack',[make,'-j2','stack-report','GCC_PATH=D:/Arm GNU Toolchain/14.3 rel1/bin'],180),
       ('analyzer',[make,'-j2','static-analysis','GCC_PATH=D:/Arm GNU Toolchain/14.3 rel1/bin'],900),
       ('host',[make,'host-tests','HOST_CC=D:/msys64/ucrt64/bin/gcc.exe'],900)]
for name,command,timeout in steps:
    started=time.monotonic();record={'command':command,'cwd':str(project),'utc_start':datetime.datetime.now(datetime.timezone.utc).isoformat(),**generation}
    print('START '+name,flush=True)
    with (out/(name+'.log')).open('xb') as stream:
        try:result=subprocess.run(command,cwd=project,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=timeout);record['exit_code']=result.returncode
        except subprocess.TimeoutExpired:record.update(exit_code=None,timed_out=True)
    record.update(elapsed_s=time.monotonic()-started,utc_end=datetime.datetime.now(datetime.timezone.utc).isoformat(),log_sha256=hashlib.sha256((out/(name+'.log')).read_bytes()).hexdigest())
    (out/(name+'_result.json')).write_text(json.dumps(record,indent=2),encoding='utf-8')
    print('END '+name+' '+str(record['exit_code']),flush=True)
    if name=='release' and record['exit_code']!=0:break
