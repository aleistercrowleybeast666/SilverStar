#include "system_project_parameters_if.h"
#include <stddef.h>
#include "silverstar_assert.h"

/* Generated from the selected manifest parameters and their actual values. */
#define PROJECT_MISSION_PARAMETER_COUNT 40U
static const SystemProjectParameter s_parameters[] =
{
    {0x0FA47BF5UL, 0x411C7AE1UL, SystemProjectParameterKind_Float32},
    {0x57E79461UL, 0x00000002UL, SystemProjectParameterKind_Int32},
    {0xF0955706UL, 0x411C7AE1UL, SystemProjectParameterKind_Float32},
    {0x5C69DFF0UL, 0x3B449BA6UL, SystemProjectParameterKind_Float32},
    {0x3A58B74DUL, 0x3DA3D70AUL, SystemProjectParameterKind_Float32},
    {0x99684B60UL, 0x38D1B717UL, SystemProjectParameterKind_Float32},
    {0xAE582E4DUL, 0x3A83126FUL, SystemProjectParameterKind_Float32},
    {0x01114AE5UL, 0x40800000UL, SystemProjectParameterKind_Float32},
    {0x061152C4UL, 0x40800000UL, SystemProjectParameterKind_Float32},
    {0x11116415UL, 0x41100000UL, SystemProjectParameterKind_Float32},
    {0xF93A3F79UL, 0x3E800000UL, SystemProjectParameterKind_Float32},
    {0xFE3A4758UL, 0x3E800000UL, SystemProjectParameterKind_Float32},
    {0x093A58A9UL, 0x3E800000UL, SystemProjectParameterKind_Float32},
    {0x4469F209UL, 0x3CF98AE7UL, SystemProjectParameterKind_Float32},
    {0x4369F076UL, 0x3CF98AE7UL, SystemProjectParameterKind_Float32},
    {0x4269EEE3UL, 0x3CF98AE7UL, SystemProjectParameterKind_Float32},
    {0xB2620FB0UL, 0x38D1B717UL, SystemProjectParameterKind_Float32},
    {0xB3621143UL, 0x38D1B717UL, SystemProjectParameterKind_Float32},
    {0xB46212D6UL, 0x38D1B717UL, SystemProjectParameterKind_Float32},
    {0x7ED66791UL, 0x3C23D70AUL, SystemProjectParameterKind_Float32},
    {0x7DD665FEUL, 0x3C23D70AUL, SystemProjectParameterKind_Float32},
    {0x7CD6646BUL, 0x3C23D70AUL, SystemProjectParameterKind_Float32},
    {0x0DDB4C0FUL, 0x3FC00000UL, SystemProjectParameterKind_Float32},
    {0xEB3531C1UL, 0x40200000UL, SystemProjectParameterKind_Float32},
    {0xD46251F6UL, 0x3E19999AUL, SystemProjectParameterKind_Float32},
    {0x0E28A755UL, 0x40200000UL, SystemProjectParameterKind_Float32},
    {0xE7652E40UL, 0x40D451ECUL, SystemProjectParameterKind_Float32},
    {0x9F3BEE05UL, 0x412D3F7DUL, SystemProjectParameterKind_Float32},
    {0xBF42AA31UL, 0x41135C29UL, SystemProjectParameterKind_Float32},
    {0xC1B969C8UL, 0x415D0E56UL, SystemProjectParameterKind_Float32},
    {0x5A53F0B8UL, 0x40800000UL, SystemProjectParameterKind_Float32},
    {0xCC526674UL, 0x00000000UL, SystemProjectParameterKind_Float32},
    {0x1979D71FUL, 0x00000000UL, SystemProjectParameterKind_Float32},
    {0xAA024F16UL, 0x00000000UL, SystemProjectParameterKind_Float32},
    {0x409F3A50UL, 0x00000000UL, SystemProjectParameterKind_Int32},
    {0x2F3B2C64UL, 0x0000010EUL, SystemProjectParameterKind_Int32},
    {0xA5DED4BDUL, 0x00000000UL, SystemProjectParameterKind_Int32},
    {0xAAB93B10UL, 0x00000001UL, SystemProjectParameterKind_Int32},
    {0xC31CB54DUL, 0x00000001UL, SystemProjectParameterKind_Int32},
    {0x21A1494AUL, 0x00000001UL, SystemProjectParameterKind_Int32},
};

uint16_t SystemProjectParameter_CountGet(void)
{ return PROJECT_MISSION_PARAMETER_COUNT; }

SystemProjectParameterResult SystemProjectParameter_Get(
    uint16_t index, SystemProjectParameter *parameter)
{
    if (parameter == NULL)
    { return SystemProjectParameterResult_InvalidArgument; }
    if (index >= PROJECT_MISSION_PARAMETER_COUNT)
    { return SystemProjectParameterResult_NotFound; }
    SILVERSTAR_ASSERT_OBJECT(parameter, SystemProjectParameter,
        SILVERSTAR_ASSERT_MODULE_GENERATED);
    *parameter = s_parameters[index];
    return SystemProjectParameterResult_Ok;
}
