from pathlib import Path
import sys, json, dataclasses, hashlib
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root/"apps/SCG/src"))
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.build.runner import BuildRunner,BuildAction
from silverstar_fccg.core.workspace import WorkspacePolicy
from silverstar_fccg.project.configuration import ProjectConfiguration_Reconcile
from silverstar_fccg.core.nis_probability import NisInput_Create
out=Path(__file__).resolve().parent
kind=sys.argv[1]
project=out/("generated_"+kind+"02")
assert not project.exists()
service=FccgService(root/"apps/SCG")
model=service.ReferenceProject_Create("nis013_"+kind)
component="silverstar.algorithm.estimator."+kind
if kind=="eskf15":
 model.strategies["estimator"]=component
 from copy import deepcopy
 from silverstar_fccg.project.logging import LoggingProfile_AvailabilityTransitionApply
 previous=service.ReferenceProject_Create("nis013_"+kind)
 LoggingProfile_AvailabilityTransitionApply(previous,model,service.catalog)
 model=service.ProjectConfiguration_Reconcile(model).model
model.algorithm_parameters[component]["nis_2d_soft"]=NisInput_Create(0.95,2)
model.algorithm_parameters[component]["nis_2d_hard"]=NisInput_Create(0.999,2)
from dataclasses import replace
model.build=replace(model.build,memory_layout="auto")
service.Project_Save(model,project,confirm_dangerous=True)
runner=BuildRunner(WorkspacePolicy(project))
result=runner.Run(model,project,BuildAction.BUILD,line_callback=print)
(out/("build_"+kind+"02_result.json")).write_text(json.dumps(dataclasses.asdict(result),indent=2),encoding="utf-8")
assert result.succeeded and result.diagnostic_status=="bound",result
print("FRESH_ARM_BUILD_AND_BIND_OK",kind)
