# Latest checkpoint (second continuation)

Local execution was briefly disconnected, then read-only git/status and log reads succeeded. HEAD remains 682b7bccbb404b119a35e85c061495018fb26c42; NIS changes are uncommitted. No code/source was discarded. No serial/probe/flash/reset/target action or cleanup.

## Main failure diagnosis, proven

The exact pre-NIS 682b7bcc KF6 C source and current C source, compiled with the same GCC 16.1.0, same input fixture and same generated numeric thresholds/headers, produce byte-identical 1,109,911-byte default trajectories: both SHA256 4deb49b19d86bd4a8ade8fb35013fb3f9b1e5347bc0b7cde9ace5266ff9525cb. See kf6_default_compare02/result.json and before.trace/after.trace (5005 lines). The frozen expected SHA ad64bc875b4ec87f0bafdd65e868bb99822b79dfe79fc0debf13ec9484486aa1 remains failed; its recorded source b2e05fb is not resolvable in this repo. Golden unchanged. This scoped comparison proves NIS did not change the default trajectory, not that the historical golden provenance has been reconstructed.

DF mapping: raw NIS, EN position/velocity joint residual df=2; U position/velocity and baro df=1 in both product estimators; KF6 3D thresholds reserved; SF6 no NIS. ESKF C reports post-soft-inflation NIS while Python retains gate-input NIS. Existing behavior preserved and documented.

## Implementation repairs and tests

- Fixed FLP language change losing primary probability (previously restored only actual numeric value).
- Fixed reset evaluating an invalid draft value as an eager dictionary fallback.
- Invalid drafts can now survive translation/runtime refresh while remaining rejected; no stale numeric readout is shown.
- Strict recorded DF declaration validates schema/raw definition/fraction units/integer df; malformed/unknown declarations do not fabricate recorded probabilities.
- SCG readout uses actual target float32 while preserving the untouched legacy input value.
- flp_migration02: 152 passed. kf6_switch_post01: 4 passed, all enable combinations, hard >= equality, invalid input/covariance preservation.
- Corrected pre-feature evidence: KF6 3 unsupported-switch failures/1 pass, ESKF 4 unsupported-switch/invalid-mask failures/4 passes; preserved expected normal and external-invalid-input checks.
- scg_final01: 182 passed, 1 historical hash mismatch; no skip, 112.43s.
- flp_migration_final02: 203 passed, exactly 7 old missing-model-revision failures, no skip, 21.33s. Old failure baseline remains flp_baseline02 (exact old KF6 modules/old navigation contract), not a whole-old-repository run. flp_migration_final01 had one missing-environment skip; final02 set SILVERSTAR_FCCG_ROOT and ran real C parity.
- lint_final01 --select F passed; no lint/gate weakened.

## Builds and gates, separated by configuration

- KF6 legacy layout custom probability95 and restored-default ARM builds/link/ssdiag bindings succeeded.
- ESKF legacy-layout link failed CCMRAM overflow 1664 bytes (generated_eskf1501 retained). Existing auto layout solved the configuration failure without shrinking/changing buffers or algorithms: generated_eskf1502 custom probability95 and restored-default ARM builds/link/ssdiag bindings succeeded. Linked auto RAM occupied117568/spare13504 (yellow); CCM occupied50208/spare15328. Not a stack/timing proof.
- Custom-probability artifacts archived before default validation in kf6_probability_artifacts and eskf_probability_artifacts with exact configurations and hashes. The unmodified generic Host test checks literal default soft2D=9.210, so custom95 (actual ~5.99146) fails its assumption; full kf6_gates01/eskf_gates01 recorded that failure without changing assertions. Their architecture/power10/real -fanalyzer/artifact checks passed.
- Restored defaults via prepare_defaults01.py only in task-owned projects; complete default gate sequences started separately.
- kf6_default_gates01 completed after the progress snapshot: architecture=0, power10=0, real static_analysis=0, host_tests=0, artifact=0. Full summary and logs retained. No command was stopped. Both complete default gate commands are now finished.
- eskf_default_gates01 completed: architecture=0, power10=0, real static_analysis=0, host_tests=2, artifact=0. Host fails at interfaces compile: Tests/Host/test_interfaces.c:23 asserts sizeof(SystemInertialIncrement)==40 unconditionally under the ESKF configuration. This is NOT the new NavigationEskfConfig mask type. Need inspect actual conditional increment layout and demonstrate pre-NIS headers/source baseline before deciding a narrow test contract repair; no assertion has been weakened or changed.
- All power10 passes explicitly retain critical-contract review NOT PROVEN; no original-P10/NASA/hardware/compliance claim.

## Remaining same-scope work

1. KF6 full default gate finished successfully; do not rerun it without a new change or unresolved concern.
2. Diagnose ESKF Host interface-layout assertion against pre-NIS source and current selected configuration. Preserve exact interface layout and safety expectations; if it is an outdated test assumption, repair the precise conditional contract only with proof, otherwise fix introduced owning source. No hidden exclusions/allowlist/golden changes.
3. Complete relevant migration/default/ESKF Host verification, review the final diff/source-graph/type contracts, optional small real-widget QA, formal evidence/command/tool-version/source/config/artifact hashes.
4. Update docs status, create a single independent local NIS commit once reviewable; acceptance must still disclose historical hash/missing-model tests and critical review NOT PROVEN. No push/tag/Release.

User input inventories and frozen v0.1.2 tag object/peeled commit reverified unchanged. Keep .work contents; no cleanup authorization. Source snapshots source_snapshot_checkpoint.json and a fresh source_snapshot_checkpoint02.json identify current code. KF6 default gate completion was verified from its result records before ending this checkpoint.
