from pathlib import Path
import os, sys, json, re, subprocess, hashlib, datetime
root=Path(__file__).resolve().parents[2]
out=Path(__file__).resolve().parent/"kf6_default_compare02"
out.mkdir(exist_ok=False)
project=root/"apps/SCG/.work/dev013_nis01/temp04/test_generated_defaults_numeri0/generated"
compiler=Path("D:/msys64/ucrt64/bin/gcc.exe")
assert project.is_dir() and compiler.is_file()
script=(project/"Tests/Host/run_tests.ps1").read_text(encoding="utf-8")
includes=re.findall(r'"-I\$repoRoot\\([^"\n]+)"',script)
assert includes
kernel="apps/SCG/plugins/builtin/silverstar_algorithm_estimator_kf6/payload/Algorithm/Estimator/KF6"
before=out/"before";before.mkdir()
old_c=subprocess.check_output(["git","show","682b7bcc:"+kernel+"/Src/navigation_kf.c"],cwd=root)
(before/"navigation_kf.c").write_bytes(old_c)
old_h=subprocess.check_output(["git","show","682b7bcc:"+kernel+"/Inc/navigation_kf.h"],cwd=root)
assert old_h.replace(b"\r\n",b"\n")== (project/"Algorithm/Estimator/KF6/Inc/navigation_kf.h").read_bytes().replace(b"\r\n",b"\n"), "C header content changed"
fixed_sources=["Algorithm/INS/Coning2Sculling2/Src/ins_mechanization.c", "Algorithm/Common/Src/attitude_frame.c", "System/Src/system_estimator_profile.c", "Common/Src/silverstar_assert.c"]
fixture=root/"apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tests/Host/test_algorithm_parameters.c"
headers={str(p.relative_to(project)):hashlib.sha256(p.read_bytes()).hexdigest() for p in project.rglob("*.h")}
records={"before_commit":"682b7bccbb404b119a35e85c061495018fb26c42","compiler_version":subprocess.check_output([str(compiler),"--version"],text=True),"input_fixture_sha256":hashlib.sha256(fixture.read_bytes()).hexdigest(),"before_kf_header_sha256":hashlib.sha256(old_h).hexdigest(),"kf_header_normalized_content_equal":True,"shared_header_hashes":headers,"sources":{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [*(project/x for x in fixed_sources),fixture]},"runs":[]}
env=dict(os.environ,TEMP=str(out),TMP=str(out));env["PATH"]=str(compiler.parent)+os.pathsep+env.get("PATH","")
for label,cfile in [("before",before/"navigation_kf.c"),("after",project/"Algorithm/Estimator/KF6/Src/navigation_kf.c")]:
 exe=out/(label+".exe")
 command=[str(compiler),"-std=c11","-Wall","-Wextra","-Werror","-pedantic","-O2","-include",str(project/"Generated/Inc/project_flight_config.h")]
 command += ["-I"+str(project/path.replace("\\","/")) for path in includes]
 command += [str(project/x) for x in fixed_sources]+[str(cfile),str(fixture),"-lm","-o",str(exe)]
 compile_result=subprocess.run(command,env=env,capture_output=True,timeout=90)
 (out/(label+"_compile.log")).write_bytes(compile_result.stdout+compile_result.stderr)
 assert compile_result.returncode==0,compile_result.stderr.decode(errors="replace")
 run=subprocess.run([str(exe)],env=env,capture_output=True,timeout=60)
 (out/(label+"_raw.trace")).write_bytes(run.stdout)
 (out/(label+"_stderr.log")).write_bytes(run.stderr)
 assert run.returncode==0,run.stderr
 trace=run.stdout.replace(b"\r\n",b"\n")
 (out/(label+".trace")).write_bytes(trace)
 records["runs"].append({"label":label,"command":command,"compile_exit":compile_result.returncode,"run_exit":run.returncode,"c_sha256":hashlib.sha256(cfile.read_bytes()).hexdigest(),"trace_bytes":len(trace),"trace_sha256":hashlib.sha256(trace).hexdigest()})
records["before_after_byte_equal"]=(out/"before.trace").read_bytes()==(out/"after.trace").read_bytes()
frozen=json.loads((root/"apps/SCG/tests/fixtures/algorithm_parameters_golden.json").read_text(encoding="utf-8"));records["frozen_golden"]=frozen
(out/"result.json").write_text(json.dumps(records,indent=2)+"\n",encoding="utf-8")
assert records["before_after_byte_equal"],"NIS task changed default trajectory"
print(json.dumps({"before_after_byte_equal":True,"before_sha256":records["runs"][0]["trace_sha256"],"after_sha256":records["runs"][1]["trace_sha256"],"frozen_sha256":frozen["trajectory_sha256"],"bytes":records["runs"][0]["trace_bytes"]}))
