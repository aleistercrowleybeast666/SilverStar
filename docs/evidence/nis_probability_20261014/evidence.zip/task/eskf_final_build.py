from pathlib import Path
import sys,json,dataclasses
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root/"apps/SCG/src"))
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.build.runner import BuildRunner,BuildAction
from silverstar_fccg.core.workspace import WorkspacePolicy
out=Path(__file__).resolve().parent
service=FccgService(root/"apps/SCG")
model=service.Project_Open(out/"generated_eskf1502/SilverStar.ssproject")
project=out/"generated_eskf1503"
assert not project.exists()
service.Project_Save(model,project,confirm_dangerous=True)
result=BuildRunner(WorkspacePolicy(project)).Run(model,project,BuildAction.BUILD,line_callback=lambda line:print(line,flush=True))
data=dataclasses.asdict(result);data.pop("output",None)
(out/"eskf_final_arm_result.json").write_text(json.dumps(data,indent=2),encoding="utf-8")
assert result.succeeded and result.diagnostic_status=="bound",result
print("FINAL_ESKF_ARM_AND_BIND_OK")
