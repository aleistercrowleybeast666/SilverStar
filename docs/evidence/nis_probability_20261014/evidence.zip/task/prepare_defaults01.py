from pathlib import Path
import sys,json,hashlib,shutil,dataclasses
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root/"apps/SCG/src"))
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.build.runner import BuildRunner,BuildAction
from silverstar_fccg.core.workspace import WorkspacePolicy
out=Path(__file__).resolve().parent
project=out/sys.argv[1]
archive=out/(sys.argv[2]+"_probability_artifacts")
archive.mkdir(exist_ok=False)
service=FccgService(root/"apps/SCG")
model=service.Project_Open(project/"SilverStar.ssproject")
model.build=dataclasses.replace(model.build,tool_paths={**model.build.tool_paths,"host_gcc":"D:/msys64/ucrt64/bin/gcc.exe"})
records=[]
for p in project.rglob("*"):
 if not p.is_file():continue
 relative=p.relative_to(project)
 keep=(relative.as_posix() in {"SilverStar.ssproject","Generated/Inc/project_algorithm_parameters.h","Generated/Src/project_mission_parameters.c",".fccg/ownership.json"}
       or p.suffix in {".elf",".map",".ssdecoder",".ssdiag"} or p.name in {"memory_layout_report.json","artifact_report.json"})
 if keep:
  target=archive/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
  records.append({"path":relative.as_posix(),"bytes":p.stat().st_size,"sha256":hashlib.sha256(p.read_bytes()).hexdigest()})
(archive/"inventory.json").write_text(json.dumps({"owner":"NIS task","purpose":"retain exact probability95/custom build before separate default validation","configuration":model.Dictionary_Get(),"files":records},indent=2),encoding="utf-8")
selected=model.strategies["estimator"]
owner=service.Plugin_Get(selected)
for p in owner.algorithm_parameters:
 if p.nis_df or p.parameter_id in {"nis_soft_enabled","nis_hard_enabled"}:
  model.algorithm_parameters[selected][p.parameter_id]=p.default
service.Project_Save(model,project,confirm_dangerous=True)
result=BuildRunner(WorkspacePolicy(project)).Run(model,project,BuildAction.BUILD,line_callback=lambda line:print(line,flush=True))
data=dataclasses.asdict(result);data.pop("output",None)
(out/(sys.argv[2]+"_default_arm_result.json")).write_text(json.dumps(data,indent=2),encoding="utf-8")
assert result.succeeded and result.diagnostic_status=="bound",result
print("DEFAULT_ARM_BUILD_AND_BIND_OK",selected)
