from pathlib import Path
import os,re,subprocess,json
root=Path(__file__).resolve().parents[3]
out=Path(__file__).resolve().parent
project=root/".work/dev013_nis01/generated_eskf1502"
runner=(project/"Tests/Host/run_tests.ps1").read_text(encoding="utf-8")
includes=re.findall(r'"-I\$repoRoot\\([^"\n]+)"',runner)
assert includes
records=[]
for version in ["before","after"]:
 for enabled in [0,1]:
  for auto in [0,1]:
   name=f"{version}_eskf{enabled}_auto{auto}"
   exe=out/(name+".exe")
   fixture=(out/"before/Tests/Host/test_interfaces.c" if version=="before" else root/"apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tests/Host/test_interfaces.c")
   command=["D:/msys64/ucrt64/bin/gcc.exe","-std=c11","-O2","-Wall","-Wextra","-Werror","-pedantic",f"-DSYSTEM_BUILD_ESKF15_ENABLED={enabled}",f"-DSILVERSTAR_MEMORY_LAYOUT_AUTO={auto}"]
   if version=="before": command += ["-I"+str(out/"before/Interfaces/Inc")]
   command += ["-I"+str(project/x.replace("\\","/")) for x in includes]
   command += [str(fixture),"-o",str(exe)]
   env=dict(os.environ,TEMP=str(out),TMP=str(out));env["PATH"]="D:/msys64/ucrt64/bin"+os.pathsep+env.get("PATH","")
   compile_result=subprocess.run(command,capture_output=True,text=True,env=env,timeout=60)
   (out/(name+"_compile.log")).write_text(compile_result.stdout+compile_result.stderr,encoding="utf-8")
   expected=1 if version=="before" and enabled else 0
   assert (compile_result.returncode!=0)==bool(expected),compile_result.stdout+compile_result.stderr
   run=None
   if compile_result.returncode==0:
    run=subprocess.run([str(exe)],capture_output=True,text=True,env=env,timeout=20)
    (out/(name+"_run.log")).write_text(run.stdout+run.stderr,encoding="utf-8")
    assert run.returncode==0,run.stdout+run.stderr
   records.append({"version":version,"eskf_enabled":enabled,"memory_auto":auto,"command":command,"compile_exit":compile_result.returncode,"run_exit":run.returncode if run else None,"expected_old_failure":bool(expected)})
(out/"matrix_result.json").write_text(json.dumps(records,indent=2)+"\n",encoding="utf-8")
print("INTERFACE_MATRIX_CONFIRMED",len(records),"old ESKF fails; corrected exact offsets/sizes pass both memory layouts")
