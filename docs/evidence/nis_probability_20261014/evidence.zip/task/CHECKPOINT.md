Latest continuation status: see CHECKPOINT_LATEST.md and checkpoint_progress02.json.

ESKF continuation: arm_eskf15_02 compiled C successfully but legacy-layout link failed, CCMRAM overflow 1664 bytes. Exact failed project remains generated_eskf1501. generate_build03.py selects the existing auto layout in a separate generated_eskf1502 project; no buffer/code algorithm change. This is a configuration-specific failure, not a claimed build pass.

# Latest continuation result

2026-10-14: Same GCC 16.1.0, input fixture, generated numeric thresholds and headers: pre-NIS 682b7bcc KF6 and current KF6 produce byte-identical 1,109,911-byte trajectories, both SHA256 4deb49b19d86bd4a8ade8fb35013fb3f9b1e5347bc0b7cde9ace5266ff9525cb. Frozen golden SHA ad64bc875b4ec87f0bafdd65e868bb99822b79dfe79fc0debf13ec9484486aa1 still fails. Golden's b2e05fb source commit cannot be resolved in this repo. NIS did not introduce this default-trace difference; frozen-source validity remains unproven. Golden unchanged. Commands, shared input/header/source hashes and both complete traces: kf6_default_compare02/result.json. ESKF15 ARM now running via arm_eskf15_02 (session 88934).

Audited df: horizontal GNSS position/velocity joint E,N -> 2; vertical position/velocity U and baro -> 1 for KF6/ESKF15; KF6 df=3 reserved configuration only; SF6 no NIS. Both use raw quadratic forms, not normalization by state/residual size. ESKF C reports recomputed post-soft NIS whereas FLP retains gate-input NIS; comparison labels must preserve that existing difference.

# NIS task checkpoint — 2026-10-14

Requested by the parent because live commentary is not visible and connections have interrupted execution. This is an implementation checkpoint, not completion or acceptance. No NIS commit has been created; HEAD remains 682b7bccbb404b119a35e85c061495018fb26c42 on feature/usb-transport-0.1.3-20261013.

## Preserved implementation

- Source mapping and statistical caveats: docs/public/SCG/NIS_PROBABILITY_0_1_3.md.
- contracts/nis_probability_v1.json: 110 independent SciPy 1.16.3 vectors, df 1/2/3/5/6/10/15/30/100/256, lower/upper tails.
- Identical pure-Python CDF/PPF modules in SCG and FLP; no SciPy runtime dependency, bounded iteration, validation before memoization.
- SCG declarative nis_df, percentage editor with numeric/df readout, typed primary probability schema silverstar.nis-cdf-input/1.0 (fraction), project format 18 only when needed. Untouched numeric values remain numeric, including finite values whose CDF displays 100%.
- FLP Replay percentage editor and optional versioned nis_inputs saved separately from actual_values. Recorded mode without declared df shows numeric values/unknown df; no fabricated probability. Recorded and Recomputed remain separate.
- Explicit default-on soft/hard enabled integer parameters and checkbox controls. KF6 owning C uses compile-time numeric controls; ESKF15 owning C config appends a validated disabled bit mask. Existing gate comparisons, inflation formulas and default paths retained. ctypes producer bindings updated for the new C config layout.
- ESKF old/preserved source identity guard added to assembler; must still add/run its focused tests. Normal generation must not describe preserved old ESKF source as supporting new switches.
- Existing ESKF C reported NIS is recomputed after soft R inflation; FLP retains pre-inflation gate NIS. Documented and test expectations account for this existing difference. No filter math fix introduced for it.
- Source fixtures updated for the added config layout; historical traces/archives/NPZ/JSON golden evidence left unchanged. New parameter count checks explicitly test both added default-on controls.

## Recorded runs

- scg_selected04: 175 passed, 1 failed, 87.34s. All new probability tests and old ESKF full-state exact-trace regressions passed. Remaining failure is the existing frozen default trajectory hash assertion; actual 4deb49b19d86bd4a8ade8fb35013fb3f9b1e5347bc0b7cde9ace5266ff9525cb versus expected ad64bc875b4ec87f0bafdd65e868bb99822b79dfe79fc0debf13ec9484486aa1. Pre-change C comparison is still REQUIRED; do not label this as pre-existing yet and do not update the golden to make it green.
- flp_selected02: 55 passed, 7 failed; actual C parity test ran with SILVERSTAR_FCCG_ROOT, no skip. Those 7 failures (missing KF6 process-model revision in old synthetic inputs) reproduced in flp_baseline02 using exact 682b7bcc KF6 filter/fixed_lag/plugin and old navigation contract. Keep missing-identity checks intact. This is not a full old-repository test run.
- flp_nis01/02: authoring failures in new tests, not a production assertion weakened. Initial test wrongly assumed pre-gate NIS reporting and then used an incorrect ctypes field name. Both fixed in test expectations. flp_nis03 passed all 142 cases in 5.74s (conversion, actual C gates/faults and Replay GUI).
- eskf_pre_feature01: expected unsupported-switch demonstrations plus initial authoring failures; rerun corrected tests against retained pre_feature_eskf before claiming complete pre/post evidence.
- scg_selected03 was interrupted: session 43671 vanished; no final exit JSON. scg_selected03_interrupted.json records NOT PROVEN. No completion inferred from progress dots.
- numpy_dependency01 succeeded: fixed NumPy 2.4.1 installed only in the existing repo .venv (system NumPy 2.4.0 preserved). No new venv/SDK.
- All other failed attempts, commands and complete available logs retained under this task directory.

## Active / corrected commands

- arm_kf6_01: completed, exit 0, fresh generated_kf601 ARM compilation/link and ssdiag binding succeeded. Exact result in build_kf601_result.json and complete arm_kf6_01.log. No hardware access. Other emitted gates/static analyzer/Host suite remain pending.
- arm_eskf15_01 failed before generation: script ignored ProjectConfiguration_Reconcile's returned candidate. generate_build02.py corrects this and handles logging selection transition. generated_eskf1501 does not yet exist. Start a new named run only after verifying that remains true.
- flp_nis03: completed, exit 0, 142 passed in 5.74s.

## Next work (same scope)

1. Both checkpoint commands have completed (KF6 ARM exit 0 and FLP 142 passed); no task-owned command remains active. Inspect recorded logs before further runs.
2. Add focused ESKF preserved-source guard tests, FLP saved primary probability roundtrip/invalid metadata tests, and actual KF6 switch normal/fault/equality tests. Check the new checkbox/readout translations and typed-input source graph paths.
3. Compare the failed SCG default trajectory against exact pre-change C source in an isolated task-owned project; preserve all hashes and unchanged frozen evidence. If introduced by this task, fix the owning source and rerun. If baseline fails identically, report that scoped fact.
4. Rerun corrected pre-feature ESKF switch demonstration and current post tests; retain normal and invalid-input expectations.
5. Correctly generate/build ESKF15 via generate_build02.py; verify emitted project format 18 loads and numeric thresholds compile. Existing KF6 source copied before the final generator-only guard change: record scope or rerun generation as needed; never attribute a different source snapshot to a binary.
6. Run exact generated architecture-check, power10-check, artifact-check, Host regressions, real -fanalyzer and ARM link for both selected estimator projects. Power10 critical-contract manual review must remain NOT PROVEN; no complete-compliance/hardware claim.
7. Complete formal commands/tool versions/source snapshots/configuration/source+artifact hashes/failure records; update document status; create one independent local NIS commit only when ready. No push/tag/Release.

## Ownership/safety

Only this root writes the repo. Additional app-local test parent apps/SCG/.work/dev013_nis01 is required by SCG test WorkspacePolicy; inventory.json records it. No cleanup performed or authorized. Three user input lists remain byte-identical to inventory baseline. v0.1.2 tag object 942f20ef64df3cb1aa65be7349361c409418aa0f and peeled c31c13cc0686a56a3184d4f207fd3816c5d39696 unchanged. No serial/DAP/ST-Link, flash, halt, reset, target write, actuator, flight logic or navigation-algorithm operation. Current changes are uncommitted; preserve them on continuation.
