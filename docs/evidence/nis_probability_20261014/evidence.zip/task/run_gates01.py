from pathlib import Path
import sys,json,dataclasses
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root/"apps/SCG/src"))
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.build.runner import BuildRunner,BuildAction
from silverstar_fccg.core.workspace import WorkspacePolicy
out=Path(__file__).resolve().parent
project=out/sys.argv[1]
service=FccgService(root/"apps/SCG")
model=service.Project_Open(project/"SilverStar.ssproject")
model.build=dataclasses.replace(model.build,tool_paths={**model.build.tool_paths,"host_gcc":"D:/msys64/ucrt64/bin/gcc.exe"})
runner=BuildRunner(WorkspacePolicy(project))
records=[]
for action in [BuildAction.ARCHITECTURE_CHECK,BuildAction.POWER10_CHECK,BuildAction.STATIC_ANALYSIS,BuildAction.HOST_TESTS,BuildAction.ARTIFACT_CHECK]:
 print("GATE_BEGIN",action,flush=True)
 result=runner.Run(model,project,action,line_callback=lambda line: print(line,flush=True))
 data=dataclasses.asdict(result);data.pop("output",None)
 (out/(sys.argv[2]+"_"+action.value+".json")).write_text(json.dumps(data,indent=2),encoding="utf-8")
 (out/(sys.argv[2]+"_"+action.value+".log")).write_text(result.output,encoding="utf-8")
 records.append({"action":action.value,"return_code":result.return_code})
 print("GATE_END",action,result.return_code,flush=True)
(out/(sys.argv[2]+"_summary.json")).write_text(json.dumps({"project":str(project),"configuration":model.Dictionary_Get(),"gates":records,"critical_contract_review":"NOT PROVEN"},indent=2),encoding="utf-8")
raise SystemExit(0 if all(item["return_code"]==0 for item in records) else 1)
