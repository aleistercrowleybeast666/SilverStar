from pathlib import Path
import sys,json,struct
root=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(root/"apps/SCG/src"),str(root/"apps/FLP/src")]
from PySide6.QtWidgets import QApplication,QWidget,QHBoxLayout,QVBoxLayout,QGroupBox,QFormLayout,QLabel
from PySide6.QtGui import QFont
from silverstar_fccg.ui.nis_editor import NisProbabilityEditor as ScgEditor,GateEnableEditor as ScgGate
from silverstar_flp.ui.nis_editor import NisProbabilityEditor as FlpEditor,GateEnableEditor as FlpGate
from silverstar_fccg.core.nis_probability import NisInput_Create
out=Path(__file__).resolve().parent
app=QApplication([]);app.setFont(QFont("Microsoft YaHei UI",10))
examples=[]
for language in ["zh_CN","en_US"]:
 window=QWidget();window.setWindowTitle("Actual NIS widgets — offscreen QA")
 layout=QHBoxLayout(window)
 for name,editor_type,gate_type in [("SCG",ScgEditor,ScgGate),("FLP",FlpEditor,FlpGate)]:
  box=QGroupBox(name);form=QFormLayout(box)
  for kind,p in [("soft",.95),("hard",.999)]:
   editor=editor_type(2,.001,10000.,language);editor.setValue(NisInput_Create(p,2))
   form.addRow(("软覆盖率" if kind=="soft" else "硬覆盖率") if language=="zh_CN" else kind+" coverage",editor)
   gate=gate_type();gate.setValue(1);form.addRow("启用" if language=="zh_CN" else "Enabled",gate)
   examples.append({"app":name,"language":language,"df":2,"probability":p,"actual":editor.value(),"float32_hex":struct.pack("<f",editor.value()).hex(),"readout":editor.readout.text()})
  recorded=editor_type(1,.001,10000.,language);recorded.setValue(6.635);recorded.NumericDisplay_Set(True);recorded.setReadOnly(True)
  form.addRow("历史未声明自由度" if language=="zh_CN" else "Recorded df unavailable",recorded)
  layout.addWidget(box)
 window.resize(1240,390);window.show();app.processEvents()
 assert window.grab().save(str(out/("widgets_"+language+".png")))
 window.close();app.processEvents()
(out/"widget_examples.json").write_text(json.dumps({"scope":"actual widgets rendered offscreen; not native/hardware validation","examples":examples},ensure_ascii=False,indent=2),encoding="utf-8")
print("ACTUAL_WIDGET_OFFSCREEN_QA_READY")
