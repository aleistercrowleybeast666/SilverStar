import sys, os, subprocess, types
from pathlib import Path
import pytest
ROOT=Path(__file__).resolve().parents[2]
REV="682b7bccbb404b119a35e85c061495018fb26c42"
import silverstar_flp.plugins.algorithms.kf6.plugin
import silverstar_flp.plugins.algorithms.eskf15.plugin
for name,path in [
 ("silverstar_flp.plugins.algorithms.kf6.filter", "apps/FLP/src/silverstar_flp/plugins/algorithms/kf6/filter.py"),
 ("silverstar_flp.plugins.algorithms.kf6.fixed_lag", "apps/FLP/src/silverstar_flp/plugins/algorithms/kf6/fixed_lag.py"),
 ("silverstar_flp.plugins.algorithms.kf6.plugin", "apps/FLP/src/silverstar_flp/plugins/algorithms/kf6/plugin.py"),
 ("silverstar_flp.plugins.algorithms.eskf15.plugin", "apps/FLP/src/silverstar_flp/plugins/algorithms/eskf15/plugin.py")]:
 code=subprocess.check_output(["git","show",f"{REV}:{path}"],cwd=ROOT).decode("utf-8")
 module=types.ModuleType(name); module.__file__=str(ROOT/path); module.__package__=name.rsplit(".",1)[0]
 sys.modules[name]=module
 if name.endswith("eskf15.plugin"):
  from unittest.mock import patch
  original=Path.read_text
  old_contract=subprocess.check_output(["git","show",f"{REV}:contracts/navigation_v1.json"],cwd=ROOT).decode("utf-8")
  def read_old(path,*args,**kwargs):
   return old_contract if path.resolve()==(ROOT/"contracts/navigation_v1.json").resolve() else original(path,*args,**kwargs)
  with patch.object(Path,"read_text",read_old):
   exec(compile(code,module.__file__,"exec"),module.__dict__)
 else:
  exec(compile(code,module.__file__,"exec"),module.__dict__)
import silverstar_flp.plugins.registry as registry
import importlib
importlib.reload(registry)
raise SystemExit(pytest.main(sys.argv[1:]))
