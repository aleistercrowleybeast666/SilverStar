"""Read exact newly generated mode2 package; never upgrade/replace old inputs."""
import hashlib
import json
from pathlib import Path
import sys
root = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(root/'apps/SCG/src'), str(root/'apps/FLP/src')]
from silverstar_flp.decoder_profiles.package import DecoderProfilePackage
from silverstar_flp.decoder_profiles.fusion_timing import FusionTiming_FromSemantics
from silverstar_flp.decoder_profiles.kf6_revision import Kf6Revision_FromSemantics

task = Path(__file__).resolve().parent
project = task/sys.argv[1]
packages = list(project.glob('*.ssdecoder'))
assert len(packages) == 1
source = packages[0]
before = hashlib.sha256(source.read_bytes()).hexdigest()
package = DecoderProfilePackage.Load(source)
document = package.semantics.raw_metadata
identity = FusionTiming_FromSemantics(document)
assert identity.mode == 2 and identity.horizon_us == 300000 and not identity.unavailable_reason
assert identity.version == ('0.4.0' if identity.component.endswith('kf6') else '0.3.0')
if identity.component.endswith('kf6'):
    assert Kf6Revision_FromSemantics(document) == 2
header = (project/'Generated/Inc/project_algorithm_parameters.h').read_text(encoding='utf-8')
assert '#define SYSTEM_FUSION_TIMING_MODE 2' in header and '#define SYSTEM_FUSION_HORIZON_MS 300' in header
assert hashlib.sha256(source.read_bytes()).hexdigest() == before
receipt = {'owner': '/root normal mode2 package admission', 'package': str(source), 'sha256': before,
           'identity': identity.__dict__, 'scope': 'normal SCG generated headers + exact FLP package loading; not a log-open/board/flight claim'}
(task/(project.name+'_decoder_receipt.json')).write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(receipt, indent=2))
