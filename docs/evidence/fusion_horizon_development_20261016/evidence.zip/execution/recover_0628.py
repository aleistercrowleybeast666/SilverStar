"""Preserve incomplete gate results after the second transport disconnect."""
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import subprocess

TASK = Path(__file__).resolve().parent
ROOT = TASK.parents[1]
record = {'owner': '/root', 'utc': datetime.now(timezone.utc).isoformat(),
    'reason': 'exec-server transport disconnected / pong_timeout; original sessions unknown after reconnect',
    'process_check': 'Get-Process runner/compiler names returned no matching processes before continuation',
    'original_sessions': [96350, 98206], 'exit_code': None,
    'status': 'INTERRUPTED_NO_FINAL_ARM_RESULT', 'completed': {}, 'partial_artifacts': {},
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()}
for name in ('kf6_2_native02', 'eskf15_2_native02'):
    for suffix in ('POWER10_CHECK', 'remaining02_STATIC_ANALYSIS'):
        path = TASK / (name + '_' + suffix + '.json')
        result = json.loads(path.read_text(encoding='utf8'))
        record['completed'][path.name] = {'return_code': result['return_code'],
            'receipt_sha256': sha256(path.read_bytes()).hexdigest()}
    assert not (TASK / (name + '_remaining02_BUILD.json')).exists()
    for path in (TASK / name / 'build').rglob('*'):
        if path.is_file() and path.suffix in ('.elf', '.o', '.map', '.su'):
            record['partial_artifacts'][str(path.relative_to(TASK))] = {
                'size': path.stat().st_size, 'sha256': sha256(path.read_bytes()).hexdigest()}
with (TASK / 'RECOVERED_20261016_0628.json').open('x', encoding='utf8') as stream:
    json.dump(record, stream, indent=2)
print('preserved', len(record['partial_artifacts']), 'partial artifacts; no full ARM gate pass')
