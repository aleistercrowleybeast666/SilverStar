"""Exact opaque wire comparison across the private event-layout memory fix."""
from hashlib import sha256
import json
from pathlib import Path
import sys

TASK = Path(__file__).resolve().parent
ROOT = TASK.parents[1]
sys.path.insert(0, str(ROOT/'apps/FLP/src'))
from silverstar_flp.decoder_profiles import DecoderProfileCache
from silverstar_flp.log_open import LogOpenCoordinator, LogOpenRequest
from silverstar_flp.plugins.registry import builtin_registry

output = TASK/'layout_wire_comparison01'
output.mkdir(exist_ok=False)
rows = []
for project_name, log_name in (
    ('kf6_2_native02', 'native_horizon_log_open_pytest02/native_kf60/native.sslog'),
    ('kf6_2_native03', 'native_kf_memory_log_pytest03/native_kf60/native.sslog')):
    log = TASK/log_name
    decoder, = (TASK/project_name).glob('*.ssdecoder')
    dataset = LogOpenCoordinator(builtin_registry(), cache=DecoderProfileCache(output/project_name)).Open(
        LogOpenRequest(log_path=log, decoder_package_path=decoder)).dataset
    names = ('ESTIMATOR', 'KF6_FULL_P', 'FUSION_HORIZON_MEASUREMENT',
        'FUSION_HORIZON_STATUS', 'ESTIMATOR_STEP', 'INERTIAL_INCREMENT')
    counts = {name: len(dataset.Records_Get(name)) for name in names}
    types = {record.record_type for name in names for record in dataset.Records_Get(name)}
    data = log.read_bytes()
    offset, frames = 64, []
    while offset < len(data):
        assert data[offset:offset+4] == b'FLG1'
        size = int.from_bytes(data[offset+6:offset+8], 'little') + 28
        if data[offset+5] in types: frames.append(data[offset:offset+size])
        offset += size
    assert offset == len(data)
    rows.append((counts, b''.join(frames)))
assert rows[0] == rows[1], 'An owning serialized numerical/body/timing byte changed'
baseline = json.loads((TASK/'focused_product_regression01.json').read_text(encoding='utf8'))
snapshot = TASK/'before_activation_test01.py'
expected = baseline['source_sha256']['apps/FLP/tests/test_fusion_horizon_records.py']
assert sha256(snapshot.read_bytes()).hexdigest() == expected, 'Before-test snapshot is not original failure input'
with (output/'receipt.json').open('x', encoding='utf8') as stream:
    json.dump({'owner': '/root memory fix verification', 'counts': rows[0][0],
        'compared_wire_bytes': len(rows[0][1]), 'bitwise_equal': True,
        'wire_sha256': sha256(rows[0][1]).hexdigest(),
        'before_activation_test_sha256_verified': expected,
        'scope': 'six owning C body/output/full-P/timing record types through exact package opens; no hardware'}, stream, indent=2)
print('bitwise equal:', rows[0][0], len(rows[0][1]), 'wire bytes')
