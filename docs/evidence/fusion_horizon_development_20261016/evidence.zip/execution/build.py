"""Real emitted actions and O0 links in task-owned build directories."""
from pathlib import Path
from datetime import datetime, timezone
import dataclasses
import hashlib
import json
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
TASK = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "apps/SCG/src"))
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.build.runner import BuildAction, BuildRunner
from silverstar_fccg.core.workspace import WorkspacePolicy

project = (TASK / sys.argv[1]).resolve()
assert project.parent == TASK and project.is_dir()
model = FccgService(ROOT / "apps/SCG").Project_Open(project / "SilverStar.ssproject")
runner = BuildRunner(WorkspacePolicy(project))
failed = False
actions = sys.argv[2:]
suffix = actions.pop(0)[9:] if actions and actions[0].startswith("--suffix=") else ""
assert not suffix or suffix.replace("_", "").isalnum()
for action in actions:
    name = project.name + ("_" + suffix if suffix else "") + "_" + action
    assert not (TASK / (name + ".json")).exists()
    started = time.monotonic()
    if action == "STACK_REPORT":
        command = ["mingw32-make", "TARGET_PROFILE=SilverStar_F407", "CONFIG=Release",
                   "MEMORY_LAYOUT=" + model.build.memory_layout, "stack-report"]
        run = subprocess.run(command, cwd=project, capture_output=True, text=True, encoding="utf-8", errors="replace")
        text = run.stdout + run.stderr
        record = {"command": command, "return_code": run.returncode}
    elif action == "O0":
        layout = "auto" if project.name.startswith("eskf15") else "legacy"
        build_root = "build/FCCG/SilverStar_F407/ReleaseO0/" + layout
        command = ["mingw32-make", "-j2", "TARGET_PROFILE=SilverStar_F407", "CONFIG=Release",
                   "OPT=-O0", "MEMORY_LAYOUT=" + layout, "BUILD_ROOT=" + build_root, "all"]
        run = subprocess.run(command, cwd=project, capture_output=True, text=True, encoding="utf-8", errors="replace")
        text = run.stdout + run.stderr
        record = {"command": command, "return_code": run.returncode}
        elf = project / build_root / "SilverStar_0_1_3.elf"
        if run.returncode == 0:
            record["elf_sha256"] = hashlib.sha256(elf.read_bytes()).hexdigest()
            nm = subprocess.run(["arm-none-eabi-nm", "-a", "-S", str(elf)], capture_output=True, text=True, check=True)
            record["history_symbols"] = [line for line in nm.stdout.splitlines() if any(
                line.endswith(" " + symbol) for symbol in ("s_replay", "s_replay_storage", "s_history", "s_body_history"))]
            (TASK / (name + ".nm.txt")).write_text(nm.stdout, encoding="utf-8")
    else:
        result = runner.Run(model, project, getattr(BuildAction, action), line_callback=lambda line: None)
        record = dataclasses.asdict(result)
        text = record.pop("output")
    record.update(owner="/root horizon development", elapsed_seconds=time.monotonic() - started,
                  finished_utc=datetime.now(timezone.utc).isoformat(), cwd=str(project))
    (TASK / (name + ".log")).write_text(text, encoding="utf-8")
    with (TASK / (name + ".json")).open("x", encoding="utf-8") as output:
        json.dump(record, output, indent=2)
    print(name, "EXIT", record["return_code"], "seconds", record["elapsed_seconds"], flush=True)
    failed = failed or record["return_code"] != 0
raise SystemExit(1 if failed else 0)
