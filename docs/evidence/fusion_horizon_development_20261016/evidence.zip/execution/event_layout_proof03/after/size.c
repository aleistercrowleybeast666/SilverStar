#include "navigation_kf_horizon.h"
char NavigationKfHorizonEvent_Size[sizeof(NavigationKfHorizonEvent)];
char NavigationKfHorizon_Size[sizeof(NavigationKfHorizon)];
