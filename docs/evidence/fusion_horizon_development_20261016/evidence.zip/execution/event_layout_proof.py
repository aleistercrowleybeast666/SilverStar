"""Actual ARM private-struct size before/after natural field ordering."""
from hashlib import sha256
import json
from pathlib import Path
import re
import shutil
import subprocess

TASK = Path(__file__).resolve().parent
ROOT = TASK.parents[1]
owner = ROOT/'apps/SCG/plugins/builtin/silverstar_algorithm_estimator_kf6/payload/Algorithm/Estimator/KF6'
before = TASK/'kf6_2_native02/Algorithm/Estimator/KF6/Inc/navigation_kf_horizon.h'
after = owner/'Inc/navigation_kf_horizon.h'
output = TASK/'event_layout_proof03'
output.mkdir(exist_ok=False)
compiler = shutil.which('arm-none-eabi-gcc')
nm = shutil.which('arm-none-eabi-nm')
assert compiler and nm
record = {'owner': '/root memory defect fix', 'scope': 'actual ARM object sizeof; not firmware link or stack proof',
    'compiler': subprocess.check_output([compiler, '--version'], text=True), 'cases': {}}
native = json.loads((TASK/'native_configuration_backend_pytest01/kf_backend_horizon-O20/compile.json').read_text(encoding='utf8'))
includes = [arg for arg in native['command'] if arg.startswith('-I')]
for name, header in (('before', before), ('after', after)):
    directory = output/name
    directory.mkdir()
    (directory/header.name).write_bytes(header.read_bytes())
    source = directory/'size.c'
    source.write_text('#include "navigation_kf_horizon.h"\n'
        'char NavigationKfHorizonEvent_Size[sizeof(NavigationKfHorizonEvent)];\n'
        'char NavigationKfHorizon_Size[sizeof(NavigationKfHorizon)];\n', encoding='utf8')
    target = directory/'size.o'
    command = [compiler, '-std=c11', '-mcpu=cortex-m4', '-mthumb', '-Wall', '-Wextra', '-Werror',
        '-I'+str(directory), *includes,
        '-c', str(source), '-o', str(target)]
    run = subprocess.run(command, capture_output=True, text=True)
    (directory/'compile.json').write_text(json.dumps(dict(command=command,
        exit_code=run.returncode, stdout=run.stdout, stderr=run.stderr), indent=2), encoding='utf8')
    assert run.returncode == 0, run.stdout + run.stderr
    symbols = subprocess.check_output([nm, '-S', '--size-sort', str(target)], text=True)
    values = {symbol: int(size, 16) for size, symbol in re.findall(
        r'^[0-9a-fA-F]+ ([0-9a-fA-F]+) \w (NavigationKfHorizon(?:Event)?_Size)$', symbols, re.M)}
    record['cases'][name] = {'command': command, 'exit_code': run.returncode,
        'stdout': run.stdout, 'stderr': run.stderr, 'symbols': symbols, 'sizes': values,
        'header_sha256': sha256(header.read_bytes()).hexdigest(),
        'object_sha256': sha256(target.read_bytes()).hexdigest()}
assert record['cases']['before']['sizes']['NavigationKfHorizonEvent_Size'] == 152
assert record['cases']['after']['sizes']['NavigationKfHorizonEvent_Size'] == 144
assert record['cases']['before']['sizes']['NavigationKfHorizon_Size'] - record['cases']['after']['sizes']['NavigationKfHorizon_Size'] == 512
with (output/'receipt.json').open('x', encoding='utf8') as stream:
    json.dump(record, stream, indent=2)
print('ARM private event 152 -> 144 bytes; fixed64-event context saves512 bytes')
