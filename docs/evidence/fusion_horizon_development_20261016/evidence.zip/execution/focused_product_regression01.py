"""Only the changed product admission/execution scope; not a full-suite rerun."""
import json
import os
from pathlib import Path
import subprocess
import sys

TASK = Path(__file__).resolve().parent
ROOT = TASK.parents[1]
label = sys.argv[1] if len(sys.argv) == 2 else 'focused_product_regression01'
assert label.replace('_', '').isalnum()
baseline = json.loads((TASK/'flp_regression08.json').read_text(encoding='utf8'))
environment = {**os.environ, **baseline['environment'],
    'SILVERSTAR_HORIZON_TRACE_ROOT': str(TASK/'prepared_wire_backend_pytest04'),
    'SILVERSTAR_HORIZON_RECORDED_TRACE_ROOT': str(TASK/'recorded_inputs_backend_pytest02'),
    'SILVERSTAR_HORIZON_KF_STAGE_PROJECT': str(TASK/'kf6_0_stage04'),
    'SILVERSTAR_HORIZON_STAGE_PROJECT': str(TASK/'eskf15_0_stage04')}
tests = ['test_fusion_timing_contract', 'test_fusion_timing_records_v2', 'test_fusion_horizon_identity',
    'test_fusion_horizon_records', 'test_packaged_fusion_contracts', 'test_fusion_timing_ui',
    'test_horizon_execution', 'test_horizon_result', 'test_horizon_recorded_bodies']
command = [sys.executable, '-X', 'utf8', '-m', 'pytest', '-q', '-p', 'no:cacheprovider',
    '--import-mode=importlib', *['apps/FLP/tests/'+test+'.py' for test in tests],
    '--basetemp', str(TASK/(label + '_pytest'))]
raise SystemExit(subprocess.call([sys.executable, '-X', 'utf8', str(TASK/'run.py'),
    label, *command], cwd=ROOT, env=environment))
