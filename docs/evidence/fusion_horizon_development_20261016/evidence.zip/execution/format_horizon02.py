"""Readable product helpers with retained before bytes and AST proof."""
import ast
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
TASK = Path(__file__).resolve().parent
paths = [
 'apps/FLP/src/silverstar_flp/plugins/algorithms/horizon_bodies.py',
 'apps/FLP/src/silverstar_flp/plugins/algorithms/horizon_execution.py',
 'apps/FLP/src/silverstar_flp/plugins/algorithms/horizon_result.py',
 'apps/FLP/src/silverstar_flp/plugins/algorithms/horizon_inputs.py',
 'apps/FLP/src/silverstar_flp/plugins/algorithms/horizon_timeline.py',
 'apps/FLP/src/silverstar_flp/decoder_profiles/contract_data.py',
 'apps/FLP/src/silverstar_flp/decoder_profiles/fusion_timing.py',
 'apps/FLP/src/silverstar_flp/decoder_profiles/fusion_timing_records.py',
 'apps/FLP/tests/test_horizon_native_log_open.py',
]
before = {name: (ROOT/name).read_bytes() for name in paths}
with zipfile.ZipFile(TASK/'horizon_format_before02.zip', 'x', zipfile.ZIP_DEFLATED) as archive:
    for name, data in before.items(): archive.writestr(name, data)
for action in (['check', '--select', 'I', '--fix'], ['format']):
    subprocess.run([sys.executable, '-m', 'ruff', *action, *paths], cwd=ROOT, check=True)

class WithoutImports(ast.NodeTransformer):
    def visit_Import(self, node): return None
    def visit_ImportFrom(self, node): return None

def identity(data):
    tree = ast.parse(data.decode('utf8'))
    imports = [(type(node).__name__, getattr(node, 'module', '') or '', getattr(node, 'level', 0),
        alias.name, alias.asname or '') for node in ast.walk(tree)
        if isinstance(node, (ast.Import, ast.ImportFrom)) for alias in node.names]
    return sorted(imports), ast.dump(WithoutImports().visit(tree), include_attributes=False)

receipt = {'owner': '/root source readability', 'files': {}}
for name, data in before.items():
    after = (ROOT/name).read_bytes()
    assert identity(data) == identity(after), name
    receipt['files'][name] = {'before': sha256(data).hexdigest(), 'after': sha256(after).hexdigest(),
        'same_import_bindings_and_nonimport_AST': True}
with (TASK/'horizon_format_verify02.json').open('x', encoding='utf8') as stream:
    json.dump(receipt, stream, indent=2)
subprocess.run([sys.executable, '-m', 'ruff', 'check', *paths], cwd=ROOT, check=True)
