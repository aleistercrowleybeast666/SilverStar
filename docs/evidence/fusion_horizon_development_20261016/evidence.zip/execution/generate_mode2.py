"""Fresh normal mode2 projects using the reference UART board's declared variant.

JY901S exposes no pressure provider. Never invent I2C or synchronized-ready nets
on the fixed reference board to force a different sensor configuration through.
"""
from dataclasses import replace
import hashlib
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[2]
task = Path(__file__).resolve().parent
sys.path.insert(0, str(root/'apps/SCG/src'))
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.project.configuration import ProjectConfiguration_Reconcile
from silverstar_fccg.project.model import DeviceInstance
from silverstar_fccg.project.rate_plan import InertialRatePlan_Resolve

kind, label = sys.argv[1:]
assert kind in ('kf6', 'eskf15') and label.replace('_', '').isalnum()
destination = task/f'{kind}_2_{label}'
assert not destination.exists()
source = root/'.work/dev013_nis01'/('generated_kf602' if kind == 'kf6' else 'generated_eskf1503')
service = FccgService(root/'apps/SCG')
model = service.Project_Open(source/'SilverStar.ssproject')
model.identity = replace(model.identity, name=f'Horizon013_{kind}_{label}')
model.device_instances[0] = DeviceInstance('imu0', 'silverstar.device.imu.jy901b', 'uart', 'jy901s')
model.component_provenance = {}
model = ProjectConfiguration_Reconcile(model, service.catalog).model
model.algorithm_parameters[f'silverstar.algorithm.estimator.{kind}']['fusion_timing_mode'] = 2
assert model.algorithm_parameters[f'silverstar.algorithm.estimator.{kind}']['fusion_horizon_ms'] == 300
model.logging_streams = [replace(row, enabled=True, decimation=1) if
    any(name in row.record for name in ('FUSION_HORIZON', 'ESKF15', 'ESTIMATOR', 'INERTIAL_INCREMENT', 'INITIAL_STATE', 'SYSTEM_CONFIG'))
    else row for row in model.logging_streams]
rate = InertialRatePlan_Resolve(model, service.catalog)
assert rate.raw_imu_odr_hz == 200 and rate.effective_propagation_rate_hz == 100
assert not rate.issues, rate.issues
(task/(destination.name+'_configuration_before_generation.json')).write_text(
    json.dumps({'owner': '/root normal generated mode2 software validation',
                'configuration': model.Dictionary_Get()}, indent=2), encoding='utf-8')
service.Project_Save(model, destination, confirm_dangerous=True)
receipt = {'owner': '/root normal generated mode2 software validation',
    'hardware_qualification': 'NOT PROVEN; CPU fixtures only', 'source': str(source),
    'configuration': model.Dictionary_Get(), 'files': {p.relative_to(destination).as_posix():
        hashlib.sha256(p.read_bytes()).hexdigest() for p in destination.rglob('*') if p.is_file()}}
(task/(destination.name+'_generation.json')).write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print('GENERATED', destination, 'files', len(receipt['files']), flush=True)
