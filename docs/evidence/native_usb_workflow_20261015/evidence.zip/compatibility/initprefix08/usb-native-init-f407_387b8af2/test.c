
#include <assert.h>
#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "usb_cdc_transport.h"
#define USBD_OK 0U
#define USBD_FAIL 2U
#define USBD_STATE_DEFAULT 1U
#define HAL_OK 0U
#define DEVICE_FS 0U
#define PCD_SPEED_FULL 1U
#define PCD_PHY_EMBEDDED 0U
#define DISABLE 0U
#define PCD_SNG_BUF 0U
#define USE_HAL_PCD_REGISTER_CALLBACKS 0U
#define USB_OTG_FS_TOTAL_FIFO_SIZE 1280U
typedef uint8_t USBD_StatusTypeDef;
typedef struct { void *pData;uint8_t id,dev_state; } USBD_HandleTypeDef;
typedef struct { uint32_t GRXFSIZ,DIEPTXF0_HNPTXFSIZ,DIEPTXF[4]; } Regs;
typedef struct { uint32_t dev_endpoints,speed,dma_enable,phy_itface,Sof_enable,low_power_enable,
 lpm_enable,vbus_sensing_enable,use_dedicated_ep1,battery_charging_enable; } PcdInit;
typedef struct { uint16_t pmaadress;uint8_t doublebuffer; } Ep;
typedef struct { void *pData;Regs *Instance;PcdInit Init;Ep IN_ep[16],OUT_ep[16]; } PCD_HandleTypeDef;
static USBD_HandleTypeDef hUsbDeviceFS;
static PCD_HandleTypeDef hpcd_USB_OTG_FS;
static Regs regs;
#define USB (&regs)
#define USB_OTG_FS (&regs)
static unsigned calls,fail_call,fail_init,fail_deinit,bad_readback,link_down;
void UsbCdc_LinkDown(void) { link_down++; }
void Error_Handler(void) { assert(0 && "unexpected terminal initialization path"); }
uint8_t HAL_PCD_Init(PCD_HandleTypeDef *p) { assert(p==&hpcd_USB_OTG_FS);return (uint8_t)fail_init; }
uint8_t HAL_PCD_DeInit(PCD_HandleTypeDef *p) { assert(p==&hpcd_USB_OTG_FS);return (uint8_t)fail_deinit; }

uint8_t HAL_PCDEx_SetRxFiFo(PCD_HandleTypeDef *p,uint16_t size)
{ assert(p==&hpcd_USB_OTG_FS);calls++;if(calls==fail_call) { return 1U; }regs.GRXFSIZ=size;return 0U; }
uint8_t HAL_PCDEx_SetTxFiFo(PCD_HandleTypeDef *p,uint8_t n,uint16_t size)
{ assert(p==&hpcd_USB_OTG_FS && n<=2U);calls++;if(calls==fail_call) { return 1U; }
  uint32_t offset=regs.GRXFSIZ;
  if(n==0U) { regs.DIEPTXF0_HNPTXFSIZ=((uint32_t)size<<16)|offset; }
  else { offset+=regs.DIEPTXF0_HNPTXFSIZ>>16;if(n==2U) { offset+=regs.DIEPTXF[0]>>16; }
    regs.DIEPTXF[n-1U]=((uint32_t)size<<16)|offset;if(bad_readback) { regs.DIEPTXF[n-1U]=0U; } }
  return 0U; }

USBD_StatusTypeDef USBD_LL_Init(USBD_HandleTypeDef *pdev)
{
  /* Init USB Ip. */
  if (pdev->id == DEVICE_FS) {
  /* Link the driver to the stack. */
  hpcd_USB_OTG_FS.pData = pdev;
  pdev->pData = &hpcd_USB_OTG_FS;

  hpcd_USB_OTG_FS.Instance = USB_OTG_FS;
  hpcd_USB_OTG_FS.Init.dev_endpoints = 4;
  hpcd_USB_OTG_FS.Init.speed = PCD_SPEED_FULL;
  hpcd_USB_OTG_FS.Init.dma_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.phy_itface = PCD_PHY_EMBEDDED;
  hpcd_USB_OTG_FS.Init.Sof_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.low_power_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.lpm_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.vbus_sensing_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.use_dedicated_ep1 = DISABLE;
  if (HAL_PCD_Init(&hpcd_USB_OTG_FS) != HAL_OK)
  {
    Error_Handler( );
  }

#if (USE_HAL_PCD_REGISTER_CALLBACKS == 1U)
  /* Register USB PCD CallBacks */
  HAL_PCD_RegisterCallback(&hpcd_USB_OTG_FS, HAL_PCD_SOF_CB_ID, PCD_SOFCallback);
  HAL_PCD_RegisterCallback(&hpcd_USB_OTG_FS, HAL_PCD_SETUPSTAGE_CB_ID, PCD_SetupStageCallback);
  HAL_PCD_RegisterCallback(&hpcd_USB_OTG_FS, HAL_PCD_RESET_CB_ID, PCD_ResetCallback);
  HAL_PCD_RegisterCallback(&hpcd_USB_OTG_FS, HAL_PCD_SUSPEND_CB_ID, PCD_SuspendCallback);
  HAL_PCD_RegisterCallback(&hpcd_USB_OTG_FS, HAL_PCD_RESUME_CB_ID, PCD_ResumeCallback);
  HAL_PCD_RegisterCallback(&hpcd_USB_OTG_FS, HAL_PCD_CONNECT_CB_ID, PCD_ConnectCallback);
  HAL_PCD_RegisterCallback(&hpcd_USB_OTG_FS, HAL_PCD_DISCONNECT_CB_ID, PCD_DisconnectCallback);

  HAL_PCD_RegisterDataOutStageCallback(&hpcd_USB_OTG_FS, PCD_DataOutStageCallback);
  HAL_PCD_RegisterDataInStageCallback(&hpcd_USB_OTG_FS, PCD_DataInStageCallback);
  HAL_PCD_RegisterIsoOutIncpltCallback(&hpcd_USB_OTG_FS, PCD_ISOOUTIncompleteCallback);
  HAL_PCD_RegisterIsoInIncpltCallback(&hpcd_USB_OTG_FS, PCD_ISOINIncompleteCallback);
#endif /* USE_HAL_PCD_REGISTER_CALLBACKS */
  HAL_PCDEx_SetRxFiFo(&hpcd_USB_OTG_FS, 0x80);
  HAL_PCDEx_SetTxFiFo(&hpcd_USB_OTG_FS, 0, 0x40);
  HAL_PCDEx_SetTxFiFo(&hpcd_USB_OTG_FS, 1, 0x80);
  }
  return USBD_OK;
}
int main(int argc,char **argv)
{
 assert(argc==2);
 if(strcmp(argv[1],"pcd-failure")==0) { fail_init=1U; }
 if(strcmp(argv[1],"readback")==0) { bad_readback=1U; }
 if(strncmp(argv[1],"call-",5)==0) { fail_call=(unsigned)strtoul(argv[1]+5,NULL,10); }
 if(strcmp(argv[1],"cleanup-failure")==0) { fail_call=1U;fail_deinit=1U; }
 uint8_t result=USBD_LL_Init(&hUsbDeviceFS);
 if(fail_init||fail_call||bad_readback) { assert(result!=USBD_OK && link_down>0U); }
 else { assert(result==USBD_OK);assert(calls==4U && regs.GRXFSIZ==128U && regs.DIEPTXF[0]==((64U<<16)|192U) && regs.DIEPTXF[1]==((16U<<16)|256U)); }
 return 0;
}
