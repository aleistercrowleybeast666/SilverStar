#define USBD_malloc USBD_static_malloc
