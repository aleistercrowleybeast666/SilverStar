# Call after defining the native target; CubeMX owns all native sources.
# Select exactly one assertion owner; never link duplicate implementations.
function(UsbCdc_Attach target assertion_owner)
  if(NOT TARGET ${target})
    message(FATAL_ERROR "UsbCdc_Attach needs an existing native target")
  endif()
  if("${assertion_owner}" STREQUAL "BUNDLED")
    target_sources(${target} PRIVATE
      "${CMAKE_CURRENT_FUNCTION_LIST_DIR}/Common/Src/silverstar_assert.c")
  elseif(NOT "${assertion_owner}" STREQUAL "EXISTING")
    message(FATAL_ERROR "Choose BUNDLED or EXISTING assertion ownership")
  endif()
  target_sources(${target} PRIVATE
    "${CMAKE_CURRENT_FUNCTION_LIST_DIR}/Src/usb_cdc_transport.c"
    "${CMAKE_CURRENT_FUNCTION_LIST_DIR}/Src/usb_cdc_port.c")
  target_include_directories(${target} PRIVATE
    "${CMAKE_CURRENT_FUNCTION_LIST_DIR}/Inc"
    "${CMAKE_CURRENT_FUNCTION_LIST_DIR}/Common/Inc")
endfunction()
