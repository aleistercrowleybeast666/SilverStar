
#include <assert.h>
#include <string.h>
#include <setjmp.h>
#include "Src/usb_cdc_transport.c"
static uint32_t mask;
static uint32_t arms;
static uint32_t submits;
static uint8_t *owned;
static UsbCdcResult state = USB_CDC_OK;
static UsbCdcResult submit = USB_CDC_OK;
static UsbCdcResult rearm = USB_CDC_OK;
static jmp_buf trap;
uint32_t UsbCdcPort_Lock(void) { uint32_t prior = mask; mask = 1U; return prior; }
void UsbCdcPort_Unlock(uint32_t token) { mask = token; }
UsbCdcResult UsbCdcPort_TxState(void) { return state; }
UsbCdcResult UsbCdcPort_Submit(uint8_t *data, uint16_t length)
{ assert(mask == 1U); assert(length > 0U); owned = data; submits++; return submit; }
UsbCdcResult UsbCdcPort_Rearm(void) { assert(mask == 1U); arms++; return rearm; }
void SilverStarAssert_Check(uint8_t ok, SilverStarAssertModuleId module,
    const char *file, uint32_t line, SilverStarAssertReasonId reason)
{ (void)module; (void)file; (void)line; (void)reason; if (!ok) { longjmp(trap, 1); } }
int main(void)
{
    uint8_t data[USB_CDC_RX_CAPACITY];
    uint8_t out[USB_CDC_RX_CAPACITY];
    uint32_t session;
    uint16_t length;
    uint32_t old;
    uint32_t index;
    memset(data, 0x39, sizeof(data));
    assert(UsbCdc_Write(data, 1U, 1U) == USB_CDC_OFFLINE);
    assert(UsbCdc_Configure() == USB_CDC_OK);
    assert(UsbCdc_Configure() == USB_CDC_BUSY);
    assert(UsbCdc_Quiesced() == USB_CDC_BUSY);
    assert(UsbCdc_Service() == USB_CDC_OK && arms == 0U);
    old = UsbCdc_SessionGet();
    for (index = 0U; index < 8U; index++)
    {
        assert(UsbCdc_Receive(data, 64U) == USB_CDC_OK);
        assert(UsbCdc_Service() == USB_CDC_OK);
    }
    assert(arms == 7U);
    assert(UsbCdc_Receive(data, 1U) == USB_CDC_BUSY);
    assert(UsbCdc_Read(out, 63U, &length, &session) == USB_CDC_OK && length == 63U);
    assert(UsbCdc_Service() == USB_CDC_OK && arms == 7U);
    assert(UsbCdc_Read(out, 1U, &length, &session) == USB_CDC_OK && length == 1U);
    assert(UsbCdc_Service() == USB_CDC_OK && arms == 8U);
    assert(UsbCdc_Receive(data, 64U) == USB_CDC_OK);
    assert(UsbCdc_Read(out, sizeof(out), &length, &session) == USB_CDC_OK);
    assert(length == sizeof(out) && session == old && memcmp(out, data, sizeof(out)) == 0);
    assert(UsbCdc_Write(data, 64U, session) == USB_CDC_OK);
    state = USB_CDC_BUSY;
    assert(UsbCdc_Service() == USB_CDC_BUSY && submits == 0U);
    state = USB_CDC_OK;
    assert(UsbCdc_Service() == USB_CDC_OK && submits == 1U);
    data[0] = 0x72;
    assert(owned[0] == 0x39);
    state = USB_CDC_BUSY; /* Data IN and the trailing ZLP still own the buffer. */
    assert(UsbCdc_Service() == USB_CDC_BUSY);
    assert(UsbCdc_Write(data, 1U, session) == USB_CDC_BUSY);
    UsbCdc_LinkDown();
    assert(UsbCdc_Configure() == USB_CDC_BUSY && owned[0] == 0x39);
    assert(UsbCdc_Write(data, 1U, old) == USB_CDC_OFFLINE);
    assert(UsbCdc_Quiesced() == USB_CDC_OK);
    assert(UsbCdc_Configure() == USB_CDC_OK);
    assert(UsbCdc_Write(data, 1U, old) == USB_CDC_OFFLINE);
    assert(UsbCdc_Read(out, sizeof(out), &length, &session) == USB_CDC_OK && length == 0U);
    assert(UsbCdc_Write(data, 1U, session) == USB_CDC_OK);
    state = USB_CDC_OK;
    submit = USB_CDC_FAULT;
    assert(UsbCdc_Service() == USB_CDC_FAULT);
    assert(UsbCdc_Configure() == USB_CDC_BUSY && owned[0] == 0x72);
    assert(UsbCdc_Quiesced() == USB_CDC_OK);
    assert(UsbCdc_Configure() == USB_CDC_OK);
    assert(UsbCdc_Receive(data, 64U) == USB_CDC_OK);
    rearm = USB_CDC_FAULT;
    assert(UsbCdc_Service() == USB_CDC_FAULT);
    assert(UsbCdc_Read(out, sizeof(out), &length, &session) == USB_CDC_OFFLINE && length == 0U);
    assert(UsbCdc_Receive(NULL, 1U) == USB_CDC_INVALID);
    assert(UsbCdc_Write(data, USB_CDC_TX_CAPACITY + 1U, session) == USB_CDC_INVALID);
    s_session = UINT32_MAX;
    UsbCdc_LinkDown();
    assert(UsbCdc_Quiesced() == USB_CDC_OK);
    assert(UsbCdc_Configure() == USB_CDC_FAULT);
    /* Test-only terminal trap interception; no target recovery mechanism. */
    if (setjmp(trap) == 0)
    {
        s_count = USB_CDC_RX_CAPACITY + 1U;
        (void)UsbCdc_Service();
        assert(0);
    }
    return 0;
}
