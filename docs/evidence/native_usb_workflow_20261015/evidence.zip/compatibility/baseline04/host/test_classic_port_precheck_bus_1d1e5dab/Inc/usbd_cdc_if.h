uint8_t CDC_Transmit_FS(uint8_t *, uint16_t);
uint8_t USBD_CDC_ReceivePacket(USBD_HandleTypeDef *);
