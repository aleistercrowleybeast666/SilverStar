#include <stdint.h>
#define USBD_STATE_CONFIGURED 3U
#define USBD_OK 0U
#define USBD_BUSY 1U
#define CDC_DATA_FS_MAX_PACKET_SIZE 64U
typedef struct { uint32_t TxState; } USBD_CDC_HandleTypeDef;
typedef struct { uint8_t dev_state; uint8_t classId; void *pClassData; void *pClassDataCmsit[1]; } USBD_HandleTypeDef;
