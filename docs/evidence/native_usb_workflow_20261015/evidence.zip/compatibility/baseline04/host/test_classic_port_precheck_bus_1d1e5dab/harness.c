
#include <assert.h>
#include "Src/usb_cdc_port.c"
USBD_HandleTypeDef hUsbDeviceFS;
static unsigned calls;
static uint8_t result;
uint8_t CDC_Transmit_FS(uint8_t *data, uint16_t length)
{ (void)data; (void)length; calls++; return result; }
uint8_t USBD_CDC_ReceivePacket(USBD_HandleTypeDef *device)
{ (void)device; calls++; return result; }
int main(void)
{
    USBD_CDC_HandleTypeDef cdc = {1U};
    uint8_t byte = 1U;
    hUsbDeviceFS.dev_state = USBD_STATE_CONFIGURED;
    hUsbDeviceFS.pClassData = &cdc;
    hUsbDeviceFS.pClassDataCmsit[0] = &cdc;
    assert(UsbCdcPort_Submit(&byte, 1U) == USB_CDC_BUSY && calls == 0U);
    cdc.TxState = 0U;
    result = USBD_BUSY;
    assert(UsbCdcPort_Submit(&byte, 1U) == USB_CDC_FAULT && calls == 1U);
    assert(UsbCdcPort_Rearm() == USB_CDC_FAULT && calls == 2U);
    result = USBD_OK;
    assert(UsbCdcPort_Submit(&byte, 1U) == USB_CDC_OK);
    assert(UsbCdcPort_Rearm() == USB_CDC_OK);
    hUsbDeviceFS.dev_state = 0U;
    assert(UsbCdcPort_Submit(&byte, 1U) == USB_CDC_OFFLINE);
    return 0;
}
