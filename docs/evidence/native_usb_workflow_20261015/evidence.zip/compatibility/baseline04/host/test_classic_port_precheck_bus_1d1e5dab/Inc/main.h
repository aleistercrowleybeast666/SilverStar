#include <stdint.h>
static uint32_t __get_PRIMASK(void) { return 0U; }
static void __disable_irq(void) {}
static void __set_PRIMASK(uint32_t value) { (void)value; }
static void __DMB(void) {}
