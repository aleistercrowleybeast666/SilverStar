void SystemClock_Config(void) {} void IRQ(void) { HAL_PCD_IRQHandler(); } int main(void) { MX_USB_DEVICE_Init(); }
/* changed input */
