#include <assert.h>
#include "usb_cdc_transport.h"
#include "usb_device.h"
static USBD_CDC_HandleTypeDef cdc;
USBD_HandleTypeDef hUsbDeviceFS;
uint8_t CDC_Transmit_FS(uint8_t *data, uint16_t length)
{ assert(data != 0 && length == 1U); return USBD_OK; }
uint8_t USBD_CDC_ReceivePacket(USBD_HandleTypeDef *device)
{ assert(device == &hUsbDeviceFS); return USBD_OK; }
int main(void)
{
    uint8_t byte = 7U;
    hUsbDeviceFS.dev_state = USBD_STATE_CONFIGURED;
    hUsbDeviceFS.pClassData = &cdc;
    assert(UsbCdc_Configure() == USB_CDC_OK);
    assert(UsbCdc_Write(&byte, 1U, UsbCdc_SessionGet()) == USB_CDC_OK);
    assert(UsbCdc_Service() == USB_CDC_OK);
    assert(UsbCdc_Service() == USB_CDC_OK);
    assert(UsbCdc_Write(&byte, 1U, UsbCdc_SessionGet()) == USB_CDC_OK);
    UsbCdc_LinkDown();
    assert(UsbCdc_Quiesced() == USB_CDC_OK);
    return 0;
}
