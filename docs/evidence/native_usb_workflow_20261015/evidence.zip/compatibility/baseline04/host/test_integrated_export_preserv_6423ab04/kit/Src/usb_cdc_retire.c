#include "usb_cdc_retire.h"
#include "usb_cdc_port.h"
#include "usb_device.h"
#include "main.h"
#include <stddef.h>
extern PCD_HandleTypeDef hpcd_USB_OTG_FS;
extern USBD_HandleTypeDef hUsbDeviceFS;

UsbCdcResult UsbCdcRetire_Endpoint(USBD_HandleTypeDef *device, uint8_t address)
{
    PCD_EPTypeDef *ep;
    uint32_t token;
    uint8_t number = address & 0x7FU;
    if ((device != &hUsbDeviceFS) || (device->pData != &hpcd_USB_OTG_FS) ||
        ((address != 0x81U) && (address != 0x01U) && (address != 0x82U)))
    { return USB_CDC_INVALID; }
    token = UsbCdcPort_Lock();
    ep = ((address & 0x80U) != 0U) ? &hpcd_USB_OTG_FS.IN_ep[number] : &hpcd_USB_OTG_FS.OUT_ep[number];
    if ((HAL_PCD_EP_Abort(&hpcd_USB_OTG_FS, address) != HAL_OK) ||
        (HAL_PCD_EP_Close(&hpcd_USB_OTG_FS, address) != HAL_OK))
    { UsbCdcPort_Unlock(token); return USB_CDC_FAULT; }
    uintptr_t USBx_BASE = (uintptr_t)hpcd_USB_OTG_FS.Instance;
    if ((address & 0x80U) != 0U)
    {
        if (USB_FlushTxFifo(hpcd_USB_OTG_FS.Instance, number) != HAL_OK)
        { UsbCdcPort_Unlock(token); return USB_CDC_FAULT; }
        USBx_INEP(number)->DIEPINT = 0xFFFFFFFFU;
    }
    else { USBx_OUTEP(number)->DOEPINT = 0xFFFFFFFFU; }
    /* No DMA in these exact profiles. Disabled endpoints cannot consume more
     * CPU source bytes; clear pending completion and stale software pointers. */
    ep->xfer_buff = NULL;
    ep->xfer_len = 0U;
    ep->xfer_count = 0U;
    UsbCdcPort_Unlock(token);
    return USB_CDC_OK;
}
