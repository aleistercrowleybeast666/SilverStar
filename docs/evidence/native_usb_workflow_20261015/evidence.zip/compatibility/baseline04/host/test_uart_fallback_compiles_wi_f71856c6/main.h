#ifndef __MAIN_H
#define __MAIN_H
#include <stdint.h>
typedef struct { unsigned value; } UART_HandleTypeDef;
typedef enum { HAL_OK, HAL_BUSY, HAL_ERROR } HAL_StatusTypeDef;
HAL_StatusTypeDef HAL_UART_Receive(UART_HandleTypeDef *, uint8_t *, uint16_t, uint32_t);
HAL_StatusTypeDef HAL_UART_Transmit(UART_HandleTypeDef *, uint8_t *, uint16_t, uint32_t);
#endif
