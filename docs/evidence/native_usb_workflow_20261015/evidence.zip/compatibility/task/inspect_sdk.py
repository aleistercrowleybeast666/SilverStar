import hashlib,json,sys
from pathlib import Path
repo=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(repo/'apps/SCG/src'))
from silverstar_fccg.generator.native_hal import NativeC_FunctionSpanGet
base=Path('C:/Users/chdxm/Documents/Codex/2026-10-08/task/usb-validation')
records={}
for part in ('f103','f407'):
    root=base/('cube-'+part+'-usb')
    names={
      'stm32f1xx_hal_pcd.c':('HAL_PCD_EP_Abort','HAL_PCD_EP_Close','HAL_PCD_EP_Open','HAL_PCD_EP_Transmit','HAL_PCD_EP_Receive'),
      'stm32f4xx_hal_pcd.c':('HAL_PCD_EP_Abort','HAL_PCD_EP_Close','HAL_PCD_EP_Open','HAL_PCD_EP_Transmit','HAL_PCD_EP_Receive'),
      'stm32f1xx_ll_usb.c':('USB_EPStopXfer','USB_DeactivateEndpoint','USB_ActivateEndpoint','USB_EPStartXfer'),
      'stm32f4xx_ll_usb.c':('USB_EPStopXfer','USB_DeactivateEndpoint','USB_ActivateEndpoint','USB_EPStartXfer','USB_FlushTxFifo','USB_FlushRxFifo'),
      'stm32f1xx_hal_pcd_ex.c':('HAL_PCDEx_PMAConfig',),
      'stm32f4xx_hal_pcd_ex.c':('HAL_PCDEx_SetRxFiFo','HAL_PCDEx_SetTxFiFo'),
      'usbd_conf.c':('USBD_LL_Init','USBD_LL_Reset','HAL_PCD_ResetCallback','HAL_PCD_DataOutStageCallback','HAL_PCD_SuspendCallback'),
    }
    for path in root.rglob('*.c'):
        if path.name not in names:continue
        source=path.read_text(encoding='utf-8-sig')
        for name in names[path.name]:
            try:a,_o,b=NativeC_FunctionSpanGet(source,name)
            except ValueError:continue
            records[part+'/'+name]={'path':str(path.resolve()),'line':source[:a].count('\n')+1,
                'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'function':source[a:b]}
(Path(__file__).resolve().parent/'sdk-source-facts.json').write_text(json.dumps(records,indent=2),encoding='utf8')
for name in sys.argv[1:]:
    for key,value in records.items():
        if key.endswith('/'+name):print(key,value['path'],value['line'],value['function'],sep='\n')
