"""Record reviewed SDK/callback components without pinning unrelated user files."""
import hashlib,json,sys
from pathlib import Path
repo=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(repo/'apps/SCG/src'))
from silverstar_fccg.app.usb_transport import _Project_Read,UsbTransport_Plan
from silverstar_fccg.generator.native_hal import NativeC_FunctionSpanGet
from silverstar_fccg.hardware.usb_transport_profiles import PROFILES
base=Path('C:/Users/chdxm/Documents/Codex/2026-10-08/task/usb-validation')
components=[]
for part,family,pcd in [('f103','f1','hpcd_USB_FS'),('f407','f4','hpcd_USB_OTG_FS')]:
    root=base/('cube-'+part+'-usb');files=_Project_Read(root);plan=UsbTransport_Plan(root)
    names=['usbd_core.c','usbd_core.h','usbd_cdc.c','usbd_cdc.h','usbd_def.h','stm32'+family+'xx_hal_pcd.c',
           'stm32'+family+'xx_hal_pcd_ex.c','stm32'+family+'xx_ll_usb.c','stm32'+family+'xx_ll_usb.h']
    hashes={name:hashlib.sha256(next(b for p,b in files.items() if Path(p).name==name)).hexdigest() for name in names}
    regions={}
    for owner,functions in [('usbd_cdc_if.c',['CDC_Init_FS','CDC_DeInit_FS','CDC_Receive_FS','CDC_Transmit_FS']),
        ('usbd_conf.c',['USBD_LL_CloseEP','HAL_PCD_DataInStageCallback','HAL_PCD_DataOutStageCallback'])]:
        source=files[plan.owners[owner]].decode('utf-8-sig').replace('\r\n','\n').replace('#endif /* USE_HAL_PCD_REGISTER_CALLBACKS */','')
        for name in functions:
            a,_o,b=NativeC_FunctionSpanGet(source,name)
            regions[owner+':'+name]=hashlib.sha256(source[a:b].encode()).hexdigest()
    components.append({'name':'classic-indexed-otg-fs' if part=='f407' else 'classic-legacy-f1-pma',
        'indexed':part=='f407','pcd':pcd,'instance':'USB_OTG_FS' if part=='f407' else 'USB',
        'files':hashes,'regions':regions})
dest=repo/'apps/SCG/src/silverstar_fccg/hardware/usb_transport_profiles.py'
dest.write_text('''"""Reviewed source components for opt-in lifecycle derivation.

Full-input fingerprints retain historical evidence identity. Component contracts
allow unrelated user clock/pin/project changes, but never unknown edited hooks.
They grant patch-shape compatibility only, not firmware/hardware acceptance.
See apps/SCG/docs/USB_CDC_COMPATIBILITY_20261015.md.
"""
'''+'PROFILES = '+repr(PROFILES)+'\n\nCOMPONENT_PROFILES = '+repr(components)+'\n',encoding='utf8')
(Path(__file__).parent/'component-signatures.json').write_text(json.dumps(components,indent=2),encoding='utf8')
print('Recorded',len(components),'component profiles in',dest)
