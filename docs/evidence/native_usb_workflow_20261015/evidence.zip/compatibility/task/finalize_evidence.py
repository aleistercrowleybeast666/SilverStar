"""Inventory this USB task only; no deletion or source modification."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

repo = Path(__file__).resolve().parents[2]
task = Path(__file__).resolve().parent
assert task == repo / '.work/usb013-compat-20261015'
files = [
    'apps/SCG/src/silverstar_fccg/app/usb_transport.py',
    'apps/SCG/src/silverstar_fccg/generator/usb_cdc_integration.py',
    'apps/SCG/src/silverstar_fccg/hardware/usb_transport_capabilities.py',
    'apps/SCG/src/silverstar_fccg/hardware/usb_transport_profiles.py',
    'apps/SCG/tests/test_usb_transport.py',
    'apps/SCG/tests/test_usb_transport_capabilities.py',
    'apps/SCG/tests/test_usb_transport_integration.py',
    'apps/SCG/tools/validation/usb_transport_validate.py',
    'apps/SCG/docs/USB_CDC_COMPATIBILITY_20261015.md',
]
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
snapshot = json.loads((task / 'validate03/source-snapshot.json').read_text())
mismatches = [path for path, record in snapshot['source_files'].items()
              if digest(repo / path) != record['sha256']]
assert not mismatches, mismatches
historical = json.loads((repo / 'apps/SCG/docs/evidence/usb_transport_20261013/SHA256SUMS.json').read_text())
immutable_history = {path: digest(repo / path) == expected for path, expected in historical.items()
                     if path.startswith('apps/SCG/docs/') or path.endswith('usb_transport_baseline.py') or
                     path.endswith('generator/usb_cdc_transport.py')}
assert all(immutable_history.values()), immutable_history
history_manifest = repo / 'apps/SCG/docs/evidence/usb_transport_20261013/SHA256SUMS.json'
summary = json.loads((task / 'validate03/summary.json').read_text())
commands = json.loads((task / 'validate03/commands.json').read_text())
failed_commands = [{'label': row['label'], 'exit': row['exit']} for row in commands if row['exit'] != 0]
handoff = {
    'version': '0.1.3', 'owner': 'USB compatibility delegation from 01a11c26-bf4e-740a-9b0e-bbbfea726019',
    'created_utc': datetime.now(timezone.utc).isoformat(),
    'build_source_commit': snapshot['source_commit'],
    'current_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
    'current_sources_match_executed_dirty_snapshot': True,
    'owned_file_snapshots': {path: {'sha256': digest(repo / path), 'source': (repo / path).read_text(encoding='utf8')} for path in files},
    'immutable_historical_artifacts_match': immutable_history,
    'historical_manifest_sha256': digest(history_manifest),
    'final_validation': 'validate03', 'acceptance': 'FAIL / critical contracts and hardware NOT PROVEN',
    'host': {'passed': 54, 'skipped': 1, 'warnings': 1,
        'skip': 'F103 PMA has no FIFO flush; abort/close faults exercised separately'},
    'nonzero_recorded_commands': failed_commands,
    'summary': summary,
    'earlier_attempts': {
        'precheck.log': '9 capability tests failed before detection fix',
        'cap01.log': 'intermediate negative-only pass; not final positive coverage',
        'cap02.log': '29 capability/export checks passed',
        'integration01.log': '24 passed; F103 FIFO case was then a duplicate close test',
        'validate01': 'stopped at first retained F103 UART analyzer warning',
        'validate02': 'full builds; checker absolute-linker projection flaw, superseded by complete validate03 run',
    },
    'no_actions': ['no hardware operations', 'no staging or commits', 'no branch switch', 'no push', 'no cleanup'],
    'next_scope': 'Resolve exact native init/FIFO/retirement and diagnostic blockers before widening compiled fixture coverage; preserve production gates.',
}
(task / 'handoff.json').write_text(json.dumps(handoff, indent=2), encoding='utf8')
inventory = {
    'version': '0.1.3', 'owner': handoff['owner'],
    'purpose': 'Generated capability/Host/ARM/analyzer/gate attempts and retained audit evidence',
    'root': str(task), 'source_commit': snapshot['source_commit'],
    'retained_evidence': ['precheck.log', 'validate03/commands.json', 'validate03/source-snapshot.json',
                          'validate03/summary.json', 'validate03/inventory.json', 'handoff.json'],
    'cleanup': 'No cleanup authorized or performed. This manifest is an inventory, not deletion authorization.',
    'files': {p.relative_to(task).as_posix(): {'sha256': digest(p), 'bytes': p.stat().st_size}
              for p in sorted(task.rglob('*')) if p.is_file() and p != task / 'inventory.json'},
}
(task / 'inventory.json').write_text(json.dumps(inventory, indent=2), encoding='utf8')
print(json.dumps({'owned_files': len(files), 'snapshot_source_match': True,
    'commands_recorded': len(commands), 'nonzero_commands': failed_commands,
    'inventoried_files': len(inventory['files']), 'bytes': sum(r['bytes'] for r in inventory['files'].values())}, indent=2))
