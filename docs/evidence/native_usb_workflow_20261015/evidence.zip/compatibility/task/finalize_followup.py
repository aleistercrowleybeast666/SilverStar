"""Freeze the authorized USB follow-up evidence; never delete or alter inputs."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

repo = Path(__file__).resolve().parents[2]
task = Path(__file__).resolve().parent
assert task == repo / '.work/usb013-compat-20261015'
files = [
    'apps/SCG/src/silverstar_fccg/app/usb_transport.py',
    'apps/SCG/src/silverstar_fccg/generator/usb_cdc_integration.py',
    'apps/SCG/src/silverstar_fccg/hardware/usb_transport_capabilities.py',
    'apps/SCG/src/silverstar_fccg/hardware/usb_transport_profiles.py',
    'apps/SCG/tests/test_usb_transport.py',
    'apps/SCG/tests/test_usb_transport_capabilities.py',
    'apps/SCG/tests/test_usb_transport_integration.py',
    'apps/SCG/tools/validation/usb_transport_validate.py',
    'apps/SCG/docs/USB_CDC_COMPATIBILITY_20261015.md',
]
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
snapshot = json.loads((task / 'validate12/source-snapshot.json').read_text())
mismatches = [path for path, row in snapshot['source_files'].items()
              if digest(repo / path) != row['sha256']]
assert not mismatches, mismatches
historical = json.loads((repo / 'apps/SCG/docs/evidence/usb_transport_20261013/SHA256SUMS.json').read_text())
history = {path: digest(repo / path) == expected for path, expected in historical.items()
           if path.startswith('apps/SCG/docs/') or path.endswith('usb_transport_baseline.py') or
           path.endswith('generator/usb_cdc_transport.py')}
assert all(history.values()), history
checked_artifacts = {}
for name in ('baseline04', 'validate12'):
    root = task / name
    inventory = json.loads((root / 'inventory.json').read_text())
    bad = [path for path, expected in inventory.items() if digest(root / path) != expected]
    assert not bad, (name, bad)
    checked_artifacts[name] = len(inventory)
summary = json.loads((task / 'validate12/summary.json').read_text())
commands = json.loads((task / 'validate12/commands.json').read_text())
attribution = json.loads((task / 'validate12/baseline-attribution.json').read_text())
assert (task / 'validate12-exit.txt').read_text().strip() == '1'
failed = [{'label': row['label'], 'exit': row['exit']} for row in commands if row['exit'] != 0]
handoff = {
    'version': '0.1.3',
    'owner': 'USB compatibility delegation from 01a11c26-bf4e-740a-9b0e-bbbfea726019',
    'created_utc': datetime.now(timezone.utc).isoformat(),
    'build_source_commit': snapshot['source_commit'],
    'current_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
    'current_sources_match_executed_dirty_snapshot': True,
    'snapshot_sources_checked': len(snapshot['source_files']),
    'owned_file_snapshots': {path: {'sha256': digest(repo / path),
        'source': (repo / path).read_text(encoding='utf8')} for path in files},
    'immutable_historical_artifacts_match': history,
    'verified_artifact_inventories': checked_artifacts,
    'final_validation': 'validate12', 'unchanged_native_baseline': 'baseline04',
    'aggregate_exit': 1, 'acceptance': 'FAIL / CRITICAL_CONTRACTS_AND_HARDWARE_NOT_PROVEN',
    'host': {'passed': 98, 'skipped': 5, 'warnings': 1,
        'skip_details': {'f103_no_fifo_flush': 1, 'f103_no_global_rx_fifo': 2,
                        'f407_native_configuration_has_no_calls_4_or_5': 2},
        'warning': 'Existing pytest cache_dir configuration with cache plugin disabled'},
    'nonzero_recorded_commands': failed, 'commands_recorded': len(commands),
    'summary': summary, 'baseline_attribution': attribution,
    'architecture': 'Native capability audit -> structured adaptation description -> transport/lifecycle adapter -> compiled and board evidence',
    'native_ownership': 'CubeMX clocks, pins, PCD and USB initialization, PMA/FIFO, IRQ wiring, startup and linker remain native-owned',
    'completed_followup': [
        'Reviewed component and callback-region signatures permit unrelated native project variation',
        'Explicit declarative inventory supports complete non-Make projects without executing their scripts',
        'Structured local adaptation description separates missing capabilities, hooks, build and evidence',
        'Runtime memory geometry rejects invalid configuration before class initialization/RX arm',
        'Retirement checks disabled endpoint postconditions and retains OUT ownership while RX FIFO is pending',
        'Native data callback bounds/ownership/results and missing class DeInit are checked',
        'Real effective PCD/PCDEx/USB LL preprocessing records selected SDK function bodies',
        'Unmodified native baseline attributes identical UART diagnostics and existing gate items without waivers',
    ],
    'remaining_actions': [
        'Native F407 owner must allocate CDC notification TX2 within actual FIFO budget in the CubeMX project, then reimport/revalidate',
        'Parent must separately authorize/co-ordinate service/project/source-graph/GUI integration and production admission',
        'Resolve existing vendor diagnostics and failed gate categories without widening exceptions or suppressing failures',
        'Complete critical-contract, dependency/call-graph, full-stack and timing review',
        'Run documented board matrix only after explicit hardware authorization',
        'Add complete representative DRD/PMA/OTG fixtures and separate USBX/RTOS/HS/DMA/cache adapters before claiming those capabilities',
    ],
    'historical_evidence': {
        'handoff.json': 'Preserved initial validate03 handoff; not current',
        'inventory.json': 'Preserved initial task inventory; not current',
        'precheck.log': 'Nine pre-fix capability false positives',
        'prefix05.log': 'Host-model unused-variable error retained',
        'prefix06.log': 'Five pre-fix endpoint-active/pending-RX failures',
        'initprefix08.log': 'Broader native-init rewrite probe failed; proposal not adopted after CubeMX ownership clarification; native error propagation not claimed fixed',
        'validate03': 'Historical 54 passed/1 skipped; four ARM links; failed gates retained',
    },
    'no_actions': ['no hardware operations', 'no staging or commits', 'no branch switch', 'no push', 'no cleanup'],
}
with (task / 'handoff-final.json').open('x', encoding='utf8') as stream:
    json.dump(handoff, stream, indent=2)
inventory = {
    'version': '0.1.3', 'owner': handoff['owner'], 'created_utc': handoff['created_utc'],
    'purpose': 'USB capability/Host/ARM/analyzer/gate baseline and follow-up; retained audit evidence',
    'root': str(task), 'build_source_commit': snapshot['source_commit'],
    'retained_evidence': ['precheck.log', 'prefix06.log', 'initprefix08.log', 'baseline04', 'validate12',
                          'validate12-exit.txt', 'handoff-final.json', 'handoff.json', 'inventory.json'],
    'cleanup': 'No cleanup authorized or performed. Evidence and immutable history must be retained. This inventory is not deletion authorization.',
    'files': {p.relative_to(task).as_posix(): {'sha256': digest(p), 'bytes': p.stat().st_size}
              for p in sorted(task.rglob('*')) if p.is_file() and p != task / 'inventory-final.json'},
}
with (task / 'inventory-final.json').open('x', encoding='utf8') as stream:
    json.dump(inventory, stream, indent=2)
print(json.dumps({'owned_files': len(files), 'snapshot_source_match': True,
    'verified_artifact_inventories': checked_artifacts, 'commands_recorded': len(commands),
    'nonzero_commands': failed, 'inventoried_files': len(inventory['files']),
    'bytes': sum(row['bytes'] for row in inventory['files'].values())}, indent=2))
