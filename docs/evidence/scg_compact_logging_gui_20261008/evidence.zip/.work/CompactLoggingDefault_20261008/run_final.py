from pathlib import Path
import os,sys,subprocess,json,hashlib,datetime,time
repo=Path.cwd();out=Path(__file__).resolve().parent
paths=['apps/SCG/src/silverstar_fccg/ui/main_window.py','apps/SCG/src/silverstar_fccg/ui/pages/components.py',
       'apps/SCG/tests/test_storage_maintenance_acceptance.py','apps/SCG/tests/test_compact_logging_user_acceptance.py']
sha=lambda b:hashlib.sha256(b).hexdigest()
sources={p:sha((repo/p).read_bytes()) for p in paths}
snapshot=subprocess.check_output(['git','diff','--binary']);(out/'final_dirty_snapshot.patch').write_bytes(snapshot)
cmd=[str(repo/'apps/FLP/.venv/Scripts/python.exe'),'-B',str(repo/'.work/gui012_20261008/run_pytest.py'),
 'tests/test_compact_logging_user_acceptance.py','tests/test_storage_maintenance_acceptance.py',
 'tests/test_feature_tiers.py','tests/test_optional_protocols.py','-k','not protocol_combos_and_logging_disabled_state_are_stable',
 '-q','--basetemp=.work/cl_final','--tb=short']
row={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_sha256':sources,
 'dirty_snapshot_sha256':sha(snapshot),'command':cmd,'cwd':str(repo/'apps/SCG'),
 'env':{'QT_QPA_PLATFORM':'offscreen','PYTHONDONTWRITEBYTECODE':'1'},
 'utc_start':datetime.datetime.now(datetime.timezone.utc).isoformat()}
start=time.monotonic()
with (out/'final.log').open('wb') as log:
    result=subprocess.run(cmd,cwd=repo/'apps/SCG',env=dict(os.environ,QT_QPA_PLATFORM='offscreen',PYTHONDONTWRITEBYTECODE='1'),stdout=log,stderr=subprocess.STDOUT,timeout=240)
row.update(exit_code=result.returncode,elapsed_s=time.monotonic()-start,utc_end=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 log_sha256=sha((out/'final.log').read_bytes()),sources_unchanged={p:sha((repo/p).read_bytes())==d for p,d in sources.items()})
(out/'final_result.json').write_text(json.dumps(row,indent=2),encoding='utf8')
print((out/'final.log').read_text(encoding='utf8',errors='replace')[-7500:])
assert all(row['sources_unchanged'].values())
raise SystemExit(result.returncode)
