from pathlib import Path
import json,subprocess,hashlib,zipfile,datetime
repo=Path.cwd();out=Path(__file__).resolve().parent
delivery=repo/'docs/evidence/scg_compact_logging_gui_20261008';delivery.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
result=json.loads((out/'final_result.json').read_text())
assert result['exit_code']==0 and all(result['sources_unchanged'].values())
assert '50 passed, 1 deselected' in (out/'final.log').read_text(encoding='utf8')
for path,digest in result['source_sha256'].items():assert sha((repo/path).read_bytes())==digest,path
render=json.loads((out/'render_comparison.json').read_text());assert render['all_generated_bytes_equal_prior_verified_sample']
assert int((out/'visual_qa.exit.txt').read_text().strip())==0
visual=json.loads((out/'visual/result.json').read_text(encoding='utf8'))
assert all(not row['storage_remove_buttons'] for row in visual)
assert all(any(e['selected'] and e['enabled'] and '0.0' in e['text'] for e in row['logging_entries']) for row in visual)
frozen=['apps/SCG/src/silverstar_fccg/generator/render.py','apps/SCG/src/silverstar_fccg/project/feature_tiers.py',
 'apps/SCG/src/silverstar_fccg/project/protocols.py','apps/SCG/src/silverstar_fccg/project/configuration.py',
 'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tools/check_task_stacks.py',
 'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tools/check_power_of_ten.ps1']
for path in frozen:
    baseline=subprocess.check_output(['git','show','HEAD:'+path]).decode('utf8').replace('\r\n','\n')
    assert (repo/path).read_text(encoding='utf8')==baseline,path
paths=list(result['source_sha256'])+['docs/SCG_COMPACT_LOGGING_GUI_20261008.md']
snapshot=subprocess.check_output(['git','diff','--binary']);(out/'delivery_dirty_snapshot.patch').write_bytes(snapshot)
files=[p for p in out.rglob('*') if p.is_file()]+[repo/p for p in paths]+[
 repo/'.work/gui012_20261008/run_pytest.py',
 repo/'docs/evidence/nightly_software_20261008/normal_test_paths.py',
 repo/'docs/evidence/nightly_software_20261008/closeout_test_paths.py',
 repo/'docs/evidence/logger_health_retest_20261008/generated_config.ssproject',
 repo/'docs/evidence/scg_decoder_binding_20261008/manifest.json']
versions={}
for name,cmd in {'python':['apps/FLP/.venv/Scripts/python.exe','--version'],
 'qt':['apps/FLP/.venv/Scripts/python.exe','-c','import PySide6; print(PySide6.__version__)'],
 'pytest':['apps/FLP/.venv/Scripts/python.exe','-c','import pytest; print(pytest.__version__)']}.items():
    versions[name]=subprocess.check_output(cmd,text=True).strip()
members={}
with zipfile.ZipFile(delivery/'evidence.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for path in files:
        name=path.relative_to(repo).as_posix();data=path.read_bytes();assert name not in members
        z.writestr(name,data);members[name]=sha(data)
    for path in result['source_sha256']:
        if path.endswith('test_compact_logging_user_acceptance.py'):continue
        name='baseline_999b541/'+path;data=subprocess.check_output(['git','show','HEAD:'+path])
        z.writestr(name,data);members[name]=sha(data)
record={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_head':result['head'],
 'source_sha256':{p:sha((repo/p).read_bytes()) for p in paths},'dirty_snapshot_sha256':sha(snapshot),
 'final_test':result,'pre_test':{'command':['../../apps/FLP/.venv/Scripts/python.exe','-B','../../.work/gui012_20261008/run_pytest.py',
 'tests/test_compact_logging_user_acceptance.py','-q','--basetemp=.work/cl_pre','--tb=short'],
 'cwd':str(repo/'apps/SCG'),'exit_code':1,'result':'4 failed / 2 passed; delete-button expectation in 3 source paths and auto-disabled logging restoration failed.',
 'scope':'Original 6 new cases before additional SF6-stream assertion and reopen isolation test. Production source exactly base HEAD; baseline Git blobs archived.'},
 'intermediate_test':{'result':'49 passed / 1 deselected / exit0','credit_for_final':False,
 'note':'Product source was further refined during this preliminary run. Final unchanged-source run separately executed and recorded.'},
 'first_probe_error':'Wrong diagnostic import CompactLogStreams_Get in first attempt; log retained; not a product failure.',
 'render_comparison':render,'visual_qa':visual,'tools':versions,
 'frozen_owner_files_unchanged':{p:sha((repo/p).read_bytes()) for p in frozen},
 'behavior':'Remove new TF/SD per-instance delete buttons. Only explicit Compact switch can restore same-session transport-cleared logging choice/streams after availability becomes valid. Explicit None and imported/off settings preserved; new/open clears session cache.',
 'uncertainty':'User current unsaved project was not inspected. Reproduced one storage-toggle path; no universal Compact logging-off default found. Saved None has no trustworthy automatic/manual provenance and is preserved.',
 'expected_configuration_effect':'Restoring an auto-cleared logging choice enables its firmware logging contract for that edited model; cannot claim its new bytes equal a logging-disabled model.',
 'firmware_checks':'No new ARM/Host/analyzer/stack run; no firmware payload/generator/checker modification. Prior 999b541 gate evidence retains its exact scope.',
 'critical_contract_review':'NOT_PROVEN, unchanged','hardware':'NOT RUN','user_project':'Not touched','push':'Not performed',
 'archive_sha256':sha((delivery/'evidence.zip').read_bytes()),'members':members}
(delivery/'manifest.json').write_text(json.dumps(record,indent=2),encoding='utf8')
with zipfile.ZipFile(delivery/'evidence.zip') as z:
    assert z.testzip() is None;assert set(z.namelist())==set(members)
    for name,digest in members.items():assert sha(z.read(name))==digest
print(json.dumps({'archive_sha256':record['archive_sha256'],'members':len(members),'final_exit':result['exit_code'],
 'generated_equal':render['all_generated_bytes_equal_prior_verified_sample'],'source_sha256':record['source_sha256']},indent=2))
