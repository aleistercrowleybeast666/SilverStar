from pathlib import Path
import sys,json,hashlib
repo=Path.cwd();out=Path(__file__).resolve().parent
sys.path.insert(0,str(repo/'apps/SCG/src'))
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.project.model import ProjectModel_Load
from silverstar_fccg.generator.render import GeneratedFiles_Render
from silverstar_fccg.generator.source_graph import SourceGraph_Resolve
source=repo/'docs/evidence/logger_health_retest_20261008/generated_config.ssproject'
before=source.read_bytes();model=ProjectModel_Load(source);catalog=FccgService(repo/'apps/SCG').catalog
files=GeneratedFiles_Render(model,catalog,SourceGraph_Resolve(model,catalog))
sha=lambda b:hashlib.sha256(b).hexdigest()
old=json.loads((repo/'.work/StorageMaintenanceAcceptance_20261008/after_final.json').read_text())
hashes={p:sha(data) for p,data in files.items()}
row={'input_sha256':sha(before),'input_unchanged':source.read_bytes()==before,'generated_count':len(files),
 'all_generated_bytes_equal_prior_verified_sample':hashes==old['generated'],'generated':hashes,
 'scope':'Normal unchanged saved sample. New GUI restoration can enable logging for a previously auto-disabled edited configuration; that intentional configuration change is not claimed byte-identical.',
 'prior_verified_bin_sha256':'eac468a93aff1a7602e92f5088a2cab597b3275ccda8b45e2c0dc14ba4c3ccc7'}
(out/'render_comparison.json').write_text(json.dumps(row,indent=2),encoding='utf8')
print(json.dumps(row,indent=2));assert row['input_unchanged'] and row['all_generated_bytes_equal_prior_verified_sample']
