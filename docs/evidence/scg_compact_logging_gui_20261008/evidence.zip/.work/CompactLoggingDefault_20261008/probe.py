from pathlib import Path
import sys,json
repo=Path.cwd();out=Path(__file__).resolve().parent
sys.path.insert(0,str(repo/'apps/SCG/src'))
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.project.feature_tiers import FeatureTier_Apply
from silverstar_fccg.project.logging import ProtocolLogDefinitions_Get,LogAvailability_Get
from silverstar_fccg.project.compact_logging import CompactLogStreams_Get
from silverstar_fccg.project.reference import ReferenceProject_Create
service=FccgService(repo/'apps/SCG');catalog=service.catalog
rows=[]
for origin in ['draft','reference','old-import']:
    if origin=='draft':model=service.ProjectDraft_Create('LogProbe')
    elif origin=='reference':model=ReferenceProject_Create('LogProbe',catalog=catalog)
    else:model=service.Project_Open(repo/'docs/evidence/logger_health_retest_20261008/generated_config.ssproject')
    for tier in ['full','standard','compact','minimal','compact']:
        notes=FeatureTier_Apply(model,tier,catalog)
        result=service.ProjectConfiguration_Reconcile(model);model=result.model
        defs=ProtocolLogDefinitions_Get(model,catalog)
        defaults={d.record:d.default_stream.enabled for d in defs}
        effective=CompactLogStreams_Get(model)
        rows.append({'origin':origin,'tier':tier,'logging_protocol':str(model.protocols['logging']),
          'storage':[(i.instance_id,i.plugin) for i in model.device_instances if 'storage' in i.plugin],
          'stored_enabled':sum(i.enabled for i in model.logging_streams),
          'effective_enabled':sum(i.enabled for i in effective),
          'sf6':[(i.record,i.enabled,defaults.get(i.record)) for i in effective if 'SF6' in i.record],
          'notes':notes,'notices':[str(n) for n in result.notices]})
print(json.dumps(rows,indent=2))
(out/'before_probe.json').write_text(json.dumps(rows,indent=2),encoding='utf8')
