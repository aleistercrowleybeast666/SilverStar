from pathlib import Path
import os,sys,json
os.environ['QT_QPA_PLATFORM']='offscreen'
os.environ['PYTHONDONTWRITEBYTECODE']='1'
repo=Path.cwd();sys.path.insert(0,str(repo/'apps/SCG/src'))
from PySide6.QtWidgets import QApplication,QMessageBox
from PySide6.QtGui import QFontDatabase,QFont
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.core.settings import SettingsStore
from silverstar_fccg.ui.main_window import MainWindow
from silverstar_fccg.project.reference import ReferenceProject_Create
app=QApplication([])
for name in ('msyh.ttc','msyhbd.ttc','segoeui.ttf'):
    path=Path('C:/Windows/Fonts')/name
    if path.exists():QFontDatabase.addApplicationFont(str(path))
app.setFont(QFont('Microsoft YaHei',10))
private=repo/'apps/SCG/.work/cl_visual';private.mkdir(exist_ok=False)
out=Path(__file__).resolve().parent/'visual';out.mkdir(exist_ok=False)
w=MainWindow(SettingsStore(private/'settings.ini'),service=FccgService(repo/'apps/SCG'))
w._MessageBox_Exec=lambda *args,**kwargs:QMessageBox.StandardButton.Discard
w._Error_Show=lambda error: (_ for _ in ()).throw(error)
w._model=ReferenceProject_Create(catalog=w._service.catalog)
w._Project_Refresh();w.resize(1200,900);w.show();app.processEvents()
rows=[]
for tier in ('compact','minimal'):
    w._FeatureTier_Change(tier);app.processEvents()
    group=w.devices_page.storage_group
    group.resize(580,group.sizeHint().height());group.grab().save(str(out/(tier+'_storage.png')))
    combo=w.flight_configuration_page.protocol_combos['logging']
    combo.resize(580,40);combo.grab().save(str(out/(tier+'_logging.png')))
    rows.append({'tier':tier,'storage_instances':[item.instance_id for item in w._model.device_instances
        if w._service.Plugin_Get(item.plugin).component_class=='storage'],
        'storage_remove_buttons':[key for key in w.devices_page.remove_buttons if key.startswith('storage')],
        'logging_entries':[{'text':combo.itemText(i),'selected':i==combo.currentIndex(),
            'enabled':combo.model().item(i).isEnabled()} for i in range(combo.count())]})
(out/'result.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False),encoding='utf8')
print(json.dumps(rows,indent=2,ensure_ascii=False))
w.close();app.processEvents()
