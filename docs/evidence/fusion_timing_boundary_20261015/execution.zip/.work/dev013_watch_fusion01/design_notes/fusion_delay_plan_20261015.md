# 融合延迟与 ESKF15 重捕获：只读实施建议

Owner: `/root/fusion_delay_design`。任务：父代理授权的只读设计；不修改产品源码、不提交、不操作硬件。2026-10-15 当前工作区存在其他代理修改，本文只陈述所读代码和建议。配套 inventory 记录本笔记及关键源文件的 SHA-256。本文不是已实现、已测试或上板验收报告。

## 已核实的实现与接口

| 组件 | 当前行为 | 关键位置 |
|---|---|---|
| KF6 | 600 ms 历史，144 IMU、48 GNSS、160 baro、8 checkpoints / stride 18；恢复完整滤波器状态后按事件顺序重放。接收侧可用性/自洽证据只推进一次。 | `navigation_kf_replay.h`；`NavigationReplay_ReceiveTrack`、`NavigationReplay_EventApply`、`NavigationReplay_InsertedApply` |
| KF6 时间 | trusted 用 MCU sample；untrusted 非零 delay 用 receive-delay；untrusted **零 delay 有 legacy 特例：用 estimator present**。仍走 replay engine。 | core `APP/Src/estimator_task.c:2139` `Estimator_MeasurementTimeResolve`；FLP `kf6/measurement_time.py:5` |
| ESKF15 | 600 ms，192 个 64-byte 原始 body pair、208 events；每次插入从 anchor 重建状态和完整 15×15 P。子区间重积分各自那半段 body 输入。 | `navigation_eskf_replay.c` `Replay_PropagatePart`、`Replay_Run`、`NavigationEskfReplay_Predict/Insert` |
| ESKF15 时间 | 直接用 `SystemTime_MeasurementTimestampResolve`，trusted sample 优先；untrusted receive-delay，零 delay 是 receive。GNSS 四组分别插入，baro 第五组。 | `navigation_eskf_backend.c` `Backend_GnssGroupApply`、`Backend_BarometerUpdate`、`Backend_EventApply` |
| ESKF15 更新 | 15维增益、Joseph、右局部姿态注入/reset Jacobian、完整 P 数值检查之后才提交。角注入 >0.35 rad、gyro bias norm >1 rad/s、accel bias norm >5 m/s² 返回 MODEL_MISMATCH。 | `navigation_eskf.c` `Eskf_CorrectionBuild`、`Eskf_JosephBuild`、`NavigationEskf_Update` |
| ESKF15 健康 | MODEL_MISMATCH 由 live supervisor 锁存；GNSS 无 preflight frame 时不接受飞行中首次 fix 建原点。 | `system_navigation_health.c`；`Backend_GnssUpdate` |
| SF6 rev2 | 当前态、到达顺序、固定增益；无 P、无历史、无 NIS。最大 source age 500 ms；严格组/source/receive/sequence 顺序。旧 rev1 replay 单独保留。 | `apps/FLP/SF6_REVISION2.md`；SF6 owning payload + FLP `current_state.py` |

KF6 的 `NavigationKf_GnssReanchorApply` 直接替换选中 p/v，并清该组与其他状态的交叉项。**不得移植到 ESKF15**。ESKF15 现无同等 reacquisition 状态机；普通 GNSS 更新本身能在某些失锁后恢复，但不是 1/5/30/120 s 全场景承诺。

FLP 对应接口：KF6 `fixed_lag.py:FixedLagReplay/Faithful_Run`；ESKF15 `replay.py:DelayedReplay` 与 `plugin.py:run`。ESKF15 Python 保存每个 body boundary 的完整 checkpoint 并从插入之前最近点重建；C 从 anchor 重建。任何恢复策略必须可随 checkpoint 重放，不能只放在不可回滚的 Python supervisor。

## 先交付参数分组，再开放有实际实现的模式

SCG `ui/pages/algorithm_parameters.py` 已有常驻 basic 和 advanced：常用集合包含测量噪声、三个 delay、soft/hard enable。FLP `ui/pages/replay.py:_CommonParameter_Is` 把 process_model 当普通参数；ESKF15 `_Parameters_Build` 却把 **全部** 35 个参数都声明成 process_model，P0/杆臂/NIS 阈值因此也常驻。应修正准确分组而不是再套一个总折叠框。

建议普通区：算法、实际支持的时间模式、测量源/组、过程噪声、测量噪声、soft/hard enable；delay 仅在对应时间模式有用时显示并说明 trusted timestamp 优先。高级区：P0、杆臂、门限概率、R scale 上限、恢复细项；是否把 NIS 概率提升到普通区是显示决定，不改原数值。

Pure INS 不出现融合/测量时序控件。SF6 rev2 只显示当前态说明和六个 gain，不接收 delay 字段，不能伪造 P/NIS。历史 SF6 rev1 的原算法/表单不改。

### 模式必须分开“source time”和“application time”

所有模式保留 sample、receive、resolved source time；新增 application/evaluation time 的明确定义。无回放不能把 source time 改成 now 来掩盖陈旧数据。source age/physical validity/重复顺序仍先校验。

1. **当前状态更新（无回放）**：每次 IMU 正常 predict；到达且合格的测量只在 present state/P 上更新，application=present；不 rewinding、不存历史事件。旧测量的时滞误差仍存在，不承诺通过 R 放大自动消除。编译时可去掉 history arrays 才可声称节省 RAM。ESKF lever-arm 的 omega 应取 application boundary 当前 body 数据，不能继续依赖已去掉的 history 查询。KF6保留 `NavigationKf_GnssEpochTrack` 的接收证据、组更新/恢复语义和原事件顺序，不能仅把内部历史容量设成 0。
2. **延迟回放**：source time 处更新完整状态/P，再重放后续所有 body inputs 与 measurement events 到 present。当前实现作为 legacy revision 保留；600 ms/capacity 之外明确 HISTORY_MISS，不降级成当前态融合。延迟窗口是 transport/measurement lag 容量，与 GNSS 失锁总时长无关；120 s 失锁后回来的是新的测量，不需要 120 s IMU history。
3. **延迟融合 + 输出预测器**：须先有完整独立实现，再出现在可选项。建议 primary filter 运行在固定融合时域 `t_f=t_now-L`，收集有界 IMU/量测队列，按测量时刻一次融合；已经落后于 committed horizon 的迟包显式拒绝。输出从 `(x_f,P_f)` 的独立副本用 `[t_f,t_now]` 原始 body 输入重新预测，绝不反馈到 primary filter。不使用缓存的最终 delta-v/姿态增量跨 bias 更新。最低风险版本把完整 P 一起预测到 now 并标明 output state/P 时间；若以后为性能省掉输出 P 传播，则必须明确 `P_time=t_f`、当前 P unavailable/approximate，不能把滞后 P 和当前 state 当同一时刻发布。KF6 原始 interval dt 的 Q 语义也不能随 horizon 切片改变。

模式3还需要启动不足 L 的 WARMUP、队列满、horizon 移动、观测晚到、IMU gap/身份切换、输出预测失败的事务行为；不是现有 replay 开关的同义词。第一可验证批次只开放1/2；模式3用独立说明文字报告尚未实现，不提供可点击空功能。

## 最小配置和版本边界

建议将时间策略作为 estimator 自有 `fusion_timing_mode` int32（0=current、1=replay；2 直到实现前禁止），默认/legacy_default=1，现有 owner reconciliation 保留旧行为。生成符号由 owning plugin 声明；不改业务返回值。不一定需要再升 SCG project format：整数参数结构已存在于格式14–18，但新参数支持仍需 parser/validation/schema identity 测试；若改为新的顶层 enum 对象，必须明确新格式版本，不能偷塞旧格式。

新策略必须加入 `metadata.navigation_semantics` 的独立 `fusion_timing` revision、模式、时间定义、能力/容量；现有 KF6 process-model revision2、quality revision3、ESKF algorithm revision1 不能被重命名来掩盖变化。重捕获也是独立策略 revision，或明确升 ESKF算法revision（实现时二选一固定下来）；最小建议用 ESKF revision2，保留 revision1 kernel/profile路径与旧结果。

旧 `.ssdecoder` 缺新字段时，仅从已知完整 component/version + 旧语义证明其 legacy replay，不把缺字段当“录制了当前默认”。未知版本继续原始解码可用/数值回放不可用。新包/旧包与日志 revision 不符拒绝。FLP Recorded Configuration 依精确 Descriptor/package，What-if 覆盖必须留 run identity、旧/新模式和实际参数；项目恢复检查 parameter schema identity，不能改存档 log/package/fixture。

SSLOG container0.0 和 package1.2可保留，但 changed record payload 必须新 `(record_type,record_version)` 或新增 record，不能挤掉现有 reserved 字段的约定或静默变更原100-byte ESKF15_MEASUREMENT。至少记录 source/receive/application/evaluation、mode/revision、recovery decision/attempt/factor/reason、一次接收证据身份。KF6 `GNSS_MEASUREMENT`、`BARO_MEASUREMENT`、`ESTIMATOR_STEP` 当前 operation sequence/replay_generation 不能在 current 模式伪造 rewind 次数。

改动挂点：SCG 两个 estimator `plugin.json`、`contracts/navigation_v1.json`/新增专用 contract、`project/algorithm_parameters.py`、生成语义/日志 owning schema；FLP `decoder_profiles/algorithm_parameters.py`、新 timing/recovery revision resolver、两算法 plugin/replay、项目保存与 audit exporter。snapshot 96-entry 静态上限仍需检查。GSHC/Android 此批仅受新增记录元数据影响，不改飞控控制/开伞流程。

## ESKF15 重捕获：全协方差、有限恢复、可复演

建议新增 ESKF 专用 recovery context/函数，不让 KF6 的清块路径参与链接。第一批不做强制重定位：

- 每个 GNSS group 跟踪最后物理可用 receive、qualified outage、返回 source/sequence、有限连续自洽 evidence；与最后 effective fusion 不同。只有 NIS 连续拒绝但没有可用性 outage，不授权恢复。无 fix、年龄超限、重复/反序、错误source/calibration/epoch不增长恢复资格。
- 分离 receive tracker（只推进一次）与 replayed recovery state。每个事件保存接收证据快照；history anchor/checkpoint 包含恢复尝试/间隔/accept streak，重放只重算状态，没有日志/健康副作用。外层只发当前 operation 的结果。这是防止四 GNSS 组各自重放时重复累计恢复、重复inflate的核心。
- qualified outage 后先普通15维更新。仅合格、连续自洽且 NIS rejected 时做有上限、有限次数的协方差恢复。可用正对角合同变换 `P_candidate = D P D^T`，对选中的 p/v 轴取 `D_i>=1`，其余为1；**每个225项都按 `D_i D_j` 处理**，与姿态/gyro bias/accel bias的交叉项保留并相应缩放。它保持精确算术SPD与相关系数，仍需binary32有限值、对称、Cholesky、diag caps检查；绝不能只乘选中对角、截掉交叉项或把上限过后的对角独立clamp。先由对角上限限制整个factor；能力不足则明确 exhausted。
- 推荐第一版“本事件拒绝但提交经过验证的膨胀，下一独立接收epoch再普通更新”，避免复用同一观测两次。恢复因子/attempt进event replay state，成功normal update后等待连续有效非零gain确认，不以 packet received 或 inflation 成功宣称恢复。
- 仍调用 `NavigationEskf_Update`，保留完整K/Joseph/reset与0.35rad、bias上限。不能通过临时关闭NIS、清P、减小R、clamp correction、重复同一measurement分块注入来强行达标。超出局部模型有效域继续 MODEL_MISMATCH/INVALID，现有锁存不因后来一帧成功而消失；没有证据不能承诺所有120s运动失锁能自动恢复。
- proposed inflation是统计建模变化，不是纯性能优化；因子、cap、资格阈值要作为版本化策略固定/声明，先用工程保守值与oracle验证，不称经过实飞调参。允许baro继续观测时只影响它该影响的状态，GNSS各组独立；不可重设preflight GNSS坐标原点。

若将来需要超过局部线性化区间的大误差恢复，须另设计经过审阅的全状态重初始化/IEKF方案与新mission epoch、观测一致性和全部15×15协方差契约。本批不能冒用 KF6 reanchor 来满足“恢复”。

## 已存在的一个时序差异，建议独立修复批次

FLP ESKF15 `plugin.py:_Measurements_Build` 的 What-if baro 分支在 `group==4` 时视 sample trusted 后仍减 configured delay（约295–302行）；C `SystemTime_MeasurementTimestampResolve` 的 trusted 分支忽略 delay。故 trusted baro + 显式非零 What-if delay会改变Python时刻但不会改变对应固件时刻。先增加独立反例与C/Python对照，再修复；不能通过新模式迁移悄悄改变全部旧录制结果。KF6 的 zero-delay present 特例则是有文档注释的既有行为，应保留，不能误判为同一bug。

## 测试接口与分批顺序

1. **UI-only**：准确basic/advanced分组；算法/mode切换、语言切换、折叠和恢复保持数值，SF6 rev2/PureINS无不适用项。保存/重开旧工程字节意义保持。适配 `test_round4_navigation_ui.py`、FLP `test_eskf15_product.py` 与现有参数UI测试。仅此批无需伪造firmware功能。
2. **timing contract + current mode**：先写能区分“measurement old but apply now”与historical-replay的加速度/恒速反例；然后分别接入 C 和 FLP。延迟回放0/非零原轨迹与现有oracle保持；源时刻/应用时刻分别可审计；编译no-replay没有history symbols才声称RAM收益。
3. **ESKF recovery**：先独立C函数+fullP oracle，再接收证据/replay事务，最后日志+FLP对照。与性能提交分开，新的recovery不得使severe-tilt/no-fix/invalidP既有拒绝测试变绿为accepted。
4. **delayed predictor**：新状态/队列/日志/FLP时间语义齐备后才开放；先fullP output propagation，后续性能减省另评审，不能混入本轮代数优化。

可复用：FLP `tests/eskf15_c_bridge.py` 的 `CCore`/`State`/`Workspace`/`Body`/`Observation`；`test_eskf15_native_parity.py` 的实际C DLL与 `_Replay_Create`、trim/capacity/mid-interval/identity测试；`test_eskf15.py` Jacobian有限差分/PSD和延迟序列；`test_eskf15_acceptance.py` severe tilt、badP、fault-atomicity、body重新积分；core Host `test_eskf_backend.c`，SCG `test_navigation_v1.py`、`test_fixed_lag_replay.py`、`test_navigation_queue_contract_host.py`；FLP `test_fixed_lag_contract.py`、`test_actual_parameters.py`、revision tests。桥接ctypes布局需随新增struct明确更新，不得只靠碰巧ABI正确。

必需故障矩阵：

- outage1/5/30/120秒 × baro有/无 × 静止/匀速/强加速度/多轴旋转；恢复源为真实合格新epoch。长场景用C host每步predict，Python/reference抽样全P；不是把600ms history扩大到120s。
- no-fix、零accuracy、NaN/Inf、孤立/持续位置跳变、速度矛盾、卫星质量差；只有NIS拒绝但从未失锁；PosEN/PosU/VelEN/VelU互不越权。
- measurement time在anchor前/等于/之后、IMU半段/边界、present/receive未来、0和550ms、trusted/untrusted、receive排队延迟、原始dt；同epoch四组乱序/重复、source切换、seq回绕、calibration/missionepoch变化。
- denseSPD初始225项均有交叉项；证明DPD变换比对、正常update全P/Jacobian、Cholesky、单位quaternion、bias/injection上限、attempt/cap耗尽，失败时nominal/P/history/sequence不部分提交。
- 历史重放n次不会让live outage/恢复计数n倍、不重复日志/健康更新；prefix剪裁后重捕获state准确；队列/容量满和失败回滚保留旧正确状态。
- 报告首次有效融合时间、连续确认时间、创新/NIS、recoveryattempt/factor、全部15状态与P误差、真实source/application/output时刻、health原因，不只看position收敛。

每个固件行为批次仍须：pre-fix反例→post正常/故障、fresh generated owning输出、原样power10-check、相关Host、真实-fanalyzer编译、ARM编译/link、sourcegraph/linkedartifact/stack报告。完整日志、toolversions、config、source snapshot与hash。NOT PROVEN项（全调用图、真实栈裕量、STM32 WCET、长失锁飞行准确性/全部硬件）保持明确，不由host通过变成PASS。
