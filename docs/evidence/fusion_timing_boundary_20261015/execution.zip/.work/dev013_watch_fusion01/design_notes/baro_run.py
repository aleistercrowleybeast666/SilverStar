"""Record this bounded FLP-only regression without modifying existing evidence."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

root = Path(__file__).resolve().parents[3]
assert (root / "apps/FLP").is_dir()
base = Path(__file__).resolve().parent / sys.argv[1]
base.mkdir(exist_ok=False)
environment = os.environ.copy()
environment.update(PYTHONIOENCODING="utf-8", PYTHONDONTWRITEBYTECODE="1",
                   QT_QPA_PLATFORM="offscreen", SILVERSTAR_FCCG_ROOT=str(root / "apps/SCG"),
                   PYTHONPATH=str(root / "apps/FLP/src"))
temporary = base / "tmp"
temporary.mkdir()
for key in ("TMP", "TEMP", "TMPDIR"):
    environment[key] = str(temporary)
source = root / "apps/FLP/src/silverstar_flp/plugins/algorithms/eskf15/plugin.py"
(base / "plugin_snapshot.py.txt").write_bytes(source.read_bytes())
command = [str(root / "apps/FLP/.venv/Scripts/python.exe"), "-m", "pytest", *sys.argv[2:],
           "--basetemp=" + str(base / "test"), "-o", "cache_dir=" + str(base / "cache")]
start = datetime.now(timezone.utc).isoformat()
with (base / "pytest.log").open("xb") as output:
    result = subprocess.run(command, cwd=root / "apps/FLP", env=environment,
                            stdout=output, stderr=subprocess.STDOUT, check=False)
document = {
    "owner": "/root/fusion_delay_design", "command": command,
    "cwd": str(root / "apps/FLP"), "started_utc": start,
    "ended_utc": datetime.now(timezone.utc).isoformat(), "exit_code": result.returncode,
    "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
    "head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip(),
    "environment": {k: environment[k] for k in ("PYTHONIOENCODING", "PYTHONDONTWRITEBYTECODE",
        "QT_QPA_PLATFORM", "SILVERSTAR_FCCG_ROOT", "PYTHONPATH", "TMP", "TEMP", "TMPDIR")},
    "scope": "Host tests only; no hardware/ARM execution or firmware modification",
}
(base / "result.json").write_text(json.dumps(document, indent=2) + "\n", encoding="utf-8")
print("\n".join((base / "pytest.log").read_text(encoding="utf-8", errors="replace").splitlines()[-20:]))
raise SystemExit(result.returncode)
