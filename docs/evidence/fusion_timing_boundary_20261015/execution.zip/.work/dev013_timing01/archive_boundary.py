"""Retain compact evidence, source snapshots and every failed attempt; no cleanup."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import zipfile

root=Path(__file__).resolve().parents[2]
task=root/'.work/dev013_timing01'
runs=root/'.work/dev013_watch_fusion01'
destination=root/'docs/evidence/fusion_timing_boundary_20261015'
destination.mkdir(exist_ok=False)
final=json.loads((task/'final_source_manifest02.json').read_text(encoding='utf8'))
entries={}
def add(path, name=None):
    if path.is_file():
        entries[name or path.relative_to(root).as_posix()]=path.read_bytes()
for path,expected in final['files'].items():
    body=(root/path).read_bytes()
    assert hashlib.sha256(body).hexdigest()==expected,path
    entries['source/'+path]=body
for path in task.iterdir():
    if path.is_file() and path.suffix in ('.json','.log','.py') and path.name!='build_wire_contract.py':
        add(path)
for name in ('timing_repair01','timing_repair02','timing_repair03','timing_repair04','timing_baseline01',
             'flp_full_timing01','flp_collect_timing01','flp_modal_baseline01','flp_failed_current01',
             'flp_failed_baseline01','flp_optional_baseline01'):
    for suffix in ('.log','.json'):
        add(runs/(name+suffix))
add(runs/'run.py')
notes=runs/'design_notes'
for path in notes.iterdir():
    if path.is_file(): add(path)
for label in ('bt01','bt02','bt03','bt04'):
    folder=notes/label
    for path in folder.iterdir():
        if path.is_file(): add(path)
    for path in (folder/'test').glob('baro_time_*/*'):
        if path.name in ('compile.json','unused_platform.c'): add(path)
for path in (task/'pytest06').glob('baro_time_*/*'):
    if path.name in ('compile.json','unused_platform.c'): add(path)
for path in ('apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/System/Src/system_time.c',
             'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/System/Inc/system_time.h'):
    add(root/path,'source/'+path)
baseline_revision='08e76ec5df7ba087915143fd7926b128f444ec6f'
for path in ('apps/FLP/src/silverstar_flp/decoder_profiles/package.py',
             'apps/FLP/src/silverstar_flp/plugins/algorithms/kf6/plugin.py',
             'apps/FLP/src/silverstar_flp/plugins/algorithms/eskf15/plugin.py'):
    entries['baseline/'+path]=subprocess.check_output(['git','show',baseline_revision+':'+path],cwd=root)
manifest=dict(utc=datetime.datetime.now(datetime.UTC).isoformat(),owner='root',
    purpose='FLP timing-declaration boundary and ESKF barometer timestamp correction, before actual timing-mode activation',
    source_base_commit=final['head'],baseline_modules_commit=baseline_revision,
    cleanup_authorized=False,files={name:dict(size=len(body),sha256=hashlib.sha256(body).hexdigest()) for name,body in entries.items()},
    limitations=['Full FLP run interrupted at an unmocked save modal dialog; no full-suite result',
        'Baseline 46-node attribution interrupted after 44 outcomes; last two independently reproduced',
        'Existing failures remain; no hardware/firmware acceptance claim',
        'Independent later current/kernel changes are not included in this tested source snapshot'])
(destination/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
archive=destination/'execution.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as output:
    for name,body in sorted(entries.items()): output.writestr(name,body)
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    assert len(check.namelist())==len(entries)
receipt=dict(archive='execution.zip',size=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),entries=len(entries))
(destination/'receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf8')
print(json.dumps(receipt))
