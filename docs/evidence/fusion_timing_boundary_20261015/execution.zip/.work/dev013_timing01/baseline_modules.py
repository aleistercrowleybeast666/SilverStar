"""Read exact committed FLP modules without checking out or editing user files."""
import hashlib
import importlib.abc
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

import pytest

root = Path(__file__).resolve().parents[2]
revision = '08e76ec5df7ba087915143fd7926b128f444ec6f'
paths = (
    'apps/FLP/src/silverstar_flp/decoder_profiles/package.py',
    'apps/FLP/src/silverstar_flp/plugins/algorithms/kf6/plugin.py',
    'apps/FLP/src/silverstar_flp/plugins/algorithms/eskf15/plugin.py',
)
sources = {}
hashes = {}
for path in paths:
    body = subprocess.check_output(['git', 'show', revision + ':' + path], cwd=root)
    name = path[len('apps/FLP/src/'):-3].replace('/', '.')
    sources[name] = (path, body.decode('utf-8'))
    hashes[path] = hashlib.sha256(body).hexdigest()


class BaselineLoader(importlib.abc.MetaPathFinder, importlib.abc.Loader):
    def find_spec(self, name, path=None, target=None):
        if name in sources:
            return importlib.util.spec_from_loader(name, self)

    def create_module(self, spec):
        return None

    def exec_module(self, module):
        path, source = sources[module.__name__]
        module.__file__ = str(root / path)
        exec(compile(source, module.__file__, 'exec'), module.__dict__)


sys.meta_path.insert(0, BaselineLoader())
print(json.dumps({'revision': revision, 'read_only_module_overlay': hashes}))
raise SystemExit(pytest.main(sys.argv[1:]))
