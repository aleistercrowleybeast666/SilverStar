
#include <stdlib.h>
#include "platform_time.h"
#include "platform_critical.h"
#include "silverstar_assert.h"
PlatformResult PlatformTime_Init(void) { abort(); }
uint64_t PlatformTime_Us(void) { abort(); }
PlatformCriticalState PlatformCritical_Enter(void) { abort(); }
void PlatformCritical_Exit(PlatformCriticalState state) { (void)state; abort(); }
void SilverStarAssert_Check(uint8_t condition, SilverStarAssertModuleId module,
    const char *file, uint32_t line, SilverStarAssertReasonId reason)
{ (void)condition; (void)module; (void)file; (void)line; (void)reason; abort(); }
void SilverStarAssert_ObjectCheck(const volatile void *object, uint32_t alignment,
    SilverStarAssertModuleId module, const char *file, uint32_t line)
{ (void)object; (void)alignment; (void)module; (void)file; (void)line; abort(); }
