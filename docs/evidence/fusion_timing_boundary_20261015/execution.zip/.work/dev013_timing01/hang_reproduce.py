"""Read-only baseline reproduction of the full-suite modal-window stall."""
import faulthandler
from pathlib import Path
import runpy

faulthandler.enable()
faulthandler.dump_traceback_later(15, exit=True)
runpy.run_path(str(Path(__file__).with_name('baseline_modules.py')), run_name='__main__')
