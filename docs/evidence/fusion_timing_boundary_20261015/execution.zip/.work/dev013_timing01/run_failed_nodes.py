"""Focused attribution of failures inferred from the interrupted full run."""
import faulthandler
import json
from pathlib import Path
import runpy
import sys

task = Path(__file__).resolve().parent
baseline = sys.argv[1] == 'baseline'
name = sys.argv[2]
nodes = json.loads((task/'full01_inferred_failures.json').read_text(encoding='utf8'))['inferred_failed_nodes']
sys.argv = [sys.argv[0], *nodes, '-vv', '--tb=short', '-ra', '-p', 'no:cacheprovider',
            '--basetemp='+str(task/name)]
faulthandler.enable()
faulthandler.dump_traceback_later(240, exit=True)
if baseline:
    runpy.run_path(str(task/'baseline_modules.py'), run_name='__main__')
else:
    import pytest
    raise SystemExit(pytest.main(sys.argv[1:]))
