"""Retain the original archive and emit unique verified fixture entries."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
directory = ROOT / "docs/evidence/algorithm_stack_binding_20261015"
entries = {}
duplicates = []
with zipfile.ZipFile(directory / "inputs.zip") as original:
    for entry in original.infolist():
        data = original.read(entry)
        if entry.filename in entries:
            assert entries[entry.filename] == data, "Conflicting fixture bytes"
            duplicates.append(entry.filename)
        else:
            entries[entry.filename] = data
with zipfile.ZipFile(directory / "inputs_v2.zip", "x", compression=zipfile.ZIP_DEFLATED) as archive:
    for name, data in sorted(entries.items()):
        archive.writestr(name, data)
(directory / "inputs_v2.json").write_text(json.dumps({
    "owner": "/root algorithm closeout", "purpose": "Unique source fixtures for exact reviewed compiler inputs",
    "original_retained": "inputs.zip", "identical_duplicate_entries": duplicates,
    "archive_sha256": hashlib.sha256((directory / "inputs_v2.zip").read_bytes()).hexdigest(),
    "entries": {name: hashlib.sha256(data).hexdigest() for name, data in entries.items()},
    "hardware": "NOT_TESTED", "whole_stack": "NOT_PROVEN",
}, indent=2) + "\n", encoding="utf-8")
print("unique entries", len(entries), "identical duplicate occurrences", len(duplicates))
