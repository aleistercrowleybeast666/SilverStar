"""Fresh task-owned projects; external SDKs and historical evidence stay in place."""
from pathlib import Path
from dataclasses import replace
import hashlib
import json
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
TASK = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "apps/SCG/src"))
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.project.configuration import ProjectConfiguration_Reconcile

kind, mode, label = sys.argv[1:4]
assert kind in ("kf6", "eskf15") and mode in ("0", "1", "2")
destination = TASK / f"{kind}_{mode}_{label}"
assert not destination.exists(), "Never overwrite a project or earlier evidence"
source = ROOT / ".work/dev013_nis01" / ("generated_kf602" if kind == "kf6" else "generated_eskf1503")
service = FccgService(ROOT / "apps/SCG")
model = ProjectConfiguration_Reconcile(service.Project_Open(source / "SilverStar.ssproject"), service.catalog).model
model.algorithm_parameters[f"silverstar.algorithm.estimator.{kind}"]["fusion_timing_mode"] = int(mode)
model.logging_streams = [replace(stream, enabled=True, decimation=1)
    if "ESKF15" in stream.record or stream.record == "FLIGHT_LOG_RECORD_NAV_QUALITY"
    else stream for stream in model.logging_streams]
model.component_provenance = {}
start = time.monotonic()
service.Project_Save(model, destination, confirm_dangerous=True)
record = {"owner": "/root algorithm closeout", "source_model": str(source),
    "configuration": model.Dictionary_Get(), "elapsed_seconds": time.monotonic() - start,
    "file_sha256": {p.relative_to(destination).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                    for p in destination.rglob("*") if p.is_file()}}
with (TASK / (destination.name + "_generation.json")).open("x", encoding="utf-8") as output:
    json.dump(record, output, indent=2)
print("GENERATED", destination, "files", len(record["file_sha256"]), flush=True)
