# Next implementation boundary — 2026-10-15

Owner: /root, algorithm closeout. This is a continuation checklist, not a claim
that the complete three-mode/recovery request has been delivered.

The committed/being sealed batch covers current mode and preserved replay,
storage pressure, memory/O0 and exact stack input binding. Mode 2 remains
rejected by the actual generator, firmware compile guard, wire contract and FLP
resolver; keep that rejection until its execution and evidence are complete.

## Delayed horizon and output predictor

Start from the reviewed design at
`.work/dev013_watch_fusion01/design_notes/fusion_delay_plan_20261015.md`.
Use a primary filter at now-L, bounded raw body and measurement queues, one
forward-only application per measurement, and a separate complete state/P copy
propagated to now. Never feed the predictor back. Preserve source, receive,
application, evaluation, primary and output state/P epochs. Reject a source
behind the committed horizon; do not fall back to current fusion.

Newly checked existing support: KF6 already exports
`NavigationKf_PredictInterval(context, dv, fragment_dt, original_dt)`.
Its process density is sigma^2 * original_dt; pp/pv/vv terms then use fragment
dt. Preserve original_dt for every fragment rather than calling ordinary
Predict with the fragment duration as a new stochastic interval. This removes
the need to quantize all measurements to IMU boundaries merely to preserve Q.
It is useful existing machinery, not proof of a horizon implementation.
ESKF must retain raw calibrated half-body inputs and recompute with the primary
or output copy's current residual biases; cached final delta-v is insufficient.

Before UI activation, define transactional WARMUP, queue/work limits, missing
body input, source/calibration/mission changes and output-predict failure.
Deferred measurement acceptance and its later numerical outcome need explicit
versioned records; do not silently admit mode 2 to the frozen v2 0/1 contract.
FLP needs independent forward primary/output execution and complete C backend
state/full-P/operation-time differential traces, including mid-interval cases.
Every firmware change requires new source/closure review, fresh generated gates,
real analyzer compilation and actual ARM link, with ordinary faults preserved.

## ESKF15 recovery

The additive covariance utility is commit 68a5205e; it is not called by the
active recovery policy. The policy module remains only a draft at
`.work/dev013_reacq_module01/draft`. Its isolated 250 Host checks and object
compilation do not prove backend/replay/logging integration.

Integrate receive evidence once, immutable per-event evidence, replayable
attempt/cooldown state in anchor/transactions, physical/coherent qualification,
finite attempts/caps, and independent next-epoch confirmation. Do not transplant
KF6's reanchor, reset the inflight origin, bypass NIS/model mismatch, clamp the
correction or drop the 225 covariance cross terms. Avoid growing all 208 replay
events without measuring the complete linked resource cost. Config snapshot
has a hard 96-entry bound. Version the policy, log outcomes and reproduce it in
FLP before declaring recovery enabled. Retain ordinary invalid-input paths.

Required outage matrix remains 1/5/30/120 seconds, barometer on/off, stationary,
constant velocity, acceleration and multi-axis rotation, plus no-fix, jumps,
invalid R/P, identity/time boundaries, duplicate groups, repeated replay and
fault-atomicity. Report first effective update and confirmation separately.

## SX1278 handoff received during closeout

Read `.work/0.1.3-sx1278-20261015/followup-contract-review/INTEGRATION_UPDATE.md`
and CONTRACT_REVIEW.md: one exact isolated invocation is 284 passed, no skips;
strict analyzer/ARM component links passed. Local P10 exit1 is an incomplete
fixture Makefile/build-policy interruption, with zero accumulated failures
before interruption, not a complete gate PASS.

Actual integration blocker: SystemTelemetry_Stop clears started after BUSY;
SystemTelemetry_Process's cleanup path retries Stop without servicing the sole
Process owner. SX1278 asynchronous cleanup therefore cannot finish. Service it
boundedly on that same owner before accepting completion/replacement; do not
add OFFLINE to a generic success allowlist. Test real selector plus generated
dispatcher, immediate restart and GPIO errors before full Flight/Ground gates.
No radio/shared lifecycle source was changed in this closeout batch.

The unselected radio catalog already changes generated physical IDs. Exact
current dirty-catalog bytes and header combinations are recorded in the stack
review, not treated as integration admission. A clean catalog and a catalog
after radio integration need their own exact generation/input/gate records.

## Proof limits that persist

Critical-contract manual review, complete program call graph, all checked
returns/minimum scope, MSP/ISR nesting, full dynamic/library/indirect stack
bounds, STM32 WCET and hardware/flight performance remain NOT PROVEN. One
diagnostic legacy KF6 O0 configuration overflows Flash by 1088 bytes. The
requested current-mode O0 links passed; do not relabel that legacy failure.
No hardware, push, tag, release or cleanup is authorized by this checklist.
