"""Apply the reviewed final KF6 tuple set, never learn arbitrary project inputs."""
from pathlib import Path
import importlib.util
import hashlib
import json
import pprint
import re
import zipfile

ROOT = Path(__file__).resolve().parents[2]
TASK = Path(__file__).resolve().parent
path = ROOT / 'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tools/check_task_stacks.py'
spec = importlib.util.spec_from_file_location('review', path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
record = json.loads((TASK / 'stack_additional_kf_closures01.json').read_text())
assert record['unknown_inputs'] == {'Generated/Src/project_log_decoder_profile.c':
 'b0381344dee2c994808f0b44925d1290bb839f75b163fcb2c8d0653d0202d358'}
assert len(record['records']) == 22
sources = dict(module.BINDING_SOURCE_ALGORITHM_TIMING_V18)
closures = dict(module.BINDING_COMPILED_INPUTS_ALGORITHM_TIMING_V18)
project = TASK / 'kf6_1_stack02'
for relative, digest in record['unknown_inputs'].items():
    assert module.BindingSourceHash_Get((project / relative).read_text(encoding='utf-8')) == digest
    sources[relative] = sorted(set(sources.get(relative, []) + [digest]))
for item in record['records']:
    for relative, digest in item['inputs']:
        assert module.BindingSourceHash_Get((project / relative).read_text(encoding='utf-8')) == digest
        assert digest in module.BindingSourceVersions_Get(relative) or record['unknown_inputs'].get(relative) == digest
    closures[item['source']] = sorted(set(closures.get(item['source'], []) + [item['closure_sha256']]))
text = path.read_text(encoding='utf-8')
text, count = re.subn(r'(?ms)^BINDING_SOURCE_ALGORITHM_TIMING_V18 = .*?(?=^BINDING_DEPENDENCIES_ALGORITHM_TIMING_V18 = )',
 'BINDING_SOURCE_ALGORITHM_TIMING_V18 = ' + pprint.pformat(sources, width=105, sort_dicts=True) + '\n\n', text)
assert count == 1
text, count = re.subn(r'(?ms)^BINDING_COMPILED_INPUTS_ALGORITHM_TIMING_V18 = .*?(?=^def BindingSourceVersions_Get)',
 'BINDING_COMPILED_INPUTS_ALGORITHM_TIMING_V18 = ' + pprint.pformat(closures, width=110, sort_dicts=True) + '\n\n\n', text)
assert count == 1
path.write_text(text, encoding='utf-8', newline='\n')
destination = ROOT / 'docs/evidence/algorithm_stack_binding_20261015'
entries = {}
with zipfile.ZipFile(destination / 'additional_kf_inputs.zip', 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for relative in ['Generated/Src/project_log_decoder_profile.c', 'Generated/Inc/project_device_instances.h']:
        raw = (project / relative).read_bytes()
        archive.writestr(relative, raw)
        entries[relative] = hashlib.sha256(raw).hexdigest()
    for item in record['records']:
        relative = 'build/FCCG/SilverStar_F407/Release/' + str(Path(item['source']).with_suffix('.d')).replace('\\', '/')
        raw = (project / relative).read_bytes()
        archive.writestr(relative, raw)
        entries[relative] = hashlib.sha256(raw).hexdigest()
(destination / 'additional_kf_inputs.json').write_text(json.dumps({
 'owner': '/root algorithm closeout', 'review': 'Exact final KF6 source and ordered compiler closures',
 'entries': entries, 'new_source_versions': record['unknown_inputs'], 'new_closures': record['records'],
 'checker_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
 'archive_sha256': hashlib.sha256((destination / 'additional_kf_inputs.zip').read_bytes()).hexdigest(),
 'unselected_radio': 'Catalog IDs only; no SX1278 runtime object linked or integrated',
 'critical_contracts': 'NOT_PROVEN', 'whole_stack_msp_isr': 'NOT_PROVEN'}, indent=2) + '\n', encoding='utf-8')
print('Added exact source versions 1; exact complete compiler tuples 22')
