"""Scoped emitted writer reproduction, not a substitute for the full Host gate.

Run the emitted preparation/compilation unchanged. Stop immediately after the
real writer compilation, then execute only the named pressure scenario.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import runpy
import subprocess
import sys
import time

TASK = Path(__file__).resolve().parent
project = (TASK / sys.argv[1]).resolve()
label = sys.argv[2]
assert project.parent == TASK and project.is_dir()
receipt = TASK / (label + ".json")
assert not receipt.exists()
original_run = subprocess.run
compiler_command = []


class WriterCompiled(Exception):
    pass


def Compile_Capture(command, *args, **kwargs):
    result = original_run(command, *args, **kwargs)
    if any(str(value).endswith("/test_logger_storage.c") or str(value).endswith("\\test_logger_storage.c")
           for value in command):
        compiler_command.extend(str(value) for value in command)
        raise WriterCompiled
    return result


start = time.monotonic()
script = project / "Tests/Host/storage_integrity/run_storage_integrity.py"
module = runpy.run_path(str(script), run_name="storage_writer_diagnosis")
subprocess.run = Compile_Capture
try:
    module["StorageIntegrity_Run"](project, "D:/msys64/ucrt64/bin/gcc.exe")
except WriterCompiled:
    pass
finally:
    subprocess.run = original_run
assert compiler_command, "No real writer compilation occurred"
writer = project / "build/FCCG/Host/Tests/StorageIntegrity/logger_storage.exe"
output = TASK / (label + ".sslog")
assert not output.exists()
command = [str(writer), str(output), "startup-burst-overload"]
result = subprocess.run(command, cwd=project, capture_output=True, text=True, encoding="utf-8", errors="replace")
print(result.stdout + result.stderr, flush=True)
record = {"owner": "/root algorithm closeout", "scope": "one emitted startup-burst-overload writer; NOT full Host gate",
    "compiler_command": compiler_command, "command": command, "cwd": str(project),
    "writer_sha256": hashlib.sha256(writer.read_bytes()).hexdigest(),
    "generation_receipt_sha256": hashlib.sha256((TASK / (project.name + "_generation.json")).read_bytes()).hexdigest(),
    "exit_code": result.returncode, "elapsed_seconds": time.monotonic() - start,
    "finished_utc": datetime.now(timezone.utc).isoformat(),
    "sslog_sha256": hashlib.sha256(output.read_bytes()).hexdigest() if output.exists() else None}
with receipt.open("x", encoding="utf-8") as stream:
    json.dump(record, stream, indent=2)
raise SystemExit(result.returncode)
