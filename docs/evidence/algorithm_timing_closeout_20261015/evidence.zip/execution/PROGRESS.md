# Active algorithm closeout checkpoint

2026-10-15, owner /root. **ACTIVE**, not a final handoff. Latest parent instructions:
all work uses 6.1-sol, never auto-switch Astra. Continue KF6/ESKF15 first. Third
mode delayed horizon + full-state/P output predictor and safe ESKF GNSS recovery
remain authorized goals. ESKF20/Invariant EKF planning only; no empty selectable
plugin. SX1278/Android are separate tasks; do not touch their files. SX1278 parent
handoff is `.work/0.1.3-sx1278-20261015/INTEGRATION_HANDOFF.md`, to inspect only after
navigation closes; do not interrupt active navigation for radio integration.

## Repository / authorization

Branch feature/usb-transport-0.1.3-20261013. Initial HEAD54b9267d, initial 62-file
navigation/FLP dirty freeze and 3 user CSV/TXT inputs verified unchanged. GSHC and
USB untouched. No hardware/push/tag/release/cleanup. New task outputs only here.
Read AGENTS and redirected SCG/FLP architecture; no applicable local algorithm
skill. Two standard local memory_summary.md paths did not exist.

## Completed memory batch

Local commit **89427d9a**: 6 product/test files + 3 formal evidence files.
Files: estimator_bus.c, auto_memory_layout.py, platform_memory.h, F407
platform_memory_target.h and STM32F407XX_FLASH.ld, test_auto_memory_layout.py.

- CPU-only estimator bus 2560B moves to existing target CCM BSS; no pointer
  escapes, no DMA use. No queue/budget changes. F407 KF legacy O2 main SRAM
  101260 <=102400 (previous103820), CCM61736/65536, artifact PASS.
- F407 optional KF replay gets `.ccmram_bss.kf_replay`; linker clear covers
  `.ccmram_bss.*`; O0 GC can discard it despite other live CCM objects.
- Auto-layout missing symbol accepted only with real linker map discarded-input
  block, exact group/owner/size; no fake address or placement. Existing source,
  bounds, DMA, alignment checks remain. Actual `-Wl,-Map=path,--cref` supported.
- Corrected pre-fix two ARM regressions fail; final memory_post02 **31pass**.
- KF current full O0 ELF PASS no histories; ESKF current full O0 ELF PASS no
  histories. ELFs and full nm saved in *_O0.*.
- KF legacy actual analyzer110 first-party `-fanalyzer -c`, no diagnostics,
  links. Emitted P10 for three configs PASS with critical NOT_PROVEN.
- memory_host02 correct selected cases estimator_preparation_actual and
  logger_streaming_actual plus runner's ALWAYS executed full StorageIntegrity
  PASS. It is NOT full Host.
- Newly attempted KF legacy full O0 exceeds Flash by1088B. NOT waived. Other
  failed fixture/argument/selection attempts all retained.

Formal docs/evidence/algorithm_memory_closeout_20261015/evidence.zip
6296074B SHA a4adb365548d317e55d6d013a19d7689fe9033ca21d56a55c06a40c798d30138.
Archive includes 62-file original dirty source, 6 changed files, per-project exact
generated data/tool versions, logs, three ELFs/maps/frames/dependencies.

## Logger pressure fix — UNCOMMITTED

Only additional product edit so far is owning core APP/Src/logger_task.c.
New bounded helper drains at most4 records between outer status/lifecycle work;
same queues, stream cadence, per-record append/start-barrier and error handling.
Iteration diagnostics count each real attempted drain subiteration. Record scratch
expires before finalization I/O. Mathematical estimator code unchanged.

- storage_prefault01 reproduces original startup-burst-overload: 443->444,
  last drop frame13810, normal lane IMU push. Exact original assertion fails.
- storage_post01 was an invocation race (fresh project not yet ready); no test ran.
- storage_post02 removed late drop but failed unchanged iteration_count>=drain
  contract. Corrected implementation records actual subiterations, no test edits.
- storage_post03 writer PASS all original assertions, drops443->443, no post-
  recovery drop. storage_wire_audit01 PASS with exact fresh decoder and explicit
  finite overload drops. No queue/cadence/assertions weakened.
- **eskf15_0_storage02 full emitted Host PASS**:81 executables,4414064 checks,
  zero failure,11 compile-pass,18 expected compile-fail,10 N/A. P10 PASS.
- Same project's ARM BUILD and ARTIFACT_CHECK PASS. Actual analyzer/stack action
  pipeline may still be running (session81793); stack checker remains old v17
  and is expected to reject unreviewed input hashes.
- Need finish ARM/analyzer, actual stack review and legacy validation before
  separate logging behavior commit. Do not include it in memory commit/evidence.

## Stack review — diagnosis only, checker NOT CHANGED yet

Tool owning core Tools/check_task_stacks.py, current revision
maintenance_diagnostics_20261013_v17, const around1198; source versions function
1503, dependency verifier1524, actual StackReport_Build1598, CLI--project etc1930.
It intentionally binds ALL selected compiled C sources and compiler includes.
Do not bypass verifier, add callbacks, relax margins, hide indirect calls or infer
whole MSP/ISR acceptance from a task report.

`collect_stack_review.py stack_review_candidates02` is READ ONLY, no bypass or
successful report produced. Exact 3 compiled snapshots yield27 new input paths,
6 changed dependency paths. Candidate01 missed Release/auto dir, explicitly partial.
Candidate02 includes KF legacy(memory01), KF current(memory02), ESKF current
(storage02). ESKF legacy skipped until compiled. Need collector03 after legacy
normal build, then review precise source/graphs before a versioned exact v18
identity update. Source categories: current/legacy math and timing code; v2 SSLOG
struct/codec; generated data/parameter headers; memory headers; logger helper.
Existing callback slots/immutable startup/SD tables unchanged. Unknown bytes and
dependency graph mutations must continue failing; no broad exemption.

Generated sources are stable across tool-only changes: ESKF current memory01 vs
memory02 algorithm params, metadata, mission params, decoder-profile C identical.
No hash self-reference obstacle. Device_instances header is enums/prototypes;
capability_routes.c is bounded data-only uint32 route table + checked value copy,
not a callback registry (read actual emitted source).

test_stack_budget.py currently live-source hardcoded ff... header hash likely
has two stale failures from initial timing header edits; preserve historical
proof and exact mutation rejection when updating reviewed current identity.

## Active sessions at checkpoint (poll once; may already have ended)

- 81793: eskf15_0_storage02 BUILD/ARTIFACT already0; analyzer then old STACK_REPORT.
- 89451: eskf15_1_storage02 BUILD ARTIFACT_CHECK HOST_TESTS POWER10_CHECK.
- 35297: kf6_1_memory01 old emitted STACK_REPORT expected binding failure.
- 34919: stack_prefault01 pytest test_stack_budget.py, baseline before v18 edits.

All other sessions already closed. build.py aggregates failures exit1, exact
per-action return_code JSON authoritative. run.py source hashes include tracked
SCG/FLP tests since post02; exact fresh project generation snapshots bind new
untracked target inputs as well. Host-only tests always run storage stage even
with -Only. Never claim these selected runs are a full suite.

## Remaining main scope

1. Close stack input bindings without weakening; observe actual task chains and
   address any real deficits. Whole-stack/MSP/ISR remains separate NOT_PROVEN.
2. Finish logger fix evidence and separate local commit; original 62-file timing
   implementation still uncommitted, preserve/split deliberately.
3. Third mode design already explicit in old design_notes/fusion_delay_plan:
   primary at now-L, bounded raw body/measurement queues, no rewind; reject late
   observations behind committed horizon; independently propagate full output P
   and state to now, never feed output back. Preserve KF interval Q semantics.
   WARMUP, overflow/gaps/source/calibration/output-fault transactions required.
   Do not reuse bias-dependent final delta-v across bias changes.
4. GNSS recovery draft `.work/dev013_reacq_module01/draft` only, NOT activated.
   Host250pass, real analyzer/ARM object prior proof, current base1488B. Integrate
   physical/coherent evidence, replay-transaction state and bounded resources,
   exact logging/FLP; no KF reanchor or P diagonal-only scaling.
5. SCG/FLP mode2 serializer/GUI/schema/decoder migration and C/Python differential
   validation. Current frozen wire v2 admits0/1 only; do not silently repurpose it.
6. Existing numerical performance commit5af1efa1 is already validated differential
   optimization; additional behavior changes get separate commits.

Future ESKF20/InEKF planning file already exists among62:
docs/public/SCG/FUTURE_NAVIGATION_MODELS_20261015.md. Add minimal interface plan
at a safe stage; extra5 states unresolved; Invariant != iterated; no activation.

## Later checkpoint: stack draft and logging validation

Both ESKF modes full Host81/4414064/0,11 compile-pass,18 expected-fail,10 N/A.
Current BUILD/ARTIFACT/analyzer110 real compiles all0. Legacy BUILD/ARTIFACT/P10 all0.
Logger helper remains uncommitted; initial62 source unchanged.

Owning stack checker is now UNCOMMITTED draft v18. Exact27 input paths/6 changed
dependency paths reviewed from four real compiled configurations, then a new
negative test exposed independent source/graph mixing (stack_post01 40pass1fail).
Do NOT weaken that test. Final v18 adds complete source+ordered input CONTENT
fingerprints:160 source paths,628 compiled closures. stack_post02 transiently
failed missing new constant due insertion guard; fixed without changing test.
stack_post03 **41pass**. Owner checker v18 pair-enforced stack_owner_kf02 and
stack_owner_eskf02 both0; actual task margins recorded, whole MSP/ISR NOT_PROVEN.
stack_owner_eskf_legacy02 also0. These are OWNER CHECKER direct runs on exact
fresh recorded ELFs, NOT old emitted make gates passing; original emitted v17
STACK_REPORTs remain FAIL and retained. A fresh eskf15_0_stack01 generation is
starting to prove actual emitted v18 target. CLI --project --config Release
--memory-layout auto/legacy. BuildAction has no STACK_REPORT: build.py now uses
actual make stack-report target. Driver setup failures retained.

Source review doc: docs/public/SCG/NAVIGATION_STACK_INPUT_REVIEW_20261015.md.
Inputs.zip had one duplicate identical compiler header entry (original retained);
inputs_v2.zip deduplicates after exact-byte equality and is the test fixture.
Test_stack_budget live header identity updated to exact reviewed8a853...; original
forbidden patch/runtime mutations still reject. New3 cases reject CPU placement
change, missing memory header and old dependency-list mix.

New design-only doc NAVIGATION_MODEL_INTERFACE_PLAN_20261015.md answers ESKF20/
Invariant(EKF, NOT iterated) question; no selectable stub/component/activation.

New active commands after this note: generate eskf15 0 stack01; covariance_kernel01
pytest test_eskf15_covariance_scale.py. Poll tool sessions from conversation.
