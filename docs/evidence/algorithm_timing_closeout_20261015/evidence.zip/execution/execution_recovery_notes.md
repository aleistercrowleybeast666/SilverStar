# Execution setup/recovery notes

- The first stack driver used nonexistent BuildAction.STACK_REPORT and did not
  execute a checker. The driver was corrected to invoke the actual emitted make
  stack-report target. Later v17 failures did execute the old checker.
- The first storage-post invocation raced generation and ran no writer. The
  actual second and third reproductions are separately recorded.
- eskf15_0_stack01's first BUILD/ARTIFACT receipts are failed. Output-path writes
  conflicted during overlapping/recovered execution and the build log's tail is
  not a valid reason to replace the failed return_code. serial02 receipts are
  the independent successful sequential retry. Exact C/H/ASM/linker equality
  with storage02 is recorded separately.
- A kf6_1_stack02 execution session was lost after partial object compilation;
  no complete command receipt was produced. It establishes no gate result.
  serial03 resumes the actual make recipe and has its own complete receipts.
  Its original stack target correctly rejects the unregistered final catalog
  tuple; that failed gate is retained. stack03 is the fresh project emitted
  with the final explicitly reviewed checker, rather than a patched old tool.
- timing_flp01 omitted the explicit SILVERSTAR_FCCG_ROOT prerequisite. Its
  259 passes and 12 setup errors are retained. timing_flp02 records the exact
  prerequisite and both backend trace inputs and reruns all 271 cases.

No setup failure is presented as a firmware pre-fix defect, and no successful
subset or log tail is promoted to an unexecuted complete-suite PASS.
