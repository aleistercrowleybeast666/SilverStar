"""Pair the exact reviewed source and complete compiler input closure."""
from pathlib import Path
import hashlib
import importlib.util
import json
import pprint
import re

ROOT = Path(__file__).resolve().parents[2]
TASK = Path(__file__).resolve().parent
tool = ROOT / "apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tools/check_task_stacks.py"
spec = importlib.util.spec_from_file_location("closure_review", tool)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
closures, records = {}, []
for name in ("kf6_1_memory01", "kf6_0_memory02", "eskf15_0_storage02", "eskf15_1_storage02"):
    root = TASK / name
    graph = (root / "Generated/project_sources.mk").read_text(encoding="utf-8")
    block = re.search(r"(?ms)^C_SOURCES \+= \\\n(.*?)(?:\n\n|\Z)", graph)
    sources = [line.strip().removesuffix("\\").strip() for line in block[1].splitlines()]
    for source in sources:
        reports = [root / base / Path(source).with_suffix(".d") for base in (
            "build/FCCG/SilverStar_F407/Release", "build/FCCG/SilverStar_F407/Release/auto",
            "build/FCCG/SilverStar_F407/ReleaseO0/legacy", "build/FCCG/SilverStar_F407/ReleaseO0/auto")]
        dependency = next(path for path in reports if path.is_file())
        dependencies = dependency.read_text(encoding="utf-8").split(":", 1)[1].replace("\\\n", " ").split("\n", 1)[0].split()
        source_hash = module.BindingSourceHash_Get((root / source).read_text(encoding="utf-8"))
        inputs = [[path, module.BindingSourceHash_Get((root / path).read_text(encoding="utf-8"))] for path in dependencies]
        payload = {"source": source, "source_sha256": source_hash, "inputs": inputs}
        digest = hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        closures.setdefault(source, set()).add(digest)
        records.append({"project": name, "source": source, "closure_sha256": digest, **payload})
destination = TASK / "stack_compiled_closures01.json"
record = {"owner": "/root algorithm closeout", "records": records,
          "scope": "Exact complete input tuples, not independently interchangeable source/header versions"}
if destination.exists():
    assert json.loads(destination.read_text(encoding="utf-8")) == record
else:
    with destination.open("x", encoding="utf-8") as output:
        json.dump(record, output, indent=2)
text = tool.read_text(encoding="utf-8")
marker = "def BindingSourceVersions_Get(path):"
assert "\nBINDING_COMPILED_INPUTS_ALGORITHM_TIMING_V18 = " not in text
values = {path: sorted(hashes) for path, hashes in sorted(closures.items())}
text = text.replace(marker, "# Complete source/header tuples prevent mixing independently approved versions.\n"
                    "BINDING_COMPILED_INPUTS_ALGORITHM_TIMING_V18 = " +
                    pprint.pformat(values, width=110, sort_dicts=True) + "\n\n\n" + marker)
tool.write_text(text, encoding="utf-8", newline="\n")
print("reviewed source paths", len(values), "complete compilation closures", sum(map(len, values.values())))
