"""Seal only the completed memory batch; no builds, cleanup or Git mutation."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[2]
TASK = Path(__file__).resolve().parent
DEST = ROOT / "docs/evidence/algorithm_memory_closeout_20261015"
DEST.mkdir(exist_ok=True)
assert {p.name for p in DEST.iterdir()} == {"README.md"}, "Never overwrite evidence"
sources = [
    "apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/APP/Src/estimator_bus.c",
    "apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tools/auto_memory_layout.py",
    "apps/SCG/plugins/builtin/silverstar_platform_api/payload/Platform/Inc/platform_memory.h",
    "apps/SCG/plugins/builtin/silverstar_mcu_stm32f407vet6/payload/Targets/SilverStar_F407/Inc/platform_memory_target.h",
    "apps/SCG/plugins/builtin/silverstar_mcu_stm32f407vet6/payload/STM32F407XX_FLASH.ld",
    "apps/SCG/tests/test_auto_memory_layout.py",
]
freeze = json.loads((ROOT / ".work/dev013_watch_fusion01/SOURCE_FREEZE_20261015.json").read_text(encoding="utf-8"))
for entry in freeze["files"] + freeze["preserved_user_inputs"]:
    assert hashlib.sha256((ROOT / entry["path"]).read_bytes()).hexdigest() == entry["sha256"], entry["path"]
assert json.loads((TASK / "memory_host02.json").read_text())["exit_code"] == 0
archive = DEST / "evidence.zip"
items = {}


def add(z, source, name):
    data = source.read_bytes()
    z.writestr(name, data)
    items[name] = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for name in sources:
        add(z, ROOT / name, "source/" + name)
    for entry in freeze["files"]:
        add(z, ROOT / entry["path"], "prior_dirty_source/" + entry["path"])
    add(z, ROOT / ".work/dev013_watch_fusion01/SOURCE_FREEZE_20261015.json", "prior_dirty_source_manifest.json")
    for p in sorted(TASK.iterdir()):
        if p.is_file() and (p.name.startswith("memory_") or p.name.startswith("kf6_") or p.name.startswith("eskf15_0_memory")
                            or p.name in {"run.py", "generate.py", "build.py", "seal_memory.py", "tool_versions.json", "inventory.json"}):
            add(z, p, "execution/" + p.name)
    for project, variant in [
        ("kf6_1_memory01", "Release"),
        ("kf6_0_memory02", "ReleaseO0/legacy"),
        ("eskf15_0_memory02", "ReleaseO0/auto"),
    ]:
        for p in [*(TASK / project / "Generated").rglob("*"),
                  TASK / project / "SilverStar.ssproject", TASK / project / "Tools/auto_memory_layout.py"]:
            if p.is_file():
                add(z, p, "executed_generated/" + project + "/" + p.relative_to(TASK / project).as_posix())
        directory = TASK / project / "build/FCCG/SilverStar_F407" / variant
        for p in sorted(directory.rglob("*")):
            if p.is_file() and (p.suffix in {".elf", ".map", ".su", ".d"} or p.name == "decision.json"):
                add(z, p, "artifacts/" + project + "/" + p.relative_to(directory).as_posix())
manifest = {
    "created_utc": datetime.now(timezone.utc).isoformat(), "owner": "/root algorithm closeout",
    "base_head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
    "scope": "Six-file memory batch only; later logger scheduling trial is excluded",
    "source_sha256": {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in sources},
    "archive": {"path": "evidence.zip", "bytes": archive.stat().st_size,
                "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()},
    "entries": items, "hardware": "NOT_TESTED", "stack": "NOT_PROVEN",
    "critical_contract_review": "NOT_PROVEN", "cleanup_authorized": False,
}
(DEST / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
print(json.dumps(manifest["archive"], indent=2))
