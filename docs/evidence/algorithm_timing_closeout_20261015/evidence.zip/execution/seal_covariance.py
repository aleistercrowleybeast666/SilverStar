from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[2]
TASK = Path(__file__).resolve().parent
DEST = ROOT / 'docs/evidence/eskf15_covariance_scale_20261015'
DEST.mkdir(exist_ok=False)
paths = [
 'apps/SCG/plugins/builtin/silverstar_algorithm_estimator_eskf15/payload/Algorithm/Estimator/ESKF15/Inc/navigation_eskf.h',
 'apps/SCG/plugins/builtin/silverstar_algorithm_estimator_eskf15/payload/Algorithm/Estimator/ESKF15/Src/navigation_eskf.c',
 'apps/SCG/tests/fixtures/eskf15_covariance_scale.c',
 'apps/SCG/tests/test_eskf15_covariance_scale.py',
]
old = ROOT / '.work/dev013_reacq_kernel01'
record = json.loads((old / 'arm_object01/result.json').read_text(encoding='utf-8'))
for relative, expected in record['source_sha256'].items():
    assert hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() == expected
inputs = [ROOT / p for p in paths]
for directory in ('prepare03', 'host02', 'validation01', 'arm_object01'):
    inputs.extend(p for p in (old / directory).rglob('*') if p.is_file()
                  and 'cache' not in p.parts and '__pycache__' not in p.parts)
inputs.extend([old / 'contract_review.md', old / 'tool_versions.json',
               TASK / 'covariance_kernel01.json', TASK / 'covariance_kernel01.log'])
inputs = sorted(set(inputs))
entries = {p.relative_to(ROOT).as_posix(): {'bytes': p.stat().st_size,
           'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in inputs}
archive = DEST / 'evidence.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as output:
    for p in inputs:
        output.write(p, p.relative_to(ROOT).as_posix())
manifest = {'owner': '/root algorithm closeout', 'created_utc': datetime.now(timezone.utc).isoformat(),
            'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
            'source_paths': paths, 'entries': entries,
            'archive': {'bytes': archive.stat().st_size,
                        'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()},
            'activation': 'API only; no recovery policy or call site activated',
            'scope': 'Host O0/O2 kernel, actual analyzer object and Cortex-M4F object; no hardware proof'}
(DEST / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
(DEST / 'README.md').write_text('''# ESKF15 covariance congruence API evidence — 2026-10-15

This additive API computes every entry of P' = D P D-transpose and commits only
after original/candidate symmetry, finite-value, SPD and variance-cap checks.
The nominal state, time and identities remain unchanged. Every non-APPLIED
result preserves the complete state bytes. This is a bounded utility, not an
enabled GNSS recovery policy or a pure performance optimization.

The preserved baseline shows eight repeated NIS rejections with unchanged
state/P. A missing new API was not counted as a pre-fix defect. Independent
float64 dense-matrix products, all 225 entries, correlations, cap boundaries,
aliases, NaN/Inf, asymmetric/indefinite/singular input and candidate faults are
covered at real GCC O0 and O2: 196 tests passed. The task-end rerun also passed
196 tests. Existing predict/update/replay differential traces are unchanged.
Real GCC -fanalyzer object compilation and Cortex-M4F object compilation passed;
their exact commands, versions, sources, artifacts and outputs are in the ZIP.
The source hashes were checked against both prior compilation receipts before
sealing. Current generated firmware/analyzer validation is separately retained
in algorithm_memory_closeout_20261015 and the algorithm closeout task directory.

Selective scaling preserves SPD and correlation in exact arithmetic; it does
not generally prove P'-P positive semidefinite. Only uniform scaling gives that
order guarantee. No cap clamping, diagonal-only replacement, NIS bypass, new
origin, model-mismatch recovery or firmware recovery default is introduced.

The exact source snapshot and complete retained failures/results are hashed in
manifest.json. Tool PASS is limited to the stated scope. Critical-contract
manual acceptance, whole-program call graph, MSP/ISR stack, MCU timing and
flight/hardware qualification remain NOT PROVEN. No hardware was accessed.
''', encoding='utf-8')
commit = paths + [p.relative_to(ROOT).as_posix() for p in DEST.iterdir()]
(TASK / 'covariance_commit_paths.json').write_text(json.dumps(commit, indent=2), encoding='utf-8')
print(json.dumps(manifest['archive']))
