"""Install the explicitly reviewed exact v18 inputs; no target exceptions."""
from pathlib import Path
import hashlib
import json
import pprint
import zipfile

ROOT = Path(__file__).resolve().parents[2]
TASK = Path(__file__).resolve().parent
data = json.loads((TASK / "stack_review_candidates03.json").read_text(encoding="utf-8"))
tool = ROOT / "apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tools/check_task_stacks.py"
assert hashlib.sha256(tool.read_bytes()).hexdigest() == data["tool_sha256"]
assert len(data["inputs"]) == 27 and len(data["dependency_graphs"]) == 6
assert all(scope["compiled_sources"] == 157 for scope in data["scopes"])
assert (ROOT / "docs/public/SCG/NAVIGATION_STACK_INPUT_REVIEW_20261015.md").is_file()
sources = {path: sorted(values) for path, values in sorted(data["inputs"].items())}
graphs = {path: sorted(values) for path, values in sorted(data["dependency_graphs"].items())}
text = tool.read_text(encoding="utf-8")
text = text.replace('BINDING_REVIEW_REVISION = "maintenance_diagnostics_20261013_v17"',
                    'BINDING_REVIEW_REVISION = "algorithm_timing_memory_20261015_v18"')
block = ("# Exact navigation/timing/memory review v18. No new callback or exception.\n"
         "# Review and unresolved bounds: docs/public/SCG/NAVIGATION_STACK_INPUT_REVIEW_20261015.md\n"
         "BINDING_SOURCE_ALGORITHM_TIMING_V18 = " + pprint.pformat(sources, width=105, sort_dicts=True) + "\n\n"
         "BINDING_DEPENDENCIES_ALGORITHM_TIMING_V18 = " + pprint.pformat(graphs, width=105, sort_dicts=True) + "\n\n\n")
assert "BINDING_SOURCE_ALGORITHM_TIMING_V18" not in text
text = text.replace("def BindingSourceVersions_Get(path):", block + "def BindingSourceVersions_Get(path):")
text = text.replace("BINDING_SOURCE_MAINTENANCE_DIAGNOSTICS_V17.get(path, []))",
                    "BINDING_SOURCE_MAINTENANCE_DIAGNOSTICS_V17.get(path, []) +\n"
                    "            BINDING_SOURCE_ALGORITHM_TIMING_V18.get(path, []))")
text = text.replace("BINDING_DEPENDENCIES_UART_MAINTENANCE_V16.get(path, []))",
                    "BINDING_DEPENDENCIES_UART_MAINTENANCE_V16.get(path, []) +\n"
                    "                          BINDING_DEPENDENCIES_ALGORITHM_TIMING_V18.get(path, []))")
tool.write_text(text, encoding="utf-8", newline="\n")

destination = ROOT / "docs/evidence/algorithm_stack_binding_20261015"
destination.mkdir(exist_ok=False)
entries = {}
with zipfile.ZipFile(destination / "inputs.zip", "x", compression=zipfile.ZIP_DEFLATED) as archive:
    for scope in data["scopes"]:
        project = TASK / scope["project"]
        for relative, versions in data["inputs"].items():
            path = project / relative
            if not path.is_file():
                continue
            raw = path.read_bytes()
            normalized = hashlib.sha256(path.read_text(encoding="utf-8").encode()).hexdigest()
            if normalized in versions and scope["project"] in versions[normalized]:
                name = scope["project"] + "/" + relative
                archive.writestr(name, raw)
                entries[name] = hashlib.sha256(raw).hexdigest()
    project = TASK / "kf6_1_memory01"
    source = "APP/Src/estimator_bus.c"
    graph = next(iter(data["dependency_graphs"][source].values()))
    for relative in graph:
        raw = (project / relative).read_bytes()
        name = "compiler_fixture/" + relative
        archive.writestr(name, raw)
        entries[name] = hashlib.sha256(raw).hexdigest()
    dependency = project / "build/FCCG/SilverStar_F407/Release/APP/Src/estimator_bus.d"
    archive.writestr("compiler_fixture/estimator_bus.d", dependency.read_bytes())
(destination / "inputs.json").write_text(json.dumps({"owner": "/root algorithm closeout",
    "review": "algorithm_timing_memory_20261015_v18", "entries": entries,
    "checker_before_sha256": data["tool_sha256"],
    "checker_after_sha256": hashlib.sha256(tool.read_bytes()).hexdigest(),
    "archive_sha256": hashlib.sha256((destination / "inputs.zip").read_bytes()).hexdigest(),
    "critical_contracts": "NOT_PROVEN", "hardware": "NOT_TESTED"}, indent=2) + "\n", encoding="utf-8")
print("registered reviewed source paths", len(sources), "dependency paths", len(graphs))
