"""Bounded task-owned command and exact source receipts."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
TASK = Path(__file__).resolve().parent
name, *command = sys.argv[1:]
env = dict(os.environ, PYTHONUTF8="1", PYTHONDONTWRITEBYTECODE="1", QT_QPA_PLATFORM="offscreen",
           PYTHONPATH=os.pathsep.join(str(ROOT / p) for p in ("apps/SCG/src", "apps/FLP/src")))
started = time.monotonic()
sources = subprocess.check_output(["git", "ls-files", "-z", "apps/SCG/src", "apps/SCG/plugins/builtin",
                                   "apps/SCG/tests", "apps/FLP/src", "apps/FLP/tests", "contracts"], cwd=ROOT).decode("utf-8").rstrip("\0").split("\0")
record = {"owner": "/root algorithm closeout", "command": command, "cwd": str(ROOT),
          "started_utc": datetime.now(timezone.utc).isoformat(),
          "head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
          "environment": {k: env[k] for k in ("PYTHONUTF8", "PYTHONDONTWRITEBYTECODE", "QT_QPA_PLATFORM", "PYTHONPATH", *[k for k in env if k.startswith("SILVERSTAR_CURRENT_") or k == "SILVERSTAR_FCCG_ROOT"])},
          "source_sha256": {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in sources if (ROOT / p).is_file()}}
with (TASK / (name + ".log")).open("xb") as stream:
    run = subprocess.run(command, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT)
record.update(exit_code=run.returncode, elapsed_seconds=time.monotonic() - started,
              finished_utc=datetime.now(timezone.utc).isoformat())
with (TASK / (name + ".json")).open("x", encoding="utf-8") as stream:
    json.dump(record, stream, indent=2)
    stream.write("\n")
print(json.dumps({k: record[k] for k in ("exit_code", "elapsed_seconds")}))
raise SystemExit(run.returncode)
