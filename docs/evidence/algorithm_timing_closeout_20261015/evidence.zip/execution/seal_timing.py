"""Seal reviewed timing/storage/binding work only; no cleanup or Git mutation."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[2]
TASK = Path(__file__).resolve().parent
DEST = ROOT / 'docs/evidence/algorithm_timing_closeout_20261015'
freeze_path = ROOT / '.work/dev013_watch_fusion01/SOURCE_FREEZE_20261015.json'
freeze = json.loads(freeze_path.read_text(encoding='utf-8'))
for entry in freeze['files'] + freeze['preserved_user_inputs']:
    assert hashlib.sha256((ROOT / entry['path']).read_bytes()).hexdigest() == entry['sha256'], entry['path']
for name in ['timing_generator01', 'timing_flp02', 'stack_post04']:
    assert json.loads((TASK / (name + '.json')).read_text())['exit_code'] == 0
for name in ['eskf15_0_stack01_serial02_BUILD', 'eskf15_0_stack01_serial02_ARTIFACT_CHECK',
             'eskf15_0_stack01_serial02_STACK_REPORT', 'eskf15_0_stack01_POWER10_CHECK',
             'eskf15_0_stack01_ARCHITECTURE_CHECK', 'eskf15_0_storage02_HOST_TESTS',
             'eskf15_0_storage02_STATIC_ANALYSIS', 'eskf15_1_storage02_HOST_TESTS',
             'eskf15_1_storage02_BUILD', 'eskf15_1_storage02_ARTIFACT_CHECK',
             'eskf15_1_storage02_POWER10_CHECK', 'kf6_1_stack02_serial03_BUILD',
             'kf6_1_stack02_serial03_ARTIFACT_CHECK', 'kf6_1_stack02_serial03_ARCHITECTURE_CHECK',
             'kf6_1_stack02_serial03_POWER10_CHECK', 'kf6_1_stack02_serial03_STATIC_ANALYSIS',
             'kf6_1_stack03_BUILD', 'kf6_1_stack03_ARTIFACT_CHECK', 'kf6_1_stack03_STACK_REPORT']:
    assert json.loads((TASK / (name + '.json')).read_text())['return_code'] == 0, name

DEST.mkdir(exist_ok=True)
assert {p.name for p in DEST.iterdir()} == {'README.md'}
source_paths = [entry['path'] for entry in freeze['files']]
additional = [
 'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/APP/Src/logger_task.c',
 'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tools/check_task_stacks.py',
 'apps/SCG/tests/test_stack_budget.py',
 'docs/public/SCG/NAVIGATION_STACK_INPUT_REVIEW_20261015.md',
 'docs/public/SCG/NAVIGATION_MODEL_INTERFACE_PLAN_20261015.md',
]
entries = {}
archive = DEST / 'evidence.zip'

def add(output, source, name):
    if name in entries:
        raise ValueError('Duplicate archive entry: ' + name)
    raw = source.read_bytes()
    output.writestr(name, raw)
    entries[name] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as output:
    for name in source_paths + additional:
        add(output, ROOT / name, 'source/' + name)
    add(output, freeze_path, 'source_freeze.json')
    for path in sorted(TASK.iterdir()):
        if path.is_file() and path.suffix in ('.py', '.json', '.log', '.md', '.txt'):
            add(output, path, 'execution/' + path.name)
    for path in sorted(TASK.glob('storage_*writer*.sslog')):
        add(output, path, 'storage_logs/' + path.name)
    for path in sorted((TASK / 'flp_pytest02').rglob('*')):
        if path.is_file() and path.suffix in ('.json', '.dll', '.c', '.h'):
            add(output, path, 'flp_final_artifacts/' + path.relative_to(TASK / 'flp_pytest02').as_posix())
    radio_catalog = ROOT / 'apps/SCG/plugins/builtin/silverstar_device_telemetry_sx1278/plugin.json'
    add(output, radio_catalog, 'unselected_dirty_catalog/' + radio_catalog.name)
    for project_name in ['eskf15_0_stack01', 'eskf15_1_storage02', 'kf6_1_stack02', 'kf6_1_stack03']:
        project = TASK / project_name
        for path in sorted((project / 'Generated').rglob('*')):
            if path.is_file():
                add(output, path, 'generated/' + project_name + '/' + path.relative_to(project).as_posix())
        for name in ['SilverStar.ssproject', 'Tools/check_task_stacks.py', 'Tools/check_power_of_ten.ps1']:
            path = project / name
            if path.is_file():
                add(output, path, 'generated/' + project_name + '/' + name)
        for path in sorted((project / 'build/FCCG/SilverStar_F407/Release').rglob('*')):
            if path.is_file() and (path.suffix in ('.elf', '.map', '.su', '.d') or
                                  'stack' in path.name or path.name == 'decision.json'):
                add(output, path, 'artifacts/' + project_name + '/' + path.relative_to(project).as_posix())
    prior = ROOT / '.work/dev013_timing_firmware01'
    for path in sorted(prior.iterdir()):
        if path.is_file() and (path.suffix in ('.json', '.log', '.md', '.c', '.ps1', '.py') or
                              'legacy_' in path.name and path.suffix == '.bin' or
                              path.name in ('eskf_trace03.sslog', 'kf6_trace04.jsonl')):
            add(output, path, 'prior_firmware/' + path.name)
    for path in sorted((prior / 'baseline_inputs').rglob('*')):
        if path.is_file():
            add(output, path, 'prior_firmware/baseline_inputs/' + path.relative_to(prior / 'baseline_inputs').as_posix())
    for kind in ('kf6', 'eskf15'):
        project = prior / f'generated_{kind}_0_trace02'
        path = project / f'nis013_{kind}.ssdecoder'
        add(output, path, 'prior_firmware/' + project.name + '/' + path.name)
    prior = ROOT / '.work/dev013_timing_flp01'
    for path in sorted(prior.rglob('*')):
        if path.is_file() and path.suffix in ('.json', '.log', '.md') and not any(
            part in ('cache', '.pytest_cache', '__pycache__', 'pytest') for part in path.parts):
            add(output, path, 'prior_flp/' + path.relative_to(prior).as_posix())

manifest = {'owner': '/root algorithm closeout', 'created_utc': datetime.now(timezone.utc).isoformat(),
 'base_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
 'source_sha256': {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
                   for name in source_paths + additional},
 'archive': {'path': archive.name, 'bytes': archive.stat().st_size,
             'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}, 'entries': entries,
 'scope': 'Two implemented timing modes, storage pressure and exact task stack input bindings',
 'not_implemented': ['delayed horizon with output predictor', 'active ESKF15 GNSS recovery policy'],
 'hardware': 'NOT_TESTED', 'whole_stack_msp_isr': 'NOT_PROVEN',
 'critical_contract_review': 'NOT_PROVEN', 'cleanup_authorized': False}
(DEST / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
covariance = set(json.loads((TASK / 'covariance_commit_paths.json').read_text()))
scg = [p for p in source_paths if p.startswith(('apps/SCG/', 'contracts/')) and p not in covariance]
scg += additional[:4]
scg += [p.relative_to(ROOT).as_posix() for p in (ROOT / 'docs/evidence/algorithm_stack_binding_20261015').iterdir()]
scg += [p.relative_to(ROOT).as_posix() for p in DEST.iterdir()]
flp = [p for p in source_paths if p.startswith('apps/FLP/')]
planning = [p for p in source_paths if p.startswith('docs/public/SCG/')] + additional[-1:]
for label, paths in [('timing_scg', scg), ('timing_flp', flp), ('model_planning', planning)]:
    assert len(paths) == len(set(paths))
    (TASK / (label + '_commit_paths.json')).write_text(json.dumps(paths, indent=2), encoding='utf-8')
print(json.dumps(manifest['archive']))
print('SCG', len(scg), 'FLP', len(flp), 'planning', len(planning))
