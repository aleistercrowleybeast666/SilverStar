"""Collect exact candidate inputs for review; never changes or bypasses a gate."""
from pathlib import Path
import hashlib
import importlib.util
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
TASK = Path(__file__).resolve().parent
tool = ROOT / "apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tools/check_task_stacks.py"
spec = importlib.util.spec_from_file_location("stack_candidate_review", tool)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
inputs, graphs, scopes = {}, {}, []
for name in ("kf6_1_memory01", "kf6_0_memory02", "eskf15_0_storage02", "eskf15_1_storage02"):
    project = TASK / name
    text = (project / "Generated/project_sources.mk").read_text(encoding="utf-8")
    block = re.search(r"(?ms)^C_SOURCES \+= \\\n(.*?)(?:\n\n|\Z)", text)
    sources = [line.strip().removesuffix("\\").strip() for line in block[1].splitlines()]
    compiled = 0
    for source in sources:
        for build in (project / "build/FCCG/SilverStar_F407/Release",
                      project / "build/FCCG/SilverStar_F407/Release/auto",
                      project / "build/FCCG/SilverStar_F407/ReleaseO0/legacy",
                      project / "build/FCCG/SilverStar_F407/ReleaseO0/auto"):
            dependency = build / Path(source).with_suffix(".d")
            if not dependency.is_file():
                continue
            dependencies = dependency.read_text(encoding="utf-8").split(":", 1)[1].replace("\\\n", " ").split("\n", 1)[0].split()
            digest = hashlib.sha256("\n".join(dependencies).encode()).hexdigest()
            expected = []
            for attribute in dir(module):
                if attribute.startswith("BINDING_DEPENDENCIES_"):
                    expected += getattr(module, attribute).get(source, [])
            if digest not in expected:
                graphs.setdefault(source, {})[digest] = dependencies
            compiled += 1
            break
    # Register candidates only in paths already in the compiled input closure,
    # plus its known new timing header. Unselected payloads gain no admission.
    dependencies = set(sources)
    for source in sources:
        for build in (project / "build/FCCG/SilverStar_F407/Release",
                      project / "build/FCCG/SilverStar_F407/Release/auto",
                      project / "build/FCCG/SilverStar_F407/ReleaseO0/legacy",
                      project / "build/FCCG/SilverStar_F407/ReleaseO0/auto"):
            dependency = build / Path(source).with_suffix(".d")
            if dependency.is_file():
                dependencies.update(dependency.read_text(encoding="utf-8").split(":", 1)[1].replace("\\\n", " ").split("\n", 1)[0].split())
                break
    if not compiled:
        scopes.append({"project": name, "compiled_sources": 0, "status": "NOT_COMPILED_NOT_REGISTERED"})
        continue
    for relative in sorted(dependencies):
        source = project / relative
        digest = module.BindingSourceHash_Get(source.read_text(encoding="utf-8"))
        if digest not in module.BindingSourceVersions_Get(relative):
            inputs.setdefault(relative, {}).setdefault(digest, []).append(name)
    scopes.append({"project": name, "compiled_sources": compiled, "status": "CANDIDATE_REVIEW_REQUIRED"})
result = {"owner": "/root algorithm closeout", "status": "NOT_PROVEN_CANDIDATES_ONLY",
          "inputs": inputs, "dependency_graphs": graphs, "scopes": scopes,
          "tool_sha256": hashlib.sha256(tool.read_bytes()).hexdigest()}
destination = TASK / (sys.argv[1] + ".json")
with destination.open("x", encoding="utf-8") as output:
    json.dump(result, output, indent=2)
print("candidate input paths", len(inputs), "graphs", len(graphs))
print(json.dumps(scopes, indent=2))
