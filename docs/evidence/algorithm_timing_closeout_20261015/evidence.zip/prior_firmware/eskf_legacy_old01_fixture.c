#define main Original_Main
#define s_gnss_source s_fixture_gnss_source
#define SystemNavigationBackend_Predict Trace_BackendPredict
#include "D:/python_software/SilverStar/.work/dev013_timing_firmware01/generated_eskf15_1_trace02/Tests/Host/test_eskf_backend.c"
#undef SystemNavigationBackend_Predict
#undef s_gnss_source
#undef main
#include "D:/python_software/SilverStar/.work/dev013_timing_firmware01/baseline_inputs/apps/SCG/plugins/builtin/silverstar_algorithm_estimator_eskf15/payload/Algorithm/Estimator/ESKF15/Src/navigation_eskf_backend.c"

static FILE *trace_out;
SystemDeviceResult Trace_BackendPredict(const SystemInertialIncrement *input,EstimatorOutputSnapshot *output)
{
 SystemDeviceResult result=SystemNavigationBackend_Predict(input,output);
 TEST_CHECK(fwrite(&result,sizeof(result),1U,trace_out)==1U);
 TEST_CHECK(fwrite(&s_state,sizeof(s_state),1U,trace_out)==1U);
 return result;
}
int main(int argc,char **argv)
{ if(argc!=2){return 2;}trace_out=fopen(argv[1],"wb");if(!trace_out){return 3;}int result=Original_Main(0,NULL);if(fclose(trace_out)!=0){return 4;}return result; }
