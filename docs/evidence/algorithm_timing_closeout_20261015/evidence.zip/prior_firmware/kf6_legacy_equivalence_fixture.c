#include <stdio.h>
#define main Original_Main
#include "D:/python_software/SilverStar/.work/dev013_timing_firmware01/generated_kf6_1_trace02/Tests/Host/test_navigation_kf_replay.c"
#undef main

static FILE *trace_out;
static void Trace_Write(const void *data,size_t size)
{ if(trace_out!=NULL) { TEST_CHECK(fwrite(data,1U,size,trace_out)==size); } }
static void Trace_Result(unsigned kind,NavigationReplayResult result,const NavigationReplayContext *h,const NavigationKfContext *state)
{
    Trace_Write(&kind,sizeof(kind));Trace_Write(&result,sizeof(result));
    if(h!=NULL){Trace_Write(&h->diagnostics,sizeof(h->diagnostics));Trace_Write(&h->present_us,sizeof(h->present_us));}
    if(state!=NULL){
        Trace_Write(state->state,sizeof(state->state));Trace_Write(state->covariance,sizeof(state->covariance));
        Trace_Write(state->last_gnss_group_nis,sizeof(state->last_gnss_group_nis));
        Trace_Write(&state->last_baro_nis,sizeof(state->last_baro_nis));
        Trace_Write(state->last_position_innovation,sizeof(state->last_position_innovation));
        Trace_Write(state->last_velocity_innovation,sizeof(state->last_velocity_innovation));
        Trace_Write(state->last_position_effective_variance,sizeof(state->last_position_effective_variance));
        Trace_Write(state->last_velocity_effective_variance,sizeof(state->last_velocity_effective_variance));
        Trace_Write(&state->predict_count,sizeof(uint32_t)*11U);
        Trace_Write(state->gnss_group_accept_count,sizeof(state->gnss_group_accept_count));
        Trace_Write(state->gnss_group_soft_count,sizeof(state->gnss_group_soft_count));
        Trace_Write(state->gnss_group_reject_count,sizeof(state->gnss_group_reject_count));
        Trace_Write(&state->health_flags,sizeof(state->health_flags));
    }
}
NavigationReplayResult __real_NavigationReplay_Predict(NavigationReplayContext*,NavigationKfContext*,uint64_t,const float*,float);
NavigationReplayResult __wrap_NavigationReplay_Predict(NavigationReplayContext*h,NavigationKfContext*s,uint64_t t,const float*d,float dt)
{ NavigationReplayResult r=__real_NavigationReplay_Predict(h,s,t,d,dt);Trace_Result(1U,r,h,s);return r; }
NavigationReplayResult __real_NavigationReplay_Insert(NavigationReplayContext*,NavigationKfContext*,const NavigationReplayEvent*,NavigationReplayOutcome*);
NavigationReplayResult __wrap_NavigationReplay_Insert(NavigationReplayContext*h,NavigationKfContext*s,const NavigationReplayEvent*e,NavigationReplayOutcome*o)
{ NavigationReplayResult r=__real_NavigationReplay_Insert(h,s,e,o);Trace_Result(2U,r,h,s);return r; }
NavigationReplayResult __real_NavigationReplay_ReceiveTrack(NavigationReplayContext*,const NavigationKfGnssEpoch*,NavigationReplayEvent*);
NavigationReplayResult __wrap_NavigationReplay_ReceiveTrack(NavigationReplayContext*h,const NavigationKfGnssEpoch*g,NavigationReplayEvent*e)
{ NavigationReplayResult r=__real_NavigationReplay_ReceiveTrack(h,g,e);Trace_Result(3U,r,h,NULL);return r; }
int main(int argc,char**argv)
{ if(argc!=2){return 2;}trace_out=fopen(argv[1],"wb");if(trace_out==NULL){return 3;}int result=Original_Main();if(fclose(trace_out)!=0){return 4;}return result; }
