/* Backend owning C is included by the task harness. */
typedef int BackendTranslationUnitIncludedByFixture;
