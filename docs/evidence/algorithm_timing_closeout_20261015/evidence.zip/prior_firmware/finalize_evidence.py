"""Read retained results and freeze this task's source/evidence manifests; no tests."""
from pathlib import Path
import datetime,hashlib,json
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as stream:
  for block in iter(lambda:stream.read(1048576),b''):h.update(block)
 return h.hexdigest()
expected=[f'generated_{kind}_{mode}_trace02_ARTIFACT_CHECK.json' for kind in ('kf6','eskf15') for mode in ('0','1')]
expected += [f'generated_kf6_{mode}_trace03_HOST_TESTS.json' for mode in ('0','1')]
assert all((OUT/name).exists() for name in expected),'Wait for every already-started run; do not infer completion'
source=json.loads((OUT/'final_source_manifest.json').read_text(encoding='utf-8'))
for row in source['sources']:
 assert sha(ROOT/row['path'])==row['after_sha256'],'Source changed after frozen hash: '+row['path']
source['status']='FROZEN_WITH_RECORDED_BLOCKERS'
source['frozen_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(OUT/'final_source_manifest.json').write_text(json.dumps(source,indent=2),encoding='utf-8')
rows=[]
suffixes=['ARCHITECTURE_CHECK','POWER10_CHECK','HOST_TESTS','BUILD','STATIC_ANALYSIS','ARTIFACT_CHECK','STACK_REPORT','O0']
for p in sorted(OUT.glob('generated_*_trace0[23]_*.json')):
 if not any(p.stem.endswith('_'+s) for s in suffixes):continue
 d=json.loads(p.read_text(encoding='utf-8'));log=p.with_suffix('.log');body=log.read_text(encoding='utf-8') if log.exists() else ''
 rows.append({'result':str(p.relative_to(ROOT)),'result_sha256':sha(p),
  'log':str(log.relative_to(ROOT)),'log_sha256':sha(log) if log.exists() else None,
  'command':d.get('command'),'exit_code':d.get('return_code',d.get('exit_code')),
  'host_summary':[l for l in body.splitlines() if 'SilverStar host summary:' in l],
  'not_applicable_and_skip':[l for l in body.splitlines() if any(s in l for s in ['NOT_APPLICABLE','SKIP'])],
  'warning_lines':[l for l in body.splitlines() if 'warning:' in l or 'WARNING:' in l],
  'failure_lines':[l for l in body.splitlines() if any(s in l for s in ['FAIL ','FAIL:', 'ValueError:', 'Host test failed:'])],
  'history_symbols':d.get('history_symbols'),
  'scope_notes':['Power10 text PASS retains critical-contract NOT_PROVEN'] if '_POWER10_' in p.name else []})
(OUT/'gate_status.json').write_text(json.dumps({'status':'COMPLETE_WITH_FAILURES','utc':source['frozen_utc'],'gates':rows},indent=2),encoding='utf-8')
artifacts=[]
projects=[OUT/f'generated_{kind}_{mode}_trace02' for kind in ('kf6','eskf15') for mode in ('0','1')]
projects += [OUT/f'generated_kf6_{mode}_trace03' for mode in ('0','1')]
for project in projects:
 for p in project.glob('*.ssdecoder'):
  artifacts.append({'path':str(p.relative_to(ROOT)),'sha256':sha(p),'bytes':p.stat().st_size,'role':'exact decoder, immutable evidence'})
 for p in (project/'build/FCCG').rglob('*'):
  if p.is_file() and p.suffix in ('.elf','.map','.ssdiag','.sslog'):
   artifacts.append({'path':str(p.relative_to(ROOT)),'sha256':sha(p),'bytes':p.stat().st_size,'role':'retained actual build or source log; never cleanup target'})
root_evidence=[]
for p in sorted(OUT.iterdir()):
 if p.is_file() and p.suffix in ('.json','.log','.md','.txt','.sslog','.jsonl','.bin','.c','.py','.ps1') and p.name!='evidence_index.json':
  root_evidence.append({'path':str(p.relative_to(ROOT)),'sha256':sha(p),'bytes':p.stat().st_size})
(OUT/'evidence_index.json').write_text(json.dumps({'owner':'navigation_performance','cleanup_authorized':False,'no_sdk_or_project_archive_created':True,'root_evidence':root_evidence,'formal_artifacts':artifacts},indent=2),encoding='utf-8')
print('Frozen sources:',len(source['sources']),'recorded gates:',len(rows),'formal artifacts:',len(artifacts))
for row in rows:print(Path(row['result']).name,row['exit_code'],*row['host_summary'])
