param([Parameter(Mandatory=$true)][string]$TaskProject,
      [Parameter(Mandatory=$true)][string]$TaskName,
      [Parameter(Mandatory=$true)][string]$TaskStem,
      [string[]]$TaskExtra=@(), [string[]]$TaskRunArgs=@(),
      [string]$TaskSourceFrom="", [string]$TaskSourceTo="", [switch]$TaskMergeLogger,
      [string]$TaskSecondSourceFrom="", [string]$TaskSecondSourceTo="", [switch]$TaskCold)
$ErrorActionPreference='Stop'
$TaskProject=(Resolve-Path -LiteralPath $TaskProject).Path
$TaskScript=Join-Path $TaskProject 'Tests/Host/run_tests.ps1'
$TaskPrefix=(Get-Content -LiteralPath $TaskScript -Raw).Split('$script:collectHostJobs = $false')[0]
$TaskPrefix=$TaskPrefix.Replace('$PSScriptRoot', "'" + (Split-Path -Parent $TaskScript).Replace("'","''") + "'")
Invoke-Expression $TaskPrefix
$TaskJob=@($script:hostJobs | Where-Object { $_.Name -eq $TaskName })
if ($TaskJob.Count -ne 1) { throw 'Expected exactly one emitted Host job' }
HostContract_JobPrepare -Job $TaskJob[0]
if ($TaskSourceFrom -ne '') {
 $TaskJob[0].Sources=@($TaskJob[0].Sources | ForEach-Object {
  if ($_ -eq $TaskSourceFrom) { $TaskSourceTo } else { $_ }
 })
}
if ($TaskSecondSourceFrom -ne '') {
 $TaskJob[0].Sources=@($TaskJob[0].Sources | ForEach-Object {
  if ($_ -eq $TaskSecondSourceFrom) { $TaskSecondSourceTo } else { $_ }
 })
}
if ($TaskCold) {
 $TaskJob[0].Sources=@((Join-Path $TaskProject 'Tests/Host/test_fusion_timing.c'),
  (Join-Path $TaskProject 'System/Src/system_barometer_cold.c'),
  (Join-Path $TaskProject 'System/Src/system_barometer.c'))
}
if ($TaskMergeLogger) {
 $TaskJob[0].Sources=@((@($TaskJob[0].Sources) + @($loggerSources | Where-Object {
  $_ -notmatch '(test_logger|diagnostic_log)\.c$'
 }) + @((Join-Path $TaskProject 'System/Src/system_time.c'))) | Select-Object -Unique)
}
$TaskArgs=@('-std=c11','-Wall','-Wextra','-Werror','-pedantic','-O2') +
    (HostContract_CompilerArgsGet -Overrides (@($TaskJob[0].ExtraCompilerArgs) + $TaskExtra)) +
    $includeArgs + @($TaskJob[0].Sources) + @($silverstarAssertSource,'-lm','-o',($TaskStem+'.exe'))
$TaskRecord=[ordered]@{compiler=$script:hostCompilerPath;version=$script:hostCompilerVersion;
    target=$script:hostCompilerTarget;args=$TaskArgs;project=$TaskProject;job=$TaskName;
    source_hashes=@{};compile_exit=$null;run_args=$TaskRunArgs;run_exit=$null}
foreach($TaskSource in @($TaskJob[0].Sources)+@($silverstarAssertSource)) {
 $TaskRecord.source_hashes[$TaskSource]=(Get-FileHash -LiteralPath $TaskSource -Algorithm SHA256).Hash.ToLower()
}
$TaskCompile=Invoke-HostCompiler -CompilerArgs $TaskArgs
$TaskRecord.compile_exit=$TaskCompile.ExitCode
$TaskCompile.Output | Out-File -LiteralPath ($TaskStem+'.compile.log') -Encoding utf8
if ($TaskCompile.ExitCode -eq 0) {
 $TaskOutput=@(& ($TaskStem+'.exe') @TaskRunArgs 2>&1)
 $TaskRecord.run_exit=$LASTEXITCODE
 $TaskOutput | Out-File -LiteralPath ($TaskStem+'.run.log') -Encoding utf8
}
$TaskRecord | ConvertTo-Json -Depth 8 | Out-File -LiteralPath ($TaskStem+'.json') -Encoding utf8
Write-Output ('HOST_JOB ' + $TaskName + ' compile=' + $TaskRecord.compile_exit + ' run=' + $TaskRecord.run_exit)
if ($TaskRecord.compile_exit -ne 0 -or $TaskRecord.run_exit -ne 0) { exit 1 }
