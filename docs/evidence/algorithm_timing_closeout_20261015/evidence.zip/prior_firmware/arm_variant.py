"""Actual all-source O0 build in a separate output root; no source/SDK copies."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
OUT=Path(__file__).resolve().parent
project=(OUT/sys.argv[1]).resolve()
assert project.parent==OUT and project.is_dir()
kind='eskf15' if 'eskf15' in project.name else 'kf6'
layout='auto' if kind=='eskf15' else 'legacy'
relative='build/FCCG/SilverStar_F407/ReleaseO0/'+layout
stem=OUT/(project.name+'_O0')
assert not stem.with_suffix('.json').exists()
command=['mingw32-make','-j2','TARGET_PROFILE=SilverStar_F407','CONFIG=Release',
         'OPT=-O0','MEMORY_LAYOUT='+layout,'BUILD_ROOT='+relative,'all']
started=time.time()
r=subprocess.run(command,cwd=project,capture_output=True,text=True,encoding='utf-8',errors='replace')
stem.with_suffix('.log').write_text(r.stdout+'\nSTDERR\n'+r.stderr,encoding='utf-8')
record={'command':command,'cwd':str(project),'exit_code':r.returncode,'seconds':time.time()-started,
        'scope':'Entire emitted C/ASM graph, strict owner compiler policy, actual ELF link; all source uses -O0.',
        'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'artifacts':{}}
for extension in ['elf','map','bin']:
 p=project/relative/('SilverStar_0_1_3.'+extension)
 if p.exists():record['artifacts'][str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
if r.returncode==0:
 elf=project/relative/'SilverStar_0_1_3.elf'
 nm=subprocess.run(['arm-none-eabi-nm','-a','-S',str(elf)],capture_output=True,text=True)
 stem.with_suffix('.nm.txt').write_text(nm.stdout,encoding='utf-8')
 record['nm_exit']=nm.returncode
 record['history_symbols']=[line for line in nm.stdout.splitlines() if any(line.endswith(' '+name) for name in ['s_replay','s_replay_storage','s_history','s_body_history'])]
stem.with_suffix('.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps(record,indent=2),flush=True)
sys.exit(r.returncode)
