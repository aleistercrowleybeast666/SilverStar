from pathlib import Path
import hashlib,json,sys
OUT=Path(__file__).resolve().parent
project=(OUT/sys.argv[1]).resolve()
assert project.parent==OUT
source=project/'Tests/Host/test_eskf_backend.c'
s=source.read_text(encoding='utf-8')
s=s.replace('#include "../../APP/Src/flight_task.c"', '#include "'+(project/'APP/Src/flight_task.c').as_posix()+'"')
s=s.replace('#include "../../APP/Src/logger_task.c"', '#include "'+(project/'APP/Src/logger_task.c').as_posix()+'"')
s=s.replace('    Test_OptionalOrigins();','    Test_OptionalOrigins();\n    Test_RecordsDrain(); /* Export consumer drains final optional-origin records too. */')
if len(sys.argv)>2 and sys.argv[2]=='edge':
    s=s.replace('        if (cycle == 195U)', '        if (cycle == 151U) { s_gnss_source = 3U; }\n        if (cycle == 152U) { s_gnss_source = 2U; }\n        if (cycle == 195U)')
    s=s.replace('s_failover_measurements == 8U','s_failover_measurements == 12U')
fixture=OUT/(project.name+'_export_fixture.c')
assert not fixture.exists()
fixture.write_text(s,encoding='utf-8')
fixture.with_suffix('.provenance.json').write_text(json.dumps({'upstream':str(source),'upstream_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'fixture_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),'changes':['Absolute include paths only','Consumer drains final optional-origin records before empty-queue assertion']+(['A2 to B3 to A2 same packet at cycles150/151/152, expected source3 record count+4'] if len(sys.argv)>2 else [])},indent=2),encoding='utf-8')
print(fixture)
