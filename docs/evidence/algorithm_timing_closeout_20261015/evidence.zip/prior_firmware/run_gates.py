"""Run real emitted gates on an existing named fresh task output; no Git/SDK copies."""
from pathlib import Path
import dataclasses, datetime, hashlib, json, os, subprocess, sys
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'apps/SCG/src'))
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.build.runner import BuildRunner, BuildAction
from silverstar_fccg.core.workspace import WorkspacePolicy
project=(OUT/sys.argv[1]).resolve()
assert project.parent==OUT and project.is_dir()
model=FccgService(ROOT/'apps/SCG').Project_Open(project/'SilverStar.ssproject')
runner=BuildRunner(WorkspacePolicy(project))
for name in sys.argv[2:]:
 stem=OUT/(project.name+'_'+name)
 assert not stem.with_suffix('.json').exists(), 'Never overwrite evidence'
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 result=runner.Run(model,project,getattr(BuildAction,name),line_callback=lambda line:None)
 record=dataclasses.asdict(result);record.pop('output',None)
 record.update(started_utc=started,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 stem.with_suffix('.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
 stem.with_suffix('.log').write_text(result.output,encoding='utf-8')
 print(name,'EXIT',result.return_code,flush=True)
 print(result.output[-2500:],flush=True)
