# KF6 / ESKF15 fusion timing: implementation proposal

Owner: navigation_performance. Status: IMPLEMENTING; root lifted the product freeze. Exact approved write set is in write_plan.json. No Git or hardware actions.
Reference integration commit supplied by root: 5af1efa1 (no Git operation by this task).
Scope: current/no replay and legacy replay; no delayed predictor, INS/SF6 option,
UI, FLP, USB, performance kernel edit, golden rewrite or hardware action.

## Actual existing boundaries

- KF6 runs in core `APP/Src/estimator_task.c`, not a separate KF6 backend.
  `Estimator_PredictionApply` calls `NavigationReplay_Predict`; GNSS and barometer
  go through `NavigationReplay_Insert`. Reset occurs at three lifecycle sites.
- KF6 `Estimator_MeasurementTimeResolve` first calls `SystemTime_MeasurementTimestampResolve`,
  then replaces the result with estimator present for untrusted, zero-delay input.
  `NavigationReplay_InsertedApply` has a present-time fast path, but still stores
  the event. Setting delay to zero therefore does not disable replay.
- ESKF15 `navigation_eskf_backend.c` owns live state, history, body history,
  source/sequence trackers, GNSS quality, consistency, health and log adapters.
  Every `NavigationEskfReplay_Insert` runs `Replay_Run`; prediction also rebuilds
  the prospective anchor when trimming. Current must bypass both operations.
- ESKF lever-arm velocity uses `Backend_AngularRateGet` over history. Current
  must use the latest accepted prediction's endpoint body rate instead, at its
  present application epoch; it cannot keep looking up delayed history. The stored value is the raw/calibrated
second-half body rate from the latest successful prediction. Each group subtracts
its then-current gyro bias in the unchanged measurement model; never cache the
bias-corrected rate or use the two-half average.
- Existing records are GNSS_MEASUREMENT 0x14/v1/164 bytes, BARO_MEASUREMENT
  0x15/v1/72, ESKF15_MEASUREMENT 0x25/v1/100. None explicitly identifies a timing
  mode or a separate application epoch. Existing source/sample/receive values
  and operation sequence identities must remain intact.
- Existing generator identity guards cover KF6 kernel paths and ESKF NIS paths,
  but not the complete core/backend/logging implementation of a new timing mode.
  Merely adding metadata would mislabel preserved old project payloads.

## Parameter, enum and declaration

Only KF6 and ESKF15 get integer `fusion_timing_mode`, min 0/max 1/step 1,
default=1 and legacy_default=1, generated `SYSTEM_FUSION_TIMING_MODE`.
Values: CURRENT=0, LEGACY_REPLAY=1. Missing/invalid generated values fail build
for these two algorithms; no mode 2 or runtime mode switch is introduced.
Use existing declarative parameter machinery; no parameter-schema/UI changes.
Enum/constants and execution-result mapping live in a small core timing header.

`metadata_declarations.fusion_timing` is rendered from resolved actual values,
not a fixed manifest mode. Root owns the contract/FLP boundary. Agreed words:

- source_time = resolved_measurement_epoch: unmodified common SystemTime resolver.
- mode 0 application_time = estimator_present; replays_history=false.
- mode 1 application_time = legacy_algorithm_epoch; replays_history=true.
- evaluation/output_state/output_covariance time = estimator_present.

For legacy KF6 untrusted && delay==0, application=present while source=receive.
Otherwise legacy uses its existing effective epoch. ESKF15 legacy application
is its resolved epoch. Preserve this exception; do not change numerics to fit
a declaration. Original raw `sample_timestamp_us` is not reinterpreted as a
trusted source epoch.

Configured delay remains meaningful in current for source-epoch resolution and
age evidence; it never shifts the live state or requests history. Rate planning
must report current replay window/capacity/steps as zero without erasing those
configured delays or relaxing arithmetic/CPU qualification checks.

## Current execution

KF6: add compact current context/APIs beside the existing replay adapter in
`navigation_kf_replay.h/.c`. It contains receive-side reacquisition tracking,
transaction scratch, present/epoch/continuity state and bounded identity evidence;
it has no IMU/event/checkpoint arrays. Share the existing observation/evidence/
group-recovery logic through small internal helpers, preserving the legacy call
order and checks. Do not edit `navigation_kf.c` or INS numerical code.

Core task selects reset/predict/receive/apply adapters at build time. Current
predict performs one live prediction with the original complete increment and
same dt semantics. Current updates copy live state to scratch, apply each admitted
packet once at present (position then velocity, then barometer), and commit only
after the complete operation succeeds. Legacy retains its older-component-first
ordering, event retention, rewind and original diagnostics. Current has no calls
to prune, checkpoint, insert-history, rebuild or historical prediction. Both implementation declarations remain in checked first-party source. The immutable generated
mode is an ordinary C constant branch. No runtime mode switch exists. Current must have no
linked legacy history/storage in the actual ARM ELF; -O0 and -O2 map/symbol verification
is required and is not inferred from a source-level constant.

ESKF15: keep numerical `navigation_eskf.c` and legacy replay implementation
unchanged. Backend mode 0 calls `NavigationEskf_Predict` once and
`NavigationEskf_Update` at live present. Retain temporal/source/generation and
body-quality checks formerly supplied by the replay wrapper. Keep only the
latest accepted endpoint rate for present-time lever-arm velocity; update this
cache only after successful prediction. Legacy continues using history lookup.
History arrays/initialization/trim/replay are excluded from the current build.

Both modes preserve external physical validity, finite/SPD checks, source
selection, GNSS native-time consistency, receive-side outage/reacquisition,
NIS thresholds/comparisons, robust scaling, health publication, lifecycle reset
and established failure paths. New current admission validates nonzero resolved
source, source <= receive <= present, epoch/generation, duplicate identity and
bounded ages before applying. Approved current policy: retain the existing 500 ms receive-age
limit and also enforce that same limit on current resolved source age; legacy
history/admission bounds stay unchanged. Equality at the limit is accepted.
Current invalid/stale/duplicate inputs are ordinary rejected outcomes, not fatal
assertions. Corrupt internal state and numeric failures keep safe failure behavior;
failed operations never publish partially committed live state or successful READY.

Identity checks are source/generation aware and bounded; monotonic uint32 sample
sequences use explicit wrap handling. Source switches reset the corresponding
receipt identity. Do not compare a GNSS source ID with the IMU source ID as if they
were the same namespace. Repeated direct calls must not fuse a packet twice.

## Record v2 contract (explicit serialization, no struct-layout casts)

The sole wire authority is `contracts/navigation_fusion_timing_records_v2.json`.
SCG catalogs, serializer tests and FLP must read/verify it, not independently
maintain another contract. The approved sizes are GNSS_MEASUREMENT 212 bytes,
BARO_MEASUREMENT 100 bytes and ESKF15_MEASUREMENT 116 bytes, record version 2.
Old prefix field order and all legacy values remain unchanged. Exact appended
names, types and offsets are defined by that contract. `timing_reserved` avoids
colliding with each old `reserved` field.

GNSS appends separately resolved position/velocity source epochs and actual
application epochs, timing mode/flags/execution, real selected `source_id` and
`calibration_generation`. GNSS source ID zero is valid; unavailable identity must
never be invented as zero. BARO appends its resolved source and application epochs,
timing fields, canonical logical producer source ID 1 and estimator calibration
generation. ESKF retains its existing resolved source field and appends application,
timing fields and the received packet `source_sequence`. Sequence must never come
from operation_sequence or the SSLOG header. KF6 replay_generation is a replay
counter, never calibration_generation.

The current identity key is source namespace + source ID + mission epoch +
calibration generation + actual delivered sequence + group. Barometer source 1 is
the canonical estimator producer, not a physical sensor instance. Cold failover
maintains a logical sequence; the actual EstimatorPressureSnapshot.sequence is
used rather than substituting the native physical record sequence. Legacy ESKF
barometer source continues to mean its historical selected IMU source. This batch
does not change producer/bus code or claim physical barometer switch auditing.

Flags are SOURCE_RESOLVED=0x01, APPLICATION_EPOCH_VALID=0x02,
TRUSTED_SOURCE=0x04, DELAY_FALLBACK=0x08 and LEGACY_PRESENT_OVERRIDE=0x10;
0xE0 is reserved. Trusted and delay fallback are mutually exclusive. The override
only describes legacy KF6 untrusted zero-delay behavior. No provable application
epoch means application=0 and APPLICATION_EPOCH_VALID clear. A clear flag does
not establish that no numerical attempt occurred: legacy ESKF can fail before or
after its target update without exposing the stage. NIS rejection can have a
valid application epoch. Evaluation remains the estimator present epoch.

Execution results are COMPLETE=0, INVALID=1, STALE=2, DUPLICATE=3,
EPOCH_MISMATCH=4, DISCONTINUITY=5, NUMERIC_ERROR=6, NOT_READY=7,
HISTORY_MISS=8, CAPACITY=9 and WORK_LIMIT=10. Current uses only 0..7.
COMPLETE is execution completion, not NIS acceptance, logger delivery or READY.
Legacy replay-result fields use NOT_RUN=255 in current mode; execution results
never use that sentinel. Current does not increment replay_generation.

Mode 1 original payload prefixes and full numerical state/P outputs must compare
to the pre-task baseline. Added fields, component provenance, record versions and
decoder hashes intentionally differ. Old v1 logs stay bound to their exact old
decoder; no recorded bytes or package is rewritten. Logger capacities and explicit
serializer boundaries must accommodate v2. No unrelated record is version-bumped.

## Version and identity plan

Proposed component versions: KF6 0.2.1 -> 0.3.0; ESKF15 0.1.1 -> 0.2.0;
core 0.1.0 -> 0.1.1; SSLOG 0.1.0 -> 0.2.0. Record versions above become 2.
KF6 mathematical revision 2 and ESKF numerical revision do not change. The timing
contract has independent revision 1; product VERSION and frozen releases do not
change. Root confirmed these component versions and record layouts, including the
pre-activation ESKF extension from 112 to 116 bytes for actual packet sequence,
and GNSS/BARO extensions from 204/92 to 212/100 for explicit identity evidence.

Before generation, validate timing payload identity across selected algorithm,
core adapter and SSLOG serializer/schema inputs. Fresh projects may initialize
from catalog; preserved/edited old projects cannot receive current metadata or
silently updated payloads. Fail with a fresh-project migration reason. Normal
generation remains ownership-preserving. Expand no source/checker allowlists.

## Validation to execute after approval

1. Capture source hashes/configuration before changes. Demonstrate pre-change
   current option absent and default replay behavior with dedicated Host traces.
2. Same-compiler baseline vs new mode 1 full state/P/outcome, trusted/untrusted
   zero/nonzero delays, delayed out-of-order groups, source switch, duplicate,
   sequence wrap, reset, invalid/overflow and transaction failures. Compare old
   record prefixes. Do not rerun the unrelated completed performance suite.
3. Mode 0 Host proof: no history calls/storage, one prediction per input, no
   reapplication after late observations, complete dense P, latest-state NIS,
   receive/source-age boundaries, future/pre-epoch/underflow/invalid timestamps,
   sequence identity, lever-arm endpoint rate, failed state unchanged, and log
   round trips including mode/validity/result. Delay zero is not the proof.
4. New SCG tests: parameter default/reconcile/range, no INS/SF6 option, actual
   declaration/value match, rate-plan zero replay, provenance refusal preserving
   old projects, record catalog/decoder hash/serializer length agreement. Keep
   golden fixtures unchanged. Root owns FLP import/refusal integration.
5. Fresh separately named projects for KF6 mode 0/1 and ESKF15 mode 0/1 using
   external SDK paths, plus INS-only/SF6 compile coverage and logging-disabled
   coverage. Exact emitted power10-check, Host, real analyzer compilation,
   ARM link, architecture/source graph, artifact/memory/stack reports. Complete
   failures/skips/versions/commands/configs/source and artifact hashes retained.
6. The previous stack binding mismatch is an explicit known blocker. Do not
   whitelist it as part of this feature or call a partial report a stack proof.
   Any catalog expectation updates in architecture checking are limited to the
   reviewed v2 record contract; other gates/thresholds/exceptions stay intact.

## Ownership and approval boundary

Exact product/test candidates and their current hashes are in `write_plan.json`.
Root retains contracts/FLP, and must synchronize actual-parameter recognition,
new component versions, v2 records and current numerical-replay refusal before
activation. This subtask will not edit FLP/UI/USB, any performance kernel,
golden, Git or hardware. Any newly discovered necessary file is reported before
expanding the approved write set. This design creates no firmware support claim.


## Implemented packet and prediction semantics addendum

GNSS source IDs are checked uint32 values less than the actual generated
PROJECT_GNSS_INSTANCE_COUNT_MAX=4 before any index, including valid ID0.
Four SystemFusionReceipt watermarks plus one canonical barometer watermark
retain A-to-B-to-A identity; each is 8 host bytes (40 total). This added bounded
state is not by itself evidence of lower total RAM. Equal sequence and used
mask rejects DUPLICATE; forward unsigned delta 1..0x7fffffff is new, delta
0x80000000..0xffffffff is DISCONTINUITY. UINT32_MAX-to-0 is forward. Reset of
mission/calibration identity clears the watermarks. Packet bit0x80 is consumed
after receive-time/epoch/readiness checks, before consistency processing. Each
delivered group is consumed before source-age checks, including source-stale
rejection; repeated delivery cannot change its source epoch to bypass refusal.

ESKF GNSS emits a contiguous group0,1,2,3 quartet even for physically invalid
or packet-rejected data, with common epoch/calibration/source/source_sequence/
receive/evaluation and consecutive operation sequence. Barometer follows the
quartet. Same selected source and sequence on consecutive polling is skipped
without logs. A-to-B-to-A delivery is rejected by retained packet watermarks.
The FLP numerical executor binds this execution rule to exact ESKF0.2.0 and
mode0; missing/reordered groups cannot prove a packet. Raw log opening still
preserves honest partial diagnostic records and does not label them corrupted.

Current ESKF cannot dispatch measurement before the first successful prediction:
endpoint_valid remains false and result is NOT_READY7. Successful prediction
caches calibrated/raw body gyro2 only. The numerical model subtracts the then
current gyro bias per group. Invalid physical admission returns INVALID1 without
application evidence. Physically valid, admitted NaN/invalid variance reaches
the unchanged kernel: ordinary INVALID_INPUT3 is execution COMPLETE0 with a
proven application epoch. Numeric/model mismatch latches fault6 and commits no
numerical state. First-predict timestamp setup is rolled back on failure. The
fault certificate clears snapshot initialized/mission flags, disables backend
activity and makes SnapshotGet NOT_READY; the task clears its own lifecycle flags
when receiving that explicit terminal certificate. Legacy path is unchanged.

KF6 ESTIMATOR_STEP v0 layout remains unchanged. The exact KF6 0.3.0 mode0
metadata.navigation_semantics.fusion_prediction_adapter binds existing
replay_result to the current prediction adapter enum: reachable0,1,4,5,6;
committed0; fault-latched4,5,6; attitude_result0 means not called. Values2,3,7
are unreachable and must not be numerically replayed. Its sources are the
existing STEP layout/enum and actual adapter code, not a new wire authority.
Measurement v2 replay_result remains255; receive_result remains the legacy
mapping, while appended execution fields use the new execution enum.

Default estimator logger slot200 was too small for actual sizeof record240;
changed only that slot to240, same48 slots =>1920 extra raw queue bytes. Normal
slot200 and queue depths are unchanged. Actual old-slot rejection and new-slot
acceptance are retained under sslog/. ARM alignment/map remain separate checks.

No Power10 exceptions were extended. Initial conditional dispatch triggered
rule8 FAIL; immutable ordinary C dispatch replaces it. Function boundaries now
separate GNSS packet receipt/admission, barometer diagnostic preparation, and
ESKF input/epoch preparation by responsibility. All selected first-party sources
remain in emitted gates, and both modes will be checked.
