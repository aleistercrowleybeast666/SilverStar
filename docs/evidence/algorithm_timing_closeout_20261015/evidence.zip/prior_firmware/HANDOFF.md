# Current/no-replay firmware batch — evidence and remaining blockers

Owner: navigation_performance. Parent reference integration commit: 5af1efa1;
this task made no Git operations. Exact dirty-source identities are recorded in
`final_source_manifest.json`, the generated `*_snapshot.json` inventories, and
per-command JSON. No hardware, serial, DAP, flash, release, push or cleanup ran.

## Delivered implementation

- KF6 0.3.0 and ESKF15 0.2.0 expose `fusion_timing_mode`: 0 applies at the
  estimator present without history replay; 1 is the default legacy replay.
  INS/SF6 have no fake parameter. Mode is an immutable generated constant.
- Current admission independently checks source and receive ages against
  500000 us, ordering, epoch/calibration and bounded source identity. Four GNSS
  watermarks retain A→B→A duplicate protection, forward uint32 serial ordering,
  wrap and half-range refusal. Barometer uses logical producer 1 and the actual
  cold producer's logical sequence. No physical-barometer-instance audit claim.
- ESKF current retains the latest successful second-half raw/calibrated gyro;
  each observation uses its then-current bias. Before that first prediction,
  observations are NOT_READY. Numerical prediction failure preserves the state
  including timestamp/epoch; terminal fault invalidates READY/publication.
- Core 0.1.1 and SSLOG 0.2.0 produce append-only GNSS/BARO/ESKF v2 records of
  212/100/116 bytes. Source/receive/application/evaluation are distinct; current
  measurement replay_result=255. KF STEP v0 keeps its layout and is interpreted
  only through the exact-version package prediction-adapter declaration.
- The unique wire authority is the root-owned
  `contracts/navigation_fusion_timing_records_v2.json`, SHA256
  `257f574479bd3fea5cc4564c7afd00504c39f1f66dda6ad793c34e9b7834f5fd`.
  Clear application-valid bit means missing evidence, not proof of no execution.
  COMPLETE means the call completed, not NIS acceptance or READY.
- Capability-bearing generation checks the complete owned payload identity and
  refuses stale or user-edited payload rather than overwriting it. Legacy
  combinations without the new capability retain their prior path.
- The estimator queue slot is 240 instead of 200 bytes (48 slots unchanged,
  +1920 raw queue bytes). Normal queue slot and capacities are unchanged.

The 29 approved paths, ownership, baseline hashes and rationale are in
`write_plan.json`. Numerical kernels and FLP/UI/USB were not written by this
task. SSLOG's seven-path subset was written by the explicitly delegated
`timing_sslog` agent; its complete report is `sslog/REPORT.md`.

## Tests already completed

| Scope | Recorded result |
|---|---|
| Generator/provenance pre-implementation | 14 failed, 11 passed: new feature absent |
| Stable generator/provenance post implementation | 25 passed (`generator_post02.*`) |
| KF current direct adapter, time/identity/fault boundaries | 5477 checks, 0 failures (`generated_kf6_0_validate01_host.*`) |
| ESKF current direct backend, full state/P and gyro/bias, first-predict fault | 1311 checks, 0 failures (`generated_eskf15_0_validate01_host.*`) |
| Cold logical producer and duplicate boundary | 30 checks, 0 failures, plus original cold suite; actual producer C (`cold_logical01.*`) |
| Codec and actual LoggerBus/SPSC | Child report; three exact layouts, all offsets, capacities and old prefixes |
| Corrected selected-policy queue test | KF6 4554/0, ESKF15 4551/0; `sslog/selection_fix01/` |
| Old vs new KF legacy replay | Each 475873 checks/0; 10187496-byte numerical/diagnostic traces exactly equal |
| Old vs new ESKF legacy backend | Each 1999 checks/0; complete state/P/results 202188 bytes exactly equal |

Legacy comparisons use the same GCC16.1/O2, shared numerical kernel and current
headers/configuration, substituting only the pre-current owning replay/backend
C. They prove those inputs, not all possible legacy behavior. KF trace contains
all six state elements, all 36 P elements, NIS, innovations/effective R, counters,
replay diagnostics and present time; ESKF contains the complete 15-state object
and covariance after every actual backend prediction. See
`kf6_legacy_equivalence_result.json` and `eskf_legacy_equivalence_result.json`.

### Actual current backends and independent FLP

- `eskf_trace03.sslog`: SHA256
  `cc48a6e3a9d598dc063529081fdea82a6f1f97022b3e8346aeba327705477e48`.
  Exact decoder: `generated_eskf15_0_trace02/nis013_eskf15.ssdecoder`, SHA256
  `35ed9c017b2ee29672b95d945870a78b3d67d9a972837baed1f7758776e93463`.
  Actual backend/LoggerBus/LoggerTask/serializer: 2166 checks, 0 failures,
  506 serialized records. Single main mission; separate optional-origin tests
  execute after the real logger closes. A2→B3→A2 is included.
  Sibling FLP production-open and independent numerical execution passed in
  `.work/dev013_timing_flp01/backend_final02`; all 107 measurement timing and
  identity comparisons passed. Full state/P numerical result remains
  APPROXIMATE, not bit-identical.
- `kf6_trace04.jsonl`: SHA256
  `eb0d125564f75a38d6e3ebea07350fa829d7c4ea6f82ea85007ffda5bb9f04ea`.
  Exact decoder: `generated_kf6_0_trace02/nis013_kf6.ssdecoder`, SHA256
  `e05e821c9a7aee5f7d882ed478c427f1613cc1cecf565f80ef730fc061910a93`.
  Actual initialization/prediction/GNSS/barometer/LoggerBus/serializer:
  638 checks/0, 201 complete state/P samples, 200 inputs, 297 real wire records.
  The fixture supplies sensors, clock and explicit lifecycle activation; this
  is not full mission-start or full SSLOG-open proof. FLP independent CurrentState
  and its operation runner each matched 200 predictions, all 47 measurements,
  full 6×6 P, state/q/NIS and timing/identity. Max state/P/NIS differences:
  1.91e-9 / 6.00e-8 / 2.94e-11; history count stayed zero. Evidence:
  `.work/dev013_timing_flp01/kf_backend02/pytest/test_actual_kf_current_backend0/kf_backend_parity.json`.

## Fresh whole-project gates

Four `generated_{kf6,eskf15}_{0,1}_trace02` projects contain auditable source
snapshots. No SDK copies: external SDK inputs from the prior NIS configurations
were reused. `gate_status.json` is the machine-readable final execution matrix;
each listed gate has its own unabridged `.log` and command/result `.json`.

All four emitted architecture checks pass 356/0. All four emitted Power10
text checks pass without new exceptions (KF 6497 checks, ESKF 6355), while
explicitly reporting **critical-contract review NOT_PROVEN**. Both implementations
remain visible to the first-party gate; ordinary constant C dispatch replaced
the rejected extra preprocessing branches.

All four O2 ARM whole-source compile/link runs passed. Actual text/data/bss:

| Configuration | text | data | bss |
|---|---:|---:|---:|
| KF current | 339668 | 1140 | 133728 |
| KF legacy | 343124 | 1140 | 161856 |
| ESKF current | 327140 | 1140 | 139344 |
| ESKF legacy | 328660 | 1140 | 168552 |

O2 current ELFs contain neither KF `s_replay`/`s_replay_storage` nor ESKF
`s_history`/`s_body_history`. Legacy ELFs contain those exact symbols. Complete
nm output is `generated_*_trace02_O2.nm.txt`. These figures are not stack margin,
WCET, hardware validation or flight qualification.

## Remaining blockers — do not claim complete acceptance

1. **O0 history storage proof failed.** KF all-source O0 ELF links but shared
   CCM input section retains `s_replay_storage`, size 0x2880 = 10368 bytes.
   ESKF all-source O0 compiles, but automatic placement discovers `s_history`
   in the object candidate set and then refuses because linker GC removed the
   final symbol: `Linked whitelist symbol missing or ambiguous: s_history`.
   No formal ESKF O0 ELF was produced. Complete commands/map/output are
   `generated_{kf6,eskf15}_0_trace02_O0.*`. Moving a static into a constant-false
   local block alone also retains the explicit input section at O0 in the small
   `o0_storage_scope_probe.*`; it is not a solution.
   Minimum next-batch candidates: target/platform memory section ownership for
   independently collectable KF history, and owning auto_memory_layout candidate
   validation against actual linked GC reachability, or a mode-selected source
   split with all first-party files still checked. These require a new approved
   common-file scope. No exception, allowlist or threshold was changed here.
2. **All four stack reports refuse the reviewed callback input binding** at
   `Generated/Inc/project_algorithm_parameters.h`. See `*_STACK_REPORT.*`.
   This is not a stack pass and no task/ISR/library/main/MSP bound is claimed.
3. **Full Host results must be read as executed.** KF trace02 stopped at the
   new queue test's three unsupported-ESKF-stream assertions; prior logger
   2106353 checks passed. The owning new test is corrected, with positive ESKF
   and explicit unsupported KF behavior. Fresh KF trace03 full runs are separate
   recorded runs; both pass and do not retroactively turn trace02 green. The final matrix
   records completed/failed/not-run gates and their real scopes.
4. **Both ESKF modes fail full Host storage stress.** Each actual emitted
   `startup-burst-overload` scenario reaches `test_logger_storage.c:507`:
   `bus.overflow_count == s_recovery_drops` fails. Drops at recovery sampling were
   443; one later drop at frame 13810 / 69637300 us makes 444. Normal queue high
   water is 80/80, estimator 47/48. Its main Host cases finished first; the whole
   Host gate still exits 2. Both modes reproduce the same recorded values.
   The trace configuration enabled relevant ESKF and
   navigation-quality streams with decimation 1 before generation. Causality
   between that workload, expanded records and the prior stress assumptions is
   not established. Preserve the complete log, configuration and generated
   `build/FCCG/Host/Tests/StorageIntegrity/logger-startup-burst-overload.sslog`.
   No assertion, capacity or decimation was weakened to pass. Parent directed
   no new attribution matrix in this batch.
5. **KF legacy artifact budget fails.** The actual O2 link succeeds, but
   artifact-check exits 2 because main SRAM=103820 exceeds the reviewed logging
   budget=102400 by 1420 bytes. Physical capacity=131072 does not waive that
   gate. Estimator slot240 is required for the actual record and adds1920 bytes;
   legacy GNSS events also carry the new calibration identity. No budget or
   queue threshold was changed. Current KF and current ESKF artifact checks
   pass their recorded scopes. ESKF legacy artifact-check also exits0 under
   its existing auto-layout policy, with an explicit historical-budget warning:
   main SRAM119484 and remaining11588 bytes. That policy was not changed here,
   and its warning is not evidence of safe stack margin.
6. No board or flight evidence. Power10 candidate counts and compiler checks do
   not prove every safety contract, whole-program recursion/timing or stack.

## Preserved failure provenance

No failed gate/test output was deleted. This includes initial new-feature
pytest failures; initial logger size/version assertions; original 200-byte
slot rejection; KF preparation fixture using removed history; first-predict
ESKF timestamp commit and stale READY failures before their owning fixes;
intermediate test enum/duplicate-static typos; strict trace fixture compile
diagnostics; initial export policy and final queue failures; and trace02's
honest multi-initialization time gap rejected by FLP. Trace03 was generated by
closing the actual main mission before separate tests, not by trimming a log.
The generation script's erroneous `model.logging` access failed before creating
trace01; corrected `logging_streams` produced trace02. Recovery's temporary
unregistered files were withdrawn by root before these snapshots; none were
silently deleted by this agent.

One intermediate 24-pass/1-fail pytest run collided with this agent editing a
payload test during identity hashing; its terminal result was observed but a
complete standalone task log was not retained. The stable 25-pass run is
separate evidence. Do not invent a retained full log or attribute its failure
to the provenance guard without that limitation.

### Final Host-only correction snapshot

KF current `generated_kf6_0_trace03` full emitted Host gate passed: 83
executables, 4456585 checks, zero failures, 11 compile-pass cases, 18 expected
compile failures and 9 explicitly not-applicable cases; all storage integrity
scenarios completed. Its earlier trace02 failure remains unchanged. A file-by-file
comparison finds only `SilverStar.ssproject`, `.fccg/ownership.json` and the
corrected Host test differ between trace02 and trace03 in each KF mode;
all target source, generated headers and decoder packages match. See
`trace02_trace03_diff_inventory.json`. No unexecuted whole-suite pass is inferred.

KF legacy `generated_kf6_1_trace03` also completes the full emitted Host gate:
83 executables, 4456581 checks, zero failures, 11 compile-pass cases, 18 expected
compile failures and 9 not-applicable cases, including all storage scenarios.
Both ESKF trace02 full runs remain failed at the exact storage overload recovery
assertion described above; their earlier ordinary Host cases are not promoted
to a full-suite pass. All already-started runs have ended. No platform, automatic
layout, stack binding or storage stress repair was started after the parent
directed this safe-boundary freeze.

Final gate summary (fresh emitted configurations):

| Configuration | Architecture / P10 text | ARM O2 / real analyzer | Full Host | Artifact | Stack |
|---|---|---|---|---|---|
| KF current | PASS / PASS, critical review NOT_PROVEN | PASS / PASS | trace03 PASS | PASS | FAIL binding |
| KF legacy | PASS / PASS, critical review NOT_PROVEN | PASS / PASS | trace03 PASS | FAIL SRAM budget | FAIL binding |
| ESKF current | PASS / PASS, critical review NOT_PROVEN | PASS / PASS | FAIL storage recovery | PASS | FAIL binding |
| ESKF legacy | PASS / PASS, critical review NOT_PROVEN | PASS / PASS | FAIL storage recovery | PASS with existing auto-layout warning | FAIL binding |

The four emitted analyzer runs each execute110 real `-fanalyzer -c` first-party
ARM compilation commands and link successfully, with zero compiler diagnostics;
none uses `-fsyntax-only`. `analyzer_scope.json` records this scope. ARM selected
source-graph counts differ from the gate's all-first-party source-file count;
neither is advertised as a proof of all unselected target combinations.
