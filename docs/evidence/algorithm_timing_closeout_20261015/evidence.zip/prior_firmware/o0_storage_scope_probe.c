typedef struct { char bytes[10368]; } Storage;
static Storage *Storage_Get(void) { if (MODE == 1) { static Storage value __attribute__((section(".bss.shared"))); return &value; } return (Storage*)0; }
Storage *Owner_Get(void) { if (MODE == 1) return Storage_Get(); return (Storage*)0; }
