"""Small task-owned fresh output; SDK inputs remain external, no Git operations."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time
from dataclasses import replace

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "apps/SCG/src"))
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.project.configuration import ProjectConfiguration_Reconcile

kind, mode, suffix = sys.argv[1:4]
assert kind in ("kf6", "eskf15") and mode in ("0", "1")
project = OUT / f"generated_{kind}_{mode}_{suffix}"
assert not project.exists(), "Fresh outputs must never overwrite an earlier evidence project"
source = ROOT / ".work/dev013_nis01" / ("generated_kf602" if kind == "kf6" else "generated_eskf1503")
service = FccgService(ROOT / "apps/SCG")
model = service.Project_Open(source / "SilverStar.ssproject")
model = ProjectConfiguration_Reconcile(model, service.catalog).model
model.algorithm_parameters[f"silverstar.algorithm.estimator.{kind}"]["fusion_timing_mode"] = int(mode)
if suffix.startswith("trace"):
    model.logging_streams = [replace(stream, enabled=True, decimation=1)
        if "ESKF15" in stream.record or stream.record == "FLIGHT_LOG_RECORD_NAV_QUALITY"
        else stream for stream in model.logging_streams]
model.component_provenance = {}
started = time.time()
service.Project_Save(model, project, confirm_dangerous=True)
snapshot = {"owner": "navigation_performance", "configuration_source": str(source),
            "configuration": model.Dictionary_Get(), "generation_seconds": time.time() - started,
            "source_reference_from_parent": "5af1efa1 plus audited dirty sources; no Git call",
            "files": {str(p.relative_to(project)): hashlib.sha256(p.read_bytes()).hexdigest()
                      for p in project.rglob("*") if p.is_file()}}
(OUT / f"{project.name}_snapshot.json").write_text(json.dumps(snapshot, indent=2), encoding="utf-8")
print("GENERATED", project, flush=True)
if len(sys.argv) > 4:
    names = sys.argv[4:]
    quoted = ",".join("'" + name + "'" for name in names)
    command = ["pwsh", "-NoProfile", "-Command",
               f"& '{project / 'Tests/Host/run_tests.ps1'}' -Only @({quoted})"]
    started = time.time()
    result = subprocess.run(command, cwd=project, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"),
                            capture_output=True, text=True, encoding="utf-8", errors="replace")
    stem = OUT / f"{project.name}_host"
    stem.with_suffix(".log").write_text(result.stdout + "\nSTDERR\n" + result.stderr, encoding="utf-8")
    stem.with_suffix(".json").write_text(json.dumps({"command": command, "exit_code": result.returncode,
        "seconds": time.time() - started, "stdout": result.stdout, "stderr": result.stderr}, indent=2), encoding="utf-8")
    print(result.stdout[-10000:] + result.stderr[-10000:])
    raise SystemExit(result.returncode)
