# FLP current timing: staged write and verification plan

Owner: `/root/fusion_current_mode`. These files are a new-test and planning batch.
Existing FLP product files remain frozen until root confirms its boundary/barometer
commit. No hardware, Git mutation, release change, cleanup or whole-tree copy is
part of this batch. `write_plan.json` is the exact approved 15-product-file list.

## Authority and identity

Use `contracts/navigation_fusion_timing_records_v2.json` directly for wire fields,
lengths, enum values, flags, timestamp meaning and source namespaces. The approved
sizes are GNSS 212 bytes, BARO 100 bytes, ESKF15 116 bytes. The superseded 204/92/112
sizes are not compatibility variants. V1 remains unchanged.

Current is integer 0; legacy replay is 1 and is the execution compatibility value
only for explicitly known legacy contracts. New actual parameters must match the
component lock, metadata declaration and record modes. Missing actual metadata is
not an offline-default recording. Unknown versions or declarations gain no legacy
identity. SF6 and PureINS gain no timing parameter. Mode 2 has no implementation.

Logical identity is source namespace, source ID, mission epoch, calibration
generation, producer source sequence and group. Header record sequence and replay
generation cannot supply those values. BARO ID 1 identifies the canonical
estimator pressure producer; its logical sequence need not match a native sensor
sequence. Physical barometer failover is not independently auditable from this
record. Native-data What-if association must have unique recorded evidence;
timestamp or sequence similarity across instances is insufficient.

`APPLICATION_EPOCH_VALID` describes evidence for an application epoch. If clear,
the serialized application is zero and normalized application is unknown. It
does not establish that a legacy numerical attempt never happened. COMPLETE
describes a finished attempt, including NIS rejection. Current's old replay-result
field is 255 NOT_RUN, separate from execution results 0 through 7.

Age and ordering checks govern admission, not whether an honest STALE diagnostic
can be decoded. The ordinary rejected observation must remain visible. Root has
been asked to clarify this distinction in the authority contract before code.

## Proposed interfaces exercised by drafts

These names are local FLP API proposals, not additional wire authorities. They
will be reconciled against the actual firmware interface before implementation.

- `kf6.current_state.CurrentState(state, timestamp_us=0, epoch=1,
  calibration_generation=...)`: `Predict`, `Receive`, `Insert`, `state`,
  `present`, and `Audit_Get`. Current operation returns use the wire execution
  enumeration. `ReplayEvent.measurement_us` remains the resolved source epoch;
  source ID and calibration generation come from its explicit payload. Each
  operation commits a full candidate state and covariance only on successful
  numerical completion. FixedLagReplay history methods must never be called.
- `eskf15.current_state.CurrentState(kernel, start_us, epoch=...,
  lever_arm=...)`: `Body_Receive`, `Measurement_Receive`, `kernel`, `present_us`,
  `Audit_Get`. Add optional `source_sequence` and `mission_epoch` fields to the
  existing immutable Measurement type; legacy defaults retain old behavior,
  current requires evidence. Existing Measurement.key remains a reporting key,
  never producer duplicate identity. Measurement return retains NIS/update result;
  execution result remains separate.
- Both audits expose `last_source_us`, `last_application_us`,
  `last_execution_result`, `history_replay_count`, `history_step_count`. Valid
  current application equals present. Rejected admission has no application
  evidence. Counters describe actual execution and storage, not renamed history.
- `fusion_timing_records.FusionTimingLayout_Validate(layout)` validates the exact
  root-owned v2 field names/types/counts/order and cumulative byte offsets, size,
  ID/version, and absence of value scale/offset transforms.
- `FusionTimingOperations_Get(record, declared_mode=...)` validates and normalizes
  the decoded record without mutation, returning immutable per-operation objects
  with source/application/present times, execution result and explicit identity.
  Unknown application normalizes to `None`, not a fabricated valid zero epoch.

The package admission hook and `LogOpenCoordinator` call the same trusted
validator. Descriptor and `.ssdecoder` matching remains mandatory. No alternate
production open path, executable decoder payload or permissive fallback is added.

## Four test groups

| Draft | Current coverage | Additional integration evidence still required |
| --- | --- | --- |
| `test_fusion_current_state.py` | Present-vs-replay distinction; forbidden history methods; full x/P comparison; source and receive age limits; invalid timing/data; producer duplicates; full-state prediction rollback; ESKF raw gyro2 and latest residual bias; same-packet groups; rejected BODY state/omega rollback | KF6 receive tracking exactly once; fixed packet position/velocity/baro order; active mission/source/generation transitions; uint32 sequence rollover policy; bounded duplicate metadata over a long stream; health and reacquisition paths |
| `test_fusion_timing_records_v2.py` | Contract-driven byte layouts and unchanged v1 prefix; record immutability; valid source/application times; identity; reserved bytes/flags; invalid mode/result; COMPLETE vs NIS rejection; honest legacy unknown application; honest STALE record; strict field identity | Generated package actual/declaration/component agreement; LogOpenCoordinator Descriptor failures and full raw-log hash preservation; native What-if association ambiguity; current v2 required-record admission |
| `test_fusion_current_native_parity.py` | Actual C ESKF numerical core at O0/O2, all five groups, complete state and 225 P entries, explicit raw gyro2, NIS rejection; captured command/compiler/source/artifact hashes | Actual backend/receive admission/health/recovery/logging parity and KF6 full-state parity; firmware owner is preparing actual backend traces. A C numerical core PASS cannot substitute for those checks |
| `test_fusion_current_project_audit.py` | Optional integer mode only in KF6/ESKF15; rejects 2/bool/string; recorded legacy absence preserved; recorded override rejection; captured historical schema hashes; project round-trip selected mode/absence without raw-log changes | New v2 actual Recorded run and cross-mode What-if full numerical run; run/export channels show recorded and selected mode plus source/application/execution provenance; exact availability remains gated by evidence |

The drafts use production classes. There is no fake current implementation or
Python-to-Python duplicate engine presented as a native oracle. The numerical
reference calls existing independently exercised update kernels directly. Test
inputs are synthetic, not flown logs or new frozen golden fixtures.

## Activation sequence and review boundary

1. Root commits its boundary/barometer batch and releases existing product files.
   Re-hash the approved paths; report changes from `write_plan.json` before edits.
2. Consume the root wire contract and actual firmware trace/harness interface.
   Finalize the current executor return/audit API and duplicate-transition rules.
3. Implement strict versions/actual parameters/layouts and history-free executors;
   preserve old record interpretation and the legacy untrusted-zero-delay epoch.
4. Integrate the existing KF6 operation driver and ESKF BODY/observation loop. New
   current processing uses actual arrival/operation order, not source-time sort.
   Preserve ordinary validity, NIS, duplicate, age, health and fault paths.
5. Add independent run audit and time channels. Root owns UI and contracts. Do
   not relabel current as exact before its full applicable evidence is complete.
6. Run these bounded new tests, focused existing affected tests and coordinated
   actual backend traces. Root owns broader suite deduplication. Record all
   failures/skips and separate baseline failures from new failures. Run new C
   sources only after source hashes and compiler configuration are captured.

`schema_before.json` captures current accepted schema identities and synthetic
offline values before activation. It is local review evidence, not an additional
contract or a source fixture to edit to obtain a pass.

## Evidence status

Only syntax/collection checks may run during this preparation batch. Missing
current APIs and not-yet-added parameters are new-interface failures, not legacy
regressions. No current algorithm implementation, complete numerical closure,
RAM saving, hardware timing, accuracy or flight qualification is claimed.
Formal evidence remains under this task directory with SHA256 and owner inventory.
No cleanup is authorized.
