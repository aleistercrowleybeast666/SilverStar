# FLP current timing implementation — 2026-10-15

Owner: `/root/fusion_current_mode`. Product boundary: 15 FLP files in
`write_plan.json`, four new test modules, the existing timing-contract test and
the narrowly approved actual-parameter schema expectation. Root owns GUI and
shared contracts; firmware and numerical C kernels belong to other owners.
No Git mutation, hardware operation, source-log mutation or cleanup was performed.

## Implemented boundary

- Exact KF6 0.3.0 / ESKF15 0.2.0 declarations bind actual integer
  `fusion_timing_mode` (0 current, 1 legacy; default 1), component version,
  immutable v2 wire definitions and recorded mode. Unknown declarations remain
  unavailable for numerical execution. SF6 and PureINS gain no parameter.
- Current executes independent present-state transactions. No IMU history,
  checkpoint rewind or observation replay is used. Producer watermarks are
  bounded separately from numerical history; source/application/evaluation
  epochs and execution/NIS results remain distinct. This is not a whole-firmware
  RAM saving, timing, navigation accuracy or flight-qualification claim.
- Current admission validates source and receive ages, mission/calibration,
  serial sequence rollover and A→B→A producer history. ESKF requires complete,
  correctly ordered four-group GNSS packets. Rejected admissions do not gain
  fabricated application epochs. Numeric faults preserve full pre-operation
  state/P and latch failure; subsequent successful state publication stops.
- ESKF current uses the latest successful raw/calibrated second-half gyro and
  subtracts the then-current residual bias for each group. KF6 current retains
  packet receipt once and position→velocity→barometer operation order.
- V2 Recorded uses logged mask/R and marks quality input `recorded_v2`.
  GNSS quality evidence requires unique source/sample/receive/producer sequence;
  missing evidence invalidates the corresponding health reconstruction instead
  of inventing a healthy result. V1 numerical behavior is retained.
- What-if preserves recorded mode and timing alongside selected mode. Proven
  v2 legacy packages can select current; v1 cannot invent missing source or
  calibration identity. New noise/quality-policy changes lacking a complete
  input provenance are rejected before numerical work. Barometer logical producer
  sequence is not interpreted as a native physical-instance sequence. Unsupported
  noise changes use explicit `fusion_timing_v2_*_recompute_unavailable` or
  `parameter_dynamic_uncertainty_missing:BARO_NATIVE_logical_producer_identity`.
  Unchanged noise parameters preserve logged R. Process noise, NIS, initialization
  and delay parameters continue through their actual supported execution paths.
- Production opening still goes through exact `.ssdecoder` + Descriptor in
  `LogOpenCoordinator`; cold and cache paths validate v2 evidence. Honest
  INVALID/STALE/etc. diagnostic records remain viewable. Current results remain
  `APPROXIMATE`; no exact replay claim is added.

## Validation and retained failures

Complete command receipts and output remain under this directory; no selected
passes are presented as a full-suite result.

- `run08`: 228 passed, including diagnostic actual ESKF backend trace. The
  producer had **two failures**, so this trace is diagnosis, not acceptance.
- `backend_probe01/result.json`: exact production open plus independent current
  execution matched state/quaternion/bias/full covariance and all 99 operation
  source/application/execution/producer identities. Maximum full-P discrepancy
  was 3.381e-7. Original log and decoder SHA256 remained unchanged.
- `run10`: 191 passed / 2 failed. Both failures were in new tests whose synthetic
  metadata omitted quality revision 3. The product's legacy parameter filter was
  preserved; fixture metadata was corrected. `run11`: all 41 then-current project
  audit tests passed, including explicit barometer noise rejection.
- `run12`: invocation error, nonexistent barometer test filename; zero tests ran.
  `run13`: 110 passed / 2 failed. Existing barometer-time tests all passed; the
  two new tests expected a later rejection reason, while the existing parameter
  validator correctly rejected earlier. Removed redundant new guards and used
  the existing precise reason. `run14`: 47 project audit tests passed.
- `predict_fault_before01`: four newly added ESKF current prediction fault tests
  failed because the executor raised without latching. `predict_fault_after01`:
  all 37 current-state tests passed after adding transactional failure latching.
- `run04`: 206 passed / six pre-existing `kf6_algorithm_revision_missing`
  failures. Root independently established those baseline failures. Frozen
  fixtures and their rejection expectations were not modified.
- `run15`: **260 passed / 1 deselected, 14.31 s**, targeted current-state/wire/
  project/legacy regression and actual C numerical-core O0/O2 run. The
  final actual-backend test is explicitly excluded pending a producer-success
  trace. C kernel-only parity does not prove backend/health/logging parity.

## Remaining evidence boundary

Final scoped backend evidence is now complete:

- `run16`: 102 passed. Numerical admission requires continuous uint32 operation
  sequence across complete GNSS packets and barometer operations in an epoch;
  same-present duplicate/reordered/gapped packets reject. Actual plugin execution
  preserves the full `FFFFFFFF → 0` packet boundary. Raw gap records stay readable.
- `backend_final01`: retained failed trace02 comparison. The producer appended
  independent 12/13-second optional-initialization tests after the main mission;
  FLP correctly stopped at the BODY gap. The source log was not trimmed.
- `backend_final02`: **1 passed**, new single-mission ESKF trace03; real producer
  compile/run 0, 2166 checks / 0 failures. Exact production open and independent
  current execution matched full state/P and all **107 operations**. Source
  hash `cc48a6e3a9d598dc063529081fdea82a6f1f97022b3e8346aeba327705477e48`.
- `kf_backend01`: **1 passed**, actual KF6 pipeline trace04 vs independent current
  adapter. `kf_backend02`: **1 passed**, additionally the owning `Faithful_Run`
  operation driver matched all **200 state/P snapshots**, with zero execution
  mismatches. Real producer compile/run 0, 638 checks / 0 failures; **297 wire
  records**, **47 measurement packets**, all wire CRCs and exact decoder catalog
  validated. Source hash
  `eb0d125564f75a38d6e3ebea07350fa829d7c4ea6f82ea85007ffda5bb9f04ea`.
  The trace uses actual estimator_task/receive/update/LoggerBus/serializer with
  fixture sensor, clock and activation. Its input-to-INERTIAL_INCREMENT identity
  adapter is test-only and explicitly is not a production log-open fallback or
  evidence of a complete mission initialization/log file.

Root owns broader suite integration after this source freeze; its previous full
suite encountered a baseline save-dialog hang. There has been no fresh full-suite
PASS, no hardware validation and no broad exact/flight qualification claim.

The backend trace test consumes paths from `SILVERSTAR_CURRENT_ESKF_TRACE` and
`SILVERSTAR_CURRENT_ESKF_DECODER`, checks exact production open and source hashes,
and compares complete numerical state/P plus each recorded operation identity.
KF6 trace integration uses `SILVERSTAR_CURRENT_KF_TRACE` and
`SILVERSTAR_CURRENT_KF_DECODER` with the same immutable source-hash check.

## UI and activation information

Both owning plugins provide an additive optional `ParameterSpec`:
`parameter_id=fusion_timing_mode`, type `int`, default 1, minimum 0, maximum 1,
unit `1`, required false. Root has already connected the two named choices.
Old project schema identities remain accepted; absence is not inserted into
recorded configuration. Delayed predictor mode 2 is rejected.

Wire authority: `contracts/navigation_fusion_timing_records_v2.json`, SHA256
`257f574479bd3fea5cc4564c7afd00504c39f1f66dda6ad793c34e9b7834f5fd`.
GNSS/BARO/ESKF v2 sizes are 212/100/116 bytes. No root contract was edited here.

Status: implemented; targeted regressions and the two scoped actual-backend
comparisons passed. Source freeze: `working_snapshot03.json`. No further product
edits are planned by this owner; root retains integration/commit authority.
