from pathlib import Path
import sys, shutil, hashlib, json, subprocess, datetime
repo = Path.cwd()
out = Path(__file__).resolve().parent
old = repo/'.work/StorageMaintenanceAcceptance_20261008/gates/project/Flight_Controller'
new = out/'project/Flight_Controller'
assert not new.exists()
shutil.copytree(old, new)
owner = repo/'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tools/check_task_stacks.py'
shutil.copy2(owner, new/'Tools/check_task_stacks.py')
sha = lambda b: hashlib.sha256(b).hexdigest()
target = {}
for p in old.rglob('*'):
    if p.is_file() and p.suffix.lower() in ('.c','.h','.s','.ld','.o','.su','.d','.elf','.bin','.map'):
        rel = p.relative_to(old).as_posix()
        assert p.read_bytes() == (new/rel).read_bytes(), rel
        target[rel] = sha(p.read_bytes())
metadata = new/'Generated/Src/project_metadata.c'
assert sha(metadata.read_bytes()) == 'bba3aed1cc73043a10cfd126a7759728a10de53e3769e2563fb209a4b12feadf'
sys.path.insert(0, str(repo/'apps/SCG/src'))
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.project.model import ProjectModel_Load
from silverstar_fccg.generator.source_graph import SourceGraph_Resolve
from silverstar_fccg.generator.render import GeneratedFiles_Render
source = repo/'docs/evidence/logger_health_retest_20261008/generated_config.ssproject'
input_bytes = source.read_bytes()
service = FccgService(repo/'apps/SCG')
model = ProjectModel_Load(source)
files = GeneratedFiles_Render(model, service.catalog, SourceGraph_Resolve(model, service.catalog))
for name, data in files.items():
    assert (new/name).read_bytes().replace(b'\r\n',b'\n') == data.replace(b'\r\n',b'\n'), name
assert source.read_bytes() == input_bytes
assert (new/'Makefile').read_bytes() == (old/'Makefile').read_bytes()
assert (new/'Tools/check_task_stacks.py').read_bytes() == owner.read_bytes()
record = {'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'base_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'old_fixture':str(old), 'new_fixture':str(new), 'input_sha256':sha(input_bytes),
 'checker_sha256':sha(owner.read_bytes()), 'metadata_sha256':sha(metadata.read_bytes()),
 'generated_count':len(files), 'all_rendered_outputs_equal':True,
 'reuse_note':'Verified previous ARM release objects/binary, dependency and stack reports reused. No claim of new C compilation.',
 'target_and_compiled_artifacts':target}
(out/'prepare.json').write_text(json.dumps(record,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in record.items() if k!='target_and_compiled_artifacts'},indent=2))
