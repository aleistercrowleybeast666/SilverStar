from pathlib import Path
import json, subprocess, hashlib, zipfile, datetime
repo=Path.cwd();out=Path(__file__).resolve().parent
delivery=repo/'docs/evidence/scg_metadata_binding_20261008'
delivery.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
paths=['apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tools/check_task_stacks.py',
       'apps/SCG/tools/reference_overlays/check_task_stacks.py',
       'apps/SCG/tests/test_stack_budget.py',
       'docs/SCG_STORAGE_MAINTENANCE_ACCEPTANCE_20261008.md']
snapshot=subprocess.check_output(['git','diff','--binary'])
(out/'dirty_snapshot.patch').write_bytes(snapshot)
prepare=json.loads((out/'prepare.json').read_text())
project=out/'project/Flight_Controller'
for name,digest in prepare['target_and_compiled_artifacts'].items():
    assert sha((project/name).read_bytes())==digest,name
versions={}
for name,cmd in {
 'python':['apps/FLP/.venv/Scripts/python.exe','--version'],
 'make':['D:/msys64/ucrt64/bin/mingw32-make.exe','--version'],
 'arm_gcc':['D:/Arm GNU Toolchain/14.3 rel1/bin/arm-none-eabi-gcc.exe','--version'],
 'host_gcc':['D:/msys64/ucrt64/bin/gcc.exe','--version']}.items():
    versions[name]=subprocess.check_output(cmd,text=True).strip()
commands={
 'pre_test':{'args':['apps/SCG/tests/test_stack_budget.py','-k','product_metadata_binding','-q','--basetemp=apps/SCG/.work/mb_pre','--tb=short'],'exit_code':1,'result':'2 failed, 16 deselected'},
 'owner_test':{'args':['apps/SCG/tests/test_stack_budget.py','-q','--basetemp=apps/SCG/.work/mb_post','--tb=short'],'exit_code':0,'result':'18 passed'},
 'overlay_test':{'args':['apps/SCG/tests/test_stack_budget.py','-q','--basetemp=apps/SCG/.work/mb_overlay','--tb=short'],'exit_code':0,'result':'18 passed','SILVERSTAR_STACK_CHECKER_SOURCE':str(repo/paths[1])},
 'stack':{'command':['D:/msys64/ucrt64/bin/mingw32-make.exe','-j2','stack-report','GCC_PATH=D:/Arm GNU Toolchain/14.3 rel1/bin'],'cwd':str(project),'exit_code':int((out/'stack.exit.txt').read_text().strip()),'result':'FAIL unknown Generated/Src/project_log_decoder_profile.c'},
 'affected_gates':{'command':['D:/msys64/ucrt64/bin/mingw32-make.exe','-j2','architecture-check','power10-check','artifact-check','GCC_PATH=D:/Arm GNU Toolchain/14.3 rel1/bin'],'cwd':str(project),'exit_code':int((out/'affected_gates.exit.txt').read_text().strip()),'result':'PASS text/artifact checks; critical-contract review NOT PROVEN'},
}
for k in ['pre_test','owner_test','overlay_test']:
    commands[k].update(command_prefix=['apps/FLP/.venv/Scripts/python.exe','-B','.work/gui012_20261008/run_pytest.py'],cwd=str(repo),QT_QPA_PLATFORM='offscreen',PYTHONDONTWRITEBYTECODE='1')
files=[p for p in out.iterdir() if p.is_file()]
files += [repo/p for p in paths]
files += [repo/'.work/gui012_20261008/run_pytest.py',
 repo/'docs/evidence/nightly_software_20261008/normal_test_paths.py',
 repo/'docs/evidence/nightly_software_20261008/closeout_test_paths.py',
 repo/'docs/evidence/logger_health_retest_20261008/generated_config.ssproject',
 repo/'.work/StorageMaintenanceAcceptance_20261008/metadata_identity_probe.json',
 repo/'.work/StorageMaintenanceAcceptance_20261008/gates/stack.log',
 repo/'.work/StorageMaintenanceAcceptance_20261008/gates/stack_result.json',
 repo/'docs/evidence/scg_storage_maintenance_20261008/manifest.json']
files += [project/'Makefile',project/'Tools/check_task_stacks.py',
 project/'Tools/check_power_of_ten.ps1',project/'Generated/Src/project_metadata.c',
 project/'Generated/Src/project_log_decoder_profile.c',
 repo/'.work/finalized_health_20261008_v2/project/Flight_Controller/Generated/Src/project_metadata.c',
 repo/'.work/finalized_health_20261008_v2/project/Flight_Controller/Generated/Src/project_log_decoder_profile.c']
members={}
with zipfile.ZipFile(delivery/'evidence.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for path in files:
        name=path.relative_to(repo).as_posix();data=path.read_bytes()
        assert name not in members
        z.writestr(name,data);members[name]=sha(data)
record={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'base_head':prepare['base_head'],'source_sha256':{p:sha((repo/p).read_bytes()) for p in paths},
 'dirty_snapshot_sha256':sha(snapshot),'user_authorization':'Only Generated/Src/project_metadata.c exact hash bba3aed1cc73043a10cfd126a7759728a10de53e3769e2563fb209a4b12feadf.',
 'registration':'Owning payload and overlay only; no other hash, threshold or exception changed.',
 'commands':commands,'tools':versions,'prepare':prepare,'decoder_probe':json.loads((out/'decoder_probe.json').read_text()),
 'binary_sha256':{n:d for n,d in prepare['target_and_compiled_artifacts'].items() if n.endswith('.bin')},
 'critical_contract_review':'NOT_PROVEN manual_acceptance_pending, original text checker output preserved',
 'remaining_blocker':'project_log_decoder_profile.c unknown complete source; not authorized or registered',
 'compile_reuse':'Verified ARM target source/compiled cache from prior actual release compile reused. No fresh C compilation/Host/analyzer claim.',
 'hardware':'NOT RUN','user_project':'Not touched','push':'Not performed',
 'archive_sha256':sha((delivery/'evidence.zip').read_bytes()),'members':members}
(delivery/'manifest.json').write_text(json.dumps(record,indent=2),encoding='utf8')
with zipfile.ZipFile(delivery/'evidence.zip') as z:
    assert z.testzip() is None
    assert set(z.namelist())==set(members)
    for name,digest in members.items():assert sha(z.read(name))==digest
print(json.dumps({'archive_sha256':record['archive_sha256'],'members':len(members),'sources':record['source_sha256'],'stack_exit':commands['stack']['exit_code'],'gates_exit':commands['affected_gates']['exit_code']},indent=2))
