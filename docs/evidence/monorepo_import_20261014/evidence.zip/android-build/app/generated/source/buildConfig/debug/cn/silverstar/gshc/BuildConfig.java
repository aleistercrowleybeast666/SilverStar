/**
 * Automatically generated file. DO NOT MODIFY
 */
package cn.silverstar.gshc;

public final class BuildConfig {
  public static final boolean DEBUG = Boolean.parseBoolean("true");
  public static final String APPLICATION_ID = "cn.silverstar.gshc";
  public static final String BUILD_TYPE = "debug";
  public static final int VERSION_CODE = 1;
  public static final String VERSION_NAME = "0.1.3-dev.1";
  // Field from build type: debug
  public static final boolean ALLOW_USB = false;
}
