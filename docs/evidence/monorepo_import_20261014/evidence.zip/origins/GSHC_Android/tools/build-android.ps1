param([string[]]$BuildTasks = @(':app:assembleDebug', ':app:lintDebug', ':app:testDebugUnitTest'))
$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path -LiteralPath (Split-Path -Parent $PSScriptRoot)).Path
$sdkRoot = Join-Path $projectRoot 'build/toolchain/android-sdk'
$gradleExe = Join-Path $projectRoot 'build/toolchain/gradle-8.13/bin/gradle.bat'
if (-not (Test-Path -LiteralPath (Join-Path $sdkRoot 'platforms/android-36/android.jar'))) { throw 'Android SDK36 is absent. Install only the previously authorized components described in docs/SDK_SETUP.md.' }
if (-not (Test-Path -LiteralPath $gradleExe)) { throw 'Verified Gradle8.13 installation is absent.' }
$env:JAVA_HOME = 'C:\Program Files\Microsoft\jdk-21.0.12.101-hotspot'
$env:ANDROID_HOME = $sdkRoot
$env:ANDROID_USER_HOME = Join-Path $projectRoot 'build/android-user'
$env:GRADLE_USER_HOME = Join-Path $projectRoot 'build/gradle-user'
$env:TEMP = Join-Path $projectRoot 'build/temp'
$env:TMP = $env:TEMP
foreach ($directory in @($env:ANDROID_USER_HOME, $env:GRADLE_USER_HOME, $env:TEMP)) { New-Item -ItemType Directory -Path $directory -Force | Out-Null }
[System.IO.File]::WriteAllText((Join-Path $projectRoot 'local.properties'), ('sdk.dir=' + $sdkRoot.Replace('\','/') + [Environment]::NewLine), [System.Text.UTF8Encoding]::new($false))
Push-Location -LiteralPath $projectRoot
try {
    & $gradleExe --no-daemon --console=plain --continue '-Pandroid.builder.sdkDownload=false' @BuildTasks
    if ($LASTEXITCODE -ne 0) { throw "Android build failed with exit $LASTEXITCODE" }
} finally { Pop-Location }
