"""Archive this subtask's small evidence only; never copy generated trees/SDKs."""
from pathlib import Path
import datetime
import hashlib
import json
import re
import subprocess
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
report_path = OUT / "REPORT.md"
report = report_path.read_text(encoding="utf-8")
report = report.replace(
    "4. Final complete test/benchmark fixture: `post_test03.log`, 18 passed, 36.28 s.",
    "4. Expanded full-call benchmark fixture: `post_test03.log`, 18 passed, 36.28 s.\n"
    "5. Final suite: `post_test04.log`, **21 passed**, 60.92 s, no skips/failures.\n"
    "   The additional case compiles baseline and current INS with\n"
    "   `SYSTEM_MECHANIZATION_SUBSAMPLE_COUNT=1` and runs another 100,000 INS\n"
    "   calls per compiler configuration. Regular cases cover two-sample INS.")
report = report.replace(
    "hashes are under each test run directory. `lint.log` reports the focused Python\n"
    "F-rule check passing; scoped `git diff --check` also passed.",
    "hashes are under each test run directory. Final source/header/test copies\n"
    "are in `final_source_inputs/` (26 files) and `final_source_inputs_manifest.json`.\n"
    "Every copy was verified against its current source hash. `final_checks.json`\n"
    "records final Python F-rule lint and scoped `git diff --check`, both exit 0;\n"
    "Git's LF-to-CRLF informational warning is retained.")
timing_addendum = """
The final suite repeated these workloads; all five samples are retained in
`post_test04/*/run_benchmark.json` and `host_benchmark_post04_summary.json`:

| Final-suite Host GCC mode | ESKF 10k median before/after | INS 1M median before/after |
|---|---:|---:|
| O0, contraction off | 0.525 / 0.355 s | 0.538 / 0.465 s |
| O2, contraction off | 0.079 / 0.058 s | 0.211 / 0.184 s |
| O2, default contraction | 0.062 / 0.047 s | 0.124 / 0.127 s |

Concurrent system load was not controlled. The large between-run variation and
all slower samples are retained. These numbers must not be selected selectively
or treated as MCU/WCET evidence. The reset-only number below is from post03.

"""
report = report.replace("ESKF reset-only O2 sample:", timing_addendum + "ESKF reset-only O2 sample:")
report = re.sub(
    r"Individual compiler frame reports:.*?library, dynamic-frame, MSP or interrupt stack bounds\.",
    "Individual compiler frame reports: `InsInertial_Update` 248 to 280 bytes, while\n"
    "its old call to the 112-byte standalone sculling function is removed; ESKF\n"
    "Update 240 to 248 bytes, Predict 336 to 336. These local frames do not establish\n"
    "full task, library, dynamic-frame, MSP or interrupt stack bounds.",
    report, flags=re.DOTALL)
fresh = """Both fresh runs completed. Complete streams are in `*_full_run.log`, commands,
UTC and exits in per-action JSON/logs, and summaries in `kf6_summary.json` and
`eskf15_summary.json`. Both wrappers exited 1 because `stack-report` failed.
This is not a full-green gate result.

| Exact emitted action | KF6 legacy | ESKF15 auto |
|---|---:|---:|
| Release ARM compile/link and HEX/BIN | 0 | 0 |
| architecture-check/source graph | 0 | 0 |
| power10-check | 0 | 0 |
| static-analysis: analyzer compilation and link | 0 | 0 |
| host-tests | 0 | 0 |
| artifact-check | 0 | 0 |
| stack-report | **2 (FAIL)** | **2 (FAIL)** |
| memory-report (alias of artifact-check) | 0 | 0 |

Each actual static-analysis build compiled 110 first-party analyzer objects and
48 dependency objects, then linked and produced HEX/BIN. No syntax-only
substitution was used. Toolchains: Host GCC 16.1.0, ARM GNU 14.3 rel1 (GCC 14.3.1),
repository Python 3.14. Logs retain versions and exact flags. Emitted Power10,
architecture, artifact and stack checkers are unchanged relative to the prior
projects (`emitted_gate_identity.json`).

| Host runner result | KF6 | ESKF15 |
|---|---:|---:|
| Executables | 80 | 78 |
| Checks | 4,446,532 | 4,408,184 |
| Failures | 0 | 0 |
| Compile-pass cases | 11 | 11 |
| Expected compile-failure cases | 18 | 18 |
| Runner-level not-applicable cases | 8 | 9 |

`*_not_applicable_details.json` retains distinct raw messages and occurrence
counts, including repeated inline unsupported-stream/storage-profile cases
beyond the runner-level count. Complete reasons and expected negative compile
diagnostics remain in `*_host_tests.log`. These synthetic Host fixtures do not
validate hardware.

Power10 reports 6,447 checks / 113 first-party C files / 2,813 functions /
847 recommendations for KF6 and 6,301 / 113 / 2,740 / 827 for ESKF15. Both
explicitly report **critical-contract review NOT PROVEN**, manual acceptance
pending. Exit 0 does not supersede this status.

Linked Release section/file sizes, bytes:

| Profile | text | data | bss | BIN file |
|---|---:|---:|---:|---:|
| KF6 | 341,804 | 1,140 | 159,928 | 342,956 |
| ESKF15 | 327,756 | 1,140 | 166,632 | 328,908 |

ESKF15 auto layout reports RAM occupied/spare 117,568/13,504 bytes (yellow),
CCM occupied/spare 50,208/15,328 (green). These spare bytes do not prove stack
margin. Both artifact checks find no heap symbols and diagnostics are bound.
Release and StaticAnalysis ELF/MAP/BIN/HEX/SSDIAG/SU hashes are in
`*_final_artifacts.json`; no old build objects/binaries were reused.

Release artifact directories:

- `generated_kf601/build/FCCG/SilverStar_F407/Release/`
- `generated_eskf1501/build/FCCG/SilverStar_F407/Release/auto/`

### Stack failure and diagnostic limits

Both exact emitted `stack-report` commands fail in `BindingHeader_Verify`:

```
ValueError: Changed or missing reviewed callback compilation input:
Generated/Inc/project_algorithm_parameters.h
```

Prior NIS and fresh navperf headers are byte-identical within each profile:

- KF6 SHA-256: `2bbc37593fe83cfca827f212028169c7faee1bebe8cd8aec016ba96ffb0f54bc`
- ESKF15 SHA-256: `2bef83bce27abfbd53ac91e308e378994c2c6141dd09b95a884f6ed1828db68c`

The emitted stack checker is also unchanged. Its unchanged `BindingHeader_Verify`
was invoked read-only and rejects all four prior/fresh inputs identically.
`stack_preexisting_input_failure.json` records hashes, reviewed versions and
errors. This establishes an existing reviewed-input mismatch, not one introduced
by these performance edits. This diagnosis is **not a full prior-project stack
run**. No allowlist, checker or threshold was changed to bypass the failure.

Both fresh full reports stopped at this error; later checks did not complete.
Task/library/callback/dynamic-frame/main/MSP/ISR bounds remain unproven. Review
the exact header and provenance before any separately authorized binding repair
and rerun. This report does not claim it is the only remaining stack issue.

### Retained evidence and archival scope

`archive_inventory.json` enumerates every archived small file with size and
SHA-256, purpose/owner and cleanup authorization false. The evidence ZIP contains
source snapshots, pinned baseline sources, fixed configuration, scripts, scoped
patch, logs, JSON and individual SU files. It excludes entire generated project
trees, SDK/toolchain/runtime copies, objects and executable/firmware binaries.
Actual generated artifacts remain at the local paths above and their hashes
remain archived. `archive_receipt.json` records the ZIP hash and size.

"""
start = report.index("Fresh validation is IN PROGRESS")
end = report.index("## Limits and remaining work", start)
report = report[:start] + fresh + report[end:]
report_path.write_text(report, encoding="utf-8")

utc = datetime.datetime.now(datetime.timezone.utc).isoformat()
source_manifest = json.loads((OUT / "final_source_inputs_manifest.json").read_text(encoding="utf-8"))
for rel, expected in source_manifest["files"].items():
    assert hashlib.sha256((ROOT / rel).read_bytes()).hexdigest() == expected, rel
    assert hashlib.sha256((OUT / "final_source_inputs" / rel).read_bytes()).hexdigest() == expected, rel
completion = {
    "owner": "navigation_performance", "utc": utc,
    "baseline_commit": "57b78fbb56d64eb09a76c8b7e961aa4027a6eb70",
    "head_at_handoff": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
    "status": "DIFFERENTIAL_PASS; FRESH_STACK_FAIL; CRITICAL_CONTRACT_NOT_PROVEN",
    "differential": {"passed": 21, "failed": 0, "skipped": 0, "log": "post_test04.log"},
    "fresh_summary_paths": ["kf6_summary.json", "eskf15_summary.json"],
    "stack_blocker": "Unchanged emitted BindingHeader_Verify rejects the same prior/fresh generated parameter header hashes; later stack checks not completed.",
    "source_manifest": "final_source_inputs_manifest.json",
    "changed_product_files": [p for p in source_manifest["files"] if p.endswith(("Src\\ins_mechanization.c", "Src\\navigation_eskf.c"))],
    "kf6_product_modified": False,
    "commit_performed": False, "hardware_performed": False,
    "publication_performed": False, "cleanup_authorized": False,
}
(OUT / "completion.json").write_text(json.dumps(completion, indent=2), encoding="utf-8")
allowed_suffixes = {".json", ".log", ".md", ".py", ".patch", ".h", ".c", ".su"}
excluded_roots = {"generated_kf601", "generated_eskf1501"}
files = []
for path in sorted(OUT.rglob("*")):
    rel = path.relative_to(OUT)
    if not path.is_file() or rel.parts[0] in excluded_roots:
        continue
    if path.name in {"archive_inventory.json", "archive_receipt.json"} or path.suffix not in allowed_suffixes:
        continue
    files.append(path)
inventory = {
    "owner": "navigation_performance", "utc": utc,
    "purpose": "retained local performance differential, fresh validation and failed stack evidence",
    "cleanup_authorized": False,
    "excluded": "generated project trees, SDK/toolchains/runtimes, objects, executables and firmware binaries; artifact hashes retained",
    "files": [{"path": p.relative_to(OUT).as_posix(), "bytes": p.stat().st_size,
               "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in files],
}
inventory_path = OUT / "archive_inventory.json"
inventory_path.write_text(json.dumps(inventory, indent=2), encoding="utf-8")
archive = OUT / "navigation_performance_evidence_20261015.zip"
assert not archive.exists(), "Do not overwrite a retained evidence archive"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as package:
    for path in files + [inventory_path]:
        package.write(path, path.relative_to(OUT).as_posix())
with zipfile.ZipFile(archive) as package:
    assert package.testzip() is None
    for record in inventory["files"]:
        content = package.read(record["path"])
        assert len(content) == record["bytes"]
        assert hashlib.sha256(content).hexdigest() == record["sha256"]
receipt = {"path": str(archive), "bytes": archive.stat().st_size,
           "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
           "archived_entries": len(files) + 1,
           "verification": "CRC and each inventory entry size/SHA256 verified",
           "cleanup_authorized": False}
(OUT / "archive_receipt.json").write_text(json.dumps(receipt, indent=2), encoding="utf-8")
print(json.dumps({"completion": completion, "archive": receipt}, indent=2))
