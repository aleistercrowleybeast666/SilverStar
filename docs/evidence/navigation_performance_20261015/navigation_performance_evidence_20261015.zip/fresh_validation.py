"""Task-owned fresh projects; reuse only prior configuration, no old outputs."""
from pathlib import Path
import dataclasses
import datetime
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "apps/SCG/src"))
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.build.runner import BuildRunner, BuildAction
from silverstar_fccg.core.workspace import WorkspacePolicy

kind = sys.argv[1]
assert kind in ("kf6", "eskf15")
source = ROOT / ".work/dev013_nis01" / ("generated_kf602" if kind == "kf6" else "generated_eskf1503")
project = OUT / ("generated_" + kind + "01")
assert not project.exists()
service = FccgService(ROOT / "apps/SCG")
model = service.Project_Open(source / "SilverStar.ssproject")
service.Project_Save(model, project, confirm_dangerous=True)
snapshot = {
    "owner": "navigation_performance", "purpose": "fresh emitted validation project",
    "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
    "configuration_source": str(source / "SilverStar.ssproject"),
    "configuration": model.Dictionary_Get(),
    "files": {str(p.relative_to(project)): hashlib.sha256(p.read_bytes()).hexdigest()
              for p in project.rglob("*") if p.is_file()},
}
(OUT / (kind + "_generated_snapshot.json")).write_text(json.dumps(snapshot, indent=2), encoding="utf-8")
runner = BuildRunner(WorkspacePolicy(project))
records = []
build_command = None
for action in (BuildAction.BUILD, BuildAction.ARCHITECTURE_CHECK, BuildAction.POWER10_CHECK,
               BuildAction.STATIC_ANALYSIS, BuildAction.HOST_TESTS, BuildAction.ARTIFACT_CHECK):
    print("BEGIN", kind, action, flush=True)
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = runner.Run(model, project, action, line_callback=lambda line: print(line, flush=True))
    record = dataclasses.asdict(result)
    record.pop("output", None)
    record.update(started_utc=started, finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    (OUT / (kind + "_" + action.value + ".json")).write_text(json.dumps(record, indent=2), encoding="utf-8")
    (OUT / (kind + "_" + action.value + ".log")).write_text(result.output, encoding="utf-8")
    records.append(record)
    if action == BuildAction.BUILD:
        build_command = list(result.command)
    print("END", kind, action, result.return_code, flush=True)
assert build_command and build_command[-1] == "all"
for target in ("stack-report", "memory-report"):
    command = build_command[:-1] + [target]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = subprocess.run(command, cwd=project, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=180)
    record = {"action": target, "command": command, "cwd": str(project),
              "return_code": result.returncode, "started_utc": started,
              "finished_utc": datetime.datetime.now(datetime.timezone.utc).isoformat()}
    (OUT / (kind + "_" + target + ".json")).write_text(json.dumps(record, indent=2), encoding="utf-8")
    (OUT / (kind + "_" + target + ".log")).write_text(result.stdout + result.stderr, encoding="utf-8")
    records.append(record)
    print("END", kind, target, result.returncode, flush=True)
artifacts = {}
for p in (project / "build").rglob("*"):
    if p.is_file() and p.suffix in (".elf", ".map", ".bin", ".hex", ".ssdiag", ".su"):
        artifacts[str(p.relative_to(project))] = hashlib.sha256(p.read_bytes()).hexdigest()
(OUT / (kind + "_final_artifacts.json")).write_text(json.dumps(artifacts, indent=2), encoding="utf-8")
(OUT / (kind + "_summary.json")).write_text(json.dumps({
    "records": records, "critical_contract_review": "NOT PROVEN",
    "hardware": "NOT RUN", "linked_stack_proof": "See full emitted reports; not inferred from tool exit",
}, indent=2), encoding="utf-8")
raise SystemExit(0 if all(r["return_code"] == 0 for r in records) else 1)
