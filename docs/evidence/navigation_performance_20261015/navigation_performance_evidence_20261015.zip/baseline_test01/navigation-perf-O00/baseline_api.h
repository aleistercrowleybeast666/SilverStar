void Baseline_InsInertial_Reset(InsInertialContext *context);
InsInertialUpdateResult Baseline_InsInertial_Update(InsInertialContext *context,
    const InsAlgorithmSample *sample, InsState *increment);
void Baseline_InsMechanization_Init(InsMechanizationContext *context,
                           float gravity_mps2);
void Baseline_InsMechanization_ResetNavigation(InsMechanizationContext *context);
uint8_t Baseline_InsMechanization_ResetNavigationWithAttitude(
    InsMechanizationContext *context,
    const float initial_q_nb[4]);
void Baseline_Ins_ComputeSubIntervalIncrement(const InsAlgorithmSample *previous,
                                     const InsAlgorithmSample *current,
                                     float delta_theta_b[3],
                                     float delta_velocity_b[3],
                                     float *dt_s);
void Baseline_Ins_ComputeSecondOrderConing(const float delta_theta_1[3],
                                  const float delta_theta_2[3],
                                  float corrected[3]);
void Baseline_Ins_ComputeSecondOrderSculling(const float delta_theta_1[3],
                                    const float delta_velocity_1[3],
                                    const float delta_theta_2[3],
                                    const float delta_velocity_2[3],
                                    float delta_velocity_corrected_b[3]);
void Baseline_Ins_TransformDeltaVelocityToNavigation(const float q_nb_start[4],
                                             const float delta_velocity_b[3],
                                             float total_dt_s,
                                             float gravity_mps2,
                                             float delta_velocity_n[3]);
void Baseline_Ins_IntegrateVelocity(const float previous_velocity_n[3],
                           const float delta_velocity_n[3],
                           float current_velocity_n[3]);
void Baseline_Ins_IntegratePositionTrapezoidal(const float previous_position_n[3],
                                      const float previous_velocity_n[3],
                                      const float current_velocity_n[3],
                                      float dt_s,
                                      float current_position_n[3]);
uint8_t Baseline_InsMechanization_Update(InsMechanizationContext *context,
                                const InsAlgorithmSample *sample,
                                InsState *state);
NavigationEskfResult Baseline_NavigationEskf_Initialize(
    NavigationEskfState *state, NavigationEskfWorkspace *workspace,
    const float nominal[16], const float covariance[NAV_ESKF_DIM][NAV_ESKF_DIM],
    uint64_t timestamp_us, uint32_t source, uint32_t generation);
NavigationEskfResult Baseline_NavigationEskf_Predict(
    NavigationEskfState *state, NavigationEskfWorkspace *workspace,
    const NavigationEskfConfig *config, const NavigationEskfBodyInput *input);
NavigationEskfResult Baseline_NavigationEskf_Update(
    NavigationEskfState *state, NavigationEskfWorkspace *workspace,
    const NavigationEskfConfig *config, const NavigationEskfMeasurement *measurement,
    NavigationEskfOutcome *outcome);
NavigationEskfResult Baseline_NavigationEskf_ConfigValidate(const NavigationEskfConfig *config);
NavigationKfUpdateResult Baseline_NavigationKf_UpdateGnssPositionGroups(
    NavigationKfContext *context, const float position_enu_m[3],
    const float variance_m2[3], uint8_t valid_group_mask,
    NavigationKfGnssSeparatedUpdateResult *result);
NavigationKfUpdateResult Baseline_NavigationKf_UpdateGnssVelocityGroups(
    NavigationKfContext *context, const float velocity_enu_mps[3],
    const float variance_m2ps2[3], uint8_t valid_group_mask,
    NavigationKfGnssSeparatedUpdateResult *result);
void Baseline_NavigationKf_Init(NavigationKfContext *context);
void Baseline_NavigationKf_Reset(NavigationKfContext *context);
uint8_t Baseline_NavigationKf_ResetWithCovariance(
    NavigationKfContext *context,
    const float *covariance);
uint8_t Baseline_NavigationKf_Predict(NavigationKfContext *context,
                             const float delta_velocity_enu_mps[3],
                             float dt_s);
NavigationKfPredictResult Baseline_NavigationKf_PredictInterval(
    NavigationKfContext *context, const float delta_velocity_enu_mps[3],
    float fragment_dt_s, float original_dt_s);
NavigationKfUpdateResult Baseline_NavigationKf_UpdateGnssPosition(
    NavigationKfContext *context,
    const float position_enu_m[3],
    const float variance_m2[3]);
NavigationKfUpdateResult Baseline_NavigationKf_UpdateGnssPositionSeparated(
    NavigationKfContext *context,
    const float position_enu_m[3],
    const float variance_m2[3],
    NavigationKfGnssSeparatedUpdateResult *separated_result);
NavigationKfUpdateResult Baseline_NavigationKf_UpdateGnssVelocity2D(
    NavigationKfContext *context,
    const float velocity_enu_mps[2],
    const float variance_m2ps2[2]);
NavigationKfUpdateResult Baseline_NavigationKf_UpdateGnssVelocity3D(
    NavigationKfContext *context,
    const float velocity_enu_mps[3],
    const float variance_m2ps2[3]);
NavigationKfUpdateResult Baseline_NavigationKf_UpdateGnssVelocitySeparated(
    NavigationKfContext *context,
    const float velocity_enu_mps[3],
    const float variance_m2ps2[3],
    uint8_t vertical_valid,
    NavigationKfGnssSeparatedUpdateResult *separated_result);
NavigationKfUpdateResult Baseline_NavigationKf_UpdateBaroAltitude(
    NavigationKfContext *context,
    float altitude_up_m,
    float variance_m2);
void Baseline_NavigationKf_SetProcessAccelStd(NavigationKfContext *context,
                                     const float accel_std_mps2[3]);
void Baseline_NavigationKf_SetBaroStd(NavigationKfContext *context,
                             float altitude_std_m);
void Baseline_NavigationKf_SetNisThresholds(
    NavigationKfContext *context,
    const float soft_threshold[3],
    const float hard_threshold[3],
    float maximum_r_scale);
void Baseline_NavigationKf_GnssEpochTrack(
    NavigationKfContext *context,
    const NavigationKfGnssEpoch *epoch);
NavigationKfUpdateResult Baseline_NavigationKf_GnssGroupRecover(
    NavigationKfContext *context, NavigationKfGnssGroup group,
    NavigationKfUpdateResult result, const float observation[3],
    const float variance[3], uint64_t receive_timestamp_us);
void Baseline_NavigationKf_GnssGroupResultProcess(
    NavigationKfContext *context,
    NavigationKfGnssGroup group,
    NavigationKfUpdateResult result);