from pathlib import Path
import sys, json, hashlib
root=Path(__file__).absolute().parents[2]
sys.path.insert(0,str(root/'apps/SCG/src'))
from silverstar_fccg.app.service import FccgService
out=Path(__file__).absolute().parent
project=out/'project01'
assert not project.exists()
service=FccgService(root/'apps/SCG')
model=service.ReferenceProject_Create('target013e01')
print('target',model.hardware.mcu,model.mcu)
service.Project_Save(model,project,confirm_dangerous=True)
files=[dict(path=p.relative_to(project).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in project.rglob('*') if p.is_file()]
(out/'generated_inventory.json').write_text(json.dumps(dict(owner='root',purpose='Fresh target/ELF generation regression; never flashed',files=files),indent=2))
print('generated',len(files),sum(f['bytes'] for f in files))
