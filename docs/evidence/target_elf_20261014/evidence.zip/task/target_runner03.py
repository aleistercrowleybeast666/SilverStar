from pathlib import Path
import sys, json, hashlib, dataclasses
root=Path(__file__).absolute().parents[2]
sys.path.insert(0,str(root/'apps/SCG/src'))
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.build.runner import BuildRunner,BuildAction
from silverstar_fccg.core.workspace import WorkspacePolicy
out=Path(__file__).absolute().parent
project=out/'project02'
service=FccgService(root/'apps/SCG')
model=service.ReferenceProject_Create('target013e02')
runner=BuildRunner(WorkspacePolicy(project))
result=runner.Target_Run(model,project,line_callback=print)
(out/'target_runner_result03.json').write_text(json.dumps(dataclasses.asdict(result),indent=2))
assert result.succeeded and result.diagnostic_status=='bound', result.diagnostic_detail
print('SCG_BUILD_AND_BIND_OK')
