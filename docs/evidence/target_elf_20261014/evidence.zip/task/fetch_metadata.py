from pathlib import Path
import urllib.request, hashlib, json
out = Path(__file__).parent
records = []
for family in ('F4', 'C0'):
    url = f'https://www.keil.com/pack/Keil.STM32{family}xx_DFP.pdsc'
    request = urllib.request.Request(url, headers={'User-Agent': 'SilverStar metadata audit'})
    with urllib.request.urlopen(request, timeout=30) as response:
        data = response.read(8 * 1024 * 1024 + 1)
        assert len(data) <= 8 * 1024 * 1024
        final = response.url
    path = out / f'STM32{family}.pdsc'
    path.write_bytes(data)
    records.append(dict(url=url, final_url=final, bytes=len(data), sha256=hashlib.sha256(data).hexdigest(), file=path.name))
(out/'metadata_downloads.json').write_text(json.dumps(records, indent=2))
print(json.dumps(records, indent=2))
