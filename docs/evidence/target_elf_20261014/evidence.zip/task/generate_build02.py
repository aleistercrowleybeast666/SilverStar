from pathlib import Path
import sys, json, hashlib, dataclasses
root=Path(__file__).absolute().parents[2]
sys.path.insert(0,str(root/'apps/SCG/src'))
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.build.runner import BuildRunner,BuildAction
from silverstar_fccg.core.workspace import WorkspacePolicy
out=Path(__file__).absolute().parent
project=out/'project02'
assert not project.exists()
service=FccgService(root/'apps/SCG')
model=service.ReferenceProject_Create('target013e02')
service.Project_Save(model,project,confirm_dangerous=True)
files=[dict(path=p.relative_to(project).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in project.rglob('*') if p.is_file()]
(out/'generated_inventory02.json').write_text(json.dumps(dict(owner='root',purpose='Fresh corrected metadata-only build; never flashed',files=files),indent=2))
runner=BuildRunner(WorkspacePolicy(project))
result=runner.Run(model,project,BuildAction.BUILD,line_callback=print)
(out/'build_service02.json').write_text(json.dumps(dataclasses.asdict(result),indent=2))
assert result.succeeded and result.diagnostic_status=='bound', result.diagnostic_detail
print('SCG_BUILD_AND_BIND_OK')
