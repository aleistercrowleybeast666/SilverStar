"""Explicit authorized Horco/F407 read-only bench. No writes to target addresses."""
from dataclasses import asdict
from datetime import datetime,timezone
import hashlib,json,runpy,subprocess,sys,time,traceback
from pathlib import Path
from threading import Event
root=Path(__file__).absolute().parents[2]
task=Path(__file__).absolute().parent/'bench01'
task.mkdir(exist_ok=False)
sys.path.insert(0,str(root/'apps/GSHC'))
from transport.probe_inventory import ProbeInventory_Read,ProbeInventoryResult
from transport.swd_session import SwdSession,SwdResult as R,_ProbeOwners
from transport.swd_firmware import Firmware_Import,DiagnosticResult
from transport import _swd_pyocd as adapter
identity=r'USB\VID_FAED&PID_4870\132765403520'
result={'started':datetime.now(timezone.utc).isoformat(),'sessions':[],'errors':[]}
def default(value):
    if isinstance(value,bytes): return value.hex()
    return value.value
def save():
    (task/'result.json').write_text(json.dumps(result,default=default,ensure_ascii=False,indent=2),encoding='utf-8')
names=['openocd.exe','pyocd.exe','ST-LINK_gdbserver.exe','STM32_Programmer_CLI.exe','STM32CubeProgrammer.exe',
       'JLink.exe','JLinkGDBServer.exe','JLinkGDBServerCL.exe','Ozone.exe','UV4.exe','gdb.exe','arm-none-eabi-gdb.exe']
script='$names=@('+','.join("'"+n+"'" for n in names)+'); @(Get-CimInstance Win32_Process | Where-Object { $names -contains $_.Name } | Select-Object Name,ProcessId) | ConvertTo-Json -Compress'
check=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',script],capture_output=True,text=True,timeout=20)
result['process_check']=dict(exit=check.returncode,stdout=check.stdout,stderr=check.stderr,names=names)
save()
assert check.returncode==0 and check.stdout.strip() in ('','[]','null'), 'Debugger present or inspection failed'
inventory=ProbeInventory_Read(Event());result['inventory']=asdict(inventory);save()
matches=[p for p in inventory.probes if p.identity==identity]
assert inventory.result==ProbeInventoryResult.Ready and len(matches)==1 and matches[0].host_status=='OK'
source=subprocess.check_output(['git','ls-files','-m','-o','--exclude-standard'],cwd=root,text=True).splitlines()
result['sources']={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in source if p.startswith(('apps/','contracts/','tools/'))}
guard=runpy.run_path(str(root/'.work/dev013_swd_pyocd01/bench_readonly.py'),run_name='packet_guard')['check_packet']
packets=(task/'packets.jsonl').open('x',encoding='utf-8');count=0
original=adapter._BulkInterface
def audited(api,device,deadline_guard):
    interface=original(api,device,deadline_guard);write=interface.write;select=0
    def checked(data):
        nonlocal select
        global count
        assert count<50000,'Bounded bench DAP packet budget exceeded'
        select=guard(data,select);count+=1
        packets.write(json.dumps(dict(utc=datetime.now(timezone.utc).isoformat(),allowed=True,tx=bytes(data).hex()))+'\n')
        return write(data)
    interface.write=checked
    return interface
adapter._BulkInterface=audited
try:
    # Preserve the previously verified family identity before choosing a part map.
    session=SwdSession();record={'kind':'identity_preflight'};result['sessions'].append(record)
    try:
        reply=session.Swd_Attach(matches[0]);record['reply']=asdict(reply);save()
        assert reply.result==R.Ok and reply.snapshot.cpuid==0x410FC241 and reply.snapshot.device_id==0x413 and reply.snapshot.revision_id==0x1007
        assert not reply.snapshot.dhcsr & ((1<<17)|3), 'Debug/halt state changed'
    finally:
        record['release']=asdict(session.Swd_Detach());save()
    assert record['release']['result']==R.Ok
    inputs=[('fresh_not_flashed',root/'.work/dev013_target_elf01/project02/build/FCCG/SilverStar_F407/Release/SilverStar_0_1_3.ssdiag'),
            ('legacy_manual_elf',Path('D:/stm32_project/SS_0_5_TEST_FINAL/Flight_Controller/build/FCCG/SilverStar_F407/Release/auto/SilverStar_0_1_2.elf'))]
    for label,path in inputs:
        imported=Firmware_Import([path],target=None if path.suffix=='.ssdiag' else 'STM32F407VET6')
        record={'kind':label,'input':str(path),'input_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                'import':dict(result=imported.result.value,detail=imported.detail)}
        result['sessions'].append(record);save()
        assert imported.result==DiagnosticResult.Ok,imported.detail
        fw=imported.firmware;record['firmware']=fw.descriptor;record['provenance']=fw.provenance
        session=SwdSession(firmware=fw)
        try:
            record['attach']=asdict(session.Swd_Attach(matches[0]));save()
            assert record['attach']['result']==R.Ok
            time.sleep(.11)
            reply=session.Swd_VerifyFirmware();record['verify']=asdict(reply);save()
            if label=='fresh_not_flashed': assert reply.result==R.FirmwareMismatch
            if reply.result==R.Ok:
                time.sleep(.11)
                record['diagnostics']=asdict(session.Swd_Diagnostics());save()
                assert record['diagnostics']['result']==R.Ok
                snapshot=record['diagnostics']['snapshot']
                assert not snapshot['dhcsr'] & ((1<<17)|3) and snapshot['symbols']=='matched'
            else:
                assert reply.result==R.FirmwareMismatch
                record['diagnostic_refusal']=asdict(session.Swd_Diagnostics());save()
                assert record['diagnostic_refusal']['result']==R.FirmwareMismatch
        finally:
            record['release']=asdict(session.Swd_Detach());save()
        assert record['release']['result']==R.Ok
        assert hashlib.sha256(path.read_bytes()).hexdigest()==record['input_sha256']
except Exception:
    result['errors'].append(traceback.format_exc())
finally:
    packets.close()
    result.update(finished=datetime.now(timezone.utc).isoformat(),packets=count,
                  library_released=not adapter._LibraryOwner.locked(),process_owners=len(_ProbeOwners))
    save()
assert not result['errors'] and result['library_released'] and result['process_owners']==0, result['errors']
print(json.dumps(dict(packets=count,sessions=[dict(kind=r['kind'],verify=r.get('verify',{}).get('result'),
                                                   release=r.get('release',{}).get('result')) for r in result['sessions']]),default=default))
