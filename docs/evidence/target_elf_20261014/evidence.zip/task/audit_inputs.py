from pathlib import Path
import hashlib,json,sys,subprocess
from collections import Counter
root=Path(__file__).absolute().parents[2]
task=Path(__file__).absolute().parent
sys.path.insert(0,str(root/'apps/SCG/src'))
from silverstar_diagnostics.elf import Firmware_Load
from silverstar_diagnostics.dependencies import ElfTools_Ensure
ElfTools_Ensure()
from elftools.elf.elffile import ELFFile
paths=[task/'project02/build/FCCG/SilverStar_F407/Release/SilverStar_0_1_3.elf',
 Path('D:/stm32_project/SS_0_5_TEST_FINAL/Flight_Controller/build/FCCG/SilverStar_F407/Release/auto/SilverStar_0_1_2.elf'),
 Path('D:/stm32_project/SS_0_5_TEST_FINAL/Flight_Controller/build/FCCG/SilverStar_F407/EIDE/Release/SS_0_5_TEST_FINAL.elf'),
 root/'.work/bench08c_f407/Flight_Controller/build/FCCG/SilverStar_F407/Release/auto/SilverStar_0_1_1.elf']
result={'purpose':'Offline retained ELF LMA/VMA audit only; no hardware access; no candidate asserted onboard','elfs':[]}
for path in paths:
    row={'path':str(path),'exists':path.is_file()};result['elfs'].append(row)
    if not row['exists']:continue
    data=path.read_bytes();row.update(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
    try:
        fw=Firmware_Load(path,target='STM32F407VET6')
        row.update(load_bytes=sum(len(x) for a,x in fw.segments),load_manifest=fw.descriptor['binding']['segments'],
                   fields_available=sum(not e.unavailable for e in fw.entries),vector_first16=fw.segments[0][1][:16].hex())
        with path.open('rb') as stream:
            elf=ELFFile(stream)
            row['load_headers']=[{k:s[k] for k in ('p_paddr','p_vaddr','p_filesz','p_memsz','p_flags')} for s in elf.iter_segments() if s['p_type']=='PT_LOAD']
            row['sections']={name:{k:s[k] for k in ('sh_addr','sh_type','sh_size')} for name in ('.data','.bss') if (s:=elf.get_section_by_name(name)) is not None}
    except Exception as exc:row['error']=str(exc)
    assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256']
catalog=json.loads((root/'apps/SCG/src/silverstar_diagnostics/stm32_targets.json').read_text())
result['catalog_counts']=dict(Counter(v['source'] for v in catalog['targets'].values()))
result['catalog_sources']=catalog['sources']
result['versions']={}
for name,args in [('python',[sys.executable,'--version']),('arm_gcc',['arm-none-eabi-gcc','--version']),('host_gcc',['D:/msys64/ucrt64/bin/gcc.exe','--version']),('make',['mingw32-make','--version'])]:
    r=subprocess.run(args,capture_output=True,text=True);result['versions'][name]={'exit':r.returncode,'output':r.stdout}
(task/'input_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'catalog':result['catalog_counts'],'elfs':[{k:r.get(k) for k in ('path','exists','sha256','load_bytes','fields_available','error')} for r in result['elfs']]},ensure_ascii=False,indent=2))
