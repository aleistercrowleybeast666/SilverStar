from pathlib import Path
import sys,json,dataclasses
root=Path(__file__).absolute().parents[2]
sys.path.insert(0,str(root/'apps/SCG/src'))
from silverstar_diagnostics.elf import Firmware_Load
from silverstar_diagnostics.targets import Target_Get
print(Target_Get('STM32F407VET6'))
firmware=Firmware_Load(root/'.work/dev013_maint01/project01/build/FCCG/SilverStar_F407/Release/SilverStar_0_1_3.elf',target='STM32F407VET6')
print('elf',firmware.sha256, 'segments',[(hex(a),len(b)) for a,b in firmware.segments])
print(json.dumps([dataclasses.asdict(e) for e in firmware.entries],ensure_ascii=False,indent=2))
