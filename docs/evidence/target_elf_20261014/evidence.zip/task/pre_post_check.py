"""Reproduce an ELF parser boundary failure using hash-verified prior source.
Offline only. Neither target firmware nor user input is modified.
"""
from pathlib import Path
import hashlib,json,struct,sys,types
task=Path(__file__).absolute().parent
root=task.parents[1]
sys.path.insert(0,str(root/'apps/SCG/src'))
from silverstar_diagnostics.elf import Firmware_Load
from silverstar_diagnostics.contract import DiagnosticError
source=task/'pre_fix_elf.py'
expected=json.loads((task/'bench01/result.json').read_text(encoding='utf-8'))['sources']['apps/SCG/src/silverstar_diagnostics/elf.py']
assert hashlib.sha256(source.read_bytes()).hexdigest()==expected
old=types.ModuleType('silverstar_diagnostics.pre_fix_elf')
old.__package__='silverstar_diagnostics'
sys.modules[old.__name__]=old
exec(compile(source.read_bytes(),str(source),'exec'),old.__dict__)
normal=task/'pytest05/arm_diagnostic_fixture0/fixture.elf'
bad=task/'empty_executable_fixture.elf'
assert not bad.exists()
data=bytearray(normal.read_bytes());phoff=struct.unpack_from('<I',data,28)[0]
for index in range(struct.unpack_from('<H',data,44)[0]):
    offset=phoff+index*32
    if struct.unpack_from('<I',data,offset)[0]==1 and struct.unpack_from('<I',data,offset+24)[0]&1:
        struct.pack_into('<I',data,offset+16,0)
bad.write_bytes(data)
before=old.Firmware_Load(bad,target='STM32F407VET6')
assert before.segments # Prior code accepted only nonexecutable initializer bytes.
try:
    Firmware_Load(bad,target='STM32F407VET6')
except DiagnosticError as exc:
    after={'result':exc.result.value,'detail':str(exc)}
else:raise AssertionError('Current reader accepted empty executable image')
normal_image=Firmware_Load(normal,target='STM32F407VET6')
assert normal_image.segments and all(not e.unavailable for e in normal_image.entries)
record={'predecessor_source_sha256':expected,'pre_fix':'ACCEPTED invalid image with empty executable PT_LOAD',
        'post_fix':after,'normal':'accepted with four parsed entries',
        'fixture_sha256':hashlib.sha256(data).hexdigest(),
        'current_source_sha256':hashlib.sha256((root/'apps/SCG/src/silverstar_diagnostics/elf.py').read_bytes()).hexdigest(),
        'hardware_access':False}
(task/'pre_post_result.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record))
