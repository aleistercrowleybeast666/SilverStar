"""Archive small evidence and auditable source deltas; no cleanup or SDK copies."""
from pathlib import Path
import datetime,hashlib,json,subprocess,zipfile,shutil
root=Path(__file__).absolute().parents[2]
task=Path(__file__).absolute().parent
formal=root/'docs/evidence/target_elf_20261014'
formal.mkdir(parents=True,exist_ok=False)
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):h.update(block)
    return h.hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
base=git('rev-parse','HEAD').decode().strip()
assert base=='034e491bc6e4c6f4e69a59d467db677640c23e8e'
selected=sorted(set(git('ls-files','-m','-o','--exclude-standard').decode().splitlines()))
sources=[p for p in selected if p.startswith(('apps/','contracts/','tools/'))]
assert not any(Path(p).suffix.lower() in ('.c','.h','.s') for p in sources)
snapshot=[{'path':p,'bytes':(root/p).stat().st_size,'sha256':sha(root/p)} for p in sources]
(formal/'source_manifest.json').write_text(json.dumps({'base_commit':base,'modified_and_new_source_files':snapshot},indent=2))
inventory=[]
for path in sorted(task.rglob('*')):
    if not path.is_file() or path.name=='inventory.json':continue
    rel=path.relative_to(task).as_posix()
    role=('source metadata input; retain' if path.suffix=='.pdsc' else
          'retained generated project / compiler / analyzer evidence' if rel.startswith('project') else
          'test-generated fixture / result; retain' if rel.startswith(('pytest','app_offscreen','native','bench')) else
          'task script / verification record; retain')
    inventory.append({'path':str(path.resolve()),'relative':rel,'bytes':path.stat().st_size,'sha256':sha(path),'purpose':role})
inv={'owner':'/root; dev013_target_elf01','generated_root':str(task.resolve()),
     'retained_evidence':str(formal.resolve()),'cleanup_authorized':False,'deleted_files':[],
     'files':inventory,'total_bytes':sum(x['bytes'] for x in inventory)}
(task/'inventory.json').write_text(json.dumps(inv,indent=2))
include=[p for p in task.iterdir() if p.is_file() and p.suffix in ('.json','.log','.py','.md') and p.name!='migration_survey.json']
for folder in ('bench01','native01','app_offscreen02','app_offscreen03','app_offscreen04','app_offscreen05'):
    include += [p for p in (task/folder).glob('*') if p.is_file() and p.suffix in ('.json','.jsonl')]
include += list((task/'app_offscreen05').glob('*.png'))
include += [task/'pytest05/arm_diagnostic_fixture0/fixture.elf',task/'empty_executable_fixture.elf']
include += list((task/'pytest05/arm_diagnostic_fixture0').glob('compile.json'))
paired=task/'project02/build/FCCG/SilverStar_F407/Release/SilverStar_0_1_3.ssdiag'
include.append(paired)
manifest=[]
with zipfile.ZipFile(formal/'evidence.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for path in sorted(set(include)):
        name='task/'+path.relative_to(task).as_posix()
        archive.write(path,name);manifest.append({'path':name,'bytes':path.stat().st_size,'sha256':sha(path)})
    for item in snapshot:
        archive.write(root/item['path'],'source_snapshot/'+item['path'])
    archive.writestr('source_snapshot/tracked.patch',git('diff','--binary',base,'--','apps','contracts','tools'))
    archive.write(formal/'source_manifest.json','source_snapshot/manifest.json')
summary={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_commit':base,
         'branch':git('branch','--show-current').decode().strip(),
         'frozen_tag_object':git('rev-parse','v0.1.2').decode().strip(),
         'frozen_tag_commit':git('rev-parse','v0.1.2^{}').decode().strip(),
         'evidence_zip_sha256':sha(formal/'evidence.zip'),'evidence_zip_bytes':(formal/'evidence.zip').stat().st_size,
         'task_total_bytes':inv['total_bytes'],'task_file_count':len(inventory),'archive_entries':manifest,
         'new_hardware_access_after_recovery':False,'migration_performed':False,'cleanup_performed':False}
(formal/'verification.json').write_text(json.dumps(summary,indent=2))
shutil.copyfile(task/'input_audit.json',formal/'input_audit.json')
shutil.copyfile(task/'app_offscreen05/03_simulated_matched_diagnostics.png',formal/'preview_offscreen_simulated.png')
print(json.dumps({k:v for k,v in summary.items() if k!='archive_entries'},indent=2))
