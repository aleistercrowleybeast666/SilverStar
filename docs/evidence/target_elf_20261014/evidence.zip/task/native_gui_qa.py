"""Native QtTest on real app.main; one simulated image and a real old ELF check.

Application-level test, not OS mouse automation. Native windows platform and
exposed QWidget captures. UART forbidden; actual SWD packets independently audited.
"""
from pathlib import Path
from dataclasses import asdict
from datetime import datetime,timezone
import hashlib,json,os,runpy,subprocess,sys,time,traceback,threading
from threading import Event
from unittest.mock import patch
root=Path(__file__).absolute().parents[2]
task=Path(__file__).absolute().parent/'native01';task.mkdir(exist_ok=False)
sys.path[:0]=[str(root/'apps/GSHC'),str(root/'apps/GSHC/tests')]
os.environ.pop('QT_QPA_PLATFORM',None)
os.environ['SILVERSTAR_GSHC_DATA_ROOT']=str(task/'user_data')
from PySide6.QtCore import Qt,QSettings,QTimer
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication,QFileDialog
QSettings.setDefaultFormat(QSettings.IniFormat)
QSettings.setPath(QSettings.IniFormat,QSettings.UserScope,str(task/'settings'))
from transport.swd_session import SwdSession,SwdResult,_ProbeOwners
from transport.probe_inventory import ProbeInventory_Read,ProbeInventoryResult
from transport import _swd_pyocd as adapter
from test_swd_firmware import ImageMemory
import app
identity=r'USB\VID_FAED&PID_4870\132765403520'
fresh=root/'.work/dev013_target_elf01/project02/build/FCCG/SilverStar_F407/Release/SilverStar_0_1_3.ssdiag'
legacy=Path('D:/stm32_project/SS_0_5_TEST_FINAL/Flight_Controller/build/FCCG/SilverStar_F407/EIDE/Release/SS_0_5_TEST_FINAL.elf')
bad=task/'bad.ssdiag';bad.write_text('{"version":99}')
result={'method':'native Windows QtTest on actual Controller/main; synthetic matched image first, real EIDE legacy ELF second',
        'steps':[],'errors':[],'releases':[],'legacy_elf':str(legacy),'legacy_sha256':hashlib.sha256(legacy.read_bytes()).hexdigest()}
def default(value):
    if isinstance(value,bytes):return value.hex()
    return value.value
def save(): (task/'result.json').write_text(json.dumps(result,default=default,ensure_ascii=False,indent=2),encoding='utf-8')
names=['openocd.exe','pyocd.exe','ST-LINK_gdbserver.exe','STM32_Programmer_CLI.exe','STM32CubeProgrammer.exe','JLink.exe','JLinkGDBServer.exe','JLinkGDBServerCL.exe','Ozone.exe','UV4.exe','gdb.exe','arm-none-eabi-gdb.exe']
command='$names=@('+','.join("'"+n+"'" for n in names)+'); @(Get-CimInstance Win32_Process | Where-Object { $names -contains $_.Name } | Select-Object Name,ProcessId) | ConvertTo-Json -Compress'
check=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',command],capture_output=True,text=True,timeout=20)
result['process_check']=dict(exit=check.returncode,stdout=check.stdout,stderr=check.stderr)
inventory=ProbeInventory_Read(Event());result['inventory']=asdict(inventory);save()
assert check.returncode==0 and check.stdout.strip() in ('','[]','null')
assert inventory.result==ProbeInventoryResult.Ready and len([p for p in inventory.probes if p.identity==identity and p.host_status=='OK'])==1
guard=runpy.run_path(str(root/'.work/dev013_swd_pyocd01/bench_readonly.py'),run_name='packet_guard')['check_packet']
packets=(task/'packets.jsonl').open('x',encoding='utf-8');count=0;phase='init'
original_bulk=adapter._BulkInterface
def audited(api,device,deadline):
    interface=original_bulk(api,device,deadline);write=interface.write;select=0
    def checked(data):
        nonlocal select
        global count
        assert count<50000
        select=guard(data,select);count+=1
        packets.write(json.dumps(dict(phase=phase,allowed=True,tx=bytes(data).hex()))+'\n')
        return write(data)
    interface.write=checked
    return interface
adapter._BulkInterface=audited
original_close=adapter.PyOcdMemAp.close
def observed_close(self):
    interface=self._interface
    original_close(self)
    result['releases'].append(dict(phase=phase,device_released=interface is None or interface.dev is None,
                                  rx_stopped=interface is None or interface.thread is None,library_released=not self._owned))
    save()
adapter.PyOcdMemAp.close=observed_close
holder={};original_controller=app.Controller.__init__
def controller_init(self,*args,**kwargs):
    original_controller(self,*args,**kwargs)
    holder['controller']=self;holder['qa']=Qa(self)

class Qa:
    def __init__(self,c):
        self.c=c;self.w=c.window;self.m=c.swd;self.state='inventory';self.started=time.monotonic();self.entered=self.started
        self.timer=QTimer(self.w);self.timer.setInterval(100);self.timer.timeout.connect(self.tick);self.timer.start()
    def stage(self,state):
        global phase
        phase=self.state=state;self.entered=time.monotonic()
    def shot(self,name):
        assert QApplication.instance().platformName()=='windows' and self.w.windowHandle().isExposed()
        assert self.w.grab().save(str(task/(name+'.png')))
        result['steps'].append(dict(name=name,phase=phase,utc=datetime.now(timezone.utc).isoformat(),packets=count,
            native_exposed=True,platform='windows',status=self.m.status,detail=self.m.detail,
            imported=self.w.maintenance_page.swd_import_status.text(),snapshot=asdict(self.m.snapshot) if self.m.snapshot else None,
            rows=self.m.rows))
        save()
    def click(self,button):
        assert button.isEnabled() and button.isVisible()
        QTest.mouseClick(button,Qt.LeftButton)
    def choose(self,path):
        with patch.object(QFileDialog,'getOpenFileNames',return_value=([str(path)],'Firmware diagnostics')):
            self.click(self.w.maintenance_page.btn_swd_import)
    def tick(self):
        try:self.advance()
        except Exception:
            result['errors'].append(dict(phase=phase,traceback=traceback.format_exc()));save()
            self.timer.stop();self.m.detach();self.c.probes.request_close();self.w.close()
    def advance(self):
        assert time.monotonic()-self.started<240 and time.monotonic()-self.entered<135
        page=self.w.maintenance_page
        if self.state=='inventory':
            if self.c.probes.worker:return
            assert self.c.probes.selection.identity==identity
            self.w.resize(1440,1000)
            index=self.w.pages.indexOf(self.w.maintenance_scroll)
            QTest.mouseClick(self.w.pages.tabBar(),Qt.LeftButton,pos=self.w.pages.tabBar().tabRect(index).center())
            self.stage('ready')
        elif self.state=='ready':
            if not page.btn_swd_import.isVisible():return
            self.shot('01_import_entry');self.choose(fresh);self.stage('import_fresh')
        elif self.state=='import_fresh':
            if self.m.import_worker:return
            assert self.m.firmware and not self.m.worker and count==0
            self.shot('02_fresh_imported')
            def factory(**kwargs):
                backend=ImageMemory(kwargs['firmware'])
                return SwdSession(**kwargs,_backend_factory=lambda _:backend)
            self.m.factory=factory
            self.click(page.btn_swd_attach);self.stage('simulated_match')
        elif self.state=='simulated_match':
            if not self.m.rows:return
            assert self.m.snapshot.symbols=='matched' and len(self.m.rows)==4 and count==0
            self.shot('03_simulated_matched_diagnostics')
            self.click(page.btn_swd_detach);self.stage('simulated_detach')
        elif self.state=='simulated_detach':
            if self.m.worker:return
            assert not self.m.rows
            self.choose(bad);self.stage('bad_import')
        elif self.state=='bad_import':
            if self.m.import_worker:return
            assert self.m.firmware is None
            self.shot('04_bad_import_refused')
            self.choose(legacy);self.stage('legacy_import')
        elif self.state=='legacy_import':
            if self.m.import_worker:return
            assert self.m.firmware and self.m.firmware.provenance=='manual_elf_unbound'
            self.shot('05_legacy_manual_import')
            self.m.factory=SwdSession
            self.click(page.btn_swd_attach);self.stage('real_verify')
        elif self.state=='real_verify':
            if self.m.rows:
                assert self.m.snapshot.symbols=='matched' and not self.m.snapshot.dhcsr & ((1<<17)|3)
                result['real_match']='matched';self.shot('06_real_legacy_matched')
                self.click(page.btn_swd_detach);self.stage('real_detach')
            elif self.m.worker is None:
                assert self.m.status=='swd.firmware_mismatch',self.m.detail
                result['real_match']='mismatch';self.shot('06_real_legacy_mismatch');self.stage('real_detach')
        elif self.state=='real_detach':
            if self.m.worker:return
            assert not adapter._LibraryOwner.locked() and not _ProbeOwners
            page.swd_target.setCurrentIndex(0)
            assert self.m.firmware is None
            self.stage('close_ready')
        elif self.state=='close_ready':
            if not page.btn_swd_attach.isEnabled():return
            self.click(page.btn_swd_attach);self.stage('close_connected')
        elif self.state=='close_connected':
            if not self.m.snapshot:return
            assert self.m.snapshot.device_id==0x413 and not self.m.snapshot.dhcsr & ((1<<17)|3)
            self.shot('07_close_while_attached');self.stage('close_requested');self.timer.stop();self.w.close()

app.Controller.__init__=controller_init
code=1
try:
    with patch('transport.serial_backend.serial.Serial',side_effect=AssertionError('UART forbidden')) as serial:
        code=app.main();c=holder['controller']
        result['final']=dict(app_exit=code,phase=phase,serial_opens=serial.call_count,window_hidden=not c.window.isVisible(),
            swd_worker_none=c.swd.worker is None,import_worker_none=c.swd.import_worker is None,probe_worker_none=c.probes.worker is None,
            library_released=not adapter._LibraryOwner.locked(),owners_empty=not _ProbeOwners,
            rx_threads=[t.name for t in threading.enumerate() if 'CMSIS-DAPv2 receive' in t.name],packets=count)
        assert not result['errors'] and code==0 and phase=='close_requested' and serial.call_count==0
        assert all(result['final'][k] for k in ('window_hidden','swd_worker_none','import_worker_none','probe_worker_none','library_released','owners_empty'))
        assert not result['final']['rx_threads']
        assert hashlib.sha256(legacy.read_bytes()).hexdigest()==result['legacy_sha256']
except Exception:
    result['errors'].append(dict(phase='outer',traceback=traceback.format_exc()));code=1
finally:
    packets.close();save();print(json.dumps(dict(exit=code,steps=len(result['steps']),packets=count,errors=result['errors'])))
raise SystemExit(code)
