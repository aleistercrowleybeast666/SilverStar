# dev013_target_elf01

Owner: /root, SilverStar SCG/GSHC target descriptor and ELF diagnostics, 2026-10-14.
Base: 034e491bc6e4c6f4e69a59d467db677640c23e8e.

This versioned task directory contains two independently generated validation projects,
ARM/host/analyzer outputs, official PDSC inputs, bounded test fixtures, run commands,
all failed and successful logs, one earlier authorized read-only bench, and offline GUI QA.
No firmware was flashed, no user FINAL project was modified, and no cleanup is authorized
or performed. Project01 records the rejected generator-boundary design; Project02 is the
corrected metadata/host-binder design. Both are retained, not mixed into one executed pass.

Formal small evidence: docs/evidence/target_elf_20261014/REPORT.md and evidence.zip.
Inventory: inventory.json records absolute paths, role, owner context, sizes and SHA-256.
Generated projects/binaries remain here by exact paths and hashes; no SDK or environment
copy is in the formal archive. Source inputs, fixtures and formal evidence are retained.

bench01 is the earlier actual read-only Horco/F407 check (160 audited packets; both ELF
candidates mismatched; releases OK). native01 failed before any DAP packet because importing
a test helper selected Qt offscreen before the script asserted windows. app_offscreen02
failed on a stale real-vs-model identity assertion; 03/04/05 are explicitly simulated app
runs. 05 is the final table/label UI run. They are not native desktop or hardware acceptance.
After recovery the user GSHC was running, so no new probe access was attempted.

pre_fix_elf.py is reconstructed from the recorded predecessor and accepted only after
matching bench01's exact source hash. pre_post_check.py proves the empty-executable-PT_LOAD
failure before the fix and rejection afterward, plus normal parsing. No target involved.

migration_survey.json is a separate read-only source inventory for a later migration phase.
No source directories were moved, deleted, or staged into this ELF implementation.
