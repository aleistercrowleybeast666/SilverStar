from pathlib import Path
import sys, json, datetime, subprocess, os
out=Path(__file__).absolute().parent
name,cwd=sys.argv[1:3]
assert name.replace('_','').isalnum()
assert not (out/(name+'.json')).exists()
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out/(name+'.log')).open('wb') as stream:
    result=subprocess.run(sys.argv[3:],cwd=cwd,stdout=stream,stderr=subprocess.STDOUT)
(out/(name+'.json')).write_text(json.dumps(dict(command=sys.argv[3:],cwd=str(cwd),started=started,
    finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=result.returncode,
    environment={key:os.environ.get(key) for key in ('PYTHONPATH','SILVERSTAR_ELFTOOLS_PATH','QT_QPA_PLATFORM')}),indent=2))
print(name,'exit',result.returncode)
raise SystemExit(result.returncode)
