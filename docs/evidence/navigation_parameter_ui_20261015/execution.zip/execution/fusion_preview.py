"""Offline parameter panels, no dataset/device operations."""
from pathlib import Path
import sys
root=Path(__file__).resolve().parent
repo=root.parents[1]
sys.path.insert(0,str(repo/'apps/FLP/src'))
from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QFont,QFontDatabase
from silverstar_fccg.core.i18n import Translator as ScgTranslator
from silverstar_fccg.plugins.catalog import PluginCatalog
from silverstar_fccg.ui.pages.algorithm_parameters import NavigationConfigurationPage
from silverstar_flp.core.i18n import Translator as FlpTranslator
from silverstar_flp.ui.pages.replay import ReplayPage
from silverstar_flp.plugins.registry import builtin_registry
from silverstar_flp.plugins.algorithms.eskf15.plugin import Eskf15AlgorithmPlugin
app=QApplication([])
QFontDatabase.addApplicationFont('C:/Windows/Fonts/msyh.ttc')
app.setFont(QFont('Microsoft YaHei',10))
catalog=PluginCatalog(repo/'apps/SCG/plugins/builtin',repo/'apps/SCG/plugins/installed')
catalog.Scan()
owner=catalog.Component_Get('silverstar.algorithm.estimator.eskf15')
values={owner.component_id:{p.parameter_id:p.default for p in owner.algorithm_parameters}}
for language in ('zh_CN','en_US'):
    scg=NavigationConfigurationPage(ScgTranslator(language))
    scg.Configuration_Set((owner,),values)
    scg.resize(1050,1100);scg.show();app.processEvents()
    assert scg.grab().save(str(root/('scg_common_'+language+'.png')))
    scg.close()
    flp=ReplayPage(FlpTranslator(language),builtin_registry())
    flp.algorithm_combo.setCurrentIndex(flp.algorithm_combo.findData(Eskf15AlgorithmPlugin.metadata.plugin_id))
    flp.resize(1050,1100);flp.show();app.processEvents()
    assert flp.grab().save(str(root/('flp_common_'+language+'.png')))
    flp.close()
print('Saved offline component previews; no target/dataset loaded')
