"""Preserve the UI-only changes and all task-local attempts without cleanup."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

task = Path(__file__).resolve().parent
repo = task.parents[1]
destination = repo / 'docs/evidence/navigation_parameter_ui_20261015'
destination.mkdir(parents=True, exist_ok=False)
sources = (
    'apps/SCG/src/silverstar_fccg/ui/pages/algorithm_parameters.py',
    'apps/SCG/tests/test_algorithm_parameters.py',
    'apps/SCG/tests/test_common_navigation_parameters_ui.py',
    'apps/FLP/src/silverstar_flp/ui/pages/replay.py',
    'apps/FLP/src/silverstar_flp/i18n/en_US.json',
    'apps/FLP/src/silverstar_flp/i18n/zh_CN.json',
    'apps/FLP/tests/test_replay_page.py',
    'docs/public/SCG/NAVIGATION_PARAMETER_VISIBILITY_20261015.md',
)
files = {name: repo / name for name in sources}
for pattern in ('fusion_ui*.json', 'fusion_ui*.log', 'scg_ui*.json', 'scg_ui*.log',
                'fusion_visual*.json', 'fusion_visual*.log', '*_common_*.png'):
    for path in task.glob(pattern):
        files['execution/' + path.name] = path
for name in ('run.py', 'fusion_preview.py', 'record_fusion_ui_evidence.py'):
    files['execution/' + name] = task / name
manifest = {
    'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
    'owner': 'watch_fusion root', 'scope': 'SCG/FLP parameter presentation only',
    'scg': '166 passed, one known historical golden mismatch explicitly deselected',
    'flp': '148 passed',
    'visual': 'Offline component previews; SCG Chinese and FLP English inspected by root',
    'hardware': 'NOT TESTED', 'cleanup_authorized': False,
    'files': {name: {'size': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
              for name, path in files.items()},
}
with zipfile.ZipFile(destination / 'execution.zip', 'x', zipfile.ZIP_DEFLATED) as archive:
    for name, path in sorted(files.items()):
        archive.write(path, name)
    archive.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2))
    assert archive.testzip() is None
receipt = {'bytes': (destination / 'execution.zip').stat().st_size,
           'sha256': hashlib.sha256((destination / 'execution.zip').read_bytes()).hexdigest()}
(destination / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
(destination / 'receipt.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
baseline = json.loads((task / 'inventory.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((repo / name).read_bytes()).hexdigest() == digest
           for name, digest in baseline['user_files'].items())
assert subprocess.check_output(['git', 'rev-parse', 'v0.1.2'], cwd=repo, text=True).strip() == baseline['frozen_tag']
print(json.dumps(receipt))
print('User inputs and frozen v0.1.2 tag unchanged')
