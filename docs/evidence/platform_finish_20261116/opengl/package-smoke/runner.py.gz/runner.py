"""Limited actual-EXE smoke; no injected hooks, native input, or renderer claims.

Run only after the coordinated candidate is ready. FLP --version exits before
QApplication construction and QSettings writes. GSHC's normal idle startup reads
preferences, uses its existing data-root override and never opens a port/target
without an explicit user action. Host PnP/COM inventory remains enabled. The
bounded GSHC process is deliberately terminated, not reported as normal close.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time
import winreg


EXPECTED_COMMIT = '6fed5b639d0835de7874a74db25a63ab0da814ad'
ROOT = Path('D:/python_software/SilverStar')


def Digest(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def RegistryIdentity_Read(product):
    """Hash existing application values; never publish values or write/restore."""
    records = []
    def visit(path, relative):
        try:
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, path, 0, winreg.KEY_READ)
        except FileNotFoundError:
            return False
        with key:
            children, values, _modified = winreg.QueryInfoKey(key)
            for index in range(values):
                name, value, kind = winreg.EnumValue(key, index)
                records.append((relative, name, kind, repr(value)))
            for index in range(children):
                child = winreg.EnumKey(key, index)
                visit(path + '\\' + child, relative + '/' + child)
        return True
    exists = visit('Software\\SilverStar\\' + product, '')
    data = json.dumps(sorted(records), ensure_ascii=True).encode()
    return {'exists': exists, 'value_count': len(records),
            'values_sha256': hashlib.sha256(data).hexdigest()}


def Process_Run(command, output, environment, seconds, *, expect_exit):
    started = time.monotonic()
    record = {'command': command, 'cwd': str(output), 'observation_limit_s': seconds,
              'started_utc': datetime.now(timezone.utc).isoformat(),
              'stdout_note': 'Windowed PyInstaller Python streams may be unavailable; empty logs do not prove absence of internal errors.'}
    with (output / 'stdout.log').open('xb') as stdout, (output / 'stderr.log').open('xb') as stderr:
        process = subprocess.Popen(command, cwd=output, env=environment,
            stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
            creationflags=subprocess.CREATE_NO_WINDOW)
        record['pid'] = process.pid
        record['process_ownership'] = 'The exact subprocess.Popen process handle created by this runner; no process-name/window matching.'
        try:
            try:
                process.wait(timeout=seconds)
                record['exit_reason'] = 'process exited without runner termination'
                record['alive_at_observation_limit'] = False
            except subprocess.TimeoutExpired:
                record['alive_at_observation_limit'] = True
                record['exit_reason'] = 'runner deliberately terminated its own process after bounded observation; not normal close acceptance'
                process.terminate()
                process.wait(timeout=10)
        finally:
            if process.poll() is None:
                process.kill()
                process.wait(timeout=10)
            record['exit_code'] = process.returncode
            record['seconds'] = time.monotonic() - started
    logs = {}
    error_signals = []
    for name in ('stdout.log', 'stderr.log'):
        path = output / name
        text = path.read_bytes().decode('utf8', errors='replace')
        logs[name] = {'bytes': path.stat().st_size, 'sha256': Digest(path)}
        error_signals.extend(match.group(0) for match in re.finditer(
            r'Traceback|Unhandled exception|Error loading Python DLL|Failed to execute script|ModuleNotFoundError', text))
    record['logs'] = logs
    record['error_signals'] = error_signals
    record['limited_check_satisfied'] = (process.returncode == 0 and not record['alive_at_observation_limit']
        if expect_exit else record['alive_at_observation_limit']) and not error_signals
    return record


def Main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bundle', type=Path, required=True)
    parser.add_argument('--candidate', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    bundle, output = args.bundle.resolve(), args.out.resolve()
    if bundle != ROOT / 'dist/pf1117b/SilverStar':
        raise ValueError('Unexpected candidate bundle')
    if not output.is_relative_to(ROOT / '.work/platform-finish-20261116/opengl'):
        raise ValueError('Output must remain in the owned task directory')
    if output.exists():
        raise ValueError('Use a fresh output directory')
    candidate = json.loads(args.candidate.read_text(encoding='utf8'))
    manifest_path = bundle / 'CANDIDATE_MANIFEST.json'
    manifest = json.loads(manifest_path.read_text(encoding='utf8'))
    if candidate['code_commit'] != EXPECTED_COMMIT or manifest['code_commit'] != EXPECTED_COMMIT:
        raise ValueError('Candidate source identity mismatch')
    if Path(candidate['bundle']).resolve() != bundle:
        raise ValueError('Candidate output mismatch')
    output.mkdir(parents=True)
    record = {'code_commit': EXPECTED_COMMIT, 'bundle': str(bundle),
        'candidate_receipt_sha256': Digest(args.candidate), 'manifest_sha256': Digest(manifest_path),
        'scope': 'Actual windowed EXE version/idle-process smoke and static packaged application-source hashes; no native GUI, 3D, physical display, hardware, or cold/warm startup acceptance.',
        'checks': {}, 'issues': []}
    try:
        expected_files = manifest['files']
        scoped = {name: value for name, value in expected_files.items()
            if name.startswith(('_internal/apps/FLP/', '_internal/apps/GSHC/'))
            or name in ('FLP.exe', 'GSHC.exe')}
        if not scoped:
            raise ValueError('Application resources absent from candidate manifest')
        for name, expected in scoped.items():
            if Digest(bundle / name) != expected:
                raise ValueError('Packaged file hash mismatch: ' + name)
        for product in ('FLP', 'GSHC'):
            if Digest(bundle / (product + '.exe')) != candidate['executable_sha256'][product + '.exe']:
                raise ValueError('Executable identity differs from candidate receipt')
        for suffix in ('/qoffscreen.dll', '/Qt6OpenGLWidgets.dll'):
            matching = [name for name in expected_files if name.endswith(suffix)]
            if not matching:
                raise ValueError('Required packaged runtime input missing: ' + suffix)
            for name in matching:
                if Digest(bundle / name) != expected_files[name]:
                    raise ValueError('Runtime input hash mismatch: ' + name)
        record['static_verified_files'] = scoped
        record['exe_sha256'] = {product: Digest(bundle / (product + '.exe')) for product in ('FLP', 'GSHC')}
        record['registry_before'] = {p: RegistryIdentity_Read(p) for p in ('SilverStar_FLP', 'SilverStar_GSHC')}
        environment = os.environ.copy()
        for variable in ('PYTHONPATH', 'PYTHONHOME', 'QT_OPENGL', 'QT_PLUGIN_PATH', 'QT_QPA_PLATFORM_PLUGIN_PATH'):
            environment.pop(variable, None)
        environment['QT_QPA_PLATFORM'] = 'offscreen'
        environment['PYTHONDONTWRITEBYTECODE'] = '1'
        record['process_environment_overrides'] = {'QT_QPA_PLATFORM': 'offscreen',
            'note': 'APPDATA/LOCALAPPDATA only contain ordinary environment-derived files; Windows native QSettings is read but is not claimed isolated or overridden.'}
        for product, arguments, seconds, expect_exit in (
            ('FLP', ['--version'], 20, True), ('GSHC', [], 40, False)):
            product_out = output / product
            product_out.mkdir()
            for variable in ('TEMP', 'TMP', 'APPDATA', 'LOCALAPPDATA', 'MPLCONFIGDIR'):
                destination = product_out / variable.lower()
                destination.mkdir()
                environment[variable] = str(destination)
            data_root = product_out / 'data-root'
            if product == 'GSHC':
                environment['SILVERSTAR_GSHC_DATA_ROOT'] = str(data_root)
            command = [str(bundle / (product + '.exe')), *arguments]
            record['checks'][product] = Process_Run(command, product_out, environment, seconds, expect_exit=expect_exit)
            if not record['checks'][product]['limited_check_satisfied']:
                record['issues'].append(product + ': limited process check not satisfied; consult exact exit/log evidence')
            if product == 'GSHC':
                record['gshc_data_root'] = str(data_root)
                record['gshc_data_files'] = [{ 'path': str(p.relative_to(data_root)), 'bytes': p.stat().st_size,
                    'sha256': Digest(p)} for p in sorted(data_root.rglob('*')) if p.is_file()]
                record['gshc_data_directories'] = [p.name for p in sorted(data_root.iterdir()) if p.is_dir()] if data_root.exists() else []
                if record['gshc_data_files']:
                    record['issues'].append('Unexpected GSHC idle data file; inspect before accepting smoke')
        record['registry_after'] = {p: RegistryIdentity_Read(p) for p in record['registry_before']}
        record['registry_values_unchanged'] = record['registry_after'] == record['registry_before']
        if not record['registry_values_unchanged']:
            record['issues'].append('Application registry value identity changed during observation; no rollback attempted because another user process may own concurrent updates')
        record['package_scoped_hashes_unchanged'] = all(Digest(bundle / name) == digest for name, digest in scoped.items())
        if not record['package_scoped_hashes_unchanged']:
            record['issues'].append('Packaged application source/executable changed during smoke')
    except Exception as error:
        record['issues'].append(type(error).__name__ + ': ' + str(error))
        raise
    finally:
        record['finished_utc'] = datetime.now(timezone.utc).isoformat()
        (output / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf8')
        print(json.dumps({'output': str(output), 'issues': record['issues'],
            'checks': {name: {'pid': value['pid'], 'exit_code': value['exit_code'],
                'limited_check_satisfied': value['limited_check_satisfied']} for name, value in record['checks'].items()}}), flush=True)
    return int(bool(record['issues']))


if __name__ == '__main__':
    raise SystemExit(Main())
