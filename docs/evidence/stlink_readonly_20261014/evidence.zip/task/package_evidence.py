from pathlib import Path
import json,hashlib,subprocess,zipfile,datetime
root=Path(__file__).absolute().parents[2]
task=Path(__file__).absolute().parent
formal=root/'docs/evidence/stlink_readonly_20261014'
assert json.loads((task/'regression02.json').read_text())['exit_code']==0
assert not formal.exists()
formal.mkdir(parents=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
snapshot=json.loads((task/'tested_source_snapshot.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==snapshot['base_commit']
for item in snapshot['files']:assert sha(root/item['path'])==item['sha256'],item['path']
baseline=json.loads((root/'.work/dev013_monorepo01/baseline.json').read_text())
assert all(sha(root/p)==h for p,h in baseline['user_files'].items())
inventory=[{'path':str(p.resolve()),'bytes':p.stat().st_size,'sha256':sha(p),
            'owner':'/root dev013_stlink01','purpose':'retained fake-USB regression / source and dependency evidence'}
           for p in task.rglob('*') if p.is_file() and p.name!='inventory.json']
(task/'inventory.json').write_text(json.dumps({'files':inventory,'total_bytes':sum(x['bytes'] for x in inventory),'cleanup_performed':False},indent=2))
members=[]
with zipfile.ZipFile(formal/'evidence.zip','x',zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(task.iterdir()):
        if path.is_file() and path.suffix in ('.json','.log','.py','.md','.patch'):
            name='task/'+path.name;archive.write(path,name)
            members.append({'path':name,'bytes':path.stat().st_size,'sha256':sha(path)})
    for item in snapshot['files']:
        path=root/item['path'];archive.write(path,'source_snapshot/'+item['path'])
    # Current compiled test fixture is generated offline and never run on a target.
    for path in (task/'pytest_full02').glob('arm_diagnostic_fixture*/compile.json'):
        archive.write(path,'fixture/'+path.parent.name+'/compile.json')
summary={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_commit':snapshot['base_commit'],
         'scope':'254 scoped GSHC tests, ten files; not whole monorepo or hardware',
         'hardware_access':False,'new_dependencies_installed':False,'firmware_C_changed':False,
         'openocd_enabled':False,'source_snapshot':snapshot,'members':members,
         'evidence_zip_sha256':sha(formal/'evidence.zip'),'evidence_zip_bytes':(formal/'evidence.zip').stat().st_size,
         'task_bytes':sum(x['bytes'] for x in inventory),'cleanup_performed':False,
         'frozen_tag':subprocess.check_output(['git','rev-parse','v0.1.2'],cwd=root,text=True).strip(),
         'frozen_commit':subprocess.check_output(['git','rev-parse','v0.1.2^{}'],cwd=root,text=True).strip()}
(formal/'verification.json').write_text(json.dumps(summary,indent=2))
with zipfile.ZipFile(formal/'evidence.zip') as archive:
    assert archive.testzip() is None
    for member in members:
        data=archive.read(member['path'])
        assert len(data)==member['bytes'] and hashlib.sha256(data).hexdigest()==member['sha256']
print(json.dumps({k:summary[k] for k in ('base_commit','task_bytes','evidence_zip_bytes','evidence_zip_sha256')},indent=2))
