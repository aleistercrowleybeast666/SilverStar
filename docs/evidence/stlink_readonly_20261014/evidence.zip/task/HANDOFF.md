# ST-Link 接续点

Base: 43ee0e82d421be52b8f3b38935104baae96c778c. Current application code is unchanged
since the monorepo-import commit. No ST-Link backend implementation or admission change
has been made. No probe/serial/device access; no installs or driver changes.

Pinned installed pyOCD0.45.1 has StlinkProbe, STLinkMemoryInterface, STLinkUSBInterface.
Sources read and SHA-256 recorded in reviewed_dependencies.json. Reuse dependency,
do not fork/download SDK. Existing _swd_pyocd._LoadLibrary and _LibraryOwner lock can
provide trusted options-only Session and cross-backend process lifetime coordination.

Implementation seam: configure/open/read/close, read-only factory by explicit HostProbe
identity; current SwdSession._ValidateProbe still rejects all but Horco. Separate ST-Link
backend and profile selection; keep OpenOCD reserved/disabled with no arbitrary config/Tcl.
No Board/CortexM/target initialization, reset/halt/resume, target write, SWV or DFU/SWIM.

Reviewed USB map: VID0483, PID3748/374A/374B/374E/374F/3752/3753/3754/3755/3757.
Reject V1 PID3744 and DFU374D. Upstream normalizes a 12-character STLinkV2 serial to
24 hex characters; compare exact upstream-normalized identity, not approximate serial.
Native USB interface is0, endpoints depend on this fixed map. No set_configuration or
kernel-driver detach. Claim must succeed before ANY ST-Link protocol command; fail Busy
and stop. Retain resource when partial open/claim/flush fails; release only owned interface.

Upstream _flush_rx uses an unbounded loop: override with64 packet budget, deadline/cancel,
USB timeout500ms, close without unbounded join (ST-Link uses synchronous I/O).
Upstream link.open calls enter_idle before version query: GET_CURRENT_MODE must refuse
pre-existing JTAG/SWIM/DFU/unknown mode before any exit or enter command. Only own connection
may perform controlled SWD enter/exit. Conservative initial MASS-only admission is planned.
Do not call upstream link.close blindly after an admission/partial-open failure.

Wire-command allowlist must enforce operands, lengths and readSize, writeData=None:
GET_VERSION(6), EXT(12), MODE(2), VTARGET(8); JTAG_ENTER2=[F2,30,A3,0]; EXIT=[F2,21]
only after own enter attempt; INIT_AP=[F2,4B,0,0] NO_CORE; fixed SWD clock at <=1MHz.
V2 SWD_SET_FREQ=[F2,43,3] for950kHz, read2; V3 prescaler1 read8, GET_COM_FREQ protocol0
read52, SET_COM_FREQ protocol0/reserved0/freq<=1000kHz read8.
Only DAP IDR read DPportFFFF/address0 and APport0/addressFC. Verify DPv1/v2 and AP0
AHB MEM-AP before target read; V2>=J28 needed for NO_CORE AP setup. No AP discovery loop.
Memory read opcodes07/0C (optionally47 only if justified), APSEL0, CSW bytes0, count<=1024,
32-bit alignment when required. Each memory transfer must fit exactly the currently
admitted backend read window, which already passes trusted RAM/flash/core-ID ranges.
GETLASTRWSTATUS2 read12. SWD fault clearing is exactly DP_ABORT value0x1E, if permitted;
upstream _clear_sticky_error uses this, not target-memory writes. All other writes blocked.

Managed STLinkMemoryInterface.read_memory_block8 splits unaligned head, aligned32-bit
middle and tail, without overreading. Reuse actual pinned classes with fake USB packets
in tests: V2/V3(/V4), model M3/M4/M0+, claim refusal emits0 protocol commands, ambiguous
identity/driver/version/mode/AP refusal, malformed/short replies, timeout/unplug/cancel,
flush budget, no reset/halt/write packets, release failure retains ownership, full ELF
verification/diagnostic interface common tests, stale GUI worker lifecycle.
Pre-fix drain proof can run original _flush_rx on66 fake packets then timeout versus
new64 rejection; never intercept MCU traps or describe this as hardware recovery.

Update frontend capability explanation as experimental/unverified hardware. Existing
user GSHC is running; do not steal desktop or physical probe. No ST-Link physical sample.
Run scoped GSHC regressions with offscreen/fake I/O, save exact baseline/dirty snapshots,
commands/versions/logs/source hashes and separate local commit. No new firmware C edits
are planned. Preserve three original untracked CSV/TXT files and frozen v0.1.2 tag.
