"""Read-only HEAD module overlay for baseline UI failure attribution, no checkout."""
import importlib.abc
import importlib.util
from pathlib import Path
import subprocess
import sys
import pytest

root=Path(__file__).resolve().parents[2]
paths=subprocess.check_output(['git','diff','--name-only','--','apps/GSHC','apps/SCG/src/silverstar_diagnostics'],cwd=root,text=True).splitlines()
sources={}
for path in paths:
    if not path.endswith('.py') or '/tests/' in path: continue
    if path.startswith('apps/GSHC/'):
        name=path[len('apps/GSHC/'):-3].replace('/','.')
    else:
        name=path[len('apps/SCG/src/'):-3].replace('/','.')
    sources[name]=(path,subprocess.check_output(['git','show','HEAD:'+path],cwd=root).decode('utf-8'))
class HeadLoader(importlib.abc.MetaPathFinder,importlib.abc.Loader):
    def find_spec(self,name,path=None,target=None):
        if name in sources:return importlib.util.spec_from_loader(name,self)
    def create_module(self,spec):return None
    def exec_module(self,module):
        path,source=sources[module.__name__]
        module.__file__=str(root/path)
        exec(compile(source,module.__file__,'exec'),module.__dict__)
sys.meta_path.insert(0,HeadLoader())
print('BASELINE HEAD',subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip())
print('Read-only module replacements',list(sources))
raise SystemExit(pytest.main(sys.argv[1:]))
