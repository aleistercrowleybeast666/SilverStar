"""Small task-owned command recorder; no hardware operations or cleanup."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]

def save(name, value):
    path = ROOT / name
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)

if sys.argv[1] == 'baseline':
    user_files = ['work_build_candidates_20261006.csv', 'work_inventory_20261006.txt',
                  'work_subtree_classification_20261006.csv']
    def git(*args):
        return subprocess.check_output(['git', *args], cwd=REPO, text=True, encoding='utf-8').strip()
    save('inventory.json', dict(owner='Codex sole repository writer',
        purpose='0.1.3 GSHC read-only watch and navigation work; baseline/status before changes',
        root=str(ROOT), cleanup_authorized=False, retained_evidence=[str(ROOT)],
        utc=datetime.datetime.now(datetime.UTC).isoformat(), head=git('rev-parse','HEAD'),
        branch=git('branch','--show-current'), status=git('status','--short'),
        frozen_tag=git('rev-parse','v0.1.2'), frozen_commit=git('rev-parse','v0.1.2^{}'),
        user_files={p:hashlib.sha256((REPO/p).read_bytes()).hexdigest() for p in user_files}))
else:
    name = sys.argv[1]
    assert name.isidentifier(), name
    command = sys.argv[2:]
    temporary = ROOT / (name+'_temp')
    temporary.mkdir(exist_ok=False)
    env = dict(os.environ, PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1',
               QT_QPA_PLATFORM='offscreen', PYTHONPATH=os.pathsep.join(str(REPO/p) for p in ('apps/GSHC','apps/GSHC/tests','apps/SCG/src')),
               TMP=str(temporary), TEMP=str(temporary), TMPDIR=str(temporary))
    start = datetime.datetime.now(datetime.UTC).isoformat()
    before = time.monotonic()
    with (ROOT/(name+'.log')).open('xb') as output:
        result = subprocess.run(command, cwd=REPO, env=env, stdout=output, stderr=subprocess.STDOUT)
    record = dict(command=command,cwd=str(REPO),utc=start,seconds=time.monotonic()-before,
                  exit_code=result.returncode,log=str(ROOT/(name+'.log')),
                  environment={k:env[k] for k in ('PYTHONIOENCODING','PYTHONDONTWRITEBYTECODE','QT_QPA_PLATFORM','PYTHONPATH','TMP','TEMP','TMPDIR')})
    save(name+'.json',record)
    print(json.dumps(record,ensure_ascii=False))
    print((ROOT/(name+'.log')).read_text(encoding='utf-8',errors='replace')[-3500:])
    sys.exit(result.returncode)
