"""Task-owned, offline-only visual QA. No connection manager or transport."""
from pathlib import Path
from PySide6.QtCore import QSettings
from PySide6.QtGui import QFont, QFontDatabase
from PySide6.QtWidgets import QApplication
from services.i18n import I18n
from ui.main_window import MainWindow
from transport.swd_firmware import Firmware_Import, DiagnosticResult

root=Path(__file__).resolve().parent
app=QApplication([])
QFontDatabase.addApplicationFont('C:/Windows/Fonts/msyh.ttc')
app.setFont(QFont('Microsoft YaHei',10))
window=MainWindow(I18n(QSettings(str(root/'preview.ini'),QSettings.IniFormat)))
window.render_timer.stop();window.gl_view.hide()
window.resize(1280,900)
page=window.maintenance_page
window.pages.setCurrentWidget(window.maintenance_scroll)
imported=Firmware_Import([root/'wt06/arm_diagnostic_fixture0/watch.elf'],target='STM32F407VET6')
assert imported.result==DiagnosticResult.Ok,imported.detail
page.swd_watch.set_firmware(imported.firmware)
page.swd_watch.search.setText('global_state.inner.value')
page.swd_watch.add.click()
for language in ('zh_CN','en_US'):
    window.i18n.set_language(language);window.retranslate_ui()
    page.swd_summary.setText('\n'.join(window.i18n.tr('watch.summary.'+key)+': UNKNOWN' for key in (
        'task.preparation','thread.estimator','sensor.ins_solution','thread.logger')))
    window.show();app.processEvents()
    assert window.grab().save(str(root/('watch_v2_'+language+'.png')))
    print(language,window.size().width(),window.size().height(),page.swd_watch.size().width())
window.close()
