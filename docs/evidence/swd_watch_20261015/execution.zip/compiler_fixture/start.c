volatile unsigned int zero_data[16];
void _start(void) { for (;;) {} }
