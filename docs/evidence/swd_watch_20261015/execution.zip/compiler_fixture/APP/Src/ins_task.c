static volatile struct {
unsigned long long timestamp_us;
unsigned int update_seq;
unsigned int health_flags;
unsigned int alignment_valid;
unsigned int ins_valid;
unsigned int mission_running;
} s_published_output __attribute__((used)) = {2};
