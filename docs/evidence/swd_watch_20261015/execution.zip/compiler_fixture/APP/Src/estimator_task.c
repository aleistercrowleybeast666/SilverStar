static volatile struct {
unsigned int sequence;
unsigned long long last_start_us;
unsigned long long last_end_us;
unsigned long long last_interval_us;
unsigned long long last_duration_us;
unsigned long long max_duration_us;
unsigned int duration_over_20ms_count;
unsigned int last_prediction_count;
unsigned int prediction_cap_count;
} s_estimator_task_timing __attribute__((used)) = {2};
