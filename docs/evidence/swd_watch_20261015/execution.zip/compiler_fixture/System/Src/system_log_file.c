static volatile struct {
unsigned long long timestamp_us;
unsigned int sequence;
unsigned long long last_completed_write_us;
unsigned int completed_writes;
unsigned int storage_valid;
unsigned int mounted;
unsigned int healthy;
unsigned int writer_open;
unsigned int log_fault;
unsigned int finalization;
unsigned int valid;
} s_snapshot __attribute__((used)) = {2};
