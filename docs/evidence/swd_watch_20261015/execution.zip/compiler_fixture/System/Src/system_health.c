static volatile struct {
unsigned long long timestamp_us;
unsigned int sequence;
unsigned int start_blocking_mask;
unsigned int warning_mask;
unsigned int attitude_status;
unsigned int ready;
} s_health __attribute__((used)) = {2};
