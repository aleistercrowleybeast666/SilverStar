
typedef struct { float value; unsigned long long ticks; } Inner;
volatile struct { int count; Inner inner; _Bool ready; int *pointer; int array[2]; unsigned bits:3; } global_state = {7,{1.25f,42},1,0,{0},0};
static volatile double precision = 2.5;
static volatile int duplicate = 4;
volatile int global_scalar = -12;
enum Mode { Mode_Failed = -3, Mode_Ready = 2 };
volatile enum Mode mode = Mode_Failed;
__attribute__((used)) int Local(void) { volatile int stack_local=3; static volatile int local_static=5; (void)precision; return stack_local+local_static+duplicate; }
