"""Record an exact current command for the affected GSHC software gates."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

root = Path('D:/python_software/SilverStar')
work = root / '.work/gui-convergence-20261110'
BATCH = 'gshc-final-v2'
files = [
    'test_release_telemetry_direction.py', 'test_reconnect_recovery.py',
    'test_sensor_snapshot.py', 'test_navigation_readiness.py',
    'test_magnetometer_calibration.py', 'test_magnetometer_workflow.py',
    'test_maintenance_serial_profile.py', 'test_gui_maintenance_workflow.py',
]
command = [str(root / '.venv/Scripts/python.exe'), '-B', '-m', 'pytest', '-q',
           *['apps/GSHC/tests/' + name for name in files],
           '--basetemp=' + str(work / BATCH)]
settings = {'PYTHONUTF8': '1', 'PYTHONDONTWRITEBYTECODE': '1',
            'QT_QPA_PLATFORM': 'offscreen', 'QT_QPA_FONTDIR': 'C:/Windows/Fonts',
            'PYTHONPATH': str(root / 'apps/GSHC'),
            'SILVERSTAR_GSHC_DATA_ROOT': str(work / (BATCH + '-data'))}
env = dict(os.environ, **settings)
inputs = {}
for path in sorted((root / 'apps/GSHC').rglob('*.py')):
    if any(part in {'.venv', '.work', '.git', '__pycache__'} for part in path.parts):
        continue
    inputs[path.relative_to(root).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
started = time.monotonic()
with (work / ('root/' + BATCH + '.log')).open('xb') as log:
    result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
changed = [name for name, value in inputs.items() if hashlib.sha256((root / name).read_bytes()).hexdigest() != value]
receipt = {'command': command, 'cwd': str(root), 'environment': settings,
           'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
           'exit_code': result.returncode, 'seconds': time.monotonic() - started,
           'source_hashes': inputs, 'changed_inputs': changed,
           'scope': 'Eight explicit current affected GSHC software files, not the full application suite or hardware communication; earlier 80-pass command was not retained in a standalone receipt and is not reconstructed from counts.'}
(work / ('root/' + BATCH + '-receipt.json')).write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'exit_code': result.returncode, 'seconds': receipt['seconds'], 'inputs': len(inputs), 'changed': changed}))
raise SystemExit(result.returncode or bool(changed))
