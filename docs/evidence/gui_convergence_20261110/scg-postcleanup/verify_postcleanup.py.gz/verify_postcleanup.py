"""One normal generated research Release after cleanup; no source/gate edits."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

repo = Path('D:/python_software/SilverStar')
work = Path(__file__).resolve().parent
out = work / 'post-cleanup-research'
logs = work / 'post-cleanup-research-validation'
assert not out.exists() and not logs.exists()
logs.mkdir()
model = repo / '.work/gui-convergence-20261110/integration/research.ssproject'
gcc = Path('D:/Arm GNU Toolchain/14.3 rel1/bin')
host = Path('D:/msys64/ucrt64/bin')
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONUTF8='1')
env['PATH'] = os.pathsep.join((str(gcc), str(host), str(Path(sys.executable).parent),
                             env['PATH']))


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


record = {'source_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo,
                                                text=True).strip(),
          'configuration': 'research / STM32F407 / Release; one normal generated project',
          'model': str(model), 'model_sha256': digest(model),
          'hardware_tested': False, 'source_or_gate_modified': False,
          'commands': [], 'tools': {}}
for name, command in {
    'arm_gcc': [str(gcc / 'arm-none-eabi-gcc.exe'), '--version'],
    'make': [str(host / 'mingw32-make.exe'), '--version'],
    'python': [sys.executable, '--version'],
}.items():
    version = subprocess.run(command, env=env, capture_output=True, text=True, check=True)
    record['tools'][name] = version.stdout.splitlines()[0]
project = out / 'research/Flight_Controller'
commands = [('generate', [sys.executable, '-B',
             str(repo / 'apps/SCG/tools/validation/generate_stack_review_cases.py'),
             str(out), '--case', 'research', '--research-model', str(model)])]
for target in ('all', 'artifact-check', 'stack-report'):
    commands.append((target, [str(host / 'mingw32-make.exe'), '-C', str(project), '-j2',
                     'CONFIG=Release', 'GCC_PATH=' + str(gcc),
                     'PYTHON=' + sys.executable, target]))
for name, command in commands:
    log = logs / (name + '.log')
    start = time.monotonic()
    with log.open('w', encoding='utf8') as stream:
        result = subprocess.run(command, cwd=repo, env=env, stdout=stream,
                                stderr=subprocess.STDOUT, timeout=1200)
    record['commands'].append({'name': name, 'argv': command, 'cwd': str(repo),
                               'exit': result.returncode,
                               'seconds': round(time.monotonic() - start, 3),
                               'log': str(log), 'log_sha256': digest(log)})
    (logs / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf8')
    print(name, result.returncode, flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
assert digest(model) == record['model_sha256']
record['model_unchanged'] = True
record['output_bytes'] = sum(path.stat().st_size for path in out.rglob('*') if path.is_file())
record['artifacts'] = [dict(path=str(path), size=path.stat().st_size, sha256=digest(path))
                       for path in project.rglob('*')
                       if path.is_file() and (path.suffix in {'.elf', '.map'}
                       or path.name in {'memory-report.json', 'stack-report.json'})]
(logs / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf8')
print(json.dumps({'output_bytes': record['output_bytes'],
                  'receipt': str(logs / 'receipt.json')}), flush=True)
