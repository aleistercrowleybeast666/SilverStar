"""Read-only inventory; no traversal through links and no cleanup actions."""
import datetime
import json
import os
from pathlib import Path
import stat
import subprocess

OUTPUT = Path(__file__).parent / 'inventory-after.json'
ROOTS = [Path('D:/python_software') / name for name in (
    'SilverStar', 'Underline_RETLDC', 'TreeDiagram', 'SilverStar_FCCG',
    'SilverStar_GSHC', 'SilverStar_FLP', 'SilverStar_GSHC_Android')]

def git(root, *args):
    result = subprocess.run(['git', '-C', str(root), *args], capture_output=True, text=True)
    return {'exit': result.returncode, 'output': result.stdout, 'error': result.stderr}

def measure(root):
    counts = {}; links = []; errors = []; total_files = 0
    pending = [(str(root), ())]
    while pending:
        directory, parts = pending.pop()
        try:
            with os.scandir(directory) as entries:
                for entry in entries:
                    info = entry.stat(follow_symlinks=False)
                    if (entry.is_symlink() or getattr(info, 'st_file_attributes', 0)
                            & stat.FILE_ATTRIBUTE_REPARSE_POINT):
                        links.append(entry.path); continue
                    relative = (*parts, entry.name)
                    if stat.S_ISDIR(info.st_mode):
                        pending.append((entry.path, relative)); continue
                    if not stat.S_ISREG(info.st_mode):
                        links.append(entry.path); continue
                    key = '/'.join(relative[:2]) if len(relative) > 2 else relative[0]
                    row = counts.setdefault(key, {'files': 0, 'logical_bytes': 0})
                    row['files'] += 1; row['logical_bytes'] += info.st_size
                    total_files += 1
                    if total_files % 100000 == 0:
                        print(root.name, 'scanned', total_files, 'files', flush=True)
                        (OUTPUT.parent / 'inventory-after-progress.json').write_text(json.dumps({
                            'root': str(root), 'files': total_files, 'groups': counts,
                            'pending_directories': len(pending)}, ensure_ascii=False), encoding='utf8')
        except OSError as exc: errors.append(str(exc))
    return {'groups': counts, 'links_not_followed': links, 'errors': errors,
            'logical_bytes': sum(row['logical_bytes'] for row in counts.values())}

result = {'started': datetime.datetime.now().astimezone().isoformat(), 'roots': []}
for root in ROOTS:
    row = {'path': str(root), 'inventory': measure(root)}
    if (root / '.git').exists():
        row['status'] = git(root, 'status', '--short', '--branch')
        row['refs'] = git(root, 'show-ref')
        row['remotes'] = git(root, 'remote', '-v')
    result['roots'].append(row)
    OUTPUT.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf8')
    print(root.name, row['inventory']['logical_bytes'], flush=True)
result['finished'] = datetime.datetime.now().astimezone().isoformat()
OUTPUT.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf8')
