"""Read completed cleanup receipts; never delete files or infer pending removals.

Run once during packaging, then rerun with --final after final cleanup and
inventory_after.py. Receipt archive hashes are provenance, not a new bulk rehash.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path("D:/python_software/SilverStar")
TASK = ROOT / ".work/gui-convergence-20261110/root"
EVIDENCE = ROOT / "docs/evidence/gui_convergence_20261110"
ARCHIVE = Path("D:/SilverStar_Archive/20261110")
UL = Path("D:/python_software/Underline_RETLDC")
TD = Path("D:/python_software/TreeDiagram")
UL_CLEAN = UL / "docs/evidence/gui_convergence_20261110/cleanup"
TD_CLEAN = TD / "docs/evidence/gui_convergence_20261110/cleanup"
sources, batches, archives, exact_paths, prefix_scopes = {}, [], {}, {}, []


def now():
    return datetime.now(timezone.utc).isoformat()


def identity(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def read(path):
    path = Path(path)
    data = path.read_bytes()
    sources[str(path)] = {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
    return json.loads(data.decode("utf-8-sig"))


def canonical(path):
    return str(path).replace("\\", "/").rstrip("/").casefold()


def add_archive(path, size, sha, restoration, category="payload", **details):
    path = Path(path)
    key = canonical(path)
    row = {"path": str(path), "bytes": int(size), "sha256": sha.lower(),
           "category": category, "restoration_scope": restoration,
           "hash_basis": "completed producer receipt; aggregator does not rehash large archives",
           "exists_at_summary": path.is_file(), **details}
    row["size_matches_at_summary"] = path.stat().st_size == size if path.is_file() else False
    if key in archives:
        assert archives[key]["bytes"] == row["bytes"] and archives[key]["sha256"] == row["sha256"]
    else:
        archives[key] = row
    return str(path)


def add_batch(name, byte_count, file_count, retained, receipt, status="completed", **details):
    row = {"id": name, "status": status, "logical_deleted_bytes": int(byte_count),
           "removed_file_or_path_count": int(file_count), "retained_or_limited": retained,
           "receipt": str(receipt), **details}
    batches.append(row)
    return row


def claim(name, root, entries, expected):
    total = 0
    for relative, size in entries:
        key = canonical(Path(root) / relative)
        if key in exact_paths:
            raise RuntimeError(f"overlapping logical deletion: {name} and {exact_paths[key]}: {key}")
        exact_paths[key] = name
        total += int(size)
    if total != int(expected):
        raise RuntimeError(f"receipt/manifest byte mismatch in {name}: {total} != {expected}")


def journal(path):
    path = Path(path)
    data = path.read_bytes()
    sources[str(path)] = {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
    return [json.loads(line) for line in data.decode("utf-8-sig").splitlines() if line]


def collect_retired():
    receipt = EVIDENCE / "retirement.json"
    retired = read(receipt)
    tip_source = retired["retirement_tip_receipt"]
    tips = read(Path(tip_source["path"]))
    recorded_tip_source = sources[str(Path(tip_source["path"]))]
    assert recorded_tip_source["bytes"] == tip_source["size"]
    assert recorded_tip_source["sha256"] == tip_source["sha256"]
    tips_by_name = {row["repository"]: row for row in tips}
    assert len(tips_by_name) == len(tips)
    for row in retired["repositories"]:
        name = "old_checkout/" + row["repository"]
        restored, deleted = row["archive_restore"], row["deletion"]
        archive_path = add_archive(restored["archive"], restored["archive_bytes"],
            restored["archive_sha256"], restored["restoration"],
            distinct_contents_restored=restored["distinct_contents_restored"],
            external_verified_files=restored.get("external_verified_files", 0),
            manifest=row["manifest"])
        kept = {"original_skipped_count": len(deleted.get("original_skipped", [])),
                "changed_or_denied_count": len(deleted.get("changed_or_denied", [])),
                "root_absent": deleted.get("root_absent"),
                "reason": "Unreadable paths and reparse points were retained without ACL changes or traversal; exact paths remain in retirement.json."}
        if "removed_logical_bytes" not in deleted:
            add_batch(name, 0, 0, kept, receipt, status="pending", archive=archive_path)
            continue
        add_batch(name, deleted["removed_logical_bytes"], deleted["removed_files"], kept,
            receipt, archive=archive_path, detailed_receipt=deleted["complete_receipt"])
        prefix_scopes.append((canonical(restored["source"]), name))
        if "git_history" in row:
            history = row["git_history"]
            add_archive(history["bundle"], history["bundle_bytes"], history["bundle_sha256"],
                "Git refs and tree restored from bundle; retained mirror is additional unmeasured storage.",
                category="git_bundle", mirror=history["mirror"],
                all_refs_restored=history["all_refs_restored"], tree_restored=history["tree_restored"])
            tip = row["retirement_tip"]
            assert tip == {key: value for key, value in tips_by_name[row["repository"]].items()
                           if key != "repository"}
            assert tip["restore_verified"]
            add_archive(tip["bundle"], tip["bundle_bytes"], tip["bundle_sha256"],
                "Final archived remote main/README tip restored from its separate migration-tip bundle; original refs remain in the original bundle.",
                category="retirement_tip_bundle", retirement_main=tip["retirement_main"],
                readme_sha256=tip["readme_sha256"], restore_verified=tip["restore_verified"])


def collect_cold_scg_flp():
    path = EVIDENCE / "cold_archive_manifest.json"
    cold = read(path)
    deleted = cold["deletion_receipt"]
    assert cold["source_deleted"] and cold["restored_and_verified"]
    archive = add_archive(cold["archive"], cold["archive_bytes"], cold["archive_sha256"],
        "All 44 historical evidence files physically restored and SHA verified; fixed-commit original references retained.")
    add_batch("cold_evidence", deleted["logical_bytes"], deleted["count"], cold["scope"], path, archive=archive)
    claim("cold_evidence", ROOT, ((r["path"], r["size"]) for r in cold["files"]), deleted["logical_bytes"])

    path = EVIDENCE / "scg-cleanup.json"
    scg = read(path)
    result, arc = scg["result"], scg["result"]["archive"]
    assert scg["delete_exit"] == 0 and scg["journal_reconciled"] and not result["errors"]
    archive = add_archive(arc["archive"], arc["archive_bytes"], arc["archive_sha256"],
        arc["restoration"], distinct_contents_restored=arc["distinct_contents_restored"])
    add_batch("scg_generated_copies", result["deleted_bytes"], result["deleted_files"],
        {"complete_trees": result["preserved_complete_trees"],
         "retained_files_sha_verified": result["retained_files_sha_verified"],
         "reason": "Required current builds, raw logs, decoders, archives, source fixtures and input directories retained."},
        path, archive=archive)
    claim("scg_generated_copies", ROOT / ".work/gui-convergence-20261110/scg",
        ((r["path"], r["size"]) for r in journal(Path(result["deleted_paths_journal"]))), result["deleted_bytes"])

    folder = ARCHIVE / "task/flp-duplicates"
    path = folder / "cleanup-result.json"
    flp = read(path)
    arc = flp["archive"]
    assert not flp["errors"]
    archive = add_archive(arc["archive"], arc["archive_bytes"], arc["archive_sha256"],
        "614 unique contents physically restored to disk and reread; 940 retained full2 copies rechecked after deletion.",
        unique_contents_restored=arc["unique_objects_physically_restored_and_sha_verified"])
    add_batch("flp_duplicate_outputs", flp["deleted_bytes"], flp["deleted_files"],
        "Only identical old PNG/CSV outputs removed; full2, unique results, raw logs, decoders, archives, fixtures and necessary failure reproductions remain.", path, archive=archive)
    claim("flp_duplicate_outputs", ROOT / ".work",
        ((r["path"], r["size"]) for r in journal(folder / "deleted-files.jsonl")), flp["deleted_bytes"])


def collect_application_caches():
    path = UL_CLEAN / "applied.json"
    applied = read(path)
    plan_rows = {}
    for index in range(len(applied["results"])):
        for row in read(UL_CLEAN / f"plan-{index}.json")["records"]:
            plan_rows[row["path"]] = row["size"]
    entries = [(p, plan_rows[p]) for result in applied["results"] for p in result["removed_paths"]]
    assert applied["all_protected_hashes_unchanged"]
    add_batch("underline_caches", applied["logical_bytes_removed"], len(entries),
        f"{applied['protected_files']} protected input hashes unchanged; caches reproduced by normal tools; no payload archive claimed.", path)
    claim("underline_caches", UL, entries, applied["logical_bytes_removed"])

    for name, repo, receipt, plan in (
        ("treediagram_caches", TD, TD_CLEAN / "receipt.json", TD_CLEAN / "reviewed-plan.json"),
        ("gshc_caches", ROOT, EVIDENCE / "cache_cleanup.json", TASK / "gshc-cache-reviewed.json"),
    ):
        result, selected = read(receipt), read(plan)
        assert result["result"] == "applied" and result["repeat_removed"] == 0
        assert len(selected["records"]) == result["removed_paths"]
        add_batch(name, result["logical_bytes"], result["removed_paths"],
            result.get("retained_unowned", "Protected source/input hashes verified; no cache payload archive claimed."), receipt)
        claim(name, repo, ((r["path"], r["size"]) for r in selected["records"]), result["logical_bytes"])


def collect_deliveries_worktree():
    path = UL_CLEAN / "prefit-retirement.json"
    data = read(path)
    assert not data["failures"] and data["protected_inputs_unchanged"]
    for arc in data["archives"]:
        add_archive(arc["path"], arc["size"], arc["sha256"], data["physical_restore"])
    add_batch("underline_old_package", data["logical_bytes_removed"], data["removed_files"],
        {"final_candidate": data["final_candidate_retained"],
         "protected_input_count": data["protected_source_input_count"]}, path)
    raw = read(ARCHIVE / "task/underline/RETIREMENT_RECEIPT.json")
    claim("underline_old_package", UL, ((r["path"], r["size"]) for r in raw["removed_files"]), data["logical_bytes_removed"])

    path = TD / "docs/evidence/gui_initial_frame_20261111/old-wheel-archive.json"
    wheel = read(path)
    assert wheel["old_wheel_removed"]
    add_archive(wheel["archive"], wheel["old_wheel_logical_bytes"], wheel["sha256"],
        f"Actual wheel extraction verified {wheel['actual_extracted_and_verified']} files; restored temporary copies subsequently removed.")
    add_batch("treediagram_old_wheel", wheel["old_wheel_logical_bytes"], 1,
        "Final wheel, source and formal test evidence retained; archive keeps original wheel bytes.", path)
    claim("treediagram_old_wheel", TD, [(str(Path(wheel["old_path"]).relative_to(TD)), wheel["old_wheel_logical_bytes"])], wheel["old_wheel_logical_bytes"])

    path = EVIDENCE / "worktree_cleanup.json"
    wt = read(path)
    assert wt["exit_code"] == 0 and wt["path_absent"] and wt["contained_in_current_history"]
    add_batch("merged_worktree", wt["logical_bytes"], wt["file_count"],
        "Clean including ignored files, merged into current history; Git history retained, no standalone payload archive claimed.", path,
        worktree=wt["path"], head=wt["head"], inventory_sha256=wt["inventory_sha256"])
    prefix_scopes.append((canonical(wt["path"]), "merged_worktree"))


def collect_packages():
    for name in ("silverstar-packages", "silverstar-packages-long-path", "silverstar-final-build"):
        folder = ARCHIVE / "task" / name
        result_path, proof_path = folder / "cleanup-result.json", folder / "archive-verified.json"
        proof = read(proof_path) if proof_path.exists() else None
        archive = None
        if proof is not None:
            archive = add_archive(folder / "superseded-packages.zip", proof["archive_bytes"],
                proof["archive_sha256"], proof["restore_scope"],
                unique_contents_restored=proof["unique_objects_restored_to_disk_and_read_back"])
        if not result_path.exists():
            add_batch(name, 0, 0,
                "Current final runtime/ZIP, all input inventories, source and formal evidence retained.",
                result_path, status="pending", archive=archive,
                pending_reason="Archive verified; deletion receipt absent" if proof else "Archive verification and deletion receipts absent",
                planned_logical_bytes=proof["logical_bytes"] if proof else None)
            continue
        result = read(result_path)
        if proof is None:
            raise RuntimeError(f"cleanup result without archive proof: {name}")
        rows = journal(folder / "delete-journal.jsonl")
        assert len(rows) == result["removed_files"]
        status = "completed" if not result["errors"] else "partial_with_errors"
        add_batch(name, result["logical_bytes"], result["removed_files"],
            "Current final runtime/ZIP, source, licenses, raw evidence and input inventories retained.",
            result_path, status=status, archive=archive, errors=result["errors"])
        claim(name, ROOT, ((r["path"], r["bytes"]) for r in rows), result["logical_bytes"])


def inventory_summary(path):
    if not path.exists():
        return {"status": "pending", "path": str(path)}
    data = read(path)
    result = {"status": "completed" if data.get("finished") else "pending",
              "started": data.get("started"), "finished": data.get("finished"), "roots": []}
    for row in data["roots"]:
        inv = row["inventory"]
        git_bytes = sum(v["logical_bytes"] for k, v in inv["groups"].items() if k == ".git" or k.startswith(".git/"))
        result["roots"].append({"path": row["path"], "logical_bytes": inv["logical_bytes"],
            "git_database_logical_bytes": git_bytes, "links_not_followed_count": len(inv["links_not_followed"]),
            "error_count": len(inv["errors"]),
            "missing_root_only": (len(inv["errors"]) == 1 and not inv["groups"]
                                  and not inv["links_not_followed"]
                                  and inv["errors"][0].startswith("[WinError 3]")),
            "no_readable_groups": not bool(inv["groups"])})
    return result


def main(final_requested):
    collect_retired()
    collect_cold_scg_flp()
    collect_application_caches()
    collect_deliveries_worktree()
    collect_packages()
    for index, (prefix, name) in enumerate(prefix_scopes):
        for other, other_name in prefix_scopes[index + 1:]:
            if prefix == other or prefix.startswith(other + "/") or other.startswith(prefix + "/"):
                raise RuntimeError(f"overlapping prefix scopes: {name}, {other_name}")
        for path, owner in exact_paths.items():
            if path == prefix or path.startswith(prefix + "/"):
                raise RuntimeError(f"overlap between prefix {name} and exact manifest {owner}")
    before = inventory_summary(TASK / "inventory-before.json")
    after = inventory_summary(TASK / "inventory-after.json")
    tracked_before = read(TASK / "tracked-before.json")
    tracked_names = subprocess.check_output(["git", "ls-files", "-z"], cwd=ROOT).decode("utf8").split("\0")
    tracked_sizes, missing = [], []
    for name in filter(None, tracked_names):
        path = ROOT / name
        if path.is_file():
            tracked_sizes.append(path.stat().st_size)
        else:
            missing.append(name)
    resume = read(TASK / "resume-disks.json")
    measured = now()
    disks = {volume: dict(zip(("total", "used", "free"), shutil.disk_usage(volume))) for volume in resume["drives"]}
    for volume, row in disks.items():
        row["single_interval_free_delta_since_resume"] = row["free"] - resume["drives"][volume]["free"]
    pending = [r["id"] for r in batches if r["status"] != "completed"]
    final = final_requested and not pending and after["status"] == "completed"
    result = {
        "schema": "silverstar.gui-convergence-cleanup-summary/1", "generated_utc": measured,
        "script": identity(Path(__file__)), "source_head_at_summary": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
        "state": "final_receipts_collected" if final else "interim_pending_final_collection",
        "pending_batches": pending, "final_requested": final_requested,
        "logical_deletion": {"bytes": sum(row["logical_deleted_bytes"] for row in batches),
            "file_or_path_count": sum(row["removed_file_or_path_count"] for row in batches),
            "nonoverlap": {"exact_manifest_paths_checked": len(exact_paths),
                "disjoint_checkout_or_worktree_prefixes": [{"path": p, "batch": n} for p, n in prefix_scopes],
                "duplicates_or_overlapping_prefixes": 0},
            "scope": "Actual producer-receipted logical removals only; no planned bytes, restored temporary copies, empty directories or physical free deltas added."},
        "batches": batches,
        "archive_storage": {"named_archive_bytes": sum(r["bytes"] for r in archives.values()),
            "named_archive_count": len(archives), "archives": list(archives.values()),
            "limits": "Unique archive paths counted once. Retained mirrors, external Android toolchains/keys, manifests and auxiliary files are not included in this named-archive subtotal. No claim of net disk space reclaimed."},
        "working_tree_inventory": {"before": before, "after": after,
            "limits": "Read-only directory snapshots include concurrent builds, generated output and Git data; differences are not attributed exclusively to cleanup. Error/link scopes remain explicit."},
        "tracked_working_files": {"baseline": {"bytes": tracked_before["total"], "files": len(tracked_before["files"])},
            "current": {"bytes": sum(tracked_sizes), "readable_files": len(tracked_sizes), "missing_tracked_paths": missing},
            "limits": "Git-index-listed working files, not Git history or object database. No history rewrite, pack-size reduction or remote repository shrinking is claimed."},
        "physical_free_space": {"resume_observation": resume, "current_observed_utc": measured,
            "current_observation_is_final": final, "current_drives": disks,
            "limits": "Resume at 2026-11-11 19:18:15 +08 is not original task start. Only this one resume-to-current interval is shown per volume; concurrent builds/archives/cleanup and other writes prevent exclusive attribution. Per-batch free-space intervals are never added."},
        "source_receipts": list(sources.values()),
        "unmeasured_or_retained": [
            "Old FLP reparse points and old FCCG denied paths remain; exact counts/reasons in batch receipts.",
            "Android shell backup also relies on 16802 exact externally retained tool/key files referenced by its original manifest; shell ZIP alone is not a full restore set.",
            "Empty abandoned silverstar-packages-interrupted-fit archive directory has no completed receipt and contributes no archived/deleted bytes.",
            "Final runtime candidates, raw logs, decoder packages, source fixtures, immutable evidence and historical Git data remain protected."]}
    output = EVIDENCE / "cleanup_summary.json"
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf8")
    print(json.dumps({"output": str(output), "state": result["state"],
        "logical_deleted_bytes": result["logical_deletion"]["bytes"],
        "named_archive_bytes": result["archive_storage"]["named_archive_bytes"],
        "pending": pending, "inventory_after": after["status"]}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--final", action="store_true", help="Label final only when receipts and final inventory are complete")
    main(parser.parse_args().final)
