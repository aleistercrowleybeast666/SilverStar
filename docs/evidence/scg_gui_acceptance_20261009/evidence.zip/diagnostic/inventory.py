from pathlib import Path
import hashlib,json,zipfile
root=Path(r'D:\stm32_project\SS_0_5_TEST_FINAL')
result={'candidate_only':True,'root':str(root),'files':[]}
for path in [root/'SilverStar.ssproject',root/'Flight_Controller/SilverStar.ssproject',root/'SS_0_5_TEST_FINAL.ssdecoder',*sorted((root/'Flight_Controller/build').rglob('*.elf')),*sorted((root/'Flight_Controller/build').rglob('*.bin'))]:
    before=path.stat(); data=path.read_bytes(); after=path.stat()
    item={'path':str(path),'size':len(data),'sha256':hashlib.sha256(data).hexdigest(),'mtime_ns':after.st_mtime_ns,'stable_during_read':(before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns)}
    if path.suffix=='.ssproject':
        obj=json.loads(data)
        item.update(format_version=obj.get('format_version'),project=obj.get('project'),components=obj.get('components'),build=obj.get('build'),ground_target=obj.get('ground_target'),protocols=obj.get('protocols'))
    elif path.suffix=='.ssdecoder':
        item['zip_file']=zipfile.is_zipfile(path)
        if item['zip_file']:
            with zipfile.ZipFile(path) as archive:
                item['members']=archive.namelist()
                for name in archive.namelist():
                    if name.endswith('manifest.json'): item['manifest']=json.loads(archive.read(name))
                checked=[]
                for line in archive.read('checksums.sha256').decode().splitlines():
                    digest,name=line.split(maxsplit=1)
                    name=name.lstrip('*')
                    checked.append({'name':name,'matches':hashlib.sha256(archive.read(name)).hexdigest()==digest})
                item['internal_checksums']=checked
    result['files'].append(item)
result['ground_files']=[str(p.relative_to(root)) for p in (root/'Ground_Station').iterdir()]
decoder=next(item for item in result['files'] if item['path'].endswith('.ssdecoder'))
manifest=decoder.get('manifest',{})
for item in result['files']:
    if item['path'].endswith(('.elf','.bin')):
        data=Path(item['path']).read_bytes()
        item['decoder_hash128_prefix_presence']={key:bytes.fromhex(manifest[key])[:16] in data
            for key in ('generation_profile_sha256','record_catalog_sha256','project_semantics_sha256') if key in manifest}
out=Path(__file__).with_name('candidate_inventory.json')
out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='files'},ensure_ascii=False))
for item in result['files']:
    print(json.dumps({k:v for k,v in item.items() if k not in {'components','ground_target','protocols','build','manifest'}},ensure_ascii=False))
