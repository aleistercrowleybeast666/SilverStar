from pathlib import Path
import sys
repo=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(repo/'apps/SCG/src'),str(repo/'apps/SCG/tests')]
from dataclasses import replace
from types import SimpleNamespace
from PySide6.QtWidgets import QApplication,QMessageBox,QScrollArea
from PySide6.QtGui import QFont,QFontDatabase
from PySide6.QtCore import QCoreApplication,QEvent
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.core.settings import SettingsStore
from silverstar_fccg.ui.main_window import MainWindow
from test_f103_ground_reference import _GroundF103Model_Get
out=repo/'apps/SCG/.work/gui_acceptance_20261009/visual_qa'
out.mkdir(parents=True,exist_ok=True)
app=QApplication([])
for name in ('msyh.ttc','msyhbd.ttc','segoeui.ttf'):
    path=Path(r'C:\Windows\Fonts')/name
    if path.is_file(): QFontDatabase.addApplicationFont(str(path))
app.setFont(QFont('Microsoft YaHei',10))
window=MainWindow(SettingsStore(out/'private.ini'),service=FccgService(repo/'apps/SCG'))
window._MessageBox_Exec=lambda *args,**kwargs: QMessageBox.StandardButton.Discard
window.resize(1500,1050)
window.show()
window._model=_GroundF103Model_Get(window._service.catalog)
window._model.ground_target=replace(window._model.ground_target,activity_led_enabled=True)
window._Project_Refresh()
page=window.ground_target_page
page.advanced_section.toggle_button.setChecked(True)
window.pages.setCurrentWidget(window.air_link_page)
app.processEvents()
QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete)
scroll=window.air_link_page.findChild(QScrollArea)
scroll.verticalScrollBar().setValue(scroll.verticalScrollBar().maximum())
app.processEvents()
window.grab().save(str(out/'ground_radio_pass_led_pending.png'))
ground=window._model.ground_target
window._model.ground_target=replace(ground,resource_assignments={k:v for k,v in ground.resource_assignments.items() if k!='radio0:radio_bus'})
window._Project_Refresh()
app.processEvents()
QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete)
window.grab().save(str(out/'ground_missing_radio_red.png'))
window.pages.setCurrentWidget(window.build_page)
window.build_page.advanced_section.toggle_button.setChecked(True)
window.build_page.QualityResults_Set((SimpleNamespace(task='power10_check',result='passed',summary='NOT_PROVEN',timestamp='synthetic GUI QA',duration=0),))
app.processEvents()
scroll=window.build_page.findChild(QScrollArea)
scroll.verticalScrollBar().setValue(scroll.verticalScrollBar().maximum())
app.processEvents()
window.grab().save(str(out/'power10_automatic_pass_manual_pending.png'))
window._project_state=type(window._project_state).DRAFT
window.close()
app.processEvents()
print('3 private offscreen screenshots saved; synthetic UI state only')
