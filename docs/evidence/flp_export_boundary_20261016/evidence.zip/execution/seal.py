"""Small export-only evidence; frozen navigation and input bytes stay unchanged."""
import ast
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import zipfile

TASK=Path(__file__).resolve().parent
ROOT=TASK.parents[1]
FORMAL=ROOT/'docs/evidence/flp_export_boundary_20261016'
FORMAL.mkdir(exist_ok=False)
paths=['apps/FLP/src/silverstar_flp/export/service.py',
 'apps/FLP/src/silverstar_flp/ui/main_window.py',
 'apps/FLP/tests/test_export_without_navigation.py',
 'docs/public/FLP/EXPORT_WITHOUT_NAVIGATION_FIX_20261016.md']
frozen=json.loads((ROOT/'docs/evidence/navigation_receipt_default_off_20261016/validation.json').read_text())
assert all(sha256((ROOT/p).read_bytes()).hexdigest()==h for p,h in frozen['source_sha256'].items())
assert all(sha256((ROOT/p).read_bytes()).hexdigest()==h for p,h in frozen['protected_inputs_sha256'].items())
result=json.loads((TASK/'final04.json').read_text())
assert result['exit_code']==0 and '100 passed' in (TASK/'final04.log').read_text()
scope=json.loads((TASK/'whole_file_scope_final.json').read_text())
assert all(scope['all_other_AST_nodes_equal'].values())
entries={}
with zipfile.ZipFile(FORMAL/'evidence.zip','x',zipfile.ZIP_DEFLATED) as archive:
    for relative in paths:
        path=ROOT/relative;raw=path.read_bytes();archive.writestr('current/'+relative,raw)
        entries['current/'+relative]=sha256(raw).hexdigest()
    for path in sorted(TASK.iterdir()):
        if path.is_file() and (path.suffix in ('.json','.log','.py','.md') or path.name.endswith('_runner_sources.zip')):
            raw=path.read_bytes();archive.writestr('execution/'+path.name,raw)
            entries['execution/'+path.name]=sha256(raw).hexdigest()
    # Actual manifests/CSV/inputs/metadata are small; keep binary plot assets
    # in their registered local test directory with a complete hash inventory.
    outputs={}
    for path in sorted((TASK/'final04').rglob('*')):
        if not path.is_file():continue
        key=path.relative_to(TASK).as_posix();outputs[key]=dict(sha256=sha256(path.read_bytes()).hexdigest(),bytes=path.stat().st_size)
        if path.suffix in ('.json','.csv','.txt','.sslog','.ssdecoder','.BIN'):
            raw=path.read_bytes();archive.writestr('outputs/'+key,raw)
            entries['outputs/'+key]=sha256(raw).hexdigest()
manifest=dict(owner='/root FLP export boundary',utc=datetime.now(timezone.utc).isoformat(),
    base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    status='SCOPED_EXPORT_FIX_100_TESTS_PASSED',test_command=result['command'],
    exit_code=result['exit_code'],before_result='8 failed, 1 passed',
    before_sources_file='execution/before_sources.json',
    source_sha256={p:sha256((ROOT/p).read_bytes()).hexdigest() for p in paths},
    frozen_navigation_sha256=frozen['source_sha256'],
    protected_inputs_sha256=frozen['protected_inputs_sha256'],
    scope_audit=scope,entries=entries,final_outputs=outputs,
    archive_sha256=sha256((FORMAL/'evidence.zip').read_bytes()).hexdigest(),
    limitations=['Not the full FLP suite or full manual GUI acceptance.',
        'No navigation/firmware/decoder/math changes or hardware operations.',
        'Active recovery remains blocked and incomplete; frozen prior evidence unchanged.'])
(FORMAL/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
(TASK/'owned_paths.json').write_text(json.dumps(paths+[p.relative_to(ROOT).as_posix() for p in FORMAL.iterdir()],indent=2),encoding='utf8')
print('sealed',len(entries),'evidence entries,',len(outputs),'output hashes;', (FORMAL/'evidence.zip').stat().st_size,'bytes')
