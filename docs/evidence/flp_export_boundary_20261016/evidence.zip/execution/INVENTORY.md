# FLP export boundary / 0.1.3 /2026-10-16
Owner /root. Scope: FLP export/service.py, UI export entry, dedicated tests and new FLP report/evidence. Frozen navigation, USB/GSHC/showcase unchanged. Preserve exact decoder/log bytes. Unique test outputs and before/after source snapshots retained here; no cleanup authorized.
