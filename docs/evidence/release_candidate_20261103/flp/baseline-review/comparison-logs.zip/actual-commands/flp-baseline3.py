from pathlib import Path
import subprocess,sys,os,json,hashlib
repo=Path.cwd(); w=Path(__file__).resolve().parent;tmp=w/'flp-baseline';base=tmp/'repo';commit='8a25f99e7096df94cbf46b83bf4049a55e43a887'
for name in subprocess.check_output(['git','ls-tree','-r','--name-only',commit,'tools'],text=True).splitlines():
 if Path(name).parent.as_posix()=='tools' and Path(name).name.startswith('silverstar_') and name.endswith('.py'):
  out=base/name;out.parent.mkdir(exist_ok=True);out.write_bytes(subprocess.check_output(['git','show',commit+':'+name]))
nodes=json.loads((tmp/'nodes.json').read_text(encoding='utf8'))
for name,root,ids,dest in [('baseline3',base,nodes,tmp/'tmp-base003'),('short-base',base,[i for i in nodes if 'audit_block' in i or 'cache_generation' in i],w/'fb'),('short-now',repo,[i for i in nodes if 'audit_block' in i or 'cache_generation' in i],w/'fn')]:
 env=dict(os.environ);env['QT_QPA_PLATFORM']='offscreen';env['PYTHONPATH']=os.pathsep.join(str(q) for q in [root/'apps/FLP/src',root/'apps/FLP',root/'apps/SCG/src']);cmd=[sys.executable,'-B','-u','-m','pytest','-vv','--tb=short','-o','cache_dir='+str(tmp/('cache-'+name)),'--basetemp='+str(dest),*ids];log=tmp/(name+'.log')
 with log.open('w',encoding='utf8') as stream: ret=subprocess.run(cmd,cwd=root/'apps/FLP',env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=600)
 (tmp/(name+'-receipt.json')).write_text(json.dumps({'command':cmd,'cwd':str(root/'apps/FLP'),'pythonpath':env['PYTHONPATH'],'source':commit if root==base else subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'exit':ret.returncode,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()},indent=2));print(name,ret.returncode,flush=True)
