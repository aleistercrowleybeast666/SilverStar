from pathlib import Path
import subprocess,os,sys,json,hashlib
root=Path.cwd();tmp=Path(__file__).resolve().parent/'flp-baseline';p=tmp/'repo';commit='8a25f99e7096df94cbf46b83bf4049a55e43a887'
for name in ('tools/silverstar_version.py','versions.json'):
 r=subprocess.run(['git','show',commit+':'+name],capture_output=True); 
 if r.returncode==0:
  dest=p/name;dest.parent.mkdir(exist_ok=True);dest.write_bytes(r.stdout)
chosen=json.loads((tmp/'nodes.json').read_text(encoding='utf8'));env=dict(os.environ);env['QT_QPA_PLATFORM']='offscreen';env['PYTHONPATH']=os.pathsep.join(str(q) for q in [p/'apps/FLP/src',p/'apps/FLP',p/'apps/SCG/src']);cmd=[sys.executable,'-B','-u','-m','pytest','-vv','--tb=short','-o','cache_dir='+str(tmp/'cache-baseline2'),'--basetemp='+str(tmp/'tmp-baseline2'),*chosen];log=tmp/'baseline2.log'
with log.open('w',encoding='utf8') as stream:ret=subprocess.run(cmd,cwd=p/'apps/FLP',env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=600)
(tmp/'baseline2-receipt.json').write_text(json.dumps({'cmd':cmd,'cwd':str(p/'apps/FLP'),'PYTHONPATH':env['PYTHONPATH'],'identity':commit,'exit':ret.returncode,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()},indent=2));print(ret.returncode)
