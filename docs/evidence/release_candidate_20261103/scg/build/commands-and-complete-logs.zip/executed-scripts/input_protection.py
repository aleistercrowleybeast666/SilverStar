from pathlib import Path
import json,hashlib,sys
from silverstar_fccg.plugins.catalog import PluginCatalog
from silverstar_fccg.core.workspace import WorkspacePolicy
from silverstar_fccg.hardware.cubemx import CubeMxImporter
from silverstar_fccg.hardware.cubemx import CubeMxImportError
repo=Path.cwd();tmp=Path(__file__).resolve().parent; out=tmp/'cube-input-protection';out.mkdir(exist_ok=False); import_root=out/'cache';importer=CubeMxImporter(WorkspacePolicy(import_root))
def hashes(path): return {p.relative_to(path).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(path.rglob('*')) if p.is_file()}
summary=[]
for label,src,want in [('native-cdc-source',Path('D:/Codex_Work/2026-10-08/task/usb-validation/cube-f407-usb'),False),('ordinary-uart-input',tmp/'matrix-v2/f407-sx1281/uart-f407',True)]:
 before=hashes(src); cache_before=hashes(import_root);result=False
 try:
  imported=importer.Project_Import(src,risk_acknowledged=True,target='ground');result=True; detail=imported.inventory.mcu_part
 except CubeMxImportError as error: detail=str(error)
 except ValueError as error: detail=str(error)
 assert want==result,(label,want,detail);after=hashes(src);assert before==after,label; delta=sorted(cache_before.keys() ^ hashes(import_root).keys());assert result or not delta,delta
 (out/(label+'-sha256.json')).write_text(json.dumps(before,indent=2),encoding='utf8');summary.append(dict(case=label,source=str(src),source_file_count=len(before),all_source_bytes_unchanged=before==after,import_accepted=result,detail=detail,snapshot_files_created=len(delta)));print(label,len(before),result,detail)
(out/'result.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
