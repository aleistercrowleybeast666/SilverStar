from pathlib import Path
import json,re,hashlib

def _Inputs_Get(root,flight):
 relevant={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.relative_to(root).parts[0] not in ('build','.git','.fccg') and (p.name=='Makefile' or p.suffix.lower() in ('.h','.inc','.s','.ld','.mk'))}
 if flight:
  raw=(root/'Generated/project_sources.mk').read_text(encoding='utf8'); block=re.search(r'(?ms)^C_SOURCES \+= \\\n(.*?)(?:\n\n|\Z)',raw)[1];src=[v.strip().removesuffix('\\').strip() for v in block.splitlines()]
 else:
  graph=json.loads((root/'Generated/ground_source_graph.json').read_text(encoding='utf8')); src=graph['sources']+graph['asm_sources'];relevant.add('Generated/ground_source_graph.json')
 relevant.update(p.relative_to(root).as_posix() for sub in ('Tools', 'Tests') for p in (root/sub).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix.lower() in ('.py','.ps1','.c','.h','.json','.mk','.md'))
 relevant.update(src)
 return {name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in sorted(relevant)}

def Compare(old,new,flight):
 before=_Inputs_Get(old,flight);after=_Inputs_Get(new,flight);changed={name:{'before':before.get(name),'after':after.get(name)} for name in sorted(set(before)|set(after)) if before.get(name)!=after.get(name)};return {'original':str(old),'current':str(new),'old_inputs':len(before),'new_inputs':len(after),'changed':changed,'policy':'All selected C/ASM, all headers/includes/linker scripts/Make declarations; any changed byte triggers actual per-target gates.'}
