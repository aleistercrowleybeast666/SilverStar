from pathlib import Path
import sys, subprocess, hashlib, json, traceback
repo=Path.cwd(); scg=repo/'apps/SCG';sys.path[:0]=[str(scg/'src'),str(scg/'tests')]
from test_round2_targets import _GroundBoardProject_Get
from sx1278_project_fixture import Sx1278Project_Create
from silverstar_fccg.plugins.catalog import PluginCatalog
from silverstar_fccg.core.workspace import WorkspacePolicy
from silverstar_fccg.generator.multi_target import TargetGeneration_Apply, TargetScope
out=repo/'.work/0.1.3-release-20261103/scg'/sys.argv[1];out.mkdir(exist_ok=False)
cat=PluginCatalog(scg/'plugins/builtin',scg/'plugins/installed');cat.Scan()
receipt={};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(): (out/'receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf8')
for tag in ('f407-sx1281','f407-sx1278'):
 case=out/tag;case.mkdir(); row=receipt[tag]={'commands':[]};save()
 try:
  model=_GroundBoardProject_Get(cat) if tag.endswith('1281') else Sx1278Project_Create(cat,case)
  TargetGeneration_Apply(model,cat,WorkspacePolicy(case),case/'project',TargetScope.FLIGHT)
  row['decoders']={p.relative_to(case).as_posix():sha(p) for p in case.rglob('*.ssdecoder')};row['generated']=True;save()
 except Exception: (case/'generation-failed.log').write_text(traceback.format_exc(),encoding='utf8');row['generated']=False;save()
for tag,row in receipt.items():
 if not row.get('generated'):continue
 case=out/tag; root=case/'project/Flight_Controller'
 for target in ('all','architecture-check','power10-check','static-analysis','artifact-check','stack-report'):
  cmd=['mingw32-make','-j2',target]; p=case/(target+'.log');print(tag,target,flush=True)
  try:
   with p.open('w',encoding='utf8') as log: exitcode=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=2400).returncode
  except subprocess.TimeoutExpired:exitcode='timeout_2400s'
  row['commands'].append({'cwd':str(root),'cmd':cmd,'exit':exitcode,'log_sha256':sha(p)});save()
 row['artifacts']={p.relative_to(root).as_posix():sha(p) for p in (root/'build').rglob('*') if p.suffix in ('.elf','.bin','.map','.json')};save()
