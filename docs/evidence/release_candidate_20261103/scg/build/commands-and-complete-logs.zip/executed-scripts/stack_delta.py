from pathlib import Path
import hashlib,json,re
base=Path(__file__).resolve().parent/'flight-v1'; results={}
for p in base.glob('*/project/Flight_Controller'):
 def sha(path):return hashlib.sha256(path.read_bytes().replace(b'\r\n',b'\n')).hexdigest()
 mk=(p/'Generated/project_sources.mk').read_text(encoding='utf8'); block=re.search(r'(?ms)^C_SOURCES \+= \\\n(.*?)(?:\n\n|\Z)',mk)[1];sources=[l.strip().removesuffix('\\').strip() for l in block.splitlines()];src={*sources,*(f.relative_to(p).as_posix() for f in p.rglob('*') if f.is_file() and f.suffix.lower() in ('.h','.inc','.s','.ld') and f.relative_to(p).parts[0] not in ('build','.git','.fccg'))};actual={s:sha(p/s) for s in src}; declarations={'Makefile',*(f.relative_to(p).as_posix() for f in p.rglob('*.mk') if f.relative_to(p).parts[0] not in ('build','.git','.fccg'))};declared={s:sha(p/s) for s in declarations}; review=json.loads((p/'Tools/software_stack_inputs.json').read_text());cs=[]
 for case in review['cases']:
  if case['target_profile']!='SilverStar_F407' or case['configuration']!='Release':continue
  old=case['source_inputs'];cs.append({'review_name':case['name'],'same_build_declarations':declared==case['build_declarations'],'modified':sorted(k for k in actual.keys()&old.keys() if actual[k]!=old[k]),'added':sorted(actual.keys()-old.keys()),'removed':sorted(old.keys()-actual.keys()),'sources_same':sorted(sources)==case['sources']})
 cs.sort(key=lambda r:(not r['same_build_declarations'],sum(len(r[k]) for k in ('modified','added','removed'))));results[p.parents[1].name]={'source_count':len(sources),'closure_inputs':len(src),'nearest_prior_review':cs[0]};print(p.parents[1].name,cs[0]['review_name'],cs[0]['same_build_declarations'],cs[0]['modified'][:12],cs[0]['added'][:5])
(base/'stack-closure-delta.json').write_text(json.dumps(results,indent=2),encoding='utf8')
