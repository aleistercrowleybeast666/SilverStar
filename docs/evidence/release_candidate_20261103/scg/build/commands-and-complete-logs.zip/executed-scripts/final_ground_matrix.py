import hashlib,json,re,shutil,subprocess,sys,traceback
from pathlib import Path
from dataclasses import replace
from copy import deepcopy
REPO=Path.cwd(); SCG=REPO/'apps/SCG';sys.path[:0]=[str(SCG/'src'),str(SCG/'tests')]
from silverstar_fccg.plugins.catalog import PluginCatalog
from silverstar_fccg.core.workspace import WorkspacePolicy
from silverstar_fccg.hardware.cubemx import CubeMxImporter
from silverstar_fccg.generator.multi_target import TargetGeneration_Apply,TargetScope
from silverstar_fccg.project.air_link import GroundTargetIssues_Get
from test_round2_targets import _GroundBoardProject_Get
from sx1278_project_fixture import Sx1278Project_Create,_Sx1278Input_Configure
ROOT=REPO/'.work/0.1.3-release-20261103/scg';out=ROOT/sys.argv[1];out.mkdir(exist_ok=False)
log=out/'receipt.json';rows=[];records=[]
def save():log.write_text(json.dumps({'cases':rows,'commands':records},indent=2),encoding='utf8')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,s):p.write_text(s,encoding='utf8')
def f407_input(dest,e32):
 src=Path('D:/Codex_Work/2026-10-08/task/usb-validation/cube-f407-usb')
 # Representative new UART-only input uses the exact vendor HAL, USART1 DMA, SPI and clock sources.
 # The original native reference is read only, never the output of this fixture.
 dest.mkdir();shutil.copytree(src/'Core',dest/'Core');shutil.copytree(src/'Drivers',dest/'Drivers')
 for n in ('startup_stm32f407xx.s','STM32F407XX_FLASH.ld','Package_license.md'):shutil.copy2(src/n,dest/n)
 raw=(src/'Makefile').read_text(encoding='utf-8-sig')
 logical=re.sub(r'\\\r?\n',' ',raw)
 def args(k):return re.search('(?m)^'+k+r'\s*=\s*([^\r\n]*)',logical)[1].split()
 source=[p for p in args('C_SOURCES') if not p.startswith(('USB_DEVICE/','Middlewares/ST/STM32_USB_Device_Library/')) and Path(p).name not in ('stm32f4xx_hal_pcd.c','stm32f4xx_hal_pcd_ex.c','stm32f4xx_ll_usb.c')]
 includes=[p for p in args('C_INCLUDES') if not p.startswith(('-IUSB_DEVICE/','-IMiddlewares/ST/STM32_USB_Device_Library/'))]
 write(dest/'Makefile','\n'.join(k+' = '+' '.join(v) for k,v in [('C_SOURCES',source),('C_INCLUDES',includes)]+[(k,args(k)) for k in ('ASM_SOURCES','LDSCRIPT','C_DEFS','CPU','FPU','FLOAT-ABI')])+'\n')
 ioc=next(src.glob('*.ioc')).read_text(encoding='utf-8-sig');ioc='\n'.join(l for l in ioc.splitlines() if not l.startswith(('Mcu.IP7=USB_DEVICE','Mcu.IP8=USB_OTG_FS','USB_DEVICE.','USB_OTG_FS.','NVIC.OTG_FS_IRQn','PA11.','PA12.','VP_USB_DEVICE')));ioc=re.sub(r'Mcu.IPNb=\d+','Mcu.IPNb=7',ioc);pins=re.findall(r'(?m)^Mcu.Pin\d+=(.+)$',ioc);pins=[p for p in pins if p not in ('PA11','PA12') and not p.startswith('VP_USB')];ioc=re.sub(r'(?m)^Mcu.Pin\d+=.*\n?','',ioc)
 if e32:pins+=['PC1','PC2']
 ioc=re.sub(r'Mcu.PinsNb=\d+','Mcu.PinsNb='+str(len(pins)),ioc)+'\n'+'\n'.join(f'Mcu.Pin{i}={p}' for i,p in enumerate(pins))+'\n'
 main=dest/'Core/Src/main.c';s=main.read_text(encoding='utf-8-sig');write(main,s.replace('#include "usb_device.h"','').replace('  MX_USB_DEVICE_Init();',''))
 irq=dest/'Core/Src/stm32f4xx_it.c';s=irq.read_text(encoding='utf-8-sig');s=re.sub(r'(?ms)^void OTG_FS_IRQHandler\(void\)\s*\{.*?^\}','',s).replace('extern PCD_HandleTypeDef hpcd_USB_OTG_FS;','');write(irq,s)
 header=dest/'Core/Inc/stm32f4xx_it.h';write(header,header.read_text(encoding='utf-8-sig').replace('void OTG_FS_IRQHandler(void);',''))
 conf=dest/'Core/Inc/stm32f4xx_hal_conf.h';write(conf,conf.read_text(encoding='utf-8-sig').replace('#define HAL_PCD_MODULE_ENABLED','/* PCD unused in UART-only validation fixture. */'))
 if e32:
  h=dest/'Core/Inc/main.h';g=dest/'Core/Src/gpio.c';header=h.read_text(encoding='utf-8-sig');gpio=g.read_text(encoding='utf-8-sig');init=''
  for pin,name in [('PC1','RF_RX_EN'),('PC2','RF_TX_EN')]:
   ioc+='\n'.join((f'{pin}.Signal=GPIO_Output',f'{pin}.GPIOParameters=GPIO_Label',f'{pin}.GPIO_Label={name}',f'{pin}.GPIO_ModeDefaultOutputPP=GPIO_MODE_OUTPUT_PP',f'{pin}.GPIO_PuPd=GPIO_NOPULL',f'{pin}.GPIO_Speed=GPIO_SPEED_FREQ_LOW',f'{pin}.PinState=GPIO_PIN_RESET',f'{pin}.Locked=true'))+'\n'
   header+=f'\n#define {name}_Pin GPIO_PIN_{pin[2:]}\n#define {name}_GPIO_Port GPIOC\n';init+=f'  __HAL_RCC_GPIOC_CLK_ENABLE();\n  HAL_GPIO_WritePin(GPIOC, {name}_Pin, GPIO_PIN_RESET);\n  GPIO_InitStruct.Pin = {name}_Pin;\n  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;\n  GPIO_InitStruct.Pull = GPIO_NOPULL;\n  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;\n  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);\n'
  write(h,header);write(g,gpio.replace('  /* EXTI interrupt init*/',init+'  /* EXTI interrupt init*/',1))
 write(dest/'SyntheticRadio.ioc',ioc)
 if e32:_Sx1278Input_Configure(dest)
 return src
catalog=PluginCatalog(SCG/'plugins/builtin',SCG/'plugins/installed');catalog.Scan()
for part,radio in [('f103','sx1281'),('f103','sx1278'),('f407','sx1281'),('f407','sx1278')]:
 if len(sys.argv)>2 and part not in sys.argv[2:]:continue
 case=out/(part+'-'+radio);case.mkdir();row={'case':case.name,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()};rows.append(row)
 try:
  e32=radio=='sx1278';model=Sx1278Project_Create(catalog,case) if e32 else _GroundBoardProject_Get(catalog)
  if part=='f407':
   f407_input(case/'uart-f407',e32);hw=CubeMxImporter(WorkspacePolicy(case)).Project_Import(case/'uart-f407',risk_acknowledged=True,target='ground').hardware
   roles={'radio0:radio_bus':'SPI1','radio0:radio_nss':'RADIO_NSS','radio0:radio_reset':'RADIO_RST','radio0:time':next(x.resource_id for x in hw.resources if x.kind=='time')}
   roles.update({'radio0:radio_dio0':'RADIO_DIO1','radio0:radio_rx_en':'RF_RX_EN','radio0:radio_tx_en':'RF_TX_EN'} if e32 else {'radio0:radio_busy':'RADIO_BUSY','radio0:radio_dio1':'RADIO_DIO1'})
   model.ground_target=replace(model.ground_target,mcu='silverstar.mcu.stm32f407vet6',board='',hardware=hw,pc_resource='USART1',resource_assignments=roles)
  issues=GroundTargetIssues_Get(model,catalog);assert not issues,issues
  TargetGeneration_Apply(model,catalog,WorkspacePolicy(case),case/'project',TargetScope.GROUND)
  root=case/'project/Ground_Station';row['graph_sha256']=sha(root/'Generated/ground_source_graph.json') if (root/'Generated/ground_source_graph.json').exists() else None
  row['generated']=True
  from closure_compare import Compare
  old=ROOT/('matrix-v1' if part=='f103' else 'matrix-v2')/case.name/'project/Ground_Station'
  delta=Compare(old,root,flight=False);row['comparison']=delta;save()
  gates=('all','host-tests','architecture-check','static-analysis','artifact-check','power10-check') if delta['changed'] else ()
  for target in gates:
   cmd=['mingw32-make','-j2',target];result=subprocess.run(cmd,cwd=root,stdout=open(case/(target+'.log'),'w',encoding='utf8'),stderr=subprocess.STDOUT,timeout=900)
   records.append({'case':case.name,'target':target,'cwd':str(root),'command':cmd,'exit':result.returncode,'log_sha256':sha(case/(target+'.log'))});save()
  row['artifacts']={p.relative_to(root).as_posix():sha(p) for p in (root/'build').rglob('*') if p.suffix in ('.elf','.map','.bin','.size')};save()
 except Exception as exc:
  row['error']=repr(exc);(case/'error.log').write_text(traceback.format_exc(),encoding='utf8');save()
 print(case.name,row.get('error','finished'),flush=True)

