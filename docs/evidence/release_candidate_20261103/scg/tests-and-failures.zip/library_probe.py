from pathlib import Path
import os,sys,json
repo=Path.cwd();sys.path[:0]=[str(repo/'apps/SCG/src')];os.environ['QT_QPA_PLATFORM']='offscreen'
from PySide6.QtCore import QTimer,Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication,QDialog,QDialogButtonBox,QMessageBox
from silverstar_fccg.core.settings import SettingsStore
from silverstar_fccg.ui.main_window import MainWindow
from silverstar_fccg.ui.mission_stage_transaction import MissionStageTransactionDialog
app=QApplication([]);w=Path(__file__).resolve().parent;window=MainWindow(SettingsStore(w/'library-probe.ini'));window._toolchain_checked=True;window._MessageBox_Exec=lambda *_args,**_kw:QMessageBox.StandardButton.Discard;errors=[];window._Error_Show=lambda obj,*args:errors.append(str(obj));window._model=window._service.ReferenceProject_Create('Library validation');window._Project_Refresh();window.navigation_list.setCurrentRow(1);window.show();app.processEvents();original=window._model.Dictionary_Get();owner='silverstar.algorithm.estimator.eskf15';selected=[];events=[]
def during(accept):
 d=QApplication.activeModalWidget()
 try:
  assert isinstance(d,MissionStageTransactionDialog),type(d);assert d._function_id=='estimator'; assert d._draft.strategies['estimator']==owner; assert window._model.Dictionary_Get()==original
  if accept:
   d.accept(); assert d.result()==QDialog.DialogCode.Accepted,d.error.text()
  else:QTest.keyClick(d,Qt.Key.Key_Escape)
  events.append('applied' if accept else 'discarded')
 except BaseException as ex:
  errors.append(repr(ex));d.reject() if d is not None else None
for accept in (False,True):
 QTimer.singleShot(0,lambda a=accept:during(a));window._FunctionAdd_Apply(owner);app.processEvents();selected.append(window._model.strategies['estimator']);assert not errors,errors
assert selected==[original['components']['strategies']['estimator'],owner],selected
print(json.dumps({'events':events,'owners_after_cancel_apply':selected,'errors':errors}));window.close()
