import json,subprocess,sys,types,inspect
from pathlib import Path
from dataclasses import fields
repo=Path.cwd();scg=repo/'apps/SCG';sys.path[:0]=[str(scg/'src'),str(scg/'tests')];tmp=Path(__file__).resolve().parent;hist='f284db36';case=tmp/'schema-history';case.mkdir(exist_ok=True)
from silverstar_fccg.plugins.catalog import PluginCatalog
cat=PluginCatalog(scg/'plugins/builtin',scg/'plugins/installed');cat.Scan()
def module(path,name):
 raw=subprocess.check_output(['git','show',hist+':'+path]); file=case/(name.rsplit('.',1)[-1]+'.py');file.write_bytes(raw); m=types.ModuleType(name);m.__file__=str(file);sys.modules[name]=m;exec(compile(raw,str(file),'exec'),m.__dict__);return m
old=module('apps/SCG/src/silverstar_fccg/project/model.py','silverstar_fccg.project.f284model')
import test_project_schema_current as tests
from silverstar_fccg.project.reference import ReferenceProject_Create
from test_f103_ground_reference import _GroundF103Model_Get

def convert(m):
 m.mission_process=None  # Pre-v22 inputs have no mission_process field. Select this feature explicitly in the v22 fixture.
 g=old.GroundTargetConfiguration(**{f.name:getattr(m.ground_target,f.name) for f in fields(old.GroundTargetConfiguration) if f.name!='enabled'},enabled=bool(m.ground_target.board))
 return old.ProjectModel(**{f.name:getattr(m,f.name) for f in fields(old.ProjectModel) if f.name!='ground_target'},ground_target=g)
tests.ReferenceProject_Create=lambda *a,**kw: convert(ReferenceProject_Create(*a,**kw));tests._GroundF103Model_Get=lambda *a,**kw:convert(_GroundF103Model_Get(*a,**kw));
cm=convert(ReferenceProject_Create('SchemaCompatibility',catalog=cat)); cm.format_version=14; print('base produced',cm.Dictionary_Get()['format_version'], [(i.instance_id,i.mount_x_axis,i.module_variant) for i in cm.device_instances],cm.mission_process is not None, cm.mission_functions is not None,cm.sensor_installation,cm.build.feature_tier,cm.build.magnetometer_enabled,cm.build.maintenance_log_export_enabled,cm.ground_target.radio_instances)
for v in range(14,24):
 try: j=tests._Document_Get(v,cat); (case/f'v{v}.json').write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print('OK',v)
 except Exception as e:print('FAIL',v,repr(e));raise
