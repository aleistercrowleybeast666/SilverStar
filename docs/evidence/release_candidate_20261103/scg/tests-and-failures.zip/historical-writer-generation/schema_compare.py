import json,sys
from pathlib import Path
from silverstar_fccg.project.model import ProjectModel_Parse
p=Path(__file__).resolve().parent/'schema-history'
for f in sorted(p.glob('v*.json')):
 old=json.loads(f.read_text(encoding='utf8'))
 try:
  n=ProjectModel_Parse(old).Dictionary_Get(); print(f.name,[(k,[(i if isinstance(old[k],dict) else '')for i in (old[k].keys()|n[k].keys()) if old[k].get(i)!=n[k].get(i)] if isinstance(old[k],dict) else None) for k in old if old[k]!=n.get(k)],'add',n.keys()-old.keys())
 except Exception as ex: print(f.name,'ERR',ex)
