from pathlib import Path
import os,sys,subprocess,json,hashlib,time,datetime,shutil

repo=Path.cwd();out=Path(__file__).resolve().parent/'gates'
out.mkdir(exist_ok=False)
sys.path.insert(0,str(repo/'apps/SCG/src'))
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.project.model import ProjectModel_Load
from silverstar_fccg.generator.multi_target import TargetGeneration_Apply,TargetScope

source=repo/'docs/evidence/logger_health_retest_20261008/generated_config.ssproject'
original=source.read_bytes();model=ProjectModel_Load(source)
service=FccgService(repo/'apps/SCG');target=out/'project'
TargetGeneration_Apply(model,service.catalog,service.policy,target,TargetScope.FLIGHT)
assert source.read_bytes()==original
project=target/'Flight_Controller'
old=repo/'.work/gui012_20261008/software/project/Flight_Controller'
sources=[path for path in project.rglob('*') if path.is_file() and path.suffix.lower() in ('.c','.h','.s','.ld')]
equal={str(path.relative_to(project)): (old/path.relative_to(project)).exists()
       and path.read_bytes().replace(b'\r\n',b'\n')==(old/path.relative_to(project)).read_bytes().replace(b'\r\n',b'\n')
       for path in sources}
source_hashes={str(path.relative_to(project)):hashlib.sha256(path.read_bytes()).hexdigest() for path in sources}
snapshot=subprocess.check_output(['git','diff','--binary'])
(out/'dirty_snapshot.patch').write_bytes(snapshot)
record={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'input_sha256':hashlib.sha256(original).hexdigest(),'source_sha256':source_hashes,
    'old_fixture_source_equal':equal,'all_old_fixture_sources_equal':all(equal.values()),
    'dirty_snapshot_sha256':hashlib.sha256(snapshot).hexdigest(),'hardware':False,
    'scope':'F407/KF6 Delay10 isolated software fixture; not user final field configuration.'}
(out/'source_snapshot.json').write_text(json.dumps(record,indent=2),encoding='utf8')
assert all(equal.values()),[key for key,value in equal.items() if not value]
# Copy only the verified generated fixture's compiler cache, preserving the old evidence.
shutil.copytree(old/'build',project/'build')
make='D:/msys64/ucrt64/bin/mingw32-make.exe'
env=dict(os.environ,PATH=str(repo/'apps/FLP/.venv/Scripts')+';D:/msys64/ucrt64/bin;D:/Arm GNU Toolchain/14.3 rel1/bin;'+os.environ.get('PATH',''),PYTHONDONTWRITEBYTECODE='1')
steps=[('architecture',['architecture-check'],120),('power10',['power10-check'],120),
       ('release',['-j2','all','artifact-check','memory-report','GCC_PATH=D:/Arm GNU Toolchain/14.3 rel1/bin'],600),
       ('stack',['-j2','stack-report','GCC_PATH=D:/Arm GNU Toolchain/14.3 rel1/bin'],180),
       ('analyzer',['-j2','static-analysis','GCC_PATH=D:/Arm GNU Toolchain/14.3 rel1/bin'],600),
       ('host',['host-tests','HOST_CC=D:/msys64/ucrt64/bin/gcc.exe'],600)]
for name,args,timeout in steps:
    command=[make,*args];started=time.monotonic()
    row={'command':command,'cwd':str(project),'utc_start':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'source_snapshot_sha256':hashlib.sha256((out/'source_snapshot.json').read_bytes()).hexdigest()}
    print('START '+name,flush=True)
    with (out/(name+'.log')).open('xb') as log:
        try:result=subprocess.run(command,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout);row['exit_code']=result.returncode
        except subprocess.TimeoutExpired:row.update(exit_code=None,timed_out=True)
    row.update(elapsed_s=time.monotonic()-started,utc_end=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               log_sha256=hashlib.sha256((out/(name+'.log')).read_bytes()).hexdigest())
    (out/(name+'_result.json')).write_text(json.dumps(row,indent=2),encoding='utf8')
    print('END '+name+' '+str(row['exit_code']),flush=True)
    if name=='release' and row['exit_code']!=0:break
print('COMPLETE',flush=True)
