from pathlib import Path
import sys,subprocess,json,hashlib,zipfile,datetime,re

repo=Path.cwd();root=Path(__file__).resolve().parent
out=repo/'docs/evidence/scg_storage_maintenance_20261008';out.mkdir(parents=True,exist_ok=False)
sha=lambda data:hashlib.sha256(data).hexdigest()
final_log=(root/'regression_final.log').read_text(encoding='utf8',errors='replace')
assert '101 passed, 3 deselected' in final_log
assert (root/'regression_final.exit.txt').read_text().strip()=='0'
render=json.loads((root/'after_final.json').read_text())
assert render['all_generated_bytes_equal_before'] and all(render['existing_fixture_c_h_s_comparison'].values())
gates={name:json.loads((root/'gates'/f'{name}_result.json').read_text())
       for name in ('architecture','power10','release','stack','analyzer','host')}
assert {name:row['exit_code'] for name,row in gates.items()}=={
    'architecture':0,'power10':0,'release':0,'stack':2,'analyzer':0,'host':0}
sources=[line for line in subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
         if line.startswith('apps/SCG/')]
sources.append('apps/SCG/tests/test_storage_maintenance_acceptance.py')
source_sha={path:sha((repo/path).read_bytes()) for path in sources}
snapshot=subprocess.check_output(['git','diff','--binary'])
(root/'final_dirty_snapshot.patch').write_bytes(snapshot)
artifacts={}
build=root/'gates/project/Flight_Controller/build/FCCG/SilverStar_F407'
for config in ('Release/auto','StaticAnalysis/Release/auto'):
    for path in (build/config).glob('SilverStar_0_1_2.*'):
        if path.suffix in ('.elf','.bin','.hex','.map'):
            artifacts[str(path.relative_to(root))]={'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())}
binary=build/'Release/auto/SilverStar_0_1_2.bin'
old_binary=repo/'.work/gui012_20261008/software/project/Flight_Controller/build/FCCG/SilverStar_F407/Release/auto/SilverStar_0_1_2.bin'
assert binary.read_bytes()==old_binary.read_bytes()
tool_commands={
    'python':[sys.executable,'--version'],
    'make':['D:/msys64/ucrt64/bin/mingw32-make.exe','--version'],
    'host_gcc':['D:/msys64/ucrt64/bin/gcc.exe','--version'],
    'arm_gcc':['D:/Arm GNU Toolchain/14.3 rel1/bin/arm-none-eabi-gcc.exe','--version']}
versions={name:subprocess.check_output(command,text=True).splitlines()[0] for name,command in tool_commands.items()}
import PySide6,pytest
versions.update(PySide6=PySide6.__version__,pytest=pytest.__version__)
gate_tools={}
project=root/'gates/project/Flight_Controller'
for name in ('Makefile','Tools/check_power_of_ten.ps1','Tools/check_architecture.ps1',
             'Tools/check_task_stacks.py','Tools/check_firmware_artifact.ps1','Tests/Host/run_tests.ps1'):
    gate_tools[name]=sha((project/name).read_bytes())
user_inputs={path:sha((repo/path).read_bytes()) for path in (
    'work_build_candidates_20261006.csv','work_inventory_20261006.txt','work_subtree_classification_20261006.csv',
    'docs/evidence/logger_health_retest_20261008/generated_config.ssproject')}
files={}
for directory in (root,root/'gates',root/'visual'):
    for path in directory.iterdir():
        if path.is_file() and path.suffix in ('.py','.json','.log','.txt','.patch','.png'):
            files[str(path.relative_to(root))]=path
# Include the one initial runner failure outside the evidence folder as recorded.
initial=repo/'.work/StorageMaintenanceAcceptance_20261008_pre.log'
files['pre_initial.log']=initial
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as bundle:
    for name,path in sorted(files.items()):bundle.write(path,name)
manifest={
    'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'base_head':'e702ffd0fddf2432b22bd4c46fd1a45980d6705d',
    'source_sha256':source_sha,'dirty_snapshot_sha256':sha(snapshot),
    'gates':gates,'tool_versions':versions,'gate_tools_sha256':gate_tools,
    'final_regression':{'passed':101,'deselected':3,'exit_code':0,
        'cwd':'D:/python_software/SilverStar/apps/SCG',
        'excluded':['test_protocol_combos_and_logging_disabled_state_are_stable',
            'test_legacy_format9_device_shape_rejected_and_current_roundtrip_stable',
            'test_legacy_board_owned_storage_collision_is_rejected'],
        'baseline_same_failures':'baseline_stale3.log: e702ffd extracted Python, same plugin bytes and filesystem anchors; 3 failed/1 passed'},
    'earlier_failures':{'pre4':'5 failed/2 passed','pre_entries':'2 failed/7 deselected',
        'pre_migration':'1 failed/1 passed/10 deselected','regression1':'4 failed/97 passed',
        'post1':'2 failed/5 passed; invalid synthetic hardware fixture and newly exposed load-time rewrite',
        'post2':'7 passed','regression2':'99 passed/3 deselected',
        'environment_attempts':'pre_initial, pre2, pre3, baseline_stale, baseline_stale2 are retained harness/path failures; not product evidence'},
    'generated_file_count':len(render['generated']),
    'generated_bytes_equal_before':True,'fixture_bin_equal_previous_0_1_2':True,
    'artifacts':artifacts,'user_input_sha256':user_inputs,
    'metadata_blocker':json.loads((root/'metadata_identity_probe.json').read_text()),
    'hardware':False,'user_current_unsaved_model_inspected':False,'user_window_closed':False,
    'push':False,'full_suite':False,'original_power10_compliance':False,
    'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,
    'members':{name:sha(path.read_bytes()) for name,path in sorted(files.items())}}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf8')
(out/'.gitattributes').write_text('evidence.zip binary\n',encoding='utf8')
print(json.dumps({'archive':str(archive),'archive_sha256':manifest['archive_sha256'],
                  'regression':manifest['final_regression'],'source_sha256':source_sha},indent=2))
