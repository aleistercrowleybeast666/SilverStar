from pathlib import Path
import sys, json, hashlib, subprocess, difflib

repo = Path.cwd()
sys.path.insert(0, str(repo / 'apps/SCG/src'))
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.project.model import ProjectModel_Load
from silverstar_fccg.project.generation_state import ProjectGenerationState_Normalize, ProjectDigest_Get
from silverstar_fccg.generator.source_graph import SourceGraph_Resolve
from silverstar_fccg.generator.render import GeneratedFiles_Render

out = Path(__file__).resolve().parent
phase = sys.argv[1]
source = repo / 'docs/evidence/logger_health_retest_20261008/generated_config.ssproject'
input_bytes = source.read_bytes()
model = ProjectModel_Load(source)
service = FccgService(repo / 'apps/SCG')
graph = SourceGraph_Resolve(model, service.catalog)
files = GeneratedFiles_Render(model, service.catalog, graph)
destination = out / phase
destination.mkdir(exist_ok=False)
for name, data in files.items():
    path = destination / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
sha = lambda data: hashlib.sha256(data).hexdigest()
record = {
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'input_sha256': sha(input_bytes), 'input_unchanged': source.read_bytes() == input_bytes,
    'model_digest': f'{ProjectDigest_Get(model):08x}',
    'generated': {name: sha(data) for name, data in files.items()},
}
if phase.startswith('after'):
    before = json.loads((out / 'before.json').read_text())
    record['same_input'] = record['input_sha256'] == before['input_sha256']
    record['all_generated_bytes_equal_before'] = record['generated'] == before['generated']
    old_project = repo / '.work/gui012_20261008/software/project/Flight_Controller'
    record['existing_fixture_c_h_s_comparison'] = {
        name: (old_project / name).read_bytes().replace(b'\r\n', b'\n') == data.replace(b'\r\n', b'\n')
        for name, data in files.items() if Path(name).suffix.lower() in ('.c', '.h', '.s')
    }
    old = repo / '.work/finalized_health_20261008_v2/project/Flight_Controller/SilverStar.ssproject'
    record['old_model_path'] = str(old)
    if old.exists():
        previous_model = ProjectModel_Load(old)
        previous_state = ProjectGenerationState_Normalize(previous_model)
        current_state = ProjectGenerationState_Normalize(model)
        record['old_vs_current_model_differences'] = [
            key for key in set(previous_state) | set(current_state)
            if previous_state.get(key) != current_state.get(key)
        ]
        (out / 'normalized_model_diff.patch').write_text(''.join(difflib.unified_diff(
            json.dumps(previous_state, indent=2, sort_keys=True).splitlines(True),
            json.dumps(current_state, indent=2, sort_keys=True).splitlines(True),
            'b2fae22 model normalized', 'e702ffd model normalized')), encoding='utf8')
print(json.dumps(record, indent=2))
(out / (phase + '.json')).write_text(json.dumps(record, indent=2), encoding='utf8')
