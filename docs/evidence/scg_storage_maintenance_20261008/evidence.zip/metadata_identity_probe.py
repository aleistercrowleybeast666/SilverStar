from pathlib import Path
from dataclasses import replace
import sys,json,hashlib,difflib,runpy
repo=Path.cwd();sys.path.insert(0,str(repo/'apps/SCG/src'))
from silverstar_fccg.project.model import ProjectModel_Load
from silverstar_fccg.project.generation_state import ProjectDigest_Get
out=repo/'.work/StorageMaintenanceAcceptance_20261008'
model=ProjectModel_Load(repo/'docs/evidence/logger_health_retest_20261008/generated_config.ssproject')
new_digest=ProjectDigest_Get(model)
identity=model.identity
model.identity=replace(identity,firmware_version='0.1.1',build_target='SilverStar_0_1_1')
old_digest=ProjectDigest_Get(model)
old_path=repo/'.work/finalized_health_20261008_v2/project/Flight_Controller/Generated/Src/project_metadata.c'
new_path=out/'after/Generated/Src/project_metadata.c'
old=old_path.read_text(encoding='utf8');new=new_path.read_text(encoding='utf8')
checker=runpy.run_path(str(repo/'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tools/check_task_stacks.py'))
row={'old_digest':f'{old_digest:08x}','new_digest':f'{new_digest:08x}','identity_only_migration':{'old':{'firmware_version':'0.1.1','build_target':'SilverStar_0_1_1'},'new':identity.Dictionary_Get() if hasattr(identity,'Dictionary_Get') else {'firmware_version':identity.firmware_version,'build_target':identity.build_target}},'old_normalized_sha256':checker['BindingSourceHash_Get'](old),'new_normalized_sha256':checker['BindingSourceHash_Get'](new),'old_digest_only_substitution_equals_new':old.replace(f'0x{old_digest:08X}UL',f'0x{new_digest:08X}UL')==new,'new_hash_authorized':checker['BindingSourceHash_Get'](new) in checker['BindingSourceVersions_Get']('Generated/Src/project_metadata.c')}
(out/'metadata_identity_probe.json').write_text(json.dumps(row,indent=2),encoding='utf8')
print(json.dumps(row,indent=2))

