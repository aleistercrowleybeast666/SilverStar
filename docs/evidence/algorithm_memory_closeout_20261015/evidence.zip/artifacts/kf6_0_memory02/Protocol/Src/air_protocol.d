build/FCCG/SilverStar_F407/ReleaseO0/legacy/Protocol/Src/air_protocol.o: \
 Protocol/Src/air_protocol.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 Protocol/Inc/air_protocol.h Common/Inc/silverstar_sensor_id.h \
 Common/Inc/silverstar_assert.h Common/Inc/silverstar_compiler.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
Protocol/Inc/air_protocol.h:
Common/Inc/silverstar_sensor_id.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
