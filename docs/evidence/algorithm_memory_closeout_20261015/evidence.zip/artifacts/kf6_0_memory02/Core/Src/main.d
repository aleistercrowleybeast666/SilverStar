build/FCCG/SilverStar_F407/ReleaseO0/legacy/Core/Src/main.o: \
 Core/Src/main.c Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h Core/Inc/main.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal.h \
 Core/Inc/stm32f4xx_hal_conf.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_def.h \
 Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f4xx.h \
 Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f407xx.h \
 Drivers/CMSIS/Include/core_cm4.h Drivers/CMSIS/Include/cmsis_version.h \
 Drivers/CMSIS/Include/cmsis_compiler.h Drivers/CMSIS/Include/cmsis_gcc.h \
 Drivers/CMSIS/Include/mpu_armv7.h \
 Drivers/CMSIS/Device/ST/STM32F4xx/Include/system_stm32f4xx.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc_ex.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio_ex.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_exti.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma_ex.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_cortex.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_adc.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_adc.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_adc_ex.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ex.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ramfunc.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr_ex.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_sd.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_sdmmc.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_spi.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_tim.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_tim_ex.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_uart.h Core/Inc/adc.h \
 Core/Inc/main.h Core/Inc/dma.h FATFS/App/fatfs.h \
 Middlewares/Third_Party/FatFs/src/ff.h \
 Middlewares/Third_Party/FatFs/src/integer.h FATFS/Target/ffconf.h \
 FATFS/Target/bsp_driver_sd.h FATFS/Target/fatfs_platform.h \
 Middlewares/Third_Party/FatFs/src/ff_gen_drv.h \
 Middlewares/Third_Party/FatFs/src/diskio.h \
 Middlewares/Third_Party/FatFs/src/ff.h FATFS/Target/sd_diskio.h \
 Core/Inc/sdio.h Core/Inc/spi.h Core/Inc/usart.h Core/Inc/gpio.h \
 ThirdParty/FreeRTOS-Kernel/include/FreeRTOS.h \
 OS/FreeRTOS/FreeRTOSConfig.h \
 Targets/SilverStar_F407/Inc/freertos_target_config.h \
 ThirdParty/FreeRTOS-Kernel/include/projdefs.h \
 ThirdParty/FreeRTOS-Kernel/include/portable.h \
 ThirdParty/FreeRTOS-Kernel/include/deprecated_definitions.h \
 ThirdParty/FreeRTOS-Kernel/portable/GCC/ARM_CM4F/portmacro.h \
 ThirdParty/FreeRTOS-Kernel/include/mpu_wrappers.h APP/Inc/app_tasks.h \
 System/Inc/system_task_stack.h Interfaces/Inc/system_device_types.h \
 Common/Inc/silverstar_compiler.h System/Inc/system_version.h \
 System/User/system_user_config.h System/Inc/system_configuration_types.h \
 System/User/system_user_flight_config.h \
 Targets/SilverStar_F407/Inc/target_system_config.h \
 System/Inc/system_capabilities.h \
 System/User/system_user_alignment_config.h \
 System/Alignment/Inc/system_alignment.h \
 System/User/system_user_capability_validation.h \
 System/User/system_user_platform_capabilities.h Common/Inc/debug_log.h \
 System/Inc/system_startup.h Interfaces/Inc/system_gnss_if.h \
 Interfaces/Inc/system_device_types.h \
 ThirdParty/FreeRTOS-Kernel/include/task.h \
 ThirdParty/FreeRTOS-Kernel/include/list.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
Core/Inc/main.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal.h:
Core/Inc/stm32f4xx_hal_conf.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_def.h:
Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f4xx.h:
Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f407xx.h:
Drivers/CMSIS/Include/core_cm4.h:
Drivers/CMSIS/Include/cmsis_version.h:
Drivers/CMSIS/Include/cmsis_compiler.h:
Drivers/CMSIS/Include/cmsis_gcc.h:
Drivers/CMSIS/Include/mpu_armv7.h:
Drivers/CMSIS/Device/ST/STM32F4xx/Include/system_stm32f4xx.h:
Drivers/STM32F4xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc_ex.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio_ex.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_exti.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma_ex.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_cortex.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_adc.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_adc.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_adc_ex.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ex.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ramfunc.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr_ex.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_sd.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_sdmmc.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_spi.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_tim.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_tim_ex.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_uart.h:
Core/Inc/adc.h:
Core/Inc/main.h:
Core/Inc/dma.h:
FATFS/App/fatfs.h:
Middlewares/Third_Party/FatFs/src/ff.h:
Middlewares/Third_Party/FatFs/src/integer.h:
FATFS/Target/ffconf.h:
FATFS/Target/bsp_driver_sd.h:
FATFS/Target/fatfs_platform.h:
Middlewares/Third_Party/FatFs/src/ff_gen_drv.h:
Middlewares/Third_Party/FatFs/src/diskio.h:
Middlewares/Third_Party/FatFs/src/ff.h:
FATFS/Target/sd_diskio.h:
Core/Inc/sdio.h:
Core/Inc/spi.h:
Core/Inc/usart.h:
Core/Inc/gpio.h:
ThirdParty/FreeRTOS-Kernel/include/FreeRTOS.h:
OS/FreeRTOS/FreeRTOSConfig.h:
Targets/SilverStar_F407/Inc/freertos_target_config.h:
ThirdParty/FreeRTOS-Kernel/include/projdefs.h:
ThirdParty/FreeRTOS-Kernel/include/portable.h:
ThirdParty/FreeRTOS-Kernel/include/deprecated_definitions.h:
ThirdParty/FreeRTOS-Kernel/portable/GCC/ARM_CM4F/portmacro.h:
ThirdParty/FreeRTOS-Kernel/include/mpu_wrappers.h:
APP/Inc/app_tasks.h:
System/Inc/system_task_stack.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
System/Inc/system_version.h:
System/User/system_user_config.h:
System/Inc/system_configuration_types.h:
System/User/system_user_flight_config.h:
Targets/SilverStar_F407/Inc/target_system_config.h:
System/Inc/system_capabilities.h:
System/User/system_user_alignment_config.h:
System/Alignment/Inc/system_alignment.h:
System/User/system_user_capability_validation.h:
System/User/system_user_platform_capabilities.h:
Common/Inc/debug_log.h:
System/Inc/system_startup.h:
Interfaces/Inc/system_gnss_if.h:
Interfaces/Inc/system_device_types.h:
ThirdParty/FreeRTOS-Kernel/include/task.h:
ThirdParty/FreeRTOS-Kernel/include/list.h:
