build/FCCG/SilverStar_F407/ReleaseO0/legacy/APP/Src/estimator_barometer_pending.o: \
 APP/Src/estimator_barometer_pending.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 APP/Inc/estimator_barometer_pending.h APP/Inc/estimator_bus.h \
 Interfaces/Inc/system_device_types.h Common/Inc/silverstar_compiler.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
APP/Inc/estimator_barometer_pending.h:
APP/Inc/estimator_bus.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
