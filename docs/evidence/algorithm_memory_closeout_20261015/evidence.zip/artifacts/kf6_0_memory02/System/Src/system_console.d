build/FCCG/SilverStar_F407/ReleaseO0/legacy/System/Src/system_console.o: \
 System/Src/system_console.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 System/Inc/system_version.h System/User/system_user_config.h \
 System/Inc/system_configuration_types.h \
 System/User/system_user_flight_config.h \
 Targets/SilverStar_F407/Inc/target_system_config.h \
 System/Inc/system_capabilities.h Interfaces/Inc/system_device_types.h \
 Common/Inc/silverstar_compiler.h \
 System/User/system_user_alignment_config.h \
 System/Alignment/Inc/system_alignment.h \
 System/User/system_user_capability_validation.h \
 System/User/system_user_platform_capabilities.h \
 System/Inc/system_console.h System/Inc/system_log_file.h \
 System/Inc/system_console.h Common/Inc/common_format.h \
 Platform/Inc/platform_memory.h Generated/Inc/project_device_instances.h \
 Interfaces/Inc/system_barometer_if.h \
 Interfaces/Inc/system_device_types.h \
 Interfaces/Inc/system_descriptor_if.h Interfaces/Inc/system_gnss_if.h \
 Interfaces/Inc/system_hardware_quaternion_if.h \
 Interfaces/Inc/system_imu_if.h Interfaces/Inc/system_imu_epoch_if.h \
 Interfaces/Inc/system_magnetometer_if.h Interfaces/Inc/system_power_if.h \
 Interfaces/Inc/system_telemetry_transport_if.h \
 Common/Inc/silverstar_assert.h Common/Inc/silverstar_compiler.h \
 System/Calibration/Inc/system_calibration.h \
 Algorithm/Calibration/Inc/imu_six_face_calibration.h \
 System/Inertial/Inc/system_inertial_types.h \
 Interfaces/Inc/system_imu_epoch_if.h System/Inc/system_barometer.h \
 Interfaces/Inc/system_console_if.h \
 System/Inc/system_estimator_diagnostics.h \
 System/Inc/system_flight_recovery.h \
 Interfaces/Inc/system_mission_action_if.h \
 System/Inc/system_configuration_types.h System/Inc/system_health.h \
 System/Inc/system_capabilities.h System/Inc/system_lifecycle.h \
 System/Calibration/Inc/system_mag_calibration.h \
 Interfaces/Inc/system_output_if.h System/Inc/system_profile.h \
 System/Inc/system_startup.h Interfaces/Inc/system_storage_if.h \
 System/Inc/system_task_stack.h System/Inc/system_time.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
System/Inc/system_version.h:
System/User/system_user_config.h:
System/Inc/system_configuration_types.h:
System/User/system_user_flight_config.h:
Targets/SilverStar_F407/Inc/target_system_config.h:
System/Inc/system_capabilities.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
System/User/system_user_alignment_config.h:
System/Alignment/Inc/system_alignment.h:
System/User/system_user_capability_validation.h:
System/User/system_user_platform_capabilities.h:
System/Inc/system_console.h:
System/Inc/system_log_file.h:
System/Inc/system_console.h:
Common/Inc/common_format.h:
Platform/Inc/platform_memory.h:
Generated/Inc/project_device_instances.h:
Interfaces/Inc/system_barometer_if.h:
Interfaces/Inc/system_device_types.h:
Interfaces/Inc/system_descriptor_if.h:
Interfaces/Inc/system_gnss_if.h:
Interfaces/Inc/system_hardware_quaternion_if.h:
Interfaces/Inc/system_imu_if.h:
Interfaces/Inc/system_imu_epoch_if.h:
Interfaces/Inc/system_magnetometer_if.h:
Interfaces/Inc/system_power_if.h:
Interfaces/Inc/system_telemetry_transport_if.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
System/Calibration/Inc/system_calibration.h:
Algorithm/Calibration/Inc/imu_six_face_calibration.h:
System/Inertial/Inc/system_inertial_types.h:
Interfaces/Inc/system_imu_epoch_if.h:
System/Inc/system_barometer.h:
Interfaces/Inc/system_console_if.h:
System/Inc/system_estimator_diagnostics.h:
System/Inc/system_flight_recovery.h:
Interfaces/Inc/system_mission_action_if.h:
System/Inc/system_configuration_types.h:
System/Inc/system_health.h:
System/Inc/system_capabilities.h:
System/Inc/system_lifecycle.h:
System/Calibration/Inc/system_mag_calibration.h:
Interfaces/Inc/system_output_if.h:
System/Inc/system_profile.h:
System/Inc/system_startup.h:
Interfaces/Inc/system_storage_if.h:
System/Inc/system_task_stack.h:
System/Inc/system_time.h:
