build/FCCG/SilverStar_F407/ReleaseO0/legacy/System/Src/system_log_file.o: \
 System/Src/system_log_file.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 System/Inc/system_log_file.h System/Inc/system_console.h \
 Interfaces/Inc/system_device_types.h Common/Inc/silverstar_compiler.h \
 System/Inc/system_lifecycle.h System/User/system_user_config.h \
 System/Inc/system_configuration_types.h \
 System/User/system_user_flight_config.h \
 Targets/SilverStar_F407/Inc/target_system_config.h \
 System/Inc/system_capabilities.h \
 System/User/system_user_alignment_config.h \
 System/Alignment/Inc/system_alignment.h \
 System/User/system_user_capability_validation.h \
 System/User/system_user_platform_capabilities.h \
 System/Inc/system_version.h Common/Inc/common_format.h \
 Platform/Inc/platform_critical.h Platform/Inc/platform_memory.h \
 Common/Inc/silverstar_assert.h Common/Inc/silverstar_compiler.h \
 System/Inc/system_time.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
System/Inc/system_log_file.h:
System/Inc/system_console.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
System/Inc/system_lifecycle.h:
System/User/system_user_config.h:
System/Inc/system_configuration_types.h:
System/User/system_user_flight_config.h:
Targets/SilverStar_F407/Inc/target_system_config.h:
System/Inc/system_capabilities.h:
System/User/system_user_alignment_config.h:
System/Alignment/Inc/system_alignment.h:
System/User/system_user_capability_validation.h:
System/User/system_user_platform_capabilities.h:
System/Inc/system_version.h:
Common/Inc/common_format.h:
Platform/Inc/platform_critical.h:
Platform/Inc/platform_memory.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
System/Inc/system_time.h:
