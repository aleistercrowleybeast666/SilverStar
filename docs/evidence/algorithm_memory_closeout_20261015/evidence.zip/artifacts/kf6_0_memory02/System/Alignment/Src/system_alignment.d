build/FCCG/SilverStar_F407/ReleaseO0/legacy/System/Alignment/Src/system_alignment.o: \
 System/Alignment/Src/system_alignment.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 System/Alignment/Inc/system_alignment.h \
 Interfaces/Inc/system_device_types.h Common/Inc/silverstar_compiler.h \
 System/Inc/system_configuration_types.h Platform/Inc/platform_critical.h \
 Common/Inc/silverstar_assert.h Common/Inc/silverstar_compiler.h \
 System/Alignment/Inc/system_alignment_backend.h \
 System/Alignment/Inc/system_alignment.h \
 Interfaces/Inc/system_barometer_if.h \
 Interfaces/Inc/system_device_types.h \
 System/Calibration/Inc/system_calibration.h \
 Algorithm/Calibration/Inc/imu_six_face_calibration.h \
 System/Inertial/Inc/system_inertial_types.h \
 Interfaces/Inc/system_imu_epoch_if.h Interfaces/Inc/system_gnss_if.h \
 Interfaces/Inc/system_hardware_quaternion_if.h \
 Interfaces/Inc/system_imu_if.h Interfaces/Inc/system_imu_epoch_if.h \
 System/Inc/system_lifecycle.h System/User/system_user_config.h \
 System/User/system_user_flight_config.h \
 Targets/SilverStar_F407/Inc/target_system_config.h \
 System/Inc/system_capabilities.h \
 System/User/system_user_alignment_config.h \
 System/User/system_user_capability_validation.h \
 System/User/system_user_platform_capabilities.h \
 Interfaces/Inc/system_magnetometer_if.h \
 System/Inc/system_source_selector.h System/Inc/system_startup.h \
 System/User/system_user_alignment_config.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
System/Alignment/Inc/system_alignment.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
System/Inc/system_configuration_types.h:
Platform/Inc/platform_critical.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
System/Alignment/Inc/system_alignment_backend.h:
System/Alignment/Inc/system_alignment.h:
Interfaces/Inc/system_barometer_if.h:
Interfaces/Inc/system_device_types.h:
System/Calibration/Inc/system_calibration.h:
Algorithm/Calibration/Inc/imu_six_face_calibration.h:
System/Inertial/Inc/system_inertial_types.h:
Interfaces/Inc/system_imu_epoch_if.h:
Interfaces/Inc/system_gnss_if.h:
Interfaces/Inc/system_hardware_quaternion_if.h:
Interfaces/Inc/system_imu_if.h:
Interfaces/Inc/system_imu_epoch_if.h:
System/Inc/system_lifecycle.h:
System/User/system_user_config.h:
System/User/system_user_flight_config.h:
Targets/SilverStar_F407/Inc/target_system_config.h:
System/Inc/system_capabilities.h:
System/User/system_user_alignment_config.h:
System/User/system_user_capability_validation.h:
System/User/system_user_platform_capabilities.h:
Interfaces/Inc/system_magnetometer_if.h:
System/Inc/system_source_selector.h:
System/Inc/system_startup.h:
System/User/system_user_alignment_config.h:
