build/FCCG/SilverStar_F407/ReleaseO0/legacy/System/Calibration/Src/system_mag_calibration.o: \
 System/Calibration/Src/system_mag_calibration.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 System/Calibration/Inc/system_mag_calibration.h \
 Interfaces/Inc/system_magnetometer_if.h \
 Interfaces/Inc/system_device_types.h Common/Inc/silverstar_compiler.h \
 Platform/Inc/platform_critical.h \
 Generated/Inc/project_device_instances.h \
 Interfaces/Inc/system_barometer_if.h \
 Interfaces/Inc/system_descriptor_if.h Interfaces/Inc/system_gnss_if.h \
 Interfaces/Inc/system_hardware_quaternion_if.h \
 Interfaces/Inc/system_imu_if.h Interfaces/Inc/system_imu_epoch_if.h \
 Interfaces/Inc/system_power_if.h \
 Interfaces/Inc/system_telemetry_transport_if.h \
 Common/Inc/silverstar_assert.h Common/Inc/silverstar_compiler.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
System/Calibration/Inc/system_mag_calibration.h:
Interfaces/Inc/system_magnetometer_if.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
Platform/Inc/platform_critical.h:
Generated/Inc/project_device_instances.h:
Interfaces/Inc/system_barometer_if.h:
Interfaces/Inc/system_descriptor_if.h:
Interfaces/Inc/system_gnss_if.h:
Interfaces/Inc/system_hardware_quaternion_if.h:
Interfaces/Inc/system_imu_if.h:
Interfaces/Inc/system_imu_epoch_if.h:
Interfaces/Inc/system_power_if.h:
Interfaces/Inc/system_telemetry_transport_if.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
