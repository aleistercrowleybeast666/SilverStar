build/FCCG/SilverStar_F407/ReleaseO0/legacy/System/User/system_user_inertial_config.o: \
 System/User/system_user_inertial_config.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 System/User/system_user_inertial_config.h \
 System/Inertial/Inc/system_inertial_source_if.h \
 Interfaces/Inc/system_device_types.h Common/Inc/silverstar_compiler.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
System/User/system_user_inertial_config.h:
System/Inertial/Inc/system_inertial_source_if.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
