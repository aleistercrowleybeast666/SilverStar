build/FCCG/SilverStar_F407/ReleaseO0/legacy/Generated/Src/project_mission_parameters.o: \
 Generated/Src/project_mission_parameters.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 Interfaces/Inc/system_project_parameters_if.h \
 Common/Inc/silverstar_assert.h Common/Inc/silverstar_compiler.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
Interfaces/Inc/system_project_parameters_if.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
