build/FCCG/SilverStar_F407/ReleaseO0/legacy/Algorithm/Common/Src/navigation_quality.o: \
 Algorithm/Common/Src/navigation_quality.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 Algorithm/Common/Inc/navigation_quality.h Common/Inc/silverstar_assert.h \
 Common/Inc/silverstar_compiler.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
Algorithm/Common/Inc/navigation_quality.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
