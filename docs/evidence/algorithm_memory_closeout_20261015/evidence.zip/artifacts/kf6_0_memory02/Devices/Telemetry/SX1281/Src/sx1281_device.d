build/FCCG/SilverStar_F407/ReleaseO0/legacy/Devices/Telemetry/SX1281/Src/sx1281_device.o: \
 Devices/Telemetry/SX1281/Src/sx1281_device.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 Devices/Telemetry/SX1281/Inc/sx1281_device.h \
 Devices/Telemetry/SX1281/Inc/sx1281_config.h \
 Middlewares/Third_Party/SX1280lib/sx1280.h \
 Generated/Inc/air_link_config.h Generated/Inc/project_resources.h \
 Platform/Inc/platform_adc.h Platform/Inc/platform_types.h \
 Platform/Inc/platform_gpio.h Platform/Inc/platform_uart.h \
 Platform/STM32F4/Inc/platform_stm32f4_resources.h \
 Platform/Inc/platform_can.h Platform/Inc/platform_i2c.h \
 Platform/Inc/platform_pwm.h Platform/Inc/platform_spi.h \
 Platform/Inc/platform_time.h Interfaces/Inc/system_device_types.h \
 Common/Inc/silverstar_compiler.h Common/Inc/silverstar_assert.h \
 Common/Inc/silverstar_compiler.h Platform/Inc/platform_critical.h \
 Devices/Telemetry/SX1281/Inc/sx1281_bus.h Platform/Inc/platform_types.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
Devices/Telemetry/SX1281/Inc/sx1281_device.h:
Devices/Telemetry/SX1281/Inc/sx1281_config.h:
Middlewares/Third_Party/SX1280lib/sx1280.h:
Generated/Inc/air_link_config.h:
Generated/Inc/project_resources.h:
Platform/Inc/platform_adc.h:
Platform/Inc/platform_types.h:
Platform/Inc/platform_gpio.h:
Platform/Inc/platform_uart.h:
Platform/STM32F4/Inc/platform_stm32f4_resources.h:
Platform/Inc/platform_can.h:
Platform/Inc/platform_i2c.h:
Platform/Inc/platform_pwm.h:
Platform/Inc/platform_spi.h:
Platform/Inc/platform_time.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
Platform/Inc/platform_critical.h:
Devices/Telemetry/SX1281/Inc/sx1281_bus.h:
Platform/Inc/platform_types.h:
