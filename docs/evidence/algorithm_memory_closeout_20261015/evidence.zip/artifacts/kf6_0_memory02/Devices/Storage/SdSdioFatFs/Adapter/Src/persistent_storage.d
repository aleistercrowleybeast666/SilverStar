build/FCCG/SilverStar_F407/ReleaseO0/legacy/Devices/Storage/SdSdioFatFs/Adapter/Src/persistent_storage.o: \
 Devices/Storage/SdSdioFatFs/Adapter/Src/persistent_storage.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 Devices/Storage/SdSdioFatFs/Adapter/Inc/persistent_storage.h \
 Interfaces/Inc/system_storage_if.h Interfaces/Inc/system_device_types.h \
 Common/Inc/silverstar_compiler.h Common/Inc/silverstar_assert.h \
 Common/Inc/silverstar_compiler.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
Devices/Storage/SdSdioFatFs/Adapter/Inc/persistent_storage.h:
Interfaces/Inc/system_storage_if.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
