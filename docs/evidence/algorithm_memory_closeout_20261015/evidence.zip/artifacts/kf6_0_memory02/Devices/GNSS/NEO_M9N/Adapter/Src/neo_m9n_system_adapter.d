build/FCCG/SilverStar_F407/ReleaseO0/legacy/Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.o: \
 Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 System/Inc/system_version.h System/User/system_user_config.h \
 System/Inc/system_configuration_types.h \
 System/User/system_user_flight_config.h \
 Targets/SilverStar_F407/Inc/target_system_config.h \
 System/Inc/system_capabilities.h Interfaces/Inc/system_device_types.h \
 Common/Inc/silverstar_compiler.h \
 System/User/system_user_alignment_config.h \
 System/Alignment/Inc/system_alignment.h \
 System/User/system_user_capability_validation.h \
 System/User/system_user_platform_capabilities.h \
 Interfaces/Inc/system_gnss_if.h Interfaces/Inc/system_device_types.h \
 Generated/Inc/project_resources.h Platform/Inc/platform_adc.h \
 Platform/Inc/platform_types.h Platform/Inc/platform_gpio.h \
 Platform/Inc/platform_uart.h \
 Platform/STM32F4/Inc/platform_stm32f4_resources.h \
 Platform/Inc/platform_can.h Platform/Inc/platform_i2c.h \
 Platform/Inc/platform_pwm.h Platform/Inc/platform_spi.h \
 Platform/Inc/platform_time.h \
 Devices/GNSS/NEO_M9N/Inc/neo_m9n_build_capabilities.h \
 Devices/GNSS/NEO_M9N/Inc/neo_m9n_config.h \
 Devices/GNSS/NEO_M9N/Inc/neo_m9n_device.h \
 Devices/GNSS/NEO_M9N/Adapter/Inc/neo_m9n_instance.h \
 Devices/GNSS/NEO_M9N/Adapter/Inc/neo_m9n_startup.h \
 System/Inc/system_device_startup.h Common/Inc/debug_log.h \
 Platform/Inc/platform_critical.h System/Inc/system_gnss_quality.h \
 Common/Inc/silverstar_assert.h Common/Inc/silverstar_compiler.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
System/Inc/system_version.h:
System/User/system_user_config.h:
System/Inc/system_configuration_types.h:
System/User/system_user_flight_config.h:
Targets/SilverStar_F407/Inc/target_system_config.h:
System/Inc/system_capabilities.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
System/User/system_user_alignment_config.h:
System/Alignment/Inc/system_alignment.h:
System/User/system_user_capability_validation.h:
System/User/system_user_platform_capabilities.h:
Interfaces/Inc/system_gnss_if.h:
Interfaces/Inc/system_device_types.h:
Generated/Inc/project_resources.h:
Platform/Inc/platform_adc.h:
Platform/Inc/platform_types.h:
Platform/Inc/platform_gpio.h:
Platform/Inc/platform_uart.h:
Platform/STM32F4/Inc/platform_stm32f4_resources.h:
Platform/Inc/platform_can.h:
Platform/Inc/platform_i2c.h:
Platform/Inc/platform_pwm.h:
Platform/Inc/platform_spi.h:
Platform/Inc/platform_time.h:
Devices/GNSS/NEO_M9N/Inc/neo_m9n_build_capabilities.h:
Devices/GNSS/NEO_M9N/Inc/neo_m9n_config.h:
Devices/GNSS/NEO_M9N/Inc/neo_m9n_device.h:
Devices/GNSS/NEO_M9N/Adapter/Inc/neo_m9n_instance.h:
Devices/GNSS/NEO_M9N/Adapter/Inc/neo_m9n_startup.h:
System/Inc/system_device_startup.h:
Common/Inc/debug_log.h:
Platform/Inc/platform_critical.h:
System/Inc/system_gnss_quality.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
