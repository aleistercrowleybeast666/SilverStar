build/FCCG/SilverStar_F407/ReleaseO0/legacy/Devices/IMU/JY901B/Adapter/Src/jy901b_imu_adapter.o: \
 Devices/IMU/JY901B/Adapter/Src/jy901b_imu_adapter.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 System/Inc/system_version.h System/User/system_user_config.h \
 System/Inc/system_configuration_types.h \
 System/User/system_user_flight_config.h \
 Targets/SilverStar_F407/Inc/target_system_config.h \
 System/Inc/system_capabilities.h Interfaces/Inc/system_device_types.h \
 Common/Inc/silverstar_compiler.h \
 System/User/system_user_alignment_config.h \
 System/Alignment/Inc/system_alignment.h \
 System/User/system_user_capability_validation.h \
 System/User/system_user_platform_capabilities.h \
 Devices/IMU/JY901B/Adapter/Inc/jy901b_sensor_adapter.h \
 Interfaces/Inc/system_imu_if.h Interfaces/Inc/system_device_types.h \
 Interfaces/Inc/system_imu_epoch_if.h \
 Devices/IMU/JY901B/Inc/jy901b_device.h Generated/Inc/project_resources.h \
 Platform/Inc/platform_adc.h Platform/Inc/platform_types.h \
 Platform/Inc/platform_gpio.h Platform/Inc/platform_uart.h \
 Platform/STM32F4/Inc/platform_stm32f4_resources.h \
 Platform/Inc/platform_can.h Platform/Inc/platform_i2c.h \
 Platform/Inc/platform_pwm.h Platform/Inc/platform_spi.h \
 Platform/Inc/platform_time.h Devices/IMU/JY901B/Inc/jy901b_config.h \
 Devices/IMU/JY901B/Inc/jy901b_device.h \
 Devices/IMU/JY901B/Adapter/Inc/jy901b_magnetometer_build_capabilities.h \
 Platform/Inc/platform_critical.h \
 Devices/IMU/JY901B/Inc/jy901b_imu_build_capabilities.h \
 Devices/IMU/JY901B/Adapter/Inc/jy901b_instance.h \
 Interfaces/Inc/system_barometer_if.h \
 Interfaces/Inc/system_hardware_quaternion_if.h \
 Interfaces/Inc/system_magnetometer_if.h \
 Devices/IMU/JY901B/Adapter/Inc/jy901b_sample_quality.h \
 Devices/IMU/JY901B/Adapter/Inc/jy901b_startup.h \
 System/Inc/system_device_startup.h Common/Inc/debug_log.h \
 Common/Inc/silverstar_assert.h Common/Inc/silverstar_compiler.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
System/Inc/system_version.h:
System/User/system_user_config.h:
System/Inc/system_configuration_types.h:
System/User/system_user_flight_config.h:
Targets/SilverStar_F407/Inc/target_system_config.h:
System/Inc/system_capabilities.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
System/User/system_user_alignment_config.h:
System/Alignment/Inc/system_alignment.h:
System/User/system_user_capability_validation.h:
System/User/system_user_platform_capabilities.h:
Devices/IMU/JY901B/Adapter/Inc/jy901b_sensor_adapter.h:
Interfaces/Inc/system_imu_if.h:
Interfaces/Inc/system_device_types.h:
Interfaces/Inc/system_imu_epoch_if.h:
Devices/IMU/JY901B/Inc/jy901b_device.h:
Generated/Inc/project_resources.h:
Platform/Inc/platform_adc.h:
Platform/Inc/platform_types.h:
Platform/Inc/platform_gpio.h:
Platform/Inc/platform_uart.h:
Platform/STM32F4/Inc/platform_stm32f4_resources.h:
Platform/Inc/platform_can.h:
Platform/Inc/platform_i2c.h:
Platform/Inc/platform_pwm.h:
Platform/Inc/platform_spi.h:
Platform/Inc/platform_time.h:
Devices/IMU/JY901B/Inc/jy901b_config.h:
Devices/IMU/JY901B/Inc/jy901b_device.h:
Devices/IMU/JY901B/Adapter/Inc/jy901b_magnetometer_build_capabilities.h:
Platform/Inc/platform_critical.h:
Devices/IMU/JY901B/Inc/jy901b_imu_build_capabilities.h:
Devices/IMU/JY901B/Adapter/Inc/jy901b_instance.h:
Interfaces/Inc/system_barometer_if.h:
Interfaces/Inc/system_hardware_quaternion_if.h:
Interfaces/Inc/system_magnetometer_if.h:
Devices/IMU/JY901B/Adapter/Inc/jy901b_sample_quality.h:
Devices/IMU/JY901B/Adapter/Inc/jy901b_startup.h:
System/Inc/system_device_startup.h:
Common/Inc/debug_log.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
