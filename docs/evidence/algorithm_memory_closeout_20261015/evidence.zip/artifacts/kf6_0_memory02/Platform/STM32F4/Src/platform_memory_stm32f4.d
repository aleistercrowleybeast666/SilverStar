build/FCCG/SilverStar_F407/ReleaseO0/legacy/Platform/STM32F4/Src/platform_memory_stm32f4.o: \
 Platform/STM32F4/Src/platform_memory_stm32f4.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 Platform/Inc/platform_memory.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
Platform/Inc/platform_memory.h:
