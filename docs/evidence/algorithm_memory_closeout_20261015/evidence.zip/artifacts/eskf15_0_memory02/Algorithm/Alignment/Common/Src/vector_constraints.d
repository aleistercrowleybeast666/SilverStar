build/FCCG/SilverStar_F407/ReleaseO0/auto/Algorithm/Alignment/Common/Src/vector_constraints.o: \
 Algorithm/Alignment/Common/Src/vector_constraints.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 Algorithm/Alignment/Common/Inc/vector_constraints.h \
 Common/Inc/silverstar_assert.h Common/Inc/silverstar_compiler.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
Algorithm/Alignment/Common/Inc/vector_constraints.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
