build/FCCG/SilverStar_F407/ReleaseO0/auto/Algorithm/Alignment/VectorConstraints/Src/alignment_strategy_binding.o: \
 Algorithm/Alignment/VectorConstraints/Src/alignment_strategy_binding.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 Algorithm/Alignment/VectorConstraints/Inc/alignment_strategy_binding.h \
 Algorithm/Alignment/Common/Inc/alignment_strategy_types.h \
 Algorithm/Alignment/Common/Inc/attitude_alignment.h \
 Common/Inc/silverstar_assert.h Common/Inc/silverstar_compiler.h \
 Algorithm/Alignment/Common/Inc/vector_constraints.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
Algorithm/Alignment/VectorConstraints/Inc/alignment_strategy_binding.h:
Algorithm/Alignment/Common/Inc/alignment_strategy_types.h:
Algorithm/Alignment/Common/Inc/attitude_alignment.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
Algorithm/Alignment/Common/Inc/vector_constraints.h:
