build/FCCG/SilverStar_F407/ReleaseO0/auto/Algorithm/Common/Src/geodesy_local.o: \
 Algorithm/Common/Src/geodesy_local.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 Algorithm/Common/Inc/geodesy_local.h Common/Inc/silverstar_assert.h \
 Common/Inc/silverstar_compiler.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
Algorithm/Common/Inc/geodesy_local.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
