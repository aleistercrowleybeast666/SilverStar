build/FCCG/SilverStar_F407/ReleaseO0/auto/APP/Src/device_native_log.o: \
 APP/Src/device_native_log.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 APP/Inc/device_native_log.h System/Inc/system_log_policy.h \
 Protocol/SSLOG/Inc/sslog_records.h Interfaces/Inc/system_device_types.h \
 Common/Inc/silverstar_compiler.h APP/Inc/logger_bus.h \
 Protocol/SSLOG/Inc/sslog_protocol.h Protocol/SSLOG/Inc/sslog_records.h \
 Generated/Inc/project_device_instances.h \
 Interfaces/Inc/system_barometer_if.h \
 Interfaces/Inc/system_device_types.h \
 Interfaces/Inc/system_descriptor_if.h Interfaces/Inc/system_gnss_if.h \
 Interfaces/Inc/system_hardware_quaternion_if.h \
 Interfaces/Inc/system_imu_if.h Interfaces/Inc/system_imu_epoch_if.h \
 Interfaces/Inc/system_magnetometer_if.h Interfaces/Inc/system_power_if.h \
 Interfaces/Inc/system_telemetry_transport_if.h \
 Common/Inc/silverstar_assert.h Common/Inc/silverstar_compiler.h \
 System/Inc/system_lifecycle.h System/User/system_user_config.h \
 System/Inc/system_configuration_types.h \
 System/User/system_user_flight_config.h \
 Targets/SilverStar_F407/Inc/target_system_config.h \
 System/Inc/system_capabilities.h \
 System/User/system_user_alignment_config.h \
 System/Alignment/Inc/system_alignment.h \
 System/User/system_user_capability_validation.h \
 System/User/system_user_platform_capabilities.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
APP/Inc/device_native_log.h:
System/Inc/system_log_policy.h:
Protocol/SSLOG/Inc/sslog_records.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
APP/Inc/logger_bus.h:
Protocol/SSLOG/Inc/sslog_protocol.h:
Protocol/SSLOG/Inc/sslog_records.h:
Generated/Inc/project_device_instances.h:
Interfaces/Inc/system_barometer_if.h:
Interfaces/Inc/system_device_types.h:
Interfaces/Inc/system_descriptor_if.h:
Interfaces/Inc/system_gnss_if.h:
Interfaces/Inc/system_hardware_quaternion_if.h:
Interfaces/Inc/system_imu_if.h:
Interfaces/Inc/system_imu_epoch_if.h:
Interfaces/Inc/system_magnetometer_if.h:
Interfaces/Inc/system_power_if.h:
Interfaces/Inc/system_telemetry_transport_if.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
System/Inc/system_lifecycle.h:
System/User/system_user_config.h:
System/Inc/system_configuration_types.h:
System/User/system_user_flight_config.h:
Targets/SilverStar_F407/Inc/target_system_config.h:
System/Inc/system_capabilities.h:
System/User/system_user_alignment_config.h:
System/Alignment/Inc/system_alignment.h:
System/User/system_user_capability_validation.h:
System/User/system_user_platform_capabilities.h:
