build/FCCG/SilverStar_F407/ReleaseO0/auto/Devices/Storage/SdSdioFatFs/Adapter/Src/mag_calibration_storage.o: \
 Devices/Storage/SdSdioFatFs/Adapter/Src/mag_calibration_storage.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 Interfaces/Inc/system_mag_calibration_storage_if.h \
 Devices/Storage/SdSdioFatFs/Adapter/Inc/persistent_storage.h \
 Interfaces/Inc/system_storage_if.h Interfaces/Inc/system_device_types.h \
 Common/Inc/silverstar_compiler.h \
 Generated/Inc/project_device_instances.h \
 Interfaces/Inc/system_barometer_if.h \
 Interfaces/Inc/system_descriptor_if.h Interfaces/Inc/system_gnss_if.h \
 Interfaces/Inc/system_hardware_quaternion_if.h \
 Interfaces/Inc/system_imu_if.h Interfaces/Inc/system_imu_epoch_if.h \
 Interfaces/Inc/system_magnetometer_if.h Interfaces/Inc/system_power_if.h \
 Interfaces/Inc/system_telemetry_transport_if.h \
 System/Calibration/Inc/system_mag_calibration.h \
 Common/Inc/silverstar_assert.h Common/Inc/silverstar_compiler.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
Interfaces/Inc/system_mag_calibration_storage_if.h:
Devices/Storage/SdSdioFatFs/Adapter/Inc/persistent_storage.h:
Interfaces/Inc/system_storage_if.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
Generated/Inc/project_device_instances.h:
Interfaces/Inc/system_barometer_if.h:
Interfaces/Inc/system_descriptor_if.h:
Interfaces/Inc/system_gnss_if.h:
Interfaces/Inc/system_hardware_quaternion_if.h:
Interfaces/Inc/system_imu_if.h:
Interfaces/Inc/system_imu_epoch_if.h:
Interfaces/Inc/system_magnetometer_if.h:
Interfaces/Inc/system_power_if.h:
Interfaces/Inc/system_telemetry_transport_if.h:
System/Calibration/Inc/system_mag_calibration.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
