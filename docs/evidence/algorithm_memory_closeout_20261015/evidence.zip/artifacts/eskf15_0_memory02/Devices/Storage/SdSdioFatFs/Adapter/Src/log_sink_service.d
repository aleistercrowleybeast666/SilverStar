build/FCCG/SilverStar_F407/ReleaseO0/auto/Devices/Storage/SdSdioFatFs/Adapter/Src/log_sink_service.o: \
 Devices/Storage/SdSdioFatFs/Adapter/Src/log_sink_service.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 Interfaces/Inc/system_log_sink_if.h Interfaces/Inc/system_device_types.h \
 Common/Inc/silverstar_compiler.h Platform/Inc/platform_time.h \
 Platform/Inc/platform_types.h Platform/Inc/platform_critical.h \
 Common/Inc/silverstar_assert.h Common/Inc/silverstar_compiler.h \
 System/User/system_user_config.h System/Inc/system_configuration_types.h \
 System/User/system_user_flight_config.h \
 Targets/SilverStar_F407/Inc/target_system_config.h \
 System/Inc/system_capabilities.h Interfaces/Inc/system_device_types.h \
 System/User/system_user_alignment_config.h \
 System/Alignment/Inc/system_alignment.h \
 System/User/system_user_capability_validation.h \
 System/User/system_user_platform_capabilities.h \
 Interfaces/Inc/system_storage_if.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
Interfaces/Inc/system_log_sink_if.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
Platform/Inc/platform_time.h:
Platform/Inc/platform_types.h:
Platform/Inc/platform_critical.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
System/User/system_user_config.h:
System/Inc/system_configuration_types.h:
System/User/system_user_flight_config.h:
Targets/SilverStar_F407/Inc/target_system_config.h:
System/Inc/system_capabilities.h:
Interfaces/Inc/system_device_types.h:
System/User/system_user_alignment_config.h:
System/Alignment/Inc/system_alignment.h:
System/User/system_user_capability_validation.h:
System/User/system_user_platform_capabilities.h:
Interfaces/Inc/system_storage_if.h:
