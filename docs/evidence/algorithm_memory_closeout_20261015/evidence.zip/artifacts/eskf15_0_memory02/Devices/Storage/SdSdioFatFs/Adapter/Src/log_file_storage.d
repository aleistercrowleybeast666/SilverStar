build/FCCG/SilverStar_F407/ReleaseO0/auto/Devices/Storage/SdSdioFatFs/Adapter/Src/log_file_storage.o: \
 Devices/Storage/SdSdioFatFs/Adapter/Src/log_file_storage.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 System/Inc/system_log_file.h System/Inc/system_console.h \
 Interfaces/Inc/system_device_types.h Common/Inc/silverstar_compiler.h \
 Generated/Inc/project_storage_binding.h FATFS/App/fatfs.h \
 Middlewares/Third_Party/FatFs/src/ff.h \
 Middlewares/Third_Party/FatFs/src/integer.h FATFS/Target/ffconf.h \
 Core/Inc/main.h Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal.h \
 Core/Inc/stm32f4xx_hal_conf.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_def.h \
 Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f4xx.h \
 Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f407xx.h \
 Drivers/CMSIS/Include/core_cm4.h Drivers/CMSIS/Include/cmsis_version.h \
 Drivers/CMSIS/Include/cmsis_compiler.h Drivers/CMSIS/Include/cmsis_gcc.h \
 Drivers/CMSIS/Include/mpu_armv7.h \
 Drivers/CMSIS/Device/ST/STM32F4xx/Include/system_stm32f4xx.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc_ex.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio_ex.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_exti.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma_ex.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_cortex.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_adc.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_adc.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_adc_ex.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ex.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ramfunc.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr_ex.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_sd.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_sdmmc.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_spi.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_tim.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_tim_ex.h \
 Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_uart.h \
 FATFS/Target/bsp_driver_sd.h FATFS/Target/fatfs_platform.h \
 Middlewares/Third_Party/FatFs/src/ff_gen_drv.h \
 Middlewares/Third_Party/FatFs/src/diskio.h \
 Middlewares/Third_Party/FatFs/src/ff.h FATFS/Target/sd_diskio.h \
 Interfaces/Inc/system_storage_if.h Interfaces/Inc/system_device_types.h \
 System/Inc/system_lifecycle.h System/User/system_user_config.h \
 System/Inc/system_configuration_types.h \
 System/User/system_user_flight_config.h \
 Targets/SilverStar_F407/Inc/target_system_config.h \
 System/Inc/system_capabilities.h \
 System/User/system_user_alignment_config.h \
 System/Alignment/Inc/system_alignment.h \
 System/User/system_user_capability_validation.h \
 System/User/system_user_platform_capabilities.h \
 Common/Inc/silverstar_assert.h Common/Inc/silverstar_compiler.h \
 Platform/Inc/platform_memory.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
System/Inc/system_log_file.h:
System/Inc/system_console.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
Generated/Inc/project_storage_binding.h:
FATFS/App/fatfs.h:
Middlewares/Third_Party/FatFs/src/ff.h:
Middlewares/Third_Party/FatFs/src/integer.h:
FATFS/Target/ffconf.h:
Core/Inc/main.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal.h:
Core/Inc/stm32f4xx_hal_conf.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_def.h:
Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f4xx.h:
Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f407xx.h:
Drivers/CMSIS/Include/core_cm4.h:
Drivers/CMSIS/Include/cmsis_version.h:
Drivers/CMSIS/Include/cmsis_compiler.h:
Drivers/CMSIS/Include/cmsis_gcc.h:
Drivers/CMSIS/Include/mpu_armv7.h:
Drivers/CMSIS/Device/ST/STM32F4xx/Include/system_stm32f4xx.h:
Drivers/STM32F4xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc_ex.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio_ex.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_exti.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma_ex.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_cortex.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_adc.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_adc.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_adc_ex.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ex.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ramfunc.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr_ex.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_sd.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_sdmmc.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_spi.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_tim.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_tim_ex.h:
Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_uart.h:
FATFS/Target/bsp_driver_sd.h:
FATFS/Target/fatfs_platform.h:
Middlewares/Third_Party/FatFs/src/ff_gen_drv.h:
Middlewares/Third_Party/FatFs/src/diskio.h:
Middlewares/Third_Party/FatFs/src/ff.h:
FATFS/Target/sd_diskio.h:
Interfaces/Inc/system_storage_if.h:
Interfaces/Inc/system_device_types.h:
System/Inc/system_lifecycle.h:
System/User/system_user_config.h:
System/Inc/system_configuration_types.h:
System/User/system_user_flight_config.h:
Targets/SilverStar_F407/Inc/target_system_config.h:
System/Inc/system_capabilities.h:
System/User/system_user_alignment_config.h:
System/Alignment/Inc/system_alignment.h:
System/User/system_user_capability_validation.h:
System/User/system_user_platform_capabilities.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
Platform/Inc/platform_memory.h:
