build/FCCG/SilverStar_F407/ReleaseO0/auto/Devices/Console/UART/Src/console_uart_device.o: \
 Devices/Console/UART/Src/console_uart_device.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 Devices/Console/UART/Inc/console_uart_device.h \
 Platform/Inc/platform_uart.h Platform/Inc/platform_types.h \
 Generated/Inc/project_resources.h Platform/Inc/platform_adc.h \
 Platform/Inc/platform_gpio.h \
 Platform/STM32F4/Inc/platform_stm32f4_resources.h \
 Platform/Inc/platform_can.h Platform/Inc/platform_i2c.h \
 Platform/Inc/platform_pwm.h Platform/Inc/platform_spi.h \
 Platform/Inc/platform_time.h Interfaces/Inc/system_device_types.h \
 Common/Inc/silverstar_compiler.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
Devices/Console/UART/Inc/console_uart_device.h:
Platform/Inc/platform_uart.h:
Platform/Inc/platform_types.h:
Generated/Inc/project_resources.h:
Platform/Inc/platform_adc.h:
Platform/Inc/platform_gpio.h:
Platform/STM32F4/Inc/platform_stm32f4_resources.h:
Platform/Inc/platform_can.h:
Platform/Inc/platform_i2c.h:
Platform/Inc/platform_pwm.h:
Platform/Inc/platform_spi.h:
Platform/Inc/platform_time.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
