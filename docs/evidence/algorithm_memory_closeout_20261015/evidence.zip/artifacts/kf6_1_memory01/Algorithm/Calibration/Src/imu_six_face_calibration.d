build/FCCG/SilverStar_F407/Release/Algorithm/Calibration/Src/imu_six_face_calibration.o: \
 Algorithm/Calibration/Src/imu_six_face_calibration.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 Algorithm/Calibration/Inc/imu_six_face_calibration.h \
 Common/Inc/silverstar_assert.h Common/Inc/silverstar_compiler.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
Algorithm/Calibration/Inc/imu_six_face_calibration.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
