build/FCCG/SilverStar_F407/Release/FlightLogic/FlightCycle/Src/silverstar_flight_recovery.o: \
 FlightLogic/FlightCycle/Src/silverstar_flight_recovery.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 System/Inc/system_flight_recovery.h Interfaces/Inc/system_device_types.h \
 Common/Inc/silverstar_compiler.h \
 Interfaces/Inc/system_mission_action_if.h \
 Interfaces/Inc/system_device_types.h \
 System/Inc/system_configuration_types.h \
 FlightLogic/Deployment/MultiTrigger/Inc/flight_deployment.h \
 System/Inc/system_configuration_types.h \
 FlightLogic/Landing/BarometerImuWindow/Inc/flight_landing.h \
 Platform/Inc/platform_critical.h Common/Inc/silverstar_assert.h \
 Common/Inc/silverstar_compiler.h System/Inc/system_lifecycle.h \
 System/User/system_user_config.h System/User/system_user_flight_config.h \
 Targets/SilverStar_F407/Inc/target_system_config.h \
 System/Inc/system_capabilities.h \
 System/User/system_user_alignment_config.h \
 System/Alignment/Inc/system_alignment.h \
 System/User/system_user_capability_validation.h \
 System/User/system_user_platform_capabilities.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
System/Inc/system_flight_recovery.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
Interfaces/Inc/system_mission_action_if.h:
Interfaces/Inc/system_device_types.h:
System/Inc/system_configuration_types.h:
FlightLogic/Deployment/MultiTrigger/Inc/flight_deployment.h:
System/Inc/system_configuration_types.h:
FlightLogic/Landing/BarometerImuWindow/Inc/flight_landing.h:
Platform/Inc/platform_critical.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
System/Inc/system_lifecycle.h:
System/User/system_user_config.h:
System/User/system_user_flight_config.h:
Targets/SilverStar_F407/Inc/target_system_config.h:
System/Inc/system_capabilities.h:
System/User/system_user_alignment_config.h:
System/Alignment/Inc/system_alignment.h:
System/User/system_user_capability_validation.h:
System/User/system_user_platform_capabilities.h:
