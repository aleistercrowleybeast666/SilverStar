build/FCCG/SilverStar_F407/Release/FlightLogic/Landing/BarometerImuWindow/Src/flight_landing.o: \
 FlightLogic/Landing/BarometerImuWindow/Src/flight_landing.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 FlightLogic/Landing/BarometerImuWindow/Inc/flight_landing.h \
 Common/Inc/silverstar_assert.h Common/Inc/silverstar_compiler.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
FlightLogic/Landing/BarometerImuWindow/Inc/flight_landing.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
