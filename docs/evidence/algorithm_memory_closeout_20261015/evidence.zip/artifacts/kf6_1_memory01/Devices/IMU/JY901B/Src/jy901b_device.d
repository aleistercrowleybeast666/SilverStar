build/FCCG/SilverStar_F407/Release/Devices/IMU/JY901B/Src/jy901b_device.o: \
 Devices/IMU/JY901B/Src/jy901b_device.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 Devices/IMU/JY901B/Inc/jy901b_device.h Generated/Inc/project_resources.h \
 Platform/Inc/platform_adc.h Platform/Inc/platform_types.h \
 Platform/Inc/platform_gpio.h Platform/Inc/platform_uart.h \
 Platform/STM32F4/Inc/platform_stm32f4_resources.h \
 Platform/Inc/platform_can.h Platform/Inc/platform_i2c.h \
 Platform/Inc/platform_pwm.h Platform/Inc/platform_spi.h \
 Platform/Inc/platform_time.h Interfaces/Inc/system_device_types.h \
 Common/Inc/silverstar_compiler.h Devices/IMU/JY901B/Inc/jy901b_config.h \
 Devices/IMU/JY901B/Inc/jy901b_device.h \
 Devices/IMU/JY901B/Adapter/Inc/jy901b_magnetometer_build_capabilities.h \
 Platform/Inc/platform_critical.h Common/Inc/silverstar_assert.h \
 Common/Inc/silverstar_compiler.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
Devices/IMU/JY901B/Inc/jy901b_device.h:
Generated/Inc/project_resources.h:
Platform/Inc/platform_adc.h:
Platform/Inc/platform_types.h:
Platform/Inc/platform_gpio.h:
Platform/Inc/platform_uart.h:
Platform/STM32F4/Inc/platform_stm32f4_resources.h:
Platform/Inc/platform_can.h:
Platform/Inc/platform_i2c.h:
Platform/Inc/platform_pwm.h:
Platform/Inc/platform_spi.h:
Platform/Inc/platform_time.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
Devices/IMU/JY901B/Inc/jy901b_config.h:
Devices/IMU/JY901B/Inc/jy901b_device.h:
Devices/IMU/JY901B/Adapter/Inc/jy901b_magnetometer_build_capabilities.h:
Platform/Inc/platform_critical.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
