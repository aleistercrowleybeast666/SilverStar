build/FCCG/SilverStar_F407/Release/Devices/IMU/JY901B/Adapter/Src/jy901b_sample_quality.o: \
 Devices/IMU/JY901B/Adapter/Src/jy901b_sample_quality.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 Devices/IMU/JY901B/Adapter/Inc/jy901b_sample_quality.h \
 Interfaces/Inc/system_imu_if.h Interfaces/Inc/system_device_types.h \
 Common/Inc/silverstar_compiler.h Interfaces/Inc/system_imu_epoch_if.h \
 Common/Inc/silverstar_assert.h Common/Inc/silverstar_compiler.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
Devices/IMU/JY901B/Adapter/Inc/jy901b_sample_quality.h:
Interfaces/Inc/system_imu_if.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
Interfaces/Inc/system_imu_epoch_if.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
