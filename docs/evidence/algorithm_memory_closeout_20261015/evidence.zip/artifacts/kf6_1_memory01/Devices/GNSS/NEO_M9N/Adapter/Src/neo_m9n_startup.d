build/FCCG/SilverStar_F407/Release/Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_startup.o: \
 Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_startup.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 Devices/GNSS/NEO_M9N/Adapter/Inc/neo_m9n_startup.h \
 System/Inc/system_device_startup.h Interfaces/Inc/system_gnss_if.h \
 Interfaces/Inc/system_device_types.h Common/Inc/silverstar_compiler.h \
 Devices/GNSS/NEO_M9N/Inc/neo_m9n_config.h \
 Generated/Inc/project_resources.h Platform/Inc/platform_adc.h \
 Platform/Inc/platform_types.h Platform/Inc/platform_gpio.h \
 Platform/Inc/platform_uart.h \
 Platform/STM32F4/Inc/platform_stm32f4_resources.h \
 Platform/Inc/platform_can.h Platform/Inc/platform_i2c.h \
 Platform/Inc/platform_pwm.h Platform/Inc/platform_spi.h \
 Platform/Inc/platform_time.h Interfaces/Inc/system_device_types.h \
 Devices/GNSS/NEO_M9N/Inc/neo_m9n_config_keys.h \
 Devices/GNSS/NEO_M9N/Inc/neo_m9n_device.h Platform/Inc/platform_memory.h \
 Common/Inc/silverstar_assert.h Common/Inc/silverstar_compiler.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
Devices/GNSS/NEO_M9N/Adapter/Inc/neo_m9n_startup.h:
System/Inc/system_device_startup.h:
Interfaces/Inc/system_gnss_if.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
Devices/GNSS/NEO_M9N/Inc/neo_m9n_config.h:
Generated/Inc/project_resources.h:
Platform/Inc/platform_adc.h:
Platform/Inc/platform_types.h:
Platform/Inc/platform_gpio.h:
Platform/Inc/platform_uart.h:
Platform/STM32F4/Inc/platform_stm32f4_resources.h:
Platform/Inc/platform_can.h:
Platform/Inc/platform_i2c.h:
Platform/Inc/platform_pwm.h:
Platform/Inc/platform_spi.h:
Platform/Inc/platform_time.h:
Interfaces/Inc/system_device_types.h:
Devices/GNSS/NEO_M9N/Inc/neo_m9n_config_keys.h:
Devices/GNSS/NEO_M9N/Inc/neo_m9n_device.h:
Platform/Inc/platform_memory.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
