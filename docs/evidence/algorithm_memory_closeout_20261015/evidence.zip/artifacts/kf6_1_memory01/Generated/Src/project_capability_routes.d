build/FCCG/SilverStar_F407/Release/Generated/Src/project_capability_routes.o: \
 Generated/Src/project_capability_routes.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 Generated/Inc/project_capability_routes.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
Generated/Inc/project_capability_routes.h:
