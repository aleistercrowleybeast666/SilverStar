build/FCCG/SilverStar_F407/Release/Protocol/SSLOG/Src/sslog_protocol.o: \
 Protocol/SSLOG/Src/sslog_protocol.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 Protocol/SSLOG/Inc/sslog_protocol.h Protocol/SSLOG/Inc/sslog_records.h \
 Common/Inc/silverstar_assert.h Common/Inc/silverstar_compiler.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
Protocol/SSLOG/Inc/sslog_protocol.h:
Protocol/SSLOG/Inc/sslog_records.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
