build/FCCG/SilverStar_F407/Release/Middlewares/Third_Party/SX1280lib/sx1280.o: \
 Middlewares/Third_Party/SX1280lib/sx1280.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 Middlewares/Third_Party/SX1280lib/sx1280.h \
 Middlewares/Third_Party/SX1280lib/sx1280-hal.h \
 Middlewares/Third_Party/SX1280lib/hw.h Generated/Inc/project_resources.h \
 Platform/Inc/platform_adc.h Platform/Inc/platform_types.h \
 Platform/Inc/platform_gpio.h Platform/Inc/platform_uart.h \
 Platform/STM32F4/Inc/platform_stm32f4_resources.h \
 Platform/Inc/platform_can.h Platform/Inc/platform_i2c.h \
 Platform/Inc/platform_pwm.h Platform/Inc/platform_spi.h \
 Platform/Inc/platform_time.h Interfaces/Inc/system_device_types.h \
 Common/Inc/silverstar_compiler.h \
 Devices/Telemetry/SX1281/Inc/sx1281_bus.h Platform/Inc/platform_types.h \
 Platform/Inc/platform_critical.h \
 Middlewares/Third_Party/SX1280lib/RangingCorrection.h \
 Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF5BW0400.h \
 Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrection_defines.h \
 Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF6BW0400.h \
 Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF7BW0400.h \
 Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF8BW0400.h \
 Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF9BW0400.h \
 Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF10BW0400.h \
 Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF5BW0800.h \
 Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF6BW0800.h \
 Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF7BW0800.h \
 Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF8BW0800.h \
 Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF9BW0800.h \
 Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF10BW0800.h \
 Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF5BW1600.h \
 Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF6BW1600.h \
 Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF7BW1600.h \
 Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF8BW1600.h \
 Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF9BW1600.h \
 Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF10BW1600.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
Middlewares/Third_Party/SX1280lib/sx1280.h:
Middlewares/Third_Party/SX1280lib/sx1280-hal.h:
Middlewares/Third_Party/SX1280lib/hw.h:
Generated/Inc/project_resources.h:
Platform/Inc/platform_adc.h:
Platform/Inc/platform_types.h:
Platform/Inc/platform_gpio.h:
Platform/Inc/platform_uart.h:
Platform/STM32F4/Inc/platform_stm32f4_resources.h:
Platform/Inc/platform_can.h:
Platform/Inc/platform_i2c.h:
Platform/Inc/platform_pwm.h:
Platform/Inc/platform_spi.h:
Platform/Inc/platform_time.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
Devices/Telemetry/SX1281/Inc/sx1281_bus.h:
Platform/Inc/platform_types.h:
Platform/Inc/platform_critical.h:
Middlewares/Third_Party/SX1280lib/RangingCorrection.h:
Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF5BW0400.h:
Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrection_defines.h:
Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF6BW0400.h:
Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF7BW0400.h:
Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF8BW0400.h:
Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF9BW0400.h:
Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF10BW0400.h:
Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF5BW0800.h:
Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF6BW0800.h:
Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF7BW0800.h:
Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF8BW0800.h:
Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF9BW0800.h:
Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF10BW0800.h:
Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF5BW1600.h:
Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF6BW1600.h:
Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF7BW1600.h:
Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF8BW1600.h:
Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF9BW1600.h:
Middlewares/Third_Party/SX1280lib/rangingCorrection/rangingCorrectionSF10BW1600.h:
