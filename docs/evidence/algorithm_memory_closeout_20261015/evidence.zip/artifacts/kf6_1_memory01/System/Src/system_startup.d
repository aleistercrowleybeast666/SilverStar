build/FCCG/SilverStar_F407/Release/System/Src/system_startup.o: \
 System/Src/system_startup.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 System/Inc/system_startup.h Interfaces/Inc/system_device_types.h \
 Common/Inc/silverstar_compiler.h Interfaces/Inc/system_gnss_if.h \
 Interfaces/Inc/system_device_types.h Common/Inc/debug_log.h \
 Common/Inc/silverstar_assert.h Common/Inc/silverstar_compiler.h \
 Generated/Inc/project_device_build_capabilities.h \
 Interfaces/Inc/system_barometer_if.h System/Inc/system_console.h \
 Interfaces/Inc/system_console_if.h System/Inc/system_health.h \
 System/Inc/system_capabilities.h \
 Interfaces/Inc/system_hardware_quaternion_if.h \
 Interfaces/Inc/system_imu_if.h Interfaces/Inc/system_imu_epoch_if.h \
 System/Inc/system_lifecycle.h System/User/system_user_config.h \
 System/Inc/system_configuration_types.h \
 System/User/system_user_flight_config.h \
 Targets/SilverStar_F407/Inc/target_system_config.h \
 System/Inc/system_capabilities.h \
 System/User/system_user_alignment_config.h \
 System/Alignment/Inc/system_alignment.h \
 System/User/system_user_capability_validation.h \
 System/User/system_user_platform_capabilities.h \
 System/Inc/system_log_policy.h Protocol/SSLOG/Inc/sslog_records.h \
 Interfaces/Inc/system_magnetometer_if.h \
 System/Inc/system_navigation_profile.h \
 System/Inc/system_configuration_types.h \
 Interfaces/Inc/system_output_if.h Interfaces/Inc/system_power_if.h \
 System/Inc/system_profile.h Interfaces/Inc/system_storage_if.h \
 Interfaces/Inc/system_telemetry_transport_if.h System/Inc/system_time.h \
 System/User/system_user_startup_config.h \
 System/Inc/system_barometer_cold.h System/Inc/system_startup.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
System/Inc/system_startup.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
Interfaces/Inc/system_gnss_if.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/debug_log.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
Generated/Inc/project_device_build_capabilities.h:
Interfaces/Inc/system_barometer_if.h:
System/Inc/system_console.h:
Interfaces/Inc/system_console_if.h:
System/Inc/system_health.h:
System/Inc/system_capabilities.h:
Interfaces/Inc/system_hardware_quaternion_if.h:
Interfaces/Inc/system_imu_if.h:
Interfaces/Inc/system_imu_epoch_if.h:
System/Inc/system_lifecycle.h:
System/User/system_user_config.h:
System/Inc/system_configuration_types.h:
System/User/system_user_flight_config.h:
Targets/SilverStar_F407/Inc/target_system_config.h:
System/Inc/system_capabilities.h:
System/User/system_user_alignment_config.h:
System/Alignment/Inc/system_alignment.h:
System/User/system_user_capability_validation.h:
System/User/system_user_platform_capabilities.h:
System/Inc/system_log_policy.h:
Protocol/SSLOG/Inc/sslog_records.h:
Interfaces/Inc/system_magnetometer_if.h:
System/Inc/system_navigation_profile.h:
System/Inc/system_configuration_types.h:
Interfaces/Inc/system_output_if.h:
Interfaces/Inc/system_power_if.h:
System/Inc/system_profile.h:
Interfaces/Inc/system_storage_if.h:
Interfaces/Inc/system_telemetry_transport_if.h:
System/Inc/system_time.h:
System/User/system_user_startup_config.h:
System/Inc/system_barometer_cold.h:
System/Inc/system_startup.h:
