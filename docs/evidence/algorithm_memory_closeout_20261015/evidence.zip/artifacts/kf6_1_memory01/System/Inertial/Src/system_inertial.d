build/FCCG/SilverStar_F407/Release/System/Inertial/Src/system_inertial.o: \
 System/Inertial/Src/system_inertial.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 System/Inertial/Inc/system_inertial.h \
 System/Inertial/Inc/system_inertial_source_if.h \
 Interfaces/Inc/system_device_types.h Common/Inc/silverstar_compiler.h \
 System/Inertial/Inc/system_inertial_types.h \
 Interfaces/Inc/system_imu_epoch_if.h \
 Interfaces/Inc/system_device_types.h Interfaces/Inc/system_imu_if.h \
 Interfaces/Inc/system_imu_epoch_if.h Common/Inc/silverstar_assert.h \
 Common/Inc/silverstar_compiler.h \
 System/User/system_user_inertial_config.h \
 System/Inertial/Inc/system_inertial_source_if.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
System/Inertial/Inc/system_inertial.h:
System/Inertial/Inc/system_inertial_source_if.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
System/Inertial/Inc/system_inertial_types.h:
Interfaces/Inc/system_imu_epoch_if.h:
Interfaces/Inc/system_device_types.h:
Interfaces/Inc/system_imu_if.h:
Interfaces/Inc/system_imu_epoch_if.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
System/User/system_user_inertial_config.h:
System/Inertial/Inc/system_inertial_source_if.h:
