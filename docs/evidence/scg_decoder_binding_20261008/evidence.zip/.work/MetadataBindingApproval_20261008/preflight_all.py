from pathlib import Path
import json, hashlib, re, importlib.util, datetime, subprocess, ast
repo=Path.cwd();out=Path(__file__).resolve().parent
root=out/'project/Flight_Controller'
tool=repo/'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tools/check_task_stacks.py'
spec=importlib.util.spec_from_file_location('preflight_checker',tool)
stacks=importlib.util.module_from_spec(spec);spec.loader.exec_module(stacks)
target=json.loads((root/'SilverStar.ssproject').read_text(encoding='utf8'))['build']['target_profile']
build=root/'build/FCCG'/target/'Release/auto'
manifest=(root/'Generated/project_sources.mk').read_text(encoding='utf8')
block=re.search(r'(?ms)^C_SOURCES \+= \\\n(.*?)(?:\n\n|\Z)',manifest)
assert block
sources=[line.strip().removesuffix('\\').strip() for line in block[1].splitlines()]
rows=[];inputs={};failures=[]
def check_input(path, origin):
    resolved=(root/path).resolve();resolved.relative_to(root.resolve())
    row=inputs.setdefault(path,{'path':path,'origins':[]})
    if origin not in row['origins']:row['origins'].append(origin)
    if 'status' in row:return
    if not resolved.is_file():row.update(status='MISSING');return
    data=resolved.read_bytes();text=resolved.read_text(encoding='utf8')
    digest=stacks.BindingSourceHash_Get(text)
    versions=stacks.BindingSourceVersions_Get(path)
    row.update(sha256_raw=hashlib.sha256(data).hexdigest(),sha256_normalized=digest,
               status='KNOWN' if digest in versions else 'UNKNOWN',reviewed_versions_count=len(versions))
for source in sources:
    check_input(source,'compiled-source')
    row={'source':source,'su_present':(build/Path(source).with_suffix('.su')).is_file()}
    dep=build/Path(source).with_suffix('.d')
    row['dependency_report_present']=dep.is_file()
    if dep.is_file():
        dependencies=dep.read_text(encoding='utf8').split(':',1)[1].replace('\\\n',' ').split('\n',1)[0].split()
        expected=(stacks.BINDING_DEPENDENCIES_V2.get(source,[]) +
          stacks.BINDING_DEPENDENCIES_EPOCH_V3.get(source,[]) +
          stacks.BINDING_DEPENDENCIES_NRF_V5.get(source,[]) +
          stacks.BINDING_DEPENDENCIES_HEALTH_V6.get(source,[]) +
          stacks.BINDING_DEPENDENCIES_POWER_V7.get(source,[]) +
          stacks.BINDING_DEPENDENCIES_RF_QUEUE_V9.get(source,[]))
        digest=hashlib.sha256('\n'.join(dependencies).encode()).hexdigest()
        row.update(dependency_graph_sha256=digest,dependency_graph_status='KNOWN' if digest in expected else 'UNKNOWN',dependencies=dependencies)
        for path in dependencies:check_input(path,source)
    rows.append(row)
# Cover literal extra BindingHeader_Verify calls even if not in .d manifests.
for call in ast.walk(ast.parse(tool.read_text(encoding='utf8'))):
    if isinstance(call,ast.Call) and isinstance(call.func,ast.Name) and call.func.id=='BindingHeader_Verify' and len(call.args)>1 and isinstance(call.args[1],ast.Constant) and isinstance(call.args[1].value,str):
        check_input(call.args[1].value,'explicit-header-contract')
unknown=[row for row in inputs.values() if row['status']!='KNOWN']
graph_unknown=[row for row in rows if not row['dependency_report_present'] or row.get('dependency_graph_status')!='KNOWN']
stack_missing=[row['source'] for row in rows if not row['su_present']]
record={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'checker_sha256':hashlib.sha256(tool.read_bytes()).hexdigest(),
 'fixture':str(root),'compiled_sources_count':len(sources),'distinct_inputs_count':len(inputs),
 'unknown_inputs':unknown,'unknown_dependency_graphs':graph_unknown,'missing_stack_reports':stack_missing,
 'sources':rows,'inputs':sorted(inputs.values(),key=lambda row:row['path']),
 'scope':'Identity preflight only. Every source and dependency checked independently; no monkeypatch, skipping or gate PASS claim.',
 'stack_gate':'Still FAIL; actual downstream stack bounds cannot be claimed before all identity gates pass.'}
(out/'preflight_all.json').write_text(json.dumps(record,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in record.items() if k not in ('sources','inputs')},indent=2))
