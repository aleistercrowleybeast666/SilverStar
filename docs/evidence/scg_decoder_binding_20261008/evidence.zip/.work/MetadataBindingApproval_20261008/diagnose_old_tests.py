from pathlib import Path
import sys, json, copy, os
repo=Path.cwd();out=Path(__file__).resolve().parent
sys.path.insert(0,str(repo/'apps/SCG/src'))
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.project.model import ProjectModel_Parse,ProjectModelError,PROJECT_FORMAT_VERSION
from silverstar_fccg.project.reference import ReferenceProject_Create
from silverstar_fccg.generator.assembler import ProjectAssembler
from silverstar_fccg.core.workspace import WorkspacePolicy
service=FccgService(repo/'apps/SCG');catalog=service.catalog
model=ReferenceProject_Create('CurrentStorage',catalog=catalog)
data=model.Dictionary_Get()
row={'current_roundtrip_equal':ProjectModel_Parse(copy.deepcopy(data)).Dictionary_Get()==data,
 'base_format_constant':PROJECT_FORMAT_VERSION,'serialized_format':data['format_version'],
 'supported_formats':[14,15,16,17],'test_claimed_unknown_format':PROJECT_FORMAT_VERSION+1}
legacy=copy.deepcopy(data);legacy['format_version']=9
for item in legacy['components']['devices']:
    item.pop('interface',None);item.pop('profile',None)
for label,value in [('format9_shape',legacy),('claimed_unknown15',dict(copy.deepcopy(data),format_version=15)),('actual_unknown18',dict(copy.deepcopy(data),format_version=18))]:
    try:ProjectModel_Parse(value);row[label]={'rejected':False}
    except ProjectModelError as e:row[label]={'rejected':True,'message':str(e)}
root=out/'diagnostic_collision';assert not root.exists()
assembler=ProjectAssembler(WorkspacePolicy(out),catalog)
model=ReferenceProject_Create('StorageOwnershipMigration',catalog=catalog)
assembler.Apply(model,assembler.Plan(model,root))
ownership_path=root/'.fccg/ownership.json';ownership=json.loads(ownership_path.read_text(encoding='utf8'))
storage='silverstar.device.storage.sd_sdio_fatfs';board='silverstar.board.silverstar_0_5'
sp=ownership['components'].pop(storage);ownership['active_components'].remove(storage)
bp=ownership['components'][board];oldroot=root/'Board/SilverStar_0_5/Services/Src';oldroot.mkdir(parents=True,exist_ok=True)
moved={}
for name in ('storage_service.c','log_sink_service.c'):
    relative=f'Devices/Storage/SdSdioFatFs/Adapter/Src/{name}'
    newpath=root/relative;oldpath=oldroot/name
    moved[relative]={'sha256_in_ownership':sp['files'][relative],'old_test_path_exists':(root/f'Devices/Storage/SdSdioFatFs/Src/{name}').exists()}
    oldpath.write_bytes(newpath.read_bytes());newpath.unlink()
    bp['files'][f'Board/SilverStar_0_5/Services/Src/{name}']=sp['files'][relative]
ownership_path.write_text(json.dumps(ownership,indent=2,sort_keys=True)+'\n',encoding='utf8')
plan=assembler.Plan(model,root)
conflicts={op.target for op in plan.operations if op.operation=='CONFLICT'}
storage_ops={op.target:op.operation for op in plan.operations if op.target.startswith('Devices/Storage/SdSdioFatFs/')}
expectations={'invalid_plan':not plan.valid,
 'persistent_c_conflict':any(p.endswith('persistent_storage.c') for p in conflicts),
 'persistent_h_conflict':any(p.endswith('persistent_storage.h') for p in conflicts),
 'log_sink_added':storage_ops.get('Devices/Storage/SdSdioFatFs/Adapter/Src/log_sink_service.c')=='ADD',
 'storage_service_added':storage_ops.get('Devices/Storage/SdSdioFatFs/Adapter/Src/storage_service.c')=='ADD',
 'storage_conflicts':all(storage_ops.get(p)=='CONFLICT' for p in conflicts),
 'no_board_conflicts':not any(p.startswith('Board/SilverStar_0_5/Services/') for p in conflicts)}
row['collision_diagnostic']={'scope':'Separate private fixture with current Adapter paths; original tests and production code unmodified. All original post-plan safety expectations retained.',
 'moved':moved,'expectations':expectations,'all_original_post_plan_expectations_met':all(expectations.values()),'conflicts':sorted(conflicts)}
(out/'old_tests_diagnosis.json').write_text(json.dumps(row,indent=2),encoding='utf8')
print(json.dumps(row,indent=2))
