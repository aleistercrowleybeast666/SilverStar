from pathlib import Path
import sys,subprocess,zipfile,io,importlib.util,json
repo=Path(__file__).resolve().parents[2]
out=Path(__file__).resolve().parent
archive=subprocess.check_output(['git','archive','--format=zip','e702ffd','apps/SCG/src','VERSION'],cwd=repo)
root=out/'baseline_source3';root.mkdir(exist_ok=False)
with zipfile.ZipFile(io.BytesIO(archive)) as bundle:
    for name in bundle.namelist():
        destination=(root/name).resolve()
        assert destination.is_relative_to(root.resolve())
    bundle.extractall(root)
sys.path.append(str(repo/'.venv/Lib/site-packages'))
sys.path[:0]=[str(root/'apps/SCG/src'),str(repo/'apps/FLP/src'),str(repo/'apps/FLP')]
import pytest
from silverstar_fccg.ui import main_window
assert Path(main_window.__file__).resolve().is_relative_to(root.resolve())
print('BASELINE '+str(main_window.__file__),flush=True)
# The extracted Python source uses __file__ only here to locate the existing
# application workspace/default manifest. Rebind those two filesystem anchors
# so this source-only baseline uses the same plugins and allowed temp paths.
# No code object, model policy, plugin bytes or validation expectation changes.
from silverstar_fccg.project import reference
main_window.__file__=str(repo/'apps/SCG/src/silverstar_fccg/ui/main_window.py')
reference.__file__=str(repo/'apps/SCG/src/silverstar_fccg/project/reference.py')
plugins=[]
for name in ('normal_test_paths','closeout_test_paths'):
    spec=importlib.util.spec_from_file_location(name,repo/'docs/evidence/nightly_software_20261008'/f'{name}.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);plugins.append(module)
raise SystemExit(pytest.main(['-p','no:cacheprovider',*sys.argv[1:]],plugins=plugins))
