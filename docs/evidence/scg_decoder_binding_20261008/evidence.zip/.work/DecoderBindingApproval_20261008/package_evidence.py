from pathlib import Path
import json, subprocess, hashlib, zipfile, datetime, ast
repo=Path.cwd();out=Path(__file__).resolve().parent
prior=repo/'.work/MetadataBindingApproval_20261008'
delivery=repo/'docs/evidence/scg_decoder_binding_20261008';delivery.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
paths=['apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tools/check_task_stacks.py',
 'apps/SCG/tools/reference_overlays/check_task_stacks.py','apps/SCG/tests/test_stack_budget.py',
 'docs/SCG_STORAGE_MAINTENANCE_ACCEPTANCE_20261008.md']
snapshot=subprocess.check_output(['git','diff','--binary']);(out/'dirty_snapshot.patch').write_bytes(snapshot)
# Verify only one literal review table was added; all prior literal policy/state
# assignments, including task limits and existing binding tables, are identical.
def assignments(text):
    return {target.id:ast.dump(node.value,include_attributes=False) for node in ast.parse(text).body
      if isinstance(node,ast.Assign) for target in node.targets if isinstance(target,ast.Name)}
for path in paths[:2]:
    old=assignments(subprocess.check_output(['git','show','HEAD:'+path]).decode('utf8'))
    new=assignments((repo/path).read_text(encoding='utf8'))
    assert set(new)-set(old)=={'BINDING_SOURCE_PRODUCT_DECODER_V14'}
    assert all(new[k]==v for k,v in old.items())
prepare=json.loads((out/'prepare.json').read_text());project=out/'project/Flight_Controller'
for name,digest in prepare['target_and_compiled_artifacts'].items():
    assert sha((project/name).read_bytes())==digest,name
budget_path=project/'build/FCCG/SilverStar_F407/Release/auto/stack-budget.json'
budget=json.loads(budget_path.read_text());assert budget['passes']
assert len(budget['binding_source_proofs'])==155
assert budget['elf_sha256']==sha((project/budget['elf']).read_bytes())
versions={}
for name,cmd in {'python':['apps/FLP/.venv/Scripts/python.exe','--version'],
 'make':['D:/msys64/ucrt64/bin/mingw32-make.exe','--version'],
 'arm_gcc':['D:/Arm GNU Toolchain/14.3 rel1/bin/arm-none-eabi-gcc.exe','--version'],
 'host_gcc':['D:/msys64/ucrt64/bin/gcc.exe','--version']}.items():
    versions[name]=subprocess.check_output(cmd,text=True).strip()
commands={}
for label,args,log,expected in [
 ('pre_test',['apps/SCG/tests/test_stack_budget.py','-k','product_decoder_binding','-q','--basetemp=apps/SCG/.work/db_pre','--tb=short'],'pre',1),
 ('owner_test',['apps/SCG/tests/test_stack_budget.py','-q','--basetemp=apps/SCG/.work/db_post','--tb=short'],'tests_owner',0),
 ('overlay_test',['apps/SCG/tests/test_stack_budget.py','-q','--basetemp=apps/SCG/.work/db_overlay','--tb=short'],'tests_overlay',0)]:
    actual=int((out/(log+'.exit.txt')).read_text().strip());assert actual==expected
    commands[label]={'command':['apps/FLP/.venv/Scripts/python.exe','-B','.work/gui012_20261008/run_pytest.py',*args],
      'cwd':str(repo),'exit_code':actual,'log':log+'.log','QT_QPA_PLATFORM':'offscreen','PYTHONDONTWRITEBYTECODE':'1'}
commands['overlay_test']['SILVERSTAR_STACK_CHECKER_SOURCE']=str(repo/paths[1])
for label,args in [('stack',['stack-report']),('affected_gates',['architecture-check','power10-check','artifact-check'])]:
    actual=int((out/(label+'.exit.txt')).read_text().strip());assert actual==0
    commands[label]={'command':['D:/msys64/ucrt64/bin/mingw32-make.exe','-j2',*args,'GCC_PATH=D:/Arm GNU Toolchain/14.3 rel1/bin'],
     'cwd':str(project),'exit_code':actual,'log':label+'.log',
     'log_lastwrite_utc':datetime.datetime.fromtimestamp((out/(label+'.log')).stat().st_mtime,datetime.timezone.utc).isoformat()}
for label,selector,base in [('radio_diagnostic','flight_all_variants_selector_add_delete_save_power_and_bindings','mb_radio_diag'),
                          ('radio_none_diagnostic','delete_final_flight_selection_does_not_revive_a_device','mb_none_diag')]:
    actual=int((prior/(label+'.exit.txt')).read_text().strip());assert actual==0
    commands[label]={'command':['../../apps/FLP/.venv/Scripts/python.exe','-B','../../.work/gui012_20261008/run_pytest.py',
      'tests/test_radio_variants_gui.py','-k',selector,'-q','--basetemp=.work/'+base,'--tb=short'],
      'cwd':str(repo/'apps/SCG'),'exit_code':actual,'QT_QPA_PLATFORM':'offscreen','PYTHONDONTWRITEBYTECODE':'1'}
files=[p for p in out.iterdir() if p.is_file()]+[repo/p for p in paths]+[budget_path,
 project/'Makefile',project/'Tools/check_task_stacks.py',project/'Tools/check_power_of_ten.ps1',
 project/'Generated/Src/project_metadata.c',project/'Generated/Src/project_log_decoder_profile.c',
 repo/'.work/gui012_20261008/run_pytest.py',
 repo/'docs/evidence/nightly_software_20261008/normal_test_paths.py',
 repo/'docs/evidence/nightly_software_20261008/closeout_test_paths.py',
 repo/'docs/evidence/logger_health_retest_20261008/generated_config.ssproject',
 repo/'docs/evidence/scg_metadata_binding_20261008/manifest.json',
 repo/'docs/evidence/scg_storage_maintenance_20261008/manifest.json',
 repo/'.work/StorageMaintenanceAcceptance_20261008/baseline_stale3.log',
 repo/'.work/StorageMaintenanceAcceptance_20261008/baseline_stale_tests.py']
files += [prior/p for p in ['preflight_all.py','preflight_all.json','diagnose_old_tests.py',
 'old_tests_diagnosis.json','old_tests_diagnosis.log','radio_diagnostic.log','radio_diagnostic.exit.txt',
 'radio_none_diagnostic.log','radio_none_diagnostic.exit.txt','stack.log','stack.exit.txt','decoder_probe.json','decoder_diff.patch']]
files += [repo/'.work/finalized_health_20261008_v2/project/Flight_Controller/Generated/Src/project_log_decoder_profile.c']
members={}
with zipfile.ZipFile(delivery/'evidence.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for path in files:
        name=path.relative_to(repo).as_posix();data=path.read_bytes();assert name not in members
        z.writestr(name,data);members[name]=sha(data)
record={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_head':prepare['base_head'],
 'source_sha256':{p:sha((repo/p).read_bytes()) for p in paths},'dirty_snapshot_sha256':sha(snapshot),
 'authorization':'User explicitly authorized necessary, individually reviewed exact-source registrations before field testing. No arbitrary hashes, threshold relaxation or firmware logic changes authorized.',
 'only_new_registration':{'Generated/Src/project_log_decoder_profile.c':'ee5baec0a73077cdafee252ba8715045db8ee39e4b894c6846be3cd059392616'},
 'prior_literal_policy_assignments_unchanged':True,'commands':commands,'tools':versions,'prepare':prepare,
 'preflight':{k:v for k,v in json.loads((out/'preflight_all.json').read_text()).items() if k not in ('sources','inputs','stack_gate')},
 'decoder_probe':json.loads((out/'decoder_probe.json').read_text()),
 'stack':{'exit_code':0,'passes':budget['passes'],'source_proofs':len(budget['binding_source_proofs']),
  'tasks':budget['tasks'],'checks':budget['checks'],'whole_program_stack_acceptance':budget['whole_program_stack_acceptance'],
  'hardware_high_water_marks':budget['hardware_high_water_marks'],'elf_sha256':budget['elf_sha256']},
 'old_tests_diagnosis':json.loads((prior/'old_tests_diagnosis.json').read_text()),
 'old_failures':'Original 3 failed tests and both unknown-source FAIL logs preserved. Diagnostic fixtures did not modify source or original tests.',
 'critical_contract_review':'NOT_PROVEN manual_acceptance_pending; original PoT output preserved',
 'compile_reuse':'Verified same target C/h/s/ld and ARM release objects/dependencies/stack-frame reports/binary reused; no new ARM compilation/Host/analyzer claim.',
 'binary_sha256':{n:d for n,d in prepare['target_and_compiled_artifacts'].items() if n.endswith('.bin')},
 'hardware':'NOT RUN','user_project':'Not touched','C071':'Out of repository/release scope','push':'Not performed',
 'archive_sha256':sha((delivery/'evidence.zip').read_bytes()),'members':members}
(delivery/'manifest.json').write_text(json.dumps(record,indent=2),encoding='utf8')
with zipfile.ZipFile(delivery/'evidence.zip') as z:
    assert z.testzip() is None;assert set(z.namelist())==set(members)
    for name,digest in members.items():assert sha(z.read(name))==digest
print(json.dumps({'archive_sha256':record['archive_sha256'],'members':len(members),
 'stack_exit':0,'stack_passes':budget['passes'],'source_proofs':len(budget['binding_source_proofs']),
 'unknown_inputs':record['preflight']['unknown_inputs'],'source_hashes':record['source_sha256']},indent=2))
