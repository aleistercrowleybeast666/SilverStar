from pathlib import Path
from dataclasses import replace
import sys, json, hashlib, difflib, runpy
repo=Path.cwd();out=Path(__file__).resolve().parent
sys.path.insert(0,str(repo/'apps/SCG/src'))
from silverstar_fccg.project.model import ProjectModel_Load
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.generator.render import GeneratedFiles_Render
from silverstar_fccg.generator.source_graph import SourceGraph_Resolve
model=ProjectModel_Load(repo/'docs/evidence/logger_health_retest_20261008/generated_config.ssproject')
service=FccgService(repo/'apps/SCG')
name='Generated/Src/project_log_decoder_profile.c'
old=(repo/'.work/finalized_health_20261008_v2/project/Flight_Controller'/name).read_text(encoding='utf8')
new=(out/'project/Flight_Controller'/name).read_text(encoding='utf8')
render_new=GeneratedFiles_Render(model,service.catalog,SourceGraph_Resolve(model,service.catalog))[name].decode('utf8')
model.identity=replace(model.identity,firmware_version='0.1.1',build_target='SilverStar_0_1_1')
render_old=GeneratedFiles_Render(model,service.catalog,SourceGraph_Resolve(model,service.catalog))[name].decode('utf8')
sha=lambda s:hashlib.sha256(s.encode()).hexdigest()
checker=runpy.run_path(str(repo/'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tools/check_task_stacks.py'))
row={'new_sha256':sha(new),'old_sha256':sha(old),
 'old_render_matches_old_file':render_old.replace('\r\n','\n')==old,
 'new_render_matches_new_file':render_new.replace('\r\n','\n')==new,
 'new_hash_registered':sha(new) in checker['BindingSourceVersions_Get'](name)}
(out/'decoder_diff.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),'reviewed old0.1.1','current0.1.2')),encoding='utf8')
(out/'decoder_probe.json').write_text(json.dumps(row,indent=2),encoding='utf8')
print(json.dumps(row,indent=2))
