"""Compare every control field against pinned 45778d3 implementations.

This is diagnosis only. Existing fingerprints, production code and tests remain
unchanged. Old implementations are loaded only in this isolated host process.
"""
from dataclasses import fields
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
TASK = Path(__file__).resolve().parent
OUT = TASK / 'kf_historical_control01'
OUT.mkdir(exist_ok=False)
sys.path.insert(0, str(ROOT / 'apps/FLP'))
from tests.test_kf6_replay_failure_publication import _Faithful
from tests.test_audit_block_artifacts import _Fingerprint

CURRENT = {rev: _Faithful(revision=rev) for rev in (1, 2)}
PIN = subprocess.check_output(['git', 'rev-parse', '45778d3'], text=True).strip()
origin = 'apps/FLP/src/silverstar_flp/plugins/algorithms/kf6/'
sources = {}
for name in ('filter.py', 'fixed_lag.py'):
    data = subprocess.check_output(['git', 'show', PIN + ':' + origin + name])
    (OUT / name).write_bytes(data)
    sources[name] = hashlib.sha256(data).hexdigest()

def module_load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

old_filter = module_load('silverstar_historical_kf6_filter_45778d3', OUT / 'filter.py')
# The pinned replay imports its pinned filter through the normal fully qualified
# name. This isolated process has no shared interpreter or repository mutation.
sys.modules['silverstar_flp.plugins.algorithms.kf6.filter'] = old_filter
old_replay = module_load('silverstar_historical_kf6_replay_45778d3', OUT / 'fixed_lag.py')
_Faithful.__globals__['Kf6Filter'] = old_filter.Kf6Filter
_Faithful.__globals__['Faithful_Run'] = old_replay.Faithful_Run
expected = {1: 'c3e6d483291544d1a6402e9a31b8463dadf14635cfcb8d35734341a42f644ed8',
            2: '47aebe3aa2d5337050078d3786ea66206e2576e5a7dbfc5655b9f3c6ae81af5c'}
results = {}
for rev in (1, 2):
    old_snapshots, old_state, old_diagnostics = _Faithful(revision=rev)
    snapshots, state, diagnostics = CURRENT[rev]
    old_fields = [f.name for f in fields(old_state)]
    new_fields = [f.name for f in fields(state)]
    results[rev] = {
        'historical_fingerprint': _Fingerprint((old_snapshots, old_state)),
        'expected_unchanged': expected[rev],
        'current_fingerprint': _Fingerprint((snapshots, state)),
        'snapshot_bitwise_equal': _Fingerprint(snapshots) == _Fingerprint(old_snapshots),
        'shared_field_differences': [name for name in old_fields
            if _Fingerprint(getattr(state, name)) != _Fingerprint(getattr(old_state, name))],
        'added_fields': {name: getattr(state, name) for name in new_fields if name not in old_fields},
        'removed_fields': [name for name in old_fields if name not in new_fields],
        'historical_field_order': old_fields,
        'current_execution_mismatches': diagnostics['execution_mismatches'],
        'historical_execution_mismatches': old_diagnostics['execution_mismatches'],
    }
receipt = {'scope': __doc__, 'historical_commit': PIN, 'historical_source_sha256': sources, 'results': results}
(OUT / 'comparison.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(results))
assert all(row['historical_fingerprint'] == row['expected_unchanged'] for row in results.values())
assert all(row['snapshot_bitwise_equal'] and not row['shared_field_differences'] and not row['removed_fields'] for row in results.values())
