# Navigation closure02 checkpoint05 /2026-10-16

Continues04; HEAD21562359 unchanged; no active build/test process or missing-final
receipt at latest disconnect check. Parent status steering answered in commentary
and original task CONTINUES. No hardware/serial/DAP/flash/actuators/push/tag/release/
cleanup/subagents. Read04/03 for validated modules and remaining overall scope.

New configuration implementation (not yet backend activated):
- ESKF plugin now0.4.0,29 explicit gnss_recovery_* integer/float params appended
  to root algorithm_parameters list. Zero defaults/legacy defaults mean disabled/
  unconfigured, enabled default0. Full active policy validation required. Metadata
  gnss_reacquisition_contract declares schema/revision/enabled parameter; no
  navigation_semantics static fake config. Bilingual labels required by parser.
- apps/SCG/src/silverstar_fccg/project/gnss_reacquisition.py contains strict
  metadata/actual configuration validation, binary32 fields, frozen dataclass,
  wire CRC id, generation declaration. AlgorithmParameters_Resolve calls validator
  only for explicitly declared capability; Header_Render emits derived actual
  SYSTEM_ESKF_GNSS_RECOVERY_CONFIGURATION_ID. generator/render.py metadata helper
  injects separately resolved gnss_reacquisition declaration (wirehex/enabled/id).
- Config constraints: durations/counts positive whenenabled, stable>=2, allcaps
  positive,scale>1<=2, lossGap>maxInterval1..500ms,jitter0..interval, finite positive
  accelH/V/sigma. No approved flight values. Disabled placeholders cannot activate.
- Owner metadata source is actually root algorithm_parameters, not metadata;
  initial configure script lookup failed before writing anything. Corrected script
  executed once, beforemanifest snapshot/afterhash receipt retained.
- First config tests:1failed36passed1error. Caught real wire bug: uppercaseF in
  Python3.14 struct means complex, initial'<I4I4B16FI3F' size180, not104. Shared
  NEW uncommitted contract/helper corrected to'<I4I4B16fI3f' (float32 lowercasef),
  actual104B. Initial contract/helper/manifest retained recovery_config_prefault01.
  Catalogue error was missing mandatory zh_CN labels. repair_parameter_labels.py
  added29 Chinese labels/descriptions, no bounds/default changes.
- recovery_config02:38passed. Tests exact contract/order/104bytes, every field
  influences identity,36invalid/missing/incomplete cases, disabled defaults,
  actual generated header and opt-in declaration. Ruff not yet checked config
  helper/test. No production FLP parser compatibility0.4 yet; old0.3 must stay
  supported separately, frozen horizonv1 contract/old logs unchanged.

Additional GNSS owned-metadata fault boundary (current changes after prior fresh
receipt ARM outputs, so those binaries do NOT validate this latest source):
- Added case4 in actual receipt fixture: invalid active withinMAX but>=realcount,
  invalid activeposition/order/count and count0 withactive source. Corrupt owned
  state must return BAD_STATE, preserve output, restore critical nesting.
- gnss_receipt_corrupt_prefault06:2failed8passed O0/O2 against previous owning
  code. Real bad owned states returned success/ordinary invalidarg instead of
  explicit BAD_STATE and sometimes changed caller output. Frozen before02
  selector/fixture copies retained.
- GnssActiveInstanceGet now holds nested-safe critical, validates count/active/
  position/order before array read, returns BAD_STATE vs ordinary no selection.
  LatestSampleGet also holds critical across validated selected source, cache copy
  and64-bit freshness barrier read. No device processing/control IO in lock.
  Full globalInit/reset still requires quiesced startup consumers; header documents
  this precondition. Runtime publication helper remains atomic as previous fix.
- gnss_receipt_corrupt_postfix07:49passed (new10 receipt cases +actual source
  selector fault contracts +M9N startup). Scope audit now expects seven existing
  GNSS functions changed/two newhelpers from original before01.126->124 other
  functions unchanged, including all wireless. audit script updated to output02,
  preserve previous report01. Need run current audit02 after writing checkpoint.

Actual backend code inspected but NOT edited yet. Key integration points:
- Initialize setsstate.timestamp0, captures calibrationgen, resets ordinary replay
  for mode1. Actual epoch established in Backend_PredictionEpochStart (~1110):
  state.timestamp=body.start; reset mode1history or mode2horizon; health epoch;
  logsinitialstate then s_started1. RecoveryReset MUST occur here after epoch setup.
- staticconfigs/state at top; const filter s_config, raw bodyhistory, mode1history
  CCM viaPLATFORM_ESKF_HISTORY_BSS, mode2horizon mainSRAM. Optional companion globals
  must be collectable when featuredisabled/modeunused; no capacity/budget changes.
- Backend_EventApply (~760): assignsgeneration,lever, routesmode2 toHorizonRequest;
  mode1setsAngularRate and Replay_Insert; mode0 CurrentEventApply. Extend these
  paths with immutable per-group recovery evidence and actual action logging.
- Backend_CurrentEventApply validates packet/group times then existing Update;
  numeric ormodelmismatch latchescurrentfault. Keep ordinaryinvalid/NIS semantics.
- Backend_HorizonRequest (~575) queues viaHorizon_Insert afterHealthReceiveOnly.
  Extend to recovery Insert with same evidence from original receipt.
- Backend_HorizonCompletionsDrain (~675) loops64 and calls ordinaryPop then
  CompletionPublish. RecoveryPop returns actual action only after full commit.
- HorizonCycle BodyReceive->GnssUpdate->BaroUpdate->Advance->Drain->health->snapshot.
  Call receiptReceive beforeTick(evaluationpresent), thenRecoveryAdvance whenon.
- PresentOrReplayCycle (~1160) ordinaryReplayPredict orCurrentPredict, then GNSS/
  baro, snapshot. Need optionalReplayRecoveryPredict/currentRecoveryUpdate.
- Existing legacy mode1 SnapshotGet does not latch all numeric failures; enabled
  recovery needs separatefault latch checked allmodes to withdrawREADY, preserving
  disabled oldbehavior. New moduleinvalid/corruptstate must not merelyreturnwhile
  staleREADY remains. Ordinary bad packets/timing/NIS/unknownclock stayordinary.
- Need new Recovery_SourceUnavailable API breaking receive chains once while
  preserving physical loss history; Tick afterprocessing newreceipt, neverrewind.
- Switch Backend_GnssUpdate to atomicreceipt once, and consistency/quality logs to
  captured native/source (ordinary window uses its existing admission, recovery
  strongerclockproof). Avoid metadata reads from a later selected source.
- Examine source-handoff stale completion: current CompletionPublish treats any
  HealthFusionOnly error asfault. If BAD_STATE means oldsourcecompletion, likely
  skip health credit normally while retaining actual numerical/log outcome;
  verify actual health semantics and tests before changing. No stale READY.
- Potential currentP corruption before mode1rewind still needs manual/fault test;
  old replay rebuild can overwrite fromanchor. Do not claim solved/unprovenPASS.

Source layer findings: sslog_records.h is ordinary version-controlled owning
protocol source (not generated). Count42, maxpayload256, records0x2F/0x30 free.
EVENT namespace0x2F used, mustnotchange. Only two new streams toavoidunnecessary
RAM growth (see04 arithmeticwarning, actuallinksrequired). Wireconfig104bytes
+16prefix prospective120B. Combined receipt/action kind payload needs<=existing
estimator slot payload toavoidqueue/slotgrowth; actual size check before design.
Record source/schema/catalog/LoggerBus/FLP exact record contracts stillTODO.

Remaining major work: backend activation, strict versioned wire/FLP replay,
1/5/30/120s complete active faultmatrix allmodes, current freshgenerated full
gates/static-analysis/ARM/artifact/stack exactinput review, protected hashes/formal
evidence/scoped localcommit. No full compliance/manual/hardware/WCET/stack claim.

Additional read-only findings after checkpoint creation:
- Actual old task model Project_Open sees currentcatalog/view ESKF0.4 but retains
  old39params; ProjectConfiguration_Reconcile adds29 placeholders=>68ES+2INS=70.
  Existing preserved source provenance still describes older payload. Exact
  FusionTimingDeclaration_Get rejects it (expected NOTPROVEN, no files written).
  Do not weaken this guard or overwrite old model/provenance/user code. Future
  validation models must be explicitly NEW source instances with new names and
  current owning sources, retaining ONLY derived configuration from old input;
  record old input SHA and explicit fresh-source choice. Never clear provenance
  in the original project or silently present old binaries as current evidence.
- M9N pvtSequence is a host MCU parser counter, incremented on each validPVT.
  Runtime selector recovery usesStop/Start for alreadyinitialized instance;
  adapterInit short-circuits when initialized; Stop/Start preserve driverdata.
  Only driver Init->Gnss_RuntimeStateResetLocked zerosdata. Thus ordinary M9N
  receiver reconnect/runtime recovery does NOT reset this counter; no reason to
  weaken anti-replay checks or add a speculative source-epoch API. Other drivers
  with unproven counter/lifecycle may stayineligible, not declaredqualified.
- Full SystemGnss_Init target caller foundonly system_startup.c:SystemStartup_
  GnssStart (~507), before lifecycle startup; runtime recovery invokes perinstance
  ports. Tests have their own calls. Full global init quiescence needs preserve.
- New generator declaration now additionally invokes existing exact timing/source
  provenance validation itself, so standalone calls cannot claim a configuration
  for preserved mismatching payload. Added negative test. Pendingrerun config03.
