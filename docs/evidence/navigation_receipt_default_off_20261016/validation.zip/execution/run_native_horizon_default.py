"""Fresh native-mode generated headers, both actual backends; no mode overrides."""
import os
from pathlib import Path
import subprocess
import sys

TASK=Path(__file__).resolve().parent
ROOT=TASK.parents[1]
env={**os.environ,'SILVERSTAR_HORIZON_STAGE_PROJECT':str(TASK/'eskf15_2_default03'),
     'SILVERSTAR_HORIZON_KF_STAGE_PROJECT':str(TASK/'kf6_2_default01'),
     'SILVERSTAR_HORIZON_NATIVE_CONFIGURATION':'1','SILVERSTAR_FCCG_ROOT':str(ROOT/'apps/SCG')}
raise SystemExit(subprocess.call([sys.executable,'-m','pytest','-q',
    'apps/SCG/tests/test_eskf15_horizon_backend.py','apps/SCG/tests/test_kf6_horizon_backend.py',
    '--basetemp='+str(TASK/'hn02')],cwd=ROOT,env=env))
