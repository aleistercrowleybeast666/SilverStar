"""Exact new default-off mode0 packages and fresh real C exported CPU logs."""
import os
from pathlib import Path
import subprocess
import sys

TASK=Path(__file__).resolve().parent
ROOT=TASK.parents[1]
env={**os.environ,'SILVERSTAR_FCCG_ROOT':str(ROOT/'apps/SCG')}
for kind,variable,extension in (('eskf15','ESKF','.sslog'),('kf6','KF','.jsonl')):
    variant='default03' if kind=='eskf15' else 'default01'
    project=TASK/(kind+'_0_'+variant)
    decoder,=project.glob('*.ssdecoder')
    env['SILVERSTAR_CURRENT_'+variable+'_TRACE']=str(TASK/(kind+'_current_'+variant+extension))
    env['SILVERSTAR_CURRENT_'+variable+'_DECODER']=str(decoder)
raise SystemExit(subprocess.call([sys.executable,'-m','pytest','-q',
    'apps/FLP/tests/test_fusion_current_native_parity.py',
    'apps/FLP/tests/test_eskf15_native_parity.py',
    '--basetemp='+str(TASK/'cp04')],cwd=ROOT,env=env))
