"""Diagnostic only: exact proposed tuples, with all existing stack logic intact.

This isolated process is never the emitted production gate or an acceptance.
It estimates no frames; actual .su/ELF feed the unchanged analyzer. Production
registration requires the separate source/object review and negative tests.
"""
import importlib.util
import json
from pathlib import Path
import traceback

TASK=Path(__file__).resolve().parent
ROOT=TASK.parents[1]
tool=ROOT/'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tools/check_task_stacks.py'
census=json.loads((TASK/'stack_input_census01.json').read_text(encoding='utf8'))
for name,data in census['projects'].items():
    spec=importlib.util.spec_from_file_location('probe_'+name,tool)
    stacks=importlib.util.module_from_spec(spec);spec.loader.exec_module(stacks)
    # Temporary explicit candidate input registration in this diagnostic process.
    for source,closure in data['closures'].items():
        stacks.BINDING_SOURCE_ALGORITHM_TIMING_V18.setdefault(source,[]).append(closure['source_sha256'])
        stacks.BINDING_DEPENDENCIES_ALGORITHM_TIMING_V18.setdefault(source,[]).append(closure['dependency_sha256'])
        stacks.BINDING_COMPILED_INPUTS_ALGORITHM_TIMING_V18.setdefault(source,[]).append(closure['closure'])
        for path,digest in closure['inputs']:
            stacks.BINDING_SOURCE_ALGORITHM_TIMING_V18.setdefault(path,[]).append(digest)
    result={'scope':'CANDIDATE_DIAGNOSTIC_ONLY_NOT_EMITTED_GATE_NOT_ACCEPTANCE','project':name}
    try:
        result['report']=stacks.StackReport_Build(ROOT/'.work/dev013_horizon01'/name,'Release','arm-none-eabi-',data['layout'])
        print(name,'candidate task result',result['report']['passes'],flush=True)
    except Exception:
        result['error']=traceback.format_exc();print(name,result['error'],flush=True)
    with (TASK/(name+'_candidate_stack02.json')).open('x',encoding='utf8') as stream:json.dump(result,stream,indent=2)
