"""Use the generator's exact payload-copy operation for an explicit gate-only revision."""
from hashlib import sha256
import json
from pathlib import Path
import sys

TASK=Path(__file__).resolve().parent
ROOT=TASK.parents[1]
sys.path.insert(0,str(ROOT/'apps/SCG/src'))
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.core.workspace import WorkspacePolicy

service=FccgService(ROOT/'apps/SCG')
manifest=service.catalog.Component_Get('silverstar.core.0_1_0')
relative='Tools/check_task_stacks.py'
source,=[p for p in manifest.PayloadFiles_Get() if p.relative_to(manifest.payload_root).as_posix()==relative]
review=json.loads((ROOT/'docs/evidence/navigation_receipt_default_off_20261016/manifest.json').read_text())
assert sha256(source.read_bytes()).hexdigest()==review['checker_after_sha256']
emission=TASK/'gate_emission_v20'
assert not emission.exists()
emitted=WorkspacePolicy(emission).File_Copy(source,relative)
assert emitted.read_bytes()==source.read_bytes()
record=dict(owner='/root',purpose='explicit owning v20 stack gate revision; no target C change',
    method='manifest.PayloadFiles_Get + WorkspacePolicy.File_Copy, same as ProjectAssembler._NewProject_Apply',
    before_sha256=review['checker_before_sha256'],after_sha256=review['checker_after_sha256'],projects={})
for name in ('eskf15_0_default03','eskf15_1_default03','eskf15_2_default03',
             'kf6_0_default01','kf6_1_default01','kf6_2_default01'):
    project=TASK/name
    target=(project/relative).resolve()
    assert target.is_relative_to(TASK)
    assert sha256(target.read_bytes()).hexdigest()==review['checker_before_sha256']
    power='Tools/check_power_of_ten.ps1'
    assert (project/power).read_bytes()==(manifest.payload_root/power).read_bytes()
    WorkspacePolicy(project).File_Copy(emitted,relative)
    assert target.read_bytes()==source.read_bytes()
    record['projects'][name]=dict(checker_sha256=sha256(target.read_bytes()).hexdigest(),
        power10_sha256=sha256((project/power).read_bytes()).hexdigest(),target_C_changed=False)
with (TASK/'gate_emission_v20.json').open('x',encoding='utf8') as output:json.dump(record,output,indent=2)
print('exact v20 payload emitted to',len(record['projects']),'task-only gate locations; power10 unchanged')
