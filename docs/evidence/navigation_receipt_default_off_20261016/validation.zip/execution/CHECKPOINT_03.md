# Navigation closure02 checkpoint03 / 2026-10-16

Owner /root; HEAD21562359; same existing feature branch; no hardware, push/tag/
release, cleanup, new branch/worktree, or subagents. User goal remains active
ESKF recovery then1/5/30/120s outages and modes0/1/2 closure, as prior checkpoint.

Stack v19 phase fully committed; no gate process remains running. Actual fresh
GNSS receipt safety projects kf6_2_receipt01 and eskf15_2_receipt01 now completed
all POWER10_CHECK/ARCHITECTURE_CHECK/BUILD/ARTIFACT_CHECK/STATIC_ANALYSIS with
recorded return_code0. Outer sessions94402/32309 exited0 (439/459s). These exact
snapshots contain atomic GNSS selector publication and new receipt C source,
before the later recovery edits. Do not attribute them to current changed replay/
horizon sources. Updated exact stack input review still pending after final C.

GNSS actual race before-fix4failed2passed, after6passed and extended/regression59
passed. Current new Python receipt test Ruff passes. audit_gnss_scope.py finds131
old functions,126 unchanged, exactly five changed GNSS functions/two new GNSS
helpers; wireless bytes unchanged.16 protected inputs hashes and v0.1.2 tag were
just reverified unchanged. Existing SX1278/user input files remain untracked.

New owning ESKF recovery module copied from frozen draft into payload, registered
in ESKF plugin build. Original draft unchanged. Native_us now explicitly separate
from MCU time, no cross-clock magnitude comparison. New independent-native
test first2failed/250deselected against old draft. Updated250tests passed; old
draft's native99ms-as-future case no longer applies to separate-clock contract,
replaced with positive separate-origin and duplicate-native tests; all other
old bad-evidence/fault expectations retained. Recovery receives caller-proven
clock continuity/coherent masks; backend qualification still NOT implemented.

Added direct UpdateCandidateRevision2 operation preserving exact stable reset
kernel (not a different lever model; both use rotating lever arms). New32 denseP
counterfactual tests prove Revision2 differs from legacy and wrapper matches exact
full State/Outcome; invalid angular/NaNP preserves original invalid error before
optional scaling. Initial new tests failed due unsupported NIS mask then trust-
region-exceeding observation; retained. Final recovery_revision2_05:284passed.
PolicyValidate exposed for companion authority checks; this came after284 run.

Optional static companions preserve original replay/horizon context/event ABI,
capacities and ordinary APIs. No backend activation yet, no new default setting.
- navigation_eskf_replay_recovery.h companion config, anchor/current/working
  policies, transaction and208 immutable evidence entries. Replay_Run pairs
  workingP/policy; Insert commits current only on full success; prefix commits
  anchor policy withP; insert/remove/trim shifts evidence at identical indexes.
  ReceiveState never replayed. New wrappers reject object overlap, invalid
  config/policy, checked results; barometer remains ordinary kernel.
- navigation_eskf_horizon_recovery.h companion config, primary/candidate policies,
  transaction,64 evidence/actions. Queue insertion/removal shifts companion;
  uses Revision2; commits policy only after complete output prediction alongsideP;
  output prediction never changes policy. Completion action exposed after commit.
  Caller must consistently use recovery API variants (no embedded ctx pointer).
- Both modules still need broader critical review, generated safety gates and
  actual ARM/link budget/stack review. Corrupt companion Ready returns INVALID;
  future backend must explicitly latch fault and withdraw READY, never just return.
  Consider numeric corruption of legacy currentP before rewind: existing replay
  rebuild can overwrite from anchor; active-recovery critical fault behavior needs
  review/test, not an unsupported claim that all corruption is handled.

Tests completed:
- recovery_replay01:10passed O0/O2; reorder canonical fullP/policy equality,
  no receive-FSM mutation, one surviving scale attempt, prefix eviction,
  invalid source failure rollback, invalid config authority, duplicate/historymiss
  no refill. Fixture synthetic policy only.
- recovery_legacy_abi01:15passed exact pre-workspace-rework traces;8FLP skips
  were accurately retained because explicit source absent. Reran with
  SILVERSTAR_FCCG_ROOT=D:/python_software/SilverStar/apps/SCG:
  recovery_flp_native02:8passed, no skips.
- recovery_horizon_ordinary01:70passed all existing horizon cases unchanged.
- recovery_horizon_companion01:6fail fixture (wrong BodyReceive expected result,
  omitted required audit variance/scales). Fixed actual contract, not firmware.
- recovery_horizon_companion02:6passed O0/O2. Four monotonic receive sequences
  with source epochs1.3/1.1/1.2/1.35s sort companion immutable ordinals correctly;
  final full225P primary/output and policy match direct Revision2 reference.
  CPU-only Predict interception fires AFTER candidate scale before final output;
  primaryP/policy/output unchanged, horizon faulted, no completion publication.
  Corrupt policy returnsINVALID/no commit. Interception only test fixture.

Current source modifications include ESKF replay/horizon C, new recovery C/three
headers, owning manifests, GNSS selector/receipt, tests/build-input lists. No
backend C/config/shared contract/logger/production FLP source changes yet.
Existing tests compiling replay/horizon now link recovery C; historical baseline
comparison adds it only for current source. Preserve archival evidence files.

Next: physical/native qualifier with explicit parameters, honest iTOW week/
source/time proof and uncertainty/acceleration/closure screens; opt-in actual
validated recorded configuration; backend allmodes policy pairing + receive
FSM; versioned wire records/contracts and exact-decoder FLP reconstruction;
1/5/30/120s integrated matrix; full fresh generated static/ARM/artifact/stack.
Need source snapshot/sealing/formal evidence/scoped commits after verified stage.
Not complete and no flight/navigation/hardware accuracy/WCET/MSP/ISR claim.
