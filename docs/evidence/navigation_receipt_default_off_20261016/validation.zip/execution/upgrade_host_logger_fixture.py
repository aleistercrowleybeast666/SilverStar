"""Verified task-owned emitted Host fixture revision; target C and user projects untouched."""
from hashlib import sha256
import json
from pathlib import Path

TASK=Path(__file__).resolve().parent
ROOT=TASK.parents[1]
project=TASK/'eskf15_1_default03'
relative='Tests/Host/test_logger.c'
target=(project/relative).resolve()
assert target.is_relative_to(TASK)
generation=json.loads((TASK/'eskf15_1_default03_generation.json').read_text(encoding='utf8'))
old=sha256(target.read_bytes()).hexdigest()
assert old==generation['files'][relative]
owner=ROOT/'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload'/relative
record=dict(owner='/root',purpose='explicit Host-only fixture revision: exact existing horizon catalog identities',
    target=str(target),before_sha256=old,after_sha256=sha256(owner.read_bytes()).hexdigest(),
    target_firmware_sources_changed=False)
with (TASK/'host_logger_harness_revision02.json').open('x',encoding='utf8') as output:json.dump(record,output,indent=2)
target.write_bytes(owner.read_bytes())
assert sha256(target.read_bytes()).hexdigest()==record['after_sha256']
print('verified task-owned Host fixture update',record['after_sha256'])
