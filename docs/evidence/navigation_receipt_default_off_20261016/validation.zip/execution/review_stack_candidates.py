"""Full byte diffs and actual object indirect-site inventory; no admission edit."""
from hashlib import sha256
import difflib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import zipfile

TASK=Path(__file__).resolve().parent
ROOT=TASK.parents[1]
tool=ROOT/'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tools/check_task_stacks.py'
spec=importlib.util.spec_from_file_location('stacks',tool)
stacks=importlib.util.module_from_spec(spec);spec.loader.exec_module(stacks)
census=json.loads((TASK/'stack_input_census01.json').read_text(encoding='utf8'))
record={'scope':'review candidates only; no gate PASS', 'projects':{},
    'checker_sha256':sha256(tool.read_bytes()).hexdigest(),
    'compiler':subprocess.check_output(['arm-none-eabi-gcc','--version'],text=True)}
patch=[]
with zipfile.ZipFile(TASK/'stack_review_candidate_inputs02.zip','x',zipfile.ZIP_DEFLATED) as archive:
    for name,data in census['projects'].items():
        project=ROOT/'.work/dev013_horizon01'/name
        baseline=ROOT/'.work/dev013_algorithm_closeout01'/('kf6_0_memory02' if name.startswith('kf') else 'eskf15_0_storage02')
        build=project/'build/FCCG/SilverStar_F407/Release'
        if data['layout']!='legacy':build=build/data['layout']
        inputs={};objects={}
        for path,expected in data['unknown_inputs'].items():
            current=project/path;raw=current.read_bytes();text=current.read_text(encoding='utf8')
            assert stacks.BindingSourceHash_Get(text)==expected
            before=baseline/path
            old=before.read_text(encoding='utf8') if before.is_file() else ''
            known=bool(old and stacks.BindingSourceHash_Get(old) in stacks.BindingSourceVersions_Get(path))
            inputs[path]={'normalized_sha256':expected,'raw_sha256':sha256(raw).hexdigest(),
                'baseline':str(before) if known else None,'new_or_no_reviewed_baseline':not known}
            archive.writestr(name+'/current/'+path,raw)
            if known:archive.writestr(name+'/before/'+path,before.read_bytes())
            patch.extend(difflib.unified_diff((old if known else '').splitlines(True),text.splitlines(True),
                fromfile=name+'/reviewed_before/'+path,tofile=name+'/current/'+path))
        for source in data['unknown_sources']:
            obj=build/Path(source).with_suffix('.o')
            result=subprocess.run(['arm-none-eabi-objdump','-dr',str(obj)],capture_output=True,text=True,check=True)
            functions={};function=None
            for line in result.stdout.splitlines():
                if match:=re.match(r'^[0-9a-f]+ <([^>]+)>:',line):function=match[1];functions[function]=[]
                elif function and (match:=re.match(r'^\s*[0-9a-f]+:\s+(?:[0-9a-f]{4,8}\s+)+(\S+)\s*(.*)',line)):
                    functions[function].append((match[1],match[2]))
            indirect={function:stacks.IndirectSites_Get(rows) for function,rows in functions.items()
                if stacks.IndirectSites_Get(rows)}
            objects[source]={'path':str(obj),'sha256':sha256(obj.read_bytes()).hexdigest(),
                'indirect_sites':indirect,'compiled_functions':list(functions)}
            archive.writestr(name+'/objects/'+Path(source).with_suffix('.disassembly.txt').as_posix(),result.stdout)
        for source in data['changed_graphs']:
            archive.write(build/Path(source).with_suffix('.d'),name+'/dependencies/'+Path(source).with_suffix('.d').as_posix())
        record['projects'][name]={'inputs':inputs,'objects':objects}
        print(name, 'changed compiled objects',len(objects),'indirect functions',
            sum(len(item['indirect_sites']) for item in objects.values()),flush=True)
(TASK/'stack_review_candidate_changes02.patch').write_text(''.join(patch),encoding='utf8')
with (TASK/'stack_review_candidates02.json').open('x',encoding='utf8') as stream:json.dump(record,stream,indent=2)
