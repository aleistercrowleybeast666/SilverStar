"""Identical no-origin owned-state fault expectations before and after the guard move."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

TASK=Path(__file__).resolve().parent
ROOT=TASK.parents[1]
relative='apps/SCG/plugins/builtin/silverstar_algorithm_estimator_eskf15/payload/Algorithm/Estimator/ESKF15/Src/navigation_eskf_backend.c'
baseline=TASK/'backend_before_origin_guard.c'
baseline.write_bytes((TASK/'eskf15_2_default01/Algorithm/Estimator/ESKF15/Src/navigation_eskf_backend.c').read_bytes())
results={}
for name,source in (('origin03_prefault',baseline),('origin03_postfix',ROOT/relative)):
    env={**os.environ,'SILVERSTAR_HORIZON_STAGE_PROJECT':str(TASK/'eskf15_2_default01'),
        'SILVERSTAR_HORIZON_NATIVE_CONFIGURATION':'1','SILVERSTAR_HORIZON_BACKEND_SOURCE':str(source)}
    command=[sys.executable,'-m','pytest','-q','apps/SCG/tests/test_eskf15_horizon_backend.py',
             '-k','without_preflight_origin','--basetemp='+str(TASK/(name+'_tmp'))]
    run=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,text=True)
    (TASK/(name+'.log')).write_text(run.stdout+run.stderr,encoding='utf8')
    results[name]=dict(command=command,exit_code=run.returncode,source=str(source),
        sha256=hashlib.sha256(source.read_bytes()).hexdigest())
with (TASK/'backend_origin_counterexample03.json').open('x',encoding='utf8') as output:
    json.dump(results,output,indent=2)
print({name:row['exit_code'] for name,row in results.items()})
assert results['origin03_prefault']['exit_code']==1 and results['origin03_postfix']['exit_code']==0
