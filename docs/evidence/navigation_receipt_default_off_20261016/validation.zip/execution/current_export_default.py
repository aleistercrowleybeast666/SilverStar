"""Fresh actual generated mode0 CPU export; real backend/logger, file sink only."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

TASK=Path(__file__).resolve().parent
ROOT=TASK.parents[1]
PRIOR=ROOT/'.work/dev013_timing_firmware01'
kind=sys.argv[1]
assert kind in ('kf6','eskf15')
prior=json.loads((PRIOR/('kf6_trace04.json' if kind=='kf6' else 'eskf_trace03.json')).read_text(encoding='utf8'))
variant=sys.argv[2] if len(sys.argv)>2 else 'default01'
assert variant in ('default01','default03')
project=TASK/(kind+'_0_'+variant)
old=Path(prior['project'])
prefix=kind+'_current_'+variant
executable=TASK/(prefix+'.exe')
assert not executable.exists()
graph=(project/'Generated/project_sources.mk').read_text(encoding='utf8')
match=re.search(r'^C_DEFS \+= \\\n(.*?)(?:\n\n|\Z)',graph,re.M|re.S)
definitions=['-D'+line.strip().rstrip('\\').strip() for line in match[1].splitlines() if line.strip()]
args=[];fixtures={}
for arg in prior['args']:
    if arg.startswith('-D') and not arg.startswith('-DTEST_'):continue
    changed=arg.replace(str(old),str(project)).replace(old.as_posix(),project.as_posix())
    path=Path(arg)
    if path.suffix=='.c' and path.is_absolute() and not path.is_relative_to(old):
        assert path.resolve().is_relative_to(PRIOR.resolve())
        fixture=TASK/(prefix+'_'+path.name)
        assert not fixture.exists()
        text=path.read_text(encoding='utf8').replace(str(old),str(project)).replace(old.as_posix(),project.as_posix())
        fixture.write_text(text,encoding='utf8')
        fixtures[str(fixture)]=dict(origin=str(path),origin_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
            sha256=hashlib.sha256(fixture.read_bytes()).hexdigest(),changes='fresh generated include paths only')
        changed=str(fixture)
    if path.suffix=='.exe':changed=str(executable)
    args.append(changed)
if kind=='eskf15':
    args += [str(project/'System/Src/system_gnss_receipt.c')]
    args += [str(project/'Algorithm/Estimator/ESKF15/Src'/('navigation_eskf_'+name+'.c'))
        for name in ('horizon','recovery','recovery_qualifier','recovery_configuration','reacquisition')]
command=[prior['compiler'],*definitions,*args]
result=subprocess.run(command,cwd=project,capture_output=True,text=True,encoding='utf8',errors='replace')
record=dict(scope=__doc__,command=command,cwd=str(project),fixtures=fixtures,
    compiler=subprocess.check_output([prior['compiler'],'--version'],text=True),
    compile_exit=result.returncode,compile_stdout=result.stdout,compile_stderr=result.stderr,
    sources={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in args if p.endswith('.c')},
    generated={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (project/'Generated').rglob('*') if p.is_file()})
if result.returncode==0:
    run_args=[str(TASK/(prefix+Path(arg).suffix)) if Path(arg).suffix in ('.sslog','.jsonl') else arg
              for arg in prior['run_args']]
    assert all(not Path(arg).exists() for arg in run_args if Path(arg).suffix in ('.sslog','.jsonl'))
    run=subprocess.run([str(executable),*run_args],cwd=project,capture_output=True,text=True)
    record.update(run_command=[str(executable),*run_args],run_exit=run.returncode,
        run_stdout=run.stdout,run_stderr=run.stderr,
        outputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in map(Path,run_args) if p.is_file()})
with (TASK/(prefix+'.json')).open('x',encoding='utf8') as output:json.dump(record,output,indent=2)
print(kind,'compile',record['compile_exit'],'run',record.get('run_exit'))
raise SystemExit(record.get('run_exit',record['compile_exit']))
