"""Exact actual compiler fixtures: no successful report or local project teaches admission."""
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import zipfile

import pytest

ROOT = Path(__file__).resolve().parents[3]
EVIDENCE = ROOT/'docs/evidence/navigation_horizon_stack_binding_20261016'
TOOL = ROOT/'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tools/check_task_stacks.py'
spec = importlib.util.spec_from_file_location('horizon_stack_binding', TOOL)
stacks = importlib.util.module_from_spec(spec)
spec.loader.exec_module(stacks)
SOURCE = 'APP/Src/estimator_bus.c'
PROJECTS = ('kf6_2_native03', 'eskf15_2_native02')


@pytest.fixture(params=PROJECTS)
def actual_compiler_inputs(request, tmp_path):
    manifest = json.loads((EVIDENCE/'manifest.json').read_text(encoding='utf8'))
    archive_path = EVIDENCE/'inputs.zip'
    assert sha256(archive_path.read_bytes()).hexdigest() == manifest['archive_sha256']
    prefix = 'compiler_fixture/'+request.param+'/'
    with zipfile.ZipFile(archive_path) as archive:
        for name in archive.namelist():
            if not name.startswith(prefix):
                continue
            raw = archive.read(name)
            assert sha256(raw).hexdigest() == manifest['entries'][name]
            relative = name.removeprefix(prefix)
            target = tmp_path/relative
            target.resolve().relative_to(tmp_path.resolve())
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
    build = tmp_path/'build'
    dependency = build/Path(SOURCE).with_suffix('.d')
    dependency.parent.mkdir(parents=True)
    dependency.write_bytes((tmp_path/'estimator_bus.d').read_bytes())
    return tmp_path, build, request.param


def test_exact_actual_mode2_compiler_input_tuple_is_admitted(actual_compiler_inputs):
    root, build, _ = actual_compiler_inputs
    proof, = stacks.BindingSources_Verify(root, [SOURCE], build)
    assert proof['source'] == SOURCE
    assert proof['compiled_input_sha256'] in stacks.BINDING_COMPILED_INPUTS_HORIZON_V19[SOURCE]


@pytest.mark.parametrize('mutation', ['missing_header', 'changed_header', 'added_input', 'changed_source'])
def test_mode2_input_mutation_remains_fail_closed(actual_compiler_inputs, mutation):
    root, build, _ = actual_compiler_inputs
    header = root/'Generated/Inc/project_flight_config.h'
    if mutation == 'missing_header':
        header.unlink()  # Deliberate fault in this test-owned copy only.
    elif mutation == 'changed_header':
        header.write_bytes(header.read_bytes() + b'\n#define UNREVIEWED_BOUNDARY 1\n')
    elif mutation == 'changed_source':
        source = root/SOURCE
        source.write_bytes(source.read_bytes() + b'\nvoid Changed_Binding(void) {}\n')
    else:
        (root/'unexpected.inc').write_text('/* fault input */\n', encoding='utf8')
        dependency = build/Path(SOURCE).with_suffix('.d')
        text = dependency.read_text(encoding='utf8')
        first, rest = text.split(':', 1)
        dependency.write_text(first+': unexpected.inc '+rest, encoding='utf8')
    with pytest.raises(ValueError):
        stacks.BindingSources_Verify(root, [SOURCE], build)


@pytest.mark.parametrize('replacement', ['legacy_approved', 'other_mode2_algorithm_approved'])
def test_individually_reviewed_inputs_cannot_form_unreviewed_mode2_tuple(actual_compiler_inputs, replacement):
    root, build, project = actual_compiler_inputs
    relative = 'Generated/Inc/project_flight_config.h'
    with zipfile.ZipFile(EVIDENCE/'inputs.zip') as archive:
        if replacement == 'legacy_approved':
            raw = archive.read('legacy/compiler_fixture/'+relative)
        else:
            other = next(name for name in PROJECTS if name != project)
            relative = 'Generated/Inc/project_algorithm_parameters.h'
            raw = archive.read('compiler_fixture/'+other+'/'+relative)
    target = root/relative
    assert raw != target.read_bytes()
    target.write_bytes(raw)
    assert stacks.BindingSourceHash_Get(target.read_text(encoding='utf8')) in stacks.BindingSourceVersions_Get(relative)
    with pytest.raises(ValueError, match='paired source/compiler input closure'):
        stacks.BindingSources_Verify(root, [SOURCE], build)


def test_stack_algorithm_and_all_nonbinding_policies_are_preserved():
    manifest = json.loads((EVIDENCE/'manifest.json').read_text(encoding='utf8'))
    assert manifest['all_nonbinding_policy_assignments_AST_equal']
    assert manifest['changed_registration_functions'] == ['BindingSourceVersions_Get', 'BindingSources_Verify']
    assert 'StackReport_Build' in manifest['unchanged_functions']
