"""Restore an explicitly staged Host-only variant to its recorded original snapshot."""
from hashlib import sha256
import json
from pathlib import Path

TASK=Path(__file__).resolve().parent
target=(TASK/'eskf15_1_default03/Tests/Host/test_logger.c').resolve()
original=TASK/'eskf15_0_default03/Tests/Host/test_logger.c'
revision=json.loads((TASK/'host_logger_harness_revision02.json').read_text())
assert target.is_relative_to(TASK)
assert sha256(target.read_bytes()).hexdigest()==revision['after_sha256']
assert sha256(original.read_bytes()).hexdigest()==revision['before_sha256']
full=json.loads((TASK/'eskf15_1_default03_host02_HOST_TESTS.json').read_text())
assert full['return_code']==0
retained=TASK/'host_logger_revised_fixture02.c'
assert not retained.exists()
retained.write_bytes(target.read_bytes())
target.write_bytes(original.read_bytes())
assert sha256(target.read_bytes()).hexdigest()==revision['before_sha256']
with (TASK/'host_logger_snapshot_restore02.json').open('x',encoding='utf8') as output:
    json.dump(dict(owner='/root',purpose='end staged Host variant; retain both versions; restore source-proof input',
        original_sha256=revision['before_sha256'],staged_sha256=revision['after_sha256'],
        staged_fixture_retained=str(retained),target=str(target),production_C_changed=False),output,indent=2)
print('restored exact original task snapshot; revised fixture retained and owning repository fix unchanged')
