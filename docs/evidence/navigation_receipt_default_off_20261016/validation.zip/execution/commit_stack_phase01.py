"""Scoped local stack review checkpoint; original inputs remain protected."""
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import subprocess

TASK=Path(__file__).resolve().parent;ROOT=TASK.parents[1]
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
assert git('rev-parse','HEAD')=='615d5052cd5fa9a4aa1cc31ad996187d2d160cb3'
assert git('branch','--show-current')=='feature/usb-transport-0.1.3-20261013'
assert not git('diff','--cached','--name-only')
protected=json.loads((ROOT/'.work/dev013_horizon01/local_commit_phase_c.json').read_text(encoding='utf8'))['protected_uncommitted_catalog_inputs_sha256']
protected.update(json.loads((ROOT/'docs/evidence/fusion_horizon_development_20261016/manifest.json').read_text(encoding='utf8'))['protected_inputs_sha256'])
assert all(sha256((ROOT/name).read_bytes()).hexdigest()==expected for name,expected in protected.items())
assert git('rev-parse','v0.1.2')=='942f20ef64df3cb1aa65be7349361c409418aa0f'
assert git('rev-parse','v0.1.2^{}')=='c31c13cc0686a56a3184d4f207fd3816c5d39696'
formal=ROOT/'docs/evidence/navigation_horizon_stack_binding_20261016'
validation=json.loads((formal/'validation.json').read_text(encoding='utf8'))
assert sha256((formal/'validation.zip').read_bytes()).hexdigest()==validation['archive_sha256']
paths=['apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tools/check_task_stacks.py',
 'apps/SCG/tests/test_horizon_stack_binding.py',
 'docs/public/SCG/NAVIGATION_HORIZON_STACK_INPUT_REVIEW_20261016.md']
paths += [path.relative_to(ROOT).as_posix() for path in formal.iterdir() if path.is_file()]
assert len(paths)==10
hashes={name:sha256((ROOT/name).read_bytes()).hexdigest() for name in paths}
subprocess.run(['git','add','--',*paths],cwd=ROOT,check=True)
assert set(git('diff','--cached','--name-only').splitlines())==set(paths)
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','Review exact horizon compilation inputs for the stack gate',
 '-m','Register closed v19 source/header tuples backed by ARM object review and negative/policy tests. Fresh normal mode2 ARM, architecture, artifact, Power10 and stack gates pass for both estimators. Preserve all stack/callback policies; main/MSP/ISR, hardware and critical-contract acceptance remain unproven.'],cwd=ROOT,check=True)
assert all(sha256((ROOT/name).read_bytes()).hexdigest()==expected for name,expected in protected.items())
receipt={'owner':'/root navigation closure02','utc':datetime.now(timezone.utc).isoformat(),
 'commit':git('rev-parse','HEAD'),'source_sha256':hashes,'protected_inputs_sha256':protected,
 'remaining_status':git('status','--short'),'scope':'stack-input blocker closed; ESKF integration and all-mode closure still pending'}
with (TASK/'stack_local_commit01.json').open('x',encoding='utf8') as output:json.dump(receipt,output,indent=2)
print(receipt['commit'],receipt['scope'])
