"""Register only audited exact tuples; stack policy/function logic is preserved."""
import ast
from hashlib import sha256
import json
from pathlib import Path
import pprint
import zipfile

TASK=Path(__file__).resolve().parent
ROOT=TASK.parents[1]
tool=ROOT/'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tools/check_task_stacks.py'
review=ROOT/'docs/public/SCG/NAVIGATION_HORIZON_STACK_INPUT_REVIEW_20261016.md'
data=json.loads((TASK/'stack_input_census01.json').read_text(encoding='utf8'))
objects=json.loads((TASK/'stack_review_candidates02.json').read_text(encoding='utf8'))
before=tool.read_bytes()
assert sha256(before).hexdigest()==data['checker_sha256']==objects['checker_sha256']
assert review.is_file()
source_versions={};graphs={};closures={}
for name,project in data['projects'].items():
    assert not any(item['indirect_sites'] for item in objects['projects'][name]['objects'].values())
    probe=json.loads((TASK/(name+'_candidate_stack02.json')).read_text(encoding='utf8'))
    assert probe['report']['passes'] and probe['scope'].startswith('CANDIDATE_')
    for path,digest in project['unknown_inputs'].items():source_versions.setdefault(path,set()).add(digest)
    for source,entry in project['closures'].items():
        closures.setdefault(source,set()).add(entry['closure'])
        if source in project['changed_graphs']:graphs.setdefault(source,set()).add(entry['dependency_sha256'])
values=lambda mapping:{key:sorted(value) for key,value in sorted(mapping.items())}
text=before.decode('utf8')
marker='def BindingSourceVersions_Get(path):'
assert 'BINDING_SOURCE_HORIZON_V19' not in text
block=('# Exact reviewed mode2 inputs; see NAVIGATION_HORIZON_STACK_INPUT_REVIEW_20261016.md.\n'
    '# No callback, library, source-coverage or stack-margin exception is added.\n'
    'BINDING_SOURCE_HORIZON_V19 = '+pprint.pformat(values(source_versions),width=105,sort_dicts=True)+'\n\n'
    'BINDING_DEPENDENCIES_HORIZON_V19 = '+pprint.pformat(values(graphs),width=105,sort_dicts=True)+'\n\n'
    'BINDING_COMPILED_INPUTS_HORIZON_V19 = '+pprint.pformat(values(closures),width=105,sort_dicts=True)+'\n\n\n')
replacements={
 'BINDING_REVIEW_REVISION = "algorithm_timing_memory_20261015_v18"':
 'BINDING_REVIEW_REVISION = "navigation_horizon_20261016_v19"',
 'BINDING_SOURCE_ALGORITHM_TIMING_V18.get(path, []))':
 'BINDING_SOURCE_ALGORITHM_TIMING_V18.get(path, []) +\n            BINDING_SOURCE_HORIZON_V19.get(path, []))',
 'BINDING_DEPENDENCIES_ALGORITHM_TIMING_V18.get(path, []))':
 'BINDING_DEPENDENCIES_ALGORITHM_TIMING_V18.get(path, []) +\n                          BINDING_DEPENDENCIES_HORIZON_V19.get(path, []))',
 'current_review = actual in BINDING_SOURCE_ALGORITHM_TIMING_V18.get(path, [])':
 'current_review = (actual in BINDING_SOURCE_ALGORITHM_TIMING_V18.get(path, []) or\n                          actual in BINDING_SOURCE_HORIZON_V19.get(path, []))',
 'current_review = current_review or digest in BINDING_SOURCE_ALGORITHM_TIMING_V18.get(dependency_input, [])':
 'current_review = (current_review or\n                digest in BINDING_SOURCE_ALGORITHM_TIMING_V18.get(dependency_input, []) or\n                digest in BINDING_SOURCE_HORIZON_V19.get(dependency_input, []))',
 'if current_review and closure not in BINDING_COMPILED_INPUTS_ALGORITHM_TIMING_V18.get(path, []):':
 'if current_review and closure not in (BINDING_COMPILED_INPUTS_ALGORITHM_TIMING_V18.get(path, []) +\n                                              BINDING_COMPILED_INPUTS_HORIZON_V19.get(path, [])):'}
for old,new in replacements.items():
    assert text.count(old)==1,old
    text=text.replace(old,new)
text=text.replace(marker,block+marker)
old_ast,new_ast=ast.parse(before),ast.parse(text)
functions=lambda tree:{node.name:ast.dump(node,include_attributes=False) for node in tree.body if isinstance(node,ast.FunctionDef)}
old_functions,new_functions=functions(old_ast),functions(new_ast)
assert old_functions.keys()==new_functions.keys()
changed=[name for name in old_functions if old_functions[name]!=new_functions[name]]
assert sorted(changed)==['BindingSourceVersions_Get','BindingSources_Verify']
for node in old_ast.body:
    if isinstance(node,ast.Assign) and all(isinstance(target,ast.Name) and not target.id.startswith('BINDING_') for target in node.targets):
        target=next(n for n in new_ast.body if isinstance(n,ast.Assign) and ast.dump(n.targets[0])==ast.dump(node.targets[0]))
        assert ast.dump(node)==ast.dump(target)
destination=ROOT/'docs/evidence/navigation_horizon_stack_binding_20261016'
destination.mkdir(exist_ok=False)
entries={}
with zipfile.ZipFile(destination/'inputs.zip','x',zipfile.ZIP_DEFLATED) as archive:
    with zipfile.ZipFile(TASK/'stack_review_candidate_inputs02.zip') as original:
        for name in original.namelist():
            raw=original.read(name);archive.writestr(name,raw);entries[name]=sha256(raw).hexdigest()
    archive.writestr('review/checker_before_v19.py',before)
    archive.write(TASK/'stack_review_candidate_changes02.patch','review/changes.patch')
    archive.write(TASK/'stack_input_census01.json','review/census.json')
    archive.write(TASK/'stack_review_candidates02.json','review/objects.json')
    for name,project in data['projects'].items():
        root=ROOT/'.work/dev013_horizon01'/name
        build=root/'build/FCCG/SilverStar_F407/Release'
        if project['layout']!='legacy':build=build/project['layout']
        source='APP/Src/estimator_bus.c'
        for path,digest in project['closures'][source]['inputs']:
            raw=(root/path).read_bytes()
            assert sha256(raw.decode('utf8').replace('\r\n','\n').encode()).hexdigest()==digest
            key='compiler_fixture/'+name+'/'+path
            archive.writestr(key,raw);entries[key]=sha256(raw).hexdigest()
        raw=(build/Path(source).with_suffix('.d')).read_bytes()
        key='compiler_fixture/'+name+'/estimator_bus.d';archive.writestr(key,raw);entries[key]=sha256(raw).hexdigest()
        archive.write(TASK/(name+'_candidate_stack02.json'),'review/'+name+'_candidate_stack.json')
    with zipfile.ZipFile(ROOT/'docs/evidence/algorithm_stack_binding_20261015/inputs_v2.zip') as baseline:
        path='compiler_fixture/Generated/Inc/project_flight_config.h'
        raw=baseline.read(path);key='legacy/'+path
        archive.writestr(key,raw);entries[key]=sha256(raw).hexdigest()
tool.write_text(text,encoding='utf8',newline='\n')
record={'owner':'/root','review':'navigation_horizon_20261016_v19','base':data['head'],
 'review_document_sha256':sha256(review.read_bytes()).hexdigest(),
 'checker_before_sha256':sha256(before).hexdigest(),'checker_after_sha256':sha256(tool.read_bytes()).hexdigest(),
 'unchanged_functions':sorted(set(old_functions)-set(changed)),
 'changed_registration_functions':changed,'all_nonbinding_policy_assignments_AST_equal':True,
 'entries':entries,'archive_sha256':sha256((destination/'inputs.zip').read_bytes()).hexdigest(),
 'status':'REGISTERED_REVIEWED_INPUTS_PENDING_FRESH_EMITTED_GATE_AND_NEGATIVE_TESTS',
 'main_MSP_ISR_critical_contracts':'NOT_PROVEN'}
(destination/'manifest.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
print('registered',len(source_versions),'exact input paths,',len(graphs),'graphs;',
      sum(map(len,closures.values())),'exact compiled tuples; other analyzer functions unchanged')
