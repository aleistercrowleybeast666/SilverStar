"""Exact emitted static-analysis target, with a NEW build root and unchanged source snapshot."""
from pathlib import Path
import hashlib
import json
import subprocess

TASK=Path(__file__).resolve().parent
project=TASK/'eskf15_1_default03'
build='build/FCCG/SilverStar_F407/StaticAnalysisFresh02/Release/auto'
assert not (project/build).exists()
command=['mingw32-make','-j2','TARGET_PROFILE=SilverStar_F407','CONFIG=Release',
         'MEMORY_LAYOUT=auto','BUILD_ROOT='+build,'static-analysis']
with (TASK/'mode1_fresh_static_analysis02.log').open('x',encoding='utf8') as output:
    run=subprocess.run(command,cwd=project,stdout=output,stderr=subprocess.STDOUT,text=True)
elf=project/build/'SilverStar_0_1_3.elf'
record=dict(scope=__doc__,command=command,cwd=str(project),exit_code=run.returncode,
    compiler=subprocess.check_output(['arm-none-eabi-gcc','--version'],text=True),
    target_elf_sha256=hashlib.sha256(elf.read_bytes()).hexdigest() if elf.is_file() else None)
with (TASK/'mode1_fresh_static_analysis02.json').open('x',encoding='utf8') as output:json.dump(record,output,indent=2)
print('fresh actual static-analysis target exit',run.returncode)
raise SystemExit(run.returncode)
