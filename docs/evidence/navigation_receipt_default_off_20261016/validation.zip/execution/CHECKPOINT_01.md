# Navigation closure batch02 checkpoint01

Root /root is the sole writer, model existing6.1sol per parent. No agents spawned.
Newest user/parent explicitly authorizes continuing all navigation: stack binding
review first (fresh auditable source evidence, not hash-only/relaxation), then
active ESKF GNSS recovery +1/5/30/120s matrix, then modes0/1/2. No wireless edits,
hardware, push/tag/release/cleanup. Do not stop at this checkpoint; work continues.
Branch feature/usb-transport-0.1.3-20261013; base/currentHEAD615d5052. Existing
untracked SX1278 work and rootCSV/TXT user inputs remain. AGENTS/report/checkpointC
read; no matching initial python/gcc/make processes. No new app AGENTS for SCG/FLP.

All new temporary/generated outputs are in .work/dev013_navclosure02, inventory
INVENTORY.md. Older horizon01/recovery drafts/formal evidence are retained inputs.

CURRENT ACTIVE COMMANDS (do not duplicate):

- unified exec session51725: run.py stack_kf_gates01 -> build.py kf6_2_stack01
  POWER10_CHECK BUILD ARCHITECTURE_CHECK ARTIFACT_CHECK STACK_REPORT.
- session49862: run.py stack_eskf_gates01 -> build.py eskf15_2_stack01 same actions.
- Both emitted P10 already returned0. Fresh full ARM builds currently progressing
  through HAL libraries, live *.log per action. They take minutes. Wrapper will
  continue remaining gates and produce final exit (stack failures must be kept).
- Session54306 is only an outstanding read command (headers/logs); retrieve if
  needed. Session94281 also only read output. Test/generation commands finished.

New run.py writes *_start.json BEFORE execution with exitUNKNOWN and source
hashes, captures invoked task runner bytes in *_runner_sources.zip, records final
result/log. TEMP/TMP and pytest cache are task-owned per label. build.py copied
small prior helper (no workspace copy), modified to write action-start receipts
and live BuildRunner callback logs rather than losing buffered output on outage.
Do not reuse labels or overwrite outputs.

COMPLETED STACK REVIEW WORK (still awaiting fresh emitted gates):

1. audit_stack_inputs.py -> stack_input_census01.json, read-only current actual
   source/headers/compiler.d/ELF census using old v18 checker. KF:157 C sources,
   14 unknown C,26 unknown input paths,2 dependency graphs; ESKF157/16/28/3.
   Union31 unknown paths,4 graph paths. Existing checker correctly rejects.
2. review_stack_candidates.py -> exact changed current/baseline bytes + full
   diffs + actual ARM objdump-dr for all14/16 changed C objects. Zero indirect
   functions in those actual selected objects. This is not a generic C proof.
   Files stack_review_candidate_inputs02.zip, changes02.patch, candidates02.json.
3. probe_candidate_stack.py registers only exact candidate tuples in isolated
   memory, then runs UNCHANGED stack analyzer. It is explicitly diagnostic-only,
   never an emitted gate. Existing ELF callback-table/register/slot checks and
   task budget analysis pass both. Actual candidate worst-known/margins:
   Device2144/416, Flight3648/448, Serial4944/1200, Logger1840/1232,
   Telemetry2152/1944, Idle256/256; Estimator KF2772/1324 ESKF2464/1632,
   INS KF2240/832 ESKF2264/808. Main/MSP/ISR/critical-contract/WCET remainNOTPROVEN.
4. Reviewed document docs/public/SCG/NAVIGATION_HORIZON_STACK_INPUT_REVIEW_20261016.md
   explains exact mode2/HMS300/JY901S no-baro changes, actual object review and
   limited proof. Configuration also changes validation landing mode from baro
   window to existing stillness (model-only no-baro reconcile), alignment mask
   drops baro and fusionmask0x1F->0x0F. Flight source/algorithm not edited.
5. register_stack_review_v19.py installs closed exact31-path/4-graph/314 paired
   compilation tuples in owning core payload Tools/check_task_stacks.py. All
   historical v18 maps remain. BINDING_REVIEW_REVISION navigation_horizon_20261016_v19.
   Only BindingSourceVersions_Get / BindingSources_Verify function AST changes;
   every other analyzer function and all nonbinding policy assignments AST-equal.
   Getters addV19; current_review includes19 source/header; complete closure must
   match old18 or new19 exact tuple. No callback/library/coverage/budget exception.
6. Formal docs/evidence/navigation_horizon_stack_binding_20261016:
   inputs.zip original attempt with TWO byte-identical duplicate compiler header
   entries; preserved. prepare_unique_review_fixtures.py proved equality and made
   inputs_unique.zip /inputs_unique.json (170 unique entries); tests use unique.
   manifest.json records review/checker before/after and AST invariants. No old
   evidence overwritten/deleted. Source/object diffs/census/baseline fixtures and
   full actual estimator_bus compiler closures for both algorithms are retained.
7. New apps/SCG/tests/test_horizon_stack_binding.py and existing test_stack_budget.py:
   stack_binding01.log:54pass2fail +pytest config warning from disabled cache.
   The two negatives swapped only the sole differing bus algorithm header,
   which legitimately recreated the OTHER COMPLETE APPROVED translation-unit
   tuple. This was an invalid negative premise, not a production bypass. Updated
   test uses other algorithm header PLUS independently approved legacy config,
   asserts all individual hashes known AND complete tuple NOT registered before
   expecting rejection. Existing old-header mix negative already passed. No gate
   predicate was loosened. before-test source retained task attempt01 file.
   stack_binding02.log:56pass/no warning. Tests also compare ACTUAL current
   analyzer AST vs archived old source, not just a manifest boolean. Then Ruff
   import-order+format changed test only. Run final bounded suite later with
   run.py (explicit task cache); don't attribute old source hash to formatted code.
8. generate_stack_projects.py normally generated two fresh models, preserving
   original model identity/config while using new directories kf6_2_stack01 and
   eskf15_2_stack01 (633/631 files). Original old project descriptors hash-checked
   unchanged. stack_generation01 exit0. Fresh owner v19 checker emitted.
   Do not assume gate passes until active sessions finish. If metadata/profile
   byte changes cause new tuple failure, review actual diffs; never add blindhash.

REPO CHANGES THIS BATCH SO FAR:
Only owner check_task_stacks.py, new stack-binding test, public review document,
formal review fixtures/manifest. NO firmware C/headers/algorithm/manifests/FLP
logic yet changed. Avoid changing owning firmware while first gate snapshots run.
Reference-overlays check_task_stacks.py appears empty; owner canonical payload is
what generator/tests use. Do not fill unrelated legacy placeholder blindly.

ESKF INTEGRATION READ-ONLY FINDINGS / NEXT DESIGN (not implemented):

- Frozen module .work/dev013_reacq_module01/HANDOFF.md +draft/Inc/Src read.250 old
  isolated tests and ARM/fanalyzer proof; no defaults/activation. API resets
  receive+replay states with explicit config; SourceSelect/Tick/Receive immutable
  28B per-group evidence; UpdateCandidate performs bounded full225P uniformScale
  then exactlyoneUpdate transaction. Failures preserve numerical+policy authority.
- Config160B: loss/stable/maxinterval/cooldownu64; identity;4 countu8; uniform
  scale15 (>1..2), variancecap15 (>0). Receive272, Policy112, Transaction1104.
  Must remain caller-owned static scratch, not estimator task stack.
- Need physical/coherent proof from actual native paired packet, never scale==1.
  GNSS interface SystemGnssSample has NO source id, includes receive/sample/trust,
  sequence, supported/valid bits and hAcc/vAcc/sAcc, valid/physical masks. Existing
  backend separately calls selector/sample/time; cannot assume coherent tuple.
  New narrowly scoped per-instance snapshot likely needed. Do not edit wireless.
- Actual M9N instance sample/time getters are in plugin Adapter/Src/
  neo_m9n_system_adapter.c around1660, declarations neo_m9n_instance.h. Generic
  SystemGnss_* routes appear generated project_capability_routes.c, not core
  System/Src/system_gnss.c. Inspect actual route renderer/driver cache critical
  sections before implementing. Bundle source+sample+native time identity;
  unsupported drivers keep ordinary fusion but recovery ineligible, no fallback
  native proof. Preserve old APIs/disabled behavior.
- Desired conservative product integration: recovery opt-in, no invented approved
  flight thresholds. Disabled retains old0/1/2 numerical behavior. Enabling must
  require explicit validated configuration/coherence/caps; synthetic validation
  configs labeled CPU-only. Default missing/zero remains unconfigured/disabled,
  never Recorded parameters manufactured. Need decide exact version/schema after
  reading actual authoritative contracts and plugin identities. Likely ESKF
  component bump + strict compatible old version identity, not reinterpretation.
- Proposed coherent screen to design/test: successive same-source known-native
  epochs within explicit maxinterval; supported/valid finite positive uncertainty;
  per-group bounded acceleration from native velocity differences; position-
  velocity closure vs propagated reported uncertainty plus explicit acceleration
  bound. All policy scalars explicit, no guessed default=good. Need examine existing
  GNSS quality/coherence facilities first; don't select unapproved flight settings.
- Receive FSM never replayed; process receipts before Tick(present). History
  events own immutable recovery certificates. Replay policy must roll back paired
  withP at base/checkpoints/prefix; never refill receive watermarks/budget on CPU
  re-execution. Mode2 candidate primary +Policy commits atomically only after full
  output propagation; output predict never changes policy or feeds back.
- Need separate versioned recovery config/receipt/action records (potential new
  types0x2F/0x30) instead of reinterpreting frozen148B horizonv1 KF certificate.
  Must log actual config/identity and all eligibility/action evidence; strict FLP
  reconstruction/What-if limits, immutable old logs, health only actual updates.
- Final integrated1/5/30/120s outages +bad packets/source/cal/time/cap/numeric
  faults, O0/O2 relevant subset, long logs bounded/needed only. New config only
  representative CPU model; no hardware/navigation accuracy/WCET claim.
- ESKF replay header actual capacities HISTORY192 /EVENT208 (do not assume64!
  horizon event64 only). Need inspect full header/current replay source before
  adding paired policy storage; legacy evidence208*28 ~5824B +checkpoints/state,
  placement/budget must be actual linked result, not arithmetic proof.

Pending outputs to read: session54306 has full replay/horizon headers and build
tails; no new source mutation. Latest56 tests done; active gates progressing.
Next: finish first emitted stack proof and bounded negative/Ruff tests, archive
phase1 commands/receipt/versions/hash/failed attempts, optionally scoped local
commit; then update plan and integrate recovery autonomously as authorized.
