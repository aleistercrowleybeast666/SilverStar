"""Preserve attempt1 and deduplicate identical compiler dependency entries."""
from hashlib import sha256
import json
from pathlib import Path
import zipfile

TASK=Path(__file__).resolve().parent
ROOT=TASK.parents[1]
evidence=ROOT/'docs/evidence/navigation_horizon_stack_binding_20261016'
test=ROOT/'apps/SCG/tests/test_horizon_stack_binding.py'
with (TASK/'test_horizon_stack_binding_attempt01.py').open('xb') as stream:stream.write(test.read_bytes())
entries={};duplicates=[]
with zipfile.ZipFile(evidence/'inputs.zip') as original:
    for item in original.infolist():
        raw=original.read(item)
        if item.filename in entries:
            assert entries[item.filename]==raw
            duplicates.append(item.filename)
        else:entries[item.filename]=raw
with zipfile.ZipFile(evidence/'inputs_unique.zip','x',zipfile.ZIP_DEFLATED) as archive:
    for name,raw in entries.items():archive.writestr(name,raw)
record={'owner':'/root','original_retained':'inputs.zip',
    'original_sha256':sha256((evidence/'inputs.zip').read_bytes()).hexdigest(),
    'identical_duplicate_entries':duplicates,'archive_sha256':sha256((evidence/'inputs_unique.zip').read_bytes()).hexdigest(),
    'entries':{name:sha256(raw).hexdigest() for name,raw in entries.items()}}
(evidence/'inputs_unique.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
print(len(entries),'unique entries;',len(duplicates),'identical duplicates retained in original archive')
