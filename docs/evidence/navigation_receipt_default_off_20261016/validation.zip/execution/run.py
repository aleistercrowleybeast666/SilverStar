"""Bounded receipts survive interrupted execution; no missing result is a pass."""
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile

TASK=Path(__file__).resolve().parent
ROOT=TASK.parents[1]
label,*command=sys.argv[1:]
assert label.replace('_','').isalnum() and command
temporary=TASK/(label+'_tmp');temporary.mkdir(exist_ok=False)
env={**os.environ,'PYTHONUTF8':'1','PYTHONDONTWRITEBYTECODE':'1','QT_QPA_PLATFORM':'offscreen',
 'PYTHONPATH':os.pathsep.join(str(ROOT/path) for path in ('apps/SCG/src','apps/FLP/src')),
 'TEMP':str(temporary),'TMP':str(temporary),
 'PYTEST_ADDOPTS':'-o cache_dir='+str(TASK/(label+'_cache')),
 'RUFF_CACHE_DIR':str(TASK/'ruff_cache')}
files=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z','--',
 'apps/SCG/src','apps/SCG/plugins/builtin','apps/SCG/tests','apps/FLP/src','apps/FLP/tests','contracts'],cwd=ROOT).decode('utf8').rstrip('\0').split('\0')
record={'owner':'/root navigation closure02','command':command,'cwd':str(ROOT),
 'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
 'started_utc':datetime.now(timezone.utc).isoformat(),'exit_code':None,'status':'STARTED_EXIT_UNKNOWN_UNTIL_FINAL_RECEIPT',
 'environment':{key:value for key,value in env.items() if key.startswith('SILVERSTAR_') or key in ('PYTHONPATH','PYTHONUTF8','PYTHONDONTWRITEBYTECODE','QT_QPA_PLATFORM','TEMP','TMP','PYTEST_ADDOPTS','RUFF_CACHE_DIR')},
 'source_sha256':{path:sha256((ROOT/path).read_bytes()).hexdigest() for path in files if path and (ROOT/path).is_file()}}
scripts=[TASK/'run.py']
for argument in command:
    path=Path(argument)
    if not path.is_absolute():path=ROOT/path
    if path.suffix=='.py' and path.is_file() and path.resolve().is_relative_to(TASK):scripts.append(path.resolve())
with zipfile.ZipFile(TASK/(label+'_runner_sources.zip'),'x',zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(set(scripts)):archive.write(path,path.relative_to(TASK).as_posix())
with (TASK/(label+'_start.json')).open('x',encoding='utf8') as output:json.dump(record,output,indent=2)
started=time.monotonic()
with (TASK/(label+'.log')).open('xb') as output:
    completed=subprocess.run(command,cwd=ROOT,env=env,stdout=output,stderr=subprocess.STDOUT)
record.update(exit_code=completed.returncode,status='COMPLETED',elapsed_seconds=time.monotonic()-started,
              finished_utc=datetime.now(timezone.utc).isoformat())
with (TASK/(label+'.json')).open('x',encoding='utf8') as output:json.dump(record,output,indent=2)
print(json.dumps({key:record[key] for key in ('exit_code','elapsed_seconds')}))
raise SystemExit(completed.returncode)
