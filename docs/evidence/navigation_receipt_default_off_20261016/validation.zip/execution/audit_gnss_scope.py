"""Compare all selector function bodies, preserving every non-GNSS function."""
from hashlib import sha256
import json
from pathlib import Path
import re
import sys

TASK = Path(__file__).resolve().parent
ROOT = TASK.parents[1]
before = TASK / 'gnss_receipt_before01/system_source_selector.c'
after = ROOT / 'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/System/Src/system_source_selector.c'

def functions(path):
    text = path.read_text(encoding='utf8')
    # Mask comments/strings without moving any offset before matching braces.
    masked = re.sub(r'/\*[\s\S]*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"',
                    lambda m: ''.join('\n' if c == '\n' else ' ' for c in m[0]), text)
    result = {}
    for match in re.finditer(r'(?m)^[A-Za-z_][\w \t*]*\b(System\w+)\s*\([^;{}]*\)\s*\{', masked):
        level = 1
        index = match.end()
        while level and index < len(masked):
            level += (masked[index] == '{') - (masked[index] == '}')
            index += 1
        assert level == 0
        name = match[1]
        assert name not in result
        result[name] = sha256(text[match.start():index].encode()).hexdigest()
    assert len(result) > 100
    return result

old, new = functions(before), functions(after)
changed = {name for name in old if old[name] != new.get(name)}
added = set(new) - set(old)
expected = {'SystemSourceSelector_GnssSwitchEvaluate', 'SystemSourceSelector_GnssRecoveryAttempt',
            'SystemSourceSelector_GnssRecoveryProcess', 'SystemGnss_Init', 'SystemGnss_Start',
            'SystemSourceSelector_GnssActiveInstanceGet', 'SystemGnss_LatestSampleGet'}
assert changed == expected
assert added == {'SystemSourceSelector_GnssSelectionPublish', 'SystemSourceSelector_GnssBarrierPublish'}
record = {'owner': '/root GNSS-only scope audit', 'before_sha256': sha256(before.read_bytes()).hexdigest(),
          'after_sha256': sha256(after.read_bytes()).hexdigest(), 'old_functions': old, 'new_functions': new,
          'changed': sorted(changed), 'added': sorted(added),
          'unchanged_functions': sorted(set(old) - changed),
          'claim': 'All other selector function definition bytes unchanged; no wireless body changes'}
label = sys.argv[1] if len(sys.argv) == 2 else '02'
assert label.isdigit()
with (TASK / ('gnss_receipt_scope' + label + '.json')).open('x', encoding='utf8') as output:
    json.dump(record, output, indent=2)
print(len(old), 'old functions;', len(old)-len(changed), 'unchanged;', len(changed), 'GNSS functions changed')
