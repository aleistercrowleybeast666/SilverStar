"""Register reviewed final default-off tuples; preserve every other checker policy."""
import ast
from hashlib import sha256
import json
from pathlib import Path
import pprint
import zipfile

TASK=Path(__file__).resolve().parent
ROOT=TASK.parents[1]
tool=ROOT/'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tools/check_task_stacks.py'
review=ROOT/'docs/public/SCG/NAVIGATION_RECEIPT_DEFAULT_OFF_STACK_REVIEW_20261016.md'
census=json.loads((TASK/'default_stack_census02.json').read_text(encoding='utf8'))
before=tool.read_bytes()
assert sha256(before).hexdigest()==census['checker_sha256']
assert review.is_file()
source_versions={};graphs={};closures={}
for name,data in census['projects'].items():
    assert ('_default03' in name) if name.startswith('eskf15') else ('_default01' in name)
    assert all(not obj['indirect_sites'] for obj in data['objects'].values())
    diagnostic=json.loads((TASK/(name+'_candidate_stack02.json')).read_text(encoding='utf8'))
    assert diagnostic['scope'].startswith('CANDIDATE_') and diagnostic['report']['passes']
    for path,digest in data['unknown_inputs'].items():source_versions.setdefault(path,set()).add(digest)
    for source,item in data['closures'].items():
        closures.setdefault(source,set()).add(item['closure'])
        if source in data['changed_graphs']:graphs.setdefault(source,set()).add(item['dependency_sha256'])
values=lambda mapping:{key:sorted(value) for key,value in sorted(mapping.items())}
text=before.decode('utf8')
assert 'BINDING_SOURCE_RECEIPT_V20' not in text
marker='def BindingSourceVersions_Get(path):'
block=('# Exact reviewed default-off receipt inputs; see NAVIGATION_RECEIPT_DEFAULT_OFF_STACK_REVIEW_20261016.md.\n'
    '# No callback, library, source-coverage, capacity or margin exception is added.\n'
    'BINDING_SOURCE_RECEIPT_V20 = '+pprint.pformat(values(source_versions),width=105,sort_dicts=True)+'\n\n'
    'BINDING_DEPENDENCIES_RECEIPT_V20 = '+pprint.pformat(values(graphs),width=105,sort_dicts=True)+'\n\n'
    'BINDING_COMPILED_INPUTS_RECEIPT_V20 = '+pprint.pformat(values(closures),width=105,sort_dicts=True)+'\n\n\n')
replacements={
 'BINDING_REVIEW_REVISION = "navigation_horizon_20261016_v19"':
 'BINDING_REVIEW_REVISION = "navigation_receipt_default_off_20261016_v20"',
 'BINDING_SOURCE_HORIZON_V19.get(path, []))':
 'BINDING_SOURCE_HORIZON_V19.get(path, []) +\n            BINDING_SOURCE_RECEIPT_V20.get(path, []))',
 'BINDING_DEPENDENCIES_HORIZON_V19.get(path, []))':
 'BINDING_DEPENDENCIES_HORIZON_V19.get(path, []) +\n                          BINDING_DEPENDENCIES_RECEIPT_V20.get(path, []))',
 'actual in BINDING_SOURCE_HORIZON_V19.get(path, []))':
 'actual in BINDING_SOURCE_HORIZON_V19.get(path, []) or\n                          actual in BINDING_SOURCE_RECEIPT_V20.get(path, []))',
 'digest in BINDING_SOURCE_HORIZON_V19.get(dependency_input, []))':
 'digest in BINDING_SOURCE_HORIZON_V19.get(dependency_input, []) or\n                digest in BINDING_SOURCE_RECEIPT_V20.get(dependency_input, []))',
 'BINDING_COMPILED_INPUTS_HORIZON_V19.get(path, [])):':
 'BINDING_COMPILED_INPUTS_HORIZON_V19.get(path, []) +\n                                              BINDING_COMPILED_INPUTS_RECEIPT_V20.get(path, [])):'}
# Replace longest snippets first: the actual-in expression contains a shorter suffix.
for old,new in sorted(replacements.items(),key=lambda item:-len(item[0])):
    assert text.count(old)==1,(old,text.count(old))
    text=text.replace(old,new)
text=text.replace(marker,block+marker)
old_ast,new_ast=ast.parse(before),ast.parse(text)
functions=lambda tree:{node.name:ast.dump(node,include_attributes=False) for node in tree.body if isinstance(node,ast.FunctionDef)}
old_functions,new_functions=functions(old_ast),functions(new_ast)
assert old_functions.keys()==new_functions.keys()
changed=[name for name in old_functions if old_functions[name]!=new_functions[name]]
assert sorted(changed)==['BindingSourceVersions_Get','BindingSources_Verify']
new_names={'BINDING_SOURCE_RECEIPT_V20','BINDING_DEPENDENCIES_RECEIPT_V20',
           'BINDING_COMPILED_INPUTS_RECEIPT_V20','BINDING_REVIEW_REVISION'}
def policy(tree):
    return [ast.dump(node,include_attributes=False) for node in tree.body
        if not (isinstance(node,ast.FunctionDef) and node.name in changed)
        and not (isinstance(node,ast.Assign) and any(isinstance(target,ast.Name)
            and target.id in new_names for target in node.targets))]
assert policy(old_ast)==policy(new_ast)
destination=ROOT/'docs/evidence/navigation_receipt_default_off_20261016'
destination.mkdir(exist_ok=False)
with zipfile.ZipFile(destination/'inputs.zip','x',zipfile.ZIP_DEFLATED) as archive:
    with zipfile.ZipFile(TASK/'default_stack_inputs02.zip') as original:
        for entry in original.infolist():archive.writestr(entry.filename,original.read(entry))
    archive.write(TASK/'default_stack_census02.json','review/census.json')
    archive.write(TASK/'default_stack_changes02.patch','review/changes.patch')
    for name,data in census['projects'].items():
        project=TASK/name
        dependency=project/'build/FCCG/SilverStar_F407/Release'
        if data['layout']!='legacy':dependency=dependency/data['layout']
        for prefix,fixture_source in (('fixture','System/Src/system_gnss_receipt.c'),
                                      ('fixture_meta','Generated/Src/project_metadata.c')):
            fixture=data['closures'][fixture_source]
            written=set()
            for path,digest in fixture['inputs']:
                raw=(project/path).read_bytes()
                assert sha256(raw.decode('utf8').replace('\r\n','\n').encode()).hexdigest()==digest
                if path not in written:archive.writestr(prefix+'/'+name+'/'+path,raw)
                written.add(path)
            archive.write(dependency/Path(fixture_source).with_suffix('.d'),
                prefix+'/'+name+'/receipt.d')
        archive.write(TASK/(name+'_candidate_stack02.json'),'review/'+name+'_diagnostic.json')
tool.write_text(text,encoding='utf8',newline='\n')
manifest=dict(owner='/root',review='navigation_receipt_default_off_20261016_v20',
    base=census['head'],status='REGISTERED_PENDING_EMITTED_GATE_AND_NEGATIVE_TESTS',
    checker_before_sha256=sha256(before).hexdigest(),checker_after_sha256=sha256(tool.read_bytes()).hexdigest(),
    archive_sha256=sha256((destination/'inputs.zip').read_bytes()).hexdigest(),
    source_paths=len(source_versions),changed_dependency_graphs=len(graphs),
    complete_compiled_tuples=sum(map(len,closures.values())),changed_registration_functions=changed,
    every_other_AST_node_equal=True,critical_contract_main_MSP_ISR_WCET_hardware='NOT_PROVEN')
(destination/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
print(manifest)
