# Navigation closure 0.1.3 / batch02

Owner: /root. Base615d5052cd5fa9a4aa1cc31ad996187d2d160cb3.
Task: rebuild traceable stack binding review from current sources, then integrate
ESKF15 active GNSS reacquisition, outage/fault matrix1/5/30/120s and mode0/1/2
closure. No wireless edits, hardware, publishing, push, tags or cleanup.

This directory is the only new temporary/generated output root for this batch.
Scripts are bounded audit/test/build orchestrators; *_start.json records launches,
*.json/log record completion/evidence. Original horizon01 projects/evidence and
recovery draft are read-only inputs. Any new validation project must be versioned
here and must not overwrite an existing candidate or user project. No SDK copies.

Source fixtures, logs, packages, archives, formal evidence and protected user
inputs are retained, never temporary-cleanup targets. No cleanup is authorized.
Subsequent per-action receipts provide exact configuration, commands, source and
artifact hashes. Unknown exit or proof states must remain explicit.

One preliminary direct pytest command used the repository-configured cache_dir
instead of a task override. Its cache is retained; no cleanup was attempted.
All subsequent run.py calls pin cache/TEMP/TMP within this task directory.

GNSS receipt safety: gnss_receipt_before01 contains immutable pre-fix selector
and race fixture source. gnss_receipt_* receipts/logs/pytest directories retain
all compile-plumbing failures, genuine race failures and post-fix cases.
*_2_receipt01 projects are fresh normal generator outputs, owned by /root for
this safety batch only; *_generation.json inventories their original bytes.
Their emitted BUILD/POWER10/ARCHITECTURE/ARTIFACT/STATIC_ANALYSIS actions completed
with0. This snapshot predates the recovery companion edits and is not evidence
for those later edits. Stack input review for later C edits remains pending.

recovery_* run receipts/logs/pytest roots retain current recovery module and
optional replay/horizon companion CPU proofs, all failed fixture attempts,
canonical reorder/rollback, Revision2 equivalence and exact explicit-source FLP
comparison. These are synthetic CPU-only parameters and no active backend or
approved flight configuration. Original recovery draft and evidence are read-only.
All source fixtures, raw traces, logs and archives remain retained evidence;
none is a cleanup target. No cleanup performed or authorized.

## Default-off closure /2026-10-16
Owner /root. Six *_default01 fresh generated projects (configuration-only derivation; original models untouched); actual emitted gate logs/receipts, backend pre/post owned-state counterexample, strict FLP disabled identity tests and HEAD export-failure overlay, fresh CPU mode0 exports. Purpose: reviewable default-off acceptance by12:00UTC. See CHECKPOINT_06.md for scopes and active incomplete work. Retain all failures, source snapshots and generated validation evidence; no cleanup authorized.

## Origin-boundary correction /2026-10-16
Owner /root. Retain default01 six-project snapshots, default02 superseded/partial outputs (ES2partial NOTVALID) and failed generation receipts. FINAL ESKF source validation is default03; KF remains default01 unchanged target sources. New origin pre/post CPU fixtures and audits02, fresh exporter03/native02 will support exact revision. Keep all failures and diagnostic-only stack probes explicitly separate from emitted gate evidence. No cleanup authorization. See CHECKPOINT_07.md.
