"""NEW current-source instances; derive configuration only, preserve old inputs."""
from copy import deepcopy
from dataclasses import replace
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import sys

TASK = Path(__file__).resolve().parent
ROOT = TASK.parents[1]
sys.path.insert(0, str(ROOT / 'apps/SCG/src'))
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.project.configuration import ProjectConfiguration_Reconcile

service = FccgService(ROOT / 'apps/SCG')
for family in ('eskf15', 'kf6'):
    source = TASK / (family + '_2_stack01/SilverStar.ssproject')
    before = sha256(source.read_bytes()).hexdigest()
    original = service.Project_Open(source)
    for mode in (0, 1, 2):
        target = TASK / (family + '_' + str(mode) + '_default01')
        assert not target.exists() and target.parent == TASK
        model = deepcopy(original)
        model.identity = replace(model.identity, name='NavClosure02_' + family + '_' + str(mode))
        # This is explicitly a new instance of CURRENT catalog sources, not
        # regeneration of a preserved original or import of its user payloads.
        model.component_provenance = {}
        model = ProjectConfiguration_Reconcile(model, service.catalog).model
        owner = 'silverstar.algorithm.estimator.' + family
        model.algorithm_parameters[owner]['fusion_timing_mode'] = mode
        if family == 'eskf15':
            assert model.algorithm_parameters[owner]['gnss_recovery_enabled'] == 0
        service.Project_Save(model, target, confirm_dangerous=True)
        assert sha256(source.read_bytes()).hexdigest() == before
        record = dict(owner='/root navigation closure02', utc=datetime.now(timezone.utc).isoformat(),
            purpose='new disabled-recovery current-source validation instance; no hardware',
            source_choice='current catalog owner payloads; old configuration only; no old user payload import',
            original_model=str(source), original_sha256=before, mode=mode,
            files={p.relative_to(target).as_posix(): sha256(p.read_bytes()).hexdigest()
                   for p in target.rglob('*') if p.is_file()})
        with (TASK / (target.name + '_generation.json')).open('x', encoding='utf8') as output:
            json.dump(record, output, indent=2)
        print('generated', target.name, len(record['files']), flush=True)
