# Navigation closure02 checkpoint04 /2026-10-16

Continues checkpoint03. HEAD remains21562359, branch unchanged. New user steering
asked only brief disconnect status; we answered and CONTINUE original active
recovery/allmode closure task. Latest explicit verification: every *_start.json
in this batch has a final receipt, no compiler/test process left, no unknown exit.
No repeated test launches after disconnect. No hardware/push/tag/release/cleanup.

New qualifier owning files:
- ESKF Inc/navigation_eskf_recovery_qualifier.h and Src/...c, registered plugin
  build source. Explicit config maximum_interval_us (<=existing500ms admission),
  clock_jitter_us, horizontal/vertical accel limits, closure_sigma. No defaults.
- Takes actual atomic receipt plus ENU position. Requires supported/valid native
  hAcc/vAcc/sAcc, masks/online/fix/axis validity; quality valid bits restrict
  coherent mask while physical mask remains independent of NIS/quality outcome.
- Known MCU sample or paired native iTOW proof; native epoch independent of MCU.
  Per-source week unwrap, backwards/native duplicates/gaps/jitter/source/basis
  changes break coherence. Finite bounded acceleration and position/velocity
  closure screens use native reported uncertainty, never estimator model floors.
- Original previous receipt/position owned value-copy, never replayed. Duplicate/
  discontinuous identity does not mutate state/output. External bad data normal
  ineligible; corrupt owned metadata or arithmetic exhaustion BAD_STATE no writes;
  overlaps rejected before writes. No source/control IO or callbacks.
- Qualifier source still needs fresh generated Power10/static/ARM/stack review;
  function size/control/semantic manual acceptance not established by unit tests.

Tests/fixtures test_eskf15_recovery_qualifier.py +fixture C:
39scenarios eachO0/O2, strict actual GCC warnings. Clock-independent origin,
supported/unknown MCU/native, matching identities, week rollover/backwards time,
gaps/jitter/reacquisition baseline, monotonic/duplicate/sequence wrap, per-group
position/velocity jumps, missing/zero/NaN uncertainty, finite numeric overflow,
stale/future packets, corrupt metadata, alias/no-write, unsupported fields.
qualifier01:78compileerrors missing Common/Inc include only fixture plumbing.
qualifier02:66passed12failed: unknown native clock was mislabeled BASELINE.
Fixed owning source return priority to INELIGIBLE for unproven time; masks remain
zero and physical/error paths preserved. qualifier03:78passed, exit0 (session85244
closed). No active command. New Python fixture not Ruff-formatted yet.

Verified fresh receipt projects actual three owner files (selector C, receipt C/H)
are byte-identical to owning changed files; earlier emitted ARM/analyzer scope
valid. Total task directory208MiB (not whole workspace/SDK copy).

Created shared authoritative design contract contracts/
navigation_gnss_reacquisition_v1.json; experimentaloptin v1, prospective ESKF0.4.0,
mode0/1 kernelrevision1, mode2 revision2. Does not activate feature. Declares raw
configuration wire '<I4I4B16FI3F' =104B: enabled,4durations(ms),4counts,uniformscale,
15variancecaps,clockjitter(ms),accelH/V,closureSigma. Configid CRC32(actual104bytes)
or0xFFFFFFFF if0; identity is not security proof/exact-config substitute. New
record IDs47/48 (0x2F/0x30) are RECORD namespace free; EVENT0x2F already used and
must stay unchanged. Tentative config record120B and combined receipt/action kind
record<=148B needed to preserve existing estimator slot capacity; not implemented.

Configuration planning not yet implemented:
- Add29 algorithm params gnss_recovery_* to ESKF metadata, defaults/legacy0 as
  disabled/unconfigured placeholders, never approved flight values. Existing
  metadata supports integer/float only, min/max required, groups basic/advanced/
  gnss_integrity. Max numeric bound3.402823466e38. Existing mission snapshot is
  41entries in no-baro ESKF project; adding29=>70 remains unchanged96-entry bound.
- Enable0/1. Active requires loss_gap>max_interval>0<=500ms, stable_span/cooldown>0,
  counts>=2/1/1/1<=255, uniformscale>1<=2, all15caps>0, positive finite accelH/V/
  sigma,0<=jitter<=interval. Explicit CPU config only. Other missing values remain
  zero/disabled and cannot silently activate.
- Add project validator called from AlgorithmParameters_Resolve; derived actual
  config id emitted via AlgorithmParametersHeader_Render (not a user tuning knob).
  Generation declaration includes actual enabled/config bytes and exact owner
  identity. Need ESKF pluginversion0.3->0.4 plus FLP strict explicit compatibility
  for old0.3/no-recovery; do NOT alter frozen horizonv1 or historical logs.
- _LogMetadataDeclarations_Get in generator/render.py around1787 currently injects
  FusionTimingDeclaration_Get into project_semantics. Add distinct reacquisition
  declaration from actual validated parameters, not arbitrary manifest metadata.
- FLP decoder_profiles/fusion_horizon_identity.py has VERSIONS single old0.3 map;
  fusion_timing.py imports it and supports strict tuple versions. Need preserve
  exact old identities and explicitly add known0.4 +newdeclaration/actual validation.
- Add separate versioned config and receipt/action wire records, contract byte-
  identical packaged FLP data, exact decoding/Recorded reconstruction; no fallback.

Memory warning to VERIFY with actual links, no threshold changes:
SSLOG_RECORD_COUNT currently42. New2 records grow SystemLogStreamRuntime array
(config16+count4+pad+timestamp8+valid=40B) by80B and LoggerSnapshotRequest streams
by32B. KF no-baro prior main102252/102400 leaves148B, so expected112B growth leaves
36B only IF all assumptions hold. Request is PLATFORM_CPU_FAST_BSS, actual placement
depends target/layout. Do not add third stream, enlarge queue/slot/budget or shrink
coverage/capacities to fit. Actual generated linker/stack proof required. Record
payloads must fit existing queue slots. Full feature memory can block acceptance.

Remaining: real backend config/qualifier/Receive FSM integration allmodes,
SourceUnavailable receive chain handling, fault/READY/lifecycle ownership, logging/
FLP,1/5/30/120s matrix, exact current-source generated gates+stack review/formal
archives/scoped commit. Potential legacy currentP corruption before rewind still
needs review (existing rebuild can overwrite from anchor); no full critical claim.
Protected16inputs and v0.1.2 hashes last verified unchanged in checkpoint03 work.
