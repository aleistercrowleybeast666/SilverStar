"""Supply mandatory bilingual labels; preserve all actual defaults and bounds."""
import json
from pathlib import Path

TASK = Path(__file__).resolve().parent
ROOT = TASK.parents[1]
path = ROOT / 'apps/SCG/plugins/builtin/silverstar_algorithm_estimator_eskf15/plugin.json'
manifest = json.loads(path.read_text(encoding='utf8'))
labels = {'enabled': '启用实验性 GNSS 重捕获（0/1）', 'loss_gap_ms': '物理观测中断判定时间',
    'stable_span_ms': '重捕获稳定持续时间', 'maximum_interval_ms': '连续观测最大间隔',
    'cooldown_ms': '协方差恢复冷却时间', 'stable_count': '稳定观测最小数量',
    'reject_count': '恢复前连续拒绝数量', 'confirmation_count': '恢复后确认数量',
    'maximum_attempts': '每次中断最大恢复尝试数量', 'uniform_scale': '全协方差统一缩放因子 D',
    'clock_jitter_ms': '原生与 MCU 时间增量最大偏差',
    'horizontal_acceleration_limit_mps2': '水平加速度一致性界限',
    'vertical_acceleration_limit_mps2': '垂直加速度一致性界限', 'closure_sigma': '位置速度闭合不确定度倍数'}
for group, text, axes in (('position', '位置', ('e', 'n', 'u')), ('velocity', '速度', ('e', 'n', 'u')),
                          ('theta', '姿态误差', ('x', 'y', 'z')), ('gyro_bias', '陀螺零偏', ('x', 'y', 'z')),
                          ('accel_bias', '加计零偏', ('x', 'y', 'z'))):
    for axis in axes:
        labels['cap_' + group + '_' + axis] = text + ' ' + axis.upper() + ' 方差上限'
count = 0
for parameter in manifest['algorithm_parameters']['parameters']:
    if not parameter['id'].startswith('gnss_recovery_'):
        continue
    suffix = parameter['id'][len('gnss_recovery_'):]
    assert set(parameter['display_names']) == {'en_US'}
    parameter['display_names']['zh_CN'] = labels[suffix]
    parameter['description']['zh_CN'] = '默认关闭；零值为未配置占位，不是已批准的飞行参数。启用前必须填写完整、经过审查的实验配置；硬件与飞行验证未完成。'
    count += 1
assert count == 29
path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
print('Added mandatory Chinese labels for', count, 'experimental parameters')
