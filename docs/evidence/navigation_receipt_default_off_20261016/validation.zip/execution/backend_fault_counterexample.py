"""Identical owned-source fault expectations against HEAD and the current owner."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

TASK=Path(__file__).resolve().parent
ROOT=TASK.parents[1]
relative='apps/SCG/plugins/builtin/silverstar_algorithm_estimator_eskf15/payload/Algorithm/Estimator/ESKF15/Src/navigation_eskf_backend.c'
baseline=TASK/'backend_before_receipt.c'
baseline.write_bytes(subprocess.check_output(['git','show','HEAD:'+relative],cwd=ROOT))
results={}
for name,source in (('prefault',baseline),('postfix',ROOT/relative)):
    env={**os.environ,'SILVERSTAR_HORIZON_STAGE_PROJECT':str(TASK/'eskf15_2_default01'),
        'SILVERSTAR_HORIZON_NATIVE_CONFIGURATION':'1','SILVERSTAR_HORIZON_BACKEND_SOURCE':str(source)}
    command=[sys.executable,'-m','pytest','-q','apps/SCG/tests/test_eskf15_horizon_backend.py',
             '-k','owned_source_corruption','--basetemp='+str(TASK/('backend_'+name+'_tmp'))]
    run=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,text=True)
    (TASK/('backend_'+name+'.log')).write_text(run.stdout+run.stderr,encoding='utf8')
    results[name]=dict(command=command,exit_code=run.returncode,source=str(source),
        sha256=hashlib.sha256(source.read_bytes()).hexdigest())
with (TASK/'backend_fault_counterexample.json').open('x',encoding='utf8') as output:
    json.dump(results,output,indent=2)
print({name:row['exit_code'] for name,row in results.items()})
assert results['prefault']['exit_code']==1 and results['postfix']['exit_code']==0
