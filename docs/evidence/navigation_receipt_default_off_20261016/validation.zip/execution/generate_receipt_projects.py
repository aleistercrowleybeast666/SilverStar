"""Fresh normal outputs for GNSS receipt safety batch, no user project writes."""
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import sys

TASK = Path(__file__).resolve().parent
ROOT = TASK.parents[1]
sys.path.insert(0, str(ROOT / 'apps/SCG/src'))
from silverstar_fccg.app.service import FccgService

service = FccgService(ROOT / 'apps/SCG')
for name in ('kf6', 'eskf15'):
    source = TASK / (name + '_2_stack01/SilverStar.ssproject')
    before = sha256(source.read_bytes()).hexdigest()
    model = service.Project_Open(source)
    target = TASK / (name + '_2_receipt01')
    assert not target.exists() and target.parent == TASK
    service.Project_Save(model, target, confirm_dangerous=True)
    assert sha256(source.read_bytes()).hexdigest() == before
    record = {'owner': '/root GNSS receipt safety batch',
              'purpose': 'fresh emitted safety gates; snapshot API not active recovery',
              'utc': datetime.now(timezone.utc).isoformat(),
              'input_model': str(source), 'input_sha256': before,
              'files': {p.relative_to(target).as_posix(): sha256(p.read_bytes()).hexdigest()
                        for p in target.rglob('*') if p.is_file()}}
    with (TASK / (target.name + '_generation.json')).open('x', encoding='utf8') as output:
        json.dump(record, output, indent=2)
    print('generated', target.name, len(record['files']), flush=True)
