"""DIAGNOSTIC only: actual ELF/.su with candidate tuples; never the emitted gate."""
import importlib.util
import json
from pathlib import Path
import sys
import traceback

TASK=Path(__file__).resolve().parent
ROOT=TASK.parents[1]
label=sys.argv[1] if len(sys.argv)>1 else '01'
census=json.loads((TASK/('default_stack_census'+label+'.json')).read_text(encoding='utf8'))
tool=ROOT/'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tools/check_task_stacks.py'
for name,data in census['projects'].items():
    spec=importlib.util.spec_from_file_location('candidate_'+name,tool)
    stacks=importlib.util.module_from_spec(spec);spec.loader.exec_module(stacks)
    for source,closure in data['closures'].items():
        stacks.BINDING_SOURCE_HORIZON_V19.setdefault(source,[]).append(closure['source_sha256'])
        stacks.BINDING_DEPENDENCIES_HORIZON_V19.setdefault(source,[]).append(closure['dependency_sha256'])
        stacks.BINDING_COMPILED_INPUTS_HORIZON_V19.setdefault(source,[]).append(closure['closure'])
        for path,digest in closure['inputs']:
            stacks.BINDING_SOURCE_HORIZON_V19.setdefault(path,[]).append(digest)
    result=dict(scope='CANDIDATE_DIAGNOSTIC_ONLY_NOT_EMITTED_GATE_NOT_ACCEPTANCE',project=name)
    try:
        result['report']=stacks.StackReport_Build(TASK/name,'Release','arm-none-eabi-',data['layout'])
        print(name,'diagnostic',result['report']['passes'],flush=True)
    except Exception:
        result['error']=traceback.format_exc(); print(name,result['error'],flush=True)
    with (TASK/(name+'_candidate_stack'+label+'.json')).open('x',encoding='utf8') as output:
        json.dump(result,output,indent=2)
