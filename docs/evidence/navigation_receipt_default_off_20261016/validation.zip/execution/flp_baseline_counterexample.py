"""Read-only HEAD module overlay proves whether the unrelated export failure predates this batch."""
import hashlib
import importlib.abc
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

TASK=Path(__file__).resolve().parent
ROOT=TASK.parents[1]
relative='apps/FLP/src/'
names=('decoder_profiles.contract_data','decoder_profiles.fusion_horizon_identity',
       'decoder_profiles.fusion_timing','plugins.algorithms.eskf15.plugin')
overlay=TASK/'flp_head_overlay01'
overlay.mkdir(exist_ok=False)
mapping={}
for name in names:
    source=relative+'silverstar_flp/'+name.replace('.','/')+'.py'
    target=overlay/(name+'.py')
    target.write_bytes(subprocess.check_output(['git','show','HEAD:'+source],cwd=ROOT))
    mapping['silverstar_flp.'+name]=target
class Finder(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname in mapping:
            return importlib.util.spec_from_file_location(fullname,mapping[fullname])
sys.meta_path.insert(0,Finder())
import pytest
arguments=['-q','apps/FLP/tests/test_decoder_profiles.py::test_log_open_coordinator_builds_immutable_semantics_and_none_calibration',
           '--basetemp='+str(TASK/'fb01')]
result=pytest.main(arguments)
with (TASK/'flp_head_overlay01.json').open('x',encoding='utf8') as output:
    json.dump(dict(scope='HEAD production module overlay, unchanged current test',arguments=arguments,
        exit_code=int(result),modules={name:hashlib.sha256(path.read_bytes()).hexdigest()
        for name,path in mapping.items()}),output,indent=2)
raise SystemExit(result)
