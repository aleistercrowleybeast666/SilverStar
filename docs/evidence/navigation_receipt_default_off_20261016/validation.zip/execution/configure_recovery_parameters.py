"""Add only explicit disabled/unconfigured experimental ESKF policy parameters."""
from hashlib import sha256
import json
from pathlib import Path

TASK = Path(__file__).resolve().parent
ROOT = TASK.parents[1]
path = ROOT / 'apps/SCG/plugins/builtin/silverstar_algorithm_estimator_eskf15/plugin.json'
contract = json.loads((ROOT / 'contracts/navigation_gnss_reacquisition_v1.json').read_text(encoding='utf8'))
old = path.read_bytes()
manifest = json.loads(old)
assert manifest['version'] == '0.3.0'
params = manifest['algorithm_parameters']['parameters']
assert not any(p['id'].startswith('gnss_recovery_') for p in params)
with (TASK / 'eskf_manifest_before_parameters01.json').open('xb') as output:
    output.write(old)
counts = {'stable_count', 'reject_count', 'confirmation_count', 'maximum_attempts'}
for index, name in enumerate(contract['configuration_wire']['order']):
    integral = name == 'enabled' or name.endswith('_ms') or name in counts
    maximum = (1 if name == 'enabled' else (255 if name in counts else
        (500 if name in ('maximum_interval_ms', 'clock_jitter_ms') else 2147483647))) if integral else (
        2 if name == 'uniform_scale' else 3.402823466e38)
    unit = 'ms' if name.endswith('_ms') else 'count' if name in counts else '1'
    if name.startswith('cap_'):
        unit = ('(m/s^2)^2' if name.startswith('cap_accel_bias') else
            '(rad/s)^2' if name.startswith('cap_gyro_bias') else
            'rad^2' if name.startswith('cap_theta') else '(m/s)^2' if name.startswith('cap_velocity') else 'm^2')
    if name.endswith('_mps2'):
        unit = 'm/s^2'
    label = 'Experimental GNSS recovery: ' + name.replace('_', ' ')
    description = ('Disabled by default. Enabling requires an explicit complete experimental policy; no hardware or flight qualification.'
        if name == 'enabled' else 'Zero is an unconfigured placeholder while recovery is disabled. Actual values must be explicitly reviewed before enabling. No approved flight default.')
    params.append({'id': 'gnss_recovery_' + name, 'type': 'integer' if integral else 'float',
        'default': 0 if integral else 0.0, 'legacy_default': 0 if integral else 0.0,
        'unit': unit, 'representation': 'variance' if name.startswith('cap_') else 'value',
        'min': 0, 'max': maximum, 'precision': 0 if integral else 9,
        'step': 1 if integral else 0.001, 'group': 'gnss_integrity', 'order': 300 + index,
        'generated_symbol': 'SYSTEM_ESKF_GNSS_RECOVERY_' + name.upper(),
        'display_names': {'en_US': label}, 'description': {'en_US': description}})
manifest['version'] = '0.4.0'
manifest['metadata']['gnss_reacquisition_contract'] = {'schema_id': contract['schema_id'],
    'revision': 1, 'enabled_parameter': 'gnss_recovery_enabled'}
path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
with (TASK / 'recovery_parameter_edit01.json').open('x', encoding='utf8') as output:
    json.dump({'owner': '/root explicit recovery configuration', 'before_sha256': sha256(old).hexdigest(),
        'after_sha256': sha256(path.read_bytes()).hexdigest(), 'new_parameters': len(contract['configuration_wire']['order']),
        'purpose': 'disabled placeholders only; complete active validation required; no approved flight values'}, output, indent=2)
print('ESKF0.4.0;', len(contract['configuration_wire']['order']), 'explicit parameters; disabled by default')
