"""New current-source ESKF instances after the no-origin guard safety correction."""
from copy import deepcopy
from dataclasses import replace
from hashlib import sha256
import json
from pathlib import Path
import sys

TASK=Path(__file__).resolve().parent
ROOT=TASK.parents[1]
sys.path.insert(0,str(ROOT/'apps/SCG/src'))
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.project.configuration import ProjectConfiguration_Reconcile
service=FccgService(ROOT/'apps/SCG')
for mode in (0,1,2):
    source=TASK/('eskf15_'+str(mode)+'_default01/SilverStar.ssproject')
    before=sha256(source.read_bytes()).hexdigest()
    model=deepcopy(service.Project_Open(source))
    model.identity=replace(model.identity,name='NavClosure02_OriginFinal_'+str(mode))
    model.component_provenance={}
    model=ProjectConfiguration_Reconcile(model,service.catalog).model
    assert model.algorithm_parameters['silverstar.algorithm.estimator.eskf15']['gnss_recovery_enabled']==0
    target=TASK/('eskf15_'+str(mode)+'_default03')
    assert not target.exists()
    service.Project_Save(model,target,confirm_dangerous=True)
    assert sha256(source.read_bytes()).hexdigest()==before
    with (TASK/(target.name+'_generation.json')).open('x',encoding='utf8') as output:
        json.dump(dict(owner='/root navigation closure02',source_choice='NEW instance, current owners, configuration only',
            purpose='no-origin guard correction; recovery remains disabled',original=str(source),original_sha256=before,
            files={p.relative_to(target).as_posix():sha256(p.read_bytes()).hexdigest()
                   for p in target.rglob('*') if p.is_file()}),output,indent=2)
    print('generated',target.name,flush=True)
