# Navigation closure02 checkpoint / 2026-10-16

Owner /root; branch feature/usb-transport-0.1.3-20261013.
HEAD 21562359c947f7509077297799507c327c275454.

Stack phase completed and locally committed. Both exact fresh mode2 projects
have completed BUILD, POWER10_CHECK, ARCHITECTURE_CHECK, ARTIFACT_CHECK,
STACK_REPORT receipts with return_code0. No build from that phase is running.
Formal evidence docs/evidence/navigation_horizon_stack_binding_20261016 and
review docs/public/SCG/NAVIGATION_HORIZON_STACK_INPUT_REVIEW_20261016.md.
Only recorded task stack scope is proven; critical-contract/manual, MSP/ISR,
WCET and hardware remain NOT PROVEN.

New uncommitted GNSS receipt foundation:
- Cache-only source/sample/native snapshot in core System/Inc+Src/
  system_gnss_receipt.*; source added to owning plugin manifest.
- Genuine actual selector race reproduced by CPU higher-priority scheduling
  at TimeGet between new source and freshness barrier publication.
- gnss_receipt_prefault01 compile plumbing error (two incorrect function names).
  prefault02 compiled O0/O2, 4failed/2passed: both liveness/recovery publication
  admitted stale cached new-source data and changed caller output.
- Fixed owning source_selector.c with GNSS-only atomic selection+barrier
  publication, atomic64-bit barrier refresh; device IO remains outside lock.
- postfix01 unchanged6cases all pass. Later tests add output-preservation,
  nesting, cached native/sample identity, unavailable/invalid clock proof.
- Regression02/03/extended04 have retained compile errors: old captured selector
  fixture lacked current capability header and recovery port declarations.
  Supplemented captured CPU fixtures, no weakened assertions/expectations.
- regression05 final59passed (O0/O2 receipt cases, actual source selector fault
  contracts, multi-instance generation, M9N startup). Tests no longer depend on
  .work generation. Ruff formatted new Python test after that test run.
- No active backend recovery, module, configuration or log/FLP change yet.
  New receipt C has not yet received fresh emitted full generated gates.

Design finding before active integration: frozen recovery draft native_us<=MCU
horizon checks assume shared clock, while actual M9N exposes independent iTOW.
Must fix clock semantics with regression proof or use only truthful MCU clocks;
never relabel native iTOW as MCU timestamp. Frozen draft stays read-only.
Also draft UpdateCandidate invokes legacy Update; horizon uses UpdateRevision2.
Need explicit direct Revision2 path with exact ordinary/no-evidence equivalence.

Outstanding: coherent physical/native qualification; explicit opt-in validated
configuration without invented flight defaults; recovery receive FSM outside
replay and immutable evidence; policy paired with P in modes0/1/2; versioned
logging+FLP reconstruction;1/5/30/120s outage/fault matrix; fresh analyzer/ARM/
architecture/artifact/Power10/stack review for actual changed source; protect
SX1278 uncommitted inputs, root user CSV/TXT and v0.1.2; scoped local commits.
No hardware/push/tag/release/cleanup authorized. No subagents started.
