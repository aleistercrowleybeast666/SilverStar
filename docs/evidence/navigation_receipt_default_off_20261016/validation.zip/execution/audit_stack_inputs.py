"""Read-only census of current compiled inputs against the existing review.

This does not alter or override the checker and never returns acceptance.
"""
from datetime import datetime, timezone
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import re
import subprocess

TASK = Path(__file__).resolve().parent
ROOT = TASK.parents[1]
tool = ROOT/'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tools/check_task_stacks.py'
spec = importlib.util.spec_from_file_location('stacks', tool)
stacks = importlib.util.module_from_spec(spec)
spec.loader.exec_module(stacks)
record = {'owner': '/root', 'utc': datetime.now(timezone.utc).isoformat(),
    'head': subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    'checker_sha256': sha256(tool.read_bytes()).hexdigest(), 'scope': 'census only; review NOT PROVEN', 'projects': {}}
for name, layout in (('kf6_2_native03', 'legacy'), ('eskf15_2_native02', 'auto')):
    project = ROOT/'.work/dev013_horizon01'/name
    build = project/'build/FCCG/SilverStar_F407/Release'
    if layout != 'legacy': build = build/layout
    graph = (project/'Generated/project_sources.mk').read_text(encoding='utf8')
    match = re.search(r'^C_SOURCES \+= \\\n(.*?)(?:\n\n|\Z)', graph, re.M|re.S)
    assert match
    sources = [line.strip().rstrip('\\').strip() for line in match[1].splitlines() if line.strip()]
    data = {'layout': layout, 'unknown_inputs': {}, 'unknown_sources': [], 'changed_graphs': [], 'closures': {}}
    for source in sources:
        source_text = (project/source).read_text(encoding='utf8')
        actual = stacks.BindingSourceHash_Get(source_text)
        if actual not in stacks.BindingSourceVersions_Get(source): data['unknown_sources'].append(source)
        dependency = build/Path(source).with_suffix('.d')
        assert dependency.is_file(), source
        dependencies = dependency.read_text(encoding='utf8').split(':',1)[1].replace('\\\n',' ').split('\n',1)[0].split()
        graph_digest = sha256('\n'.join(dependencies).encode()).hexdigest()
        approved_graphs = []
        for key, value in vars(stacks).items():
            if key.startswith('BINDING_DEPENDENCIES_') and isinstance(value, dict): approved_graphs.extend(value.get(source, []))
        if graph_digest not in approved_graphs: data['changed_graphs'].append(source)
        inputs = []
        for path in dependencies:
            (project/path).resolve().relative_to(project.resolve())
            digest = stacks.BindingSourceHash_Get((project/path).read_text(encoding='utf8'))
            inputs.append([path, digest])
            if digest not in stacks.BindingSourceVersions_Get(path): data['unknown_inputs'][path] = digest
        data['closures'][source] = {'source_sha256': actual, 'dependency_sha256': graph_digest,
            'inputs': inputs, 'closure': stacks.BindingClosureHash_Get(source, actual, inputs)}
    elf, = build.glob('*.elf')
    data['elf'] = {'path': str(elf), 'sha256': sha256(elf.read_bytes()).hexdigest()}
    record['projects'][name] = data
    print(name, len(sources), 'sources;', len(data['unknown_sources']), 'unknown sources;',
        len(data['unknown_inputs']), 'unknown inputs;', len(data['changed_graphs']), 'changed graphs', flush=True)
with (TASK/'stack_input_census01.json').open('x', encoding='utf8') as stream:
    json.dump(record, stream, indent=2)
for name, data in record['projects'].items():
    print(name, 'unknown:', sorted(data['unknown_inputs']), flush=True)
