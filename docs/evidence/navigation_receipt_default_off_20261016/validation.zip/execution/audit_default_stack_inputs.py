"""Read-only actual source/header/compiler closure and changed ARM object review inputs."""
from datetime import datetime, timezone
from hashlib import sha256
import difflib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile

TASK=Path(__file__).resolve().parent
ROOT=TASK.parents[1]
tool=ROOT/'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tools/check_task_stacks.py'
spec=importlib.util.spec_from_file_location('stacks',tool)
stacks=importlib.util.module_from_spec(spec);spec.loader.exec_module(stacks)
record=dict(owner='/root navigation closure02',utc=datetime.now(timezone.utc).isoformat(),
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    scope='ACTUAL_COMPILED_REVIEW_INPUTS_NOT_ACCEPTANCE',checker_sha256=sha256(tool.read_bytes()).hexdigest(),
    compiler=subprocess.check_output(['arm-none-eabi-gcc','--version'],text=True),projects={})
label=sys.argv[1] if len(sys.argv)>1 else '01'
assert label in ('01','02')
patch=[]
with zipfile.ZipFile(TASK/('default_stack_inputs'+label+'.zip'),'x',zipfile.ZIP_DEFLATED) as archive:
    archive.write(tool,'review/checker_before_v20.py')
    for family in ('eskf15','kf6'):
        baseline=TASK/(family+'_2_stack01')
        for mode in (0,1,2):
            variant='default03' if family=='eskf15' and label=='02' else 'default01'
            name=family+'_'+str(mode)+'_'+variant
            project=TASK/name
            result=json.loads((TASK/(name+'_BUILD.json')).read_text(encoding='utf8'))
            assert result['return_code']==0
            model=json.loads((project/'SilverStar.ssproject').read_text(encoding='utf8'))
            layout=model['build']['memory_layout']
            build=project/'build/FCCG/SilverStar_F407/Release'
            if layout!='legacy':build=build/layout
            graph=(project/'Generated/project_sources.mk').read_text(encoding='utf8')
            match=re.search(r'^C_SOURCES \+= \\\n(.*?)(?:\n\n|\Z)',graph,re.M|re.S)
            sources=[line.strip().rstrip('\\').strip() for line in match[1].splitlines() if line.strip()]
            data=dict(layout=layout,closures={},unknown_inputs={},unknown_sources=[],changed_graphs=[],objects={})
            for source in sources:
                actual=stacks.BindingSourceHash_Get((project/source).read_text(encoding='utf8'))
                dependency=build/Path(source).with_suffix('.d')
                assert dependency.is_file(),source
                dependencies=dependency.read_text(encoding='utf8').split(':',1)[1].replace('\\\n',' ').split('\n',1)[0].split()
                graph_hash=sha256('\n'.join(dependencies).encode()).hexdigest()
                approved=[]
                for key,value in vars(stacks).items():
                    if key.startswith('BINDING_DEPENDENCIES_') and isinstance(value,dict):approved.extend(value.get(source,[]))
                if graph_hash not in approved:data['changed_graphs'].append(source)
                inputs=[]
                for path in dependencies:
                    (project/path).resolve().relative_to(project.resolve())
                    digest=stacks.BindingSourceHash_Get((project/path).read_text(encoding='utf8'))
                    inputs.append([path,digest])
                    if digest not in stacks.BindingSourceVersions_Get(path):data['unknown_inputs'][path]=digest
                data['closures'][source]=dict(source_sha256=actual,dependency_sha256=graph_hash,
                    inputs=inputs,closure=stacks.BindingClosureHash_Get(source,actual,inputs))
                if actual not in stacks.BindingSourceVersions_Get(source):
                    data['unknown_sources'].append(source)
                    obj=build/Path(source).with_suffix('.o')
                    asm=subprocess.check_output(['arm-none-eabi-objdump','-dr',str(obj)],text=True)
                    functions={};function=None
                    for line in asm.splitlines():
                        if found:=re.match(r'^[0-9a-f]+ <([^>]+)>:',line):function=found[1];functions[function]=[]
                        elif function and (found:=re.match(r'^\s*[0-9a-f]+:\s+(?:[0-9a-f]{4,8}\s+)+(\S+)\s*(.*)',line)):
                            functions[function].append((found[1],found[2]))
                    indirect={function:stacks.IndirectSites_Get(rows) for function,rows in functions.items()
                              if stacks.IndirectSites_Get(rows)}
                    data['objects'][source]=dict(sha256=sha256(obj.read_bytes()).hexdigest(),
                        compiled_functions=list(functions),indirect_sites=indirect)
                    archive.writestr(name+'/objects/'+Path(source).with_suffix('.asm').as_posix(),asm)
                archive.write(dependency,name+'/dependencies/'+Path(source).with_suffix('.d').as_posix())
            for path,digest in data['unknown_inputs'].items():
                archive.write(project/path,name+'/current/'+path)
                old=baseline/path
                before=old.read_text(encoding='utf8') if old.is_file() else ''
                if old.is_file():archive.write(old,name+'/before/'+path)
                patch.extend(difflib.unified_diff(before.splitlines(True),(project/path).read_text(encoding='utf8').splitlines(True),
                    fromfile=name+'/before/'+path,tofile=name+'/current/'+path))
            elf,=build.glob('*.elf')
            nm=subprocess.check_output(['arm-none-eabi-nm','-a','-S',str(elf)],text=True)
            data['elf']=dict(path=str(elf),sha256=sha256(elf.read_bytes()).hexdigest())
            data['active_recovery_linked_symbols']=[line for line in nm.splitlines()
                if any(token in line for token in ('NavigationEskfReacquisition_','NavigationEskfRecovery_',
                    's_replay_recovery','s_horizon_recovery','s_current_transaction','s_current_policy','s_qualifier','s_receive'))]
            archive.writestr(name+'/linked.nm',nm)
            record['projects'][name]=data
            print(name,len(sources),'sources',len(data['unknown_inputs']),'new input paths',
                  len(data['objects']),'changed objects',sum(bool(o['indirect_sites']) for o in data['objects'].values()),
                  'indirect changed objects',len(data['active_recovery_linked_symbols']),'active-linked symbols',flush=True)
with (TASK/('default_stack_census'+label+'.json')).open('x',encoding='utf8') as output:json.dump(record,output,indent=2)
(TASK/('default_stack_changes'+label+'.patch')).write_text(''.join(patch),encoding='utf8')
