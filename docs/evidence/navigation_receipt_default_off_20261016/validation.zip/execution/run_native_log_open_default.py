"""Production LogOpen exact Descriptor/package pair from newly compiled CPU producers."""
import os
from pathlib import Path
import subprocess
import sys

TASK=Path(__file__).resolve().parent
ROOT=TASK.parents[1]
env={**os.environ,'SILVERSTAR_HORIZON_NATIVE_TRACE_ROOT':str(TASK/'hn02'),
     'SILVERSTAR_FCCG_ROOT':str(ROOT/'apps/SCG')}
raise SystemExit(subprocess.call([sys.executable,'-m','pytest','-q',
    'apps/FLP/tests/test_horizon_native_log_open.py',
    '--basetemp='+str(TASK/'nl02')],cwd=ROOT,env=env))
