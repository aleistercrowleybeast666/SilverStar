"""Seal completed stack-review batch before subsequent firmware edits."""
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import zipfile

TASK=Path(__file__).resolve().parent
ROOT=TASK.parents[1]
destination=ROOT/'docs/evidence/navigation_horizon_stack_binding_20261016'
def digest(path):return sha256(path.read_bytes()).hexdigest()
assert json.loads((TASK/'stack_binding_final03.json').read_text(encoding='utf8'))['exit_code']==0
entries={};gates={};artifacts={}
for name in ('kf6_2_stack01','eskf15_2_stack01'):
    for action in ('POWER10_CHECK','BUILD','ARCHITECTURE_CHECK','ARTIFACT_CHECK','STACK_REPORT'):
        receipt=TASK/(name+'_'+action+'.json')
        value=json.loads(receipt.read_text(encoding='utf8'))
        assert value['return_code']==0,(name,action)
        gates[name+'_'+action]={'command':value['command'],'return_code':0,'receipt_sha256':digest(receipt)}
    for path in (TASK/name/'build/FCCG/SilverStar_F407/Release').rglob('*'):
        if path.is_file() and path.suffix in ('.elf','.map','.bin','.hex'):
            artifacts[path.relative_to(TASK).as_posix()]={'size':path.stat().st_size,'sha256':digest(path)}
sources=[ROOT/'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tools/check_task_stacks.py',
 ROOT/'apps/SCG/tests/test_horizon_stack_binding.py',ROOT/'docs/public/SCG/NAVIGATION_HORIZON_STACK_INPUT_REVIEW_20261016.md']
files=set(TASK.glob('*.py'))
files.update(TASK.glob('*.patch'))
files.update(TASK.glob('stack_*.*'))
for name in ('kf6_2_stack01','eskf15_2_stack01'):
    files.update(path for path in TASK.glob(name+'_*') if path.is_file())
    files.update(path for path in (TASK/name/'build/FCCG/SilverStar_F407/Release').rglob('*')
        if path.is_file() and (path.suffix=='.su' or path.name=='stack-budget.json'))
with zipfile.ZipFile(destination/'validation.zip','x',zipfile.ZIP_DEFLATED) as archive:
    for source in sources:
        key='source/'+source.relative_to(ROOT).as_posix();archive.write(source,key);entries[key]=digest(source)
    for path in sorted(files):
        key='execution/'+path.relative_to(TASK).as_posix();archive.write(path,key);entries[key]=digest(path)
versions={name:subprocess.check_output([name,'--version'],text=True) for name in ('gcc','arm-none-eabi-gcc','mingw32-make')}
record={'owner':'/root navigation closure02','utc':datetime.now(timezone.utc).isoformat(),
 'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
 'scope':'fresh current-source input/object/paired-closure review and emitted task-stack gates',
 'gates':gates,'artifact_sha256':artifacts,'tool_versions':versions,'entries':entries,
 'archive_sha256':digest(destination/'validation.zip'),
 'test_result':'stack_binding_final03:56 passed; Ruff check passed',
 'retained_failures':'original v18 input failures; first negative premise54pass2fail; identical zip entries original retained',
 'unchanged_policy':'all task budgets/reserves/library/callback/unknown-input/dynamic/recursion/coverage criteria retained',
 'static_analysis_scope':'no firmware C change in this gate-only batch; final recovery batch will run fresh actual analyzer',
 'main_MSP_ISR_WCET_hardware_critical_contracts':'NOT_PROVEN; no general compliance or qualification claim'}
(destination/'validation.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
(destination/'README.md').write_text('''# Mode2 stack binding review / 2026-10-16

The current source/object and exact compiler-input review is described in
`docs/public/SCG/NAVIGATION_HORIZON_STACK_INPUT_REVIEW_20261016.md`.
`validation.json` records both freshly and normally generated ARM links and
original emitted stack/P10/architecture/artifact actions, all exit0. The exact
owner checker/test sources, commands, complete logs, GCC frame reports and
linked stack-budget reports are in `validation.zip`; actual artifact hashes
refer to retained versioned task projects.56 relevant negative/policy tests pass.

The source/ordered-header tuple gate remains strict. There are no new stack,
callback, library, recursion, dynamic-frame or source-exclusion exceptions.
Zero indirect sites in changed actual objects is only a configured-object fact;
linked callback restrictions still execute. Main/MSP/ISR nesting, WCET,
hardware stack margin and critical-contract acceptance remain NOT PROVEN.

`inputs.zip` retains the initial two identical duplicate compiler-header entries.
They were byte-compared before unique `inputs_unique.zip` was created. Both are
retained and hashed. Tests consume the unique fixture, not arbitrary projects.
Two initial negative cases accidentally recreated an already approved complete
bus tuple; those failures are retained. The corrected negative first establishes
that its individually approved old/new inputs form an unregistered tuple, then
requires rejection. No production predicate was weakened to fix a test.

This closes the input-hash blocker for these two mode2 configurations. Active
ESKF recovery and final all-mode/full Host closure are subsequent work, not
claimed by this batch. No hardware, wireless edit, push/tag/release or cleanup.
''',encoding='utf8')
print('sealed stack batch',len(entries),'evidence entries;', (destination/'validation.zip').stat().st_size,
      'bytes;',record['archive_sha256'])
