"""Publish exact data definitions to repository authority and shipped FLP snapshot."""
from hashlib import sha256
import json
from pathlib import Path

TASK = Path(__file__).resolve().parent
ROOT = TASK.parents[1]
authority = ROOT / 'contracts/navigation_gnss_reacquisition_v1.json'
manifest = json.loads((ROOT / 'apps/SCG/plugins/builtin/silverstar_algorithm_estimator_eskf15/plugin.json').read_text(encoding='utf8'))
contract = json.loads(authority.read_text(encoding='utf8'))
assert 'parameters' not in contract
contract['parameters'] = [{key: parameter[key] for key in
    ('id', 'type', 'default', 'unit', 'representation', 'min', 'max', 'precision', 'step')}
    for parameter in manifest['algorithm_parameters']['parameters'] if parameter['id'].startswith('gnss_recovery_')]
assert len(contract['parameters']) == 29
authority.write_text(json.dumps(contract, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
packaged = ROOT / 'apps/FLP/src/silverstar_flp/decoder_profiles/contracts/navigation_gnss_reacquisition_v1.json'
assert not packaged.exists()
packaged.write_bytes(authority.read_bytes())
print('Exact trusted snapshot', sha256(packaged.read_bytes()).hexdigest())
