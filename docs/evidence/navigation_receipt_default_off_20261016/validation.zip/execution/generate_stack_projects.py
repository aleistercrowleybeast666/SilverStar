"""Fresh normal generation, same explicit reviewed model identity/configuration."""
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import sys

TASK=Path(__file__).resolve().parent
ROOT=TASK.parents[1]
sys.path.insert(0,str(ROOT/'apps/SCG/src'))
from silverstar_fccg.app.service import FccgService

service=FccgService(ROOT/'apps/SCG')
for old,new in (('kf6_2_native03','kf6_2_stack01'),('eskf15_2_native02','eskf15_2_stack01')):
    original=ROOT/'.work/dev013_horizon01'/old/'SilverStar.ssproject'
    original_sha=sha256(original.read_bytes()).hexdigest()
    model=service.Project_Open(original)
    target=TASK/new
    assert not target.exists() and target.parent==TASK
    service.Project_Save(model,target,confirm_dangerous=True)
    assert sha256(original.read_bytes()).hexdigest()==original_sha
    result={'owner':'/root fresh stack review validation','utc':datetime.now(timezone.utc).isoformat(),
        'original_model':str(original),'original_sha256':original_sha,
        'purpose':'fresh normal generation for exact v19 source/object/stack review; no hardware',
        'files':{path.relative_to(target).as_posix():sha256(path.read_bytes()).hexdigest()
            for path in target.rglob('*') if path.is_file()}}
    with (TASK/(new+'_generation.json')).open('x',encoding='utf8') as output:json.dump(result,output,indent=2)
    print('generated',new,len(result['files']),'files; original untouched',flush=True)
