# SilverStar flight logs

Use `NavClosure02_OriginFinal_0.ssdecoder` from the project root as the declarative
decoder profile for logs produced by this exact generated configuration. The package contains
the record catalog, project semantics, checksums, and no executable code.

- Generation profile SHA-256: `867ed59f9885ea3b1d2feb5097b0c33df6cceeddef36997686d5d9536e7b0860`
- Package SHA-256: `9e272dd1c7404d1740c8d913b80dab0f191b47a9f54a617200643eca4b59d6a4`

Task logs may be stored below `Logs/`. Running the generated Host Tests creates
`Golden/NavClosure02_OriginFinal_0_golden.sslog` with the real SSLOG C codec;
`Golden/expected.json` records the expected Record and channel identities.
The `.ssdecoder` file may also be copied beside a log
or to its parent task directory; SilverStar_FLP can search the current directory, child
directories, and the parent for a matching profile. Archive the package with its firmware.

`period_us = 0` means that a non-periodic stream does not use a periodic interval; it never
means a zero-period continuous logging loop. A DECIMATION stream records once per configured
decimation factor of source updates.
