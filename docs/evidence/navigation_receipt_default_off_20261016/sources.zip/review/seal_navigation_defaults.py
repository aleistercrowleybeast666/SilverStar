"""Seal scoped current sources, exact generated inputs, real outputs and retained failures."""
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import zipfile

TASK=Path(__file__).resolve().parent
ROOT=TASK.parents[1]
FORMAL=ROOT/'docs/evidence/navigation_receipt_default_off_20261016'
scopes=[
 'apps/SCG/plugins/builtin/silverstar_algorithm_estimator_eskf15',
 'apps/SCG/plugins/builtin/silverstar_core_0_1_0/plugin.json',
 'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/System/Inc/system_gnss_receipt.h',
 'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/System/Src/system_gnss_receipt.c',
 'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/System/Src/system_source_selector.c',
 'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tools/check_task_stacks.py',
 *['apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tests/Host/'+p for p in
   ('run_tests.ps1','test_eskf_horizon.c','test_eskf_origin_receipt_fault.c','test_logger.c')],
 'apps/SCG/src/silverstar_fccg/generator/render.py',
 *['apps/SCG/src/silverstar_fccg/project/'+p+'.py' for p in
   ('algorithm_parameters','validation','gnss_reacquisition')],
 *['apps/SCG/tests/'+p+'.py' for p in ('test_eskf15_horizon','test_eskf15_horizon_backend',
   'test_eskf_body_cadence','test_eskf_workspace_equivalence','test_eskf15_recovery',
   'test_eskf15_recovery_horizon','test_eskf15_recovery_replay','test_eskf15_recovery_qualifier',
   'test_gnss_receipt_publication','test_gnss_reacquisition_config',
   'test_gnss_reacquisition_configuration_c','test_receipt_stack_binding')],
 *['apps/SCG/tests/fixtures/'+p for p in ('eskf15_recovery.c','eskf15_recovery_horizon.c',
   'eskf15_recovery_replay.c','eskf15_recovery_qualifier.c','gnss_receipt_publication.c',
   'source_selector/project_device_instances.h','source_selector/project_device_build_capabilities.h')],
 *['apps/FLP/src/silverstar_flp/decoder_profiles/'+p for p in ('contract_data.py',
   'fusion_horizon_identity.py','fusion_timing.py','gnss_reacquisition.py',
   'contracts/navigation_gnss_reacquisition_v1.json')],
 'apps/FLP/src/silverstar_flp/plugins/algorithms/eskf15/plugin.py',
 *['apps/FLP/tests/'+p+'.py' for p in ('test_eskf15_native_parity','test_fusion_current_native_parity',
   'test_fusion_horizon_backend_wire','test_packaged_fusion_contracts','test_gnss_reacquisition_identity')],
 'contracts/navigation_gnss_reacquisition_v1.json',
 'docs/public/SCG/NAVIGATION_DEFAULT_OFF_ACCEPTANCE_20261016.md',
 'docs/public/SCG/NAVIGATION_RECEIPT_DEFAULT_OFF_STACK_REVIEW_20261016.md']
raw=subprocess.check_output(['git','ls-files','--modified','--others','--exclude-standard','-z','--',*scopes],cwd=ROOT)
owned=sorted(set(raw.decode('utf8').rstrip('\0').split('\0')))
assert all(owned) and not any('usb' in p.lower() or 'sx1278' in p.lower() or 'GSHC' in p for p in owned)
hashes={p:sha256((ROOT/p).read_bytes()).hexdigest() for p in owned}
protected=json.loads((TASK/'stack_local_commit01.json').read_text())['protected_inputs_sha256']
assert all(sha256((ROOT/p).read_bytes()).hexdigest()==digest for p,digest in protected.items())
assert subprocess.check_output(['git','rev-parse','v0.1.2'],cwd=ROOT,text=True).strip()=='942f20ef64df3cb1aa65be7349361c409418aa0f'
models=('eskf15_0_default03','eskf15_1_default03','eskf15_2_default03',
        'kf6_0_default01','kf6_1_default01','kf6_2_default01')
results={};stacks={}
for name in models:
    project=TASK/name
    model=json.loads((project/'SilverStar.ssproject').read_text())
    layout=model['build']['memory_layout']
    build=project/'build/FCCG/SilverStar_F407/Release'
    if layout!='legacy':build=build/layout
    receipts={}
    for action in ('POWER10_CHECK','ARCHITECTURE_CHECK','BUILD','ARTIFACT_CHECK'):
        path=TASK/(name+'_'+action+'.json');data=json.loads(path.read_text())
        assert data['return_code']==0,(name,action)
        receipts[action]=path.name
    analysis=TASK/('mode1_fresh_static_analysis02.json' if name=='eskf15_1_default03'
                  else name+'_STATIC_ANALYSIS.json')
    data=json.loads(analysis.read_text())
    assert data.get('return_code',data.get('exit_code'))==0
    receipts['STATIC_ANALYSIS']=analysis.name
    gate=TASK/(name+'_v20_STACK_REPORT.json')
    assert json.loads(gate.read_text())['return_code']==0
    receipts['STACK_REPORT']=gate.name
    report=json.loads((build/'stack-budget.json').read_text())
    assert report['passes'] and report['binding_review_revision']=='navigation_receipt_default_off_20261016_v20'
    elf=build/'SilverStar_0_1_3.elf'
    assert sha256(elf.read_bytes()).hexdigest()==report['elf_sha256']
    results[name]=dict(layout=layout,receipts=receipts,elf_sha256=report['elf_sha256'])
    stacks[name]=report['tasks']
assert json.loads((TASK/'eskf15_1_default03_host02_HOST_TESTS.json').read_text())['return_code']==0
final_runs=('deadline_kernel01','deadline_backend_fault01','deadline_origin_fault03',
    'deadline_current_parity04','deadline_native_horizon02','deadline_native_log_open02',
    'deadline_v20_tests01','deadline_packaged02','deadline_equivalence_final01','deadline_python_lint02')
for name in final_runs:assert json.loads((TASK/(name+'.json')).read_text())['exit_code']==0,name
with zipfile.ZipFile(FORMAL/'sources.zip','x',zipfile.ZIP_DEFLATED) as archive:
    for path in owned:archive.write(ROOT/path,path)
    archive.write(TASK/'seal_navigation_defaults.py','review/seal_navigation_defaults.py')
entries={}
def add(archive,path,name):
    raw=path.read_bytes();archive.writestr(name,raw);entries[name]=sha256(raw).hexdigest()
with zipfile.ZipFile(FORMAL/'validation.zip','x',zipfile.ZIP_DEFLATED) as archive:
    # Root receipts/logs retain failures, unknown/skip statuses and runner snapshots.
    for path in sorted(TASK.iterdir()):
        if path.is_file() and (path.suffix in ('.json','.log','.py','.c','.md') or path.name.endswith('_runner_sources.zip')):
            add(archive,path,'execution/'+path.name)
    for name in models:
        project=TASK/name
        generation=json.loads((TASK/(name+'_generation.json')).read_text())
        for relative,expected in generation['files'].items():
            path=project/relative
            actual=sha256(path.read_bytes()).hexdigest()
            if relative=='Tools/check_task_stacks.py':
                assert actual==json.loads((TASK/'gate_emission_v20.json').read_text())['after_sha256']
            else:assert actual==expected,(name,relative)
            add(archive,path,'project/'+name+'/'+relative)
        layout=results[name]['layout']
        build=project/'build/FCCG/SilverStar_F407/Release'
        if layout!='legacy':build=build/layout
        for path in sorted(build.rglob('*')):
            if path.is_file() and path.suffix in ('.elf','.map','.su','.d','.json'):
                add(archive,path,'linked/'+name+'/'+path.relative_to(build).as_posix())
    fresh=TASK/'eskf15_1_default03/build/FCCG/SilverStar_F407/StaticAnalysisFresh02/Release/auto'
    for path in sorted(fresh.rglob('*')):
        if path.is_file() and path.suffix in ('.elf','.map','.su','.d','.json'):
            add(archive,path,'fresh_analysis_mode1/'+path.relative_to(fresh).as_posix())
    for rootname in ('cp04','hn02','nl02','origin03_prefault_tmp','origin03_postfix_tmp'):
        root=TASK/rootname
        assert root.is_dir(),rootname
        for path in sorted(root.rglob('*')):
            if path.is_file():add(archive,path,'cpu/'+rootname+'/'+path.relative_to(root).as_posix())
validation=dict(schema='silverstar.navigation.default-off-evidence/1',utc=datetime.now(timezone.utc).isoformat(),
    owner='/root',source_base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    status='SCOPED_DEFAULT_OFF_SOFTWARE_RESULTS_ONLY',active_recovery='BLOCKED_INCOMPLETE',
    critical_contract_main_MSP_ISR_WCET_hardware_flight='NOT_PROVEN',
    final_firmware=results,task_stack_rows=stacks,final_independent_runs=final_runs,
    source_sha256=hashes,protected_inputs_sha256=protected,
    sources_zip_sha256=sha256((FORMAL/'sources.zip').read_bytes()).hexdigest(),
    validation_zip_sha256=sha256((FORMAL/'validation.zip').read_bytes()).hexdigest(),
    validation_entries=entries,
    historical_limitations=['Initial and superseded failures are retained, not final passes.',
        'One preexisting FLP export-source failure reproduced with HEAD modules; no full FLP-suite PASS.',
        'cp01 scratch was reused by an earlier parity retry; its root receipts/logs remain, raw prior scratch is not final evidence.',
        'Final cp04, hn02 and nl02 were fresh unique paths. All final pytest scopes have zero skips.',
        'Full Host used an explicit recorded owning fixture revision; original project snapshot was then restored.',
        'No source logs, decoder inputs, protected wireless WIP or frozen release were cleanup targets.'],
    excluded_work=['USB independent changes and controller patch','GSHC GUI work','README/showcase work','SX1278 WIP'])
(FORMAL/'validation.json').write_text(json.dumps(validation,indent=2)+'\n',encoding='utf8')
manifest=json.loads((FORMAL/'manifest.json').read_text())
manifest.update(status='RECORDED_EMITTED_GATES_AND_NEGATIVE_TESTS_PASSED_SCOPED_ONLY',
    validation_sha256=sha256((FORMAL/'validation.json').read_bytes()).hexdigest(),
    source_snapshot_sha256=validation['sources_zip_sha256'],validation_archive_sha256=validation['validation_zip_sha256'])
(FORMAL/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
with (TASK/'navigation_owned_paths.json').open('x',encoding='utf8') as output:json.dump(owned,output,indent=2)
print('sealed',len(owned),'owned changed files;',len(entries),'validation entries;',
      (FORMAL/'validation.zip').stat().st_size,'archive bytes')
