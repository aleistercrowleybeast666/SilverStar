build/FCCG/SilverStar_F407/Release/auto/Common/Src/debug_log.o: \
 Common/Src/debug_log.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h Common/Inc/debug_log.h \
 Interfaces/Inc/system_console_if.h Interfaces/Inc/system_device_types.h \
 Common/Inc/silverstar_compiler.h System/User/system_user_config.h \
 System/Inc/system_configuration_types.h \
 System/User/system_user_flight_config.h \
 Targets/SilverStar_F407/Inc/target_system_config.h \
 System/Inc/system_capabilities.h Interfaces/Inc/system_device_types.h \
 System/User/system_user_alignment_config.h \
 System/Alignment/Inc/system_alignment.h \
 System/User/system_user_capability_validation.h \
 System/User/system_user_platform_capabilities.h \
 Common/Inc/common_format.h Common/Inc/silverstar_assert.h \
 Common/Inc/silverstar_compiler.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
Common/Inc/debug_log.h:
Interfaces/Inc/system_console_if.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
System/User/system_user_config.h:
System/Inc/system_configuration_types.h:
System/User/system_user_flight_config.h:
Targets/SilverStar_F407/Inc/target_system_config.h:
System/Inc/system_capabilities.h:
Interfaces/Inc/system_device_types.h:
System/User/system_user_alignment_config.h:
System/Alignment/Inc/system_alignment.h:
System/User/system_user_capability_validation.h:
System/User/system_user_platform_capabilities.h:
Common/Inc/common_format.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
