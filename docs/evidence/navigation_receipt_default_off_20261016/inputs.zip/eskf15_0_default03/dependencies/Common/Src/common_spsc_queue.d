build/FCCG/SilverStar_F407/Release/auto/Common/Src/common_spsc_queue.o: \
 Common/Src/common_spsc_queue.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 Common/Inc/common_spsc_queue.h Common/Inc/silverstar_assert.h \
 Common/Inc/silverstar_compiler.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
Common/Inc/common_spsc_queue.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
