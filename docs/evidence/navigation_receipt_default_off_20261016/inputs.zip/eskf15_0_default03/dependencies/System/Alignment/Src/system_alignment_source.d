build/FCCG/SilverStar_F407/Release/auto/System/Alignment/Src/system_alignment_source.o: \
 System/Alignment/Src/system_alignment_source.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 System/Alignment/Inc/system_alignment.h \
 Interfaces/Inc/system_device_types.h Common/Inc/silverstar_compiler.h \
 System/Inc/system_configuration_types.h Common/Inc/common_format.h \
 Common/Inc/silverstar_assert.h Common/Inc/silverstar_compiler.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
System/Alignment/Inc/system_alignment.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
System/Inc/system_configuration_types.h:
Common/Inc/common_format.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
