build/FCCG/SilverStar_F407/Release/auto/System/Indicator/Src/system_indicator.o: \
 System/Indicator/Src/system_indicator.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 System/Indicator/Inc/system_indicator.h \
 Interfaces/Inc/system_device_types.h Common/Inc/silverstar_compiler.h \
 Interfaces/Inc/system_indicator_if.h \
 Interfaces/Inc/system_device_types.h \
 System/Alignment/Inc/system_alignment.h \
 System/Inc/system_configuration_types.h \
 System/Calibration/Inc/system_calibration.h \
 Algorithm/Calibration/Inc/imu_six_face_calibration.h \
 System/Inertial/Inc/system_inertial_types.h \
 Interfaces/Inc/system_imu_epoch_if.h System/Inc/system_lifecycle.h \
 System/User/system_user_config.h System/User/system_user_flight_config.h \
 Targets/SilverStar_F407/Inc/target_system_config.h \
 System/Inc/system_capabilities.h \
 System/User/system_user_alignment_config.h \
 System/User/system_user_capability_validation.h \
 System/User/system_user_platform_capabilities.h \
 Common/Inc/silverstar_assert.h Common/Inc/silverstar_compiler.h \
 Interfaces/Inc/system_gnss_if.h System/Inc/system_health.h \
 System/Inc/system_capabilities.h System/Inc/system_time.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
System/Indicator/Inc/system_indicator.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
Interfaces/Inc/system_indicator_if.h:
Interfaces/Inc/system_device_types.h:
System/Alignment/Inc/system_alignment.h:
System/Inc/system_configuration_types.h:
System/Calibration/Inc/system_calibration.h:
Algorithm/Calibration/Inc/imu_six_face_calibration.h:
System/Inertial/Inc/system_inertial_types.h:
Interfaces/Inc/system_imu_epoch_if.h:
System/Inc/system_lifecycle.h:
System/User/system_user_config.h:
System/User/system_user_flight_config.h:
Targets/SilverStar_F407/Inc/target_system_config.h:
System/Inc/system_capabilities.h:
System/User/system_user_alignment_config.h:
System/User/system_user_capability_validation.h:
System/User/system_user_platform_capabilities.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
Interfaces/Inc/system_gnss_if.h:
System/Inc/system_health.h:
System/Inc/system_capabilities.h:
System/Inc/system_time.h:
