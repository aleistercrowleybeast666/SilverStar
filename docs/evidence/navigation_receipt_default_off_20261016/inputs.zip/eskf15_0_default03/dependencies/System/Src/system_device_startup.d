build/FCCG/SilverStar_F407/Release/auto/System/Src/system_device_startup.o: \
 System/Src/system_device_startup.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 System/Inc/system_device_startup.h Common/Inc/silverstar_assert.h \
 Common/Inc/silverstar_compiler.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
System/Inc/system_device_startup.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
