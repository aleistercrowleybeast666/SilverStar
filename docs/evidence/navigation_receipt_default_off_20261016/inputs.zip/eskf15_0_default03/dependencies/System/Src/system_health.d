build/FCCG/SilverStar_F407/Release/auto/System/Src/system_health.o: \
 System/Src/system_health.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 System/Inc/system_health.h System/Inc/system_capabilities.h \
 Interfaces/Inc/system_device_types.h Common/Inc/silverstar_compiler.h \
 Platform/Inc/platform_critical.h Common/Inc/silverstar_assert.h \
 Common/Inc/silverstar_compiler.h System/Alignment/Inc/system_alignment.h \
 System/Inc/system_configuration_types.h \
 System/Calibration/Inc/system_calibration.h \
 Algorithm/Calibration/Inc/imu_six_face_calibration.h \
 System/Inertial/Inc/system_inertial_types.h \
 Interfaces/Inc/system_imu_epoch_if.h \
 Interfaces/Inc/system_device_types.h System/Inc/system_profile.h \
 System/Inc/system_navigation_profile.h \
 System/Inc/system_configuration_types.h System/User/system_user_config.h \
 System/User/system_user_flight_config.h \
 Targets/SilverStar_F407/Inc/target_system_config.h \
 System/Inc/system_capabilities.h \
 System/User/system_user_alignment_config.h \
 System/User/system_user_capability_validation.h \
 System/User/system_user_platform_capabilities.h \
 Interfaces/Inc/system_output_if.h System/Inc/system_startup.h \
 Interfaces/Inc/system_gnss_if.h System/Inc/system_time.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
System/Inc/system_health.h:
System/Inc/system_capabilities.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
Platform/Inc/platform_critical.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
System/Alignment/Inc/system_alignment.h:
System/Inc/system_configuration_types.h:
System/Calibration/Inc/system_calibration.h:
Algorithm/Calibration/Inc/imu_six_face_calibration.h:
System/Inertial/Inc/system_inertial_types.h:
Interfaces/Inc/system_imu_epoch_if.h:
Interfaces/Inc/system_device_types.h:
System/Inc/system_profile.h:
System/Inc/system_navigation_profile.h:
System/Inc/system_configuration_types.h:
System/User/system_user_config.h:
System/User/system_user_flight_config.h:
Targets/SilverStar_F407/Inc/target_system_config.h:
System/Inc/system_capabilities.h:
System/User/system_user_alignment_config.h:
System/User/system_user_capability_validation.h:
System/User/system_user_platform_capabilities.h:
Interfaces/Inc/system_output_if.h:
System/Inc/system_startup.h:
Interfaces/Inc/system_gnss_if.h:
System/Inc/system_time.h:
