build/FCCG/SilverStar_F407/Release/auto/System/Src/system_time.o: \
 System/Src/system_time.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 System/Inc/system_time.h Interfaces/Inc/system_device_types.h \
 Common/Inc/silverstar_compiler.h Platform/Inc/platform_critical.h \
 Platform/Inc/platform_time.h Platform/Inc/platform_types.h \
 Common/Inc/silverstar_assert.h Common/Inc/silverstar_compiler.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
System/Inc/system_time.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
Platform/Inc/platform_critical.h:
Platform/Inc/platform_time.h:
Platform/Inc/platform_types.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
