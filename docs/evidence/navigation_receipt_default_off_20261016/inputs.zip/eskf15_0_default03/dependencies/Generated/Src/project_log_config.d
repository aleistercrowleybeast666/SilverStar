build/FCCG/SilverStar_F407/Release/auto/Generated/Src/project_log_config.o: \
 Generated/Src/project_log_config.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 Generated/Inc/project_log_config.h System/Inc/system_log_policy.h \
 Protocol/SSLOG/Inc/sslog_records.h Interfaces/Inc/system_device_types.h \
 Common/Inc/silverstar_compiler.h Protocol/SSLOG/Inc/sslog_protocol.h \
 Protocol/SSLOG/Inc/sslog_records.h System/User/system_user_config.h \
 System/Inc/system_configuration_types.h \
 System/User/system_user_flight_config.h \
 Targets/SilverStar_F407/Inc/target_system_config.h \
 System/Inc/system_capabilities.h \
 System/User/system_user_alignment_config.h \
 System/Alignment/Inc/system_alignment.h \
 System/User/system_user_capability_validation.h \
 System/User/system_user_platform_capabilities.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
Generated/Inc/project_log_config.h:
System/Inc/system_log_policy.h:
Protocol/SSLOG/Inc/sslog_records.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
Protocol/SSLOG/Inc/sslog_protocol.h:
Protocol/SSLOG/Inc/sslog_records.h:
System/User/system_user_config.h:
System/Inc/system_configuration_types.h:
System/User/system_user_flight_config.h:
Targets/SilverStar_F407/Inc/target_system_config.h:
System/Inc/system_capabilities.h:
System/User/system_user_alignment_config.h:
System/Alignment/Inc/system_alignment.h:
System/User/system_user_capability_validation.h:
System/User/system_user_platform_capabilities.h:
