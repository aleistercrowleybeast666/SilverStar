build/FCCG/SilverStar_F407/Release/auto/Generated/Src/project_device_instances.o: \
 Generated/Src/project_device_instances.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 Generated/Inc/project_device_instances.h \
 Interfaces/Inc/system_barometer_if.h \
 Interfaces/Inc/system_device_types.h Common/Inc/silverstar_compiler.h \
 Interfaces/Inc/system_descriptor_if.h Interfaces/Inc/system_gnss_if.h \
 Interfaces/Inc/system_hardware_quaternion_if.h \
 Interfaces/Inc/system_imu_if.h Interfaces/Inc/system_imu_epoch_if.h \
 Interfaces/Inc/system_magnetometer_if.h Interfaces/Inc/system_power_if.h \
 Interfaces/Inc/system_telemetry_transport_if.h \
 Common/Inc/silverstar_assert.h Common/Inc/silverstar_compiler.h \
 Devices/IMU/JY901B/Adapter/Inc/jy901b_instance.h \
 Devices/GNSS/NEO_M9N/Adapter/Inc/neo_m9n_instance.h \
 Devices/Telemetry/SX1281/Adapter/Inc/sx1281_instance.h \
 Devices/Telemetry/SX1281/Inc/sx1281_bus.h Platform/Inc/platform_gpio.h \
 Platform/Inc/platform_types.h Platform/Inc/platform_types.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
Generated/Inc/project_device_instances.h:
Interfaces/Inc/system_barometer_if.h:
Interfaces/Inc/system_device_types.h:
Common/Inc/silverstar_compiler.h:
Interfaces/Inc/system_descriptor_if.h:
Interfaces/Inc/system_gnss_if.h:
Interfaces/Inc/system_hardware_quaternion_if.h:
Interfaces/Inc/system_imu_if.h:
Interfaces/Inc/system_imu_epoch_if.h:
Interfaces/Inc/system_magnetometer_if.h:
Interfaces/Inc/system_power_if.h:
Interfaces/Inc/system_telemetry_transport_if.h:
Common/Inc/silverstar_assert.h:
Common/Inc/silverstar_compiler.h:
Devices/IMU/JY901B/Adapter/Inc/jy901b_instance.h:
Devices/GNSS/NEO_M9N/Adapter/Inc/neo_m9n_instance.h:
Devices/Telemetry/SX1281/Adapter/Inc/sx1281_instance.h:
Devices/Telemetry/SX1281/Inc/sx1281_bus.h:
Platform/Inc/platform_gpio.h:
Platform/Inc/platform_types.h:
Platform/Inc/platform_types.h:
