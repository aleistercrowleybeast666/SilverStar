build/FCCG/SilverStar_F407/Release/auto/Platform/STM32F4/Src/platform_critical_stm32f4.o: \
 Platform/STM32F4/Src/platform_critical_stm32f4.c \
 Targets/SilverStar_F407/Inc/platform_memory_target.h \
 Generated/Inc/project_flight_config.h \
 Generated/Inc/project_algorithm_parameters.h \
 Generated/Inc/project_device_build_capabilities.h \
 Platform/Inc/platform_critical.h Drivers/CMSIS/Include/cmsis_gcc.h
Targets/SilverStar_F407/Inc/platform_memory_target.h:
Generated/Inc/project_flight_config.h:
Generated/Inc/project_algorithm_parameters.h:
Generated/Inc/project_device_build_capabilities.h:
Platform/Inc/platform_critical.h:
Drivers/CMSIS/Include/cmsis_gcc.h:
