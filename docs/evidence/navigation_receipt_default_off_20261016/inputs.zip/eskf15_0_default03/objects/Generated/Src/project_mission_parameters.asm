
D:\python_software\SilverStar\.work\dev013_navclosure02\eskf15_0_default03\build\FCCG\SilverStar_F407\Release\auto\Generated\Src\project_mission_parameters.o:     file format elf32-littlearm


Disassembly of section .text.SystemProjectParameter_CountGet:

00000000 <SystemProjectParameter_CountGet>:
   0:	2046      	movs	r0, #70	@ 0x46
   2:	4770      	bx	lr

Disassembly of section .text.SystemProjectParameter_Get:

00000000 <SystemProjectParameter_Get>:
   0:	b301      	cbz	r1, 44 <SystemProjectParameter_Get+0x44>
   2:	b530      	push	{r4, r5, lr}
   4:	2845      	cmp	r0, #69	@ 0x45
   6:	b083      	sub	sp, #12
   8:	4605      	mov	r5, r0
   a:	d816      	bhi.n	3a <SystemProjectParameter_Get+0x3a>
   c:	460c      	mov	r4, r1
   e:	225b      	movs	r2, #91	@ 0x5b
  10:	9200      	str	r2, [sp, #0]
  12:	4620      	mov	r0, r4
  14:	4b0d      	ldr	r3, [pc, #52]	@ (4c <SystemProjectParameter_Get+0x4c>)
  16:	2207      	movs	r2, #7
  18:	2104      	movs	r1, #4
  1a:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			1a: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  1e:	4b0c      	ldr	r3, [pc, #48]	@ (50 <SystemProjectParameter_Get+0x50>)
  20:	eb05 0545 	add.w	r5, r5, r5, lsl #1
  24:	eb03 0385 	add.w	r3, r3, r5, lsl #2
  28:	e893 0007 	ldmia.w	r3, {r0, r1, r2}
  2c:	f04f 0c00 	mov.w	ip, #0
  30:	e884 0007 	stmia.w	r4, {r0, r1, r2}
  34:	4660      	mov	r0, ip
  36:	b003      	add	sp, #12
  38:	bd30      	pop	{r4, r5, pc}
  3a:	f04f 0c02 	mov.w	ip, #2
  3e:	4660      	mov	r0, ip
  40:	b003      	add	sp, #12
  42:	bd30      	pop	{r4, r5, pc}
  44:	f04f 0c01 	mov.w	ip, #1
  48:	4660      	mov	r0, ip
  4a:	4770      	bx	lr
	...
			4c: R_ARM_ABS32	.rodata.SystemProjectParameter_Get.str1.4
			50: R_ARM_ABS32	.rodata.s_parameters
