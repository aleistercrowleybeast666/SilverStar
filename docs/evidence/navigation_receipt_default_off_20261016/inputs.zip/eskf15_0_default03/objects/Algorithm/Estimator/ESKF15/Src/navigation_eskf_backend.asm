
D:\python_software\SilverStar\.work\dev013_navclosure02\eskf15_0_default03\build\FCCG\SilverStar_F407\Release\auto\Algorithm\Estimator\ESKF15\Src\navigation_eskf_backend.o:     file format elf32-littlearm


Disassembly of section .text.Backend_CurrentPacketAdmit:

00000000 <Backend_CurrentPacketAdmit>:
   0:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
   4:	4c29      	ldr	r4, [pc, #164]	@ (ac <Backend_CurrentPacketAdmit+0xac>)
   6:	7824      	ldrb	r4, [r4, #0]
   8:	2c00      	cmp	r4, #0
   a:	d138      	bne.n	7e <Backend_CurrentPacketAdmit+0x7e>
   c:	461d      	mov	r5, r3
   e:	4b28      	ldr	r3, [pc, #160]	@ (b0 <Backend_CurrentPacketAdmit+0xb0>)
  10:	781b      	ldrb	r3, [r3, #0]
  12:	b3a3      	cbz	r3, 7e <Backend_CurrentPacketAdmit+0x7e>
  14:	4680      	mov	r8, r0
  16:	460f      	mov	r7, r1
  18:	4616      	mov	r6, r2
  1a:	f7ff fffe 	bl	0 <SystemCalibration_GenerationGet>
			1a: R_ARM_THM_CALL	SystemCalibration_GenerationGet
  1e:	4b25      	ldr	r3, [pc, #148]	@ (b4 <Backend_CurrentPacketAdmit+0xb4>)
  20:	681b      	ldr	r3, [r3, #0]
  22:	4298      	cmp	r0, r3
  24:	d127      	bne.n	76 <Backend_CurrentPacketAdmit+0x76>
  26:	ea56 0305 	orrs.w	r3, r6, r5
  2a:	d02c      	beq.n	86 <Backend_CurrentPacketAdmit+0x86>
  2c:	4b22      	ldr	r3, [pc, #136]	@ (b8 <Backend_CurrentPacketAdmit+0xb8>)
  2e:	e9d3 23f2 	ldrd	r2, r3, [r3, #968]	@ 0x3c8
  32:	42b2      	cmp	r2, r6
  34:	eb73 0105 	sbcs.w	r1, r3, r5
  38:	d325      	bcc.n	86 <Backend_CurrentPacketAdmit+0x86>
  3a:	4920      	ldr	r1, [pc, #128]	@ (bc <Backend_CurrentPacketAdmit+0xbc>)
  3c:	e9d1 0100 	ldrd	r0, r1, [r1]
  40:	4286      	cmp	r6, r0
  42:	eb75 0101 	sbcs.w	r1, r5, r1
  46:	d316      	bcc.n	76 <Backend_CurrentPacketAdmit+0x76>
  48:	491d      	ldr	r1, [pc, #116]	@ (c0 <Backend_CurrentPacketAdmit+0xc0>)
  4a:	1b92      	subs	r2, r2, r6
  4c:	eb63 0305 	sbc.w	r3, r3, r5
  50:	4291      	cmp	r1, r2
  52:	eb74 0303 	sbcs.w	r3, r4, r3
  56:	d320      	bcc.n	9a <Backend_CurrentPacketAdmit+0x9a>
  58:	f1b8 0f00 	cmp.w	r8, #0
  5c:	d013      	beq.n	86 <Backend_CurrentPacketAdmit+0x86>
  5e:	f898 3004 	ldrb.w	r3, [r8, #4]
  62:	b1a3      	cbz	r3, 8e <Backend_CurrentPacketAdmit+0x8e>
  64:	f8d8 2000 	ldr.w	r2, [r8]
  68:	4297      	cmp	r7, r2
  6a:	d018      	beq.n	9e <Backend_CurrentPacketAdmit+0x9e>
  6c:	1aba      	subs	r2, r7, r2
  6e:	2a00      	cmp	r2, #0
  70:	da0d      	bge.n	8e <Backend_CurrentPacketAdmit+0x8e>
  72:	2405      	movs	r4, #5
  74:	e000      	b.n	78 <Backend_CurrentPacketAdmit+0x78>
  76:	2404      	movs	r4, #4
  78:	4620      	mov	r0, r4
  7a:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
  7e:	2407      	movs	r4, #7
  80:	4620      	mov	r0, r4
  82:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
  86:	2401      	movs	r4, #1
  88:	4620      	mov	r0, r4
  8a:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
  8e:	2380      	movs	r3, #128	@ 0x80
  90:	f8c8 7000 	str.w	r7, [r8]
  94:	f888 3004 	strb.w	r3, [r8, #4]
  98:	e7ee      	b.n	78 <Backend_CurrentPacketAdmit+0x78>
  9a:	2402      	movs	r4, #2
  9c:	e7ec      	b.n	78 <Backend_CurrentPacketAdmit+0x78>
  9e:	061a      	lsls	r2, r3, #24
  a0:	d402      	bmi.n	a8 <Backend_CurrentPacketAdmit+0xa8>
  a2:	f043 0380 	orr.w	r3, r3, #128	@ 0x80
  a6:	e7f3      	b.n	90 <Backend_CurrentPacketAdmit+0x90>
  a8:	2403      	movs	r4, #3
  aa:	e7e5      	b.n	78 <Backend_CurrentPacketAdmit+0x78>
	...
			ac: R_ARM_ABS32	.bss.s_current_faulted
			b0: R_ARM_ABS32	.bss.s_current_endpoint_valid
			b4: R_ARM_ABS32	.bss.s_calibration_generation
			b8: R_ARM_ABS32	.bss.s_state
			bc: R_ARM_ABS32	.bss.s_current_epoch_start_us
  c0:	0007a120 	.word	0x0007a120

Disassembly of section .text.Backend_StateLog:

00000000 <Backend_StateLog>:
   0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
   4:	b0cb      	sub	sp, #300	@ 0x12c
   6:	2402      	movs	r4, #2
   8:	f8df 9160 	ldr.w	r9, [pc, #352]	@ 16c <Backend_StateLog+0x16c>
   c:	9400      	str	r4, [sp, #0]
   e:	4621      	mov	r1, r4
  10:	4a50      	ldr	r2, [pc, #320]	@ (154 <Backend_StateLog+0x154>)
  12:	4e51      	ldr	r6, [pc, #324]	@ (158 <Backend_StateLog+0x158>)
  14:	4d51      	ldr	r5, [pc, #324]	@ (15c <Backend_StateLog+0x15c>)
  16:	f44f 73b7 	mov.w	r3, #366	@ 0x16e
  1a:	4680      	mov	r8, r0
  1c:	2001      	movs	r0, #1
  1e:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			1e: R_ARM_THM_CALL	SilverStarAssert_Check
  22:	f8d9 3000 	ldr.w	r3, [r9]
  26:	f44f 72a7 	mov.w	r2, #334	@ 0x14e
  2a:	9200      	str	r2, [sp, #0]
  2c:	1c58      	adds	r0, r3, #1
  2e:	4622      	mov	r2, r4
  30:	ac02      	add	r4, sp, #8
  32:	4b48      	ldr	r3, [pc, #288]	@ (154 <Backend_StateLog+0x154>)
  34:	f8c9 0000 	str.w	r0, [r9]
  38:	2104      	movs	r1, #4
  3a:	4620      	mov	r0, r4
  3c:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			3c: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  40:	227d      	movs	r2, #125	@ 0x7d
  42:	2100      	movs	r1, #0
  44:	f10d 001b 	add.w	r0, sp, #27
  48:	f7ff fffe 	bl	0 <memset>
			48: R_ARM_THM_CALL	memset
  4c:	f8d9 3000 	ldr.w	r3, [r9]
  50:	6023      	str	r3, [r4, #0]
  52:	f8d6 33d4 	ldr.w	r3, [r6, #980]	@ 0x3d4
  56:	682a      	ldr	r2, [r5, #0]
  58:	6063      	str	r3, [r4, #4]
  5a:	f8d6 33d0 	ldr.w	r3, [r6, #976]	@ 0x3d0
  5e:	60a3      	str	r3, [r4, #8]
  60:	60e2      	str	r2, [r4, #12]
  62:	4b3f      	ldr	r3, [pc, #252]	@ (160 <Backend_StateLog+0x160>)
  64:	f44f 7281 	mov.w	r2, #258	@ 0x102
  68:	8222      	strh	r2, [r4, #16]
  6a:	2203      	movs	r2, #3
  6c:	e9d6 01f2 	ldrd	r0, r1, [r6, #968]	@ 0x3c8
  70:	681b      	ldr	r3, [r3, #0]
  72:	74a2      	strb	r2, [r4, #18]
  74:	220f      	movs	r2, #15
  76:	f7ff fffe 	bl	0 <SystemNavigationHealth_OverallGet>
			76: R_ARM_THM_CALL	SystemNavigationHealth_OverallGet
  7a:	74e0      	strb	r0, [r4, #19]
  7c:	e896 0007 	ldmia.w	r6, {r0, r1, r2}
  80:	f106 0a0c 	add.w	sl, r6, #12
  84:	f10d 0b1c 	add.w	fp, sp, #28
  88:	e88b 0007 	stmia.w	fp, {r0, r1, r2}
  8c:	e89a 0007 	ldmia.w	sl, {r0, r1, r2}
  90:	f106 0318 	add.w	r3, r6, #24
  94:	f10d 0a28 	add.w	sl, sp, #40	@ 0x28
  98:	e88a 0007 	stmia.w	sl, {r0, r1, r2}
  9c:	cb0f      	ldmia	r3, {r0, r1, r2, r3}
  9e:	f10d 0a34 	add.w	sl, sp, #52	@ 0x34
  a2:	e88a 000f 	stmia.w	sl, {r0, r1, r2, r3}
  a6:	f106 0328 	add.w	r3, r6, #40	@ 0x28
  aa:	e893 0007 	ldmia.w	r3, {r0, r1, r2}
  ae:	ab11      	add	r3, sp, #68	@ 0x44
  b0:	e883 0007 	stmia.w	r3, {r0, r1, r2}
  b4:	f106 0334 	add.w	r3, r6, #52	@ 0x34
  b8:	e893 0007 	ldmia.w	r3, {r0, r1, r2}
  bc:	ab14      	add	r3, sp, #80	@ 0x50
  be:	e883 0007 	stmia.w	r3, {r0, r1, r2}
  c2:	46b6      	mov	lr, r6
  c4:	f10d 0c5c 	add.w	ip, sp, #92	@ 0x5c
  c8:	af26      	add	r7, sp, #152	@ 0x98
  ca:	f85e 3f40 	ldr.w	r3, [lr, #64]!
  ce:	f84c 3b04 	str.w	r3, [ip], #4
  d2:	4567      	cmp	r7, ip
  d4:	d1f9      	bne.n	ca <Backend_StateLog+0xca>
  d6:	e9d6 01f2 	ldrd	r0, r1, [r6, #968]	@ 0x3c8
  da:	4622      	mov	r2, r4
  dc:	f1b8 0f00 	cmp.w	r8, #0
  e0:	d034      	beq.n	14c <Backend_StateLog+0x14c>
  e2:	f7ff fffe 	bl	0 <LoggerBus_Eskf15InitialStatePush>
			e2: R_ARM_THM_CALL	LoggerBus_Eskf15InitialStatePush
  e6:	b118      	cbz	r0, f0 <Backend_StateLog+0xf0>
  e8:	4a1e      	ldr	r2, [pc, #120]	@ (164 <Backend_StateLog+0x164>)
  ea:	6813      	ldr	r3, [r2, #0]
  ec:	3301      	adds	r3, #1
  ee:	6013      	str	r3, [r2, #0]
  f0:	2402      	movs	r4, #2
  f2:	f44f 73b1 	mov.w	r3, #354	@ 0x162
  f6:	4621      	mov	r1, r4
  f8:	4a16      	ldr	r2, [pc, #88]	@ (154 <Backend_StateLog+0x154>)
  fa:	9400      	str	r4, [sp, #0]
  fc:	2001      	movs	r0, #1
  fe:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			fe: R_ARM_THM_CALL	SilverStarAssert_Check
 102:	227e      	movs	r2, #126	@ 0x7e
 104:	2100      	movs	r1, #0
 106:	f10d 00aa 	add.w	r0, sp, #170	@ 0xaa
 10a:	f7ff fffe 	bl	0 <memset>
			10a: R_ARM_THM_CALL	memset
 10e:	f8d9 3000 	ldr.w	r3, [r9]
 112:	9326      	str	r3, [sp, #152]	@ 0x98
 114:	f8d6 33d4 	ldr.w	r3, [r6, #980]	@ 0x3d4
 118:	9327      	str	r3, [sp, #156]	@ 0x9c
 11a:	f8d6 33d0 	ldr.w	r3, [r6, #976]	@ 0x3d0
 11e:	682d      	ldr	r5, [r5, #0]
 120:	f88d 40a8 	strb.w	r4, [sp, #168]	@ 0xa8
 124:	9328      	str	r3, [sp, #160]	@ 0xa0
 126:	f088 0401 	eor.w	r4, r8, #1
 12a:	e9d6 01f2 	ldrd	r0, r1, [r6, #968]	@ 0x3c8
 12e:	4b0e      	ldr	r3, [pc, #56]	@ (168 <Backend_StateLog+0x168>)
 130:	9529      	str	r5, [sp, #164]	@ 0xa4
 132:	463a      	mov	r2, r7
 134:	f88d 40a9 	strb.w	r4, [sp, #169]	@ 0xa9
 138:	f7ff fffe 	bl	0 <LoggerBus_Eskf15CovariancePush>
			138: R_ARM_THM_CALL	LoggerBus_Eskf15CovariancePush
 13c:	b118      	cbz	r0, 146 <Backend_StateLog+0x146>
 13e:	4a09      	ldr	r2, [pc, #36]	@ (164 <Backend_StateLog+0x164>)
 140:	6813      	ldr	r3, [r2, #0]
 142:	3301      	adds	r3, #1
 144:	6013      	str	r3, [r2, #0]
 146:	b04b      	add	sp, #300	@ 0x12c
 148:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 14c:	f7ff fffe 	bl	0 <LoggerBus_Eskf15StatePush>
			14c: R_ARM_THM_CALL	LoggerBus_Eskf15StatePush
 150:	e7c9      	b.n	e6 <Backend_StateLog+0xe6>
 152:	bf00      	nop
	...
			154: R_ARM_ABS32	.rodata.Backend_StateLog.str1.4
			158: R_ARM_ABS32	.bss.s_state
			15c: R_ARM_ABS32	.bss.s_calibration_generation
			160: R_ARM_ABS32	.bss.s_imu_quality_flags
			164: R_ARM_ABS32	.bss.s_log_failures
 168:	00000040 	.word	0x00000040
			168: R_ARM_ABS32	.bss.s_state
 16c:	00000000 	.word	0x00000000
			16c: R_ARM_ABS32	.bss.s_snapshot_id

Disassembly of section .text.Backend_EventApply:

00000000 <Backend_EventApply>:
   0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
   4:	b0bd      	sub	sp, #244	@ 0xf4
   6:	f44f 733d 	mov.w	r3, #756	@ 0x2f4
   a:	9300      	str	r3, [sp, #0]
   c:	460c      	mov	r4, r1
   e:	4bb6      	ldr	r3, [pc, #728]	@ (2e8 <Backend_EventApply+0x2e8>)
  10:	f8df 82ec 	ldr.w	r8, [pc, #748]	@ 300 <Backend_EventApply+0x300>
  14:	2108      	movs	r1, #8
  16:	4617      	mov	r7, r2
  18:	2202      	movs	r2, #2
  1a:	4605      	mov	r5, r0
  1c:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			1c: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  20:	f240 22f5 	movw	r2, #757	@ 0x2f5
  24:	4bb0      	ldr	r3, [pc, #704]	@ (2e8 <Backend_EventApply+0x2e8>)
  26:	9200      	str	r2, [sp, #0]
  28:	2108      	movs	r1, #8
  2a:	2202      	movs	r2, #2
  2c:	4620      	mov	r0, r4
  2e:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			2e: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  32:	f8d8 33d4 	ldr.w	r3, [r8, #980]	@ 0x3d4
  36:	61ab      	str	r3, [r5, #24]
  38:	7f2b      	ldrb	r3, [r5, #28]
  3a:	2b03      	cmp	r3, #3
  3c:	d803      	bhi.n	46 <Backend_EventApply+0x46>
  3e:	2300      	movs	r3, #0
  40:	632b      	str	r3, [r5, #48]	@ 0x30
  42:	636b      	str	r3, [r5, #52]	@ 0x34
  44:	63ab      	str	r3, [r5, #56]	@ 0x38
  46:	4aa9      	ldr	r2, [pc, #676]	@ (2ec <Backend_EventApply+0x2ec>)
  48:	4ea9      	ldr	r6, [pc, #676]	@ (2f0 <Backend_EventApply+0x2f0>)
  4a:	ca07      	ldmia	r2, {r0, r1, r2}
  4c:	f105 033c 	add.w	r3, r5, #60	@ 0x3c
  50:	e883 0007 	stmia.w	r3, {r0, r1, r2}
  54:	2220      	movs	r2, #32
  56:	2100      	movs	r1, #0
  58:	a80a      	add	r0, sp, #40	@ 0x28
  5a:	f7ff fffe 	bl	0 <memset>
			5a: R_ARM_THM_CALL	memset
  5e:	f04f 537e 	mov.w	r3, #1065353216	@ 0x3f800000
  62:	930b      	str	r3, [sp, #44]	@ 0x2c
  64:	6833      	ldr	r3, [r6, #0]
  66:	3301      	adds	r3, #1
  68:	6033      	str	r3, [r6, #0]
  6a:	f7ff fffe 	bl	0 <SystemTime_GetMonotonicUs>
			6a: R_ARM_THM_CALL	SystemTime_GetMonotonicUs
  6e:	e9c6 0102 	strd	r0, r1, [r6, #8]
  72:	6833      	ldr	r3, [r6, #0]
  74:	f894 9075 	ldrb.w	r9, [r4, #117]	@ 0x75
  78:	3301      	adds	r3, #1
  7a:	6033      	str	r3, [r6, #0]
  7c:	f1b9 0f00 	cmp.w	r9, #0
  80:	f000 824c 	beq.w	51c <Backend_EventApply+0x51c>
  84:	4b9b      	ldr	r3, [pc, #620]	@ (2f4 <Backend_EventApply+0x2f4>)
  86:	9305      	str	r3, [sp, #20]
  88:	e9d6 2302 	ldrd	r2, r3, [r6, #8]
  8c:	f884 9075 	strb.w	r9, [r4, #117]	@ 0x75
  90:	e9cd 2302 	strd	r2, r3, [sp, #8]
  94:	f7ff fffe 	bl	0 <SystemTime_GetMonotonicUs>
			94: R_ARM_THM_CALL	SystemTime_GetMonotonicUs
  98:	9b02      	ldr	r3, [sp, #8]
  9a:	4682      	mov	sl, r0
  9c:	459a      	cmp	sl, r3
  9e:	9b03      	ldr	r3, [sp, #12]
  a0:	468b      	mov	fp, r1
  a2:	eb7b 0003 	sbcs.w	r0, fp, r3
  a6:	7f29      	ldrb	r1, [r5, #28]
  a8:	f080 81df 	bcs.w	46a <Backend_EventApply+0x46a>
  ac:	6833      	ldr	r3, [r6, #0]
  ae:	3301      	adds	r3, #1
  b0:	6033      	str	r3, [r6, #0]
  b2:	e9c6 ab04 	strd	sl, fp, [r6, #16]
  b6:	2300      	movs	r3, #0
  b8:	6333      	str	r3, [r6, #48]	@ 0x30
  ba:	f886 1040 	strb.w	r1, [r6, #64]	@ 0x40
  be:	6b73      	ldr	r3, [r6, #52]	@ 0x34
  c0:	6bf3      	ldr	r3, [r6, #60]	@ 0x3c
  c2:	3301      	adds	r3, #1
  c4:	d002      	beq.n	cc <Backend_EventApply+0xcc>
  c6:	6bf3      	ldr	r3, [r6, #60]	@ 0x3c
  c8:	3301      	adds	r3, #1
  ca:	63f3      	str	r3, [r6, #60]	@ 0x3c
  cc:	6833      	ldr	r3, [r6, #0]
  ce:	3301      	adds	r3, #1
  d0:	6033      	str	r3, [r6, #0]
  d2:	f240 13e7 	movw	r3, #487	@ 0x1e7
  d6:	9300      	str	r3, [sp, #0]
  d8:	2202      	movs	r2, #2
  da:	4b83      	ldr	r3, [pc, #524]	@ (2e8 <Backend_EventApply+0x2e8>)
  dc:	2108      	movs	r1, #8
  de:	4628      	mov	r0, r5
  e0:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			e0: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  e4:	f44f 73f4 	mov.w	r3, #488	@ 0x1e8
  e8:	9300      	str	r3, [sp, #0]
  ea:	2202      	movs	r2, #2
  ec:	4b7e      	ldr	r3, [pc, #504]	@ (2e8 <Backend_EventApply+0x2e8>)
  ee:	2104      	movs	r1, #4
  f0:	a80a      	add	r0, sp, #40	@ 0x28
  f2:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			f2: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  f6:	9b05      	ldr	r3, [sp, #20]
  f8:	4a7f      	ldr	r2, [pc, #508]	@ (2f8 <Backend_EventApply+0x2f8>)
  fa:	6819      	ldr	r1, [r3, #0]
  fc:	f8d8 33d4 	ldr.w	r3, [r8, #980]	@ 0x3d4
 100:	6263      	str	r3, [r4, #36]	@ 0x24
 102:	6813      	ldr	r3, [r2, #0]
 104:	3301      	adds	r3, #1
 106:	6223      	str	r3, [r4, #32]
 108:	6013      	str	r3, [r2, #0]
 10a:	696b      	ldr	r3, [r5, #20]
 10c:	e9c4 310a 	strd	r3, r1, [r4, #40]	@ 0x28
 110:	8baa      	ldrh	r2, [r5, #28]
 112:	f895 e01d 	ldrb.w	lr, [r5, #29]
 116:	8622      	strh	r2, [r4, #48]	@ 0x30
 118:	e9d5 ab00 	ldrd	sl, fp, [r5]
 11c:	2300      	movs	r3, #0
 11e:	e9cd 331c 	strd	r3, r3, [sp, #112]	@ 0x70
 122:	692b      	ldr	r3, [r5, #16]
 124:	f894 1074 	ldrb.w	r1, [r4, #116]	@ 0x74
 128:	e9c4 ab04 	strd	sl, fp, [r4, #16]
 12c:	e9d5 ab02 	ldrd	sl, fp, [r5, #8]
 130:	e9c4 ab02 	strd	sl, fp, [r4, #8]
 134:	e9d8 abf2 	ldrd	sl, fp, [r8, #968]	@ 0x3c8
 138:	6723      	str	r3, [r4, #112]	@ 0x70
 13a:	078b      	lsls	r3, r1, #30
 13c:	e9c4 ab06 	strd	sl, fp, [r4, #24]
 140:	d503      	bpl.n	14a <Backend_EventApply+0x14a>
 142:	f412 4f7f 	tst.w	r2, #65280	@ 0xff00
 146:	f040 80c8 	bne.w	2da <Backend_EventApply+0x2da>
 14a:	f894 2075 	ldrb.w	r2, [r4, #117]	@ 0x75
 14e:	f04f 0c00 	mov.w	ip, #0
 152:	3210      	adds	r2, #16
 154:	b2d2      	uxtb	r2, r2
 156:	4663      	mov	r3, ip
 158:	a90c      	add	r1, sp, #48	@ 0x30
 15a:	c903      	ldmia	r1, {r0, r1}
 15c:	9e0a      	ldr	r6, [sp, #40]	@ 0x28
 15e:	ed9d 7a0b 	vldr	s14, [sp, #44]	@ 0x2c
 162:	6566      	str	r6, [r4, #84]	@ 0x54
 164:	9619      	str	r6, [sp, #100]	@ 0x64
 166:	f104 063c 	add.w	r6, r4, #60	@ 0x3c
 16a:	f884 c032 	strb.w	ip, [r4, #50]	@ 0x32
 16e:	f884 2033 	strb.w	r2, [r4, #51]	@ 0x33
 172:	ed84 7a18 	vstr	s14, [r4, #96]	@ 0x60
 176:	e886 0003 	stmia.w	r6, {r0, r1}
 17a:	a90e      	add	r1, sp, #56	@ 0x38
 17c:	c903      	ldmia	r1, {r0, r1}
 17e:	f104 094c 	add.w	r9, r4, #76	@ 0x4c
 182:	e889 0003 	stmia.w	r9, {r0, r1}
 186:	f105 0120 	add.w	r1, r5, #32
 18a:	c903      	ldmia	r1, {r0, r1}
 18c:	f104 0a34 	add.w	sl, r4, #52	@ 0x34
 190:	e88a 0003 	stmia.w	sl, {r0, r1}
 194:	6929      	ldr	r1, [r5, #16]
 196:	9118      	str	r1, [sp, #96]	@ 0x60
 198:	6969      	ldr	r1, [r5, #20]
 19a:	f88d 1071 	strb.w	r1, [sp, #113]	@ 0x71
 19e:	e9d5 0102 	ldrd	r0, r1, [r5, #8]
 1a2:	edd4 7a16 	vldr	s15, [r4, #88]	@ 0x58
 1a6:	edd4 6a17 	vldr	s13, [r4, #92]	@ 0x5c
 1aa:	e9cd 0112 	strd	r0, r1, [sp, #72]	@ 0x48
 1ae:	e9d5 0100 	ldrd	r0, r1, [r5]
 1b2:	ee67 7aa6 	vmul.f32	s15, s15, s13
 1b6:	e9cd 0114 	strd	r0, r1, [sp, #80]	@ 0x50
 1ba:	e9d8 01f2 	ldrd	r0, r1, [r8, #968]	@ 0x3c8
 1be:	ee67 7a87 	vmul.f32	s15, s15, s14
 1c2:	e9cd 0116 	strd	r0, r1, [sp, #88]	@ 0x58
 1c6:	edcd 7a1a 	vstr	s15, [sp, #104]	@ 0x68
 1ca:	f88d e06c 	strb.w	lr, [sp, #108]	@ 0x6c
 1ce:	f88d c06d 	strb.w	ip, [sp, #109]	@ 0x6d
 1d2:	b16b      	cbz	r3, 1f0 <Backend_EventApply+0x1f0>
 1d4:	ed9d 7a10 	vldr	s14, [sp, #64]	@ 0x40
 1d8:	eeb5 7ac0 	vcmpe.f32	s14, #0.0
 1dc:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 1e0:	f340 8188 	ble.w	4f4 <Backend_EventApply+0x4f4>
 1e4:	f89d 3045 	ldrb.w	r3, [sp, #69]	@ 0x45
 1e8:	2b01      	cmp	r3, #1
 1ea:	bf8c      	ite	hi
 1ec:	2300      	movhi	r3, #0
 1ee:	2301      	movls	r3, #1
 1f0:	eeb7 7a00 	vmov.f32	s14, #112	@ 0x3f800000  1.0
 1f4:	eef4 7ac7 	vcmpe.f32	s15, s14
 1f8:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 1fc:	f88d 306e 	strb.w	r3, [sp, #110]	@ 0x6e
 200:	7f28      	ldrb	r0, [r5, #28]
 202:	f88d 2070 	strb.w	r2, [sp, #112]	@ 0x70
 206:	bfcc      	ite	gt
 208:	2301      	movgt	r3, #1
 20a:	2300      	movle	r3, #0
 20c:	a912      	add	r1, sp, #72	@ 0x48
 20e:	f88d 306f 	strb.w	r3, [sp, #111]	@ 0x6f
 212:	f7ff fffe 	bl	0 <SystemNavigationHealth_Observe>
			212: R_ARM_THM_CALL	SystemNavigationHealth_Observe
 216:	b118      	cbz	r0, 220 <Backend_EventApply+0x220>
 218:	4a38      	ldr	r2, [pc, #224]	@ (2fc <Backend_EventApply+0x2fc>)
 21a:	6813      	ldr	r3, [r2, #0]
 21c:	3301      	adds	r3, #1
 21e:	6013      	str	r3, [r2, #0]
 220:	f894 b033 	ldrb.w	fp, [r4, #51]	@ 0x33
 224:	f44f 73dc 	mov.w	r3, #440	@ 0x1b8
 228:	f1bb 0f05 	cmp.w	fp, #5
 22c:	9300      	str	r3, [sp, #0]
 22e:	f04f 0202 	mov.w	r2, #2
 232:	4b2d      	ldr	r3, [pc, #180]	@ (2e8 <Backend_EventApply+0x2e8>)
 234:	f894 5030 	ldrb.w	r5, [r4, #48]	@ 0x30
 238:	f04f 0108 	mov.w	r1, #8
 23c:	4638      	mov	r0, r7
 23e:	bf28      	it	cs
 240:	f04f 0b03 	movcs.w	fp, #3
 244:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			244: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
 248:	2102      	movs	r1, #2
 24a:	9100      	str	r1, [sp, #0]
 24c:	f894 0030 	ldrb.w	r0, [r4, #48]	@ 0x30
 250:	4a25      	ldr	r2, [pc, #148]	@ (2e8 <Backend_EventApply+0x2e8>)
 252:	2804      	cmp	r0, #4
 254:	bf8c      	ite	hi
 256:	2000      	movhi	r0, #0
 258:	2001      	movls	r0, #1
 25a:	f240 13b9 	movw	r3, #441	@ 0x1b9
 25e:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			25e: R_ARM_THM_CALL	SilverStarAssert_Check
 262:	f894 3030 	ldrb.w	r3, [r4, #48]	@ 0x30
 266:	f8d7 2184 	ldr.w	r2, [r7, #388]	@ 0x184
 26a:	f8dd e068 	ldr.w	lr, [sp, #104]	@ 0x68
 26e:	f89d 106e 	ldrb.w	r1, [sp, #110]	@ 0x6e
 272:	2b03      	cmp	r3, #3
 274:	d870      	bhi.n	358 <Backend_EventApply+0x358>
 276:	2b01      	cmp	r3, #1
 278:	bf8c      	ite	hi
 27a:	f04f 0c02 	movhi.w	ip, #2
 27e:	f04f 0c01 	movls.w	ip, #1
 282:	ea4c 0202 	orr.w	r2, ip, r2
 286:	ea4f 0045 	mov.w	r0, r5, lsl #1
 28a:	f005 0501 	and.w	r5, r5, #1
 28e:	f8c7 2184 	str.w	r2, [r7, #388]	@ 0x184
 292:	f000 0002 	and.w	r0, r0, #2
 296:	f1c5 0502 	rsb	r5, r5, #2
 29a:	f100 0041 	add.w	r0, r0, #65	@ 0x41
 29e:	b2ed      	uxtb	r5, r5
 2a0:	f104 0240 	add.w	r2, r4, #64	@ 0x40
 2a4:	edd4 7a0f 	vldr	s15, [r4, #60]	@ 0x3c
 2a8:	f8d2 c00c 	ldr.w	ip, [r2, #12]
 2ac:	eb07 0080 	add.w	r0, r7, r0, lsl #2
 2b0:	eb06 0585 	add.w	r5, r6, r5, lsl #2
 2b4:	d926      	bls.n	304 <Backend_EventApply+0x304>
 2b6:	4295      	cmp	r5, r2
 2b8:	edc0 7a03 	vstr	s15, [r0, #12]
 2bc:	f8c0 c028 	str.w	ip, [r0, #40]	@ 0x28
 2c0:	d031      	beq.n	326 <Backend_EventApply+0x326>
 2c2:	ecf2 7a01 	vldmia	r2!, {s15}
 2c6:	3004      	adds	r0, #4
 2c8:	f8d2 c00c 	ldr.w	ip, [r2, #12]
 2cc:	f8c0 c028 	str.w	ip, [r0, #40]	@ 0x28
 2d0:	4295      	cmp	r5, r2
 2d2:	edc0 7a03 	vstr	s15, [r0, #12]
 2d6:	d1f4      	bne.n	2c2 <Backend_EventApply+0x2c2>
 2d8:	e025      	b.n	326 <Backend_EventApply+0x326>
 2da:	f04f 0c01 	mov.w	ip, #1
 2de:	f89d 2045 	ldrb.w	r2, [sp, #69]	@ 0x45
 2e2:	4663      	mov	r3, ip
 2e4:	e738      	b.n	158 <Backend_EventApply+0x158>
 2e6:	bf00      	nop
	...
			2e8: R_ARM_ABS32	.rodata.Backend_StateLog.str1.4
			2ec: R_ARM_ABS32	.bss.s_current_endpoint_rate
			2f0: R_ARM_ABS32	.bss.s_eskf_replay_timing
			2f4: R_ARM_ABS32	.bss.s_calibration_generation
			2f8: R_ARM_ABS32	.bss.s_operation
			2fc: R_ARM_ABS32	.bss.s_log_failures
			300: R_ARM_ABS32	.bss.s_state
 304:	4295      	cmp	r5, r2
 306:	edc0 7a00 	vstr	s15, [r0]
 30a:	f8c0 c01c 	str.w	ip, [r0, #28]
 30e:	d00a      	beq.n	326 <Backend_EventApply+0x326>
 310:	ecf2 7a01 	vldmia	r2!, {s15}
 314:	3004      	adds	r0, #4
 316:	f8d2 c00c 	ldr.w	ip, [r2, #12]
 31a:	f8c0 c01c 	str.w	ip, [r0, #28]
 31e:	4295      	cmp	r5, r2
 320:	edc0 7a00 	vstr	s15, [r0]
 324:	d1f4      	bne.n	310 <Backend_EventApply+0x310>
 326:	2b01      	cmp	r3, #1
 328:	6d62      	ldr	r2, [r4, #84]	@ 0x54
 32a:	f240 80e5 	bls.w	4f8 <Backend_EventApply+0x4f8>
 32e:	2b02      	cmp	r3, #2
 330:	f8c7 2140 	str.w	r2, [r7, #320]	@ 0x140
 334:	f8c7 e14c 	str.w	lr, [r7, #332]	@ 0x14c
 338:	d003      	beq.n	342 <Backend_EventApply+0x342>
 33a:	f897 31af 	ldrb.w	r3, [r7, #431]	@ 0x1af
 33e:	455b      	cmp	r3, fp
 340:	d901      	bls.n	346 <Backend_EventApply+0x346>
 342:	f887 b1af 	strb.w	fp, [r7, #431]	@ 0x1af
 346:	2900      	cmp	r1, #0
 348:	f000 81aa 	beq.w	6a0 <Backend_EventApply+0x6a0>
 34c:	f8d7 3168 	ldr.w	r3, [r7, #360]	@ 0x168
 350:	3301      	adds	r3, #1
 352:	f8c7 3168 	str.w	r3, [r7, #360]	@ 0x168
 356:	e018      	b.n	38a <Backend_EventApply+0x38a>
 358:	6ce3      	ldr	r3, [r4, #76]	@ 0x4c
 35a:	6be0      	ldr	r0, [r4, #60]	@ 0x3c
 35c:	f887 b1b0 	strb.w	fp, [r7, #432]	@ 0x1b0
 360:	f042 0204 	orr.w	r2, r2, #4
 364:	f8c7 3138 	str.w	r3, [r7, #312]	@ 0x138
 368:	6d63      	ldr	r3, [r4, #84]	@ 0x54
 36a:	f8c7 2184 	str.w	r2, [r7, #388]	@ 0x184
 36e:	f8c7 011c 	str.w	r0, [r7, #284]	@ 0x11c
 372:	f8c7 e150 	str.w	lr, [r7, #336]	@ 0x150
 376:	f8c7 3144 	str.w	r3, [r7, #324]	@ 0x144
 37a:	2900      	cmp	r1, #0
 37c:	f040 80b4 	bne.w	4e8 <Backend_EventApply+0x4e8>
 380:	f8d7 3178 	ldr.w	r3, [r7, #376]	@ 0x178
 384:	3301      	adds	r3, #1
 386:	f8c7 3178 	str.w	r3, [r7, #376]	@ 0x178
 38a:	f44f 7395 	mov.w	r3, #298	@ 0x12a
 38e:	9300      	str	r3, [sp, #0]
 390:	2202      	movs	r2, #2
 392:	4b6d      	ldr	r3, [pc, #436]	@ (548 <Backend_EventApply+0x548>)
 394:	2108      	movs	r1, #8
 396:	4620      	mov	r0, r4
 398:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			398: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
 39c:	2102      	movs	r1, #2
 39e:	9100      	str	r1, [sp, #0]
 3a0:	f894 0030 	ldrb.w	r0, [r4, #48]	@ 0x30
 3a4:	4a68      	ldr	r2, [pc, #416]	@ (548 <Backend_EventApply+0x548>)
 3a6:	2804      	cmp	r0, #4
 3a8:	bf8c      	ite	hi
 3aa:	2000      	movhi	r0, #0
 3ac:	2001      	movls	r0, #1
 3ae:	f240 132b 	movw	r3, #299	@ 0x12b
 3b2:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			3b2: R_ARM_THM_CALL	SilverStarAssert_Check
 3b6:	ed94 7b00 	vldr	d7, [r4]
 3ba:	ed8d 7b1e 	vstr	d7, [sp, #120]	@ 0x78
 3be:	ed94 7b02 	vldr	d7, [r4, #8]
 3c2:	6d63      	ldr	r3, [r4, #84]	@ 0x54
 3c4:	9333      	str	r3, [sp, #204]	@ 0xcc
 3c6:	ed8d 7b20 	vstr	d7, [sp, #128]	@ 0x80
 3ca:	6da3      	ldr	r3, [r4, #88]	@ 0x58
 3cc:	9334      	str	r3, [sp, #208]	@ 0xd0
 3ce:	ed94 7b04 	vldr	d7, [r4, #16]
 3d2:	6de3      	ldr	r3, [r4, #92]	@ 0x5c
 3d4:	9335      	str	r3, [sp, #212]	@ 0xd4
 3d6:	6e23      	ldr	r3, [r4, #96]	@ 0x60
 3d8:	9336      	str	r3, [sp, #216]	@ 0xd8
 3da:	ed8d 7b22 	vstr	d7, [sp, #136]	@ 0x88
 3de:	6a63      	ldr	r3, [r4, #36]	@ 0x24
 3e0:	9327      	str	r3, [sp, #156]	@ 0x9c
 3e2:	ed94 7b06 	vldr	d7, [r4, #24]
 3e6:	6aa3      	ldr	r3, [r4, #40]	@ 0x28
 3e8:	9328      	str	r3, [sp, #160]	@ 0xa0
 3ea:	6ae3      	ldr	r3, [r4, #44]	@ 0x2c
 3ec:	9329      	str	r3, [sp, #164]	@ 0xa4
 3ee:	ed8d 7b24 	vstr	d7, [sp, #144]	@ 0x90
 3f2:	6a23      	ldr	r3, [r4, #32]
 3f4:	9326      	str	r3, [sp, #152]	@ 0x98
 3f6:	ed94 7b1a 	vldr	d7, [r4, #104]	@ 0x68
 3fa:	6b23      	ldr	r3, [r4, #48]	@ 0x30
 3fc:	f894 0075 	ldrb.w	r0, [r4, #117]	@ 0x75
 400:	932a      	str	r3, [sp, #168]	@ 0xa8
 402:	2100      	movs	r1, #0
 404:	f894 3074 	ldrb.w	r3, [r4, #116]	@ 0x74
 408:	f88d 10e8 	strb.w	r1, [sp, #232]	@ 0xe8
 40c:	f88d 30e9 	strb.w	r3, [sp, #233]	@ 0xe9
 410:	ed8d 7b38 	vstr	d7, [sp, #224]	@ 0xe0
 414:	f88d 00ea 	strb.w	r0, [sp, #234]	@ 0xea
 418:	f88d 10eb 	strb.w	r1, [sp, #235]	@ 0xeb
 41c:	6f21      	ldr	r1, [r4, #112]	@ 0x70
 41e:	913b      	str	r1, [sp, #236]	@ 0xec
 420:	e89a 0003 	ldmia.w	sl, {r0, r1}
 424:	f10d 0eac 	add.w	lr, sp, #172	@ 0xac
 428:	e88e 0003 	stmia.w	lr, {r0, r1}
 42c:	e896 0003 	ldmia.w	r6, {r0, r1}
 430:	f10d 0cb4 	add.w	ip, sp, #180	@ 0xb4
 434:	f104 0744 	add.w	r7, r4, #68	@ 0x44
 438:	e88c 0003 	stmia.w	ip, {r0, r1}
 43c:	e897 0003 	ldmia.w	r7, {r0, r1}
 440:	ad2f      	add	r5, sp, #188	@ 0xbc
 442:	e885 0003 	stmia.w	r5, {r0, r1}
 446:	e899 0003 	ldmia.w	r9, {r0, r1}
 44a:	ab31      	add	r3, sp, #196	@ 0xc4
 44c:	e883 0003 	stmia.w	r3, {r0, r1}
 450:	aa1e      	add	r2, sp, #120	@ 0x78
 452:	e9d8 01f2 	ldrd	r0, r1, [r8, #968]	@ 0x3c8
 456:	f7ff fffe 	bl	0 <LoggerBus_Eskf15MeasurementPush>
			456: R_ARM_THM_CALL	LoggerBus_Eskf15MeasurementPush
 45a:	b118      	cbz	r0, 464 <Backend_EventApply+0x464>
 45c:	4a3b      	ldr	r2, [pc, #236]	@ (54c <Backend_EventApply+0x54c>)
 45e:	6813      	ldr	r3, [r2, #0]
 460:	3301      	adds	r3, #1
 462:	6013      	str	r3, [r2, #0]
 464:	b03d      	add	sp, #244	@ 0xf4
 466:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 46a:	9b02      	ldr	r3, [sp, #8]
 46c:	ebba 0203 	subs.w	r2, sl, r3
 470:	9b03      	ldr	r3, [sp, #12]
 472:	eb6b 0303 	sbc.w	r3, fp, r3
 476:	f04f 30ff 	mov.w	r0, #4294967295
 47a:	bb23      	cbnz	r3, 4c6 <Backend_EventApply+0x4c6>
 47c:	6833      	ldr	r3, [r6, #0]
 47e:	3301      	adds	r3, #1
 480:	6033      	str	r3, [r6, #0]
 482:	e9c6 ab04 	strd	sl, fp, [r6, #16]
 486:	6332      	str	r2, [r6, #48]	@ 0x30
 488:	f886 1040 	strb.w	r1, [r6, #64]	@ 0x40
 48c:	6b73      	ldr	r3, [r6, #52]	@ 0x34
 48e:	4293      	cmp	r3, r2
 490:	d204      	bcs.n	49c <Backend_EventApply+0x49c>
 492:	6372      	str	r2, [r6, #52]	@ 0x34
 494:	e9c6 ab06 	strd	sl, fp, [r6, #24]
 498:	f886 1041 	strb.w	r1, [r6, #65]	@ 0x41
 49c:	f644 631f 	movw	r3, #19999	@ 0x4e1f
 4a0:	429a      	cmp	r2, r3
 4a2:	f67f ae0d 	bls.w	c0 <Backend_EventApply+0xc0>
 4a6:	6bb3      	ldr	r3, [r6, #56]	@ 0x38
 4a8:	3301      	adds	r3, #1
 4aa:	f43f ae09 	beq.w	c0 <Backend_EventApply+0xc0>
 4ae:	e9d6 2308 	ldrd	r2, r3, [r6, #32]
 4b2:	431a      	orrs	r2, r3
 4b4:	bf08      	it	eq
 4b6:	e9c6 ab08 	strdeq	sl, fp, [r6, #32]
 4ba:	e9c6 ab0a 	strd	sl, fp, [r6, #40]	@ 0x28
 4be:	6bb3      	ldr	r3, [r6, #56]	@ 0x38
 4c0:	3301      	adds	r3, #1
 4c2:	63b3      	str	r3, [r6, #56]	@ 0x38
 4c4:	e5fc      	b.n	c0 <Backend_EventApply+0xc0>
 4c6:	6833      	ldr	r3, [r6, #0]
 4c8:	3301      	adds	r3, #1
 4ca:	6033      	str	r3, [r6, #0]
 4cc:	e9c6 ab04 	strd	sl, fp, [r6, #16]
 4d0:	6330      	str	r0, [r6, #48]	@ 0x30
 4d2:	f886 1040 	strb.w	r1, [r6, #64]	@ 0x40
 4d6:	6b73      	ldr	r3, [r6, #52]	@ 0x34
 4d8:	3301      	adds	r3, #1
 4da:	d0e4      	beq.n	4a6 <Backend_EventApply+0x4a6>
 4dc:	6370      	str	r0, [r6, #52]	@ 0x34
 4de:	e9c6 ab06 	strd	sl, fp, [r6, #24]
 4e2:	f886 1041 	strb.w	r1, [r6, #65]	@ 0x41
 4e6:	e7de      	b.n	4a6 <Backend_EventApply+0x4a6>
 4e8:	f8d7 316c 	ldr.w	r3, [r7, #364]	@ 0x16c
 4ec:	3301      	adds	r3, #1
 4ee:	f8c7 316c 	str.w	r3, [r7, #364]	@ 0x16c
 4f2:	e74a      	b.n	38a <Backend_EventApply+0x38a>
 4f4:	2300      	movs	r3, #0
 4f6:	e67b      	b.n	1f0 <Backend_EventApply+0x1f0>
 4f8:	f8c7 213c 	str.w	r2, [r7, #316]	@ 0x13c
 4fc:	f8c7 e148 	str.w	lr, [r7, #328]	@ 0x148
 500:	2b00      	cmp	r3, #0
 502:	f040 80bc 	bne.w	67e <Backend_EventApply+0x67e>
 506:	f887 b1ae 	strb.w	fp, [r7, #430]	@ 0x1ae
 50a:	2900      	cmp	r1, #0
 50c:	f000 80ce 	beq.w	6ac <Backend_EventApply+0x6ac>
 510:	f8d7 3164 	ldr.w	r3, [r7, #356]	@ 0x164
 514:	3301      	adds	r3, #1
 516:	f8c7 3164 	str.w	r3, [r7, #356]	@ 0x164
 51a:	e736      	b.n	38a <Backend_EventApply+0x38a>
 51c:	4b0c      	ldr	r3, [pc, #48]	@ (550 <Backend_EventApply+0x550>)
 51e:	f893 9000 	ldrb.w	r9, [r3]
 522:	f1b9 0f00 	cmp.w	r9, #0
 526:	f040 80b6 	bne.w	696 <Backend_EventApply+0x696>
 52a:	4b0a      	ldr	r3, [pc, #40]	@ (554 <Backend_EventApply+0x554>)
 52c:	781b      	ldrb	r3, [r3, #0]
 52e:	2b00      	cmp	r3, #0
 530:	f000 80b1 	beq.w	696 <Backend_EventApply+0x696>
 534:	69aa      	ldr	r2, [r5, #24]
 536:	f8d8 33d4 	ldr.w	r3, [r8, #980]	@ 0x3d4
 53a:	429a      	cmp	r2, r3
 53c:	d00e      	beq.n	55c <Backend_EventApply+0x55c>
 53e:	4b06      	ldr	r3, [pc, #24]	@ (558 <Backend_EventApply+0x558>)
 540:	9305      	str	r3, [sp, #20]
 542:	f04f 0904 	mov.w	r9, #4
 546:	e59f      	b.n	88 <Backend_EventApply+0x88>
	...
			548: R_ARM_ABS32	.rodata.Backend_StateLog.str1.4
			54c: R_ARM_ABS32	.bss.s_log_failures
			550: R_ARM_ABS32	.bss.s_current_faulted
			554: R_ARM_ABS32	.bss.s_current_endpoint_valid
			558: R_ARM_ABS32	.bss.s_calibration_generation
 55c:	f7ff fffe 	bl	0 <SystemCalibration_GenerationGet>
			55c: R_ARM_THM_CALL	SystemCalibration_GenerationGet
 560:	4b5e      	ldr	r3, [pc, #376]	@ (6dc <Backend_EventApply+0x6dc>)
 562:	9305      	str	r3, [sp, #20]
 564:	681b      	ldr	r3, [r3, #0]
 566:	4298      	cmp	r0, r3
 568:	d1eb      	bne.n	542 <Backend_EventApply+0x542>
 56a:	7f2b      	ldrb	r3, [r5, #28]
 56c:	2b04      	cmp	r3, #4
 56e:	f200 808f 	bhi.w	690 <Backend_EventApply+0x690>
 572:	696a      	ldr	r2, [r5, #20]
 574:	2a03      	cmp	r2, #3
 576:	f200 808b 	bhi.w	690 <Backend_EventApply+0x690>
 57a:	2b04      	cmp	r3, #4
 57c:	f000 8085 	beq.w	68a <Backend_EventApply+0x68a>
 580:	e9d5 0e02 	ldrd	r0, lr, [r5, #8]
 584:	ea50 010e 	orrs.w	r1, r0, lr
 588:	f000 8082 	beq.w	690 <Backend_EventApply+0x690>
 58c:	f8d8 13c8 	ldr.w	r1, [r8, #968]	@ 0x3c8
 590:	9106      	str	r1, [sp, #24]
 592:	f8d8 13cc 	ldr.w	r1, [r8, #972]	@ 0x3cc
 596:	9107      	str	r1, [sp, #28]
 598:	9906      	ldr	r1, [sp, #24]
 59a:	9002      	str	r0, [sp, #8]
 59c:	4281      	cmp	r1, r0
 59e:	9907      	ldr	r1, [sp, #28]
 5a0:	eb71 010e 	sbcs.w	r1, r1, lr
 5a4:	d374      	bcc.n	690 <Backend_EventApply+0x690>
 5a6:	494e      	ldr	r1, [pc, #312]	@ (6e0 <Backend_EventApply+0x6e0>)
 5a8:	6808      	ldr	r0, [r1, #0]
 5aa:	9008      	str	r0, [sp, #32]
 5ac:	6848      	ldr	r0, [r1, #4]
 5ae:	9009      	str	r0, [sp, #36]	@ 0x24
 5b0:	9908      	ldr	r1, [sp, #32]
 5b2:	9802      	ldr	r0, [sp, #8]
 5b4:	4288      	cmp	r0, r1
 5b6:	9909      	ldr	r1, [sp, #36]	@ 0x24
 5b8:	eb7e 0101 	sbcs.w	r1, lr, r1
 5bc:	d3c1      	bcc.n	542 <Backend_EventApply+0x542>
 5be:	9906      	ldr	r1, [sp, #24]
 5c0:	ebb1 0c00 	subs.w	ip, r1, r0
 5c4:	4847      	ldr	r0, [pc, #284]	@ (6e4 <Backend_EventApply+0x6e4>)
 5c6:	9907      	ldr	r1, [sp, #28]
 5c8:	eb61 010e 	sbc.w	r1, r1, lr
 5cc:	4560      	cmp	r0, ip
 5ce:	f04f 0000 	mov.w	r0, #0
 5d2:	eb70 0101 	sbcs.w	r1, r0, r1
 5d6:	d37e      	bcc.n	6d6 <Backend_EventApply+0x6d6>
 5d8:	2b04      	cmp	r3, #4
 5da:	d06d      	beq.n	6b8 <Backend_EventApply+0x6b8>
 5dc:	4942      	ldr	r1, [pc, #264]	@ (6e8 <Backend_EventApply+0x6e8>)
 5de:	eb01 02c2 	add.w	r2, r1, r2, lsl #3
 5e2:	2101      	movs	r1, #1
 5e4:	fa01 f303 	lsl.w	r3, r1, r3
 5e8:	b2db      	uxtb	r3, r3
 5ea:	f892 c004 	ldrb.w	ip, [r2, #4]
 5ee:	6929      	ldr	r1, [r5, #16]
 5f0:	f1bc 0f00 	cmp.w	ip, #0
 5f4:	d005      	beq.n	602 <Backend_EventApply+0x602>
 5f6:	6810      	ldr	r0, [r2, #0]
 5f8:	4288      	cmp	r0, r1
 5fa:	d063      	beq.n	6c4 <Backend_EventApply+0x6c4>
 5fc:	1a08      	subs	r0, r1, r0
 5fe:	2800      	cmp	r0, #0
 600:	db5d      	blt.n	6be <Backend_EventApply+0x6be>
 602:	7113      	strb	r3, [r2, #4]
 604:	6011      	str	r1, [r2, #0]
 606:	e9d5 3200 	ldrd	r3, r2, [r5]
 60a:	ea53 0102 	orrs.w	r1, r3, r2
 60e:	d03f      	beq.n	690 <Backend_EventApply+0x690>
 610:	9902      	ldr	r1, [sp, #8]
 612:	4299      	cmp	r1, r3
 614:	eb7e 0102 	sbcs.w	r1, lr, r2
 618:	d33a      	bcc.n	690 <Backend_EventApply+0x690>
 61a:	9908      	ldr	r1, [sp, #32]
 61c:	428b      	cmp	r3, r1
 61e:	9909      	ldr	r1, [sp, #36]	@ 0x24
 620:	eb72 0101 	sbcs.w	r1, r2, r1
 624:	d38d      	bcc.n	542 <Backend_EventApply+0x542>
 626:	9906      	ldr	r1, [sp, #24]
 628:	482e      	ldr	r0, [pc, #184]	@ (6e4 <Backend_EventApply+0x6e4>)
 62a:	1acb      	subs	r3, r1, r3
 62c:	9907      	ldr	r1, [sp, #28]
 62e:	eb61 0202 	sbc.w	r2, r1, r2
 632:	2100      	movs	r1, #0
 634:	4298      	cmp	r0, r3
 636:	4191      	sbcs	r1, r2
 638:	d34d      	bcc.n	6d6 <Backend_EventApply+0x6d6>
 63a:	7f6b      	ldrb	r3, [r5, #29]
 63c:	9302      	str	r3, [sp, #8]
 63e:	2b01      	cmp	r3, #1
 640:	d126      	bne.n	690 <Backend_EventApply+0x690>
 642:	9b06      	ldr	r3, [sp, #24]
 644:	66a3      	str	r3, [r4, #104]	@ 0x68
 646:	9b07      	ldr	r3, [sp, #28]
 648:	66e3      	str	r3, [r4, #108]	@ 0x6c
 64a:	ab0a      	add	r3, sp, #40	@ 0x28
 64c:	9300      	str	r3, [sp, #0]
 64e:	f894 3074 	ldrb.w	r3, [r4, #116]	@ 0x74
 652:	4a26      	ldr	r2, [pc, #152]	@ (6ec <Backend_EventApply+0x6ec>)
 654:	4926      	ldr	r1, [pc, #152]	@ (6f0 <Backend_EventApply+0x6f0>)
 656:	4827      	ldr	r0, [pc, #156]	@ (6f4 <Backend_EventApply+0x6f4>)
 658:	f043 0302 	orr.w	r3, r3, #2
 65c:	f884 3074 	strb.w	r3, [r4, #116]	@ 0x74
 660:	f105 031c 	add.w	r3, r5, #28
 664:	f7ff fffe 	bl	0 <NavigationEskf_Update>
			664: R_ARM_THM_CALL	NavigationEskf_Update
 668:	1f03      	subs	r3, r0, #4
 66a:	b2db      	uxtb	r3, r3
 66c:	2b01      	cmp	r3, #1
 66e:	f63f ad0b 	bhi.w	88 <Backend_EventApply+0x88>
 672:	4b21      	ldr	r3, [pc, #132]	@ (6f8 <Backend_EventApply+0x6f8>)
 674:	9a02      	ldr	r2, [sp, #8]
 676:	701a      	strb	r2, [r3, #0]
 678:	f04f 0906 	mov.w	r9, #6
 67c:	e504      	b.n	88 <Backend_EventApply+0x88>
 67e:	f897 31ae 	ldrb.w	r3, [r7, #430]	@ 0x1ae
 682:	455b      	cmp	r3, fp
 684:	f67f af41 	bls.w	50a <Backend_EventApply+0x50a>
 688:	e73d      	b.n	506 <Backend_EventApply+0x506>
 68a:	2a01      	cmp	r2, #1
 68c:	f43f af78 	beq.w	580 <Backend_EventApply+0x580>
 690:	f04f 0901 	mov.w	r9, #1
 694:	e4f8      	b.n	88 <Backend_EventApply+0x88>
 696:	4b11      	ldr	r3, [pc, #68]	@ (6dc <Backend_EventApply+0x6dc>)
 698:	9305      	str	r3, [sp, #20]
 69a:	f04f 0907 	mov.w	r9, #7
 69e:	e4f3      	b.n	88 <Backend_EventApply+0x88>
 6a0:	f8d7 3174 	ldr.w	r3, [r7, #372]	@ 0x174
 6a4:	3301      	adds	r3, #1
 6a6:	f8c7 3174 	str.w	r3, [r7, #372]	@ 0x174
 6aa:	e66e      	b.n	38a <Backend_EventApply+0x38a>
 6ac:	f8d7 3170 	ldr.w	r3, [r7, #368]	@ 0x170
 6b0:	3301      	adds	r3, #1
 6b2:	f8c7 3170 	str.w	r3, [r7, #368]	@ 0x170
 6b6:	e668      	b.n	38a <Backend_EventApply+0x38a>
 6b8:	4a10      	ldr	r2, [pc, #64]	@ (6fc <Backend_EventApply+0x6fc>)
 6ba:	2310      	movs	r3, #16
 6bc:	e795      	b.n	5ea <Backend_EventApply+0x5ea>
 6be:	f04f 0905 	mov.w	r9, #5
 6c2:	e4e1      	b.n	88 <Backend_EventApply+0x88>
 6c4:	ea1c 0f03 	tst.w	ip, r3
 6c8:	d102      	bne.n	6d0 <Backend_EventApply+0x6d0>
 6ca:	ea4c 0303 	orr.w	r3, ip, r3
 6ce:	e798      	b.n	602 <Backend_EventApply+0x602>
 6d0:	f04f 0903 	mov.w	r9, #3
 6d4:	e4d8      	b.n	88 <Backend_EventApply+0x88>
 6d6:	f04f 0902 	mov.w	r9, #2
 6da:	e4d5      	b.n	88 <Backend_EventApply+0x88>
	...
			6dc: R_ARM_ABS32	.bss.s_calibration_generation
			6e0: R_ARM_ABS32	.bss.s_current_epoch_start_us
 6e4:	0007a120 	.word	0x0007a120
	...
			6e8: R_ARM_ABS32	.bss.s_current_gnss
			6ec: R_ARM_ABS32	.rodata.s_config
			6f0: R_ARM_ABS32	.bss.silverstar_auto_eskf_work
			6f4: R_ARM_ABS32	.bss.s_state
			6f8: R_ARM_ABS32	.bss.s_current_faulted
			6fc: R_ARM_ABS32	.bss.s_current_baro

Disassembly of section .text.SystemNavigationBackend_Reset:

00000000 <SystemNavigationBackend_Reset>:
   0:	481f      	ldr	r0, [pc, #124]	@ (80 <SystemNavigationBackend_Reset+0x80>)
   2:	4920      	ldr	r1, [pc, #128]	@ (84 <SystemNavigationBackend_Reset+0x84>)
   4:	4b20      	ldr	r3, [pc, #128]	@ (88 <SystemNavigationBackend_Reset+0x88>)
   6:	4a21      	ldr	r2, [pc, #132]	@ (8c <SystemNavigationBackend_Reset+0x8c>)
   8:	b5d0      	push	{r4, r6, r7, lr}
   a:	2400      	movs	r4, #0
   c:	700c      	strb	r4, [r1, #0]
   e:	7004      	strb	r4, [r0, #0]
  10:	491f      	ldr	r1, [pc, #124]	@ (90 <SystemNavigationBackend_Reset+0x90>)
  12:	4820      	ldr	r0, [pc, #128]	@ (94 <SystemNavigationBackend_Reset+0x94>)
  14:	701c      	strb	r4, [r3, #0]
  16:	4b20      	ldr	r3, [pc, #128]	@ (98 <SystemNavigationBackend_Reset+0x98>)
  18:	7014      	strb	r4, [r2, #0]
  1a:	f880 43d8 	strb.w	r4, [r0, #984]	@ 0x3d8
  1e:	600c      	str	r4, [r1, #0]
  20:	2248      	movs	r2, #72	@ 0x48
  22:	4621      	mov	r1, r4
  24:	481d      	ldr	r0, [pc, #116]	@ (9c <SystemNavigationBackend_Reset+0x9c>)
  26:	601c      	str	r4, [r3, #0]
  28:	f7ff fffe 	bl	0 <memset>
			28: R_ARM_THM_CALL	memset
  2c:	4b1c      	ldr	r3, [pc, #112]	@ (a0 <SystemNavigationBackend_Reset+0xa0>)
  2e:	4a1d      	ldr	r2, [pc, #116]	@ (a4 <SystemNavigationBackend_Reset+0xa4>)
  30:	701c      	strb	r4, [r3, #0]
  32:	2100      	movs	r1, #0
  34:	4b1c      	ldr	r3, [pc, #112]	@ (a8 <SystemNavigationBackend_Reset+0xa8>)
  36:	6011      	str	r1, [r2, #0]
  38:	481c      	ldr	r0, [pc, #112]	@ (ac <SystemNavigationBackend_Reset+0xac>)
  3a:	491d      	ldr	r1, [pc, #116]	@ (b0 <SystemNavigationBackend_Reset+0xb0>)
  3c:	4a1d      	ldr	r2, [pc, #116]	@ (b4 <SystemNavigationBackend_Reset+0xb4>)
  3e:	601c      	str	r4, [r3, #0]
  40:	2600      	movs	r6, #0
  42:	4b1d      	ldr	r3, [pc, #116]	@ (b8 <SystemNavigationBackend_Reset+0xb8>)
  44:	600c      	str	r4, [r1, #0]
  46:	2700      	movs	r7, #0
  48:	e9c0 6700 	strd	r6, r7, [r0]
  4c:	6014      	str	r4, [r2, #0]
  4e:	4621      	mov	r1, r4
  50:	2220      	movs	r2, #32
  52:	481a      	ldr	r0, [pc, #104]	@ (bc <SystemNavigationBackend_Reset+0xbc>)
  54:	701c      	strb	r4, [r3, #0]
  56:	f7ff fffe 	bl	0 <memset>
			56: R_ARM_THM_CALL	memset
  5a:	4a19      	ldr	r2, [pc, #100]	@ (c0 <SystemNavigationBackend_Reset+0xc0>)
  5c:	4b19      	ldr	r3, [pc, #100]	@ (c4 <SystemNavigationBackend_Reset+0xc4>)
  5e:	491a      	ldr	r1, [pc, #104]	@ (c8 <SystemNavigationBackend_Reset+0xc8>)
  60:	601c      	str	r4, [r3, #0]
  62:	e9c2 4400 	strd	r4, r4, [r2]
  66:	4a19      	ldr	r2, [pc, #100]	@ (cc <SystemNavigationBackend_Reset+0xcc>)
  68:	605c      	str	r4, [r3, #4]
  6a:	e9c2 6700 	strd	r6, r7, [r2]
  6e:	4a18      	ldr	r2, [pc, #96]	@ (d0 <SystemNavigationBackend_Reset+0xd0>)
  70:	609c      	str	r4, [r3, #8]
  72:	700c      	strb	r4, [r1, #0]
  74:	7014      	strb	r4, [r2, #0]
  76:	e8bd 40d0 	ldmia.w	sp!, {r4, r6, r7, lr}
  7a:	4816      	ldr	r0, [pc, #88]	@ (d4 <SystemNavigationBackend_Reset+0xd4>)
  7c:	f7ff bffe 	b.w	0 <NavigationWindow_Reset>
			7c: R_ARM_THM_JUMP24	NavigationWindow_Reset
	...
			80: R_ARM_ABS32	.bss.s_active
			84: R_ARM_ABS32	.bss.s_started
			88: R_ARM_ABS32	.bss.s_baro_seen
			8c: R_ARM_ABS32	.bss.s_gnss_seen
			90: R_ARM_ABS32	.bss.s_operation
			94: R_ARM_ABS32	.bss.s_state
			98: R_ARM_ABS32	.bss.s_snapshot_id
			9c: R_ARM_ABS32	.bss.s_frame
			a0: R_ARM_ABS32	.bss.s_baro_origin_valid
			a4: R_ARM_ABS32	.bss.s_baro_origin
			a8: R_ARM_ABS32	.bss.s_log_failures
			ac: R_ARM_ABS32	.bss.s_native_week_us
			b0: R_ARM_ABS32	.bss.s_native_tow_ms
			b4: R_ARM_ABS32	.bss.s_imu_quality_flags
			b8: R_ARM_ABS32	.bss.s_input_faulted
			bc: R_ARM_ABS32	.bss.s_current_gnss
			c0: R_ARM_ABS32	.bss.s_current_baro
			c4: R_ARM_ABS32	.bss.s_current_endpoint_rate
			c8: R_ARM_ABS32	.bss.s_current_endpoint_valid
			cc: R_ARM_ABS32	.bss.s_current_epoch_start_us
			d0: R_ARM_ABS32	.bss.s_current_faulted
			d4: R_ARM_ABS32	.bss.silverstar_auto_eskf_window

Disassembly of section .text.SystemNavigationBackend_Initialize:

00000000 <SystemNavigationBackend_Initialize>:
   0:	e92d 4df0 	stmdb	sp!, {r4, r5, r6, r7, r8, sl, fp, lr}
   4:	ed2d 8b02 	vpush	{d8}
   8:	b096      	sub	sp, #88	@ 0x58
   a:	4604      	mov	r4, r0
   c:	460d      	mov	r5, r1
   e:	4616      	mov	r6, r2
  10:	2100      	movs	r1, #0
  12:	2240      	movs	r2, #64	@ 0x40
  14:	a806      	add	r0, sp, #24
  16:	f89d 8080 	ldrb.w	r8, [sp, #128]	@ 0x80
  1a:	eeb0 8a40 	vmov.f32	s16, s0
  1e:	461f      	mov	r7, r3
  20:	f7ff fffe 	bl	0 <memset>
			20: R_ARM_THM_CALL	memset
  24:	2c00      	cmp	r4, #0
  26:	f000 8091 	beq.w	14c <SystemNavigationBackend_Initialize+0x14c>
  2a:	2d00      	cmp	r5, #0
  2c:	f000 808e 	beq.w	14c <SystemNavigationBackend_Initialize+0x14c>
  30:	2e01      	cmp	r6, #1
  32:	f200 808b 	bhi.w	14c <SystemNavigationBackend_Initialize+0x14c>
  36:	eddf 7a4d 	vldr	s15, [pc, #308]	@ 16c <SystemNavigationBackend_Initialize+0x16c>
  3a:	eeb0 7ac8 	vabs.f32	s14, s16
  3e:	eeb4 7a67 	vcmp.f32	s14, s15
  42:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  46:	f200 8081 	bhi.w	14c <SystemNavigationBackend_Initialize+0x14c>
  4a:	23de      	movs	r3, #222	@ 0xde
  4c:	9300      	str	r3, [sp, #0]
  4e:	2202      	movs	r2, #2
  50:	4b47      	ldr	r3, [pc, #284]	@ (170 <SystemNavigationBackend_Initialize+0x170>)
  52:	2104      	movs	r1, #4
  54:	4620      	mov	r0, r4
  56:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			56: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  5a:	23df      	movs	r3, #223	@ 0xdf
  5c:	4628      	mov	r0, r5
  5e:	9300      	str	r3, [sp, #0]
  60:	2202      	movs	r2, #2
  62:	4b43      	ldr	r3, [pc, #268]	@ (170 <SystemNavigationBackend_Initialize+0x170>)
  64:	2108      	movs	r1, #8
  66:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			66: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  6a:	f7ff fffe 	bl	0 <SystemNavigationBackend_Initialize>
			6a: R_ARM_THM_CALL	SystemNavigationBackend_Reset
  6e:	4841      	ldr	r0, [pc, #260]	@ (174 <SystemNavigationBackend_Initialize+0x174>)
  70:	f7ff fffe 	bl	0 <NavigationEskf_ConfigValidate>
			70: R_ARM_THM_CALL	NavigationEskf_ConfigValidate
  74:	2800      	cmp	r0, #0
  76:	d170      	bne.n	15a <SystemNavigationBackend_Initialize+0x15a>
  78:	483f      	ldr	r0, [pc, #252]	@ (178 <SystemNavigationBackend_Initialize+0x178>)
  7a:	f7ff fffe 	bl	0 <NavigationWindow_ConfigValidate>
			7a: R_ARM_THM_CALL	NavigationWindow_ConfigValidate
  7e:	2800      	cmp	r0, #0
  80:	d16b      	bne.n	15a <SystemNavigationBackend_Initialize+0x15a>
  82:	f10d 0017 	add.w	r0, sp, #23
  86:	f7ff fffe 	bl	0 <SystemSourceSelector_ImuActiveInstanceGet>
			86: R_ARM_THM_CALL	SystemSourceSelector_ImuActiveInstanceGet
  8a:	2800      	cmp	r0, #0
  8c:	d16c      	bne.n	168 <SystemNavigationBackend_Initialize+0x168>
  8e:	6820      	ldr	r0, [r4, #0]
  90:	6861      	ldr	r1, [r4, #4]
  92:	68a2      	ldr	r2, [r4, #8]
  94:	68e3      	ldr	r3, [r4, #12]
  96:	f895 c074 	ldrb.w	ip, [r5, #116]	@ 0x74
  9a:	ac0c      	add	r4, sp, #48	@ 0x30
  9c:	c40f      	stmia	r4!, {r0, r1, r2, r3}
  9e:	f1bc 0f00 	cmp.w	ip, #0
  a2:	d01f      	beq.n	e4 <SystemNavigationBackend_Initialize+0xe4>
  a4:	4835      	ldr	r0, [pc, #212]	@ (17c <SystemNavigationBackend_Initialize+0x17c>)
  a6:	f7ff fffe 	bl	0 <SystemSourceSelector_GnssActiveInstanceGet>
			a6: R_ARM_THM_CALL	SystemSourceSelector_GnssActiveInstanceGet
  aa:	2800      	cmp	r0, #0
  ac:	d15c      	bne.n	168 <SystemNavigationBackend_Initialize+0x168>
  ae:	e9d5 2310 	ldrd	r2, r3, [r5, #64]	@ 0x40
  b2:	6be9      	ldr	r1, [r5, #60]	@ 0x3c
  b4:	4832      	ldr	r0, [pc, #200]	@ (180 <SystemNavigationBackend_Initialize+0x180>)
  b6:	f7ff fffe 	bl	0 <GeoLocalFrame_Init>
			b6: R_ARM_THM_CALL	GeoLocalFrame_Init
  ba:	2800      	cmp	r0, #0
  bc:	d054      	beq.n	168 <SystemNavigationBackend_Initialize+0x168>
  be:	f895 0070 	ldrb.w	r0, [r5, #112]	@ 0x70
  c2:	a909      	add	r1, sp, #36	@ 0x24
  c4:	354c      	adds	r5, #76	@ 0x4c
  c6:	2300      	movs	r3, #0
  c8:	fa20 f203 	lsr.w	r2, r0, r3
  cc:	f012 0f01 	tst.w	r2, #1
  d0:	bf1c      	itt	ne
  d2:	682a      	ldrne	r2, [r5, #0]
  d4:	600a      	strne	r2, [r1, #0]
  d6:	3301      	adds	r3, #1
  d8:	2b03      	cmp	r3, #3
  da:	f105 0504 	add.w	r5, r5, #4
  de:	f101 0104 	add.w	r1, r1, #4
  e2:	d1f1      	bne.n	c8 <SystemNavigationBackend_Initialize+0xc8>
  e4:	2100      	movs	r1, #0
  e6:	4827      	ldr	r0, [pc, #156]	@ (184 <SystemNavigationBackend_Initialize+0x184>)
  e8:	f44f 7261 	mov.w	r2, #900	@ 0x384
  ec:	f7ff fffe 	bl	0 <memset>
			ec: R_ARM_THM_CALL	memset
  f0:	4925      	ldr	r1, [pc, #148]	@ (188 <SystemNavigationBackend_Initialize+0x188>)
  f2:	4b24      	ldr	r3, [pc, #144]	@ (184 <SystemNavigationBackend_Initialize+0x184>)
  f4:	f101 003c 	add.w	r0, r1, #60	@ 0x3c
  f8:	f851 2b04 	ldr.w	r2, [r1], #4
  fc:	f843 2b40 	str.w	r2, [r3], #64
 100:	4281      	cmp	r1, r0
 102:	d1f9      	bne.n	f8 <SystemNavigationBackend_Initialize+0xf8>
 104:	f89d 3017 	ldrb.w	r3, [sp, #23]
 108:	4820      	ldr	r0, [pc, #128]	@ (18c <SystemNavigationBackend_Initialize+0x18c>)
 10a:	e9cd 3702 	strd	r3, r7, [sp, #8]
 10e:	4b1d      	ldr	r3, [pc, #116]	@ (184 <SystemNavigationBackend_Initialize+0x184>)
 110:	f04f 0a00 	mov.w	sl, #0
 114:	f04f 0b00 	mov.w	fp, #0
 118:	e9cd ab00 	strd	sl, fp, [sp]
 11c:	aa06      	add	r2, sp, #24
 11e:	4619      	mov	r1, r3
 120:	f7ff fffe 	bl	0 <NavigationEskf_Initialize>
			120: R_ARM_THM_CALL	NavigationEskf_Initialize
 124:	4604      	mov	r4, r0
 126:	b9c0      	cbnz	r0, 15a <SystemNavigationBackend_Initialize+0x15a>
 128:	4b19      	ldr	r3, [pc, #100]	@ (190 <SystemNavigationBackend_Initialize+0x190>)
 12a:	ed83 8a00 	vstr	s16, [r3]
 12e:	4b19      	ldr	r3, [pc, #100]	@ (194 <SystemNavigationBackend_Initialize+0x194>)
 130:	701e      	strb	r6, [r3, #0]
 132:	4b19      	ldr	r3, [pc, #100]	@ (198 <SystemNavigationBackend_Initialize+0x198>)
 134:	f883 8000 	strb.w	r8, [r3]
 138:	f7ff fffe 	bl	0 <SystemCalibration_GenerationGet>
			138: R_ARM_THM_CALL	SystemCalibration_GenerationGet
 13c:	4b17      	ldr	r3, [pc, #92]	@ (19c <SystemNavigationBackend_Initialize+0x19c>)
 13e:	4602      	mov	r2, r0
 140:	4659      	mov	r1, fp
 142:	4650      	mov	r0, sl
 144:	601a      	str	r2, [r3, #0]
 146:	f7ff fffe 	bl	0 <SystemNavigationHealth_Reset>
			146: R_ARM_THM_CALL	SystemNavigationHealth_Reset
 14a:	e000      	b.n	14e <SystemNavigationBackend_Initialize+0x14e>
 14c:	2405      	movs	r4, #5
 14e:	4620      	mov	r0, r4
 150:	b016      	add	sp, #88	@ 0x58
 152:	ecbd 8b02 	vpop	{d8}
 156:	e8bd 8df0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, sl, fp, pc}
 15a:	2408      	movs	r4, #8
 15c:	4620      	mov	r0, r4
 15e:	b016      	add	sp, #88	@ 0x58
 160:	ecbd 8b02 	vpop	{d8}
 164:	e8bd 8df0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, sl, fp, pc}
 168:	2402      	movs	r4, #2
 16a:	e7f0      	b.n	14e <SystemNavigationBackend_Initialize+0x14e>
 16c:	7f7fffff 	.word	0x7f7fffff
	...
			170: R_ARM_ABS32	.rodata.Backend_StateLog.str1.4
			174: R_ARM_ABS32	.rodata.s_config
			178: R_ARM_ABS32	.rodata.s_window_config
			17c: R_ARM_ABS32	.bss.s_gnss_source
			180: R_ARM_ABS32	.bss.s_frame
			184: R_ARM_ABS32	.bss.silverstar_auto_eskf_work
			188: R_ARM_ABS32	.rodata.s_initial_diagonal
			18c: R_ARM_ABS32	.bss.s_state
			190: R_ARM_ABS32	.bss.s_baro_origin
			194: R_ARM_ABS32	.bss.s_baro_origin_valid
			198: R_ARM_ABS32	.bss.s_active
			19c: R_ARM_ABS32	.bss.s_calibration_generation

Disassembly of section .text.SystemNavigationBackend_SnapshotGet:

00000000 <SystemNavigationBackend_SnapshotGet>:
   0:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
   4:	b082      	sub	sp, #8
   6:	2800      	cmp	r0, #0
   8:	f000 808b 	beq.w	122 <SystemNavigationBackend_SnapshotGet+0x122>
   c:	4f47      	ldr	r7, [pc, #284]	@ (12c <SystemNavigationBackend_SnapshotGet+0x12c>)
   e:	f897 33d8 	ldrb.w	r3, [r7, #984]	@ 0x3d8
  12:	2b00      	cmp	r3, #0
  14:	d077      	beq.n	106 <SystemNavigationBackend_SnapshotGet+0x106>
  16:	4a46      	ldr	r2, [pc, #280]	@ (130 <SystemNavigationBackend_SnapshotGet+0x130>)
  18:	4b46      	ldr	r3, [pc, #280]	@ (134 <SystemNavigationBackend_SnapshotGet+0x134>)
  1a:	7816      	ldrb	r6, [r2, #0]
  1c:	781b      	ldrb	r3, [r3, #0]
  1e:	431e      	orrs	r6, r3
  20:	d171      	bne.n	106 <SystemNavigationBackend_SnapshotGet+0x106>
  22:	f240 4346 	movw	r3, #1094	@ 0x446
  26:	9300      	str	r3, [sp, #0]
  28:	2202      	movs	r2, #2
  2a:	4b43      	ldr	r3, [pc, #268]	@ (138 <SystemNavigationBackend_SnapshotGet+0x138>)
  2c:	2108      	movs	r1, #8
  2e:	4604      	mov	r4, r0
  30:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			30: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  34:	e9d7 23f2 	ldrd	r2, r3, [r7, #968]	@ 0x3c8
  38:	e9c4 2300 	strd	r2, r3, [r4]
  3c:	4a3f      	ldr	r2, [pc, #252]	@ (13c <SystemNavigationBackend_SnapshotGet+0x13c>)
  3e:	4b40      	ldr	r3, [pc, #256]	@ (140 <SystemNavigationBackend_SnapshotGet+0x140>)
  40:	f892 1040 	ldrb.w	r1, [r2, #64]	@ 0x40
  44:	781a      	ldrb	r2, [r3, #0]
  46:	4b3f      	ldr	r3, [pc, #252]	@ (144 <SystemNavigationBackend_SnapshotGet+0x144>)
  48:	f897 53d8 	ldrb.w	r5, [r7, #984]	@ 0x3d8
  4c:	7818      	ldrb	r0, [r3, #0]
  4e:	4633      	mov	r3, r6
  50:	f365 0307 	bfi	r3, r5, #0, #8
  54:	f360 230f 	bfi	r3, r0, #8, #8
  58:	f361 4317 	bfi	r3, r1, #16, #8
  5c:	f362 631f 	bfi	r3, r2, #24, #8
  60:	f8c4 31a8 	str.w	r3, [r4, #424]	@ 0x1a8
  64:	f8d4 3180 	ldr.w	r3, [r4, #384]	@ 0x180
  68:	b909      	cbnz	r1, 6e <SystemNavigationBackend_SnapshotGet+0x6e>
  6a:	f043 0302 	orr.w	r3, r3, #2
  6e:	2a00      	cmp	r2, #0
  70:	d04e      	beq.n	110 <SystemNavigationBackend_SnapshotGet+0x110>
  72:	f023 0204 	bic.w	r2, r3, #4
  76:	4b2d      	ldr	r3, [pc, #180]	@ (12c <SystemNavigationBackend_SnapshotGet+0x12c>)
  78:	f8c4 2180 	str.w	r2, [r4, #384]	@ 0x180
  7c:	cb07      	ldmia	r3!, {r0, r1, r2}
  7e:	60e0      	str	r0, [r4, #12]
  80:	6121      	str	r1, [r4, #16]
  82:	6162      	str	r2, [r4, #20]
  84:	f1a3 070c 	sub.w	r7, r3, #12
  88:	f103 0534 	add.w	r5, r3, #52	@ 0x34
  8c:	cb07      	ldmia	r3!, {r0, r1, r2}
  8e:	61a0      	str	r0, [r4, #24]
  90:	61e1      	str	r1, [r4, #28]
  92:	6222      	str	r2, [r4, #32]
  94:	469a      	mov	sl, r3
  96:	e8ba 000f 	ldmia.w	sl!, {r0, r1, r2, r3}
  9a:	f104 0840 	add.w	r8, r4, #64	@ 0x40
  9e:	f104 0c70 	add.w	ip, r4, #112	@ 0x70
  a2:	f104 0958 	add.w	r9, r4, #88	@ 0x58
  a6:	46be      	mov	lr, r7
  a8:	6260      	str	r0, [r4, #36]	@ 0x24
  aa:	62a1      	str	r1, [r4, #40]	@ 0x28
  ac:	62e2      	str	r2, [r4, #44]	@ 0x2c
  ae:	6323      	str	r3, [r4, #48]	@ 0x30
  b0:	f8de 2040 	ldr.w	r2, [lr, #64]	@ 0x40
  b4:	f848 2b04 	str.w	r2, [r8], #4
  b8:	f1ac 0318 	sub.w	r3, ip, #24
  bc:	462a      	mov	r2, r5
  be:	f852 1b04 	ldr.w	r1, [r2], #4
  c2:	f843 1b04 	str.w	r1, [r3], #4
  c6:	4563      	cmp	r3, ip
  c8:	d1f9      	bne.n	be <SystemNavigationBackend_SnapshotGet+0xbe>
  ca:	45c8      	cmp	r8, r9
  cc:	f10e 0e40 	add.w	lr, lr, #64	@ 0x40
  d0:	f105 053c 	add.w	r5, r5, #60	@ 0x3c
  d4:	f103 0c18 	add.w	ip, r3, #24
  d8:	d1ea      	bne.n	b0 <SystemNavigationBackend_SnapshotGet+0xb0>
  da:	e9d7 01f2 	ldrd	r0, r1, [r7, #968]	@ 0x3c8
  de:	f7ff fffe 	bl	0 <SystemNavigationHealth_DegradedGet>
			de: R_ARM_THM_CALL	SystemNavigationHealth_DegradedGet
  e2:	f8d4 3180 	ldr.w	r3, [r4, #384]	@ 0x180
  e6:	b1c8      	cbz	r0, 11c <SystemNavigationBackend_SnapshotGet+0x11c>
  e8:	f043 0380 	orr.w	r3, r3, #128	@ 0x80
  ec:	4a16      	ldr	r2, [pc, #88]	@ (148 <SystemNavigationBackend_SnapshotGet+0x148>)
  ee:	f8c4 3180 	str.w	r3, [r4, #384]	@ 0x180
  f2:	6812      	ldr	r2, [r2, #0]
  f4:	b142      	cbz	r2, 108 <SystemNavigationBackend_SnapshotGet+0x108>
  f6:	f443 7380 	orr.w	r3, r3, #256	@ 0x100
  fa:	4630      	mov	r0, r6
  fc:	f8c4 3180 	str.w	r3, [r4, #384]	@ 0x180
 100:	b002      	add	sp, #8
 102:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
 106:	2602      	movs	r6, #2
 108:	4630      	mov	r0, r6
 10a:	b002      	add	sp, #8
 10c:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
 110:	490e      	ldr	r1, [pc, #56]	@ (14c <SystemNavigationBackend_SnapshotGet+0x14c>)
 112:	f8c4 1100 	str.w	r1, [r4, #256]	@ 0x100
 116:	f043 0204 	orr.w	r2, r3, #4
 11a:	e7ac      	b.n	76 <SystemNavigationBackend_SnapshotGet+0x76>
 11c:	f023 0380 	bic.w	r3, r3, #128	@ 0x80
 120:	e7e4      	b.n	ec <SystemNavigationBackend_SnapshotGet+0xec>
 122:	2605      	movs	r6, #5
 124:	4630      	mov	r0, r6
 126:	b002      	add	sp, #8
 128:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
	...
			12c: R_ARM_ABS32	.bss.s_state
			130: R_ARM_ABS32	.bss.s_input_faulted
			134: R_ARM_ABS32	.bss.s_current_faulted
			138: R_ARM_ABS32	.rodata.Backend_StateLog.str1.4
			13c: R_ARM_ABS32	.bss.s_frame
			140: R_ARM_ABS32	.bss.s_baro_origin_valid
			144: R_ARM_ABS32	.bss.s_active
			148: R_ARM_ABS32	.bss.s_log_failures
 14c:	7fc00000 	.word	0x7fc00000

Disassembly of section .text.SystemNavigationBackend_Predict:

00000000 <SystemNavigationBackend_Predict>:
   0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
   4:	ed2d 8b04 	vpush	{d8-d9}
   8:	f5ad 7d05 	sub.w	sp, sp, #532	@ 0x214
   c:	2800      	cmp	r0, #0
   e:	f000 8469 	beq.w	8e4 <SystemNavigationBackend_Predict+0x8e4>
  12:	460d      	mov	r5, r1
  14:	2900      	cmp	r1, #0
  16:	f000 8465 	beq.w	8e4 <SystemNavigationBackend_Predict+0x8e4>
  1a:	edd0 7a03 	vldr	s15, [r0, #12]
  1e:	ed9f 7ac9 	vldr	s14, [pc, #804]	@ 344 <SystemNavigationBackend_Predict+0x344>
  22:	eef0 6ae7 	vabs.f32	s13, s15
  26:	eef4 6a47 	vcmp.f32	s13, s14
  2a:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  2e:	4604      	mov	r4, r0
  30:	f200 8458 	bhi.w	8e4 <SystemNavigationBackend_Predict+0x8e4>
  34:	eef5 7ac0 	vcmpe.f32	s15, #0.0
  38:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  3c:	f240 8452 	bls.w	8e4 <SystemNavigationBackend_Predict+0x8e4>
  40:	ed9f 7ac1 	vldr	s14, [pc, #772]	@ 348 <SystemNavigationBackend_Predict+0x348>
  44:	eef4 7ac7 	vcmpe.f32	s15, s14
  48:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  4c:	f300 844a 	bgt.w	8e4 <SystemNavigationBackend_Predict+0x8e4>
  50:	f240 43c2 	movw	r3, #1218	@ 0x4c2
  54:	4fbd      	ldr	r7, [pc, #756]	@ (34c <SystemNavigationBackend_Predict+0x34c>)
  56:	9300      	str	r3, [sp, #0]
  58:	2202      	movs	r2, #2
  5a:	4bbd      	ldr	r3, [pc, #756]	@ (350 <SystemNavigationBackend_Predict+0x350>)
  5c:	2108      	movs	r1, #8
  5e:	ed97 8bf2 	vldr	d8, [r7, #968]	@ 0x3c8
  62:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			62: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  66:	f240 43c3 	movw	r3, #1219	@ 0x4c3
  6a:	9300      	str	r3, [sp, #0]
  6c:	2202      	movs	r2, #2
  6e:	4bb8      	ldr	r3, [pc, #736]	@ (350 <SystemNavigationBackend_Predict+0x350>)
  70:	2108      	movs	r1, #8
  72:	4628      	mov	r0, r5
  74:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			74: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  78:	4bb6      	ldr	r3, [pc, #728]	@ (354 <SystemNavigationBackend_Predict+0x354>)
  7a:	f893 8000 	ldrb.w	r8, [r3]
  7e:	4bb6      	ldr	r3, [pc, #728]	@ (358 <SystemNavigationBackend_Predict+0x358>)
  80:	781b      	ldrb	r3, [r3, #0]
  82:	ea58 0803 	orrs.w	r8, r8, r3
  86:	f040 843d 	bne.w	904 <SystemNavigationBackend_Predict+0x904>
  8a:	4bb4      	ldr	r3, [pc, #720]	@ (35c <SystemNavigationBackend_Predict+0x35c>)
  8c:	781b      	ldrb	r3, [r3, #0]
  8e:	2b00      	cmp	r3, #0
  90:	f000 8430 	beq.w	8f4 <SystemNavigationBackend_Predict+0x8f4>
  94:	f897 33d8 	ldrb.w	r3, [r7, #984]	@ 0x3d8
  98:	2b00      	cmp	r3, #0
  9a:	f000 842b 	beq.w	8f4 <SystemNavigationBackend_Predict+0x8f4>
  9e:	f240 4386 	movw	r3, #1158	@ 0x486
  a2:	9300      	str	r3, [sp, #0]
  a4:	2202      	movs	r2, #2
  a6:	4baa      	ldr	r3, [pc, #680]	@ (350 <SystemNavigationBackend_Predict+0x350>)
  a8:	2108      	movs	r1, #8
  aa:	4620      	mov	r0, r4
  ac:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			ac: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  b0:	ae22      	add	r6, sp, #136	@ 0x88
  b2:	f240 4387 	movw	r3, #1159	@ 0x487
  b6:	2202      	movs	r2, #2
  b8:	9300      	str	r3, [sp, #0]
  ba:	2108      	movs	r1, #8
  bc:	4ba4      	ldr	r3, [pc, #656]	@ (350 <SystemNavigationBackend_Predict+0x350>)
  be:	4630      	mov	r0, r6
  c0:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			c0: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  c4:	ed94 9a03 	vldr	s18, [r4, #12]
  c8:	ed9f 0aa5 	vldr	s0, [pc, #660]	@ 360 <SystemNavigationBackend_Predict+0x360>
  cc:	ee29 0a00 	vmul.f32	s0, s18, s0
  d0:	f7ff fffe 	bl	0 <llroundf>
			d0: R_ARM_THM_CALL	llroundf
  d4:	e9d4 b300 	ldrd	fp, r3, [r4]
  d8:	4583      	cmp	fp, r0
  da:	eb73 0201 	sbcs.w	r2, r3, r1
  de:	468a      	mov	sl, r1
  e0:	4681      	mov	r9, r0
  e2:	9305      	str	r3, [sp, #20]
  e4:	f0c0 83fe 	bcc.w	8e4 <SystemNavigationBackend_Predict+0x8e4>
  e8:	4641      	mov	r1, r8
  ea:	2224      	movs	r2, #36	@ 0x24
  ec:	a82f      	add	r0, sp, #188	@ 0xbc
  ee:	f7ff fffe 	bl	0 <memset>
			ee: R_ARM_THM_CALL	memset
  f2:	9b05      	ldr	r3, [sp, #20]
  f4:	6aa0      	ldr	r0, [r4, #40]	@ 0x28
  f6:	6ae1      	ldr	r1, [r4, #44]	@ 0x2c
  f8:	6473      	str	r3, [r6, #68]	@ 0x44
  fa:	ebbb 0209 	subs.w	r2, fp, r9
  fe:	63b2      	str	r2, [r6, #56]	@ 0x38
 100:	eb63 020a 	sbc.w	r2, r3, sl
 104:	63f2      	str	r2, [r6, #60]	@ 0x3c
 106:	6b63      	ldr	r3, [r4, #52]	@ 0x34
 108:	6b22      	ldr	r2, [r4, #48]	@ 0x30
 10a:	ed86 9a0c 	vstr	s18, [r6, #48]	@ 0x30
 10e:	46b4      	mov	ip, r6
 110:	e8ac 000f 	stmia.w	ip!, {r0, r1, r2, r3}
 114:	6ba0      	ldr	r0, [r4, #56]	@ 0x38
 116:	6be1      	ldr	r1, [r4, #60]	@ 0x3c
 118:	6ca2      	ldr	r2, [r4, #72]	@ 0x48
 11a:	6ce3      	ldr	r3, [r4, #76]	@ 0x4c
 11c:	f8c6 b040 	str.w	fp, [r6, #64]	@ 0x40
 120:	e8ac 0003 	stmia.w	ip!, {r0, r1}
 124:	6c61      	ldr	r1, [r4, #68]	@ 0x44
 126:	6c20      	ldr	r0, [r4, #64]	@ 0x40
 128:	f8df 8254 	ldr.w	r8, [pc, #596]	@ 380 <SystemNavigationBackend_Predict+0x380>
 12c:	e8ac 000f 	stmia.w	ip!, {r0, r1, r2, r3}
 130:	4a8c      	ldr	r2, [pc, #560]	@ (364 <SystemNavigationBackend_Predict+0x364>)
 132:	6da3      	ldr	r3, [r4, #88]	@ 0x58
 134:	6013      	str	r3, [r2, #0]
 136:	6533      	str	r3, [r6, #80]	@ 0x50
 138:	f8d7 33d4 	ldr.w	r3, [r7, #980]	@ 0x3d4
 13c:	64f3      	str	r3, [r6, #76]	@ 0x4c
 13e:	f8d7 33d0 	ldr.w	r3, [r7, #976]	@ 0x3d0
 142:	64b3      	str	r3, [r6, #72]	@ 0x48
 144:	6d20      	ldr	r0, [r4, #80]	@ 0x50
 146:	6d61      	ldr	r1, [r4, #84]	@ 0x54
 148:	f240 4365 	movw	r3, #1125	@ 0x465
 14c:	e8ac 0003 	stmia.w	ip!, {r0, r1}
 150:	2202      	movs	r2, #2
 152:	9300      	str	r3, [sp, #0]
 154:	2108      	movs	r1, #8
 156:	4b7e      	ldr	r3, [pc, #504]	@ (350 <SystemNavigationBackend_Predict+0x350>)
 158:	4630      	mov	r0, r6
 15a:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			15a: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
 15e:	2305      	movs	r3, #5
 160:	9300      	str	r3, [sp, #0]
 162:	f897 03d8 	ldrb.w	r0, [r7, #984]	@ 0x3d8
 166:	4a7a      	ldr	r2, [pc, #488]	@ (350 <SystemNavigationBackend_Predict+0x350>)
 168:	3800      	subs	r0, #0
 16a:	f240 4366 	movw	r3, #1126	@ 0x466
 16e:	bf18      	it	ne
 170:	2001      	movne	r0, #1
 172:	2102      	movs	r1, #2
 174:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			174: R_ARM_THM_CALL	SilverStarAssert_Check
 178:	f898 3000 	ldrb.w	r3, [r8]
 17c:	2b00      	cmp	r3, #0
 17e:	f000 83d6 	beq.w	92e <SystemNavigationBackend_Predict+0x92e>
 182:	f240 3303 	movw	r3, #771	@ 0x303
 186:	f04f 0800 	mov.w	r8, #0
 18a:	f8a5 31ae 	strh.w	r3, [r5, #430]	@ 0x1ae
 18e:	2303      	movs	r3, #3
 190:	6d30      	ldr	r0, [r6, #80]	@ 0x50
 192:	f8c5 8184 	str.w	r8, [r5, #388]	@ 0x184
 196:	f885 31b0 	strb.w	r3, [r5, #432]	@ 0x1b0
 19a:	f7ff fffe 	bl	0 <SystemNavigationHealth_ImuQualityRecord>
			19a: R_ARM_THM_CALL	SystemNavigationHealth_ImuQualityRecord
 19e:	f240 1379 	movw	r3, #377	@ 0x179
 1a2:	68a4      	ldr	r4, [r4, #8]
 1a4:	9300      	str	r3, [sp, #0]
 1a6:	2202      	movs	r2, #2
 1a8:	4b69      	ldr	r3, [pc, #420]	@ (350 <SystemNavigationBackend_Predict+0x350>)
 1aa:	2108      	movs	r1, #8
 1ac:	4630      	mov	r0, r6
 1ae:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			1ae: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
 1b2:	6b33      	ldr	r3, [r6, #48]	@ 0x30
 1b4:	9360      	str	r3, [sp, #384]	@ 0x180
 1b6:	6cb3      	ldr	r3, [r6, #72]	@ 0x48
 1b8:	935d      	str	r3, [sp, #372]	@ 0x174
 1ba:	4b6b      	ldr	r3, [pc, #428]	@ (368 <SystemNavigationBackend_Predict+0x368>)
 1bc:	f8cd 81b4 	str.w	r8, [sp, #436]	@ 0x1b4
 1c0:	681b      	ldr	r3, [r3, #0]
 1c2:	935e      	str	r3, [sp, #376]	@ 0x178
 1c4:	6d33      	ldr	r3, [r6, #80]	@ 0x50
 1c6:	935f      	str	r3, [sp, #380]	@ 0x17c
 1c8:	e9d6 230e 	ldrd	r2, r3, [r6, #56]	@ 0x38
 1cc:	46b0      	mov	r8, r6
 1ce:	e9cd 2358 	strd	r2, r3, [sp, #352]	@ 0x160
 1d2:	e8b8 000f 	ldmia.w	r8!, {r0, r1, r2, r3}
 1d6:	e9d6 ab10 	ldrd	sl, fp, [r6, #64]	@ 0x40
 1da:	f50d 7ec2 	add.w	lr, sp, #388	@ 0x184
 1de:	945c      	str	r4, [sp, #368]	@ 0x170
 1e0:	e9cd ab5a 	strd	sl, fp, [sp, #360]	@ 0x168
 1e4:	e8ae 000f 	stmia.w	lr!, {r0, r1, r2, r3}
 1e8:	e898 0003 	ldmia.w	r8, {r0, r1}
 1ec:	ac28      	add	r4, sp, #160	@ 0xa0
 1ee:	e88e 0003 	stmia.w	lr, {r0, r1}
 1f2:	cc0f      	ldmia	r4!, {r0, r1, r2, r3}
 1f4:	f50d 7cce 	add.w	ip, sp, #412	@ 0x19c
 1f8:	e8ac 000f 	stmia.w	ip!, {r0, r1, r2, r3}
 1fc:	e894 0003 	ldmia.w	r4, {r0, r1}
 200:	aa58      	add	r2, sp, #352	@ 0x160
 202:	e88c 0003 	stmia.w	ip, {r0, r1}
 206:	4650      	mov	r0, sl
 208:	4659      	mov	r1, fp
 20a:	f7ff fffe 	bl	0 <LoggerBus_Eskf15BodyInputPush>
			20a: R_ARM_THM_CALL	LoggerBus_Eskf15BodyInputPush
 20e:	2800      	cmp	r0, #0
 210:	f040 8388 	bne.w	924 <SystemNavigationBackend_Predict+0x924>
 214:	4a55      	ldr	r2, [pc, #340]	@ (36c <SystemNavigationBackend_Predict+0x36c>)
 216:	4b50      	ldr	r3, [pc, #320]	@ (358 <SystemNavigationBackend_Predict+0x358>)
 218:	ca07      	ldmia	r2, {r0, r1, r2}
 21a:	781b      	ldrb	r3, [r3, #0]
 21c:	ac0a      	add	r4, sp, #40	@ 0x28
 21e:	e884 0007 	stmia.w	r4, {r0, r1, r2}
 222:	2b00      	cmp	r3, #0
 224:	f040 8396 	bne.w	954 <SystemNavigationBackend_Predict+0x954>
 228:	f897 33d8 	ldrb.w	r3, [r7, #984]	@ 0x3d8
 22c:	2b00      	cmp	r3, #0
 22e:	f000 8391 	beq.w	954 <SystemNavigationBackend_Predict+0x954>
 232:	f7ff fffe 	bl	0 <SystemCalibration_GenerationGet>
			232: R_ARM_THM_CALL	SystemCalibration_GenerationGet
 236:	4b4c      	ldr	r3, [pc, #304]	@ (368 <SystemNavigationBackend_Predict+0x368>)
 238:	681b      	ldr	r3, [r3, #0]
 23a:	4298      	cmp	r0, r3
 23c:	f040 8387 	bne.w	94e <SystemNavigationBackend_Predict+0x94e>
 240:	e9d6 230e 	ldrd	r2, r3, [r6, #56]	@ 0x38
 244:	e9d7 01f2 	ldrd	r0, r1, [r7, #968]	@ 0x3c8
 248:	428b      	cmp	r3, r1
 24a:	bf08      	it	eq
 24c:	4282      	cmpeq	r2, r0
 24e:	f040 837e 	bne.w	94e <SystemNavigationBackend_Predict+0x94e>
 252:	e9d6 0110 	ldrd	r0, r1, [r6, #64]	@ 0x40
 256:	4282      	cmp	r2, r0
 258:	eb73 0101 	sbcs.w	r1, r3, r1
 25c:	f080 8377 	bcs.w	94e <SystemNavigationBackend_Predict+0x94e>
 260:	f8df 8120 	ldr.w	r8, [pc, #288]	@ 384 <SystemNavigationBackend_Predict+0x384>
 264:	f898 3000 	ldrb.w	r3, [r8]
 268:	b11b      	cbz	r3, 272 <SystemNavigationBackend_Predict+0x272>
 26a:	6d33      	ldr	r3, [r6, #80]	@ 0x50
 26c:	071b      	lsls	r3, r3, #28
 26e:	f100 836e 	bmi.w	94e <SystemNavigationBackend_Predict+0x94e>
 272:	4a3f      	ldr	r2, [pc, #252]	@ (370 <SystemNavigationBackend_Predict+0x370>)
 274:	493f      	ldr	r1, [pc, #252]	@ (374 <SystemNavigationBackend_Predict+0x374>)
 276:	4835      	ldr	r0, [pc, #212]	@ (34c <SystemNavigationBackend_Predict+0x34c>)
 278:	4633      	mov	r3, r6
 27a:	f7ff fffe 	bl	0 <NavigationEskf_Predict>
			27a: R_ARM_THM_CALL	NavigationEskf_Predict
 27e:	2800      	cmp	r0, #0
 280:	f040 8365 	bne.w	94e <SystemNavigationBackend_Predict+0x94e>
 284:	aa25      	add	r2, sp, #148	@ 0x94
 286:	ca07      	ldmia	r2, {r0, r1, r2}
 288:	f8df c0fc 	ldr.w	ip, [pc, #252]	@ 388 <SystemNavigationBackend_Predict+0x388>
 28c:	edd6 6a0c 	vldr	s13, [r6, #48]	@ 0x30
 290:	4e36      	ldr	r6, [pc, #216]	@ (36c <SystemNavigationBackend_Predict+0x36c>)
 292:	e88c 0007 	stmia.w	ip, {r0, r1, r2}
 296:	2301      	movs	r3, #1
 298:	f888 3000 	strb.w	r3, [r8]
 29c:	f105 0e40 	add.w	lr, r5, #64	@ 0x40
 2a0:	f105 0334 	add.w	r3, r5, #52	@ 0x34
 2a4:	ecf6 7a01 	vldmia	r6!, {s15}
 2a8:	ecb4 7a01 	vldmia	r4!, {s14}
 2ac:	ee77 7ac7 	vsub.f32	s15, s15, s14
 2b0:	ee87 7aa6 	vdiv.f32	s14, s15, s13
 2b4:	eca3 7a01 	vstmia	r3!, {s14}
 2b8:	459e      	cmp	lr, r3
 2ba:	d1f3      	bne.n	2a4 <SystemNavigationBackend_Predict+0x2a4>
 2bc:	f240 339b 	movw	r3, #923	@ 0x39b
 2c0:	9300      	str	r3, [sp, #0]
 2c2:	2202      	movs	r2, #2
 2c4:	4b22      	ldr	r3, [pc, #136]	@ (350 <SystemNavigationBackend_Predict+0x350>)
 2c6:	2108      	movs	r1, #8
 2c8:	4628      	mov	r0, r5
 2ca:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			2ca: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
 2ce:	2305      	movs	r3, #5
 2d0:	9300      	str	r3, [sp, #0]
 2d2:	f897 03d8 	ldrb.w	r0, [r7, #984]	@ 0x3d8
 2d6:	4a1e      	ldr	r2, [pc, #120]	@ (350 <SystemNavigationBackend_Predict+0x350>)
 2d8:	3800      	subs	r0, #0
 2da:	bf18      	it	ne
 2dc:	2001      	movne	r0, #1
 2de:	f44f 7367 	mov.w	r3, #924	@ 0x39c
 2e2:	2102      	movs	r1, #2
 2e4:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			2e4: R_ARM_THM_CALL	SilverStarAssert_Check
 2e8:	a858      	add	r0, sp, #352	@ 0x160
 2ea:	f7ff fffe 	bl	0 <SystemGnss_ReceiptSnapshotGet>
			2ea: R_ARM_THM_CALL	SystemGnss_ReceiptSnapshotGet
 2ee:	2809      	cmp	r0, #9
 2f0:	9006      	str	r0, [sp, #24]
 2f2:	f000 8366 	beq.w	9c2 <SystemNavigationBackend_Predict+0x9c2>
 2f6:	9b06      	ldr	r3, [sp, #24]
 2f8:	2b00      	cmp	r3, #0
 2fa:	f040 8229 	bne.w	750 <SystemNavigationBackend_Predict+0x750>
 2fe:	4c1e      	ldr	r4, [pc, #120]	@ (378 <SystemNavigationBackend_Predict+0x378>)
 300:	f894 3040 	ldrb.w	r3, [r4, #64]	@ 0x40
 304:	2b00      	cmp	r3, #0
 306:	f000 8223 	beq.w	750 <SystemNavigationBackend_Predict+0x750>
 30a:	f8dd 8168 	ldr.w	r8, [sp, #360]	@ 0x168
 30e:	f8d7 23c8 	ldr.w	r2, [r7, #968]	@ 0x3c8
 312:	f8dd c16c 	ldr.w	ip, [sp, #364]	@ 0x16c
 316:	f8d7 33cc 	ldr.w	r3, [r7, #972]	@ 0x3cc
 31a:	4542      	cmp	r2, r8
 31c:	eb73 000c 	sbcs.w	r0, r3, ip
 320:	f0c0 8216 	bcc.w	750 <SystemNavigationBackend_Predict+0x750>
 324:	f8df 9064 	ldr.w	r9, [pc, #100]	@ 38c <SystemNavigationBackend_Predict+0x38c>
 328:	f89d 6209 	ldrb.w	r6, [sp, #521]	@ 0x209
 32c:	f899 0000 	ldrb.w	r0, [r9]
 330:	2800      	cmp	r0, #0
 332:	f000 8376 	beq.w	a22 <SystemNavigationBackend_Predict+0xa22>
 336:	4811      	ldr	r0, [pc, #68]	@ (37c <SystemNavigationBackend_Predict+0x37c>)
 338:	9007      	str	r0, [sp, #28]
 33a:	f890 e000 	ldrb.w	lr, [r0]
 33e:	45b6      	cmp	lr, r6
 340:	e026      	b.n	390 <SystemNavigationBackend_Predict+0x390>
 342:	bf00      	nop
 344:	7f7fffff 	.word	0x7f7fffff
 348:	3ca3d70a 	.word	0x3ca3d70a
	...
			34c: R_ARM_ABS32	.bss.s_state
			350: R_ARM_ABS32	.rodata.Backend_StateLog.str1.4
			354: R_ARM_ABS32	.bss.s_input_faulted
			358: R_ARM_ABS32	.bss.s_current_faulted
			35c: R_ARM_ABS32	.bss.s_active
 360:	49742400 	.word	0x49742400
	...
			364: R_ARM_ABS32	.bss.s_imu_quality_flags
			368: R_ARM_ABS32	.bss.s_calibration_generation
 36c:	0000000c 	.word	0x0000000c
			36c: R_ARM_ABS32	.bss.s_state
	...
			370: R_ARM_ABS32	.rodata.s_config
			374: R_ARM_ABS32	.bss.silverstar_auto_eskf_work
			378: R_ARM_ABS32	.bss.s_frame
			37c: R_ARM_ABS32	.bss.s_gnss_source
			380: R_ARM_ABS32	.bss.s_started
			384: R_ARM_ABS32	.bss.s_current_endpoint_valid
			388: R_ARM_ABS32	.bss.s_current_endpoint_rate
			38c: R_ARM_ABS32	.bss.s_gnss_seen
 390:	f000 8419 	beq.w	bc6 <SystemNavigationBackend_Predict+0xbc6>
 394:	2e03      	cmp	r6, #3
 396:	f240 8408 	bls.w	baa <SystemNavigationBackend_Predict+0xbaa>
 39a:	2301      	movs	r3, #1
 39c:	f8df a358 	ldr.w	sl, [pc, #856]	@ 6f8 <SystemNavigationBackend_Predict+0x6f8>
 3a0:	9309      	str	r3, [sp, #36]	@ 0x24
 3a2:	9b07      	ldr	r3, [sp, #28]
 3a4:	4acc      	ldr	r2, [pc, #816]	@ (6d8 <SystemNavigationBackend_Predict+0x6d8>)
 3a6:	701e      	strb	r6, [r3, #0]
 3a8:	ed9f 7bc9 	vldr	d7, [pc, #804]	@ 6d0 <SystemNavigationBackend_Predict+0x6d0>
 3ac:	4bcb      	ldr	r3, [pc, #812]	@ (6dc <SystemNavigationBackend_Predict+0x6dc>)
 3ae:	48cc      	ldr	r0, [pc, #816]	@ (6e0 <SystemNavigationBackend_Predict+0x6e0>)
 3b0:	2100      	movs	r1, #0
 3b2:	ed83 7b00 	vstr	d7, [r3]
 3b6:	6011      	str	r1, [r2, #0]
 3b8:	f7ff fffe 	bl	0 <NavigationWindow_Reset>
			3b8: R_ARM_THM_CALL	NavigationWindow_Reset
 3bc:	e9d7 23f2 	ldrd	r2, r3, [r7, #968]	@ 0x3c8
 3c0:	985d      	ldr	r0, [sp, #372]	@ 0x174
 3c2:	f8ca 0000 	str.w	r0, [sl]
 3c6:	2101      	movs	r1, #1
 3c8:	a858      	add	r0, sp, #352	@ 0x160
 3ca:	f889 1000 	strb.w	r1, [r9]
 3ce:	f7ff fffe 	bl	0 <SystemGnssQuality_Evaluate>
			3ce: R_ARM_THM_CALL	SystemGnssQuality_Evaluate
 3d2:	2800      	cmp	r0, #0
 3d4:	f040 8372 	bne.w	abc <SystemNavigationBackend_Predict+0xabc>
 3d8:	f89d 6198 	ldrb.w	r6, [sp, #408]	@ 0x198
 3dc:	f006 0c01 	and.w	ip, r6, #1
 3e0:	f006 0602 	and.w	r6, r6, #2
 3e4:	f89d 31d0 	ldrb.w	r3, [sp, #464]	@ 0x1d0
 3e8:	9a5d      	ldr	r2, [sp, #372]	@ 0x174
 3ea:	f885 31ac 	strb.w	r3, [r5, #428]	@ 0x1ac
 3ee:	e9dd 015a 	ldrd	r0, r1, [sp, #360]	@ 0x168
 3f2:	2b07      	cmp	r3, #7
 3f4:	e9c5 0162 	strd	r0, r1, [r5, #392]	@ 0x188
 3f8:	f8c5 2198 	str.w	r2, [r5, #408]	@ 0x198
 3fc:	f000 836b 	beq.w	ad6 <SystemNavigationBackend_Predict+0xad6>
 400:	f003 0303 	and.w	r3, r3, #3
 404:	f1a3 0303 	sub.w	r3, r3, #3
 408:	fab3 f383 	clz	r3, r3
 40c:	095b      	lsrs	r3, r3, #5
 40e:	005b      	lsls	r3, r3, #1
 410:	f885 31ad 	strb.w	r3, [r5, #429]	@ 0x1ad
 414:	ab6b      	add	r3, sp, #428	@ 0x1ac
 416:	cb07      	ldmia	r3!, {r0, r1, r2}
 418:	f8c5 00f4 	str.w	r0, [r5, #244]	@ 0xf4
 41c:	f8c5 10f8 	str.w	r1, [r5, #248]	@ 0xf8
 420:	f8c5 20fc 	str.w	r2, [r5, #252]	@ 0xfc
 424:	f1bc 0f00 	cmp.w	ip, #0
 428:	f000 8345 	beq.w	ab6 <SystemNavigationBackend_Predict+0xab6>
 42c:	e9dd 1267 	ldrd	r1, r2, [sp, #412]	@ 0x19c
 430:	2e00      	cmp	r6, #0
 432:	f000 833e 	beq.w	ab2 <SystemNavigationBackend_Predict+0xab2>
 436:	9b69      	ldr	r3, [sp, #420]	@ 0x1a4
 438:	a80d      	add	r0, sp, #52	@ 0x34
 43a:	9000      	str	r0, [sp, #0]
 43c:	48a9      	ldr	r0, [pc, #676]	@ (6e4 <SystemNavigationBackend_Predict+0x6e4>)
 43e:	f7ff fffe 	bl	0 <GeoLocalFrame_ToEnu>
			43e: R_ARM_THM_CALL	GeoLocalFrame_ToEnu
 442:	2800      	cmp	r0, #0
 444:	f000 83a7 	beq.w	b96 <SystemNavigationBackend_Predict+0xb96>
 448:	ab0d      	add	r3, sp, #52	@ 0x34
 44a:	cb07      	ldmia	r3!, {r0, r1, r2}
 44c:	f89d 417c 	ldrb.w	r4, [sp, #380]	@ 0x17c
 450:	f8c5 00e8 	str.w	r0, [r5, #232]	@ 0xe8
 454:	f8c5 10ec 	str.w	r1, [r5, #236]	@ 0xec
 458:	f89d 01d3 	ldrb.w	r0, [sp, #467]	@ 0x1d3
 45c:	f8c5 20f0 	str.w	r2, [r5, #240]	@ 0xf0
 460:	f3c4 0180 	ubfx	r1, r4, #2, #1
 464:	f7ff fffe 	bl	0 <NavigationQuality_SatelliteVarianceScale>
			464: R_ARM_THM_CALL	NavigationQuality_SatelliteVarianceScale
 468:	9b09      	ldr	r3, [sp, #36]	@ 0x24
 46a:	eeb0 8a40 	vmov.f32	s16, s0
 46e:	2b00      	cmp	r3, #0
 470:	f000 8333 	beq.w	ada <SystemNavigationBackend_Predict+0xada>
 474:	eef7 9a00 	vmov.f32	s19, #112	@ 0x3f800000  1.0
 478:	ae38      	add	r6, sp, #224	@ 0xe0
 47a:	f04f 0800 	mov.w	r8, #0
 47e:	ed9f 9a9a 	vldr	s18, [pc, #616]	@ 6e8 <SystemNavigationBackend_Predict+0x6e8>
 482:	9508      	str	r5, [sp, #32]
 484:	46b1      	mov	r9, r6
 486:	ac10      	add	r4, sp, #64	@ 0x40
 488:	4646      	mov	r6, r8
 48a:	fa5f fa86 	uxtb.w	sl, r6
 48e:	f00a 0801 	and.w	r8, sl, #1
 492:	f1c8 0802 	rsb	r8, r8, #2
 496:	fa5f f388 	uxtb.w	r3, r8
 49a:	9305      	str	r3, [sp, #20]
 49c:	ea4f 054a 	mov.w	r5, sl, lsl #1
 4a0:	f240 332e 	movw	r3, #814	@ 0x32e
 4a4:	2e01      	cmp	r6, #1
 4a6:	9300      	str	r3, [sp, #0]
 4a8:	f005 0502 	and.w	r5, r5, #2
 4ac:	4b8f      	ldr	r3, [pc, #572]	@ (6ec <SystemNavigationBackend_Predict+0x6ec>)
 4ae:	f04f 0202 	mov.w	r2, #2
 4b2:	f04f 0108 	mov.w	r1, #8
 4b6:	a858      	add	r0, sp, #352	@ 0x160
 4b8:	f240 8279 	bls.w	9ae <SystemNavigationBackend_Predict+0x9ae>
 4bc:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			4bc: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
 4c0:	f44f 7b87 	mov.w	fp, #270	@ 0x10e
 4c4:	2302      	movs	r3, #2
 4c6:	4a89      	ldr	r2, [pc, #548]	@ (6ec <SystemNavigationBackend_Predict+0x6ec>)
 4c8:	9300      	str	r3, [sp, #0]
 4ca:	2102      	movs	r1, #2
 4cc:	f240 332f 	movw	r3, #815	@ 0x32f
 4d0:	2001      	movs	r0, #1
 4d2:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			4d2: R_ARM_THM_CALL	SilverStarAssert_Check
 4d6:	2248      	movs	r2, #72	@ 0x48
 4d8:	2100      	movs	r1, #0
 4da:	4620      	mov	r0, r4
 4dc:	f7ff fffe 	bl	0 <memset>
			4dc: R_ARM_THM_CALL	memset
 4e0:	2278      	movs	r2, #120	@ 0x78
 4e2:	2100      	movs	r1, #0
 4e4:	a83a      	add	r0, sp, #232	@ 0xe8
 4e6:	f7ff fffe 	bl	0 <memset>
			4e6: R_ARM_THM_CALL	memset
 4ea:	9b09      	ldr	r3, [sp, #36]	@ 0x24
 4ec:	f8cd b004 	str.w	fp, [sp, #4]
 4f0:	f884 a01c 	strb.w	sl, [r4, #28]
 4f4:	9402      	str	r4, [sp, #8]
 4f6:	f889 3075 	strb.w	r3, [r9, #117]	@ 0x75
 4fa:	f89d 3198 	ldrb.w	r3, [sp, #408]	@ 0x198
 4fe:	ed89 8a16 	vstr	s16, [r9, #88]	@ 0x58
 502:	40f3      	lsrs	r3, r6
 504:	2e00      	cmp	r6, #0
 506:	f003 0301 	and.w	r3, r3, #1
 50a:	eef7 7a00 	vmov.f32	s15, #112	@ 0x3f800000  1.0
 50e:	bf08      	it	eq
 510:	eef0 7a69 	vmoveq.f32	s15, s19
 514:	7763      	strb	r3, [r4, #29]
 516:	f89d 3170 	ldrb.w	r3, [sp, #368]	@ 0x170
 51a:	edc9 7a17 	vstr	s15, [r9, #92]	@ 0x5c
 51e:	9300      	str	r3, [sp, #0]
 520:	9b5d      	ldr	r3, [sp, #372]	@ 0x174
 522:	6123      	str	r3, [r4, #16]
 524:	9b07      	ldr	r3, [sp, #28]
 526:	781b      	ldrb	r3, [r3, #0]
 528:	6163      	str	r3, [r4, #20]
 52a:	e9dd 015a 	ldrd	r0, r1, [sp, #360]	@ 0x168
 52e:	e9dd 2358 	ldrd	r2, r3, [sp, #352]	@ 0x160
 532:	e9c4 0102 	strd	r0, r1, [r4, #8]
 536:	e9c9 2300 	strd	r2, r3, [r9]
 53a:	f7ff fffe 	bl	0 <SystemTime_MeasurementTimestampResolve>
			53a: R_ARM_THM_CALL	SystemTime_MeasurementTimestampResolve
 53e:	2800      	cmp	r0, #0
 540:	f000 822c 	beq.w	99c <SystemNavigationBackend_Predict+0x99c>
 544:	f04f 0300 	mov.w	r3, #0
 548:	7763      	strb	r3, [r4, #29]
 54a:	ab0d      	add	r3, sp, #52	@ 0x34
 54c:	f105 0b13 	add.w	fp, r5, #19
 550:	eb03 0885 	add.w	r8, r3, r5, lsl #2
 554:	edd9 8a17 	vldr	s17, [r9, #92]	@ 0x5c
 558:	ab58      	add	r3, sp, #352	@ 0x160
 55a:	eb03 0b8b 	add.w	fp, r3, fp, lsl #2
 55e:	ad49      	add	r5, sp, #292	@ 0x124
 560:	f04f 0a00 	mov.w	sl, #0
 564:	2e01      	cmp	r6, #1
 566:	eef0 0a49 	vmov.f32	s1, s18
 56a:	f240 8205 	bls.w	978 <SystemNavigationBackend_Predict+0x978>
 56e:	ed9b 0a03 	vldr	s0, [fp, #12]
 572:	f7ff fffe 	bl	0 <fmaxf>
			572: R_ARM_THM_CALL	fmaxf
 576:	f8db 1000 	ldr.w	r1, [fp]
 57a:	ed85 0a00 	vstr	s0, [r5]
 57e:	ee28 0a00 	vmul.f32	s0, s16, s0
 582:	eb04 038a 	add.w	r3, r4, sl, lsl #2
 586:	ee20 0a28 	vmul.f32	s0, s0, s17
 58a:	9a05      	ldr	r2, [sp, #20]
 58c:	6219      	str	r1, [r3, #32]
 58e:	ed83 0a0a 	vstr	s0, [r3, #40]	@ 0x28
 592:	f10a 0301 	add.w	r3, sl, #1
 596:	429a      	cmp	r2, r3
 598:	f105 0504 	add.w	r5, r5, #4
 59c:	f108 0804 	add.w	r8, r8, #4
 5a0:	f10b 0b04 	add.w	fp, fp, #4
 5a4:	f04f 0a01 	mov.w	sl, #1
 5a8:	d8dc      	bhi.n	564 <SystemNavigationBackend_Predict+0x564>
 5aa:	9a08      	ldr	r2, [sp, #32]
 5ac:	4649      	mov	r1, r9
 5ae:	4620      	mov	r0, r4
 5b0:	3601      	adds	r6, #1
 5b2:	f7ff fffe 	bl	0 <SystemNavigationBackend_Predict>
			5b2: R_ARM_THM_CALL	Backend_EventApply
 5b6:	2e04      	cmp	r6, #4
 5b8:	f47f af67 	bne.w	48a <SystemNavigationBackend_Predict+0x48a>
 5bc:	2268      	movs	r2, #104	@ 0x68
 5be:	2100      	movs	r1, #0
 5c0:	4648      	mov	r0, r9
 5c2:	464e      	mov	r6, r9
 5c4:	9d08      	ldr	r5, [sp, #32]
 5c6:	e9d7 9bf2 	ldrd	r9, fp, [r7, #968]	@ 0x3c8
 5ca:	f7ff fffe 	bl	0 <memset>
			5ca: R_ARM_THM_CALL	memset
 5ce:	f240 334f 	movw	r3, #847	@ 0x34f
 5d2:	9300      	str	r3, [sp, #0]
 5d4:	4652      	mov	r2, sl
 5d6:	4b45      	ldr	r3, [pc, #276]	@ (6ec <SystemNavigationBackend_Predict+0x6ec>)
 5d8:	2108      	movs	r1, #8
 5da:	a858      	add	r0, sp, #352	@ 0x160
 5dc:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			5dc: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
 5e0:	f44f 7354 	mov.w	r3, #848	@ 0x350
 5e4:	4652      	mov	r2, sl
 5e6:	9300      	str	r3, [sp, #0]
 5e8:	2108      	movs	r1, #8
 5ea:	4b40      	ldr	r3, [pc, #256]	@ (6ec <SystemNavigationBackend_Predict+0x6ec>)
 5ec:	4630      	mov	r0, r6
 5ee:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			5ee: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
 5f2:	e9dd 015a 	ldrd	r0, r1, [sp, #360]	@ 0x168
 5f6:	f89d 2208 	ldrb.w	r2, [sp, #520]	@ 0x208
 5fa:	9b5d      	ldr	r3, [sp, #372]	@ 0x174
 5fc:	e9c6 9b04 	strd	r9, fp, [r6, #16]
 600:	e9c6 0102 	strd	r0, r1, [r6, #8]
 604:	b91a      	cbnz	r2, 60e <SystemNavigationBackend_Predict+0x60e>
 606:	9a7a      	ldr	r2, [sp, #488]	@ 0x1e8
 608:	429a      	cmp	r2, r3
 60a:	f000 82ec 	beq.w	be6 <SystemNavigationBackend_Predict+0xbe6>
 60e:	e9d6 a800 	ldrd	sl, r8, [r6]
 612:	6333      	str	r3, [r6, #48]	@ 0x30
 614:	4b36      	ldr	r3, [pc, #216]	@ (6f0 <SystemNavigationBackend_Predict+0x6f0>)
 616:	f89d 217c 	ldrb.w	r2, [sp, #380]	@ 0x17c
 61a:	681b      	ldr	r3, [r3, #0]
 61c:	f89d c209 	ldrb.w	ip, [sp, #521]	@ 0x209
 620:	63b3      	str	r3, [r6, #56]	@ 0x38
 622:	4b2f      	ldr	r3, [pc, #188]	@ (6e0 <SystemNavigationBackend_Predict+0x6e0>)
 624:	f8c6 c034 	str.w	ip, [r6, #52]	@ 0x34
 628:	f3c2 0280 	ubfx	r2, r2, #2, #1
 62c:	f89d c199 	ldrb.w	ip, [sp, #409]	@ 0x199
 630:	f886 2061 	strb.w	r2, [r6, #97]	@ 0x61
 634:	f886 c059 	strb.w	ip, [r6, #89]	@ 0x59
 638:	6f9a      	ldr	r2, [r3, #120]	@ 0x78
 63a:	f89d c19a 	ldrb.w	ip, [sp, #410]	@ 0x19a
 63e:	6fd9      	ldr	r1, [r3, #124]	@ 0x7c
 640:	f8d3 00a8 	ldr.w	r0, [r3, #168]	@ 0xa8
 644:	f886 c063 	strb.w	ip, [r6, #99]	@ 0x63
 648:	ed93 7b28 	vldr	d7, [r3, #160]	@ 0xa0
 64c:	f89d c1d3 	ldrb.w	ip, [sp, #467]	@ 0x1d3
 650:	f886 c05f 	strb.w	ip, [r6, #95]	@ 0x5f
 654:	63f0      	str	r0, [r6, #60]	@ 0x3c
 656:	f893 c0b4 	ldrb.w	ip, [r3, #180]	@ 0xb4
 65a:	f8d3 00ac 	ldr.w	r0, [r3, #172]	@ 0xac
 65e:	f886 c062 	strb.w	ip, [r6, #98]	@ 0x62
 662:	4592      	cmp	sl, r2
 664:	f04f 0c03 	mov.w	ip, #3
 668:	6430      	str	r0, [r6, #64]	@ 0x40
 66a:	eb78 0e01 	sbcs.w	lr, r8, r1
 66e:	f8d3 00b0 	ldr.w	r0, [r3, #176]	@ 0xb0
 672:	f886 c058 	strb.w	ip, [r6, #88]	@ 0x58
 676:	ed86 7b06 	vstr	d7, [r6, #24]
 67a:	f893 c099 	ldrb.w	ip, [r3, #153]	@ 0x99
 67e:	6232      	str	r2, [r6, #32]
 680:	6271      	str	r1, [r6, #36]	@ 0x24
 682:	6470      	str	r0, [r6, #68]	@ 0x44
 684:	f080 81f8 	bcs.w	a78 <SystemNavigationBackend_Predict+0xa78>
 688:	f04f 30ff 	mov.w	r0, #4294967295
 68c:	f04f 31ff 	mov.w	r1, #4294967295
 690:	e9c6 010a 	strd	r0, r1, [r6, #40]	@ 0x28
 694:	f1bc 0f00 	cmp.w	ip, #0
 698:	d001      	beq.n	69e <SystemNavigationBackend_Predict+0x69e>
 69a:	2204      	movs	r2, #4
 69c:	9206      	str	r2, [sp, #24]
 69e:	9a06      	ldr	r2, [sp, #24]
 6a0:	f886 2060 	strb.w	r2, [r6, #96]	@ 0x60
 6a4:	2200      	movs	r2, #0
 6a6:	f886 205e 	strb.w	r2, [r6, #94]	@ 0x5e
 6aa:	f04f 527e 	mov.w	r2, #1065353216	@ 0x3f800000
 6ae:	6572      	str	r2, [r6, #84]	@ 0x54
 6b0:	4a10      	ldr	r2, [pc, #64]	@ (6f4 <SystemNavigationBackend_Predict+0x6f4>)
 6b2:	f8d3 c088 	ldr.w	ip, [r3, #136]	@ 0x88
 6b6:	e892 0003 	ldmia.w	r2, {r0, r1}
 6ba:	ab4a      	add	r3, sp, #296	@ 0x128
 6bc:	e883 0003 	stmia.w	r3, {r0, r1}
 6c0:	f04f 0800 	mov.w	r8, #0
 6c4:	f8c6 c050 	str.w	ip, [r6, #80]	@ 0x50
 6c8:	e018      	b.n	6fc <SystemNavigationBackend_Predict+0x6fc>
 6ca:	bf00      	nop
 6cc:	f3af 8000 	nop.w
	...
			6d8: R_ARM_ABS32	.bss.s_native_tow_ms
			6dc: R_ARM_ABS32	.bss.s_native_week_us
			6e0: R_ARM_ABS32	.bss.silverstar_auto_eskf_window
			6e4: R_ARM_ABS32	.bss.s_frame
 6e8:	3cb851ec 	.word	0x3cb851ec
	...
			6ec: R_ARM_ABS32	.rodata.Backend_StateLog.str1.4
			6f0: R_ARM_ABS32	.bss.s_calibration_generation
 6f4:	00000080 	.word	0x00000080
			6f4: R_ARM_ABS32	.bss.silverstar_auto_eskf_window
 6f8:	00000000 	.word	0x00000000
			6f8: R_ARM_ABS32	.bss.s_gnss_sequence
 6fc:	9400      	str	r4, [sp, #0]
 6fe:	464a      	mov	r2, r9
 700:	465b      	mov	r3, fp
 702:	fa5f f088 	uxtb.w	r0, r8
 706:	f7ff fffe 	bl	0 <SystemNavigationHealth_GroupGet>
			706: R_ARM_THM_CALL	SystemNavigationHealth_GroupGet
 70a:	b920      	cbnz	r0, 716 <SystemNavigationBackend_Predict+0x716>
 70c:	6aa2      	ldr	r2, [r4, #40]	@ 0x28
 70e:	9b5d      	ldr	r3, [sp, #372]	@ 0x174
 710:	429a      	cmp	r2, r3
 712:	f000 815a 	beq.w	9ca <SystemNavigationBackend_Predict+0x9ca>
 716:	f108 0801 	add.w	r8, r8, #1
 71a:	f1b8 0f04 	cmp.w	r8, #4
 71e:	d1ed      	bne.n	6fc <SystemNavigationBackend_Predict+0x6fc>
 720:	2300      	movs	r3, #0
 722:	220f      	movs	r2, #15
 724:	4659      	mov	r1, fp
 726:	4648      	mov	r0, r9
 728:	f7ff fffe 	bl	0 <SystemNavigationHealth_OverallGet>
			728: R_ARM_THM_CALL	SystemNavigationHealth_OverallGet
 72c:	4603      	mov	r3, r0
 72e:	f886 305d 	strb.w	r3, [r6, #93]	@ 0x5d
 732:	3b04      	subs	r3, #4
 734:	bf18      	it	ne
 736:	2301      	movne	r3, #1
 738:	4648      	mov	r0, r9
 73a:	4659      	mov	r1, fp
 73c:	f886 305c 	strb.w	r3, [r6, #92]	@ 0x5c
 740:	4632      	mov	r2, r6
 742:	f7ff fffe 	bl	0 <LoggerBus_NavigationQualityPush>
			742: R_ARM_THM_CALL	LoggerBus_NavigationQualityPush
 746:	b118      	cbz	r0, 750 <SystemNavigationBackend_Predict+0x750>
 748:	4abd      	ldr	r2, [pc, #756]	@ (a40 <SystemNavigationBackend_Predict+0xa40>)
 74a:	6813      	ldr	r3, [r2, #0]
 74c:	3301      	adds	r3, #1
 74e:	6013      	str	r3, [r2, #0]
 750:	4bbc      	ldr	r3, [pc, #752]	@ (a44 <SystemNavigationBackend_Predict+0xa44>)
 752:	781b      	ldrb	r3, [r3, #0]
 754:	2b00      	cmp	r3, #0
 756:	f040 80ff 	bne.w	958 <SystemNavigationBackend_Predict+0x958>
 75a:	4bbb      	ldr	r3, [pc, #748]	@ (a48 <SystemNavigationBackend_Predict+0xa48>)
 75c:	781b      	ldrb	r3, [r3, #0]
 75e:	2b00      	cmp	r3, #0
 760:	f000 80ab 	beq.w	8ba <SystemNavigationBackend_Predict+0x8ba>
 764:	ac10      	add	r4, sp, #64	@ 0x40
 766:	4620      	mov	r0, r4
 768:	f7ff fffe 	bl	0 <EstimatorBus_PressureGetLatest>
			768: R_ARM_THM_CALL	EstimatorBus_PressureGetLatest
 76c:	2800      	cmp	r0, #0
 76e:	f000 80a4 	beq.w	8ba <SystemNavigationBackend_Predict+0x8ba>
 772:	68a1      	ldr	r1, [r4, #8]
 774:	f8d7 03c8 	ldr.w	r0, [r7, #968]	@ 0x3c8
 778:	68e2      	ldr	r2, [r4, #12]
 77a:	f8d7 33cc 	ldr.w	r3, [r7, #972]	@ 0x3cc
 77e:	4288      	cmp	r0, r1
 780:	4193      	sbcs	r3, r2
 782:	f0c0 809a 	bcc.w	8ba <SystemNavigationBackend_Predict+0x8ba>
 786:	f8df b2e8 	ldr.w	fp, [pc, #744]	@ a70 <SystemNavigationBackend_Predict+0xa70>
 78a:	4eb0      	ldr	r6, [pc, #704]	@ (a4c <SystemNavigationBackend_Predict+0xa4c>)
 78c:	f89b 3000 	ldrb.w	r3, [fp]
 790:	b123      	cbz	r3, 79c <SystemNavigationBackend_Predict+0x79c>
 792:	6962      	ldr	r2, [r4, #20]
 794:	6833      	ldr	r3, [r6, #0]
 796:	429a      	cmp	r2, r3
 798:	f000 808f 	beq.w	8ba <SystemNavigationBackend_Predict+0x8ba>
 79c:	f894 0035 	ldrb.w	r0, [r4, #53]	@ 0x35
 7a0:	4aab      	ldr	r2, [pc, #684]	@ (a50 <SystemNavigationBackend_Predict+0xa50>)
 7a2:	2801      	cmp	r0, #1
 7a4:	f04f 0805 	mov.w	r8, #5
 7a8:	bf8c      	ite	hi
 7aa:	2000      	movhi	r0, #0
 7ac:	2001      	movls	r0, #1
 7ae:	f8cd 8000 	str.w	r8, [sp]
 7b2:	f44f 737a 	mov.w	r3, #1000	@ 0x3e8
 7b6:	2102      	movs	r1, #2
 7b8:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			7b8: R_ARM_THM_CALL	SilverStarAssert_Check
 7bc:	f8cd 8000 	str.w	r8, [sp]
 7c0:	f894 0034 	ldrb.w	r0, [r4, #52]	@ 0x34
 7c4:	4aa2      	ldr	r2, [pc, #648]	@ (a50 <SystemNavigationBackend_Predict+0xa50>)
 7c6:	2801      	cmp	r0, #1
 7c8:	bf8c      	ite	hi
 7ca:	2000      	movhi	r0, #0
 7cc:	2001      	movls	r0, #1
 7ce:	f240 33e9 	movw	r3, #1001	@ 0x3e9
 7d2:	2102      	movs	r1, #2
 7d4:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			7d4: R_ARM_THM_CALL	SilverStarAssert_Check
 7d8:	4b9e      	ldr	r3, [pc, #632]	@ (a54 <SystemNavigationBackend_Predict+0xa54>)
 7da:	ed94 8a09 	vldr	s16, [r4, #36]	@ 0x24
 7de:	edd3 7a00 	vldr	s15, [r3]
 7e2:	f8d4 8014 	ldr.w	r8, [r4, #20]
 7e6:	f8c6 8000 	str.w	r8, [r6]
 7ea:	ee38 8a67 	vsub.f32	s16, s16, s15
 7ee:	ae38      	add	r6, sp, #224	@ 0xe0
 7f0:	f8d4 9008 	ldr.w	r9, [r4, #8]
 7f4:	f8d4 a00c 	ldr.w	sl, [r4, #12]
 7f8:	ed85 8a40 	vstr	s16, [r5, #256]	@ 0x100
 7fc:	2301      	movs	r3, #1
 7fe:	2248      	movs	r2, #72	@ 0x48
 800:	2100      	movs	r1, #0
 802:	f8c5 819c 	str.w	r8, [r5, #412]	@ 0x19c
 806:	f8c5 9190 	str.w	r9, [r5, #400]	@ 0x190
 80a:	f8c5 a194 	str.w	sl, [r5, #404]	@ 0x194
 80e:	4630      	mov	r0, r6
 810:	f88b 3000 	strb.w	r3, [fp]
 814:	f7ff fffe 	bl	0 <memset>
			814: R_ARM_THM_CALL	memset
 818:	2278      	movs	r2, #120	@ 0x78
 81a:	2100      	movs	r1, #0
 81c:	a85a      	add	r0, sp, #360	@ 0x168
 81e:	f7ff fffe 	bl	0 <memset>
			81e: R_ARM_THM_CALL	memset
 822:	2301      	movs	r3, #1
 824:	6173      	str	r3, [r6, #20]
 826:	f894 3035 	ldrb.w	r3, [r4, #53]	@ 0x35
 82a:	f8c6 8010 	str.w	r8, [r6, #16]
 82e:	2204      	movs	r2, #4
 830:	e9c6 9a02 	strd	r9, sl, [r6, #8]
 834:	7732      	strb	r2, [r6, #28]
 836:	b17b      	cbz	r3, 858 <SystemNavigationBackend_Predict+0x858>
 838:	f894 3034 	ldrb.w	r3, [r4, #52]	@ 0x34
 83c:	b163      	cbz	r3, 858 <SystemNavigationBackend_Predict+0x858>
 83e:	e9d7 23f2 	ldrd	r2, r3, [r7, #968]	@ 0x3c8
 842:	4985      	ldr	r1, [pc, #532]	@ (a58 <SystemNavigationBackend_Predict+0xa58>)
 844:	ebb2 0209 	subs.w	r2, r2, r9
 848:	eb63 030a 	sbc.w	r3, r3, sl
 84c:	428a      	cmp	r2, r1
 84e:	f173 0300 	sbcs.w	r3, r3, #0
 852:	bf34      	ite	cc
 854:	2301      	movcc	r3, #1
 856:	2300      	movcs	r3, #0
 858:	ed94 0a0a 	vldr	s0, [r4, #40]	@ 0x28
 85c:	7773      	strb	r3, [r6, #29]
 85e:	eef1 0a09 	vmov.f32	s1, #25	@ 0x40c80000  6.250
 862:	ed86 8a08 	vstr	s16, [r6, #32]
 866:	f7ff fffe 	bl	0 <fmaxf>
			866: R_ARM_THM_CALL	fmaxf
 86a:	464a      	mov	r2, r9
 86c:	4641      	mov	r1, r8
 86e:	e9dd 8910 	ldrd	r8, r9, [sp, #64]	@ 0x40
 872:	4653      	mov	r3, sl
 874:	4879      	ldr	r0, [pc, #484]	@ (a5c <SystemNavigationBackend_Predict+0xa5c>)
 876:	ed86 0a0a 	vstr	s0, [r6, #40]	@ 0x28
 87a:	e9cd 8958 	strd	r8, r9, [sp, #352]	@ 0x160
 87e:	f7ff fffe 	bl	0 <SystemNavigationBackend_Predict>
			87e: R_ARM_THM_CALL	Backend_CurrentPacketAdmit
 882:	9602      	str	r6, [sp, #8]
 884:	6ab3      	ldr	r3, [r6, #40]	@ 0x28
 886:	9369      	str	r3, [sp, #420]	@ 0x1a4
 888:	2700      	movs	r7, #0
 88a:	7c23      	ldrb	r3, [r4, #16]
 88c:	9300      	str	r3, [sp, #0]
 88e:	9701      	str	r7, [sp, #4]
 890:	f04f 537e 	mov.w	r3, #1065353216	@ 0x3f800000
 894:	f88d 01d5 	strb.w	r0, [sp, #469]	@ 0x1d5
 898:	936e      	str	r3, [sp, #440]	@ 0x1b8
 89a:	936f      	str	r3, [sp, #444]	@ 0x1bc
 89c:	e9d6 0102 	ldrd	r0, r1, [r6, #8]
 8a0:	e9dd 2310 	ldrd	r2, r3, [sp, #64]	@ 0x40
 8a4:	f7ff fffe 	bl	0 <SystemTime_MeasurementTimestampResolve>
			8a4: R_ARM_THM_CALL	SystemTime_MeasurementTimestampResolve
 8a8:	2800      	cmp	r0, #0
 8aa:	f000 810c 	beq.w	ac6 <SystemNavigationBackend_Predict+0xac6>
 8ae:	7777      	strb	r7, [r6, #29]
 8b0:	a958      	add	r1, sp, #352	@ 0x160
 8b2:	4630      	mov	r0, r6
 8b4:	462a      	mov	r2, r5
 8b6:	f7ff fffe 	bl	0 <SystemNavigationBackend_Predict>
			8b6: R_ARM_THM_CALL	Backend_EventApply
 8ba:	4b69      	ldr	r3, [pc, #420]	@ (a60 <SystemNavigationBackend_Predict+0xa60>)
 8bc:	781b      	ldrb	r3, [r3, #0]
 8be:	2b00      	cmp	r3, #0
 8c0:	d14a      	bne.n	958 <SystemNavigationBackend_Predict+0x958>
 8c2:	f8d5 2160 	ldr.w	r2, [r5, #352]	@ 0x160
 8c6:	68ab      	ldr	r3, [r5, #8]
 8c8:	3201      	adds	r2, #1
 8ca:	3301      	adds	r3, #1
 8cc:	f8c5 2160 	str.w	r2, [r5, #352]	@ 0x160
 8d0:	60ab      	str	r3, [r5, #8]
 8d2:	4628      	mov	r0, r5
 8d4:	f7ff fffe 	bl	0 <SystemNavigationBackend_Predict>
			8d4: R_ARM_THM_CALL	SystemNavigationBackend_SnapshotGet
 8d8:	4604      	mov	r4, r0
 8da:	2800      	cmp	r0, #0
 8dc:	d16f      	bne.n	9be <SystemNavigationBackend_Predict+0x9be>
 8de:	f7ff fffe 	bl	0 <SystemNavigationBackend_Predict>
			8de: R_ARM_THM_CALL	Backend_StateLog
 8e2:	e000      	b.n	8e6 <SystemNavigationBackend_Predict+0x8e6>
 8e4:	2405      	movs	r4, #5
 8e6:	4620      	mov	r0, r4
 8e8:	f50d 7d05 	add.w	sp, sp, #532	@ 0x214
 8ec:	ecbd 8b04 	vpop	{d8-d9}
 8f0:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 8f4:	2402      	movs	r4, #2
 8f6:	4620      	mov	r0, r4
 8f8:	f50d 7d05 	add.w	sp, sp, #532	@ 0x214
 8fc:	ecbd 8b04 	vpop	{d8-d9}
 900:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 904:	f8d5 3180 	ldr.w	r3, [r5, #384]	@ 0x180
 908:	4956      	ldr	r1, [pc, #344]	@ (a64 <SystemNavigationBackend_Predict+0xa64>)
 90a:	2200      	movs	r2, #0
 90c:	f043 0308 	orr.w	r3, r3, #8
 910:	f8a5 21a8 	strh.w	r2, [r5, #424]	@ 0x1a8
 914:	f8c5 3180 	str.w	r3, [r5, #384]	@ 0x180
 918:	2010      	movs	r0, #16
 91a:	700a      	strb	r2, [r1, #0]
 91c:	2408      	movs	r4, #8
 91e:	f7ff fffe 	bl	0 <SystemNavigationHealth_ImuQualityRecord>
			91e: R_ARM_THM_CALL	SystemNavigationHealth_ImuQualityRecord
 922:	e7e0      	b.n	8e6 <SystemNavigationBackend_Predict+0x8e6>
 924:	4a46      	ldr	r2, [pc, #280]	@ (a40 <SystemNavigationBackend_Predict+0xa40>)
 926:	6813      	ldr	r3, [r2, #0]
 928:	3301      	adds	r3, #1
 92a:	6013      	str	r3, [r2, #0]
 92c:	e472      	b.n	214 <SystemNavigationBackend_Predict+0x214>
 92e:	e9d6 010e 	ldrd	r0, r1, [r6, #56]	@ 0x38
 932:	4b4d      	ldr	r3, [pc, #308]	@ (a68 <SystemNavigationBackend_Predict+0xa68>)
 934:	e9c7 01f2 	strd	r0, r1, [r7, #968]	@ 0x3c8
 938:	e9c3 0100 	strd	r0, r1, [r3]
 93c:	f7ff fffe 	bl	0 <SystemNavigationHealth_EpochSet>
			93c: R_ARM_THM_CALL	SystemNavigationHealth_EpochSet
 940:	2001      	movs	r0, #1
 942:	f7ff fffe 	bl	0 <SystemNavigationBackend_Predict>
			942: R_ARM_THM_CALL	Backend_StateLog
 946:	2301      	movs	r3, #1
 948:	f888 3000 	strb.w	r3, [r8]
 94c:	e419      	b.n	182 <SystemNavigationBackend_Predict+0x182>
 94e:	4a44      	ldr	r2, [pc, #272]	@ (a60 <SystemNavigationBackend_Predict+0xa60>)
 950:	2301      	movs	r3, #1
 952:	7013      	strb	r3, [r2, #0]
 954:	ed87 8bf2 	vstr	d8, [r7, #968]	@ 0x3c8
 958:	f8d5 3180 	ldr.w	r3, [r5, #384]	@ 0x180
 95c:	f043 0308 	orr.w	r3, r3, #8
 960:	2200      	movs	r2, #0
 962:	f8c5 3180 	str.w	r3, [r5, #384]	@ 0x180
 966:	4b3f      	ldr	r3, [pc, #252]	@ (a64 <SystemNavigationBackend_Predict+0xa64>)
 968:	f8a5 21a8 	strh.w	r2, [r5, #424]	@ 0x1a8
 96c:	2010      	movs	r0, #16
 96e:	701a      	strb	r2, [r3, #0]
 970:	2408      	movs	r4, #8
 972:	f7ff fffe 	bl	0 <SystemNavigationHealth_ImuQualityRecord>
			972: R_ARM_THM_CALL	SystemNavigationHealth_ImuQualityRecord
 976:	e7b6      	b.n	8e6 <SystemNavigationBackend_Predict+0x8e6>
 978:	eddd 0a72 	vldr	s1, [sp, #456]	@ 0x1c8
 97c:	eddd 7a71 	vldr	s15, [sp, #452]	@ 0x1c4
 980:	b9d6      	cbnz	r6, 9b8 <SystemNavigationBackend_Predict+0x9b8>
 982:	eef0 0a67 	vmov.f32	s1, s15
 986:	eeb7 0a08 	vmov.f32	s0, #120	@ 0x3fc00000  1.5
 98a:	f7ff fffe 	bl	0 <fmaxf>
			98a: R_ARM_THM_CALL	fmaxf
 98e:	ee20 0a00 	vmul.f32	s0, s0, s0
 992:	f8d8 1000 	ldr.w	r1, [r8]
 996:	ed85 0a00 	vstr	s0, [r5]
 99a:	e5f0      	b.n	57e <SystemNavigationBackend_Predict+0x57e>
 99c:	f89d 3170 	ldrb.w	r3, [sp, #368]	@ 0x170
 9a0:	2b00      	cmp	r3, #0
 9a2:	bf0c      	ite	eq
 9a4:	2309      	moveq	r3, #9
 9a6:	2305      	movne	r3, #5
 9a8:	f889 3074 	strb.w	r3, [r9, #116]	@ 0x74
 9ac:	e5cd      	b.n	54a <SystemNavigationBackend_Predict+0x54a>
 9ae:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			9ae: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
 9b2:	f04f 0b00 	mov.w	fp, #0
 9b6:	e585      	b.n	4c4 <SystemNavigationBackend_Predict+0x4c4>
 9b8:	eeb0 0a04 	vmov.f32	s0, #4	@ 0x40200000  2.5
 9bc:	e7e5      	b.n	98a <SystemNavigationBackend_Predict+0x98a>
 9be:	240b      	movs	r4, #11
 9c0:	e791      	b.n	8e6 <SystemNavigationBackend_Predict+0x8e6>
 9c2:	4a20      	ldr	r2, [pc, #128]	@ (a44 <SystemNavigationBackend_Predict+0xa44>)
 9c4:	2301      	movs	r3, #1
 9c6:	7013      	strb	r3, [r2, #0]
 9c8:	e7c6      	b.n	958 <SystemNavigationBackend_Predict+0x958>
 9ca:	e9d4 0200 	ldrd	r0, r2, [r4]
 9ce:	e9dd 135a 	ldrd	r1, r3, [sp, #360]	@ 0x168
 9d2:	429a      	cmp	r2, r3
 9d4:	bf08      	it	eq
 9d6:	4288      	cmpeq	r0, r1
 9d8:	f47f ae9d 	bne.w	716 <SystemNavigationBackend_Predict+0x716>
 9dc:	e9d4 2304 	ldrd	r2, r3, [r4, #16]
 9e0:	459b      	cmp	fp, r3
 9e2:	bf08      	it	eq
 9e4:	4591      	cmpeq	r9, r2
 9e6:	d107      	bne.n	9f8 <SystemNavigationBackend_Predict+0x9f8>
 9e8:	f896 305a 	ldrb.w	r3, [r6, #90]	@ 0x5a
 9ec:	2201      	movs	r2, #1
 9ee:	fa02 f208 	lsl.w	r2, r2, r8
 9f2:	4313      	orrs	r3, r2
 9f4:	f886 305a 	strb.w	r3, [r6, #90]	@ 0x5a
 9f8:	f894 303b 	ldrb.w	r3, [r4, #59]	@ 0x3b
 9fc:	2b00      	cmp	r3, #0
 9fe:	f43f ae8a 	beq.w	716 <SystemNavigationBackend_Predict+0x716>
 a02:	e9d4 2306 	ldrd	r2, r3, [r4, #24]
 a06:	459b      	cmp	fp, r3
 a08:	bf08      	it	eq
 a0a:	4591      	cmpeq	r9, r2
 a0c:	f47f ae83 	bne.w	716 <SystemNavigationBackend_Predict+0x716>
 a10:	f896 305b 	ldrb.w	r3, [r6, #91]	@ 0x5b
 a14:	2201      	movs	r2, #1
 a16:	fa02 f208 	lsl.w	r2, r2, r8
 a1a:	4313      	orrs	r3, r2
 a1c:	f886 305b 	strb.w	r3, [r6, #91]	@ 0x5b
 a20:	e679      	b.n	716 <SystemNavigationBackend_Predict+0x716>
 a22:	4b12      	ldr	r3, [pc, #72]	@ (a6c <SystemNavigationBackend_Predict+0xa6c>)
 a24:	9307      	str	r3, [sp, #28]
 a26:	2e03      	cmp	r6, #3
 a28:	f240 80bf 	bls.w	baa <SystemNavigationBackend_Predict+0xbaa>
 a2c:	2301      	movs	r3, #1
 a2e:	f8df a044 	ldr.w	sl, [pc, #68]	@ a74 <SystemNavigationBackend_Predict+0xa74>
 a32:	9309      	str	r3, [sp, #36]	@ 0x24
 a34:	9b07      	ldr	r3, [sp, #28]
 a36:	781b      	ldrb	r3, [r3, #0]
 a38:	42b3      	cmp	r3, r6
 a3a:	f43f acbf 	beq.w	3bc <SystemNavigationBackend_Predict+0x3bc>
 a3e:	e4b0      	b.n	3a2 <SystemNavigationBackend_Predict+0x3a2>
	...
			a40: R_ARM_ABS32	.bss.s_log_failures
			a44: R_ARM_ABS32	.bss.s_input_faulted
			a48: R_ARM_ABS32	.bss.s_baro_origin_valid
			a4c: R_ARM_ABS32	.bss.s_baro_sequence
			a50: R_ARM_ABS32	.rodata.Backend_StateLog.str1.4
			a54: R_ARM_ABS32	.bss.s_baro_origin
 a58:	0007a121 	.word	0x0007a121
	...
			a5c: R_ARM_ABS32	.bss.s_current_baro
			a60: R_ARM_ABS32	.bss.s_current_faulted
			a64: R_ARM_ABS32	.bss.s_active
			a68: R_ARM_ABS32	.bss.s_current_epoch_start_us
			a6c: R_ARM_ABS32	.bss.s_gnss_source
			a70: R_ARM_ABS32	.bss.s_baro_seen
			a74: R_ARM_ABS32	.bss.s_gnss_sequence
 a78:	ebba 0202 	subs.w	r2, sl, r2
 a7c:	eb68 0101 	sbc.w	r1, r8, r1
 a80:	e9c6 210a 	strd	r2, r1, [r6, #40]	@ 0x28
 a84:	f1bc 0f00 	cmp.w	ip, #0
 a88:	f43f ae09 	beq.w	69e <SystemNavigationBackend_Predict+0x69e>
 a8c:	ea5a 0008 	orrs.w	r0, sl, r8
 a90:	f43f ae03 	beq.w	69a <SystemNavigationBackend_Predict+0x69a>
 a94:	f8df c1a8 	ldr.w	ip, [pc, #424]	@ c40 <SystemNavigationBackend_Predict+0xc40>
 a98:	2000      	movs	r0, #0
 a9a:	4594      	cmp	ip, r2
 a9c:	4188      	sbcs	r0, r1
 a9e:	f4ff adfc 	bcc.w	69a <SystemNavigationBackend_Predict+0x69a>
 aa2:	2201      	movs	r2, #1
 aa4:	f886 205e 	strb.w	r2, [r6, #94]	@ 0x5e
 aa8:	f886 2060 	strb.w	r2, [r6, #96]	@ 0x60
 aac:	f8d3 208c 	ldr.w	r2, [r3, #140]	@ 0x8c
 ab0:	e5fd      	b.n	6ae <SystemNavigationBackend_Predict+0x6ae>
 ab2:	68a3      	ldr	r3, [r4, #8]
 ab4:	e4c0      	b.n	438 <SystemNavigationBackend_Predict+0x438>
 ab6:	e9d4 1200 	ldrd	r1, r2, [r4]
 aba:	e4b9      	b.n	430 <SystemNavigationBackend_Predict+0x430>
 abc:	2600      	movs	r6, #0
 abe:	f8ad 6198 	strh.w	r6, [sp, #408]	@ 0x198
 ac2:	46b4      	mov	ip, r6
 ac4:	e48e      	b.n	3e4 <SystemNavigationBackend_Predict+0x3e4>
 ac6:	7c23      	ldrb	r3, [r4, #16]
 ac8:	2b00      	cmp	r3, #0
 aca:	bf0c      	ite	eq
 acc:	2309      	moveq	r3, #9
 ace:	2305      	movne	r3, #5
 ad0:	f88d 31d4 	strb.w	r3, [sp, #468]	@ 0x1d4
 ad4:	e6ec      	b.n	8b0 <SystemNavigationBackend_Predict+0x8b0>
 ad6:	2303      	movs	r3, #3
 ad8:	e49a      	b.n	410 <SystemNavigationBackend_Predict+0x410>
 ada:	f44f 73c5 	mov.w	r3, #394	@ 0x18a
 ade:	9300      	str	r3, [sp, #0]
 ae0:	2202      	movs	r2, #2
 ae2:	4b4e      	ldr	r3, [pc, #312]	@ (c1c <SystemNavigationBackend_Predict+0xc1c>)
 ae4:	2108      	movs	r1, #8
 ae6:	a858      	add	r0, sp, #352	@ 0x160
 ae8:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			ae8: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
 aec:	f240 138b 	movw	r3, #395	@ 0x18b
 af0:	9300      	str	r3, [sp, #0]
 af2:	2202      	movs	r2, #2
 af4:	4b49      	ldr	r3, [pc, #292]	@ (c1c <SystemNavigationBackend_Predict+0xc1c>)
 af6:	2104      	movs	r1, #4
 af8:	a80d      	add	r0, sp, #52	@ 0x34
 afa:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			afa: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
 afe:	f89d 3208 	ldrb.w	r3, [sp, #520]	@ 0x208
 b02:	2b00      	cmp	r3, #0
 b04:	f47f acb6 	bne.w	474 <SystemNavigationBackend_Predict+0x474>
 b08:	9a5d      	ldr	r2, [sp, #372]	@ 0x174
 b0a:	9b7a      	ldr	r3, [sp, #488]	@ 0x1e8
 b0c:	4293      	cmp	r3, r2
 b0e:	f47f acb1 	bne.w	474 <SystemNavigationBackend_Predict+0x474>
 b12:	9c7b      	ldr	r4, [sp, #492]	@ 0x1ec
 b14:	4b42      	ldr	r3, [pc, #264]	@ (c20 <SystemNavigationBackend_Predict+0xc20>)
 b16:	429c      	cmp	r4, r3
 b18:	f63f acac 	bhi.w	474 <SystemNavigationBackend_Predict+0x474>
 b1c:	4e41      	ldr	r6, [pc, #260]	@ (c24 <SystemNavigationBackend_Predict+0xc24>)
 b1e:	6833      	ldr	r3, [r6, #0]
 b20:	429c      	cmp	r4, r3
 b22:	d36d      	bcc.n	c00 <SystemNavigationBackend_Predict+0xc00>
 b24:	4b40      	ldr	r3, [pc, #256]	@ (c28 <SystemNavigationBackend_Predict+0xc28>)
 b26:	6034      	str	r4, [r6, #0]
 b28:	e9d3 1300 	ldrd	r1, r3, [r3]
 b2c:	f44f 707a 	mov.w	r0, #1000	@ 0x3e8
 b30:	ae38      	add	r6, sp, #224	@ 0xe0
 b32:	fbe4 1300 	umlal	r1, r3, r4, r0
 b36:	f04f 0c00 	mov.w	ip, #0
 b3a:	f8ad c106 	strh.w	ip, [sp, #262]	@ 0x106
 b3e:	f8d7 03d4 	ldr.w	r0, [r7, #980]	@ 0x3d4
 b42:	6130      	str	r0, [r6, #16]
 b44:	e9c6 1300 	strd	r1, r3, [r6]
 b48:	a90d      	add	r1, sp, #52	@ 0x34
 b4a:	c903      	ldmia	r1, {r0, r1}
 b4c:	f89d 4209 	ldrb.w	r4, [sp, #521]	@ 0x209
 b50:	f89d 3198 	ldrb.w	r3, [sp, #408]	@ 0x198
 b54:	f10d 0cf4 	add.w	ip, sp, #244	@ 0xf4
 b58:	e9c6 2402 	strd	r2, r4, [r6, #8]
 b5c:	e88c 0003 	stmia.w	ip, {r0, r1}
 b60:	a96b      	add	r1, sp, #428	@ 0x1ac
 b62:	c903      	ldmia	r1, {r0, r1}
 b64:	f003 0e01 	and.w	lr, r3, #1
 b68:	ac3f      	add	r4, sp, #252	@ 0xfc
 b6a:	f3c3 0380 	ubfx	r3, r3, #2, #1
 b6e:	e884 0003 	stmia.w	r4, {r0, r1}
 b72:	4632      	mov	r2, r6
 b74:	492d      	ldr	r1, [pc, #180]	@ (c2c <SystemNavigationBackend_Predict+0xc2c>)
 b76:	f886 e024 	strb.w	lr, [r6, #36]	@ 0x24
 b7a:	f886 3025 	strb.w	r3, [r6, #37]	@ 0x25
 b7e:	482c      	ldr	r0, [pc, #176]	@ (c30 <SystemNavigationBackend_Predict+0xc30>)
 b80:	f7ff fffe 	bl	0 <NavigationWindow_Receive>
			b80: R_ARM_THM_CALL	NavigationWindow_Receive
 b84:	e9dd 2338 	ldrd	r2, r3, [sp, #224]	@ 0xe0
 b88:	4928      	ldr	r1, [pc, #160]	@ (c2c <SystemNavigationBackend_Predict+0xc2c>)
 b8a:	4829      	ldr	r0, [pc, #164]	@ (c30 <SystemNavigationBackend_Predict+0xc30>)
 b8c:	f7ff fffe 	bl	0 <NavigationWindow_VarianceScale>
			b8c: R_ARM_THM_CALL	NavigationWindow_VarianceScale
 b90:	eef0 9a40 	vmov.f32	s19, s0
 b94:	e471      	b.n	47a <SystemNavigationBackend_Predict+0x47a>
 b96:	f89d 3198 	ldrb.w	r3, [sp, #408]	@ 0x198
 b9a:	900f      	str	r0, [sp, #60]	@ 0x3c
 b9c:	f023 0303 	bic.w	r3, r3, #3
 ba0:	e9cd 000d 	strd	r0, r0, [sp, #52]	@ 0x34
 ba4:	f88d 3198 	strb.w	r3, [sp, #408]	@ 0x198
 ba8:	e44e      	b.n	448 <SystemNavigationBackend_Predict+0x448>
 baa:	f8dd b174 	ldr.w	fp, [sp, #372]	@ 0x174
 bae:	f8df a094 	ldr.w	sl, [pc, #148]	@ c44 <SystemNavigationBackend_Predict+0xc44>
 bb2:	4820      	ldr	r0, [pc, #128]	@ (c34 <SystemNavigationBackend_Predict+0xc34>)
 bb4:	4642      	mov	r2, r8
 bb6:	4663      	mov	r3, ip
 bb8:	4659      	mov	r1, fp
 bba:	eb00 00c6 	add.w	r0, r0, r6, lsl #3
 bbe:	f7ff fffe 	bl	0 <SystemNavigationBackend_Predict>
			bbe: R_ARM_THM_CALL	Backend_CurrentPacketAdmit
 bc2:	9009      	str	r0, [sp, #36]	@ 0x24
 bc4:	e736      	b.n	a34 <SystemNavigationBackend_Predict+0xa34>
 bc6:	f8df a07c 	ldr.w	sl, [pc, #124]	@ c44 <SystemNavigationBackend_Predict+0xc44>
 bca:	985d      	ldr	r0, [sp, #372]	@ 0x174
 bcc:	f8da 1000 	ldr.w	r1, [sl]
 bd0:	4288      	cmp	r0, r1
 bd2:	4683      	mov	fp, r0
 bd4:	f43f adbc 	beq.w	750 <SystemNavigationBackend_Predict+0x750>
 bd8:	f1be 0f03 	cmp.w	lr, #3
 bdc:	d9e9      	bls.n	bb2 <SystemNavigationBackend_Predict+0xbb2>
 bde:	2101      	movs	r1, #1
 be0:	9109      	str	r1, [sp, #36]	@ 0x24
 be2:	f7ff bbee 	b.w	3c2 <SystemNavigationBackend_Predict+0x3c2>
 be6:	4910      	ldr	r1, [pc, #64]	@ (c28 <SystemNavigationBackend_Predict+0xc28>)
 be8:	e9d1 0200 	ldrd	r0, r2, [r1]
 bec:	4690      	mov	r8, r2
 bee:	9a7b      	ldr	r2, [sp, #492]	@ 0x1ec
 bf0:	f44f 717a 	mov.w	r1, #1000	@ 0x3e8
 bf4:	fbe2 0801 	umlal	r0, r8, r2, r1
 bf8:	e9c6 0800 	strd	r0, r8, [r6]
 bfc:	4682      	mov	sl, r0
 bfe:	e508      	b.n	612 <SystemNavigationBackend_Predict+0x612>
 c00:	490d      	ldr	r1, [pc, #52]	@ (c38 <SystemNavigationBackend_Predict+0xc38>)
 c02:	1b1b      	subs	r3, r3, r4
 c04:	428b      	cmp	r3, r1
 c06:	4b08      	ldr	r3, [pc, #32]	@ (c28 <SystemNavigationBackend_Predict+0xc28>)
 c08:	d98d      	bls.n	b26 <SystemNavigationBackend_Predict+0xb26>
 c0a:	6819      	ldr	r1, [r3, #0]
 c0c:	480b      	ldr	r0, [pc, #44]	@ (c3c <SystemNavigationBackend_Predict+0xc3c>)
 c0e:	1809      	adds	r1, r1, r0
 c10:	6019      	str	r1, [r3, #0]
 c12:	6859      	ldr	r1, [r3, #4]
 c14:	f141 018c 	adc.w	r1, r1, #140	@ 0x8c
 c18:	6059      	str	r1, [r3, #4]
 c1a:	e784      	b.n	b26 <SystemNavigationBackend_Predict+0xb26>
 c1c:	00000000 	.word	0x00000000
			c1c: R_ARM_ABS32	.rodata.Backend_StateLog.str1.4
 c20:	240c83ff 	.word	0x240c83ff
	...
			c24: R_ARM_ABS32	.bss.s_native_tow_ms
			c28: R_ARM_ABS32	.bss.s_native_week_us
			c2c: R_ARM_ABS32	.rodata.s_window_config
			c30: R_ARM_ABS32	.bss.silverstar_auto_eskf_window
			c34: R_ARM_ABS32	.bss.s_current_gnss
 c38:	12064200 	.word	0x12064200
 c3c:	d0e3a000 	.word	0xd0e3a000
 c40:	005b8d80 	.word	0x005b8d80
 c44:	00000000 	.word	0x00000000
			c44: R_ARM_ABS32	.bss.s_gnss_sequence

Disassembly of section .text.SystemNavigationBackend_BodyInputFill:

00000000 <SystemNavigationBackend_BodyInputFill>:
   0:	b5f0      	push	{r4, r5, r6, r7, lr}
   2:	b083      	sub	sp, #12
   4:	461f      	mov	r7, r3
   6:	f240 43e6 	movw	r3, #1254	@ 0x4e6
   a:	460e      	mov	r6, r1
   c:	4615      	mov	r5, r2
   e:	9300      	str	r3, [sp, #0]
  10:	2202      	movs	r2, #2
  12:	4b19      	ldr	r3, [pc, #100]	@ (78 <SystemNavigationBackend_BodyInputFill+0x78>)
  14:	2108      	movs	r1, #8
  16:	4604      	mov	r4, r0
  18:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			18: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  1c:	f240 43e7 	movw	r3, #1255	@ 0x4e7
  20:	9300      	str	r3, [sp, #0]
  22:	4630      	mov	r0, r6
  24:	4b14      	ldr	r3, [pc, #80]	@ (78 <SystemNavigationBackend_BodyInputFill+0x78>)
  26:	2202      	movs	r2, #2
  28:	2104      	movs	r1, #4
  2a:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			2a: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  2e:	f44f 629d 	mov.w	r2, #1256	@ 0x4e8
  32:	9200      	str	r2, [sp, #0]
  34:	4628      	mov	r0, r5
  36:	4b10      	ldr	r3, [pc, #64]	@ (78 <SystemNavigationBackend_BodyInputFill+0x78>)
  38:	2202      	movs	r2, #2
  3a:	2104      	movs	r1, #4
  3c:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			3c: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  40:	6833      	ldr	r3, [r6, #0]
  42:	6872      	ldr	r2, [r6, #4]
  44:	68b1      	ldr	r1, [r6, #8]
  46:	68f0      	ldr	r0, [r6, #12]
  48:	6360      	str	r0, [r4, #52]	@ 0x34
  4a:	62a3      	str	r3, [r4, #40]	@ 0x28
  4c:	62e2      	str	r2, [r4, #44]	@ 0x2c
  4e:	6321      	str	r1, [r4, #48]	@ 0x30
  50:	6933      	ldr	r3, [r6, #16]
  52:	6972      	ldr	r2, [r6, #20]
  54:	63e2      	str	r2, [r4, #60]	@ 0x3c
  56:	63a3      	str	r3, [r4, #56]	@ 0x38
  58:	682b      	ldr	r3, [r5, #0]
  5a:	686a      	ldr	r2, [r5, #4]
  5c:	68a9      	ldr	r1, [r5, #8]
  5e:	68e8      	ldr	r0, [r5, #12]
  60:	64e0      	str	r0, [r4, #76]	@ 0x4c
  62:	6423      	str	r3, [r4, #64]	@ 0x40
  64:	6462      	str	r2, [r4, #68]	@ 0x44
  66:	64a1      	str	r1, [r4, #72]	@ 0x48
  68:	692b      	ldr	r3, [r5, #16]
  6a:	696a      	ldr	r2, [r5, #20]
  6c:	6562      	str	r2, [r4, #84]	@ 0x54
  6e:	6523      	str	r3, [r4, #80]	@ 0x50
  70:	65a7      	str	r7, [r4, #88]	@ 0x58
  72:	b003      	add	sp, #12
  74:	bdf0      	pop	{r4, r5, r6, r7, pc}
  76:	bf00      	nop
  78:	00000000 	.word	0x00000000
			78: R_ARM_ABS32	.rodata.Backend_StateLog.str1.4
