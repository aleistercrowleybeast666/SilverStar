
D:\python_software\SilverStar\.work\dev013_navclosure02\eskf15_0_default03\build\FCCG\SilverStar_F407\Release\auto\Algorithm\Estimator\ESKF15\Src\navigation_eskf_replay.o:     file format elf32-littlearm


Disassembly of section .text.Replay_PropagatePart:

00000000 <Replay_PropagatePart>:
   0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
   4:	b09b      	sub	sp, #108	@ 0x6c
   6:	461c      	mov	r4, r3
   8:	235f      	movs	r3, #95	@ 0x5f
   a:	9300      	str	r3, [sp, #0]
   c:	4688      	mov	r8, r1
   e:	4b57      	ldr	r3, [pc, #348]	@ (16c <Replay_PropagatePart+0x16c>)
  10:	2108      	movs	r1, #8
  12:	4691      	mov	r9, r2
  14:	2202      	movs	r2, #2
  16:	4605      	mov	r5, r0
  18:	e9dd 6724 	ldrd	r6, r7, [sp, #144]	@ 0x90
  1c:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			1c: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  20:	2360      	movs	r3, #96	@ 0x60
  22:	9300      	str	r3, [sp, #0]
  24:	2202      	movs	r2, #2
  26:	4b51      	ldr	r3, [pc, #324]	@ (16c <Replay_PropagatePart+0x16c>)
  28:	2108      	movs	r1, #8
  2a:	4620      	mov	r0, r4
  2c:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			2c: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  30:	4621      	mov	r1, r4
  32:	2258      	movs	r2, #88	@ 0x58
  34:	a804      	add	r0, sp, #16
  36:	f7ff fffe 	bl	0 <memcpy>
			36: R_ARM_THM_CALL	memcpy
  3a:	e9d5 01f2 	ldrd	r0, r1, [r5, #968]	@ 0x3c8
  3e:	42b9      	cmp	r1, r7
  40:	bf08      	it	eq
  42:	42b0      	cmpeq	r0, r6
  44:	d07d      	beq.n	142 <Replay_PropagatePart+0x142>
  46:	4286      	cmp	r6, r0
  48:	eb77 0301 	sbcs.w	r3, r7, r1
  4c:	d375      	bcc.n	13a <Replay_PropagatePart+0x13a>
  4e:	e9d4 ce10 	ldrd	ip, lr, [r4, #64]	@ 0x40
  52:	45b4      	cmp	ip, r6
  54:	eb7e 0307 	sbcs.w	r3, lr, r7
  58:	d36f      	bcc.n	13a <Replay_PropagatePart+0x13a>
  5a:	e9d4 b20e 	ldrd	fp, r2, [r4, #56]	@ 0x38
  5e:	4558      	cmp	r0, fp
  60:	eb71 0302 	sbcs.w	r3, r1, r2
  64:	d369      	bcc.n	13a <Replay_PropagatePart+0x13a>
  66:	4291      	cmp	r1, r2
  68:	bf08      	it	eq
  6a:	4558      	cmpeq	r0, fp
  6c:	d070      	beq.n	150 <Replay_PropagatePart+0x150>
  6e:	ebbc 030b 	subs.w	r3, ip, fp
  72:	eb6e 0a02 	sbc.w	sl, lr, r2
  76:	085b      	lsrs	r3, r3, #1
  78:	ea43 73ca 	orr.w	r3, r3, sl, lsl #31
  7c:	eb13 030b 	adds.w	r3, r3, fp
  80:	eb42 025a 	adc.w	r2, r2, sl, lsr #1
  84:	429e      	cmp	r6, r3
  86:	eb77 0b02 	sbcs.w	fp, r7, r2
  8a:	9302      	str	r3, [sp, #8]
  8c:	bf38      	it	cc
  8e:	9602      	strcc	r6, [sp, #8]
  90:	9b02      	ldr	r3, [sp, #8]
  92:	bf38      	it	cc
  94:	463a      	movcc	r2, r7
  96:	4298      	cmp	r0, r3
  98:	eb71 0b02 	sbcs.w	fp, r1, r2
  9c:	46a2      	mov	sl, r4
  9e:	d354      	bcc.n	14a <Replay_PropagatePart+0x14a>
  a0:	f104 0a0c 	add.w	sl, r4, #12
  a4:	4566      	cmp	r6, ip
  a6:	f8cd c008 	str.w	ip, [sp, #8]
  aa:	eb77 0c0e 	sbcs.w	ip, r7, lr
  ae:	bf38      	it	cc
  b0:	9602      	strcc	r6, [sp, #8]
  b2:	9b02      	ldr	r3, [sp, #8]
  b4:	4672      	mov	r2, lr
  b6:	bf38      	it	cc
  b8:	463a      	movcc	r2, r7
  ba:	4298      	cmp	r0, r3
  bc:	eb71 0c02 	sbcs.w	ip, r1, r2
  c0:	d23f      	bcs.n	142 <Replay_PropagatePart+0x142>
  c2:	2301      	movs	r3, #1
  c4:	9303      	str	r3, [sp, #12]
  c6:	9b02      	ldr	r3, [sp, #8]
  c8:	9012      	str	r0, [sp, #72]	@ 0x48
  ca:	1a18      	subs	r0, r3, r0
  cc:	e9cd 1313 	strd	r1, r3, [sp, #76]	@ 0x4c
  d0:	eb62 0101 	sbc.w	r1, r2, r1
  d4:	9215      	str	r2, [sp, #84]	@ 0x54
  d6:	f7ff fffe 	bl	0 <__aeabi_ul2f>
			d6: R_ARM_THM_CALL	__aeabi_ul2f
  da:	ee07 0a90 	vmov	s15, r0
  de:	e89a 0007 	ldmia.w	sl, {r0, r1, r2}
  e2:	f10a 0c18 	add.w	ip, sl, #24
  e6:	ab04      	add	r3, sp, #16
  e8:	e883 0007 	stmia.w	r3, {r0, r1, r2}
  ec:	e89c 0007 	ldmia.w	ip, {r0, r1, r2}
  f0:	f10d 0b28 	add.w	fp, sp, #40	@ 0x28
  f4:	e88b 0007 	stmia.w	fp, {r0, r1, r2}
  f8:	e89a 0007 	ldmia.w	sl, {r0, r1, r2}
  fc:	f10d 0e1c 	add.w	lr, sp, #28
 100:	e88e 0007 	stmia.w	lr, {r0, r1, r2}
 104:	ed9f 7a1a 	vldr	s14, [pc, #104]	@ 170 <Replay_PropagatePart+0x170>
 108:	e89c 0007 	ldmia.w	ip, {r0, r1, r2}
 10c:	ee67 7a87 	vmul.f32	s15, s15, s14
 110:	f10d 0c34 	add.w	ip, sp, #52	@ 0x34
 114:	edcd 7a10 	vstr	s15, [sp, #64]	@ 0x40
 118:	e88c 0007 	stmia.w	ip, {r0, r1, r2}
 11c:	464a      	mov	r2, r9
 11e:	4641      	mov	r1, r8
 120:	4628      	mov	r0, r5
 122:	f7ff fffe 	bl	0 <NavigationEskf_Predict>
			122: R_ARM_THM_CALL	NavigationEskf_Predict
 126:	b9f8      	cbnz	r0, 168 <Replay_PropagatePart+0x168>
 128:	9b03      	ldr	r3, [sp, #12]
 12a:	b953      	cbnz	r3, 142 <Replay_PropagatePart+0x142>
 12c:	e9d5 01f2 	ldrd	r0, r1, [r5, #968]	@ 0x3c8
 130:	e9d4 ce10 	ldrd	ip, lr, [r4, #64]	@ 0x40
 134:	f10a 0a0c 	add.w	sl, sl, #12
 138:	e7b4      	b.n	a4 <Replay_PropagatePart+0xa4>
 13a:	2001      	movs	r0, #1
 13c:	b01b      	add	sp, #108	@ 0x6c
 13e:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 142:	2000      	movs	r0, #0
 144:	b01b      	add	sp, #108	@ 0x6c
 146:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 14a:	2300      	movs	r3, #0
 14c:	9303      	str	r3, [sp, #12]
 14e:	e7ba      	b.n	c6 <Replay_PropagatePart+0xc6>
 150:	45be      	cmp	lr, r7
 152:	bf08      	it	eq
 154:	45b4      	cmpeq	ip, r6
 156:	d18a      	bne.n	6e <Replay_PropagatePart+0x6e>
 158:	4623      	mov	r3, r4
 15a:	464a      	mov	r2, r9
 15c:	4641      	mov	r1, r8
 15e:	4628      	mov	r0, r5
 160:	f7ff fffe 	bl	0 <NavigationEskf_Predict>
			160: R_ARM_THM_CALL	NavigationEskf_Predict
 164:	2800      	cmp	r0, #0
 166:	d0ec      	beq.n	142 <Replay_PropagatePart+0x142>
 168:	2005      	movs	r0, #5
 16a:	e7e7      	b.n	13c <Replay_PropagatePart+0x13c>
 16c:	00000000 	.word	0x00000000
			16c: R_ARM_ABS32	.rodata.Replay_PropagatePart.str1.4
 170:	358637bd 	.word	0x358637bd

Disassembly of section .text.Replay_RecoveryReady:

00000000 <Replay_RecoveryReady>:
   0:	b358      	cbz	r0, 5a <Replay_RecoveryReady+0x5a>
   2:	b149      	cbz	r1, 18 <Replay_RecoveryReady+0x18>
   4:	b510      	push	{r4, lr}
   6:	f500 5380 	add.w	r3, r0, #4096	@ 0x1000
   a:	4604      	mov	r4, r0
   c:	f893 3d00 	ldrb.w	r3, [r3, #3328]	@ 0xd00
  10:	2b01      	cmp	r3, #1
  12:	d003      	beq.n	1c <Replay_RecoveryReady+0x1c>
  14:	2000      	movs	r0, #0
  16:	bd10      	pop	{r4, pc}
  18:	2000      	movs	r0, #0
  1a:	4770      	bx	lr
  1c:	f8d1 23d4 	ldr.w	r2, [r1, #980]	@ 0x3d4
  20:	f8d0 30e8 	ldr.w	r3, [r0, #232]	@ 0xe8
  24:	4293      	cmp	r3, r2
  26:	d1f5      	bne.n	14 <Replay_RecoveryReady+0x14>
  28:	f8d0 2158 	ldr.w	r2, [r0, #344]	@ 0x158
  2c:	4293      	cmp	r3, r2
  2e:	d1f1      	bne.n	14 <Replay_RecoveryReady+0x14>
  30:	f8d0 20ec 	ldr.w	r2, [r0, #236]	@ 0xec
  34:	f8d0 315c 	ldr.w	r3, [r0, #348]	@ 0x15c
  38:	429a      	cmp	r2, r3
  3a:	d1eb      	bne.n	14 <Replay_RecoveryReady+0x14>
  3c:	4601      	mov	r1, r0
  3e:	30a0      	adds	r0, #160	@ 0xa0
  40:	f7ff fffe 	bl	0 <NavigationEskfRecovery_PolicyValidate>
			40: R_ARM_THM_CALL	NavigationEskfRecovery_PolicyValidate
  44:	2800      	cmp	r0, #0
  46:	d1e5      	bne.n	14 <Replay_RecoveryReady+0x14>
  48:	4621      	mov	r1, r4
  4a:	f504 7088 	add.w	r0, r4, #272	@ 0x110
  4e:	f7ff fffe 	bl	0 <NavigationEskfRecovery_PolicyValidate>
			4e: R_ARM_THM_CALL	NavigationEskfRecovery_PolicyValidate
  52:	fab0 f080 	clz	r0, r0
  56:	0940      	lsrs	r0, r0, #5
  58:	bd10      	pop	{r4, pc}
  5a:	2001      	movs	r0, #1
  5c:	4770      	bx	lr
  5e:	bf00      	nop

Disassembly of section .text.Replay_Run:

00000000 <Replay_Run>:
   0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
   4:	b0cd      	sub	sp, #308	@ 0x134
   6:	461c      	mov	r4, r3
   8:	2387      	movs	r3, #135	@ 0x87
   a:	e9cd 1204 	strd	r1, r2, [sp, #16]
   e:	460d      	mov	r5, r1
  10:	9300      	str	r3, [sp, #0]
  12:	2202      	movs	r2, #2
  14:	4baa      	ldr	r3, [pc, #680]	@ (2c0 <Replay_Run+0x2c0>)
  16:	f8dd 8160 	ldr.w	r8, [sp, #352]	@ 0x160
  1a:	2108      	movs	r1, #8
  1c:	4607      	mov	r7, r0
  1e:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			1e: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  22:	2388      	movs	r3, #136	@ 0x88
  24:	9300      	str	r3, [sp, #0]
  26:	2202      	movs	r2, #2
  28:	4ba5      	ldr	r3, [pc, #660]	@ (2c0 <Replay_Run+0x2c0>)
  2a:	2104      	movs	r1, #4
  2c:	4628      	mov	r0, r5
  2e:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			2e: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  32:	f44f 7278 	mov.w	r2, #992	@ 0x3e0
  36:	18bb      	adds	r3, r7, r2
  38:	4639      	mov	r1, r7
  3a:	4618      	mov	r0, r3
  3c:	9306      	str	r3, [sp, #24]
  3e:	f7ff fffe 	bl	0 <memcpy>
			3e: R_ARM_THM_CALL	memcpy
  42:	f1b8 0f00 	cmp.w	r8, #0
  46:	d006      	beq.n	56 <Replay_Run+0x56>
  48:	2270      	movs	r2, #112	@ 0x70
  4a:	f108 01a0 	add.w	r1, r8, #160	@ 0xa0
  4e:	f508 70c0 	add.w	r0, r8, #384	@ 0x180
  52:	f7ff fffe 	bl	0 <memcpy>
			52: R_ARM_THM_CALL	memcpy
  56:	01a3      	lsls	r3, r4, #6
  58:	930b      	str	r3, [sp, #44]	@ 0x2c
  5a:	f507 63f6 	add.w	r3, r7, #1968	@ 0x7b0
  5e:	f04f 0b00 	mov.w	fp, #0
  62:	930a      	str	r3, [sp, #40]	@ 0x28
  64:	f507 4380 	add.w	r3, r7, #16384	@ 0x4000
  68:	46d9      	mov	r9, fp
  6a:	465c      	mov	r4, fp
  6c:	9307      	str	r3, [sp, #28]
  6e:	f8d7 37c0 	ldr.w	r3, [r7, #1984]	@ 0x7c0
  72:	f8d7 23d4 	ldr.w	r2, [r7, #980]	@ 0x3d4
  76:	f853 c00b 	ldr.w	ip, [r3, fp]
  7a:	eb03 060b 	add.w	r6, r3, fp
  7e:	f10d 0a78 	add.w	sl, sp, #120	@ 0x78
  82:	6bb3      	ldr	r3, [r6, #56]	@ 0x38
  84:	6875      	ldr	r5, [r6, #4]
  86:	932a      	str	r3, [sp, #168]	@ 0xa8
  88:	6bf3      	ldr	r3, [r6, #60]	@ 0x3c
  8a:	e9cd 2331 	strd	r2, r3, [sp, #196]	@ 0xc4
  8e:	f8d7 33d0 	ldr.w	r3, [r7, #976]	@ 0x3d0
  92:	9330      	str	r3, [sp, #192]	@ 0xc0
  94:	f509 73d0 	add.w	r3, r9, #416	@ 0x1a0
  98:	9308      	str	r3, [sp, #32]
  9a:	9b0a      	ldr	r3, [sp, #40]	@ 0x28
  9c:	e953 2302 	ldrd	r2, r3, [r3, #-8]
  a0:	e9cd c52e 	strd	ip, r5, [sp, #184]	@ 0xb8
  a4:	e9cd 232c 	strd	r2, r3, [sp, #176]	@ 0xb0
  a8:	68b0      	ldr	r0, [r6, #8]
  aa:	68f1      	ldr	r1, [r6, #12]
  ac:	6973      	ldr	r3, [r6, #20]
  ae:	6932      	ldr	r2, [r6, #16]
  b0:	e8aa 000f 	stmia.w	sl!, {r0, r1, r2, r3}
  b4:	69b0      	ldr	r0, [r6, #24]
  b6:	69f1      	ldr	r1, [r6, #28]
  b8:	6af3      	ldr	r3, [r6, #44]	@ 0x2c
  ba:	e8aa 0003 	stmia.w	sl!, {r0, r1}
  be:	6a30      	ldr	r0, [r6, #32]
  c0:	6a71      	ldr	r1, [r6, #36]	@ 0x24
  c2:	6ab2      	ldr	r2, [r6, #40]	@ 0x28
  c4:	f8cd 8160 	str.w	r8, [sp, #352]	@ 0x160
  c8:	f10d 0e90 	add.w	lr, sp, #144	@ 0x90
  cc:	e8ae 000f 	stmia.w	lr!, {r0, r1, r2, r3}
  d0:	6b71      	ldr	r1, [r6, #52]	@ 0x34
  d2:	6b30      	ldr	r0, [r6, #48]	@ 0x30
  d4:	f8cd b024 	str.w	fp, [sp, #36]	@ 0x24
  d8:	46b8      	mov	r8, r7
  da:	9f58      	ldr	r7, [sp, #352]	@ 0x160
  dc:	e8ae 0003 	stmia.w	lr!, {r0, r1}
  e0:	4661      	mov	r1, ip
  e2:	9b07      	ldr	r3, [sp, #28]
  e4:	f8b3 324a 	ldrh.w	r3, [r3, #586]	@ 0x24a
  e8:	42a3      	cmp	r3, r4
  ea:	f240 80a3 	bls.w	234 <Replay_Run+0x234>
  ee:	eb04 0bc4 	add.w	fp, r4, r4, lsl #3
  f2:	eb08 06cb 	add.w	r6, r8, fp, lsl #3
  f6:	ea4f 0ac4 	mov.w	sl, r4, lsl #3
  fa:	f8d6 27c8 	ldr.w	r2, [r6, #1992]	@ 0x7c8
  fe:	f8d6 37cc 	ldr.w	r3, [r6, #1996]	@ 0x7cc
 102:	4291      	cmp	r1, r2
 104:	eb75 0003 	sbcs.w	r0, r5, r3
 108:	ea4f 0bcb 	mov.w	fp, fp, lsl #3
 10c:	f0c0 8092 	bcc.w	234 <Replay_Run+0x234>
 110:	e9cd 2300 	strd	r2, r3, [sp]
 114:	9806      	ldr	r0, [sp, #24]
 116:	e9dd 1204 	ldrd	r1, r2, [sp, #16]
 11a:	ab1e      	add	r3, sp, #120	@ 0x78
 11c:	f7ff fffe 	bl	0 <Replay_Run>
			11c: R_ARM_THM_CALL	Replay_PropagatePart
 120:	4605      	mov	r5, r0
 122:	2800      	cmp	r0, #0
 124:	d15f      	bne.n	1e6 <Replay_Run+0x1e6>
 126:	4601      	mov	r1, r0
 128:	2260      	movs	r2, #96	@ 0x60
 12a:	a834      	add	r0, sp, #208	@ 0xd0
 12c:	f7ff fffe 	bl	0 <memset>
			12c: R_ARM_THM_CALL	memset
 130:	2f00      	cmp	r7, #0
 132:	d05c      	beq.n	1ee <Replay_Run+0x1ee>
 134:	f896 37e4 	ldrb.w	r3, [r6, #2020]	@ 0x7e4
 138:	2b03      	cmp	r3, #3
 13a:	f206 72e4 	addw	r2, r6, #2020	@ 0x7e4
 13e:	d856      	bhi.n	1ee <Replay_Run+0x1ee>
 140:	f506 63fa 	add.w	r3, r6, #2000	@ 0x7d0
 144:	4615      	mov	r5, r2
 146:	e9d3 2300 	ldrd	r2, r3, [r3]
 14a:	f50b 6bfb 	add.w	fp, fp, #2008	@ 0x7d8
 14e:	e9cd 2334 	strd	r2, r3, [sp, #208]	@ 0xd0
 152:	eb08 030b 	add.w	r3, r8, fp
 156:	f858 200b 	ldr.w	r2, [r8, fp]
 15a:	9237      	str	r2, [sp, #220]	@ 0xdc
 15c:	689a      	ldr	r2, [r3, #8]
 15e:	685b      	ldr	r3, [r3, #4]
 160:	9336      	str	r3, [sp, #216]	@ 0xd8
 162:	f8d7 30ec 	ldr.w	r3, [r7, #236]	@ 0xec
 166:	9238      	str	r2, [sp, #224]	@ 0xe0
 168:	9339      	str	r3, [sp, #228]	@ 0xe4
 16a:	cd0f      	ldmia	r5!, {r0, r1, r2, r3}
 16c:	ae3a      	add	r6, sp, #232	@ 0xe8
 16e:	c60f      	stmia	r6!, {r0, r1, r2, r3}
 170:	cd0f      	ldmia	r5!, {r0, r1, r2, r3}
 172:	c60f      	stmia	r6!, {r0, r1, r2, r3}
 174:	e895 0007 	ldmia.w	r5, {r0, r1, r2}
 178:	ebaa 0c04 	sub.w	ip, sl, r4
 17c:	eb07 0c8c 	add.w	ip, r7, ip, lsl #2
 180:	f50c 6cc8 	add.w	ip, ip, #1600	@ 0x640
 184:	e886 0007 	stmia.w	r6, {r0, r1, r2}
 188:	e8bc 000f 	ldmia.w	ip!, {r0, r1, r2, r3}
 18c:	f50d 7e8a 	add.w	lr, sp, #276	@ 0x114
 190:	e8ae 000f 	stmia.w	lr!, {r0, r1, r2, r3}
 194:	e89c 0007 	ldmia.w	ip, {r0, r1, r2}
 198:	e88e 0007 	stmia.w	lr, {r0, r1, r2}
 19c:	aa34      	add	r2, sp, #208	@ 0xd0
 19e:	e9cd 7201 	strd	r7, r2, [sp, #4]
 1a2:	f10d 0b54 	add.w	fp, sp, #84	@ 0x54
 1a6:	9a05      	ldr	r2, [sp, #20]
 1a8:	f8cd b00c 	str.w	fp, [sp, #12]
 1ac:	f507 73f8 	add.w	r3, r7, #496	@ 0x1f0
 1b0:	9200      	str	r2, [sp, #0]
 1b2:	f507 71c0 	add.w	r1, r7, #384	@ 0x180
 1b6:	9a04      	ldr	r2, [sp, #16]
 1b8:	9806      	ldr	r0, [sp, #24]
 1ba:	f7ff fffe 	bl	0 <NavigationEskfRecovery_UpdateCandidate>
			1ba: R_ARM_THM_CALL	NavigationEskfRecovery_UpdateCandidate
 1be:	4684      	mov	ip, r0
 1c0:	e8bb 000f 	ldmia.w	fp!, {r0, r1, r2, r3}
 1c4:	ae0d      	add	r6, sp, #52	@ 0x34
 1c6:	4635      	mov	r5, r6
 1c8:	c50f      	stmia	r5!, {r0, r1, r2, r3}
 1ca:	e89b 000f 	ldmia.w	fp, {r0, r1, r2, r3}
 1ce:	e885 000f 	stmia.w	r5, {r0, r1, r2, r3}
 1d2:	f1bc 0f00 	cmp.w	ip, #0
 1d6:	d052      	beq.n	27e <Replay_Run+0x27e>
 1d8:	f1ac 0c07 	sub.w	ip, ip, #7
 1dc:	fa5f fc8c 	uxtb.w	ip, ip
 1e0:	f1bc 0f01 	cmp.w	ip, #1
 1e4:	d94b      	bls.n	27e <Replay_Run+0x27e>
 1e6:	2005      	movs	r0, #5
 1e8:	b04d      	add	sp, #308	@ 0x134
 1ea:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 1ee:	eb0a 0304 	add.w	r3, sl, r4
 1f2:	eb08 03c3 	add.w	r3, r8, r3, lsl #3
 1f6:	ae0d      	add	r6, sp, #52	@ 0x34
 1f8:	e9dd 1204 	ldrd	r1, r2, [sp, #16]
 1fc:	9806      	ldr	r0, [sp, #24]
 1fe:	9600      	str	r6, [sp, #0]
 200:	f203 73e4 	addw	r3, r3, #2020	@ 0x7e4
 204:	f7ff fffe 	bl	0 <NavigationEskf_Update>
			204: R_ARM_THM_CALL	NavigationEskf_Update
 208:	2804      	cmp	r0, #4
 20a:	d0ec      	beq.n	1e6 <Replay_Run+0x1e6>
 20c:	9b56      	ldr	r3, [sp, #344]	@ 0x158
 20e:	b13b      	cbz	r3, 220 <Replay_Run+0x220>
 210:	44a2      	add	sl, r4
 212:	eb08 0aca 	add.w	sl, r8, sl, lsl #3
 216:	691b      	ldr	r3, [r3, #16]
 218:	f8da 27d8 	ldr.w	r2, [sl, #2008]	@ 0x7d8
 21c:	429a      	cmp	r2, r3
 21e:	d033      	beq.n	288 <Replay_Run+0x288>
 220:	9b08      	ldr	r3, [sp, #32]
 222:	f109 0902 	add.w	r9, r9, #2
 226:	3401      	adds	r4, #1
 228:	4599      	cmp	r9, r3
 22a:	e9dd 152e 	ldrd	r1, r5, [sp, #184]	@ 0xb8
 22e:	b2a4      	uxth	r4, r4
 230:	f47f af57 	bne.w	e2 <Replay_Run+0xe2>
 234:	9758      	str	r7, [sp, #352]	@ 0x160
 236:	e9cd 1500 	strd	r1, r5, [sp]
 23a:	9806      	ldr	r0, [sp, #24]
 23c:	f8dd b024 	ldr.w	fp, [sp, #36]	@ 0x24
 240:	e9dd 1204 	ldrd	r1, r2, [sp, #16]
 244:	ab1e      	add	r3, sp, #120	@ 0x78
 246:	4647      	mov	r7, r8
 248:	f8dd 8160 	ldr.w	r8, [sp, #352]	@ 0x160
 24c:	f7ff fffe 	bl	0 <Replay_Run>
			24c: R_ARM_THM_CALL	Replay_PropagatePart
 250:	2800      	cmp	r0, #0
 252:	d1c8      	bne.n	1e6 <Replay_Run+0x1e6>
 254:	9b0b      	ldr	r3, [sp, #44]	@ 0x2c
 256:	f10b 0b40 	add.w	fp, fp, #64	@ 0x40
 25a:	455b      	cmp	r3, fp
 25c:	f109 0901 	add.w	r9, r9, #1
 260:	f47f af05 	bne.w	6e <Replay_Run+0x6e>
 264:	f5b9 7f18 	cmp.w	r9, #608	@ 0x260
 268:	d828      	bhi.n	2bc <Replay_Run+0x2bc>
 26a:	9a07      	ldr	r2, [sp, #28]
 26c:	f8d2 3258 	ldr.w	r3, [r2, #600]	@ 0x258
 270:	f8c2 925c 	str.w	r9, [r2, #604]	@ 0x25c
 274:	454b      	cmp	r3, r9
 276:	d2b7      	bcs.n	1e8 <Replay_Run+0x1e8>
 278:	f8c2 9258 	str.w	r9, [r2, #600]	@ 0x258
 27c:	e7b4      	b.n	1e8 <Replay_Run+0x1e8>
 27e:	f89d 5074 	ldrb.w	r5, [sp, #116]	@ 0x74
 282:	f89d 0071 	ldrb.w	r0, [sp, #113]	@ 0x71
 286:	e7bf      	b.n	208 <Replay_Run+0x208>
 288:	9b56      	ldr	r3, [sp, #344]	@ 0x158
 28a:	f8da 27dc 	ldr.w	r2, [sl, #2012]	@ 0x7dc
 28e:	695b      	ldr	r3, [r3, #20]
 290:	429a      	cmp	r2, r3
 292:	d1c5      	bne.n	220 <Replay_Run+0x220>
 294:	9b56      	ldr	r3, [sp, #344]	@ 0x158
 296:	f89a 27e4 	ldrb.w	r2, [sl, #2020]	@ 0x7e4
 29a:	7f1b      	ldrb	r3, [r3, #28]
 29c:	429a      	cmp	r2, r3
 29e:	d1bf      	bne.n	220 <Replay_Run+0x220>
 2a0:	ce0f      	ldmia	r6!, {r0, r1, r2, r3}
 2a2:	f8dd c15c 	ldr.w	ip, [sp, #348]	@ 0x15c
 2a6:	e8ac 000f 	stmia.w	ip!, {r0, r1, r2, r3}
 2aa:	e896 000f 	ldmia.w	r6, {r0, r1, r2, r3}
 2ae:	e88c 000f 	stmia.w	ip, {r0, r1, r2, r3}
 2b2:	9b59      	ldr	r3, [sp, #356]	@ 0x164
 2b4:	2b00      	cmp	r3, #0
 2b6:	d0b3      	beq.n	220 <Replay_Run+0x220>
 2b8:	701d      	strb	r5, [r3, #0]
 2ba:	e7b1      	b.n	220 <Replay_Run+0x220>
 2bc:	2003      	movs	r0, #3
 2be:	e793      	b.n	1e8 <Replay_Run+0x1e8>
 2c0:	00000000 	.word	0x00000000
			2c0: R_ARM_ABS32	.rodata.Replay_PropagatePart.str1.4

Disassembly of section .text.Replay_Insert:

00000000 <Replay_Insert>:
   0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
   4:	b089      	sub	sp, #36	@ 0x24
   6:	f8dd 8048 	ldr.w	r8, [sp, #72]	@ 0x48
   a:	2800      	cmp	r0, #0
   c:	f000 8091 	beq.w	132 <Replay_Insert+0x132>
  10:	461f      	mov	r7, r3
  12:	f8d0 37c0 	ldr.w	r3, [r0, #1984]	@ 0x7c0
  16:	4604      	mov	r4, r0
  18:	2b00      	cmp	r3, #0
  1a:	f000 808a 	beq.w	132 <Replay_Insert+0x132>
  1e:	460d      	mov	r5, r1
  20:	2900      	cmp	r1, #0
  22:	f000 8086 	beq.w	132 <Replay_Insert+0x132>
  26:	4616      	mov	r6, r2
  28:	2a00      	cmp	r2, #0
  2a:	f000 8082 	beq.w	132 <Replay_Insert+0x132>
  2e:	f1b8 0f00 	cmp.w	r8, #0
  32:	d07e      	beq.n	132 <Replay_Insert+0x132>
  34:	9b13      	ldr	r3, [sp, #76]	@ 0x4c
  36:	2b00      	cmp	r3, #0
  38:	d07b      	beq.n	132 <Replay_Insert+0x132>
  3a:	f8d8 2018 	ldr.w	r2, [r8, #24]
  3e:	f8d1 33d4 	ldr.w	r3, [r1, #980]	@ 0x3d4
  42:	429a      	cmp	r2, r3
  44:	d175      	bne.n	132 <Replay_Insert+0x132>
  46:	f898 301c 	ldrb.w	r3, [r8, #28]
  4a:	2b04      	cmp	r3, #4
  4c:	d871      	bhi.n	132 <Replay_Insert+0x132>
  4e:	f8d8 1008 	ldr.w	r1, [r8, #8]
  52:	f8d5 03c8 	ldr.w	r0, [r5, #968]	@ 0x3c8
  56:	f8d8 300c 	ldr.w	r3, [r8, #12]
  5a:	f8d5 23cc 	ldr.w	r2, [r5, #972]	@ 0x3cc
  5e:	4288      	cmp	r0, r1
  60:	419a      	sbcs	r2, r3
  62:	d366      	bcc.n	132 <Replay_Insert+0x132>
  64:	e9d8 0200 	ldrd	r0, r2, [r8]
  68:	4281      	cmp	r1, r0
  6a:	4193      	sbcs	r3, r2
  6c:	d361      	bcc.n	132 <Replay_Insert+0x132>
  6e:	f504 4980 	add.w	r9, r4, #16384	@ 0x4000
  72:	f8b9 3248 	ldrh.w	r3, [r9, #584]	@ 0x248
  76:	2bc0      	cmp	r3, #192	@ 0xc0
  78:	d85b      	bhi.n	132 <Replay_Insert+0x132>
  7a:	f8b9 324a 	ldrh.w	r3, [r9, #586]	@ 0x24a
  7e:	2bd0      	cmp	r3, #208	@ 0xd0
  80:	d857      	bhi.n	132 <Replay_Insert+0x132>
  82:	9814      	ldr	r0, [sp, #80]	@ 0x50
  84:	4629      	mov	r1, r5
  86:	f7ff fffe 	bl	0 <Replay_Insert>
			86: R_ARM_THM_CALL	Replay_RecoveryReady
  8a:	2800      	cmp	r0, #0
  8c:	d051      	beq.n	132 <Replay_Insert+0x132>
  8e:	f240 1307 	movw	r3, #263	@ 0x107
  92:	9300      	str	r3, [sp, #0]
  94:	2202      	movs	r2, #2
  96:	4bb1      	ldr	r3, [pc, #708]	@ (35c <Replay_Insert+0x35c>)
  98:	2108      	movs	r1, #8
  9a:	4620      	mov	r0, r4
  9c:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			9c: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  a0:	f44f 7384 	mov.w	r3, #264	@ 0x108
  a4:	9300      	str	r3, [sp, #0]
  a6:	2202      	movs	r2, #2
  a8:	4bac      	ldr	r3, [pc, #688]	@ (35c <Replay_Insert+0x35c>)
  aa:	2108      	movs	r1, #8
  ac:	4628      	mov	r0, r5
  ae:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			ae: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  b2:	f8d8 3004 	ldr.w	r3, [r8, #4]
  b6:	f8d8 0000 	ldr.w	r0, [r8]
  ba:	f8d4 13c8 	ldr.w	r1, [r4, #968]	@ 0x3c8
  be:	9306      	str	r3, [sp, #24]
  c0:	461a      	mov	r2, r3
  c2:	f8d4 33cc 	ldr.w	r3, [r4, #972]	@ 0x3cc
  c6:	4281      	cmp	r1, r0
  c8:	4193      	sbcs	r3, r2
  ca:	f080 80da 	bcs.w	282 <Replay_Insert+0x282>
  ce:	f8b9 3248 	ldrh.w	r3, [r9, #584]	@ 0x248
  d2:	9305      	str	r3, [sp, #20]
  d4:	2b00      	cmp	r3, #0
  d6:	f000 80d4 	beq.w	282 <Replay_Insert+0x282>
  da:	f8b9 324a 	ldrh.w	r3, [r9, #586]	@ 0x24a
  de:	9304      	str	r3, [sp, #16]
  e0:	2bcf      	cmp	r3, #207	@ 0xcf
  e2:	f200 812f 	bhi.w	344 <Replay_Insert+0x344>
  e6:	2b00      	cmp	r3, #0
  e8:	f000 810b 	beq.w	302 <Replay_Insert+0x302>
  ec:	9a04      	ldr	r2, [sp, #16]
  ee:	f8d8 e014 	ldr.w	lr, [r8, #20]
  f2:	eb02 0cc2 	add.w	ip, r2, r2, lsl #3
  f6:	ea4f 0bc2 	mov.w	fp, r2, lsl #3
  fa:	4623      	mov	r3, r4
  fc:	ea4f 02cc 	mov.w	r2, ip, lsl #3
 100:	46a2      	mov	sl, r4
 102:	eb04 0ccc 	add.w	ip, r4, ip, lsl #3
 106:	e002      	b.n	10e <Replay_Insert+0x10e>
 108:	3348      	adds	r3, #72	@ 0x48
 10a:	4563      	cmp	r3, ip
 10c:	d015      	beq.n	13a <Replay_Insert+0x13a>
 10e:	f8d3 17dc 	ldr.w	r1, [r3, #2012]	@ 0x7dc
 112:	4571      	cmp	r1, lr
 114:	d1f8      	bne.n	108 <Replay_Insert+0x108>
 116:	f8d3 47d8 	ldr.w	r4, [r3, #2008]	@ 0x7d8
 11a:	f8d8 1010 	ldr.w	r1, [r8, #16]
 11e:	428c      	cmp	r4, r1
 120:	d1f2      	bne.n	108 <Replay_Insert+0x108>
 122:	f893 47e4 	ldrb.w	r4, [r3, #2020]	@ 0x7e4
 126:	f898 101c 	ldrb.w	r1, [r8, #28]
 12a:	428c      	cmp	r4, r1
 12c:	d1ec      	bne.n	108 <Replay_Insert+0x108>
 12e:	2004      	movs	r0, #4
 130:	e000      	b.n	134 <Replay_Insert+0x134>
 132:	2001      	movs	r0, #1
 134:	b009      	add	sp, #36	@ 0x24
 136:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 13a:	f502 63f0 	add.w	r3, r2, #1920	@ 0x780
 13e:	9a04      	ldr	r2, [sp, #16]
 140:	4654      	mov	r4, sl
 142:	449a      	add	sl, r3
 144:	9b14      	ldr	r3, [sp, #80]	@ 0x50
 146:	9407      	str	r4, [sp, #28]
 148:	ebab 0b02 	sub.w	fp, fp, r2
 14c:	eb03 0b8b 	add.w	fp, r3, fp, lsl #2
 150:	4614      	mov	r4, r2
 152:	9b06      	ldr	r3, [sp, #24]
 154:	e022      	b.n	19c <Replay_Insert+0x19c>
 156:	4288      	cmp	r0, r1
 158:	4193      	sbcs	r3, r2
 15a:	f080 80fa 	bcs.w	352 <Replay_Insert+0x352>
 15e:	2248      	movs	r2, #72	@ 0x48
 160:	4651      	mov	r1, sl
 162:	eb0a 0002 	add.w	r0, sl, r2
 166:	f7ff fffe 	bl	0 <memcpy>
			166: R_ARM_THM_CALL	memcpy
 16a:	9b14      	ldr	r3, [sp, #80]	@ 0x50
 16c:	b15b      	cbz	r3, 186 <Replay_Insert+0x186>
 16e:	f20b 6e24 	addw	lr, fp, #1572	@ 0x624
 172:	e8be 000f 	ldmia.w	lr!, {r0, r1, r2, r3}
 176:	f50b 6cc8 	add.w	ip, fp, #1600	@ 0x640
 17a:	e8ac 000f 	stmia.w	ip!, {r0, r1, r2, r3}
 17e:	e89e 0007 	ldmia.w	lr, {r0, r1, r2}
 182:	e88c 0007 	stmia.w	ip, {r0, r1, r2}
 186:	3c01      	subs	r4, #1
 188:	b2a4      	uxth	r4, r4
 18a:	f1aa 0a48 	sub.w	sl, sl, #72	@ 0x48
 18e:	f1ab 0b1c 	sub.w	fp, fp, #28
 192:	2c00      	cmp	r4, #0
 194:	f000 80b4 	beq.w	300 <Replay_Insert+0x300>
 198:	e9d8 0300 	ldrd	r0, r3, [r8]
 19c:	e9da 1200 	ldrd	r1, r2, [sl]
 1a0:	4293      	cmp	r3, r2
 1a2:	bf08      	it	eq
 1a4:	4288      	cmpeq	r0, r1
 1a6:	d1d6      	bne.n	156 <Replay_Insert+0x156>
 1a8:	f898 201c 	ldrb.w	r2, [r8, #28]
 1ac:	f89a 301c 	ldrb.w	r3, [sl, #28]
 1b0:	429a      	cmp	r2, r3
 1b2:	d04d      	beq.n	250 <Replay_Insert+0x250>
 1b4:	d3d3      	bcc.n	15e <Replay_Insert+0x15e>
 1b6:	9406      	str	r4, [sp, #24]
 1b8:	f8dd b018 	ldr.w	fp, [sp, #24]
 1bc:	9c07      	ldr	r4, [sp, #28]
 1be:	eb0b 00cb 	add.w	r0, fp, fp, lsl #3
 1c2:	eb04 00c0 	add.w	r0, r4, r0, lsl #3
 1c6:	f500 60f9 	add.w	r0, r0, #1992	@ 0x7c8
 1ca:	2248      	movs	r2, #72	@ 0x48
 1cc:	4641      	mov	r1, r8
 1ce:	f7ff fffe 	bl	0 <memcpy>
			1ce: R_ARM_THM_CALL	memcpy
 1d2:	9b04      	ldr	r3, [sp, #16]
 1d4:	3301      	adds	r3, #1
 1d6:	f8a9 324a 	strh.w	r3, [r9, #586]	@ 0x24a
 1da:	9b14      	ldr	r3, [sp, #80]	@ 0x50
 1dc:	ea4f 0acb 	mov.w	sl, fp, lsl #3
 1e0:	2b00      	cmp	r3, #0
 1e2:	f000 8093 	beq.w	30c <Replay_Insert+0x30c>
 1e6:	f8dd e054 	ldr.w	lr, [sp, #84]	@ 0x54
 1ea:	ebaa 0c0b 	sub.w	ip, sl, fp
 1ee:	eb03 0c8c 	add.w	ip, r3, ip, lsl #2
 1f2:	e8be 000f 	ldmia.w	lr!, {r0, r1, r2, r3}
 1f6:	f50c 6cc8 	add.w	ip, ip, #1600	@ 0x640
 1fa:	e8ac 000f 	stmia.w	ip!, {r0, r1, r2, r3}
 1fe:	e89e 0007 	ldmia.w	lr, {r0, r1, r2}
 202:	e88c 0007 	stmia.w	ip, {r0, r1, r2}
 206:	9a16      	ldr	r2, [sp, #88]	@ 0x58
 208:	9203      	str	r2, [sp, #12]
 20a:	9a14      	ldr	r2, [sp, #80]	@ 0x50
 20c:	9202      	str	r2, [sp, #8]
 20e:	9a13      	ldr	r2, [sp, #76]	@ 0x4c
 210:	9201      	str	r2, [sp, #4]
 212:	9b05      	ldr	r3, [sp, #20]
 214:	f8cd 8000 	str.w	r8, [sp]
 218:	463a      	mov	r2, r7
 21a:	4631      	mov	r1, r6
 21c:	4620      	mov	r0, r4
 21e:	f7ff fffe 	bl	0 <Replay_Insert>
			21e: R_ARM_THM_CALL	Replay_Run
 222:	bba8      	cbnz	r0, 290 <Replay_Insert+0x290>
 224:	f44f 7278 	mov.w	r2, #992	@ 0x3e0
 228:	18a1      	adds	r1, r4, r2
 22a:	4628      	mov	r0, r5
 22c:	f7ff fffe 	bl	0 <memcpy>
			22c: R_ARM_THM_CALL	memcpy
 230:	f8d9 324c 	ldr.w	r3, [r9, #588]	@ 0x24c
 234:	9914      	ldr	r1, [sp, #80]	@ 0x50
 236:	3301      	adds	r3, #1
 238:	f8c9 324c 	str.w	r3, [r9, #588]	@ 0x24c
 23c:	9b14      	ldr	r3, [sp, #80]	@ 0x50
 23e:	2270      	movs	r2, #112	@ 0x70
 240:	f501 71c0 	add.w	r1, r1, #384	@ 0x180
 244:	f503 7088 	add.w	r0, r3, #272	@ 0x110
 248:	f7ff fffe 	bl	0 <memcpy>
			248: R_ARM_THM_CALL	memcpy
 24c:	2000      	movs	r0, #0
 24e:	e771      	b.n	134 <Replay_Insert+0x134>
 250:	f8d8 2014 	ldr.w	r2, [r8, #20]
 254:	f8da 3014 	ldr.w	r3, [sl, #20]
 258:	429a      	cmp	r2, r3
 25a:	d006      	beq.n	26a <Replay_Insert+0x26a>
 25c:	bf34      	ite	cc
 25e:	2301      	movcc	r3, #1
 260:	2300      	movcs	r3, #0
 262:	2b00      	cmp	r3, #0
 264:	f47f af7b 	bne.w	15e <Replay_Insert+0x15e>
 268:	e7a5      	b.n	1b6 <Replay_Insert+0x1b6>
 26a:	f8d8 3010 	ldr.w	r3, [r8, #16]
 26e:	f8da 2010 	ldr.w	r2, [sl, #16]
 272:	4293      	cmp	r3, r2
 274:	bf2c      	ite	cs
 276:	2300      	movcs	r3, #0
 278:	2301      	movcc	r3, #1
 27a:	2b00      	cmp	r3, #0
 27c:	f47f af6f 	bne.w	15e <Replay_Insert+0x15e>
 280:	e799      	b.n	1b6 <Replay_Insert+0x1b6>
 282:	f8d9 3250 	ldr.w	r3, [r9, #592]	@ 0x250
 286:	3301      	adds	r3, #1
 288:	2002      	movs	r0, #2
 28a:	f8c9 3250 	str.w	r3, [r9, #592]	@ 0x250
 28e:	e751      	b.n	134 <Replay_Insert+0x134>
 290:	9b06      	ldr	r3, [sp, #24]
 292:	f8b9 524a 	ldrh.w	r5, [r9, #586]	@ 0x24a
 296:	3301      	adds	r3, #1
 298:	b29b      	uxth	r3, r3
 29a:	42ab      	cmp	r3, r5
 29c:	d22c      	bcs.n	2f8 <Replay_Insert+0x2f8>
 29e:	9a06      	ldr	r2, [sp, #24]
 2a0:	1eab      	subs	r3, r5, #2
 2a2:	1a9b      	subs	r3, r3, r2
 2a4:	fa12 f383 	uxtah	r3, r2, r3
 2a8:	eb02 06c2 	add.w	r6, r2, r2, lsl #3
 2ac:	eb03 03c3 	add.w	r3, r3, r3, lsl #3
 2b0:	eb04 06c6 	add.w	r6, r4, r6, lsl #3
 2b4:	3448      	adds	r4, #72	@ 0x48
 2b6:	eb04 08c3 	add.w	r8, r4, r3, lsl #3
 2ba:	9b14      	ldr	r3, [sp, #80]	@ 0x50
 2bc:	ebc2 02c2 	rsb	r2, r2, r2, lsl #3
 2c0:	eb03 0782 	add.w	r7, r3, r2, lsl #2
 2c4:	4682      	mov	sl, r0
 2c6:	f506 6101 	add.w	r1, r6, #2064	@ 0x810
 2ca:	f506 60f9 	add.w	r0, r6, #1992	@ 0x7c8
 2ce:	2248      	movs	r2, #72	@ 0x48
 2d0:	f7ff fffe 	bl	0 <memcpy>
			2d0: R_ARM_THM_CALL	memcpy
 2d4:	9b14      	ldr	r3, [sp, #80]	@ 0x50
 2d6:	f207 6c5c 	addw	ip, r7, #1628	@ 0x65c
 2da:	f507 64c8 	add.w	r4, r7, #1600	@ 0x640
 2de:	3648      	adds	r6, #72	@ 0x48
 2e0:	371c      	adds	r7, #28
 2e2:	b133      	cbz	r3, 2f2 <Replay_Insert+0x2f2>
 2e4:	e8bc 000f 	ldmia.w	ip!, {r0, r1, r2, r3}
 2e8:	c40f      	stmia	r4!, {r0, r1, r2, r3}
 2ea:	e89c 0007 	ldmia.w	ip, {r0, r1, r2}
 2ee:	e884 0007 	stmia.w	r4, {r0, r1, r2}
 2f2:	4546      	cmp	r6, r8
 2f4:	d1e7      	bne.n	2c6 <Replay_Insert+0x2c6>
 2f6:	4650      	mov	r0, sl
 2f8:	3d01      	subs	r5, #1
 2fa:	f8a9 524a 	strh.w	r5, [r9, #586]	@ 0x24a
 2fe:	e719      	b.n	134 <Replay_Insert+0x134>
 300:	9c07      	ldr	r4, [sp, #28]
 302:	f04f 0b00 	mov.w	fp, #0
 306:	f8cd b018 	str.w	fp, [sp, #24]
 30a:	e758      	b.n	1be <Replay_Insert+0x1be>
 30c:	9b16      	ldr	r3, [sp, #88]	@ 0x58
 30e:	9303      	str	r3, [sp, #12]
 310:	9b14      	ldr	r3, [sp, #80]	@ 0x50
 312:	9302      	str	r3, [sp, #8]
 314:	9b13      	ldr	r3, [sp, #76]	@ 0x4c
 316:	9301      	str	r3, [sp, #4]
 318:	f8cd 8000 	str.w	r8, [sp]
 31c:	9b05      	ldr	r3, [sp, #20]
 31e:	463a      	mov	r2, r7
 320:	4631      	mov	r1, r6
 322:	4620      	mov	r0, r4
 324:	f7ff fffe 	bl	0 <Replay_Insert>
			324: R_ARM_THM_CALL	Replay_Run
 328:	2800      	cmp	r0, #0
 32a:	d1b1      	bne.n	290 <Replay_Insert+0x290>
 32c:	f44f 7278 	mov.w	r2, #992	@ 0x3e0
 330:	18a1      	adds	r1, r4, r2
 332:	4628      	mov	r0, r5
 334:	f7ff fffe 	bl	0 <memcpy>
			334: R_ARM_THM_CALL	memcpy
 338:	f8d9 324c 	ldr.w	r3, [r9, #588]	@ 0x24c
 33c:	3301      	adds	r3, #1
 33e:	f8c9 324c 	str.w	r3, [r9, #588]	@ 0x24c
 342:	e783      	b.n	24c <Replay_Insert+0x24c>
 344:	f8d9 3254 	ldr.w	r3, [r9, #596]	@ 0x254
 348:	3301      	adds	r3, #1
 34a:	2003      	movs	r0, #3
 34c:	f8c9 3254 	str.w	r3, [r9, #596]	@ 0x254
 350:	e6f0      	b.n	134 <Replay_Insert+0x134>
 352:	46a3      	mov	fp, r4
 354:	9406      	str	r4, [sp, #24]
 356:	9c07      	ldr	r4, [sp, #28]
 358:	e731      	b.n	1be <Replay_Insert+0x1be>
 35a:	bf00      	nop
 35c:	00000000 	.word	0x00000000
			35c: R_ARM_ABS32	.rodata.Replay_PropagatePart.str1.4

Disassembly of section .text.Replay_Predict:

00000000 <Replay_Predict>:
   0:	2800      	cmp	r0, #0
   2:	f000 80be 	beq.w	182 <Replay_Predict+0x182>
   6:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
   a:	461f      	mov	r7, r3
   c:	f8d0 37c0 	ldr.w	r3, [r0, #1984]	@ 0x7c0
  10:	b087      	sub	sp, #28
  12:	4604      	mov	r4, r0
  14:	b17b      	cbz	r3, 36 <Replay_Predict+0x36>
  16:	460d      	mov	r5, r1
  18:	b169      	cbz	r1, 36 <Replay_Predict+0x36>
  1a:	4616      	mov	r6, r2
  1c:	b15a      	cbz	r2, 36 <Replay_Predict+0x36>
  1e:	9b10      	ldr	r3, [sp, #64]	@ 0x40
  20:	b14b      	cbz	r3, 36 <Replay_Predict+0x36>
  22:	f500 4880 	add.w	r8, r0, #16384	@ 0x4000
  26:	f8b8 3248 	ldrh.w	r3, [r8, #584]	@ 0x248
  2a:	2bc0      	cmp	r3, #192	@ 0xc0
  2c:	d803      	bhi.n	36 <Replay_Predict+0x36>
  2e:	f8b8 324a 	ldrh.w	r3, [r8, #586]	@ 0x24a
  32:	2bd0      	cmp	r3, #208	@ 0xd0
  34:	d903      	bls.n	3e <Replay_Predict+0x3e>
  36:	2001      	movs	r0, #1
  38:	b007      	add	sp, #28
  3a:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
  3e:	9811      	ldr	r0, [sp, #68]	@ 0x44
  40:	f7ff fffe 	bl	0 <Replay_Predict>
			40: R_ARM_THM_CALL	Replay_RecoveryReady
  44:	2800      	cmp	r0, #0
  46:	d0f6      	beq.n	36 <Replay_Predict+0x36>
  48:	23d5      	movs	r3, #213	@ 0xd5
  4a:	9300      	str	r3, [sp, #0]
  4c:	2202      	movs	r2, #2
  4e:	4bb8      	ldr	r3, [pc, #736]	@ (330 <Replay_Predict+0x330>)
  50:	2108      	movs	r1, #8
  52:	4620      	mov	r0, r4
  54:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			54: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  58:	23d6      	movs	r3, #214	@ 0xd6
  5a:	9300      	str	r3, [sp, #0]
  5c:	2202      	movs	r2, #2
  5e:	4bb4      	ldr	r3, [pc, #720]	@ (330 <Replay_Predict+0x330>)
  60:	2108      	movs	r1, #8
  62:	4628      	mov	r0, r5
  64:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			64: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  68:	9b10      	ldr	r3, [sp, #64]	@ 0x40
  6a:	6d1b      	ldr	r3, [r3, #80]	@ 0x50
  6c:	071b      	lsls	r3, r3, #28
  6e:	f100 808a 	bmi.w	186 <Replay_Predict+0x186>
  72:	9b10      	ldr	r3, [sp, #64]	@ 0x40
  74:	e9d5 01f2 	ldrd	r0, r1, [r5, #968]	@ 0x3c8
  78:	e9d3 230e 	ldrd	r2, r3, [r3, #56]	@ 0x38
  7c:	428b      	cmp	r3, r1
  7e:	bf08      	it	eq
  80:	4282      	cmpeq	r2, r0
  82:	d1d8      	bne.n	36 <Replay_Predict+0x36>
  84:	9910      	ldr	r1, [sp, #64]	@ 0x40
  86:	e9d1 0e10 	ldrd	r0, lr, [r1, #64]	@ 0x40
  8a:	4282      	cmp	r2, r0
  8c:	eb73 030e 	sbcs.w	r3, r3, lr
  90:	d2d1      	bcs.n	36 <Replay_Predict+0x36>
  92:	f8b8 9248 	ldrh.w	r9, [r8, #584]	@ 0x248
  96:	f1b9 0f00 	cmp.w	r9, #0
  9a:	d029      	beq.n	f0 <Replay_Predict+0xf0>
  9c:	f04f 0c00 	mov.w	ip, #0
  a0:	e9cd 4504 	strd	r4, r5, [sp, #16]
  a4:	f8d4 17c0 	ldr.w	r1, [r4, #1984]	@ 0x7c0
  a8:	46e3      	mov	fp, ip
  aa:	e00b      	b.n	c4 <Replay_Predict+0xc4>
  ac:	4da1      	ldr	r5, [pc, #644]	@ (334 <Replay_Predict+0x334>)
  ae:	1a82      	subs	r2, r0, r2
  b0:	eb6e 0303 	sbc.w	r3, lr, r3
  b4:	4295      	cmp	r5, r2
  b6:	eb7b 0303 	sbcs.w	r3, fp, r3
  ba:	d20d      	bcs.n	d8 <Replay_Predict+0xd8>
  bc:	fa1f fc84 	uxth.w	ip, r4
  c0:	45cc      	cmp	ip, r9
  c2:	d066      	beq.n	192 <Replay_Predict+0x192>
  c4:	680a      	ldr	r2, [r1, #0]
  c6:	684b      	ldr	r3, [r1, #4]
  c8:	4290      	cmp	r0, r2
  ca:	eb7e 0a03 	sbcs.w	sl, lr, r3
  ce:	f10c 0401 	add.w	r4, ip, #1
  d2:	f101 0140 	add.w	r1, r1, #64	@ 0x40
  d6:	d2e9      	bcs.n	ac <Replay_Predict+0xac>
  d8:	eba9 030c 	sub.w	r3, r9, ip
  dc:	b29b      	uxth	r3, r3
  de:	2bbf      	cmp	r3, #191	@ 0xbf
  e0:	e9dd 4504 	ldrd	r4, r5, [sp, #16]
  e4:	f200 8117 	bhi.w	316 <Replay_Predict+0x316>
  e8:	f1bc 0f00 	cmp.w	ip, #0
  ec:	f040 811c 	bne.w	328 <Replay_Predict+0x328>
  f0:	9b10      	ldr	r3, [sp, #64]	@ 0x40
  f2:	463a      	mov	r2, r7
  f4:	4631      	mov	r1, r6
  f6:	4628      	mov	r0, r5
  f8:	f7ff fffe 	bl	0 <NavigationEskf_Predict>
			f8: R_ARM_THM_CALL	NavigationEskf_Predict
  fc:	2800      	cmp	r0, #0
  fe:	f040 8111 	bne.w	324 <Replay_Predict+0x324>
 102:	f8d4 e7c0 	ldr.w	lr, [r4, #1984]	@ 0x7c0
 106:	f8b8 3248 	ldrh.w	r3, [r8, #584]	@ 0x248
 10a:	9a10      	ldr	r2, [sp, #64]	@ 0x40
 10c:	9d10      	ldr	r5, [sp, #64]	@ 0x40
 10e:	e9d2 0110 	ldrd	r0, r1, [r2, #64]	@ 0x40
 112:	eb0e 1383 	add.w	r3, lr, r3, lsl #6
 116:	e9c3 0100 	strd	r0, r1, [r3]
 11a:	6b11      	ldr	r1, [r2, #48]	@ 0x30
 11c:	6d12      	ldr	r2, [r2, #80]	@ 0x50
 11e:	63da      	str	r2, [r3, #60]	@ 0x3c
 120:	6399      	str	r1, [r3, #56]	@ 0x38
 122:	9a10      	ldr	r2, [sp, #64]	@ 0x40
 124:	9910      	ldr	r1, [sp, #64]	@ 0x40
 126:	9810      	ldr	r0, [sp, #64]	@ 0x40
 128:	6812      	ldr	r2, [r2, #0]
 12a:	6849      	ldr	r1, [r1, #4]
 12c:	6880      	ldr	r0, [r0, #8]
 12e:	68ed      	ldr	r5, [r5, #12]
 130:	609a      	str	r2, [r3, #8]
 132:	60d9      	str	r1, [r3, #12]
 134:	9a10      	ldr	r2, [sp, #64]	@ 0x40
 136:	9910      	ldr	r1, [sp, #64]	@ 0x40
 138:	6118      	str	r0, [r3, #16]
 13a:	615d      	str	r5, [r3, #20]
 13c:	6912      	ldr	r2, [r2, #16]
 13e:	6949      	ldr	r1, [r1, #20]
 140:	61d9      	str	r1, [r3, #28]
 142:	619a      	str	r2, [r3, #24]
 144:	f8b8 1248 	ldrh.w	r1, [r8, #584]	@ 0x248
 148:	f8d4 37c0 	ldr.w	r3, [r4, #1984]	@ 0x7c0
 14c:	9a10      	ldr	r2, [sp, #64]	@ 0x40
 14e:	9810      	ldr	r0, [sp, #64]	@ 0x40
 150:	6992      	ldr	r2, [r2, #24]
 152:	eb03 1381 	add.w	r3, r3, r1, lsl #6
 156:	9910      	ldr	r1, [sp, #64]	@ 0x40
 158:	69c9      	ldr	r1, [r1, #28]
 15a:	6a00      	ldr	r0, [r0, #32]
 15c:	9c10      	ldr	r4, [sp, #64]	@ 0x40
 15e:	6a64      	ldr	r4, [r4, #36]	@ 0x24
 160:	621a      	str	r2, [r3, #32]
 162:	6259      	str	r1, [r3, #36]	@ 0x24
 164:	9a10      	ldr	r2, [sp, #64]	@ 0x40
 166:	9910      	ldr	r1, [sp, #64]	@ 0x40
 168:	6298      	str	r0, [r3, #40]	@ 0x28
 16a:	62dc      	str	r4, [r3, #44]	@ 0x2c
 16c:	6a92      	ldr	r2, [r2, #40]	@ 0x28
 16e:	6ac9      	ldr	r1, [r1, #44]	@ 0x2c
 170:	6359      	str	r1, [r3, #52]	@ 0x34
 172:	631a      	str	r2, [r3, #48]	@ 0x30
 174:	f8b8 3248 	ldrh.w	r3, [r8, #584]	@ 0x248
 178:	3301      	adds	r3, #1
 17a:	2000      	movs	r0, #0
 17c:	f8a8 3248 	strh.w	r3, [r8, #584]	@ 0x248
 180:	e75a      	b.n	38 <Replay_Predict+0x38>
 182:	2001      	movs	r0, #1
 184:	4770      	bx	lr
 186:	f8b8 3248 	ldrh.w	r3, [r8, #584]	@ 0x248
 18a:	2b00      	cmp	r3, #0
 18c:	f43f af71 	beq.w	72 <Replay_Predict+0x72>
 190:	e751      	b.n	36 <Replay_Predict+0x36>
 192:	e9dd 4504 	ldrd	r4, r5, [sp, #16]
 196:	9b11      	ldr	r3, [sp, #68]	@ 0x44
 198:	9302      	str	r3, [sp, #8]
 19a:	2300      	movs	r3, #0
 19c:	e9cd 3300 	strd	r3, r3, [sp]
 1a0:	9303      	str	r3, [sp, #12]
 1a2:	463a      	mov	r2, r7
 1a4:	464b      	mov	r3, r9
 1a6:	4631      	mov	r1, r6
 1a8:	4620      	mov	r0, r4
 1aa:	f7ff fffe 	bl	0 <Replay_Predict>
			1aa: R_ARM_THM_CALL	Replay_Run
 1ae:	2800      	cmp	r0, #0
 1b0:	f47f af42 	bne.w	38 <Replay_Predict+0x38>
 1b4:	9b10      	ldr	r3, [sp, #64]	@ 0x40
 1b6:	463a      	mov	r2, r7
 1b8:	4631      	mov	r1, r6
 1ba:	4628      	mov	r0, r5
 1bc:	f7ff fffe 	bl	0 <NavigationEskf_Predict>
			1bc: R_ARM_THM_CALL	NavigationEskf_Predict
 1c0:	2800      	cmp	r0, #0
 1c2:	f040 80af 	bne.w	324 <Replay_Predict+0x324>
 1c6:	22b9      	movs	r2, #185	@ 0xb9
 1c8:	4b59      	ldr	r3, [pc, #356]	@ (330 <Replay_Predict+0x330>)
 1ca:	9200      	str	r2, [sp, #0]
 1cc:	2108      	movs	r1, #8
 1ce:	2202      	movs	r2, #2
 1d0:	4620      	mov	r0, r4
 1d2:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			1d2: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
 1d6:	f8b8 0248 	ldrh.w	r0, [r8, #584]	@ 0x248
 1da:	4a55      	ldr	r2, [pc, #340]	@ (330 <Replay_Predict+0x330>)
 1dc:	4548      	cmp	r0, r9
 1de:	f04f 0305 	mov.w	r3, #5
 1e2:	bf34      	ite	cc
 1e4:	2000      	movcc	r0, #0
 1e6:	2001      	movcs	r0, #1
 1e8:	9300      	str	r3, [sp, #0]
 1ea:	2102      	movs	r1, #2
 1ec:	23ba      	movs	r3, #186	@ 0xba
 1ee:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			1ee: R_ARM_THM_CALL	SilverStarAssert_Check
 1f2:	f44f 7278 	mov.w	r2, #992	@ 0x3e0
 1f6:	18a1      	adds	r1, r4, r2
 1f8:	4620      	mov	r0, r4
 1fa:	f7ff fffe 	bl	0 <memcpy>
			1fa: R_ARM_THM_CALL	memcpy
 1fe:	9b11      	ldr	r3, [sp, #68]	@ 0x44
 200:	b133      	cbz	r3, 210 <Replay_Predict+0x210>
 202:	2270      	movs	r2, #112	@ 0x70
 204:	f503 71c0 	add.w	r1, r3, #384	@ 0x180
 208:	f103 00a0 	add.w	r0, r3, #160	@ 0xa0
 20c:	f7ff fffe 	bl	0 <memcpy>
			20c: R_ARM_THM_CALL	memcpy
 210:	f8b8 024a 	ldrh.w	r0, [r8, #586]	@ 0x24a
 214:	2800      	cmp	r0, #0
 216:	f000 8089 	beq.w	32c <Replay_Predict+0x32c>
 21a:	f504 63f9 	add.w	r3, r4, #1992	@ 0x7c8
 21e:	eb00 0cc0 	add.w	ip, r0, r0, lsl #3
 222:	f8d4 e3c8 	ldr.w	lr, [r4, #968]	@ 0x3c8
 226:	f8d4 13cc 	ldr.w	r1, [r4, #972]	@ 0x3cc
 22a:	eb03 0ccc 	add.w	ip, r3, ip, lsl #3
 22e:	4625      	mov	r5, r4
 230:	2200      	movs	r2, #0
 232:	681f      	ldr	r7, [r3, #0]
 234:	685e      	ldr	r6, [r3, #4]
 236:	45be      	cmp	lr, r7
 238:	eb71 0606 	sbcs.w	r6, r1, r6
 23c:	f102 0a01 	add.w	sl, r2, #1
 240:	f103 0348 	add.w	r3, r3, #72	@ 0x48
 244:	bf28      	it	cs
 246:	fa1f f28a 	uxthcs.w	r2, sl
 24a:	4563      	cmp	r3, ip
 24c:	d1f1      	bne.n	232 <Replay_Predict+0x232>
 24e:	4282      	cmp	r2, r0
 250:	d231      	bcs.n	2b6 <Replay_Predict+0x2b6>
 252:	1e43      	subs	r3, r0, #1
 254:	1a9b      	subs	r3, r3, r2
 256:	b29b      	uxth	r3, r3
 258:	eb02 0ac2 	add.w	sl, r2, r2, lsl #3
 25c:	ebc2 07c2 	rsb	r7, r2, r2, lsl #3
 260:	e9cd 2004 	strd	r2, r0, [sp, #16]
 264:	eb03 03c3 	add.w	r3, r3, r3, lsl #3
 268:	ea4f 0aca 	mov.w	sl, sl, lsl #3
 26c:	00bf      	lsls	r7, r7, #2
 26e:	f104 0b48 	add.w	fp, r4, #72	@ 0x48
 272:	9e11      	ldr	r6, [sp, #68]	@ 0x44
 274:	f50a 6af9 	add.w	sl, sl, #1992	@ 0x7c8
 278:	f507 67c8 	add.w	r7, r7, #1600	@ 0x640
 27c:	eb0b 0bc3 	add.w	fp, fp, r3, lsl #3
 280:	eb05 010a 	add.w	r1, r5, sl
 284:	f505 60f9 	add.w	r0, r5, #1992	@ 0x7c8
 288:	2248      	movs	r2, #72	@ 0x48
 28a:	f7ff fffe 	bl	0 <memcpy>
			28a: R_ARM_THM_CALL	memcpy
 28e:	9b11      	ldr	r3, [sp, #68]	@ 0x44
 290:	eb06 0e07 	add.w	lr, r6, r7
 294:	f506 6cc8 	add.w	ip, r6, #1600	@ 0x640
 298:	3548      	adds	r5, #72	@ 0x48
 29a:	361c      	adds	r6, #28
 29c:	b13b      	cbz	r3, 2ae <Replay_Predict+0x2ae>
 29e:	e8be 000f 	ldmia.w	lr!, {r0, r1, r2, r3}
 2a2:	e8ac 000f 	stmia.w	ip!, {r0, r1, r2, r3}
 2a6:	e89e 0007 	ldmia.w	lr, {r0, r1, r2}
 2aa:	e88c 0007 	stmia.w	ip, {r0, r1, r2}
 2ae:	45ab      	cmp	fp, r5
 2b0:	d1e6      	bne.n	280 <Replay_Predict+0x280>
 2b2:	e9dd 2004 	ldrd	r2, r0, [sp, #16]
 2b6:	f8b8 6248 	ldrh.w	r6, [r8, #584]	@ 0x248
 2ba:	f8d4 e7c0 	ldr.w	lr, [r4, #1984]	@ 0x7c0
 2be:	1a80      	subs	r0, r0, r2
 2c0:	454e      	cmp	r6, r9
 2c2:	f8a8 024a 	strh.w	r0, [r8, #586]	@ 0x24a
 2c6:	d920      	bls.n	30a <Replay_Predict+0x30a>
 2c8:	f106 3cff 	add.w	ip, r6, #4294967295
 2cc:	ebac 0c09 	sub.w	ip, ip, r9
 2d0:	fa1f fc8c 	uxth.w	ip, ip
 2d4:	f10c 0c01 	add.w	ip, ip, #1
 2d8:	ea4f 1c8c 	mov.w	ip, ip, lsl #6
 2dc:	eb0e 1a89 	add.w	sl, lr, r9, lsl #6
 2e0:	2700      	movs	r7, #0
 2e2:	eb0a 0b07 	add.w	fp, sl, r7
 2e6:	e8bb 000f 	ldmia.w	fp!, {r0, r1, r2, r3}
 2ea:	eb0e 0507 	add.w	r5, lr, r7
 2ee:	c50f      	stmia	r5!, {r0, r1, r2, r3}
 2f0:	e8bb 000f 	ldmia.w	fp!, {r0, r1, r2, r3}
 2f4:	c50f      	stmia	r5!, {r0, r1, r2, r3}
 2f6:	e8bb 000f 	ldmia.w	fp!, {r0, r1, r2, r3}
 2fa:	c50f      	stmia	r5!, {r0, r1, r2, r3}
 2fc:	e89b 000f 	ldmia.w	fp, {r0, r1, r2, r3}
 300:	3740      	adds	r7, #64	@ 0x40
 302:	45bc      	cmp	ip, r7
 304:	e885 000f 	stmia.w	r5, {r0, r1, r2, r3}
 308:	d1eb      	bne.n	2e2 <Replay_Predict+0x2e2>
 30a:	eba6 0309 	sub.w	r3, r6, r9
 30e:	b29b      	uxth	r3, r3
 310:	f8a8 3248 	strh.w	r3, [r8, #584]	@ 0x248
 314:	e6f9      	b.n	10a <Replay_Predict+0x10a>
 316:	f8d8 3254 	ldr.w	r3, [r8, #596]	@ 0x254
 31a:	3301      	adds	r3, #1
 31c:	2003      	movs	r0, #3
 31e:	f8c8 3254 	str.w	r3, [r8, #596]	@ 0x254
 322:	e689      	b.n	38 <Replay_Predict+0x38>
 324:	2005      	movs	r0, #5
 326:	e687      	b.n	38 <Replay_Predict+0x38>
 328:	46e1      	mov	r9, ip
 32a:	e734      	b.n	196 <Replay_Predict+0x196>
 32c:	4602      	mov	r2, r0
 32e:	e7c2      	b.n	2b6 <Replay_Predict+0x2b6>
 330:	00000000 	.word	0x00000000
			330: R_ARM_ABS32	.rodata.Replay_PropagatePart.str1.4
 334:	000927bf 	.word	0x000927bf

Disassembly of section .text.NavigationEskfReplay_Reset:

00000000 <NavigationEskfReplay_Reset>:
   0:	b1f8      	cbz	r0, 42 <NavigationEskfReplay_Reset+0x42>
   2:	b570      	push	{r4, r5, r6, lr}
   4:	460c      	mov	r4, r1
   6:	b121      	cbz	r1, 12 <NavigationEskfReplay_Reset+0x12>
   8:	4616      	mov	r6, r2
   a:	b112      	cbz	r2, 12 <NavigationEskfReplay_Reset+0x12>
   c:	f891 33d8 	ldrb.w	r3, [r1, #984]	@ 0x3d8
  10:	b90b      	cbnz	r3, 16 <NavigationEskfReplay_Reset+0x16>
  12:	2001      	movs	r0, #1
  14:	bd70      	pop	{r4, r5, r6, pc}
  16:	4605      	mov	r5, r0
  18:	f244 2260 	movw	r2, #16992	@ 0x4260
  1c:	2100      	movs	r1, #0
  1e:	f7ff fffe 	bl	0 <memset>
			1e: R_ARM_THM_CALL	memset
  22:	4621      	mov	r1, r4
  24:	f44f 7278 	mov.w	r2, #992	@ 0x3e0
  28:	f8c5 67c0 	str.w	r6, [r5, #1984]	@ 0x7c0
  2c:	4628      	mov	r0, r5
  2e:	f7ff fffe 	bl	0 <memcpy>
			2e: R_ARM_THM_CALL	memcpy
  32:	f44f 7278 	mov.w	r2, #992	@ 0x3e0
  36:	4621      	mov	r1, r4
  38:	18a8      	adds	r0, r5, r2
  3a:	f7ff fffe 	bl	0 <memcpy>
			3a: R_ARM_THM_CALL	memcpy
  3e:	2000      	movs	r0, #0
  40:	bd70      	pop	{r4, r5, r6, pc}
  42:	2001      	movs	r0, #1
  44:	4770      	bx	lr
  46:	bf00      	nop

Disassembly of section .text.NavigationEskfReplay_Predict:

00000000 <NavigationEskfReplay_Predict>:
   0:	b510      	push	{r4, lr}
   2:	b082      	sub	sp, #8
   4:	9c04      	ldr	r4, [sp, #16]
   6:	9400      	str	r4, [sp, #0]
   8:	2400      	movs	r4, #0
   a:	9401      	str	r4, [sp, #4]
   c:	f7ff fffe 	bl	0 <NavigationEskfReplay_Predict>
			c: R_ARM_THM_CALL	Replay_Predict
  10:	b002      	add	sp, #8
  12:	bd10      	pop	{r4, pc}

Disassembly of section .text.NavigationEskfReplay_Insert:

00000000 <NavigationEskfReplay_Insert>:
   0:	b510      	push	{r4, lr}
   2:	b086      	sub	sp, #24
   4:	9c08      	ldr	r4, [sp, #32]
   6:	9400      	str	r4, [sp, #0]
   8:	2400      	movs	r4, #0
   a:	e9cd 4403 	strd	r4, r4, [sp, #12]
   e:	9402      	str	r4, [sp, #8]
  10:	9c09      	ldr	r4, [sp, #36]	@ 0x24
  12:	9401      	str	r4, [sp, #4]
  14:	f7ff fffe 	bl	0 <NavigationEskfReplay_Insert>
			14: R_ARM_THM_CALL	Replay_Insert
  18:	b006      	add	sp, #24
  1a:	bd10      	pop	{r4, pc}

Disassembly of section .text.NavigationEskfReplayRecovery_Reset:

00000000 <NavigationEskfReplayRecovery_Reset>:
   0:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
   4:	461e      	mov	r6, r3
   6:	b08c      	sub	sp, #48	@ 0x30
   8:	f641 5308 	movw	r3, #7432	@ 0x1d08
   c:	e9cd 0300 	strd	r0, r3, [sp]
  10:	2301      	movs	r3, #1
  12:	f88d 3008 	strb.w	r3, [sp, #8]
  16:	f44f 7378 	mov.w	r3, #992	@ 0x3e0
  1a:	e9cd 1303 	strd	r1, r3, [sp, #12]
  1e:	2370      	movs	r3, #112	@ 0x70
  20:	2700      	movs	r7, #0
  22:	9307      	str	r3, [sp, #28]
  24:	23a0      	movs	r3, #160	@ 0xa0
  26:	4615      	mov	r5, r2
  28:	9206      	str	r2, [sp, #24]
  2a:	4604      	mov	r4, r0
  2c:	4688      	mov	r8, r1
  2e:	f88d 7014 	strb.w	r7, [sp, #20]
  32:	f88d 7020 	strb.w	r7, [sp, #32]
  36:	9609      	str	r6, [sp, #36]	@ 0x24
  38:	f88d 702c 	strb.w	r7, [sp, #44]	@ 0x2c
  3c:	930a      	str	r3, [sp, #40]	@ 0x28
  3e:	46ee      	mov	lr, sp
  40:	4602      	mov	r2, r0
  42:	b1f2      	cbz	r2, 82 <NavigationEskfReplayRecovery_Reset+0x82>
  44:	2f00      	cmp	r7, #0
  46:	d061      	beq.n	10c <NavigationEskfReplayRecovery_Reset+0x10c>
  48:	46ec      	mov	ip, sp
  4a:	e007      	b.n	5c <NavigationEskfReplayRecovery_Reset+0x5c>
  4c:	f8de 3004 	ldr.w	r3, [lr, #4]
  50:	4298      	cmp	r0, r3
  52:	d30f      	bcc.n	74 <NavigationEskfReplayRecovery_Reset+0x74>
  54:	f10c 0c0c 	add.w	ip, ip, #12
  58:	45f4      	cmp	ip, lr
  5a:	d017      	beq.n	8c <NavigationEskfReplayRecovery_Reset+0x8c>
  5c:	f8dc 3000 	ldr.w	r3, [ip]
  60:	4293      	cmp	r3, r2
  62:	eba3 0002 	sub.w	r0, r3, r2
  66:	eba2 0103 	sub.w	r1, r2, r3
  6a:	d2ef      	bcs.n	4c <NavigationEskfReplayRecovery_Reset+0x4c>
  6c:	f8dc 3004 	ldr.w	r3, [ip, #4]
  70:	4299      	cmp	r1, r3
  72:	d2ef      	bcs.n	54 <NavigationEskfReplayRecovery_Reset+0x54>
  74:	f89e 3008 	ldrb.w	r3, [lr, #8]
  78:	b91b      	cbnz	r3, 82 <NavigationEskfReplayRecovery_Reset+0x82>
  7a:	f89c 3008 	ldrb.w	r3, [ip, #8]
  7e:	2b00      	cmp	r3, #0
  80:	d0e8      	beq.n	54 <NavigationEskfReplayRecovery_Reset+0x54>
  82:	2701      	movs	r7, #1
  84:	4638      	mov	r0, r7
  86:	b00c      	add	sp, #48	@ 0x30
  88:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
  8c:	3701      	adds	r7, #1
  8e:	2f04      	cmp	r7, #4
  90:	d002      	beq.n	98 <NavigationEskfReplayRecovery_Reset+0x98>
  92:	f85e 2f0c 	ldr.w	r2, [lr, #12]!
  96:	e7d4      	b.n	42 <NavigationEskfReplayRecovery_Reset+0x42>
  98:	2c00      	cmp	r4, #0
  9a:	d0f2      	beq.n	82 <NavigationEskfReplayRecovery_Reset+0x82>
  9c:	f1b8 0f00 	cmp.w	r8, #0
  a0:	d0ef      	beq.n	82 <NavigationEskfReplayRecovery_Reset+0x82>
  a2:	2d00      	cmp	r5, #0
  a4:	d0ed      	beq.n	82 <NavigationEskfReplayRecovery_Reset+0x82>
  a6:	6caa      	ldr	r2, [r5, #72]	@ 0x48
  a8:	f8d8 33d4 	ldr.w	r3, [r8, #980]	@ 0x3d4
  ac:	429a      	cmp	r2, r3
  ae:	d1e8      	bne.n	82 <NavigationEskfReplayRecovery_Reset+0x82>
  b0:	f898 83d8 	ldrb.w	r8, [r8, #984]	@ 0x3d8
  b4:	f1b8 0f01 	cmp.w	r8, #1
  b8:	d1e3      	bne.n	82 <NavigationEskfReplayRecovery_Reset+0x82>
  ba:	4631      	mov	r1, r6
  bc:	4628      	mov	r0, r5
  be:	f7ff fffe 	bl	0 <NavigationEskfRecovery_PolicyValidate>
			be: R_ARM_THM_CALL	NavigationEskfRecovery_PolicyValidate
  c2:	4607      	mov	r7, r0
  c4:	2800      	cmp	r0, #0
  c6:	d1dc      	bne.n	82 <NavigationEskfReplayRecovery_Reset+0x82>
  c8:	4601      	mov	r1, r0
  ca:	f641 5208 	movw	r2, #7432	@ 0x1d08
  ce:	4620      	mov	r0, r4
  d0:	f7ff fffe 	bl	0 <memset>
			d0: R_ARM_THM_CALL	memset
  d4:	4631      	mov	r1, r6
  d6:	22a0      	movs	r2, #160	@ 0xa0
  d8:	4620      	mov	r0, r4
  da:	f7ff fffe 	bl	0 <memcpy>
			da: R_ARM_THM_CALL	memcpy
  de:	2270      	movs	r2, #112	@ 0x70
  e0:	4629      	mov	r1, r5
  e2:	f104 00a0 	add.w	r0, r4, #160	@ 0xa0
  e6:	f7ff fffe 	bl	0 <memcpy>
			e6: R_ARM_THM_CALL	memcpy
  ea:	2270      	movs	r2, #112	@ 0x70
  ec:	4629      	mov	r1, r5
  ee:	f504 7088 	add.w	r0, r4, #272	@ 0x110
  f2:	f7ff fffe 	bl	0 <memcpy>
			f2: R_ARM_THM_CALL	memcpy
  f6:	f504 70c0 	add.w	r0, r4, #384	@ 0x180
  fa:	f504 5480 	add.w	r4, r4, #4096	@ 0x1000
  fe:	2270      	movs	r2, #112	@ 0x70
 100:	4629      	mov	r1, r5
 102:	f7ff fffe 	bl	0 <memcpy>
			102: R_ARM_THM_CALL	memcpy
 106:	f884 8d00 	strb.w	r8, [r4, #3328]	@ 0xd00
 10a:	e7bb      	b.n	84 <NavigationEskfReplayRecovery_Reset+0x84>
 10c:	2701      	movs	r7, #1
 10e:	e7c0      	b.n	92 <NavigationEskfReplayRecovery_Reset+0x92>

Disassembly of section .text.NavigationEskfReplayRecovery_Predict:

00000000 <NavigationEskfReplayRecovery_Predict>:
   0:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
   4:	b096      	sub	sp, #88	@ 0x58
   6:	e9dd 981e 	ldrd	r9, r8, [sp, #120]	@ 0x78
   a:	2800      	cmp	r0, #0
   c:	d050      	beq.n	b0 <NavigationEskfReplayRecovery_Predict+0xb0>
   e:	2401      	movs	r4, #1
  10:	f88d 400c 	strb.w	r4, [sp, #12]
  14:	f88d 4018 	strb.w	r4, [sp, #24]
  18:	f88d 4024 	strb.w	r4, [sp, #36]	@ 0x24
  1c:	f88d 4030 	strb.w	r4, [sp, #48]	@ 0x30
  20:	f88d 4054 	strb.w	r4, [sp, #84]	@ 0x54
  24:	f8d0 47c0 	ldr.w	r4, [r0, #1984]	@ 0x7c0
  28:	9413      	str	r4, [sp, #76]	@ 0x4c
  2a:	f641 5408 	movw	r4, #7432	@ 0x1d08
  2e:	9402      	str	r4, [sp, #8]
  30:	f244 2460 	movw	r4, #16992	@ 0x4260
  34:	9405      	str	r4, [sp, #20]
  36:	f44f 7478 	mov.w	r4, #992	@ 0x3e0
  3a:	9408      	str	r4, [sp, #32]
  3c:	f640 4444 	movw	r4, #3140	@ 0xc44
  40:	940b      	str	r4, [sp, #44]	@ 0x2c
  42:	242c      	movs	r4, #44	@ 0x2c
  44:	940e      	str	r4, [sp, #56]	@ 0x38
  46:	2458      	movs	r4, #88	@ 0x58
  48:	2700      	movs	r7, #0
  4a:	9411      	str	r4, [sp, #68]	@ 0x44
  4c:	f44f 5440 	mov.w	r4, #12288	@ 0x3000
  50:	f8cd 8004 	str.w	r8, [sp, #4]
  54:	9004      	str	r0, [sp, #16]
  56:	9107      	str	r1, [sp, #28]
  58:	920a      	str	r2, [sp, #40]	@ 0x28
  5a:	930d      	str	r3, [sp, #52]	@ 0x34
  5c:	f8cd 9040 	str.w	r9, [sp, #64]	@ 0x40
  60:	f88d 703c 	strb.w	r7, [sp, #60]	@ 0x3c
  64:	f88d 7048 	strb.w	r7, [sp, #72]	@ 0x48
  68:	9414      	str	r4, [sp, #80]	@ 0x50
  6a:	f10d 0e04 	add.w	lr, sp, #4
  6e:	4645      	mov	r5, r8
  70:	b1f5      	cbz	r5, b0 <NavigationEskfReplayRecovery_Predict+0xb0>
  72:	b377      	cbz	r7, d2 <NavigationEskfReplayRecovery_Predict+0xd2>
  74:	f10d 0c04 	add.w	ip, sp, #4
  78:	e007      	b.n	8a <NavigationEskfReplayRecovery_Predict+0x8a>
  7a:	f8de 4004 	ldr.w	r4, [lr, #4]
  7e:	45a2      	cmp	sl, r4
  80:	d30f      	bcc.n	a2 <NavigationEskfReplayRecovery_Predict+0xa2>
  82:	f10c 0c0c 	add.w	ip, ip, #12
  86:	45f4      	cmp	ip, lr
  88:	d016      	beq.n	b8 <NavigationEskfReplayRecovery_Predict+0xb8>
  8a:	f8dc 4000 	ldr.w	r4, [ip]
  8e:	42ac      	cmp	r4, r5
  90:	eba4 0a05 	sub.w	sl, r4, r5
  94:	eba5 0604 	sub.w	r6, r5, r4
  98:	d2ef      	bcs.n	7a <NavigationEskfReplayRecovery_Predict+0x7a>
  9a:	f8dc 4004 	ldr.w	r4, [ip, #4]
  9e:	42a6      	cmp	r6, r4
  a0:	d2ef      	bcs.n	82 <NavigationEskfReplayRecovery_Predict+0x82>
  a2:	f89e 4008 	ldrb.w	r4, [lr, #8]
  a6:	b91c      	cbnz	r4, b0 <NavigationEskfReplayRecovery_Predict+0xb0>
  a8:	f89c 4008 	ldrb.w	r4, [ip, #8]
  ac:	2c00      	cmp	r4, #0
  ae:	d0e8      	beq.n	82 <NavigationEskfReplayRecovery_Predict+0x82>
  b0:	2001      	movs	r0, #1
  b2:	b016      	add	sp, #88	@ 0x58
  b4:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
  b8:	3701      	adds	r7, #1
  ba:	2f07      	cmp	r7, #7
  bc:	d002      	beq.n	c4 <NavigationEskfReplayRecovery_Predict+0xc4>
  be:	f85e 5f0c 	ldr.w	r5, [lr, #12]!
  c2:	e7d5      	b.n	70 <NavigationEskfReplayRecovery_Predict+0x70>
  c4:	e9cd 981e 	strd	r9, r8, [sp, #120]	@ 0x78
  c8:	b016      	add	sp, #88	@ 0x58
  ca:	e8bd 47f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
  ce:	f7ff bffe 	b.w	0 <NavigationEskfReplayRecovery_Predict>
			ce: R_ARM_THM_JUMP24	Replay_Predict
  d2:	2701      	movs	r7, #1
  d4:	e7f3      	b.n	be <NavigationEskfReplayRecovery_Predict+0xbe>
  d6:	bf00      	nop

Disassembly of section .text.NavigationEskfReplayRecovery_Insert:

00000000 <NavigationEskfReplayRecovery_Insert>:
   0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
   4:	b0a1      	sub	sp, #132	@ 0x84
   6:	e9dd a92a 	ldrd	sl, r9, [sp, #168]	@ 0xa8
   a:	e9dd 782c 	ldrd	r7, r8, [sp, #176]	@ 0xb0
   e:	9d2e      	ldr	r5, [sp, #184]	@ 0xb8
  10:	2800      	cmp	r0, #0
  12:	d05e      	beq.n	d2 <NavigationEskfReplayRecovery_Insert+0xd2>
  14:	2401      	movs	r4, #1
  16:	f88d 4010 	strb.w	r4, [sp, #16]
  1a:	f88d 401c 	strb.w	r4, [sp, #28]
  1e:	f88d 4028 	strb.w	r4, [sp, #40]	@ 0x28
  22:	f88d 4034 	strb.w	r4, [sp, #52]	@ 0x34
  26:	f88d 4058 	strb.w	r4, [sp, #88]	@ 0x58
  2a:	941b      	str	r4, [sp, #108]	@ 0x6c
  2c:	f88d 4070 	strb.w	r4, [sp, #112]	@ 0x70
  30:	f88d 407c 	strb.w	r4, [sp, #124]	@ 0x7c
  34:	f8d0 47c0 	ldr.w	r4, [r0, #1984]	@ 0x7c0
  38:	941d      	str	r4, [sp, #116]	@ 0x74
  3a:	f641 5408 	movw	r4, #7432	@ 0x1d08
  3e:	9403      	str	r4, [sp, #12]
  40:	f244 2460 	movw	r4, #16992	@ 0x4260
  44:	9406      	str	r4, [sp, #24]
  46:	f44f 7478 	mov.w	r4, #992	@ 0x3e0
  4a:	9409      	str	r4, [sp, #36]	@ 0x24
  4c:	f640 4444 	movw	r4, #3140	@ 0xc44
  50:	940c      	str	r4, [sp, #48]	@ 0x30
  52:	242c      	movs	r4, #44	@ 0x2c
  54:	940f      	str	r4, [sp, #60]	@ 0x3c
  56:	2448      	movs	r4, #72	@ 0x48
  58:	9412      	str	r4, [sp, #72]	@ 0x48
  5a:	2420      	movs	r4, #32
  5c:	9415      	str	r4, [sp, #84]	@ 0x54
  5e:	241c      	movs	r4, #28
  60:	2600      	movs	r6, #0
  62:	9418      	str	r4, [sp, #96]	@ 0x60
  64:	f44f 5440 	mov.w	r4, #12288	@ 0x3000
  68:	9005      	str	r0, [sp, #20]
  6a:	941e      	str	r4, [sp, #120]	@ 0x78
  6c:	9001      	str	r0, [sp, #4]
  6e:	9702      	str	r7, [sp, #8]
  70:	9108      	str	r1, [sp, #32]
  72:	920b      	str	r2, [sp, #44]	@ 0x2c
  74:	930e      	str	r3, [sp, #56]	@ 0x38
  76:	f8cd a044 	str.w	sl, [sp, #68]	@ 0x44
  7a:	f8cd 9050 	str.w	r9, [sp, #80]	@ 0x50
  7e:	f8cd 805c 	str.w	r8, [sp, #92]	@ 0x5c
  82:	951a      	str	r5, [sp, #104]	@ 0x68
  84:	f88d 6040 	strb.w	r6, [sp, #64]	@ 0x40
  88:	f88d 604c 	strb.w	r6, [sp, #76]	@ 0x4c
  8c:	f88d 6064 	strb.w	r6, [sp, #100]	@ 0x64
  90:	f10d 0e08 	add.w	lr, sp, #8
  94:	463c      	mov	r4, r7
  96:	4608      	mov	r0, r1
  98:	b1dc      	cbz	r4, d2 <NavigationEskfReplayRecovery_Insert+0xd2>
  9a:	b336      	cbz	r6, ea <NavigationEskfReplayRecovery_Insert+0xea>
  9c:	a902      	add	r1, sp, #8
  9e:	9600      	str	r6, [sp, #0]
  a0:	469b      	mov	fp, r3
  a2:	e006      	b.n	b2 <NavigationEskfReplayRecovery_Insert+0xb2>
  a4:	f8de 6004 	ldr.w	r6, [lr, #4]
  a8:	45b4      	cmp	ip, r6
  aa:	d30c      	bcc.n	c6 <NavigationEskfReplayRecovery_Insert+0xc6>
  ac:	310c      	adds	r1, #12
  ae:	4571      	cmp	r1, lr
  b0:	d013      	beq.n	da <NavigationEskfReplayRecovery_Insert+0xda>
  b2:	680b      	ldr	r3, [r1, #0]
  b4:	42a3      	cmp	r3, r4
  b6:	eba3 0c04 	sub.w	ip, r3, r4
  ba:	eba4 0603 	sub.w	r6, r4, r3
  be:	d2f1      	bcs.n	a4 <NavigationEskfReplayRecovery_Insert+0xa4>
  c0:	684b      	ldr	r3, [r1, #4]
  c2:	429e      	cmp	r6, r3
  c4:	d2f2      	bcs.n	ac <NavigationEskfReplayRecovery_Insert+0xac>
  c6:	f89e 6008 	ldrb.w	r6, [lr, #8]
  ca:	b916      	cbnz	r6, d2 <NavigationEskfReplayRecovery_Insert+0xd2>
  cc:	7a0e      	ldrb	r6, [r1, #8]
  ce:	2e00      	cmp	r6, #0
  d0:	d0ec      	beq.n	ac <NavigationEskfReplayRecovery_Insert+0xac>
  d2:	2001      	movs	r0, #1
  d4:	b021      	add	sp, #132	@ 0x84
  d6:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
  da:	9e00      	ldr	r6, [sp, #0]
  dc:	3601      	adds	r6, #1
  de:	2e0a      	cmp	r6, #10
  e0:	465b      	mov	r3, fp
  e2:	d004      	beq.n	ee <NavigationEskfReplayRecovery_Insert+0xee>
  e4:	f85e 4f0c 	ldr.w	r4, [lr, #12]!
  e8:	e7d6      	b.n	98 <NavigationEskfReplayRecovery_Insert+0x98>
  ea:	2601      	movs	r6, #1
  ec:	e7fa      	b.n	e4 <NavigationEskfReplayRecovery_Insert+0xe4>
  ee:	4601      	mov	r1, r0
  f0:	9801      	ldr	r0, [sp, #4]
  f2:	952e      	str	r5, [sp, #184]	@ 0xb8
  f4:	2400      	movs	r4, #0
  f6:	e9cd 782c 	strd	r7, r8, [sp, #176]	@ 0xb0
  fa:	e9cd a92a 	strd	sl, r9, [sp, #168]	@ 0xa8
  fe:	702c      	strb	r4, [r5, #0]
 100:	b021      	add	sp, #132	@ 0x84
 102:	e8bd 4ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
 106:	f7ff bffe 	b.w	0 <NavigationEskfReplayRecovery_Insert>
			106: R_ARM_THM_JUMP24	Replay_Insert
 10a:	bf00      	nop
