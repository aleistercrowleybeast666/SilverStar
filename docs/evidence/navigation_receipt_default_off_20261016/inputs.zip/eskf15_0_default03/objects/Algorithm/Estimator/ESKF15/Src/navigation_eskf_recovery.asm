
D:\python_software\SilverStar\.work\dev013_navclosure02\eskf15_0_default03\build\FCCG\SilverStar_F407\Release\auto\Algorithm\Estimator\ESKF15\Src\navigation_eskf_recovery.o:     file format elf32-littlearm


Disassembly of section .text.Recovery_ReceiveValid:

00000000 <Recovery_ReceiveValid>:
   0:	4603      	mov	r3, r0
   2:	2800      	cmp	r0, #0
   4:	d052      	beq.n	ac <Recovery_ReceiveValid+0xac>
   6:	f890 010a 	ldrb.w	r0, [r0, #266]	@ 0x10a
   a:	2801      	cmp	r0, #1
   c:	d14e      	bne.n	ac <Recovery_ReceiveValid+0xac>
   e:	f893 2109 	ldrb.w	r2, [r3, #265]	@ 0x109
  12:	2a01      	cmp	r2, #1
  14:	d84a      	bhi.n	ac <Recovery_ReceiveValid+0xac>
  16:	f893 210b 	ldrb.w	r2, [r3, #267]	@ 0x10b
  1a:	2a01      	cmp	r2, #1
  1c:	d846      	bhi.n	ac <Recovery_ReceiveValid+0xac>
  1e:	f893 2108 	ldrb.w	r2, [r3, #264]	@ 0x108
  22:	2a03      	cmp	r2, #3
  24:	d842      	bhi.n	ac <Recovery_ReceiveValid+0xac>
  26:	f103 01e0 	add.w	r1, r3, #224	@ 0xe0
  2a:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
  2e:	c966      	ldmia	r1, {r1, r2, r5, r6}
  30:	428d      	cmp	r5, r1
  32:	eb76 0202 	sbcs.w	r2, r6, r2
  36:	b083      	sub	sp, #12
  38:	d33a      	bcc.n	b0 <Recovery_ReceiveValid+0xb0>
  3a:	f103 0ba0 	add.w	fp, r3, #160	@ 0xa0
  3e:	461a      	mov	r2, r3
  40:	9001      	str	r0, [sp, #4]
  42:	46a9      	mov	r9, r5
  44:	46b2      	mov	sl, r6
  46:	7b1c      	ldrb	r4, [r3, #12]
  48:	2c01      	cmp	r4, #1
  4a:	d831      	bhi.n	b0 <Recovery_ReceiveValid+0xb0>
  4c:	f892 7061 	ldrb.w	r7, [r2, #97]	@ 0x61
  50:	2f01      	cmp	r7, #1
  52:	d82d      	bhi.n	b0 <Recovery_ReceiveValid+0xb0>
  54:	6dd1      	ldr	r1, [r2, #92]	@ 0x5c
  56:	b359      	cbz	r1, b0 <Recovery_ReceiveValid+0xb0>
  58:	e9d2 e510 	ldrd	lr, r5, [r2, #64]	@ 0x40
  5c:	45f1      	cmp	r9, lr
  5e:	eb7a 0105 	sbcs.w	r1, sl, r5
  62:	d325      	bcc.n	b0 <Recovery_ReceiveValid+0xb0>
  64:	e9d2 0114 	ldrd	r0, r1, [r2, #80]	@ 0x50
  68:	4581      	cmp	r9, r0
  6a:	eb7a 0601 	sbcs.w	r6, sl, r1
  6e:	d31f      	bcc.n	b0 <Recovery_ReceiveValid+0xb0>
  70:	e9d2 8612 	ldrd	r8, r6, [r2, #72]	@ 0x48
  74:	4540      	cmp	r0, r8
  76:	eb71 0c06 	sbcs.w	ip, r1, r6
  7a:	d319      	bcc.n	b0 <Recovery_ReceiveValid+0xb0>
  7c:	b127      	cbz	r7, 88 <Recovery_ReceiveValid+0x88>
  7e:	6d97      	ldr	r7, [r2, #88]	@ 0x58
  80:	b1f7      	cbz	r7, c0 <Recovery_ReceiveValid+0xc0>
  82:	ea5e 0505 	orrs.w	r5, lr, r5
  86:	d013      	beq.n	b0 <Recovery_ReceiveValid+0xb0>
  88:	f892 5060 	ldrb.w	r5, [r2, #96]	@ 0x60
  8c:	b1a5      	cbz	r5, b8 <Recovery_ReceiveValid+0xb8>
  8e:	ea58 0606 	orrs.w	r6, r8, r6
  92:	d00d      	beq.n	b0 <Recovery_ReceiveValid+0xb0>
  94:	b11c      	cbz	r4, 9e <Recovery_ReceiveValid+0x9e>
  96:	e9d3 1000 	ldrd	r1, r0, [r3]
  9a:	4301      	orrs	r1, r0
  9c:	d008      	beq.n	b0 <Recovery_ReceiveValid+0xb0>
  9e:	3228      	adds	r2, #40	@ 0x28
  a0:	455a      	cmp	r2, fp
  a2:	f103 0310 	add.w	r3, r3, #16
  a6:	d1ce      	bne.n	46 <Recovery_ReceiveValid+0x46>
  a8:	9801      	ldr	r0, [sp, #4]
  aa:	e002      	b.n	b2 <Recovery_ReceiveValid+0xb2>
  ac:	2000      	movs	r0, #0
  ae:	4770      	bx	lr
  b0:	2000      	movs	r0, #0
  b2:	b003      	add	sp, #12
  b4:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
  b8:	4301      	orrs	r1, r0
  ba:	d0eb      	beq.n	94 <Recovery_ReceiveValid+0x94>
  bc:	4628      	mov	r0, r5
  be:	e7f8      	b.n	b2 <Recovery_ReceiveValid+0xb2>
  c0:	4638      	mov	r0, r7
  c2:	e7f6      	b.n	b2 <Recovery_ReceiveValid+0xb2>

Disassembly of section .text.Recovery_PolicyValid:

00000000 <Recovery_PolicyValid>:
   0:	4603      	mov	r3, r0
   2:	f890 006a 	ldrb.w	r0, [r0, #106]	@ 0x6a
   6:	2801      	cmp	r0, #1
   8:	d108      	bne.n	1c <Recovery_PolicyValid+0x1c>
   a:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
   e:	6a0a      	ldr	r2, [r1, #32]
  10:	6d1c      	ldr	r4, [r3, #80]	@ 0x50
  12:	4294      	cmp	r4, r2
  14:	d004      	beq.n	20 <Recovery_PolicyValid+0x20>
  16:	2000      	movs	r0, #0
  18:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
  1c:	2000      	movs	r0, #0
  1e:	4770      	bx	lr
  20:	f893 2067 	ldrb.w	r2, [r3, #103]	@ 0x67
  24:	2a0f      	cmp	r2, #15
  26:	d8f6      	bhi.n	16 <Recovery_PolicyValid+0x16>
  28:	f893 c069 	ldrb.w	ip, [r3, #105]	@ 0x69
  2c:	f1bc 0f01 	cmp.w	ip, #1
  30:	d8f1      	bhi.n	16 <Recovery_PolicyValid+0x16>
  32:	f893 4066 	ldrb.w	r4, [r3, #102]	@ 0x66
  36:	2c01      	cmp	r4, #1
  38:	d8ed      	bhi.n	16 <Recovery_PolicyValid+0x16>
  3a:	f893 6068 	ldrb.w	r6, [r3, #104]	@ 0x68
  3e:	f891 5027 	ldrb.w	r5, [r1, #39]	@ 0x27
  42:	42ae      	cmp	r6, r5
  44:	d8e7      	bhi.n	16 <Recovery_PolicyValid+0x16>
  46:	f893 9065 	ldrb.w	r9, [r3, #101]	@ 0x65
  4a:	f1b9 0f03 	cmp.w	r9, #3
  4e:	d8e2      	bhi.n	16 <Recovery_PolicyValid+0x16>
  50:	f893 5064 	ldrb.w	r5, [r3, #100]	@ 0x64
  54:	2d03      	cmp	r5, #3
  56:	d8de      	bhi.n	16 <Recovery_PolicyValid+0x16>
  58:	f891 a025 	ldrb.w	sl, [r1, #37]	@ 0x25
  5c:	469c      	mov	ip, r3
  5e:	f04f 0e00 	mov.w	lr, #0
  62:	f89c 500c 	ldrb.w	r5, [ip, #12]
  66:	4555      	cmp	r5, sl
  68:	fa22 f70e 	lsr.w	r7, r2, lr
  6c:	f10e 0e01 	add.w	lr, lr, #1
  70:	d8d1      	bhi.n	16 <Recovery_PolicyValid+0x16>
  72:	f89c 600d 	ldrb.w	r6, [ip, #13]
  76:	f891 8026 	ldrb.w	r8, [r1, #38]	@ 0x26
  7a:	45b0      	cmp	r8, r6
  7c:	d3cb      	bcc.n	16 <Recovery_PolicyValid+0x16>
  7e:	b10d      	cbz	r5, 84 <Recovery_PolicyValid+0x84>
  80:	2e00      	cmp	r6, #0
  82:	d1c8      	bne.n	16 <Recovery_PolicyValid+0x16>
  84:	07fd      	lsls	r5, r7, #31
  86:	d503      	bpl.n	90 <Recovery_PolicyValid+0x90>
  88:	f8dc 5000 	ldr.w	r5, [ip]
  8c:	2d00      	cmp	r5, #0
  8e:	d0c2      	beq.n	16 <Recovery_PolicyValid+0x16>
  90:	f1be 0f04 	cmp.w	lr, #4
  94:	f10c 0c10 	add.w	ip, ip, #16
  98:	d1e3      	bne.n	62 <Recovery_PolicyValid+0x62>
  9a:	2c00      	cmp	r4, #0
  9c:	d0bc      	beq.n	18 <Recovery_PolicyValid+0x18>
  9e:	6d58      	ldr	r0, [r3, #84]	@ 0x54
  a0:	2800      	cmp	r0, #0
  a2:	d0b9      	beq.n	18 <Recovery_PolicyValid+0x18>
  a4:	fa22 f209 	lsr.w	r2, r2, r9
  a8:	f012 0201 	ands.w	r2, r2, #1
  ac:	d0b3      	beq.n	16 <Recovery_PolicyValid+0x16>
  ae:	eb03 1209 	add.w	r2, r3, r9, lsl #4
  b2:	ea4f 1909 	mov.w	r9, r9, lsl #4
  b6:	6891      	ldr	r1, [r2, #8]
  b8:	4288      	cmp	r0, r1
  ba:	d8ac      	bhi.n	16 <Recovery_PolicyValid+0x16>
  bc:	6dd8      	ldr	r0, [r3, #92]	@ 0x5c
  be:	f853 1009 	ldr.w	r1, [r3, r9]
  c2:	4288      	cmp	r0, r1
  c4:	d1a7      	bne.n	16 <Recovery_PolicyValid+0x16>
  c6:	6d98      	ldr	r0, [r3, #88]	@ 0x58
  c8:	6853      	ldr	r3, [r2, #4]
  ca:	1ac3      	subs	r3, r0, r3
  cc:	4258      	negs	r0, r3
  ce:	4158      	adcs	r0, r3
  d0:	e7a2      	b.n	18 <Recovery_PolicyValid+0x18>
  d2:	bf00      	nop

Disassembly of section .text.Recovery_EvidenceWrite:

00000000 <Recovery_EvidenceWrite>:
   0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
   4:	b083      	sub	sp, #12
   6:	4604      	mov	r4, r0
   8:	4691      	mov	r9, r2
   a:	980c      	ldr	r0, [sp, #48]	@ 0x30
   c:	2270      	movs	r2, #112	@ 0x70
   e:	4688      	mov	r8, r1
  10:	2100      	movs	r1, #0
  12:	469b      	mov	fp, r3
  14:	f7ff fffe 	bl	0 <memset>
			14: R_ARM_THM_CALL	memset
  18:	9b0c      	ldr	r3, [sp, #48]	@ 0x30
  1a:	f8d4 c058 	ldr.w	ip, [r4, #88]	@ 0x58
  1e:	f8d4 e104 	ldr.w	lr, [r4, #260]	@ 0x104
  22:	f8d4 1080 	ldr.w	r1, [r4, #128]	@ 0x80
  26:	f8d4 70a8 	ldr.w	r7, [r4, #168]	@ 0xa8
  2a:	f8d4 60d0 	ldr.w	r6, [r4, #208]	@ 0xd0
  2e:	f894 510b 	ldrb.w	r5, [r4, #267]	@ 0x10b
  32:	f8cd c004 	str.w	ip, [sp, #4]
  36:	4620      	mov	r0, r4
  38:	f103 0470 	add.w	r4, r3, #112	@ 0x70
  3c:	4622      	mov	r2, r4
  3e:	f8cd e000 	str.w	lr, [sp]
  42:	460c      	mov	r4, r1
  44:	4694      	mov	ip, r2
  46:	9a00      	ldr	r2, [sp, #0]
  48:	601a      	str	r2, [r3, #0]
  4a:	6dc2      	ldr	r2, [r0, #92]	@ 0x5c
  4c:	605a      	str	r2, [r3, #4]
  4e:	9a01      	ldr	r2, [sp, #4]
  50:	e9c3 7604 	strd	r7, r6, [r3, #16]
  54:	e9c3 2402 	strd	r2, r4, [r3, #8]
  58:	bb3d      	cbnz	r5, aa <Recovery_EvidenceWrite+0xaa>
  5a:	6d82      	ldr	r2, [r0, #88]	@ 0x58
  5c:	b32a      	cbz	r2, aa <Recovery_EvidenceWrite+0xaa>
  5e:	f890 a060 	ldrb.w	sl, [r0, #96]	@ 0x60
  62:	f898 e024 	ldrb.w	lr, [r8, #36]	@ 0x24
  66:	45f2      	cmp	sl, lr
  68:	d31f      	bcc.n	aa <Recovery_EvidenceWrite+0xaa>
  6a:	e9d0 ea12 	ldrd	lr, sl, [r0, #72]	@ 0x48
  6e:	45f1      	cmp	r9, lr
  70:	eb7b 020a 	sbcs.w	r2, fp, sl
  74:	d325      	bcc.n	c2 <Recovery_EvidenceWrite+0xc2>
  76:	f8d8 1008 	ldr.w	r1, [r8, #8]
  7a:	ebb9 020e 	subs.w	r2, r9, lr
  7e:	eb6b 0e0a 	sbc.w	lr, fp, sl
  82:	428a      	cmp	r2, r1
  84:	f8d8 200c 	ldr.w	r2, [r8, #12]
  88:	eb7e 0e02 	sbcs.w	lr, lr, r2
  8c:	bf2c      	ite	cs
  8e:	f04f 0e01 	movcs.w	lr, #1
  92:	f04f 0e00 	movcc.w	lr, #0
  96:	f883 e018 	strb.w	lr, [r3, #24]
  9a:	331c      	adds	r3, #28
  9c:	4563      	cmp	r3, ip
  9e:	f100 0028 	add.w	r0, r0, #40	@ 0x28
  a2:	d1d0      	bne.n	46 <Recovery_EvidenceWrite+0x46>
  a4:	b003      	add	sp, #12
  a6:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
  aa:	f04f 0e00 	mov.w	lr, #0
  ae:	f883 e018 	strb.w	lr, [r3, #24]
  b2:	331c      	adds	r3, #28
  b4:	4563      	cmp	r3, ip
  b6:	f100 0028 	add.w	r0, r0, #40	@ 0x28
  ba:	d1c4      	bne.n	46 <Recovery_EvidenceWrite+0x46>
  bc:	b003      	add	sp, #12
  be:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
  c2:	46ae      	mov	lr, r5
  c4:	e7f3      	b.n	ae <Recovery_EvidenceWrite+0xae>
  c6:	bf00      	nop

Disassembly of section .text.NavigationEskfRecovery_ConfigValidate:

00000000 <NavigationEskfRecovery_ConfigValidate>:
   0:	2800      	cmp	r0, #0
   2:	d05c      	beq.n	be <NavigationEskfRecovery_ConfigValidate+0xbe>
   4:	6a03      	ldr	r3, [r0, #32]
   6:	2b00      	cmp	r3, #0
   8:	d059      	beq.n	be <NavigationEskfRecovery_ConfigValidate+0xbe>
   a:	e9d0 2304 	ldrd	r2, r3, [r0, #16]
   e:	ea52 0103 	orrs.w	r1, r2, r3
  12:	d054      	beq.n	be <NavigationEskfRecovery_ConfigValidate+0xbe>
  14:	b410      	push	{r4}
  16:	e9d0 4100 	ldrd	r4, r1, [r0]
  1a:	42a2      	cmp	r2, r4
  1c:	418b      	sbcs	r3, r1
  1e:	d24a      	bcs.n	b6 <NavigationEskfRecovery_ConfigValidate+0xb6>
  20:	e9d0 3202 	ldrd	r3, r2, [r0, #8]
  24:	4313      	orrs	r3, r2
  26:	d046      	beq.n	b6 <NavigationEskfRecovery_ConfigValidate+0xb6>
  28:	e9d0 3206 	ldrd	r3, r2, [r0, #24]
  2c:	4313      	orrs	r3, r2
  2e:	d042      	beq.n	b6 <NavigationEskfRecovery_ConfigValidate+0xb6>
  30:	f890 3024 	ldrb.w	r3, [r0, #36]	@ 0x24
  34:	2b01      	cmp	r3, #1
  36:	d93e      	bls.n	b6 <NavigationEskfRecovery_ConfigValidate+0xb6>
  38:	f890 3025 	ldrb.w	r3, [r0, #37]	@ 0x25
  3c:	b3db      	cbz	r3, b6 <NavigationEskfRecovery_ConfigValidate+0xb6>
  3e:	f890 3026 	ldrb.w	r3, [r0, #38]	@ 0x26
  42:	b3c3      	cbz	r3, b6 <NavigationEskfRecovery_ConfigValidate+0xb6>
  44:	f890 3027 	ldrb.w	r3, [r0, #39]	@ 0x27
  48:	b3ab      	cbz	r3, b6 <NavigationEskfRecovery_ConfigValidate+0xb6>
  4a:	ed9f 7a1e 	vldr	s14, [pc, #120]	@ c4 <NavigationEskfRecovery_ConfigValidate+0xc4>
  4e:	f100 0328 	add.w	r3, r0, #40	@ 0x28
  52:	f100 0264 	add.w	r2, r0, #100	@ 0x64
  56:	eeb7 6a00 	vmov.f32	s12, #112	@ 0x3f800000  1.0
  5a:	eef0 5a00 	vmov.f32	s11, #0	@ 0x40000000  2.0
  5e:	ecf3 7a01 	vldmia	r3!, {s15}
  62:	eef0 6ae7 	vabs.f32	s13, s15
  66:	eef4 6a47 	vcmp.f32	s13, s14
  6a:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  6e:	d822      	bhi.n	b6 <NavigationEskfRecovery_ConfigValidate+0xb6>
  70:	eef4 7ac6 	vcmpe.f32	s15, s12
  74:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  78:	d91d      	bls.n	b6 <NavigationEskfRecovery_ConfigValidate+0xb6>
  7a:	eef4 7ae5 	vcmpe.f32	s15, s11
  7e:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  82:	dc18      	bgt.n	b6 <NavigationEskfRecovery_ConfigValidate+0xb6>
  84:	edd0 6a0a 	vldr	s13, [r0, #40]	@ 0x28
  88:	eef4 7a66 	vcmp.f32	s15, s13
  8c:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  90:	d111      	bne.n	b6 <NavigationEskfRecovery_ConfigValidate+0xb6>
  92:	edd3 7a0e 	vldr	s15, [r3, #56]	@ 0x38
  96:	eef0 6ae7 	vabs.f32	s13, s15
  9a:	eef4 6a47 	vcmp.f32	s13, s14
  9e:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  a2:	d808      	bhi.n	b6 <NavigationEskfRecovery_ConfigValidate+0xb6>
  a4:	eef5 7ac0 	vcmpe.f32	s15, #0.0
  a8:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  ac:	d903      	bls.n	b6 <NavigationEskfRecovery_ConfigValidate+0xb6>
  ae:	4293      	cmp	r3, r2
  b0:	d1d5      	bne.n	5e <NavigationEskfRecovery_ConfigValidate+0x5e>
  b2:	2000      	movs	r0, #0
  b4:	e000      	b.n	b8 <NavigationEskfRecovery_ConfigValidate+0xb8>
  b6:	2005      	movs	r0, #5
  b8:	f85d 4b04 	ldr.w	r4, [sp], #4
  bc:	4770      	bx	lr
  be:	2005      	movs	r0, #5
  c0:	4770      	bx	lr
  c2:	bf00      	nop
  c4:	7f7fffff 	.word	0x7f7fffff

Disassembly of section .text.Recovery_UpdateCandidate:

00000000 <Recovery_UpdateCandidate>:
   0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
   4:	b09f      	sub	sp, #124	@ 0x7c
   6:	461c      	mov	r4, r3
   8:	930f      	str	r3, [sp, #60]	@ 0x3c
   a:	9b28      	ldr	r3, [sp, #160]	@ 0xa0
   c:	9312      	str	r3, [sp, #72]	@ 0x48
   e:	2300      	movs	r3, #0
  10:	f88d 3050 	strb.w	r3, [sp, #80]	@ 0x50
  14:	f88d 305c 	strb.w	r3, [sp, #92]	@ 0x5c
  18:	f88d 3068 	strb.w	r3, [sp, #104]	@ 0x68
  1c:	9b29      	ldr	r3, [sp, #164]	@ 0xa4
  1e:	9315      	str	r3, [sp, #84]	@ 0x54
  20:	f44f 7378 	mov.w	r3, #992	@ 0x3e0
  24:	9307      	str	r3, [sp, #28]
  26:	2370      	movs	r3, #112	@ 0x70
  28:	930a      	str	r3, [sp, #40]	@ 0x28
  2a:	f640 4344 	movw	r3, #3140	@ 0xc44
  2e:	930d      	str	r3, [sp, #52]	@ 0x34
  30:	f44f 638a 	mov.w	r3, #1104	@ 0x450
  34:	9310      	str	r3, [sp, #64]	@ 0x40
  36:	232c      	movs	r3, #44	@ 0x2c
  38:	9313      	str	r3, [sp, #76]	@ 0x4c
  3a:	23a0      	movs	r3, #160	@ 0xa0
  3c:	9316      	str	r3, [sp, #88]	@ 0x58
  3e:	2360      	movs	r3, #96	@ 0x60
  40:	f04f 0a01 	mov.w	sl, #1
  44:	f8dd 90a8 	ldr.w	r9, [sp, #168]	@ 0xa8
  48:	f8dd 80ac 	ldr.w	r8, [sp, #172]	@ 0xac
  4c:	9319      	str	r3, [sp, #100]	@ 0x64
  4e:	2324      	movs	r3, #36	@ 0x24
  50:	f89d b0b0 	ldrb.w	fp, [sp, #176]	@ 0xb0
  54:	9006      	str	r0, [sp, #24]
  56:	9109      	str	r1, [sp, #36]	@ 0x24
  58:	920c      	str	r2, [sp, #48]	@ 0x30
  5a:	f88d a020 	strb.w	sl, [sp, #32]
  5e:	f88d a02c 	strb.w	sl, [sp, #44]	@ 0x2c
  62:	f88d a038 	strb.w	sl, [sp, #56]	@ 0x38
  66:	f88d a044 	strb.w	sl, [sp, #68]	@ 0x44
  6a:	f88d a074 	strb.w	sl, [sp, #116]	@ 0x74
  6e:	f8cd 9060 	str.w	r9, [sp, #96]	@ 0x60
  72:	f8cd 806c 	str.w	r8, [sp, #108]	@ 0x6c
  76:	931c      	str	r3, [sp, #112]	@ 0x70
  78:	2800      	cmp	r0, #0
  7a:	d041      	beq.n	100 <Recovery_UpdateCandidate+0x100>
  7c:	4605      	mov	r5, r0
  7e:	460e      	mov	r6, r1
  80:	4617      	mov	r7, r2
  82:	a806      	add	r0, sp, #24
  84:	46ac      	mov	ip, r5
  86:	68c1      	ldr	r1, [r0, #12]
  88:	4605      	mov	r5, r0
  8a:	300c      	adds	r0, #12
  8c:	2900      	cmp	r1, #0
  8e:	d037      	beq.n	100 <Recovery_UpdateCandidate+0x100>
  90:	9b06      	ldr	r3, [sp, #24]
  92:	9402      	str	r4, [sp, #8]
  94:	428b      	cmp	r3, r1
  96:	aa06      	add	r2, sp, #24
  98:	eba3 0e01 	sub.w	lr, r3, r1
  9c:	eba1 0303 	sub.w	r3, r1, r3
  a0:	d315      	bcc.n	ce <Recovery_UpdateCandidate+0xce>
  a2:	6843      	ldr	r3, [r0, #4]
  a4:	459e      	cmp	lr, r3
  a6:	bf2c      	ite	cs
  a8:	2300      	movcs	r3, #0
  aa:	2301      	movcc	r3, #1
  ac:	b11b      	cbz	r3, b6 <Recovery_UpdateCandidate+0xb6>
  ae:	7a03      	ldrb	r3, [r0, #8]
  b0:	bb33      	cbnz	r3, 100 <Recovery_UpdateCandidate+0x100>
  b2:	7a13      	ldrb	r3, [r2, #8]
  b4:	bb23      	cbnz	r3, 100 <Recovery_UpdateCandidate+0x100>
  b6:	4295      	cmp	r5, r2
  b8:	f102 030c 	add.w	r3, r2, #12
  bc:	d00d      	beq.n	da <Recovery_UpdateCandidate+0xda>
  be:	461a      	mov	r2, r3
  c0:	6813      	ldr	r3, [r2, #0]
  c2:	428b      	cmp	r3, r1
  c4:	eba3 0e01 	sub.w	lr, r3, r1
  c8:	eba1 0303 	sub.w	r3, r1, r3
  cc:	d2e9      	bcs.n	a2 <Recovery_UpdateCandidate+0xa2>
  ce:	6854      	ldr	r4, [r2, #4]
  d0:	42a3      	cmp	r3, r4
  d2:	bf2c      	ite	cs
  d4:	2300      	movcs	r3, #0
  d6:	2301      	movcc	r3, #1
  d8:	e7e8      	b.n	ac <Recovery_UpdateCandidate+0xac>
  da:	f10a 0a01 	add.w	sl, sl, #1
  de:	f1ba 0f08 	cmp.w	sl, #8
  e2:	9c02      	ldr	r4, [sp, #8]
  e4:	d1cf      	bne.n	86 <Recovery_UpdateCandidate+0x86>
  e6:	2224      	movs	r2, #36	@ 0x24
  e8:	2100      	movs	r1, #0
  ea:	4640      	mov	r0, r8
  ec:	4665      	mov	r5, ip
  ee:	f7ff fffe 	bl	0 <memset>
			ee: R_ARM_THM_CALL	memset
  f2:	2303      	movs	r3, #3
  f4:	9829      	ldr	r0, [sp, #164]	@ 0xa4
  f6:	f888 301d 	strb.w	r3, [r8, #29]
  fa:	f7ff fffe 	bl	0 <Recovery_UpdateCandidate>
			fa: R_ARM_THM_CALL	NavigationEskfRecovery_ConfigValidate
  fe:	b128      	cbz	r0, 10c <Recovery_UpdateCandidate+0x10c>
 100:	f04f 0a05 	mov.w	sl, #5
 104:	4650      	mov	r0, sl
 106:	b01f      	add	sp, #124	@ 0x7c
 108:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 10c:	9828      	ldr	r0, [sp, #160]	@ 0xa0
 10e:	f7ff fffe 	bl	0 <NavigationEskf_ConfigValidate>
			10e: R_ARM_THM_CALL	NavigationEskf_ConfigValidate
 112:	4682      	mov	sl, r0
 114:	2800      	cmp	r0, #0
 116:	d1f3      	bne.n	100 <Recovery_UpdateCandidate+0x100>
 118:	9929      	ldr	r1, [sp, #164]	@ 0xa4
 11a:	4630      	mov	r0, r6
 11c:	f7ff fffe 	bl	0 <Recovery_UpdateCandidate>
			11c: R_ARM_THM_CALL	Recovery_PolicyValid
 120:	2800      	cmp	r0, #0
 122:	d0ed      	beq.n	100 <Recovery_UpdateCandidate+0x100>
 124:	f895 33d8 	ldrb.w	r3, [r5, #984]	@ 0x3d8
 128:	9302      	str	r3, [sp, #8]
 12a:	2b01      	cmp	r3, #1
 12c:	d1e8      	bne.n	100 <Recovery_UpdateCandidate+0x100>
 12e:	f8d9 3008 	ldr.w	r3, [r9, #8]
 132:	2b03      	cmp	r3, #3
 134:	d8e4      	bhi.n	100 <Recovery_UpdateCandidate+0x100>
 136:	f899 3018 	ldrb.w	r3, [r9, #24]
 13a:	2b03      	cmp	r3, #3
 13c:	d8e0      	bhi.n	100 <Recovery_UpdateCandidate+0x100>
 13e:	f899 305c 	ldrb.w	r3, [r9, #92]	@ 0x5c
 142:	2b01      	cmp	r3, #1
 144:	d8dc      	bhi.n	100 <Recovery_UpdateCandidate+0x100>
 146:	f8d9 2044 	ldr.w	r2, [r9, #68]	@ 0x44
 14a:	2a00      	cmp	r2, #0
 14c:	f000 8170 	beq.w	430 <Recovery_UpdateCandidate+0x430>
 150:	f8d9 3048 	ldr.w	r3, [r9, #72]	@ 0x48
 154:	2b00      	cmp	r3, #0
 156:	d0d3      	beq.n	100 <Recovery_UpdateCandidate+0x100>
 158:	6cb2      	ldr	r2, [r6, #72]	@ 0x48
 15a:	f8d9 3010 	ldr.w	r3, [r9, #16]
 15e:	4293      	cmp	r3, r2
 160:	d1ce      	bne.n	100 <Recovery_UpdateCandidate+0x100>
 162:	f8d9 1014 	ldr.w	r1, [r9, #20]
 166:	6cf2      	ldr	r2, [r6, #76]	@ 0x4c
 168:	4291      	cmp	r1, r2
 16a:	d1c9      	bne.n	100 <Recovery_UpdateCandidate+0x100>
 16c:	f8d5 23d4 	ldr.w	r2, [r5, #980]	@ 0x3d4
 170:	4293      	cmp	r3, r2
 172:	d1c5      	bne.n	100 <Recovery_UpdateCandidate+0x100>
 174:	e9d9 3200 	ldrd	r3, r2, [r9]
 178:	4313      	orrs	r3, r2
 17a:	d0c1      	beq.n	100 <Recovery_UpdateCandidate+0x100>
 17c:	f44f 7278 	mov.w	r2, #992	@ 0x3e0
 180:	4629      	mov	r1, r5
 182:	4620      	mov	r0, r4
 184:	f7ff fffe 	bl	0 <memcpy>
			184: R_ARM_THM_CALL	memcpy
 188:	f504 7378 	add.w	r3, r4, #992	@ 0x3e0
 18c:	4631      	mov	r1, r6
 18e:	2270      	movs	r2, #112	@ 0x70
 190:	4618      	mov	r0, r3
 192:	9303      	str	r3, [sp, #12]
 194:	f7ff fffe 	bl	0 <memcpy>
			194: R_ARM_THM_CALL	memcpy
 198:	f8d9 1044 	ldr.w	r1, [r9, #68]	@ 0x44
 19c:	2900      	cmp	r1, #0
 19e:	f000 8191 	beq.w	4c4 <Recovery_UpdateCandidate+0x4c4>
 1a2:	f899 3018 	ldrb.w	r3, [r9, #24]
 1a6:	eb04 1003 	add.w	r0, r4, r3, lsl #4
 1aa:	ea4f 1e03 	mov.w	lr, r3, lsl #4
 1ae:	f8d0 23e8 	ldr.w	r2, [r0, #1000]	@ 0x3e8
 1b2:	4291      	cmp	r1, r2
 1b4:	f240 8186 	bls.w	4c4 <Recovery_UpdateCandidate+0x4c4>
 1b8:	f8c0 13e8 	str.w	r1, [r0, #1000]	@ 0x3e8
 1bc:	f109 0048 	add.w	r0, r9, #72	@ 0x48
 1c0:	2200      	movs	r2, #0
 1c2:	9004      	str	r0, [sp, #16]
 1c4:	46a4      	mov	ip, r4
 1c6:	9305      	str	r3, [sp, #20]
 1c8:	9b04      	ldr	r3, [sp, #16]
 1ca:	f853 0f04 	ldr.w	r0, [r3, #4]!
 1ce:	9304      	str	r3, [sp, #16]
 1d0:	f8dc 33e0 	ldr.w	r3, [ip, #992]	@ 0x3e0
 1d4:	4298      	cmp	r0, r3
 1d6:	d913      	bls.n	200 <Recovery_UpdateCandidate+0x200>
 1d8:	f04f 0300 	mov.w	r3, #0
 1dc:	f8cc 03e0 	str.w	r0, [ip, #992]	@ 0x3e0
 1e0:	f8ac 33ec 	strh.w	r3, [ip, #1004]	@ 0x3ec
 1e4:	f894 3447 	ldrb.w	r3, [r4, #1095]	@ 0x447
 1e8:	2001      	movs	r0, #1
 1ea:	4090      	lsls	r0, r2
 1ec:	4303      	orrs	r3, r0
 1ee:	f884 3447 	strb.w	r3, [r4, #1095]	@ 0x447
 1f2:	f894 3445 	ldrb.w	r3, [r4, #1093]	@ 0x445
 1f6:	4293      	cmp	r3, r2
 1f8:	bf04      	itt	eq
 1fa:	2300      	moveq	r3, #0
 1fc:	f884 3446 	strbeq.w	r3, [r4, #1094]	@ 0x446
 200:	3201      	adds	r2, #1
 202:	2a04      	cmp	r2, #4
 204:	f10c 0c10 	add.w	ip, ip, #16
 208:	d1de      	bne.n	1c8 <Recovery_UpdateCandidate+0x1c8>
 20a:	f8d9 2048 	ldr.w	r2, [r9, #72]	@ 0x48
 20e:	9204      	str	r2, [sp, #16]
 210:	4610      	mov	r0, r2
 212:	eb04 020e 	add.w	r2, r4, lr
 216:	9b05      	ldr	r3, [sp, #20]
 218:	f8d2 23e4 	ldr.w	r2, [r2, #996]	@ 0x3e4
 21c:	4290      	cmp	r0, r2
 21e:	d011      	beq.n	244 <Recovery_UpdateCandidate+0x244>
 220:	4602      	mov	r2, r0
 222:	eb04 000e 	add.w	r0, r4, lr
 226:	f04f 0c00 	mov.w	ip, #0
 22a:	f8c0 23e4 	str.w	r2, [r0, #996]	@ 0x3e4
 22e:	9803      	ldr	r0, [sp, #12]
 230:	4672      	mov	r2, lr
 232:	4402      	add	r2, r0
 234:	f8a2 c00c 	strh.w	ip, [r2, #12]
 238:	f894 2445 	ldrb.w	r2, [r4, #1093]	@ 0x445
 23c:	429a      	cmp	r2, r3
 23e:	bf08      	it	eq
 240:	f884 c446 	strbeq.w	ip, [r4, #1094]	@ 0x446
 244:	f899 205c 	ldrb.w	r2, [r9, #92]	@ 0x5c
 248:	2a00      	cmp	r2, #0
 24a:	f000 8130 	beq.w	4ae <Recovery_UpdateCandidate+0x4ae>
 24e:	f103 0c12 	add.w	ip, r3, #18
 252:	eb04 020e 	add.w	r2, r4, lr
 256:	eb09 008c 	add.w	r0, r9, ip, lsl #2
 25a:	f8d2 23e0 	ldr.w	r2, [r2, #992]	@ 0x3e0
 25e:	6840      	ldr	r0, [r0, #4]
 260:	4290      	cmp	r0, r2
 262:	f040 8124 	bne.w	4ae <Recovery_UpdateCandidate+0x4ae>
 266:	f894 2447 	ldrb.w	r2, [r4, #1095]	@ 0x447
 26a:	40da      	lsrs	r2, r3
 26c:	f012 0201 	ands.w	r2, r2, #1
 270:	f000 811d 	beq.w	4ae <Recovery_UpdateCandidate+0x4ae>
 274:	f899 0019 	ldrb.w	r0, [r9, #25]
 278:	f013 0ffd 	tst.w	r3, #253	@ 0xfd
 27c:	bf08      	it	eq
 27e:	2202      	moveq	r2, #2
 280:	2800      	cmp	r0, #0
 282:	f000 80b4 	beq.w	3ee <Recovery_UpdateCandidate+0x3ee>
 286:	ed9f 7abf 	vldr	s14, [pc, #764]	@ 584 <Recovery_UpdateCandidate+0x584>
 28a:	f109 002c 	add.w	r0, r9, #44	@ 0x2c
 28e:	f109 0e38 	add.w	lr, r9, #56	@ 0x38
 292:	ecf0 7a01 	vldmia	r0!, {s15}
 296:	eef0 7ae7 	vabs.f32	s15, s15
 29a:	eef4 7a47 	vcmp.f32	s15, s14
 29e:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 2a2:	f200 80a4 	bhi.w	3ee <Recovery_UpdateCandidate+0x3ee>
 2a6:	edd0 7a02 	vldr	s15, [r0, #8]
 2aa:	eef0 7ae7 	vabs.f32	s15, s15
 2ae:	eef4 7a47 	vcmp.f32	s15, s14
 2b2:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 2b6:	f200 809a 	bhi.w	3ee <Recovery_UpdateCandidate+0x3ee>
 2ba:	4570      	cmp	r0, lr
 2bc:	d1e9      	bne.n	292 <Recovery_UpdateCandidate+0x292>
 2be:	f109 001c 	add.w	r0, r9, #28
 2c2:	ed9f 7ab0 	vldr	s14, [pc, #704]	@ 584 <Recovery_UpdateCandidate+0x584>
 2c6:	eb00 0282 	add.w	r2, r0, r2, lsl #2
 2ca:	ecf0 7a01 	vldmia	r0!, {s15}
 2ce:	eef0 7ae7 	vabs.f32	s15, s15
 2d2:	eef4 7a47 	vcmp.f32	s15, s14
 2d6:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 2da:	f200 8088 	bhi.w	3ee <Recovery_UpdateCandidate+0x3ee>
 2de:	edd0 7a01 	vldr	s15, [r0, #4]
 2e2:	eef0 6ae7 	vabs.f32	s13, s15
 2e6:	eef4 6a47 	vcmp.f32	s13, s14
 2ea:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 2ee:	d87e      	bhi.n	3ee <Recovery_UpdateCandidate+0x3ee>
 2f0:	eef5 7ac0 	vcmpe.f32	s15, #0.0
 2f4:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 2f8:	d979      	bls.n	3ee <Recovery_UpdateCandidate+0x3ee>
 2fa:	4290      	cmp	r0, r2
 2fc:	d1e5      	bne.n	2ca <Recovery_UpdateCandidate+0x2ca>
 2fe:	f894 2446 	ldrb.w	r2, [r4, #1094]	@ 0x446
 302:	2a00      	cmp	r2, #0
 304:	d073      	beq.n	3ee <Recovery_UpdateCandidate+0x3ee>
 306:	f894 2449 	ldrb.w	r2, [r4, #1097]	@ 0x449
 30a:	2a00      	cmp	r2, #0
 30c:	d16f      	bne.n	3ee <Recovery_UpdateCandidate+0x3ee>
 30e:	f894 2445 	ldrb.w	r2, [r4, #1093]	@ 0x445
 312:	429a      	cmp	r2, r3
 314:	d16b      	bne.n	3ee <Recovery_UpdateCandidate+0x3ee>
 316:	f894 2444 	ldrb.w	r2, [r4, #1092]	@ 0x444
 31a:	f8d9 3008 	ldr.w	r3, [r9, #8]
 31e:	429a      	cmp	r2, r3
 320:	d165      	bne.n	3ee <Recovery_UpdateCandidate+0x3ee>
 322:	f8d4 3438 	ldr.w	r3, [r4, #1080]	@ 0x438
 326:	9a04      	ldr	r2, [sp, #16]
 328:	429a      	cmp	r2, r3
 32a:	d160      	bne.n	3ee <Recovery_UpdateCandidate+0x3ee>
 32c:	eb09 038c 	add.w	r3, r9, ip, lsl #2
 330:	f8d4 243c 	ldr.w	r2, [r4, #1084]	@ 0x43c
 334:	685b      	ldr	r3, [r3, #4]
 336:	429a      	cmp	r2, r3
 338:	d159      	bne.n	3ee <Recovery_UpdateCandidate+0x3ee>
 33a:	f8d4 3434 	ldr.w	r3, [r4, #1076]	@ 0x434
 33e:	4299      	cmp	r1, r3
 340:	d955      	bls.n	3ee <Recovery_UpdateCandidate+0x3ee>
 342:	f8d4 3440 	ldr.w	r3, [r4, #1088]	@ 0x440
 346:	4299      	cmp	r1, r3
 348:	d951      	bls.n	3ee <Recovery_UpdateCandidate+0x3ee>
 34a:	f8d4 1420 	ldr.w	r1, [r4, #1056]	@ 0x420
 34e:	f8d4 0424 	ldr.w	r0, [r4, #1060]	@ 0x424
 352:	f504 6384 	add.w	r3, r4, #1056	@ 0x420
 356:	9304      	str	r3, [sp, #16]
 358:	ea51 0300 	orrs.w	r3, r1, r0
 35c:	d00e      	beq.n	37c <Recovery_UpdateCandidate+0x37c>
 35e:	e9d9 2300 	ldrd	r2, r3, [r9]
 362:	428a      	cmp	r2, r1
 364:	eb73 0c00 	sbcs.w	ip, r3, r0
 368:	d341      	bcc.n	3ee <Recovery_UpdateCandidate+0x3ee>
 36a:	1a52      	subs	r2, r2, r1
 36c:	9929      	ldr	r1, [sp, #164]	@ 0xa4
 36e:	eb63 0300 	sbc.w	r3, r3, r0
 372:	e9d1 0106 	ldrd	r0, r1, [r1, #24]
 376:	4282      	cmp	r2, r0
 378:	418b      	sbcs	r3, r1
 37a:	d338      	bcc.n	3ee <Recovery_UpdateCandidate+0x3ee>
 37c:	9b29      	ldr	r3, [sp, #164]	@ 0xa4
 37e:	f894 2448 	ldrb.w	r2, [r4, #1096]	@ 0x448
 382:	f893 3027 	ldrb.w	r3, [r3, #39]	@ 0x27
 386:	429a      	cmp	r2, r3
 388:	f080 80a5 	bcs.w	4d6 <Recovery_UpdateCandidate+0x4d6>
 38c:	9b29      	ldr	r3, [sp, #164]	@ 0xa4
 38e:	9a29      	ldr	r2, [sp, #164]	@ 0xa4
 390:	3364      	adds	r3, #100	@ 0x64
 392:	3228      	adds	r2, #40	@ 0x28
 394:	4639      	mov	r1, r7
 396:	4620      	mov	r0, r4
 398:	f7ff fffe 	bl	0 <NavigationEskf_CovarianceScale>
			398: R_ARM_THM_CALL	NavigationEskf_CovarianceScale
 39c:	2804      	cmp	r0, #4
 39e:	f000 80a7 	beq.w	4f0 <Recovery_UpdateCandidate+0x4f0>
 3a2:	2803      	cmp	r0, #3
 3a4:	f000 8091 	beq.w	4ca <Recovery_UpdateCandidate+0x4ca>
 3a8:	f894 3448 	ldrb.w	r3, [r4, #1096]	@ 0x448
 3ac:	3301      	adds	r3, #1
 3ae:	b2db      	uxtb	r3, r3
 3b0:	2100      	movs	r1, #0
 3b2:	f884 3448 	strb.w	r3, [r4, #1096]	@ 0x448
 3b6:	f884 1446 	strb.w	r1, [r4, #1094]	@ 0x446
 3ba:	2800      	cmp	r0, #0
 3bc:	f040 808b 	bne.w	4d6 <Recovery_UpdateCandidate+0x4d6>
 3c0:	ed99 7b00 	vldr	d7, [r9]
 3c4:	f504 6084 	add.w	r0, r4, #1056	@ 0x420
 3c8:	f8d9 2044 	ldr.w	r2, [r9, #68]	@ 0x44
 3cc:	ed80 7b00 	vstr	d7, [r0]
 3d0:	f8c4 2440 	str.w	r2, [r4, #1088]	@ 0x440
 3d4:	9a29      	ldr	r2, [sp, #164]	@ 0xa4
 3d6:	f892 2027 	ldrb.w	r2, [r2, #39]	@ 0x27
 3da:	429a      	cmp	r2, r3
 3dc:	f04f 0102 	mov.w	r1, #2
 3e0:	bf8c      	ite	hi
 3e2:	2300      	movhi	r3, #0
 3e4:	2301      	movls	r3, #1
 3e6:	f884 3449 	strb.w	r3, [r4, #1097]	@ 0x449
 3ea:	f888 1020 	strb.w	r1, [r8, #32]
 3ee:	f1bb 0f02 	cmp.w	fp, #2
 3f2:	9a28      	ldr	r2, [sp, #160]	@ 0xa0
 3f4:	f8cd 8000 	str.w	r8, [sp]
 3f8:	4639      	mov	r1, r7
 3fa:	f109 0318 	add.w	r3, r9, #24
 3fe:	4620      	mov	r0, r4
 400:	d051      	beq.n	4a6 <Recovery_UpdateCandidate+0x4a6>
 402:	f7ff fffe 	bl	0 <NavigationEskf_Update>
			402: R_ARM_THM_CALL	NavigationEskf_Update
 406:	4603      	mov	r3, r0
 408:	2b04      	cmp	r3, #4
 40a:	d071      	beq.n	4f0 <Recovery_UpdateCandidate+0x4f0>
 40c:	2b05      	cmp	r3, #5
 40e:	d06c      	beq.n	4ea <Recovery_UpdateCandidate+0x4ea>
 410:	2b03      	cmp	r3, #3
 412:	d067      	beq.n	4e4 <Recovery_UpdateCandidate+0x4e4>
 414:	9b02      	ldr	r3, [sp, #8]
 416:	b97b      	cbnz	r3, 438 <Recovery_UpdateCandidate+0x438>
 418:	4621      	mov	r1, r4
 41a:	4628      	mov	r0, r5
 41c:	f44f 7278 	mov.w	r2, #992	@ 0x3e0
 420:	f7ff fffe 	bl	0 <memcpy>
			420: R_ARM_THM_CALL	memcpy
 424:	9903      	ldr	r1, [sp, #12]
 426:	2270      	movs	r2, #112	@ 0x70
 428:	4630      	mov	r0, r6
 42a:	f7ff fffe 	bl	0 <memcpy>
			42a: R_ARM_THM_CALL	memcpy
 42e:	e669      	b.n	104 <Recovery_UpdateCandidate+0x104>
 430:	2b00      	cmp	r3, #0
 432:	f43f ae91 	beq.w	158 <Recovery_UpdateCandidate+0x158>
 436:	e663      	b.n	100 <Recovery_UpdateCandidate+0x100>
 438:	f898 201d 	ldrb.w	r2, [r8, #29]
 43c:	f899 3018 	ldrb.w	r3, [r9, #24]
 440:	2a01      	cmp	r2, #1
 442:	d965      	bls.n	510 <Recovery_UpdateCandidate+0x510>
 444:	2a02      	cmp	r2, #2
 446:	d15d      	bne.n	504 <Recovery_UpdateCandidate+0x504>
 448:	eb04 1103 	add.w	r1, r4, r3, lsl #4
 44c:	2200      	movs	r2, #0
 44e:	f881 23ed 	strb.w	r2, [r1, #1005]	@ 0x3ed
 452:	9a29      	ldr	r2, [sp, #164]	@ 0xa4
 454:	f892 0025 	ldrb.w	r0, [r2, #37]	@ 0x25
 458:	f891 23ec 	ldrb.w	r2, [r1, #1004]	@ 0x3ec
 45c:	4282      	cmp	r2, r0
 45e:	d34a      	bcc.n	4f6 <Recovery_UpdateCandidate+0x4f6>
 460:	f894 2449 	ldrb.w	r2, [r4, #1097]	@ 0x449
 464:	2a00      	cmp	r2, #0
 466:	d1d7      	bne.n	418 <Recovery_UpdateCandidate+0x418>
 468:	f894 2446 	ldrb.w	r2, [r4, #1094]	@ 0x446
 46c:	2a00      	cmp	r2, #0
 46e:	d1d3      	bne.n	418 <Recovery_UpdateCandidate+0x418>
 470:	2201      	movs	r2, #1
 472:	f884 3445 	strb.w	r3, [r4, #1093]	@ 0x445
 476:	f884 2446 	strb.w	r2, [r4, #1094]	@ 0x446
 47a:	f8d9 1008 	ldr.w	r1, [r9, #8]
 47e:	f884 1444 	strb.w	r1, [r4, #1092]	@ 0x444
 482:	eb09 0383 	add.w	r3, r9, r3, lsl #2
 486:	6cd9      	ldr	r1, [r3, #76]	@ 0x4c
 488:	e9d9 3011 	ldrd	r3, r0, [r9, #68]	@ 0x44
 48c:	f8c4 143c 	str.w	r1, [r4, #1084]	@ 0x43c
 490:	f8c4 0438 	str.w	r0, [r4, #1080]	@ 0x438
 494:	f8c4 3434 	str.w	r3, [r4, #1076]	@ 0x434
 498:	f898 3020 	ldrb.w	r3, [r8, #32]
 49c:	2b00      	cmp	r3, #0
 49e:	d1bb      	bne.n	418 <Recovery_UpdateCandidate+0x418>
 4a0:	f888 2020 	strb.w	r2, [r8, #32]
 4a4:	e7b8      	b.n	418 <Recovery_UpdateCandidate+0x418>
 4a6:	f7ff fffe 	bl	0 <NavigationEskf_UpdateRevision2>
			4a6: R_ARM_THM_CALL	NavigationEskf_UpdateRevision2
 4aa:	4603      	mov	r3, r0
 4ac:	e7ac      	b.n	408 <Recovery_UpdateCandidate+0x408>
 4ae:	9903      	ldr	r1, [sp, #12]
 4b0:	4672      	mov	r2, lr
 4b2:	440a      	add	r2, r1
 4b4:	2100      	movs	r1, #0
 4b6:	8191      	strh	r1, [r2, #12]
 4b8:	f894 2445 	ldrb.w	r2, [r4, #1093]	@ 0x445
 4bc:	429a      	cmp	r2, r3
 4be:	d101      	bne.n	4c4 <Recovery_UpdateCandidate+0x4c4>
 4c0:	f884 1446 	strb.w	r1, [r4, #1094]	@ 0x446
 4c4:	2300      	movs	r3, #0
 4c6:	9302      	str	r3, [sp, #8]
 4c8:	e791      	b.n	3ee <Recovery_UpdateCandidate+0x3ee>
 4ca:	f04f 0a05 	mov.w	sl, #5
 4ce:	2300      	movs	r3, #0
 4d0:	f888 3020 	strb.w	r3, [r8, #32]
 4d4:	e616      	b.n	104 <Recovery_UpdateCandidate+0x104>
 4d6:	2301      	movs	r3, #1
 4d8:	f884 3449 	strb.w	r3, [r4, #1097]	@ 0x449
 4dc:	2303      	movs	r3, #3
 4de:	f888 3020 	strb.w	r3, [r8, #32]
 4e2:	e784      	b.n	3ee <Recovery_UpdateCandidate+0x3ee>
 4e4:	f04f 0a08 	mov.w	sl, #8
 4e8:	e7f1      	b.n	4ce <Recovery_UpdateCandidate+0x4ce>
 4ea:	f04f 0a07 	mov.w	sl, #7
 4ee:	e7ee      	b.n	4ce <Recovery_UpdateCandidate+0x4ce>
 4f0:	f04f 0a06 	mov.w	sl, #6
 4f4:	e7eb      	b.n	4ce <Recovery_UpdateCandidate+0x4ce>
 4f6:	3201      	adds	r2, #1
 4f8:	b2d2      	uxtb	r2, r2
 4fa:	4290      	cmp	r0, r2
 4fc:	f881 23ec 	strb.w	r2, [r1, #1004]	@ 0x3ec
 500:	d88a      	bhi.n	418 <Recovery_UpdateCandidate+0x418>
 502:	e7ad      	b.n	460 <Recovery_UpdateCandidate+0x460>
 504:	9a03      	ldr	r2, [sp, #12]
 506:	eb02 1303 	add.w	r3, r2, r3, lsl #4
 50a:	2200      	movs	r2, #0
 50c:	819a      	strh	r2, [r3, #12]
 50e:	e783      	b.n	418 <Recovery_UpdateCandidate+0x418>
 510:	edd8 7a06 	vldr	s15, [r8, #24]
 514:	ed9f 7a1b 	vldr	s14, [pc, #108]	@ 584 <Recovery_UpdateCandidate+0x584>
 518:	eef0 6ae7 	vabs.f32	s13, s15
 51c:	eef4 6a47 	vcmp.f32	s13, s14
 520:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 524:	d8ee      	bhi.n	504 <Recovery_UpdateCandidate+0x504>
 526:	eef5 7ac0 	vcmpe.f32	s15, #0.0
 52a:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 52e:	dde9      	ble.n	504 <Recovery_UpdateCandidate+0x504>
 530:	eb04 1103 	add.w	r1, r4, r3, lsl #4
 534:	2200      	movs	r2, #0
 536:	f881 23ec 	strb.w	r2, [r1, #1004]	@ 0x3ec
 53a:	9a29      	ldr	r2, [sp, #164]	@ 0xa4
 53c:	f892 0026 	ldrb.w	r0, [r2, #38]	@ 0x26
 540:	f891 23ed 	ldrb.w	r2, [r1, #1005]	@ 0x3ed
 544:	4282      	cmp	r2, r0
 546:	d311      	bcc.n	56c <Recovery_UpdateCandidate+0x56c>
 548:	f894 2447 	ldrb.w	r2, [r4, #1095]	@ 0x447
 54c:	2101      	movs	r1, #1
 54e:	4099      	lsls	r1, r3
 550:	ea22 0201 	bic.w	r2, r2, r1
 554:	f894 1445 	ldrb.w	r1, [r4, #1093]	@ 0x445
 558:	f884 2447 	strb.w	r2, [r4, #1095]	@ 0x447
 55c:	4299      	cmp	r1, r3
 55e:	d00d      	beq.n	57c <Recovery_UpdateCandidate+0x57c>
 560:	2a00      	cmp	r2, #0
 562:	f47f af59 	bne.w	418 <Recovery_UpdateCandidate+0x418>
 566:	f8a4 2448 	strh.w	r2, [r4, #1096]	@ 0x448
 56a:	e755      	b.n	418 <Recovery_UpdateCandidate+0x418>
 56c:	3201      	adds	r2, #1
 56e:	b2d2      	uxtb	r2, r2
 570:	4290      	cmp	r0, r2
 572:	f881 23ed 	strb.w	r2, [r1, #1005]	@ 0x3ed
 576:	f63f af4f 	bhi.w	418 <Recovery_UpdateCandidate+0x418>
 57a:	e7e5      	b.n	548 <Recovery_UpdateCandidate+0x548>
 57c:	2300      	movs	r3, #0
 57e:	f884 3446 	strb.w	r3, [r4, #1094]	@ 0x446
 582:	e7ed      	b.n	560 <Recovery_UpdateCandidate+0x560>
 584:	7f7fffff 	.word	0x7f7fffff

Disassembly of section .text.NavigationEskfRecovery_Reset:

00000000 <NavigationEskfRecovery_Reset>:
   0:	e92d 43f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, lr}
   4:	b08b      	sub	sp, #44	@ 0x2c
   6:	461f      	mov	r7, r3
   8:	f44f 7388 	mov.w	r3, #272	@ 0x110
   c:	9302      	str	r3, [sp, #8]
   e:	2370      	movs	r3, #112	@ 0x70
  10:	9305      	str	r3, [sp, #20]
  12:	23a0      	movs	r3, #160	@ 0xa0
  14:	f04f 0e01 	mov.w	lr, #1
  18:	9308      	str	r3, [sp, #32]
  1a:	2300      	movs	r3, #0
  1c:	9001      	str	r0, [sp, #4]
  1e:	9104      	str	r1, [sp, #16]
  20:	9207      	str	r2, [sp, #28]
  22:	f88d e00c 	strb.w	lr, [sp, #12]
  26:	f88d e018 	strb.w	lr, [sp, #24]
  2a:	f88d 3024 	strb.w	r3, [sp, #36]	@ 0x24
  2e:	b318      	cbz	r0, 78 <NavigationEskfRecovery_Reset+0x78>
  30:	4604      	mov	r4, r0
  32:	460d      	mov	r5, r1
  34:	4616      	mov	r6, r2
  36:	f10d 0804 	add.w	r8, sp, #4
  3a:	f858 1f0c 	ldr.w	r1, [r8, #12]!
  3e:	b1d9      	cbz	r1, 78 <NavigationEskfRecovery_Reset+0x78>
  40:	aa01      	add	r2, sp, #4
  42:	2000      	movs	r0, #0
  44:	e008      	b.n	58 <NavigationEskfRecovery_Reset+0x58>
  46:	f8d8 3004 	ldr.w	r3, [r8, #4]
  4a:	4599      	cmp	r9, r3
  4c:	d30e      	bcc.n	6c <NavigationEskfRecovery_Reset+0x6c>
  4e:	3001      	adds	r0, #1
  50:	4570      	cmp	r0, lr
  52:	f102 020c 	add.w	r2, r2, #12
  56:	d015      	beq.n	84 <NavigationEskfRecovery_Reset+0x84>
  58:	6813      	ldr	r3, [r2, #0]
  5a:	4299      	cmp	r1, r3
  5c:	eba3 0901 	sub.w	r9, r3, r1
  60:	eba1 0c03 	sub.w	ip, r1, r3
  64:	d9ef      	bls.n	46 <NavigationEskfRecovery_Reset+0x46>
  66:	6853      	ldr	r3, [r2, #4]
  68:	459c      	cmp	ip, r3
  6a:	d2f0      	bcs.n	4e <NavigationEskfRecovery_Reset+0x4e>
  6c:	f898 3008 	ldrb.w	r3, [r8, #8]
  70:	b913      	cbnz	r3, 78 <NavigationEskfRecovery_Reset+0x78>
  72:	7a13      	ldrb	r3, [r2, #8]
  74:	2b00      	cmp	r3, #0
  76:	d0ea      	beq.n	4e <NavigationEskfRecovery_Reset+0x4e>
  78:	f04f 0805 	mov.w	r8, #5
  7c:	4640      	mov	r0, r8
  7e:	b00b      	add	sp, #44	@ 0x2c
  80:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
  84:	f04f 0e02 	mov.w	lr, #2
  88:	4570      	cmp	r0, lr
  8a:	d1d6      	bne.n	3a <NavigationEskfRecovery_Reset+0x3a>
  8c:	4630      	mov	r0, r6
  8e:	f7ff fffe 	bl	0 <NavigationEskfRecovery_Reset>
			8e: R_ARM_THM_CALL	NavigationEskfRecovery_ConfigValidate
  92:	4680      	mov	r8, r0
  94:	2800      	cmp	r0, #0
  96:	d1ef      	bne.n	78 <NavigationEskfRecovery_Reset+0x78>
  98:	4641      	mov	r1, r8
  9a:	f44f 7288 	mov.w	r2, #272	@ 0x110
  9e:	4620      	mov	r0, r4
  a0:	f7ff fffe 	bl	0 <memset>
			a0: R_ARM_THM_CALL	memset
  a4:	4641      	mov	r1, r8
  a6:	2270      	movs	r2, #112	@ 0x70
  a8:	4628      	mov	r0, r5
  aa:	f7ff fffe 	bl	0 <memset>
			aa: R_ARM_THM_CALL	memset
  ae:	e9dd 0114 	ldrd	r0, r1, [sp, #80]	@ 0x50
  b2:	6a32      	ldr	r2, [r6, #32]
  b4:	9b12      	ldr	r3, [sp, #72]	@ 0x48
  b6:	f8c4 70f8 	str.w	r7, [r4, #248]	@ 0xf8
  ba:	e9c4 0138 	strd	r0, r1, [r4, #224]	@ 0xe0
  be:	e9c4 013a 	strd	r0, r1, [r4, #232]	@ 0xe8
  c2:	9912      	ldr	r1, [sp, #72]	@ 0x48
  c4:	e9c4 323f 	strd	r3, r2, [r4, #252]	@ 0xfc
  c8:	4640      	mov	r0, r8
  ca:	2301      	movs	r3, #1
  cc:	f884 310a 	strb.w	r3, [r4, #266]	@ 0x10a
  d0:	e9c5 1213 	strd	r1, r2, [r5, #76]	@ 0x4c
  d4:	64af      	str	r7, [r5, #72]	@ 0x48
  d6:	f885 306a 	strb.w	r3, [r5, #106]	@ 0x6a
  da:	65e3      	str	r3, [r4, #92]	@ 0x5c
  dc:	f8c4 3084 	str.w	r3, [r4, #132]	@ 0x84
  e0:	f8c4 30ac 	str.w	r3, [r4, #172]	@ 0xac
  e4:	f8c4 30d4 	str.w	r3, [r4, #212]	@ 0xd4
  e8:	b00b      	add	sp, #44	@ 0x2c
  ea:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
  ee:	bf00      	nop

Disassembly of section .text.NavigationEskfRecovery_SourceSelect:

00000000 <NavigationEskfRecovery_SourceSelect>:
   0:	b570      	push	{r4, r5, r6, lr}
   2:	4604      	mov	r4, r0
   4:	460d      	mov	r5, r1
   6:	f7ff fffe 	bl	0 <NavigationEskfRecovery_SourceSelect>
			6: R_ARM_THM_CALL	Recovery_ReceiveValid
   a:	b3b8      	cbz	r0, 7c <NavigationEskfRecovery_SourceSelect+0x7c>
   c:	2d03      	cmp	r5, #3
   e:	d835      	bhi.n	7c <NavigationEskfRecovery_SourceSelect+0x7c>
  10:	f894 010b 	ldrb.w	r0, [r4, #267]	@ 0x10b
  14:	bba0      	cbnz	r0, 80 <NavigationEskfRecovery_SourceSelect+0x80>
  16:	f894 3109 	ldrb.w	r3, [r4, #265]	@ 0x109
  1a:	b11b      	cbz	r3, 24 <NavigationEskfRecovery_SourceSelect+0x24>
  1c:	f894 3108 	ldrb.w	r3, [r4, #264]	@ 0x108
  20:	429d      	cmp	r5, r3
  22:	d026      	beq.n	72 <NavigationEskfRecovery_SourceSelect+0x72>
  24:	4623      	mov	r3, r4
  26:	f104 0ea0 	add.w	lr, r4, #160	@ 0xa0
  2a:	f04f 0c00 	mov.w	ip, #0
  2e:	2601      	movs	r6, #1
  30:	2000      	movs	r0, #0
  32:	2100      	movs	r1, #0
  34:	6dda      	ldr	r2, [r3, #92]	@ 0x5c
  36:	f883 c060 	strb.w	ip, [r3, #96]	@ 0x60
  3a:	f1b2 3fff 	cmp.w	r2, #4294967295
  3e:	bf18      	it	ne
  40:	3201      	addne	r2, #1
  42:	e9c3 0112 	strd	r0, r1, [r3, #72]	@ 0x48
  46:	e9c3 0114 	strd	r0, r1, [r3, #80]	@ 0x50
  4a:	bf18      	it	ne
  4c:	65da      	strne	r2, [r3, #92]	@ 0x5c
  4e:	f103 0328 	add.w	r3, r3, #40	@ 0x28
  52:	bf08      	it	eq
  54:	f884 610b 	strbeq.w	r6, [r4, #267]	@ 0x10b
  58:	4573      	cmp	r3, lr
  5a:	d1eb      	bne.n	34 <NavigationEskfRecovery_SourceSelect+0x34>
  5c:	2300      	movs	r3, #0
  5e:	2200      	movs	r2, #0
  60:	e9c4 233c 	strd	r2, r3, [r4, #240]	@ 0xf0
  64:	f894 010b 	ldrb.w	r0, [r4, #267]	@ 0x10b
  68:	f884 5108 	strb.w	r5, [r4, #264]	@ 0x108
  6c:	2301      	movs	r3, #1
  6e:	f884 3109 	strb.w	r3, [r4, #265]	@ 0x109
  72:	3800      	subs	r0, #0
  74:	bf18      	it	ne
  76:	2001      	movne	r0, #1
  78:	0080      	lsls	r0, r0, #2
  7a:	bd70      	pop	{r4, r5, r6, pc}
  7c:	2005      	movs	r0, #5
  7e:	bd70      	pop	{r4, r5, r6, pc}
  80:	2004      	movs	r0, #4
  82:	bd70      	pop	{r4, r5, r6, pc}

Disassembly of section .text.NavigationEskfRecovery_SourceUnavailable:

00000000 <NavigationEskfRecovery_SourceUnavailable>:
   0:	b510      	push	{r4, lr}
   2:	4604      	mov	r4, r0
   4:	f7ff fffe 	bl	0 <NavigationEskfRecovery_SourceUnavailable>
			4: R_ARM_THM_CALL	Recovery_ReceiveValid
   8:	b370      	cbz	r0, 68 <NavigationEskfRecovery_SourceUnavailable+0x68>
   a:	f894 110b 	ldrb.w	r1, [r4, #267]	@ 0x10b
   e:	bb69      	cbnz	r1, 6c <NavigationEskfRecovery_SourceUnavailable+0x6c>
  10:	f894 0109 	ldrb.w	r0, [r4, #265]	@ 0x109
  14:	b318      	cbz	r0, 5e <NavigationEskfRecovery_SourceUnavailable+0x5e>
  16:	ed9f 7b16 	vldr	d7, [pc, #88]	@ 70 <NavigationEskfRecovery_SourceUnavailable+0x70>
  1a:	4623      	mov	r3, r4
  1c:	f104 00a0 	add.w	r0, r4, #160	@ 0xa0
  20:	f04f 0c01 	mov.w	ip, #1
  24:	6dda      	ldr	r2, [r3, #92]	@ 0x5c
  26:	f883 1060 	strb.w	r1, [r3, #96]	@ 0x60
  2a:	f1b2 3fff 	cmp.w	r2, #4294967295
  2e:	bf18      	it	ne
  30:	3201      	addne	r2, #1
  32:	ed83 7b12 	vstr	d7, [r3, #72]	@ 0x48
  36:	ed83 7b14 	vstr	d7, [r3, #80]	@ 0x50
  3a:	bf18      	it	ne
  3c:	65da      	strne	r2, [r3, #92]	@ 0x5c
  3e:	f103 0328 	add.w	r3, r3, #40	@ 0x28
  42:	bf08      	it	eq
  44:	f884 c10b 	strbeq.w	ip, [r4, #267]	@ 0x10b
  48:	4283      	cmp	r3, r0
  4a:	d1eb      	bne.n	24 <NavigationEskfRecovery_SourceUnavailable+0x24>
  4c:	2300      	movs	r3, #0
  4e:	2200      	movs	r2, #0
  50:	e9c4 233c 	strd	r2, r3, [r4, #240]	@ 0xf0
  54:	f894 010b 	ldrb.w	r0, [r4, #267]	@ 0x10b
  58:	2300      	movs	r3, #0
  5a:	f884 3109 	strb.w	r3, [r4, #265]	@ 0x109
  5e:	3800      	subs	r0, #0
  60:	bf18      	it	ne
  62:	2001      	movne	r0, #1
  64:	0080      	lsls	r0, r0, #2
  66:	bd10      	pop	{r4, pc}
  68:	2005      	movs	r0, #5
  6a:	bd10      	pop	{r4, pc}
  6c:	2004      	movs	r0, #4
  6e:	bd10      	pop	{r4, pc}
	...

Disassembly of section .text.NavigationEskfRecovery_Tick:

00000000 <NavigationEskfRecovery_Tick>:
   0:	2800      	cmp	r0, #0
   2:	f000 8082 	beq.w	10a <NavigationEskfRecovery_Tick+0x10a>
   6:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
   a:	4688      	mov	r8, r1
   c:	2900      	cmp	r1, #0
   e:	d053      	beq.n	b8 <NavigationEskfRecovery_Tick+0xb8>
  10:	4281      	cmp	r1, r0
  12:	4616      	mov	r6, r2
  14:	461f      	mov	r7, r3
  16:	4604      	mov	r4, r0
  18:	4605      	mov	r5, r0
  1a:	d850      	bhi.n	be <NavigationEskfRecovery_Tick+0xbe>
  1c:	1a43      	subs	r3, r0, r1
  1e:	2b9f      	cmp	r3, #159	@ 0x9f
  20:	bf8c      	ite	hi
  22:	2300      	movhi	r3, #0
  24:	2301      	movls	r3, #1
  26:	2b00      	cmp	r3, #0
  28:	d146      	bne.n	b8 <NavigationEskfRecovery_Tick+0xb8>
  2a:	4620      	mov	r0, r4
  2c:	f7ff fffe 	bl	0 <NavigationEskfRecovery_Tick>
			2c: R_ARM_THM_CALL	Recovery_ReceiveValid
  30:	2800      	cmp	r0, #0
  32:	d041      	beq.n	b8 <NavigationEskfRecovery_Tick+0xb8>
  34:	4640      	mov	r0, r8
  36:	f7ff fffe 	bl	0 <NavigationEskfRecovery_Tick>
			36: R_ARM_THM_CALL	NavigationEskfRecovery_ConfigValidate
  3a:	bbe8      	cbnz	r0, b8 <NavigationEskfRecovery_Tick+0xb8>
  3c:	f8d4 2100 	ldr.w	r2, [r4, #256]	@ 0x100
  40:	f8d8 3020 	ldr.w	r3, [r8, #32]
  44:	429a      	cmp	r2, r3
  46:	d137      	bne.n	b8 <NavigationEskfRecovery_Tick+0xb8>
  48:	f898 1024 	ldrb.w	r1, [r8, #36]	@ 0x24
  4c:	f104 02a0 	add.w	r2, r4, #160	@ 0xa0
  50:	4620      	mov	r0, r4
  52:	f890 3060 	ldrb.w	r3, [r0, #96]	@ 0x60
  56:	428b      	cmp	r3, r1
  58:	f100 0028 	add.w	r0, r0, #40	@ 0x28
  5c:	d82c      	bhi.n	b8 <NavigationEskfRecovery_Tick+0xb8>
  5e:	4282      	cmp	r2, r0
  60:	d1f7      	bne.n	52 <NavigationEskfRecovery_Tick+0x52>
  62:	f894 310b 	ldrb.w	r3, [r4, #267]	@ 0x10b
  66:	bb8b      	cbnz	r3, cc <NavigationEskfRecovery_Tick+0xcc>
  68:	e9d4 133a 	ldrd	r1, r3, [r4, #232]	@ 0xe8
  6c:	428e      	cmp	r6, r1
  6e:	eb77 0303 	sbcs.w	r3, r7, r3
  72:	d348      	bcc.n	106 <NavigationEskfRecovery_Tick+0x106>
  74:	e9c4 673a 	strd	r6, r7, [r4, #232]	@ 0xe8
  78:	e9d5 1310 	ldrd	r1, r3, [r5, #64]	@ 0x40
  7c:	ea51 0003 	orrs.w	r0, r1, r3
  80:	d00f      	beq.n	a2 <NavigationEskfRecovery_Tick+0xa2>
  82:	f895 0061 	ldrb.w	r0, [r5, #97]	@ 0x61
  86:	b960      	cbnz	r0, a2 <NavigationEskfRecovery_Tick+0xa2>
  88:	428e      	cmp	r6, r1
  8a:	eb77 0003 	sbcs.w	r0, r7, r3
  8e:	d308      	bcc.n	a2 <NavigationEskfRecovery_Tick+0xa2>
  90:	ebb6 0c01 	subs.w	ip, r6, r1
  94:	e9d8 0100 	ldrd	r0, r1, [r8]
  98:	eb67 0303 	sbc.w	r3, r7, r3
  9c:	4584      	cmp	ip, r0
  9e:	418b      	sbcs	r3, r1
  a0:	d216      	bcs.n	d0 <NavigationEskfRecovery_Tick+0xd0>
  a2:	3528      	adds	r5, #40	@ 0x28
  a4:	4295      	cmp	r5, r2
  a6:	d1e7      	bne.n	78 <NavigationEskfRecovery_Tick+0x78>
  a8:	f894 010b 	ldrb.w	r0, [r4, #267]	@ 0x10b
  ac:	3800      	subs	r0, #0
  ae:	bf18      	it	ne
  b0:	2001      	movne	r0, #1
  b2:	0080      	lsls	r0, r0, #2
  b4:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
  b8:	2005      	movs	r0, #5
  ba:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
  be:	1a0b      	subs	r3, r1, r0
  c0:	f5b3 7f88 	cmp.w	r3, #272	@ 0x110
  c4:	bf2c      	ite	cs
  c6:	2300      	movcs	r3, #0
  c8:	2301      	movcc	r3, #1
  ca:	e7ac      	b.n	26 <NavigationEskfRecovery_Tick+0x26>
  cc:	2004      	movs	r0, #4
  ce:	e7f4      	b.n	ba <NavigationEskfRecovery_Tick+0xba>
  d0:	6dab      	ldr	r3, [r5, #88]	@ 0x58
  d2:	1c58      	adds	r0, r3, #1
  d4:	bf07      	ittee	eq
  d6:	2301      	moveq	r3, #1
  d8:	f884 310b 	strbeq.w	r3, [r4, #267]	@ 0x10b
  dc:	3301      	addne	r3, #1
  de:	65ab      	strne	r3, [r5, #88]	@ 0x58
  e0:	f44f 7180 	mov.w	r1, #256	@ 0x100
  e4:	6deb      	ldr	r3, [r5, #92]	@ 0x5c
  e6:	f8a5 1060 	strh.w	r1, [r5, #96]	@ 0x60
  ea:	2000      	movs	r0, #0
  ec:	2100      	movs	r1, #0
  ee:	e9c5 0112 	strd	r0, r1, [r5, #72]	@ 0x48
  f2:	e9c5 0114 	strd	r0, r1, [r5, #80]	@ 0x50
  f6:	1c59      	adds	r1, r3, #1
  f8:	bf0b      	itete	eq
  fa:	2301      	moveq	r3, #1
  fc:	3301      	addne	r3, #1
  fe:	f884 310b 	strbeq.w	r3, [r4, #267]	@ 0x10b
 102:	65eb      	strne	r3, [r5, #92]	@ 0x5c
 104:	e7cd      	b.n	a2 <NavigationEskfRecovery_Tick+0xa2>
 106:	2002      	movs	r0, #2
 108:	e7d7      	b.n	ba <NavigationEskfRecovery_Tick+0xba>
 10a:	2005      	movs	r0, #5
 10c:	4770      	bx	lr
 10e:	bf00      	nop

Disassembly of section .text.NavigationEskfRecovery_Receive:

00000000 <NavigationEskfRecovery_Receive>:
   0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
   4:	4698      	mov	r8, r3
   6:	b093      	sub	sp, #76	@ 0x4c
   8:	f44f 7388 	mov.w	r3, #272	@ 0x110
   c:	e9cd 0306 	strd	r0, r3, [sp, #24]
  10:	2300      	movs	r3, #0
  12:	f88d 302c 	strb.w	r3, [sp, #44]	@ 0x2c
  16:	f88d 3038 	strb.w	r3, [sp, #56]	@ 0x38
  1a:	23a0      	movs	r3, #160	@ 0xa0
  1c:	930a      	str	r3, [sp, #40]	@ 0x28
  1e:	2328      	movs	r3, #40	@ 0x28
  20:	f04f 0e01 	mov.w	lr, #1
  24:	930d      	str	r3, [sp, #52]	@ 0x34
  26:	2370      	movs	r3, #112	@ 0x70
  28:	f88d e020 	strb.w	lr, [sp, #32]
  2c:	9109      	str	r1, [sp, #36]	@ 0x24
  2e:	920c      	str	r2, [sp, #48]	@ 0x30
  30:	f8cd 803c 	str.w	r8, [sp, #60]	@ 0x3c
  34:	f88d e044 	strb.w	lr, [sp, #68]	@ 0x44
  38:	9310      	str	r3, [sp, #64]	@ 0x40
  3a:	2800      	cmp	r0, #0
  3c:	d03a      	beq.n	b4 <NavigationEskfRecovery_Receive+0xb4>
  3e:	460e      	mov	r6, r1
  40:	4617      	mov	r7, r2
  42:	ad06      	add	r5, sp, #24
  44:	4681      	mov	r9, r0
  46:	68e9      	ldr	r1, [r5, #12]
  48:	4628      	mov	r0, r5
  4a:	350c      	adds	r5, #12
  4c:	b391      	cbz	r1, b4 <NavigationEskfRecovery_Receive+0xb4>
  4e:	9b06      	ldr	r3, [sp, #24]
  50:	4299      	cmp	r1, r3
  52:	aa06      	add	r2, sp, #24
  54:	eba3 0c01 	sub.w	ip, r3, r1
  58:	eba1 0303 	sub.w	r3, r1, r3
  5c:	d815      	bhi.n	8a <NavigationEskfRecovery_Receive+0x8a>
  5e:	686b      	ldr	r3, [r5, #4]
  60:	459c      	cmp	ip, r3
  62:	bf2c      	ite	cs
  64:	2300      	movcs	r3, #0
  66:	2301      	movcc	r3, #1
  68:	b11b      	cbz	r3, 72 <NavigationEskfRecovery_Receive+0x72>
  6a:	7a2b      	ldrb	r3, [r5, #8]
  6c:	bb13      	cbnz	r3, b4 <NavigationEskfRecovery_Receive+0xb4>
  6e:	7a13      	ldrb	r3, [r2, #8]
  70:	bb03      	cbnz	r3, b4 <NavigationEskfRecovery_Receive+0xb4>
  72:	4290      	cmp	r0, r2
  74:	f102 030c 	add.w	r3, r2, #12
  78:	d00d      	beq.n	96 <NavigationEskfRecovery_Receive+0x96>
  7a:	461a      	mov	r2, r3
  7c:	6813      	ldr	r3, [r2, #0]
  7e:	4299      	cmp	r1, r3
  80:	eba3 0c01 	sub.w	ip, r3, r1
  84:	eba1 0303 	sub.w	r3, r1, r3
  88:	d9e9      	bls.n	5e <NavigationEskfRecovery_Receive+0x5e>
  8a:	6854      	ldr	r4, [r2, #4]
  8c:	42a3      	cmp	r3, r4
  8e:	bf2c      	ite	cs
  90:	2300      	movcs	r3, #0
  92:	2301      	movcc	r3, #1
  94:	e7e8      	b.n	68 <NavigationEskfRecovery_Receive+0x68>
  96:	f10e 0e01 	add.w	lr, lr, #1
  9a:	f1be 0f04 	cmp.w	lr, #4
  9e:	d1d2      	bne.n	46 <NavigationEskfRecovery_Receive+0x46>
  a0:	4648      	mov	r0, r9
  a2:	f7ff fffe 	bl	0 <NavigationEskfRecovery_Receive>
			a2: R_ARM_THM_CALL	Recovery_ReceiveValid
  a6:	464c      	mov	r4, r9
  a8:	4605      	mov	r5, r0
  aa:	b118      	cbz	r0, b4 <NavigationEskfRecovery_Receive+0xb4>
  ac:	4630      	mov	r0, r6
  ae:	f7ff fffe 	bl	0 <NavigationEskfRecovery_Receive>
			ae: R_ARM_THM_CALL	NavigationEskfRecovery_ConfigValidate
  b2:	b120      	cbz	r0, be <NavigationEskfRecovery_Receive+0xbe>
  b4:	2505      	movs	r5, #5
  b6:	4628      	mov	r0, r5
  b8:	b013      	add	sp, #76	@ 0x4c
  ba:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
  be:	f8d4 2100 	ldr.w	r2, [r4, #256]	@ 0x100
  c2:	6a33      	ldr	r3, [r6, #32]
  c4:	429a      	cmp	r2, r3
  c6:	d1f5      	bne.n	b4 <NavigationEskfRecovery_Receive+0xb4>
  c8:	f896 1024 	ldrb.w	r1, [r6, #36]	@ 0x24
  cc:	46a1      	mov	r9, r4
  ce:	f104 0aa0 	add.w	sl, r4, #160	@ 0xa0
  d2:	4623      	mov	r3, r4
  d4:	f893 2060 	ldrb.w	r2, [r3, #96]	@ 0x60
  d8:	428a      	cmp	r2, r1
  da:	f103 0328 	add.w	r3, r3, #40	@ 0x28
  de:	d8e9      	bhi.n	b4 <NavigationEskfRecovery_Receive+0xb4>
  e0:	459a      	cmp	sl, r3
  e2:	d1f7      	bne.n	d4 <NavigationEskfRecovery_Receive+0xd4>
  e4:	6939      	ldr	r1, [r7, #16]
  e6:	2903      	cmp	r1, #3
  e8:	d8e4      	bhi.n	b4 <NavigationEskfRecovery_Receive+0xb4>
  ea:	69ba      	ldr	r2, [r7, #24]
  ec:	f8d4 30f8 	ldr.w	r3, [r4, #248]	@ 0xf8
  f0:	429a      	cmp	r2, r3
  f2:	d1df      	bne.n	b4 <NavigationEskfRecovery_Receive+0xb4>
  f4:	69fa      	ldr	r2, [r7, #28]
  f6:	f8d4 30fc 	ldr.w	r3, [r4, #252]	@ 0xfc
  fa:	429a      	cmp	r2, r3
  fc:	d1da      	bne.n	b4 <NavigationEskfRecovery_Receive+0xb4>
  fe:	6838      	ldr	r0, [r7, #0]
 100:	f8d7 b004 	ldr.w	fp, [r7, #4]
 104:	9003      	str	r0, [sp, #12]
 106:	ea50 030b 	orrs.w	r3, r0, fp
 10a:	d0d3      	beq.n	b4 <NavigationEskfRecovery_Receive+0xb4>
 10c:	e9d4 2338 	ldrd	r2, r3, [r4, #224]	@ 0xe0
 110:	4290      	cmp	r0, r2
 112:	eb7b 0303 	sbcs.w	r3, fp, r3
 116:	9005      	str	r0, [sp, #20]
 118:	d3cc      	bcc.n	b4 <NavigationEskfRecovery_Receive+0xb4>
 11a:	f894 310b 	ldrb.w	r3, [r4, #267]	@ 0x10b
 11e:	2b00      	cmp	r3, #0
 120:	f040 8102 	bne.w	328 <NavigationEskfRecovery_Receive+0x328>
 124:	f8d4 c104 	ldr.w	ip, [r4, #260]	@ 0x104
 128:	f1bc 3fff 	cmp.w	ip, #4294967295
 12c:	f000 80fc 	beq.w	328 <NavigationEskfRecovery_Receive+0x328>
 130:	eb04 1301 	add.w	r3, r4, r1, lsl #4
 134:	6978      	ldr	r0, [r7, #20]
 136:	7b1b      	ldrb	r3, [r3, #12]
 138:	9004      	str	r0, [sp, #16]
 13a:	010a      	lsls	r2, r1, #4
 13c:	b18b      	cbz	r3, 162 <NavigationEskfRecovery_Receive+0x162>
 13e:	eb04 0e02 	add.w	lr, r4, r2
 142:	f8de 3008 	ldr.w	r3, [lr, #8]
 146:	1ac3      	subs	r3, r0, r3
 148:	2b00      	cmp	r3, #0
 14a:	d0b4      	beq.n	b6 <NavigationEskfRecovery_Receive+0xb6>
 14c:	f2c0 8106 	blt.w	35c <NavigationEskfRecovery_Receive+0x35c>
 150:	58a3      	ldr	r3, [r4, r2]
 152:	9805      	ldr	r0, [sp, #20]
 154:	f8de 5004 	ldr.w	r5, [lr, #4]
 158:	4283      	cmp	r3, r0
 15a:	eb75 050b 	sbcs.w	r5, r5, fp
 15e:	f080 80fd 	bcs.w	35c <NavigationEskfRecovery_Receive+0x35c>
 162:	18a5      	adds	r5, r4, r2
 164:	9804      	ldr	r0, [sp, #16]
 166:	60a8      	str	r0, [r5, #8]
 168:	9803      	ldr	r0, [sp, #12]
 16a:	50a0      	str	r0, [r4, r2]
 16c:	f10c 0301 	add.w	r3, ip, #1
 170:	2201      	movs	r2, #1
 172:	f8c5 b004 	str.w	fp, [r5, #4]
 176:	732a      	strb	r2, [r5, #12]
 178:	4620      	mov	r0, r4
 17a:	f8c4 3104 	str.w	r3, [r4, #260]	@ 0x104
 17e:	f7ff fffe 	bl	0 <NavigationEskfRecovery_Receive>
			17e: R_ARM_THM_CALL	NavigationEskfRecovery_SourceSelect
 182:	4605      	mov	r5, r0
 184:	2800      	cmp	r0, #0
 186:	d196      	bne.n	b6 <NavigationEskfRecovery_Receive+0xb6>
 188:	e9d4 133a 	ldrd	r1, r3, [r4, #232]	@ 0xe8
 18c:	9803      	ldr	r0, [sp, #12]
 18e:	4288      	cmp	r0, r1
 190:	eb7b 0303 	sbcs.w	r3, fp, r3
 194:	f04f 0201 	mov.w	r2, #1
 198:	f0c0 80a2 	bcc.w	2e0 <NavigationEskfRecovery_Receive+0x2e0>
 19c:	9a03      	ldr	r2, [sp, #12]
 19e:	465b      	mov	r3, fp
 1a0:	4631      	mov	r1, r6
 1a2:	4620      	mov	r0, r4
 1a4:	f7ff fffe 	bl	0 <NavigationEskfRecovery_Receive>
			1a4: R_ARM_THM_CALL	NavigationEskfRecovery_Tick
 1a8:	4605      	mov	r5, r0
 1aa:	2800      	cmp	r0, #0
 1ac:	d183      	bne.n	b6 <NavigationEskfRecovery_Receive+0xb6>
 1ae:	f897 3022 	ldrb.w	r3, [r7, #34]	@ 0x22
 1b2:	f897 a020 	ldrb.w	sl, [r7, #32]
 1b6:	2b01      	cmp	r3, #1
 1b8:	f000 80b8 	beq.w	32c <NavigationEskfRecovery_Receive+0x32c>
 1bc:	ed9f 7b68 	vldr	d7, [pc, #416]	@ 360 <NavigationEskfRecovery_Receive+0x360>
 1c0:	2100      	movs	r1, #0
 1c2:	4628      	mov	r0, r5
 1c4:	46a6      	mov	lr, r4
 1c6:	2301      	movs	r3, #1
 1c8:	fa03 f201 	lsl.w	r2, r3, r1
 1cc:	f1ba 0f0f 	cmp.w	sl, #15
 1d0:	b2d2      	uxtb	r2, r2
 1d2:	d80a      	bhi.n	1ea <NavigationEskfRecovery_Receive+0x1ea>
 1d4:	ea1a 0f02 	tst.w	sl, r2
 1d8:	d007      	beq.n	1ea <NavigationEskfRecovery_Receive+0x1ea>
 1da:	e9d7 4500 	ldrd	r4, r5, [r7]
 1de:	e9c9 4510 	strd	r4, r5, [r9, #64]	@ 0x40
 1e2:	f04f 0400 	mov.w	r4, #0
 1e6:	f889 4061 	strb.w	r4, [r9, #97]	@ 0x61
 1ea:	b388      	cbz	r0, 250 <NavigationEskfRecovery_Receive+0x250>
 1ec:	f897 4021 	ldrb.w	r4, [r7, #33]	@ 0x21
 1f0:	ea0a 0404 	and.w	r4, sl, r4
 1f4:	4222      	tst	r2, r4
 1f6:	d02b      	beq.n	250 <NavigationEskfRecovery_Receive+0x250>
 1f8:	e9d9 4214 	ldrd	r4, r2, [r9, #80]	@ 0x50
 1fc:	ea54 0302 	orrs.w	r3, r4, r2
 200:	e9d7 c500 	ldrd	ip, r5, [r7]
 204:	d008      	beq.n	218 <NavigationEskfRecovery_Receive+0x218>
 206:	ebbc 0404 	subs.w	r4, ip, r4
 20a:	eb65 0302 	sbc.w	r3, r5, r2
 20e:	6932      	ldr	r2, [r6, #16]
 210:	42a2      	cmp	r2, r4
 212:	6972      	ldr	r2, [r6, #20]
 214:	419a      	sbcs	r2, r3
 216:	d34a      	bcc.n	2ae <NavigationEskfRecovery_Receive+0x2ae>
 218:	f899 2060 	ldrb.w	r2, [r9, #96]	@ 0x60
 21c:	2a00      	cmp	r2, #0
 21e:	d05b      	beq.n	2d8 <NavigationEskfRecovery_Receive+0x2d8>
 220:	f896 4024 	ldrb.w	r4, [r6, #36]	@ 0x24
 224:	4294      	cmp	r4, r2
 226:	bf88      	it	hi
 228:	3201      	addhi	r2, #1
 22a:	f101 0101 	add.w	r1, r1, #1
 22e:	bf88      	it	hi
 230:	f889 2060 	strbhi.w	r2, [r9, #96]	@ 0x60
 234:	2904      	cmp	r1, #4
 236:	e9c9 c514 	strd	ip, r5, [r9, #80]	@ 0x50
 23a:	d022      	beq.n	282 <NavigationEskfRecovery_Receive+0x282>
 23c:	2301      	movs	r3, #1
 23e:	fa03 f201 	lsl.w	r2, r3, r1
 242:	f1ba 0f0f 	cmp.w	sl, #15
 246:	f109 0928 	add.w	r9, r9, #40	@ 0x28
 24a:	b2d2      	uxtb	r2, r2
 24c:	d9c2      	bls.n	1d4 <NavigationEskfRecovery_Receive+0x1d4>
 24e:	e7cd      	b.n	1ec <NavigationEskfRecovery_Receive+0x1ec>
 250:	f04f 0200 	mov.w	r2, #0
 254:	f889 2060 	strb.w	r2, [r9, #96]	@ 0x60
 258:	f8d9 205c 	ldr.w	r2, [r9, #92]	@ 0x5c
 25c:	1c54      	adds	r4, r2, #1
 25e:	bf0c      	ite	eq
 260:	2201      	moveq	r2, #1
 262:	3201      	addne	r2, #1
 264:	f101 0101 	add.w	r1, r1, #1
 268:	ed89 7b12 	vstr	d7, [r9, #72]	@ 0x48
 26c:	ed89 7b14 	vstr	d7, [r9, #80]	@ 0x50
 270:	bf14      	ite	ne
 272:	f8c9 205c 	strne.w	r2, [r9, #92]	@ 0x5c
 276:	f88e 210b 	strbeq.w	r2, [lr, #267]	@ 0x10b
 27a:	2904      	cmp	r1, #4
 27c:	f109 0928 	add.w	r9, r9, #40	@ 0x28
 280:	d1a1      	bne.n	1c6 <NavigationEskfRecovery_Receive+0x1c6>
 282:	4674      	mov	r4, lr
 284:	2800      	cmp	r0, #0
 286:	d04c      	beq.n	322 <NavigationEskfRecovery_Receive+0x322>
 288:	e9d7 2302 	ldrd	r2, r3, [r7, #8]
 28c:	e9c4 233c 	strd	r2, r3, [r4, #240]	@ 0xf0
 290:	4631      	mov	r1, r6
 292:	9a03      	ldr	r2, [sp, #12]
 294:	f8cd 8000 	str.w	r8, [sp]
 298:	465b      	mov	r3, fp
 29a:	4620      	mov	r0, r4
 29c:	f7ff fffe 	bl	0 <NavigationEskfRecovery_Receive>
			29c: R_ARM_THM_CALL	Recovery_EvidenceWrite
 2a0:	f894 510b 	ldrb.w	r5, [r4, #267]	@ 0x10b
 2a4:	3d00      	subs	r5, #0
 2a6:	bf18      	it	ne
 2a8:	2501      	movne	r5, #1
 2aa:	00ad      	lsls	r5, r5, #2
 2ac:	e703      	b.n	b6 <NavigationEskfRecovery_Receive+0xb6>
 2ae:	f8d9 205c 	ldr.w	r2, [r9, #92]	@ 0x5c
 2b2:	ed9f 6b2b 	vldr	d6, [pc, #172]	@ 360 <NavigationEskfRecovery_Receive+0x360>
 2b6:	1c53      	adds	r3, r2, #1
 2b8:	f04f 0400 	mov.w	r4, #0
 2bc:	bf0c      	ite	eq
 2be:	2201      	moveq	r2, #1
 2c0:	3201      	addne	r2, #1
 2c2:	ed89 6b12 	vstr	d6, [r9, #72]	@ 0x48
 2c6:	ed89 6b14 	vstr	d6, [r9, #80]	@ 0x50
 2ca:	f889 4060 	strb.w	r4, [r9, #96]	@ 0x60
 2ce:	bf14      	ite	ne
 2d0:	f8c9 205c 	strne.w	r2, [r9, #92]	@ 0x5c
 2d4:	f88e 210b 	strbeq.w	r2, [lr, #267]	@ 0x10b
 2d8:	e9c9 c512 	strd	ip, r5, [r9, #72]	@ 0x48
 2dc:	2200      	movs	r2, #0
 2de:	e79f      	b.n	220 <NavigationEskfRecovery_Receive+0x220>
 2e0:	2000      	movs	r0, #0
 2e2:	2100      	movs	r1, #0
 2e4:	f8d9 305c 	ldr.w	r3, [r9, #92]	@ 0x5c
 2e8:	f889 5060 	strb.w	r5, [r9, #96]	@ 0x60
 2ec:	1c5f      	adds	r7, r3, #1
 2ee:	bf18      	it	ne
 2f0:	3301      	addne	r3, #1
 2f2:	e9c9 0112 	strd	r0, r1, [r9, #72]	@ 0x48
 2f6:	e9c9 0114 	strd	r0, r1, [r9, #80]	@ 0x50
 2fa:	bf18      	it	ne
 2fc:	f8c9 305c 	strne.w	r3, [r9, #92]	@ 0x5c
 300:	f109 0928 	add.w	r9, r9, #40	@ 0x28
 304:	bf08      	it	eq
 306:	f884 210b 	strbeq.w	r2, [r4, #267]	@ 0x10b
 30a:	45ca      	cmp	sl, r9
 30c:	d1ea      	bne.n	2e4 <NavigationEskfRecovery_Receive+0x2e4>
 30e:	9a03      	ldr	r2, [sp, #12]
 310:	f8cd 8000 	str.w	r8, [sp]
 314:	465b      	mov	r3, fp
 316:	4631      	mov	r1, r6
 318:	4620      	mov	r0, r4
 31a:	f7ff fffe 	bl	0 <NavigationEskfRecovery_Receive>
			31a: R_ARM_THM_CALL	Recovery_EvidenceWrite
 31e:	2503      	movs	r5, #3
 320:	e6c9      	b.n	b6 <NavigationEskfRecovery_Receive+0xb6>
 322:	2200      	movs	r2, #0
 324:	2300      	movs	r3, #0
 326:	e7b1      	b.n	28c <NavigationEskfRecovery_Receive+0x28c>
 328:	2504      	movs	r5, #4
 32a:	e6c4      	b.n	b6 <NavigationEskfRecovery_Receive+0xb6>
 32c:	e9d7 0102 	ldrd	r0, r1, [r7, #8]
 330:	ea50 0301 	orrs.w	r3, r0, r1
 334:	f43f af42 	beq.w	1bc <NavigationEskfRecovery_Receive+0x1bc>
 338:	e9d4 233c 	ldrd	r2, r3, [r4, #240]	@ 0xf0
 33c:	4282      	cmp	r2, r0
 33e:	eb73 0101 	sbcs.w	r1, r3, r1
 342:	f4bf af3b 	bcs.w	1bc <NavigationEskfRecovery_Receive+0x1bc>
 346:	f1ba 0f0f 	cmp.w	sl, #15
 34a:	f63f af37 	bhi.w	1bc <NavigationEskfRecovery_Receive+0x1bc>
 34e:	f897 3021 	ldrb.w	r3, [r7, #33]	@ 0x21
 352:	2b0f      	cmp	r3, #15
 354:	bf8c      	ite	hi
 356:	2500      	movhi	r5, #0
 358:	2501      	movls	r5, #1
 35a:	e72f      	b.n	1bc <NavigationEskfRecovery_Receive+0x1bc>
 35c:	2502      	movs	r5, #2
 35e:	e6aa      	b.n	b6 <NavigationEskfRecovery_Receive+0xb6>
	...

Disassembly of section .text.NavigationEskfRecovery_PolicyValidate:

00000000 <NavigationEskfRecovery_PolicyValidate>:
   0:	b570      	push	{r4, r5, r6, lr}
   2:	b178      	cbz	r0, 24 <NavigationEskfRecovery_PolicyValidate+0x24>
   4:	4605      	mov	r5, r0
   6:	4608      	mov	r0, r1
   8:	460e      	mov	r6, r1
   a:	f7ff fffe 	bl	0 <NavigationEskfRecovery_PolicyValidate>
			a: R_ARM_THM_CALL	NavigationEskfRecovery_ConfigValidate
   e:	4604      	mov	r4, r0
  10:	b940      	cbnz	r0, 24 <NavigationEskfRecovery_PolicyValidate+0x24>
  12:	4631      	mov	r1, r6
  14:	4628      	mov	r0, r5
  16:	f7ff fffe 	bl	0 <NavigationEskfRecovery_PolicyValidate>
			16: R_ARM_THM_CALL	Recovery_PolicyValid
  1a:	2800      	cmp	r0, #0
  1c:	bf08      	it	eq
  1e:	2405      	moveq	r4, #5
  20:	4620      	mov	r0, r4
  22:	bd70      	pop	{r4, r5, r6, pc}
  24:	2405      	movs	r4, #5
  26:	4620      	mov	r0, r4
  28:	bd70      	pop	{r4, r5, r6, pc}
  2a:	bf00      	nop

Disassembly of section .text.NavigationEskfRecovery_UpdateCandidate:

00000000 <NavigationEskfRecovery_UpdateCandidate>:
   0:	b510      	push	{r4, lr}
   2:	b086      	sub	sp, #24
   4:	9c08      	ldr	r4, [sp, #32]
   6:	9400      	str	r4, [sp, #0]
   8:	9c09      	ldr	r4, [sp, #36]	@ 0x24
   a:	9401      	str	r4, [sp, #4]
   c:	9c0a      	ldr	r4, [sp, #40]	@ 0x28
   e:	9402      	str	r4, [sp, #8]
  10:	9c0b      	ldr	r4, [sp, #44]	@ 0x2c
  12:	9403      	str	r4, [sp, #12]
  14:	2401      	movs	r4, #1
  16:	9404      	str	r4, [sp, #16]
  18:	f7ff fffe 	bl	0 <NavigationEskfRecovery_UpdateCandidate>
			18: R_ARM_THM_CALL	Recovery_UpdateCandidate
  1c:	b006      	add	sp, #24
  1e:	bd10      	pop	{r4, pc}

Disassembly of section .text.NavigationEskfRecovery_UpdateCandidateRevision2:

00000000 <NavigationEskfRecovery_UpdateCandidateRevision2>:
   0:	b510      	push	{r4, lr}
   2:	b086      	sub	sp, #24
   4:	9c08      	ldr	r4, [sp, #32]
   6:	9400      	str	r4, [sp, #0]
   8:	9c09      	ldr	r4, [sp, #36]	@ 0x24
   a:	9401      	str	r4, [sp, #4]
   c:	9c0a      	ldr	r4, [sp, #40]	@ 0x28
   e:	9402      	str	r4, [sp, #8]
  10:	9c0b      	ldr	r4, [sp, #44]	@ 0x2c
  12:	9403      	str	r4, [sp, #12]
  14:	2402      	movs	r4, #2
  16:	9404      	str	r4, [sp, #16]
  18:	f7ff fffe 	bl	0 <NavigationEskfRecovery_UpdateCandidateRevision2>
			18: R_ARM_THM_CALL	Recovery_UpdateCandidate
  1c:	b006      	add	sp, #24
  1e:	bd10      	pop	{r4, pc}
