
D:\python_software\SilverStar\.work\dev013_navclosure02\eskf15_0_default03\build\FCCG\SilverStar_F407\Release\auto\Algorithm\Estimator\ESKF15\Src\navigation_eskf_recovery_qualifier.o:     file format elf32-littlearm


Disassembly of section .text.NavigationEskfRecoveryQualifier_ConfigValidate:

00000000 <NavigationEskfRecoveryQualifier_ConfigValidate>:
   0:	2800      	cmp	r0, #0
   2:	d041      	beq.n	88 <NavigationEskfRecoveryQualifier_ConfigValidate+0x88>
   4:	e9d0 3100 	ldrd	r3, r1, [r0]
   8:	b530      	push	{r4, r5, lr}
   a:	4c20      	ldr	r4, [pc, #128]	@ (8c <NavigationEskfRecoveryQualifier_ConfigValidate+0x8c>)
   c:	f113 3eff 	adds.w	lr, r3, #4294967295
  10:	f141 3cff 	adc.w	ip, r1, #4294967295
  14:	2200      	movs	r2, #0
  16:	4574      	cmp	r4, lr
  18:	eb72 0c0c 	sbcs.w	ip, r2, ip
  1c:	d332      	bcc.n	84 <NavigationEskfRecoveryQualifier_ConfigValidate+0x84>
  1e:	e9d0 5402 	ldrd	r5, r4, [r0, #8]
  22:	42ab      	cmp	r3, r5
  24:	41a1      	sbcs	r1, r4
  26:	d32d      	bcc.n	84 <NavigationEskfRecoveryQualifier_ConfigValidate+0x84>
  28:	ed90 7a04 	vldr	s14, [r0, #16]
  2c:	eddf 7a18 	vldr	s15, [pc, #96]	@ 90 <NavigationEskfRecoveryQualifier_ConfigValidate+0x90>
  30:	eef0 6ac7 	vabs.f32	s13, s14
  34:	eef4 6a67 	vcmp.f32	s13, s15
  38:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  3c:	d822      	bhi.n	84 <NavigationEskfRecoveryQualifier_ConfigValidate+0x84>
  3e:	eeb5 7ac0 	vcmpe.f32	s14, #0.0
  42:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  46:	d91d      	bls.n	84 <NavigationEskfRecoveryQualifier_ConfigValidate+0x84>
  48:	ed90 7a05 	vldr	s14, [r0, #20]
  4c:	eef0 6ac7 	vabs.f32	s13, s14
  50:	eef4 6a67 	vcmp.f32	s13, s15
  54:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  58:	d814      	bhi.n	84 <NavigationEskfRecoveryQualifier_ConfigValidate+0x84>
  5a:	eeb5 7ac0 	vcmpe.f32	s14, #0.0
  5e:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  62:	d90f      	bls.n	84 <NavigationEskfRecoveryQualifier_ConfigValidate+0x84>
  64:	ed90 7a06 	vldr	s14, [r0, #24]
  68:	eef0 6ac7 	vabs.f32	s13, s14
  6c:	eef4 6a67 	vcmp.f32	s13, s15
  70:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  74:	d806      	bhi.n	84 <NavigationEskfRecoveryQualifier_ConfigValidate+0x84>
  76:	eeb5 7ac0 	vcmpe.f32	s14, #0.0
  7a:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  7e:	d901      	bls.n	84 <NavigationEskfRecoveryQualifier_ConfigValidate+0x84>
  80:	4610      	mov	r0, r2
  82:	bd30      	pop	{r4, r5, pc}
  84:	2005      	movs	r0, #5
  86:	bd30      	pop	{r4, r5, pc}
  88:	2005      	movs	r0, #5
  8a:	4770      	bx	lr
  8c:	0007a11f 	.word	0x0007a11f
  90:	7f7fffff 	.word	0x7f7fffff

Disassembly of section .text.NavigationEskfRecoveryQualifier_Reset:

00000000 <NavigationEskfRecoveryQualifier_Reset>:
   0:	b130      	cbz	r0, 10 <NavigationEskfRecoveryQualifier_Reset+0x10>
   2:	b508      	push	{r3, lr}
   4:	22d8      	movs	r2, #216	@ 0xd8
   6:	2100      	movs	r1, #0
   8:	f7ff fffe 	bl	0 <memset>
			8: R_ARM_THM_CALL	memset
   c:	2000      	movs	r0, #0
   e:	bd08      	pop	{r3, pc}
  10:	2005      	movs	r0, #5
  12:	4770      	bx	lr

Disassembly of section .text.NavigationEskfRecoveryQualifier_Receive:

00000000 <NavigationEskfRecoveryQualifier_Receive>:
   0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
   4:	ed2d 8b06 	vpush	{d8-d10}
   8:	b0a1      	sub	sp, #132	@ 0x84
   a:	469b      	mov	fp, r3
   c:	931a      	str	r3, [sp, #104]	@ 0x68
   e:	2301      	movs	r3, #1
  10:	f88d 304c 	strb.w	r3, [sp, #76]	@ 0x4c
  14:	f88d 307c 	strb.w	r3, [sp, #124]	@ 0x7c
  18:	9b32      	ldr	r3, [sp, #200]	@ 0xc8
  1a:	931d      	str	r3, [sp, #116]	@ 0x74
  1c:	23d8      	movs	r3, #216	@ 0xd8
  1e:	9312      	str	r3, [sp, #72]	@ 0x48
  20:	2320      	movs	r3, #32
  22:	9315      	str	r3, [sp, #84]	@ 0x54
  24:	23b0      	movs	r3, #176	@ 0xb0
  26:	9318      	str	r3, [sp, #96]	@ 0x60
  28:	230c      	movs	r3, #12
  2a:	f04f 0a00 	mov.w	sl, #0
  2e:	931b      	str	r3, [sp, #108]	@ 0x6c
  30:	f8dd 80c0 	ldr.w	r8, [sp, #192]	@ 0xc0
  34:	f8dd 90c4 	ldr.w	r9, [sp, #196]	@ 0xc4
  38:	9114      	str	r1, [sp, #80]	@ 0x50
  3a:	2310      	movs	r3, #16
  3c:	460e      	mov	r6, r1
  3e:	4604      	mov	r4, r0
  40:	4615      	mov	r5, r2
  42:	9011      	str	r0, [sp, #68]	@ 0x44
  44:	9217      	str	r2, [sp, #92]	@ 0x5c
  46:	f88d a058 	strb.w	sl, [sp, #88]	@ 0x58
  4a:	f88d a064 	strb.w	sl, [sp, #100]	@ 0x64
  4e:	f88d a070 	strb.w	sl, [sp, #112]	@ 0x70
  52:	931e      	str	r3, [sp, #120]	@ 0x78
  54:	af11      	add	r7, sp, #68	@ 0x44
  56:	4601      	mov	r1, r0
  58:	2900      	cmp	r1, #0
  5a:	d06e      	beq.n	13a <NavigationEskfRecoveryQualifier_Receive+0x13a>
  5c:	f1ba 0f00 	cmp.w	sl, #0
  60:	f000 81fb 	beq.w	45a <NavigationEskfRecoveryQualifier_Receive+0x45a>
  64:	aa11      	add	r2, sp, #68	@ 0x44
  66:	6813      	ldr	r3, [r2, #0]
  68:	4299      	cmp	r1, r3
  6a:	eba3 0001 	sub.w	r0, r3, r1
  6e:	eba1 0303 	sub.w	r3, r1, r3
  72:	d85c      	bhi.n	12e <NavigationEskfRecoveryQualifier_Receive+0x12e>
  74:	687b      	ldr	r3, [r7, #4]
  76:	4298      	cmp	r0, r3
  78:	bf2c      	ite	cs
  7a:	2300      	movcs	r3, #0
  7c:	2301      	movcc	r3, #1
  7e:	b12b      	cbz	r3, 8c <NavigationEskfRecoveryQualifier_Receive+0x8c>
  80:	7a3b      	ldrb	r3, [r7, #8]
  82:	2b00      	cmp	r3, #0
  84:	d159      	bne.n	13a <NavigationEskfRecoveryQualifier_Receive+0x13a>
  86:	7a13      	ldrb	r3, [r2, #8]
  88:	2b00      	cmp	r3, #0
  8a:	d156      	bne.n	13a <NavigationEskfRecoveryQualifier_Receive+0x13a>
  8c:	320c      	adds	r2, #12
  8e:	4297      	cmp	r7, r2
  90:	d1e9      	bne.n	66 <NavigationEskfRecoveryQualifier_Receive+0x66>
  92:	f10a 0a01 	add.w	sl, sl, #1
  96:	f1ba 0f05 	cmp.w	sl, #5
  9a:	d002      	beq.n	a2 <NavigationEskfRecoveryQualifier_Receive+0xa2>
  9c:	f857 1f0c 	ldr.w	r1, [r7, #12]!
  a0:	e7da      	b.n	58 <NavigationEskfRecoveryQualifier_Receive+0x58>
  a2:	4630      	mov	r0, r6
  a4:	f7ff fffe 	bl	0 <NavigationEskfRecoveryQualifier_Receive>
			a4: R_ARM_THM_CALL	NavigationEskfRecoveryQualifier_ConfigValidate
  a8:	4607      	mov	r7, r0
  aa:	2800      	cmp	r0, #0
  ac:	d145      	bne.n	13a <NavigationEskfRecoveryQualifier_Receive+0x13a>
  ae:	f894 30d3 	ldrb.w	r3, [r4, #211]	@ 0xd3
  b2:	2b01      	cmp	r3, #1
  b4:	d835      	bhi.n	122 <NavigationEskfRecoveryQualifier_Receive+0x122>
  b6:	f894 20d0 	ldrb.w	r2, [r4, #208]	@ 0xd0
  ba:	2a0f      	cmp	r2, #15
  bc:	d831      	bhi.n	122 <NavigationEskfRecoveryQualifier_Receive+0x122>
  be:	f894 20d1 	ldrb.w	r2, [r4, #209]	@ 0xd1
  c2:	2a0f      	cmp	r2, #15
  c4:	d82d      	bhi.n	122 <NavigationEskfRecoveryQualifier_Receive+0x122>
  c6:	f894 20d2 	ldrb.w	r2, [r4, #210]	@ 0xd2
  ca:	2a02      	cmp	r2, #2
  cc:	d829      	bhi.n	122 <NavigationEskfRecoveryQualifier_Receive+0x122>
  ce:	2b00      	cmp	r3, #0
  d0:	d05c      	beq.n	18c <NavigationEskfRecoveryQualifier_Receive+0x18c>
  d2:	f894 30a9 	ldrb.w	r3, [r4, #169]	@ 0xa9
  d6:	2b03      	cmp	r3, #3
  d8:	d823      	bhi.n	122 <NavigationEskfRecoveryQualifier_Receive+0x122>
  da:	6963      	ldr	r3, [r4, #20]
  dc:	b30b      	cbz	r3, 122 <NavigationEskfRecoveryQualifier_Receive+0x122>
  de:	e9d4 3202 	ldrd	r3, r2, [r4, #8]
  e2:	4313      	orrs	r3, r2
  e4:	d01d      	beq.n	122 <NavigationEskfRecoveryQualifier_Receive+0x122>
  e6:	4620      	mov	r0, r4
  e8:	f7ff fffe 	bl	0 <SystemGnssReceipt_ClockBasisGet>
			e8: R_ARM_THM_CALL	SystemGnssReceipt_ClockBasisGet
  ec:	f894 20d2 	ldrb.w	r2, [r4, #210]	@ 0xd2
  f0:	4290      	cmp	r0, r2
  f2:	4603      	mov	r3, r0
  f4:	d115      	bne.n	122 <NavigationEskfRecoveryQualifier_Receive+0x122>
  f6:	e9d4 a232 	ldrd	sl, r2, [r4, #200]	@ 0xc8
  fa:	2802      	cmp	r0, #2
  fc:	9200      	str	r2, [sp, #0]
  fe:	d022      	beq.n	146 <NavigationEskfRecoveryQualifier_Receive+0x146>
 100:	9a00      	ldr	r2, [sp, #0]
 102:	ea5a 0202 	orrs.w	r2, sl, r2
 106:	d10c      	bne.n	122 <NavigationEskfRecoveryQualifier_Receive+0x122>
 108:	2801      	cmp	r0, #1
 10a:	bf08      	it	eq
 10c:	e9d4 a300 	ldrdeq	sl, r3, [r4]
 110:	e9d4 1230 	ldrd	r1, r2, [r4, #192]	@ 0xc0
 114:	bf08      	it	eq
 116:	9300      	streq	r3, [sp, #0]
 118:	9b00      	ldr	r3, [sp, #0]
 11a:	429a      	cmp	r2, r3
 11c:	bf08      	it	eq
 11e:	4551      	cmpeq	r1, sl
 120:	d034      	beq.n	18c <NavigationEskfRecoveryQualifier_Receive+0x18c>
 122:	2006      	movs	r0, #6
 124:	b021      	add	sp, #132	@ 0x84
 126:	ecbd 8b06 	vpop	{d8-d10}
 12a:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 12e:	6850      	ldr	r0, [r2, #4]
 130:	4283      	cmp	r3, r0
 132:	bf2c      	ite	cs
 134:	2300      	movcs	r3, #0
 136:	2301      	movcc	r3, #1
 138:	e7a1      	b.n	7e <NavigationEskfRecoveryQualifier_Receive+0x7e>
 13a:	2005      	movs	r0, #5
 13c:	b021      	add	sp, #132	@ 0x84
 13e:	ecbd 8b06 	vpop	{d8-d10}
 142:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 146:	4611      	mov	r1, r2
 148:	4650      	mov	r0, sl
 14a:	4ac5      	ldr	r2, [pc, #788]	@ (460 <NavigationEskfRecoveryQualifier_Receive+0x460>)
 14c:	238c      	movs	r3, #140	@ 0x8c
 14e:	f7ff fffe 	bl	0 <__aeabi_uldivmod>
			14e: R_ARM_THM_CALL	__aeabi_uldivmod
 152:	431a      	orrs	r2, r3
 154:	d1e5      	bne.n	122 <NavigationEskfRecoveryQualifier_Receive+0x122>
 156:	f8d4 308c 	ldr.w	r3, [r4, #140]	@ 0x8c
 15a:	f44f 727a 	mov.w	r2, #1000	@ 0x3e8
 15e:	fba3 3202 	umull	r3, r2, r3, r2
 162:	eb13 000a 	adds.w	r0, r3, sl
 166:	9800      	ldr	r0, [sp, #0]
 168:	4150      	adcs	r0, r2
 16a:	f04f 0100 	mov.w	r1, #0
 16e:	bf28      	it	cs
 170:	2101      	movcs	r1, #1
 172:	2900      	cmp	r1, #0
 174:	d1d5      	bne.n	122 <NavigationEskfRecoveryQualifier_Receive+0x122>
 176:	9900      	ldr	r1, [sp, #0]
 178:	eb13 030a 	adds.w	r3, r3, sl
 17c:	eb42 0201 	adc.w	r2, r2, r1
 180:	e9d4 0130 	ldrd	r0, r1, [r4, #192]	@ 0xc0
 184:	4291      	cmp	r1, r2
 186:	bf08      	it	eq
 188:	4298      	cmpeq	r0, r3
 18a:	d1ca      	bne.n	122 <NavigationEskfRecoveryQualifier_Receive+0x122>
 18c:	f895 20a9 	ldrb.w	r2, [r5, #169]	@ 0xa9
 190:	2a03      	cmp	r2, #3
 192:	f200 8157 	bhi.w	444 <NavigationEskfRecoveryQualifier_Receive+0x444>
 196:	6968      	ldr	r0, [r5, #20]
 198:	2800      	cmp	r0, #0
 19a:	f000 8153 	beq.w	444 <NavigationEskfRecoveryQualifier_Receive+0x444>
 19e:	e9d5 3102 	ldrd	r3, r1, [r5, #8]
 1a2:	ea53 0c01 	orrs.w	ip, r3, r1
 1a6:	f000 814d 	beq.w	444 <NavigationEskfRecoveryQualifier_Receive+0x444>
 1aa:	4598      	cmp	r8, r3
 1ac:	eb79 0c01 	sbcs.w	ip, r9, r1
 1b0:	f0c0 8148 	bcc.w	444 <NavigationEskfRecoveryQualifier_Receive+0x444>
 1b4:	f8df e2b0 	ldr.w	lr, [pc, #688]	@ 468 <NavigationEskfRecoveryQualifier_Receive+0x468>
 1b8:	ebb8 0803 	subs.w	r8, r8, r3
 1bc:	eb69 0901 	sbc.w	r9, r9, r1
 1c0:	f04f 0c00 	mov.w	ip, #0
 1c4:	45c6      	cmp	lr, r8
 1c6:	eb7c 0c09 	sbcs.w	ip, ip, r9
 1ca:	f0c0 813b 	bcc.w	444 <NavigationEskfRecoveryQualifier_Receive+0x444>
 1ce:	f894 c0d3 	ldrb.w	ip, [r4, #211]	@ 0xd3
 1d2:	f1bc 0f00 	cmp.w	ip, #0
 1d6:	d004      	beq.n	1e2 <NavigationEskfRecoveryQualifier_Receive+0x1e2>
 1d8:	f894 c0a9 	ldrb.w	ip, [r4, #169]	@ 0xa9
 1dc:	4594      	cmp	ip, r2
 1de:	f000 829b 	beq.w	718 <NavigationEskfRecoveryQualifier_Receive+0x718>
 1e2:	4ba0      	ldr	r3, [pc, #640]	@ (464 <NavigationEskfRecoveryQualifier_Receive+0x464>)
 1e4:	f895 a039 	ldrb.w	sl, [r5, #57]	@ 0x39
 1e8:	cb0f      	ldmia	r3, {r0, r1, r2, r3}
 1ea:	f10d 0c34 	add.w	ip, sp, #52	@ 0x34
 1ee:	f1ba 0f0f 	cmp.w	sl, #15
 1f2:	e88c 000f 	stmia.w	ip, {r0, r1, r2, r3}
 1f6:	f200 80ad 	bhi.w	354 <NavigationEskfRecoveryQualifier_Receive+0x354>
 1fa:	f895 3076 	ldrb.w	r3, [r5, #118]	@ 0x76
 1fe:	2b01      	cmp	r3, #1
 200:	f040 80a8 	bne.w	354 <NavigationEskfRecoveryQualifier_Receive+0x354>
 204:	f895 0072 	ldrb.w	r0, [r5, #114]	@ 0x72
 208:	2801      	cmp	r0, #1
 20a:	f040 80a3 	bne.w	354 <NavigationEskfRecoveryQualifier_Receive+0x354>
 20e:	f895 2071 	ldrb.w	r2, [r5, #113]	@ 0x71
 212:	1e93      	subs	r3, r2, #2
 214:	2b02      	cmp	r3, #2
 216:	f200 809d 	bhi.w	354 <NavigationEskfRecoveryQualifier_Receive+0x354>
 21a:	e9d5 1306 	ldrd	r1, r3, [r5, #24]
 21e:	4019      	ands	r1, r3
 220:	f001 0303 	and.w	r3, r1, #3
 224:	2b03      	cmp	r3, #3
 226:	f040 8095 	bne.w	354 <NavigationEskfRecoveryQualifier_Receive+0x354>
 22a:	2300      	movs	r3, #0
 22c:	f85c eb04 	ldr.w	lr, [ip], #4
 230:	fa00 f803 	lsl.w	r8, r0, r3
 234:	ea3e 0e01 	bics.w	lr, lr, r1
 238:	f103 0301 	add.w	r3, r3, #1
 23c:	bf18      	it	ne
 23e:	ea2a 0a08 	bicne.w	sl, sl, r8
 242:	2b04      	cmp	r3, #4
 244:	d1f2      	bne.n	22c <NavigationEskfRecoveryQualifier_Receive+0x22c>
 246:	ed9b 7a00 	vldr	s14, [fp]
 24a:	eddf 7a8a 	vldr	s15, [pc, #552]	@ 474 <NavigationEskfRecoveryQualifier_Receive+0x474>
 24e:	eeb0 7ac7 	vabs.f32	s14, s14
 252:	eeb4 7a67 	vcmp.f32	s14, s15
 256:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 25a:	f200 82a5 	bhi.w	7a8 <NavigationEskfRecoveryQualifier_Receive+0x7a8>
 25e:	ed9b 7a01 	vldr	s14, [fp, #4]
 262:	eeb0 7ac7 	vabs.f32	s14, s14
 266:	eeb4 7a67 	vcmp.f32	s14, s15
 26a:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 26e:	f200 829b 	bhi.w	7a8 <NavigationEskfRecoveryQualifier_Receive+0x7a8>
 272:	ed95 7a19 	vldr	s14, [r5, #100]	@ 0x64
 276:	eef0 6ac7 	vabs.f32	s13, s14
 27a:	eef4 6a67 	vcmp.f32	s13, s15
 27e:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 282:	f200 8291 	bhi.w	7a8 <NavigationEskfRecoveryQualifier_Receive+0x7a8>
 286:	eeb5 7ac0 	vcmpe.f32	s14, #0.0
 28a:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 28e:	f240 828b 	bls.w	7a8 <NavigationEskfRecoveryQualifier_Receive+0x7a8>
 292:	eddb 7a02 	vldr	s15, [fp, #8]
 296:	ed9f 7a77 	vldr	s14, [pc, #476]	@ 474 <NavigationEskfRecoveryQualifier_Receive+0x474>
 29a:	eef0 7ae7 	vabs.f32	s15, s15
 29e:	eef4 7a47 	vcmp.f32	s15, s14
 2a2:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 2a6:	f200 8282 	bhi.w	7ae <NavigationEskfRecoveryQualifier_Receive+0x7ae>
 2aa:	edd5 7a1a 	vldr	s15, [r5, #104]	@ 0x68
 2ae:	eef0 6ae7 	vabs.f32	s13, s15
 2b2:	eef4 6a47 	vcmp.f32	s13, s14
 2b6:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 2ba:	f200 8278 	bhi.w	7ae <NavigationEskfRecoveryQualifier_Receive+0x7ae>
 2be:	eef5 7ac0 	vcmpe.f32	s15, #0.0
 2c2:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 2c6:	f240 8272 	bls.w	7ae <NavigationEskfRecoveryQualifier_Receive+0x7ae>
 2ca:	2a02      	cmp	r2, #2
 2cc:	f000 826f 	beq.w	7ae <NavigationEskfRecoveryQualifier_Receive+0x7ae>
 2d0:	edd5 7a1b 	vldr	s15, [r5, #108]	@ 0x6c
 2d4:	ed9f 7a67 	vldr	s14, [pc, #412]	@ 474 <NavigationEskfRecoveryQualifier_Receive+0x474>
 2d8:	eef0 6ae7 	vabs.f32	s13, s15
 2dc:	eef4 6a47 	vcmp.f32	s13, s14
 2e0:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 2e4:	f200 82b6 	bhi.w	854 <NavigationEskfRecoveryQualifier_Receive+0x854>
 2e8:	eef5 7ac0 	vcmpe.f32	s15, #0.0
 2ec:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 2f0:	f240 82b0 	bls.w	854 <NavigationEskfRecoveryQualifier_Receive+0x854>
 2f4:	edd5 7a13 	vldr	s15, [r5, #76]	@ 0x4c
 2f8:	ed9f 7a5e 	vldr	s14, [pc, #376]	@ 474 <NavigationEskfRecoveryQualifier_Receive+0x474>
 2fc:	eef0 7ae7 	vabs.f32	s15, s15
 300:	eef4 7a47 	vcmp.f32	s15, s14
 304:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 308:	d80e      	bhi.n	328 <NavigationEskfRecoveryQualifier_Receive+0x328>
 30a:	edd5 7a14 	vldr	s15, [r5, #80]	@ 0x50
 30e:	eef0 7ae7 	vabs.f32	s15, s15
 312:	eef4 7a47 	vcmp.f32	s15, s14
 316:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 31a:	d805      	bhi.n	328 <NavigationEskfRecoveryQualifier_Receive+0x328>
 31c:	f895 3070 	ldrb.w	r3, [r5, #112]	@ 0x70
 320:	f003 0303 	and.w	r3, r3, #3
 324:	2b03      	cmp	r3, #3
 326:	d001      	beq.n	32c <NavigationEskfRecoveryQualifier_Receive+0x32c>
 328:	f00a 0afb 	and.w	sl, sl, #251	@ 0xfb
 32c:	edd5 7a15 	vldr	s15, [r5, #84]	@ 0x54
 330:	ed9f 7a50 	vldr	s14, [pc, #320]	@ 474 <NavigationEskfRecoveryQualifier_Receive+0x474>
 334:	eef0 7ae7 	vabs.f32	s15, s15
 338:	eef4 7a47 	vcmp.f32	s15, s14
 33c:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 340:	d805      	bhi.n	34e <NavigationEskfRecoveryQualifier_Receive+0x34e>
 342:	f895 3070 	ldrb.w	r3, [r5, #112]	@ 0x70
 346:	075b      	lsls	r3, r3, #29
 348:	d501      	bpl.n	34e <NavigationEskfRecoveryQualifier_Receive+0x34e>
 34a:	2a02      	cmp	r2, #2
 34c:	d104      	bne.n	358 <NavigationEskfRecoveryQualifier_Receive+0x358>
 34e:	f00a 0af7 	and.w	sl, sl, #247	@ 0xf7
 352:	e001      	b.n	358 <NavigationEskfRecoveryQualifier_Receive+0x358>
 354:	f04f 0a00 	mov.w	sl, #0
 358:	4628      	mov	r0, r5
 35a:	f7ff fffe 	bl	0 <SystemGnssReceipt_ClockBasisGet>
			35a: R_ARM_THM_CALL	SystemGnssReceipt_ClockBasisGet
 35e:	2801      	cmp	r0, #1
 360:	f894 20d3 	ldrb.w	r2, [r4, #211]	@ 0xd3
 364:	9002      	str	r0, [sp, #8]
 366:	f000 81e4 	beq.w	732 <NavigationEskfRecoveryQualifier_Receive+0x732>
 36a:	9b02      	ldr	r3, [sp, #8]
 36c:	2b02      	cmp	r3, #2
 36e:	f040 8083 	bne.w	478 <NavigationEskfRecoveryQualifier_Receive+0x478>
 372:	f8d5 308c 	ldr.w	r3, [r5, #140]	@ 0x8c
 376:	2a00      	cmp	r2, #0
 378:	f000 81ee 	beq.w	758 <NavigationEskfRecoveryQualifier_Receive+0x758>
 37c:	f894 e0a9 	ldrb.w	lr, [r4, #169]	@ 0xa9
 380:	f895 90a9 	ldrb.w	r9, [r5, #169]	@ 0xa9
 384:	45ce      	cmp	lr, r9
 386:	f000 81f5 	beq.w	774 <NavigationEskfRecoveryQualifier_Receive+0x774>
 38a:	f44f 727a 	mov.w	r2, #1000	@ 0x3e8
 38e:	fba3 3202 	umull	r3, r2, r3, r2
 392:	e9cd 3203 	strd	r3, r2, [sp, #12]
 396:	2100      	movs	r1, #0
 398:	9100      	str	r1, [sp, #0]
 39a:	9101      	str	r1, [sp, #4]
 39c:	4689      	mov	r9, r1
 39e:	f049 0902 	orr.w	r9, r9, #2
 3a2:	f1ba 0f0f 	cmp.w	sl, #15
 3a6:	f000 81cf 	beq.w	748 <NavigationEskfRecoveryQualifier_Receive+0x748>
 3aa:	f049 0910 	orr.w	r9, r9, #16
 3ae:	4629      	mov	r1, r5
 3b0:	22b0      	movs	r2, #176	@ 0xb0
 3b2:	4620      	mov	r0, r4
 3b4:	f7ff fffe 	bl	0 <memcpy>
			3b4: R_ARM_THM_CALL	memcpy
 3b8:	f8db 2000 	ldr.w	r2, [fp]
 3bc:	f8db 3004 	ldr.w	r3, [fp, #4]
 3c0:	f8db 1008 	ldr.w	r1, [fp, #8]
 3c4:	f8c4 10b8 	str.w	r1, [r4, #184]	@ 0xb8
 3c8:	f8c4 20b0 	str.w	r2, [r4, #176]	@ 0xb0
 3cc:	f8c4 30b4 	str.w	r3, [r4, #180]	@ 0xb4
 3d0:	f884 a0d0 	strb.w	sl, [r4, #208]	@ 0xd0
 3d4:	f895 3038 	ldrb.w	r3, [r5, #56]	@ 0x38
 3d8:	9802      	ldr	r0, [sp, #8]
 3da:	9a00      	ldr	r2, [sp, #0]
 3dc:	f8c4 20c8 	str.w	r2, [r4, #200]	@ 0xc8
 3e0:	ea0a 0303 	and.w	r3, sl, r3
 3e4:	f003 030f 	and.w	r3, r3, #15
 3e8:	f884 30d1 	strb.w	r3, [r4, #209]	@ 0xd1
 3ec:	2300      	movs	r3, #0
 3ee:	f360 0307 	bfi	r3, r0, #0, #8
 3f2:	9a01      	ldr	r2, [sp, #4]
 3f4:	f8c4 20cc 	str.w	r2, [r4, #204]	@ 0xcc
 3f8:	2800      	cmp	r0, #0
 3fa:	f36a 230f 	bfi	r3, sl, #8, #8
 3fe:	bf14      	ite	ne
 400:	2201      	movne	r2, #1
 402:	2200      	moveq	r2, #0
 404:	f367 4317 	bfi	r3, r7, #16, #8
 408:	9903      	ldr	r1, [sp, #12]
 40a:	9d04      	ldr	r5, [sp, #16]
 40c:	f884 00d2 	strb.w	r0, [r4, #210]	@ 0xd2
 410:	f362 631f 	bfi	r3, r2, #24, #8
 414:	9a32      	ldr	r2, [sp, #200]	@ 0xc8
 416:	f8c4 10c0 	str.w	r1, [r4, #192]	@ 0xc0
 41a:	f04f 0001 	mov.w	r0, #1
 41e:	f8c4 50c4 	str.w	r5, [r4, #196]	@ 0xc4
 422:	f884 00d3 	strb.w	r0, [r4, #211]	@ 0xd3
 426:	e9c2 1500 	strd	r1, r5, [r2]
 42a:	60d3      	str	r3, [r2, #12]
 42c:	f8c2 9008 	str.w	r9, [r2, #8]
 430:	d011      	beq.n	456 <NavigationEskfRecoveryQualifier_Receive+0x456>
 432:	f019 0f02 	tst.w	r9, #2
 436:	f47f ae81 	bne.w	13c <NavigationEskfRecoveryQualifier_Receive+0x13c>
 43a:	fab7 f087 	clz	r0, r7
 43e:	0940      	lsrs	r0, r0, #5
 440:	0040      	lsls	r0, r0, #1
 442:	e67b      	b.n	13c <NavigationEskfRecoveryQualifier_Receive+0x13c>
 444:	9932      	ldr	r1, [sp, #200]	@ 0xc8
 446:	2200      	movs	r2, #0
 448:	2300      	movs	r3, #0
 44a:	e9c1 2300 	strd	r2, r3, [r1]
 44e:	2220      	movs	r2, #32
 450:	2300      	movs	r3, #0
 452:	608a      	str	r2, [r1, #8]
 454:	60cb      	str	r3, [r1, #12]
 456:	2002      	movs	r0, #2
 458:	e670      	b.n	13c <NavigationEskfRecoveryQualifier_Receive+0x13c>
 45a:	f04f 0a01 	mov.w	sl, #1
 45e:	e61d      	b.n	9c <NavigationEskfRecoveryQualifier_Receive+0x9c>
 460:	d0e3a000 	.word	0xd0e3a000
 464:	00000000 	.word	0x00000000
			464: R_ARM_ABS32	.rodata
 468:	0007a120 	.word	0x0007a120
 46c:	358637bd 	.word	0x358637bd
 470:	00000000 	.word	0x00000000
 474:	7f7fffff 	.word	0x7f7fffff
 478:	2300      	movs	r3, #0
 47a:	9303      	str	r3, [sp, #12]
 47c:	f04f 0901 	mov.w	r9, #1
 480:	9304      	str	r3, [sp, #16]
 482:	2a00      	cmp	r2, #0
 484:	f000 815c 	beq.w	740 <NavigationEskfRecoveryQualifier_Receive+0x740>
 488:	f895 20a9 	ldrb.w	r2, [r5, #169]	@ 0xa9
 48c:	f894 30a9 	ldrb.w	r3, [r4, #169]	@ 0xa9
 490:	429a      	cmp	r2, r3
 492:	f040 8155 	bne.w	740 <NavigationEskfRecoveryQualifier_Receive+0x740>
 496:	f894 30d2 	ldrb.w	r3, [r4, #210]	@ 0xd2
 49a:	9a02      	ldr	r2, [sp, #8]
 49c:	4293      	cmp	r3, r2
 49e:	f040 814f 	bne.w	740 <NavigationEskfRecoveryQualifier_Receive+0x740>
 4a2:	9b02      	ldr	r3, [sp, #8]
 4a4:	2b00      	cmp	r3, #0
 4a6:	f000 8185 	beq.w	7b4 <NavigationEskfRecoveryQualifier_Receive+0x7b4>
 4aa:	2300      	movs	r3, #0
 4ac:	e9cd 3300 	strd	r3, r3, [sp]
 4b0:	f8d4 30c0 	ldr.w	r3, [r4, #192]	@ 0xc0
 4b4:	9305      	str	r3, [sp, #20]
 4b6:	f8d4 30c4 	ldr.w	r3, [r4, #196]	@ 0xc4
 4ba:	9903      	ldr	r1, [sp, #12]
 4bc:	9a04      	ldr	r2, [sp, #16]
 4be:	4618      	mov	r0, r3
 4c0:	9b05      	ldr	r3, [sp, #20]
 4c2:	9006      	str	r0, [sp, #24]
 4c4:	428b      	cmp	r3, r1
 4c6:	4613      	mov	r3, r2
 4c8:	eb70 0303 	sbcs.w	r3, r0, r3
 4cc:	f080 81d3 	bcs.w	876 <NavigationEskfRecoveryQualifier_Receive+0x876>
 4d0:	6833      	ldr	r3, [r6, #0]
 4d2:	f8d6 e004 	ldr.w	lr, [r6, #4]
 4d6:	4618      	mov	r0, r3
 4d8:	9b05      	ldr	r3, [sp, #20]
 4da:	9008      	str	r0, [sp, #32]
 4dc:	1ac9      	subs	r1, r1, r3
 4de:	4613      	mov	r3, r2
 4e0:	9a06      	ldr	r2, [sp, #24]
 4e2:	9107      	str	r1, [sp, #28]
 4e4:	eb63 0c02 	sbc.w	ip, r3, r2
 4e8:	4288      	cmp	r0, r1
 4ea:	eb7e 030c 	sbcs.w	r3, lr, ip
 4ee:	f0c0 81bf 	bcc.w	870 <NavigationEskfRecoveryQualifier_Receive+0x870>
 4f2:	68a9      	ldr	r1, [r5, #8]
 4f4:	68a2      	ldr	r2, [r4, #8]
 4f6:	68e3      	ldr	r3, [r4, #12]
 4f8:	f8d5 800c 	ldr.w	r8, [r5, #12]
 4fc:	920a      	str	r2, [sp, #40]	@ 0x28
 4fe:	4618      	mov	r0, r3
 500:	930b      	str	r3, [sp, #44]	@ 0x2c
 502:	1a8b      	subs	r3, r1, r2
 504:	9a08      	ldr	r2, [sp, #32]
 506:	9109      	str	r1, [sp, #36]	@ 0x24
 508:	eb68 0100 	sbc.w	r1, r8, r0
 50c:	429a      	cmp	r2, r3
 50e:	eb7e 0e01 	sbcs.w	lr, lr, r1
 512:	f0c0 81ad 	bcc.w	870 <NavigationEskfRecoveryQualifier_Receive+0x870>
 516:	9a07      	ldr	r2, [sp, #28]
 518:	4293      	cmp	r3, r2
 51a:	eb71 0e0c 	sbcs.w	lr, r1, ip
 51e:	f080 819c 	bcs.w	85a <NavigationEskfRecoveryQualifier_Receive+0x85a>
 522:	e9dd 0109 	ldrd	r0, r1, [sp, #36]	@ 0x24
 526:	9b07      	ldr	r3, [sp, #28]
 528:	1a08      	subs	r0, r1, r0
 52a:	990b      	ldr	r1, [sp, #44]	@ 0x2c
 52c:	eb61 0208 	sbc.w	r2, r1, r8
 530:	18c0      	adds	r0, r0, r3
 532:	eb4c 0102 	adc.w	r1, ip, r2
 536:	e9d6 2302 	ldrd	r2, r3, [r6, #8]
 53a:	4282      	cmp	r2, r0
 53c:	eb73 0101 	sbcs.w	r1, r3, r1
 540:	f0c0 819c 	bcc.w	87c <NavigationEskfRecoveryQualifier_Receive+0x87c>
 544:	9807      	ldr	r0, [sp, #28]
 546:	ed5f 8a35 	vldr	s17, [pc, #-212]	@ 474 <NavigationEskfRecoveryQualifier_Receive+0x474>
 54a:	4661      	mov	r1, ip
 54c:	f7ff fffe 	bl	0 <__aeabi_ul2f>
			54c: R_ARM_THM_CALL	__aeabi_ul2f
 550:	f895 3038 	ldrb.w	r3, [r5, #56]	@ 0x38
 554:	f894 20d1 	ldrb.w	r2, [r4, #209]	@ 0xd1
 558:	ed5f 7a3c 	vldr	s15, [pc, #-240]	@ 46c <NavigationEskfRecoveryQualifier_Receive+0x46c>
 55c:	401a      	ands	r2, r3
 55e:	ea0a 0202 	and.w	r2, sl, r2
 562:	ee09 0a10 	vmov	s18, r0
 566:	9205      	str	r2, [sp, #20]
 568:	f10b 0208 	add.w	r2, fp, #8
 56c:	e9cd 2307 	strd	r2, r3, [sp, #28]
 570:	f04f 0e00 	mov.w	lr, #0
 574:	ee29 9a27 	vmul.f32	s18, s18, s15
 578:	46a8      	mov	r8, r5
 57a:	4677      	mov	r7, lr
 57c:	4625      	mov	r5, r4
 57e:	4674      	mov	r4, lr
 580:	9a05      	ldr	r2, [sp, #20]
 582:	2304      	movs	r3, #4
 584:	40bb      	lsls	r3, r7
 586:	4213      	tst	r3, r2
 588:	b2d8      	uxtb	r0, r3
 58a:	f000 80af 	beq.w	6ec <NavigationEskfRecoveryQualifier_Receive+0x6ec>
 58e:	ed96 8a04 	vldr	s16, [r6, #16]
 592:	edd6 7a05 	vldr	s15, [r6, #20]
 596:	2f00      	cmp	r7, #0
 598:	f000 80e9 	beq.w	76e <NavigationEskfRecoveryQualifier_Receive+0x76e>
 59c:	eeb0 8a67 	vmov.f32	s16, s15
 5a0:	2101      	movs	r1, #1
 5a2:	2202      	movs	r2, #2
 5a4:	ed95 aa1b 	vldr	s20, [r5, #108]	@ 0x6c
 5a8:	edd8 7a1b 	vldr	s15, [r8, #108]	@ 0x6c
 5ac:	edd6 aa06 	vldr	s21, [r6, #24]
 5b0:	ed5f 9a51 	vldr	s19, [pc, #-324]	@ 470 <NavigationEskfRecoveryQualifier_Receive+0x470>
 5b4:	ee67 7aa7 	vmul.f32	s15, s15, s15
 5b8:	ee2a aa0a 	vmul.f32	s20, s20, s20
 5bc:	f102 0313 	add.w	r3, r2, #19
 5c0:	ee3a aa27 	vadd.f32	s20, s20, s15
 5c4:	eb08 0e83 	add.w	lr, r8, r3, lsl #2
 5c8:	eeb1 7aca 	vsqrt.f32	s14, s20
 5cc:	eb05 0383 	add.w	r3, r5, r3, lsl #2
 5d0:	9306      	str	r3, [sp, #24]
 5d2:	9b07      	ldr	r3, [sp, #28]
 5d4:	eb0b 0c82 	add.w	ip, fp, r2, lsl #2
 5d8:	eb03 0282 	add.w	r2, r3, r2, lsl #2
 5dc:	9b06      	ldr	r3, [sp, #24]
 5de:	ee69 7a08 	vmul.f32	s15, s18, s16
 5e2:	ee2a 7a87 	vmul.f32	s14, s21, s14
 5e6:	eeb6 5a00 	vmov.f32	s10, #96	@ 0x3f000000  0.5
 5ea:	ee37 7a27 	vadd.f32	s14, s14, s15
 5ee:	eeb0 0a69 	vmov.f32	s0, s19
 5f2:	ecb3 6a01 	vldmia	r3!, {s12}
 5f6:	ecfe 4a01 	vldmia	lr!, {s9}
 5fa:	ecfc 7a01 	vldmia	ip!, {s15}
 5fe:	edd3 5a18 	vldr	s11, [r3, #96]	@ 0x60
 602:	ee74 6a86 	vadd.f32	s13, s9, s12
 606:	ee77 7ae5 	vsub.f32	s15, s15, s11
 60a:	ee66 6a85 	vmul.f32	s13, s13, s10
 60e:	ee34 6ac6 	vsub.f32	s12, s9, s12
 612:	ee66 6a89 	vmul.f32	s13, s13, s18
 616:	4594      	cmp	ip, r2
 618:	ee77 7ae6 	vsub.f32	s15, s15, s13
 61c:	ee66 6a06 	vmul.f32	s13, s12, s12
 620:	ee67 7aa7 	vmul.f32	s15, s15, s15
 624:	ee30 0a26 	vadd.f32	s0, s0, s13
 628:	ee79 9aa7 	vadd.f32	s19, s19, s15
 62c:	d170      	bne.n	710 <NavigationEskfRecoveryQualifier_Receive+0x710>
 62e:	eef0 7ac7 	vabs.f32	s15, s14
 632:	eef4 7a68 	vcmp.f32	s15, s17
 636:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 63a:	d857      	bhi.n	6ec <NavigationEskfRecoveryQualifier_Receive+0x6ec>
 63c:	eef0 7ac0 	vabs.f32	s15, s0
 640:	eef4 7a68 	vcmp.f32	s15, s17
 644:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 648:	d850      	bhi.n	6ec <NavigationEskfRecoveryQualifier_Receive+0x6ec>
 64a:	eeb5 0a40 	vcmp.f32	s0, #0.0
 64e:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 652:	f100 812b 	bmi.w	8ac <NavigationEskfRecoveryQualifier_Receive+0x8ac>
 656:	eef1 7ac0 	vsqrt.f32	s15, s0
 65a:	eeb4 7ae7 	vcmpe.f32	s14, s15
 65e:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 662:	d443      	bmi.n	6ec <NavigationEskfRecoveryQualifier_Receive+0x6ec>
 664:	edd8 6a19 	vldr	s13, [r8, #100]	@ 0x64
 668:	ed98 6a1a 	vldr	s12, [r8, #104]	@ 0x68
 66c:	edd5 7a19 	vldr	s15, [r5, #100]	@ 0x64
 670:	edd5 5a1a 	vldr	s11, [r5, #104]	@ 0x68
 674:	eeb5 7a00 	vmov.f32	s14, #80	@ 0x3e800000  0.250
 678:	2f00      	cmp	r7, #0
 67a:	ee29 7a07 	vmul.f32	s14, s18, s14
 67e:	bf18      	it	ne
 680:	eef0 7a65 	vmovne.f32	s15, s11
 684:	bf18      	it	ne
 686:	eef0 6a46 	vmovne.f32	s13, s12
 68a:	ee67 7aa7 	vmul.f32	s15, s15, s15
 68e:	ee66 6aa6 	vmul.f32	s13, s13, s13
 692:	ee27 7a09 	vmul.f32	s14, s14, s18
 696:	ee37 0aa6 	vadd.f32	s0, s15, s13
 69a:	ee67 7a0a 	vmul.f32	s15, s14, s20
 69e:	4304      	orrs	r4, r0
 6a0:	ee30 0a27 	vadd.f32	s0, s0, s15
 6a4:	eeb5 0a40 	vcmp.f32	s0, #0.0
 6a8:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 6ac:	f100 80eb 	bmi.w	886 <NavigationEskfRecoveryQualifier_Receive+0x886>
 6b0:	eef1 6ac0 	vsqrt.f32	s13, s0
 6b4:	eef6 7a00 	vmov.f32	s15, #96	@ 0x3f000000  0.5
 6b8:	ee68 7a27 	vmul.f32	s15, s16, s15
 6bc:	ee6a aaa6 	vmul.f32	s21, s21, s13
 6c0:	ee67 7a89 	vmul.f32	s15, s15, s18
 6c4:	ed1f 7a95 	vldr	s14, [pc, #-596]	@ 474 <NavigationEskfRecoveryQualifier_Receive+0x474>
 6c8:	ee67 7a89 	vmul.f32	s15, s15, s18
 6cc:	ee77 7aaa 	vadd.f32	s15, s15, s21
 6d0:	eef0 6ae7 	vabs.f32	s13, s15
 6d4:	eef4 6a47 	vcmp.f32	s13, s14
 6d8:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 6dc:	d806      	bhi.n	6ec <NavigationEskfRecoveryQualifier_Receive+0x6ec>
 6de:	eef0 6ae9 	vabs.f32	s13, s19
 6e2:	eef4 6a47 	vcmp.f32	s13, s14
 6e6:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 6ea:	d969      	bls.n	7c0 <NavigationEskfRecoveryQualifier_Receive+0x7c0>
 6ec:	1c7b      	adds	r3, r7, #1
 6ee:	2b02      	cmp	r3, #2
 6f0:	f04f 0701 	mov.w	r7, #1
 6f4:	f47f af44 	bne.w	580 <NavigationEskfRecoveryQualifier_Receive+0x580>
 6f8:	f1ba 0f0f 	cmp.w	sl, #15
 6fc:	46a6      	mov	lr, r4
 6fe:	9b08      	ldr	r3, [sp, #32]
 700:	462c      	mov	r4, r5
 702:	4645      	mov	r5, r8
 704:	f000 80c2 	beq.w	88c <NavigationEskfRecoveryQualifier_Receive+0x88c>
 708:	f049 0910 	orr.w	r9, r9, #16
 70c:	4677      	mov	r7, lr
 70e:	e64e      	b.n	3ae <NavigationEskfRecoveryQualifier_Receive+0x3ae>
 710:	2901      	cmp	r1, #1
 712:	f47f af6e 	bne.w	5f2 <NavigationEskfRecoveryQualifier_Receive+0x5f2>
 716:	e78a      	b.n	62e <NavigationEskfRecoveryQualifier_Receive+0x62e>
 718:	6962      	ldr	r2, [r4, #20]
 71a:	1a80      	subs	r0, r0, r2
 71c:	2800      	cmp	r0, #0
 71e:	d041      	beq.n	7a4 <NavigationEskfRecoveryQualifier_Receive+0x7a4>
 720:	db05      	blt.n	72e <NavigationEskfRecoveryQualifier_Receive+0x72e>
 722:	e9d4 0202 	ldrd	r0, r2, [r4, #8]
 726:	4298      	cmp	r0, r3
 728:	418a      	sbcs	r2, r1
 72a:	f4ff ad5a 	bcc.w	1e2 <NavigationEskfRecoveryQualifier_Receive+0x1e2>
 72e:	2004      	movs	r0, #4
 730:	e504      	b.n	13c <NavigationEskfRecoveryQualifier_Receive+0x13c>
 732:	682b      	ldr	r3, [r5, #0]
 734:	9303      	str	r3, [sp, #12]
 736:	686b      	ldr	r3, [r5, #4]
 738:	9304      	str	r3, [sp, #16]
 73a:	f04f 0900 	mov.w	r9, #0
 73e:	e6a0      	b.n	482 <NavigationEskfRecoveryQualifier_Receive+0x482>
 740:	2300      	movs	r3, #0
 742:	e9cd 3300 	strd	r3, r3, [sp]
 746:	e62a      	b.n	39e <NavigationEskfRecoveryQualifier_Receive+0x39e>
 748:	f895 3038 	ldrb.w	r3, [r5, #56]	@ 0x38
 74c:	f003 030f 	and.w	r3, r3, #15
 750:	2b0f      	cmp	r3, #15
 752:	f47f ae2a 	bne.w	3aa <NavigationEskfRecoveryQualifier_Receive+0x3aa>
 756:	e62a      	b.n	3ae <NavigationEskfRecoveryQualifier_Receive+0x3ae>
 758:	4616      	mov	r6, r2
 75a:	9200      	str	r2, [sp, #0]
 75c:	f44f 727a 	mov.w	r2, #1000	@ 0x3e8
 760:	fba3 1002 	umull	r1, r0, r3, r2
 764:	e9cd 1003 	strd	r1, r0, [sp, #12]
 768:	9601      	str	r6, [sp, #4]
 76a:	46b1      	mov	r9, r6
 76c:	e617      	b.n	39e <NavigationEskfRecoveryQualifier_Receive+0x39e>
 76e:	463a      	mov	r2, r7
 770:	2102      	movs	r1, #2
 772:	e717      	b.n	5a4 <NavigationEskfRecoveryQualifier_Receive+0x5a4>
 774:	f894 80d2 	ldrb.w	r8, [r4, #210]	@ 0xd2
 778:	f1b8 0f02 	cmp.w	r8, #2
 77c:	d034      	beq.n	7e8 <NavigationEskfRecoveryQualifier_Receive+0x7e8>
 77e:	f44f 727a 	mov.w	r2, #1000	@ 0x3e8
 782:	fba3 3202 	umull	r3, r2, r3, r2
 786:	e9cd 3203 	strd	r3, r2, [sp, #12]
 78a:	2300      	movs	r3, #0
 78c:	e9cd 3300 	strd	r3, r3, [sp]
 790:	45f1      	cmp	r9, lr
 792:	f04f 0900 	mov.w	r9, #0
 796:	f47f ae02 	bne.w	39e <NavigationEskfRecoveryQualifier_Receive+0x39e>
 79a:	f1b8 0f02 	cmp.w	r8, #2
 79e:	f47f adfe 	bne.w	39e <NavigationEskfRecoveryQualifier_Receive+0x39e>
 7a2:	e685      	b.n	4b0 <NavigationEskfRecoveryQualifier_Receive+0x4b0>
 7a4:	2003      	movs	r0, #3
 7a6:	e4c9      	b.n	13c <NavigationEskfRecoveryQualifier_Receive+0x13c>
 7a8:	f00a 0afe 	and.w	sl, sl, #254	@ 0xfe
 7ac:	e571      	b.n	292 <NavigationEskfRecoveryQualifier_Receive+0x292>
 7ae:	f00a 0afd 	and.w	sl, sl, #253	@ 0xfd
 7b2:	e58d      	b.n	2d0 <NavigationEskfRecoveryQualifier_Receive+0x2d0>
 7b4:	9b02      	ldr	r3, [sp, #8]
 7b6:	f04f 0901 	mov.w	r9, #1
 7ba:	e9cd 3300 	strd	r3, r3, [sp]
 7be:	e5f0      	b.n	3a2 <NavigationEskfRecoveryQualifier_Receive+0x3a2>
 7c0:	eef5 9a40 	vcmp.f32	s19, #0.0
 7c4:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 7c8:	d45b      	bmi.n	882 <NavigationEskfRecoveryQualifier_Receive+0x882>
 7ca:	eeb1 7ae9 	vsqrt.f32	s14, s19
 7ce:	eef4 7ac7 	vcmpe.f32	s15, s14
 7d2:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 7d6:	db89      	blt.n	6ec <NavigationEskfRecoveryQualifier_Receive+0x6ec>
 7d8:	9905      	ldr	r1, [sp, #20]
 7da:	2301      	movs	r3, #1
 7dc:	40bb      	lsls	r3, r7
 7de:	b2da      	uxtb	r2, r3
 7e0:	420b      	tst	r3, r1
 7e2:	bf18      	it	ne
 7e4:	4314      	orrne	r4, r2
 7e6:	e781      	b.n	6ec <NavigationEskfRecoveryQualifier_Receive+0x6ec>
 7e8:	f8d4 00c8 	ldr.w	r0, [r4, #200]	@ 0xc8
 7ec:	f8d4 208c 	ldr.w	r2, [r4, #140]	@ 0x8c
 7f0:	9000      	str	r0, [sp, #0]
 7f2:	f8d4 00cc 	ldr.w	r0, [r4, #204]	@ 0xcc
 7f6:	9001      	str	r0, [sp, #4]
 7f8:	429a      	cmp	r2, r3
 7fa:	4601      	mov	r1, r0
 7fc:	d911      	bls.n	822 <NavigationEskfRecoveryQualifier_Receive+0x822>
 7fe:	482f      	ldr	r0, [pc, #188]	@ (8bc <NavigationEskfRecoveryQualifier_Receive+0x8bc>)
 800:	1ad2      	subs	r2, r2, r3
 802:	4282      	cmp	r2, r0
 804:	d9bb      	bls.n	77e <NavigationEskfRecoveryQualifier_Receive+0x77e>
 806:	4a2e      	ldr	r2, [pc, #184]	@ (8c0 <NavigationEskfRecoveryQualifier_Receive+0x8c0>)
 808:	9800      	ldr	r0, [sp, #0]
 80a:	4290      	cmp	r0, r2
 80c:	460a      	mov	r2, r1
 80e:	f152 028c 	adcs.w	r2, r2, #140	@ 0x8c
 812:	f4bf ac86 	bcs.w	122 <NavigationEskfRecoveryQualifier_Receive+0x122>
 816:	4a2b      	ldr	r2, [pc, #172]	@ (8c4 <NavigationEskfRecoveryQualifier_Receive+0x8c4>)
 818:	1882      	adds	r2, r0, r2
 81a:	9200      	str	r2, [sp, #0]
 81c:	f141 028c 	adc.w	r2, r1, #140	@ 0x8c
 820:	9201      	str	r2, [sp, #4]
 822:	9900      	ldr	r1, [sp, #0]
 824:	f44f 727a 	mov.w	r2, #1000	@ 0x3e8
 828:	fba3 2302 	umull	r2, r3, r3, r2
 82c:	eb12 0c01 	adds.w	ip, r2, r1
 830:	9901      	ldr	r1, [sp, #4]
 832:	eb53 0c01 	adcs.w	ip, r3, r1
 836:	f04f 0000 	mov.w	r0, #0
 83a:	bf28      	it	cs
 83c:	2001      	movcs	r0, #1
 83e:	2800      	cmp	r0, #0
 840:	f47f ac6f 	bne.w	122 <NavigationEskfRecoveryQualifier_Receive+0x122>
 844:	9900      	ldr	r1, [sp, #0]
 846:	1852      	adds	r2, r2, r1
 848:	9203      	str	r2, [sp, #12]
 84a:	9a01      	ldr	r2, [sp, #4]
 84c:	eb42 0303 	adc.w	r3, r2, r3
 850:	9304      	str	r3, [sp, #16]
 852:	e79d      	b.n	790 <NavigationEskfRecoveryQualifier_Receive+0x790>
 854:	f00a 0af3 	and.w	sl, sl, #243	@ 0xf3
 858:	e54c      	b.n	2f4 <NavigationEskfRecoveryQualifier_Receive+0x2f4>
 85a:	9a05      	ldr	r2, [sp, #20]
 85c:	18d3      	adds	r3, r2, r3
 85e:	9a06      	ldr	r2, [sp, #24]
 860:	eb42 0101 	adc.w	r1, r2, r1
 864:	9a03      	ldr	r2, [sp, #12]
 866:	1a98      	subs	r0, r3, r2
 868:	9b04      	ldr	r3, [sp, #16]
 86a:	eb61 0103 	sbc.w	r1, r1, r3
 86e:	e662      	b.n	536 <NavigationEskfRecoveryQualifier_Receive+0x536>
 870:	f049 0904 	orr.w	r9, r9, #4
 874:	e595      	b.n	3a2 <NavigationEskfRecoveryQualifier_Receive+0x3a2>
 876:	f04f 0901 	mov.w	r9, #1
 87a:	e592      	b.n	3a2 <NavigationEskfRecoveryQualifier_Receive+0x3a2>
 87c:	f049 0908 	orr.w	r9, r9, #8
 880:	e58f      	b.n	3a2 <NavigationEskfRecoveryQualifier_Receive+0x3a2>
 882:	eeb0 0a69 	vmov.f32	s0, s19
 886:	f7ff fffe 	bl	0 <sqrtf>
			886: R_ARM_THM_CALL	sqrtf
 88a:	e72f      	b.n	6ec <NavigationEskfRecoveryQualifier_Receive+0x6ec>
 88c:	f003 030f 	and.w	r3, r3, #15
 890:	2b0f      	cmp	r3, #15
 892:	f47f af39 	bne.w	708 <NavigationEskfRecoveryQualifier_Receive+0x708>
 896:	f1be 0f0f 	cmp.w	lr, #15
 89a:	d00c      	beq.n	8b6 <NavigationEskfRecoveryQualifier_Receive+0x8b6>
 89c:	4677      	mov	r7, lr
 89e:	f1b9 0f00 	cmp.w	r9, #0
 8a2:	f47f ad84 	bne.w	3ae <NavigationEskfRecoveryQualifier_Receive+0x3ae>
 8a6:	f04f 0940 	mov.w	r9, #64	@ 0x40
 8aa:	e580      	b.n	3ae <NavigationEskfRecoveryQualifier_Receive+0x3ae>
 8ac:	9006      	str	r0, [sp, #24]
 8ae:	f7ff fffe 	bl	0 <sqrtf>
			8ae: R_ARM_THM_CALL	sqrtf
 8b2:	9806      	ldr	r0, [sp, #24]
 8b4:	e6d6      	b.n	664 <NavigationEskfRecoveryQualifier_Receive+0x664>
 8b6:	4657      	mov	r7, sl
 8b8:	e579      	b.n	3ae <NavigationEskfRecoveryQualifier_Receive+0x3ae>
 8ba:	bf00      	nop
 8bc:	12064200 	.word	0x12064200
 8c0:	2f1c6000 	.word	0x2f1c6000
 8c4:	d0e3a000 	.word	0xd0e3a000
