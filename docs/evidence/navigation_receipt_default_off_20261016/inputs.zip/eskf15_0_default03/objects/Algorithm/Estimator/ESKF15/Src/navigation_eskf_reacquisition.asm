
D:\python_software\SilverStar\.work\dev013_navclosure02\eskf15_0_default03\build\FCCG\SilverStar_F407\Release\auto\Algorithm\Estimator\ESKF15\Src\navigation_eskf_reacquisition.o:     file format elf32-littlearm


Disassembly of section .text.NavigationEskfReacquisition_Reset:

00000000 <NavigationEskfReacquisition_Reset>:
   0:	4770      	bx	lr
   2:	bf00      	nop

Disassembly of section .text.NavigationEskfReacquisition_FaultedGet:

00000000 <NavigationEskfReacquisition_FaultedGet>:
   0:	2000      	movs	r0, #0
   2:	4770      	bx	lr

Disassembly of section .text.NavigationEskfReacquisition_FaultMark:

00000000 <NavigationEskfReacquisition_FaultMark>:
   0:	4770      	bx	lr
   2:	bf00      	nop

Disassembly of section .text.NavigationEskfReacquisition_Initialize:

00000000 <NavigationEskfReacquisition_Initialize>:
   0:	2001      	movs	r0, #1
   2:	4770      	bx	lr

Disassembly of section .text.NavigationEskfReacquisition_EpochStart:

00000000 <NavigationEskfReacquisition_EpochStart>:
   0:	2001      	movs	r0, #1
   2:	4770      	bx	lr

Disassembly of section .text.NavigationEskfReacquisition_SourceSelect:

00000000 <NavigationEskfReacquisition_SourceSelect>:
   0:	2001      	movs	r0, #1
   2:	4770      	bx	lr

Disassembly of section .text.NavigationEskfReacquisition_Receive:

00000000 <NavigationEskfReacquisition_Receive>:
   0:	2001      	movs	r0, #1
   2:	4770      	bx	lr

Disassembly of section .text.NavigationEskfReacquisition_Tick:

00000000 <NavigationEskfReacquisition_Tick>:
   0:	2001      	movs	r0, #1
   2:	4770      	bx	lr

Disassembly of section .text.NavigationEskfReacquisition_ReceiptGet:

00000000 <NavigationEskfReacquisition_ReceiptGet>:
   0:	2000      	movs	r0, #0
   2:	4770      	bx	lr

Disassembly of section .text.NavigationEskfReacquisition_ReceiveStateGet:

00000000 <NavigationEskfReacquisition_ReceiveStateGet>:
   0:	2000      	movs	r0, #0
   2:	4770      	bx	lr

Disassembly of section .text.NavigationEskfReacquisition_PolicyGet:

00000000 <NavigationEskfReacquisition_PolicyGet>:
   0:	2000      	movs	r0, #0
   2:	4770      	bx	lr

Disassembly of section .text.NavigationEskfReacquisition_ReplayPredict:

00000000 <NavigationEskfReacquisition_ReplayPredict>:
   0:	f7ff bffe 	b.w	0 <NavigationEskfReplay_Predict>
			0: R_ARM_THM_JUMP24	NavigationEskfReplay_Predict

Disassembly of section .text.NavigationEskfReacquisition_ReplayInsert:

00000000 <NavigationEskfReacquisition_ReplayInsert>:
   0:	b470      	push	{r4, r5, r6}
   2:	e9dd 4603 	ldrd	r4, r6, [sp, #12]
   6:	9d05      	ldr	r5, [sp, #20]
   8:	b13c      	cbz	r4, 1a <NavigationEskfReacquisition_ReplayInsert+0x1a>
   a:	b135      	cbz	r5, 1a <NavigationEskfReacquisition_ReplayInsert+0x1a>
   c:	e9cd 4603 	strd	r4, r6, [sp, #12]
  10:	2400      	movs	r4, #0
  12:	702c      	strb	r4, [r5, #0]
  14:	bc70      	pop	{r4, r5, r6}
  16:	f7ff bffe 	b.w	0 <NavigationEskfReplay_Insert>
			16: R_ARM_THM_JUMP24	NavigationEskfReplay_Insert
  1a:	2001      	movs	r0, #1
  1c:	bc70      	pop	{r4, r5, r6}
  1e:	4770      	bx	lr

Disassembly of section .text.NavigationEskfReacquisition_CurrentUpdate:

00000000 <NavigationEskfReacquisition_CurrentUpdate>:
   0:	b430      	push	{r4, r5}
   2:	e9dd 4502 	ldrd	r4, r5, [sp, #8]
   6:	b143      	cbz	r3, 1a <NavigationEskfReacquisition_CurrentUpdate+0x1a>
   8:	b13c      	cbz	r4, 1a <NavigationEskfReacquisition_CurrentUpdate+0x1a>
   a:	b135      	cbz	r5, 1a <NavigationEskfReacquisition_CurrentUpdate+0x1a>
   c:	9402      	str	r4, [sp, #8]
   e:	2400      	movs	r4, #0
  10:	702c      	strb	r4, [r5, #0]
  12:	bc30      	pop	{r4, r5}
  14:	331c      	adds	r3, #28
  16:	f7ff bffe 	b.w	0 <NavigationEskf_Update>
			16: R_ARM_THM_JUMP24	NavigationEskf_Update
  1a:	2003      	movs	r0, #3
  1c:	bc30      	pop	{r4, r5}
  1e:	4770      	bx	lr

Disassembly of section .text.NavigationEskfReacquisition_HorizonInsert:

00000000 <NavigationEskfReacquisition_HorizonInsert>:
   0:	f7ff bffe 	b.w	0 <NavigationEskfHorizon_Insert>
			0: R_ARM_THM_JUMP24	NavigationEskfHorizon_Insert

Disassembly of section .text.NavigationEskfReacquisition_HorizonAdvance:

00000000 <NavigationEskfReacquisition_HorizonAdvance>:
   0:	f7ff bffe 	b.w	0 <NavigationEskfHorizon_Advance>
			0: R_ARM_THM_JUMP24	NavigationEskfHorizon_Advance

Disassembly of section .text.NavigationEskfReacquisition_HorizonPop:

00000000 <NavigationEskfReacquisition_HorizonPop>:
   0:	b11a      	cbz	r2, a <NavigationEskfReacquisition_HorizonPop+0xa>
   2:	2300      	movs	r3, #0
   4:	7013      	strb	r3, [r2, #0]
   6:	f7ff bffe 	b.w	0 <NavigationEskfHorizon_CompletionPop>
			6: R_ARM_THM_JUMP24	NavigationEskfHorizon_CompletionPop
   a:	2003      	movs	r0, #3
   c:	4770      	bx	lr
   e:	bf00      	nop
