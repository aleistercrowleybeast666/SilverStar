
D:\python_software\SilverStar\.work\dev013_navclosure02\eskf15_0_default03\build\FCCG\SilverStar_F407\Release\auto\System\Src\system_source_selector.o:     file format elf32-littlearm


Disassembly of section .text.SystemSourceSelector_GnssSelectionPublish:

00000000 <SystemSourceSelector_GnssSelectionPublish>:
   0:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
   4:	b082      	sub	sp, #8
   6:	4605      	mov	r5, r0
   8:	460e      	mov	r6, r1
   a:	4690      	mov	r8, r2
   c:	f7ff fffe 	bl	0 <PlatformCritical_Enter>
			c: R_ARM_THM_CALL	PlatformCritical_Enter
  10:	4c20      	ldr	r4, [pc, #128]	@ (94 <SystemSourceSelector_GnssSelectionPublish+0x94>)
  12:	4a21      	ldr	r2, [pc, #132]	@ (98 <SystemSourceSelector_GnssSelectionPublish+0x98>)
  14:	4607      	mov	r7, r0
  16:	7c20      	ldrb	r0, [r4, #16]
  18:	230a      	movs	r3, #10
  1a:	2804      	cmp	r0, #4
  1c:	bf8c      	ite	hi
  1e:	2000      	movhi	r0, #0
  20:	2001      	movls	r0, #1
  22:	9300      	str	r3, [sp, #0]
  24:	210c      	movs	r1, #12
  26:	f240 3375 	movw	r3, #885	@ 0x375
  2a:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			2a: R_ARM_THM_CALL	SilverStarAssert_Check
  2e:	7c23      	ldrb	r3, [r4, #16]
  30:	42ab      	cmp	r3, r5
  32:	d923      	bls.n	7c <SystemSourceSelector_GnssSelectionPublish+0x7c>
  34:	42b3      	cmp	r3, r6
  36:	bf94      	ite	ls
  38:	2000      	movls	r0, #0
  3a:	2001      	movhi	r0, #1
  3c:	2303      	movs	r3, #3
  3e:	4a16      	ldr	r2, [pc, #88]	@ (98 <SystemSourceSelector_GnssSelectionPublish+0x98>)
  40:	9300      	str	r3, [sp, #0]
  42:	210c      	movs	r1, #12
  44:	f240 3377 	movw	r3, #887	@ 0x377
  48:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			48: R_ARM_THM_CALL	SilverStarAssert_Check
  4c:	5da0      	ldrb	r0, [r4, r6]
  4e:	4a12      	ldr	r2, [pc, #72]	@ (98 <SystemSourceSelector_GnssSelectionPublish+0x98>)
  50:	1b40      	subs	r0, r0, r5
  52:	2305      	movs	r3, #5
  54:	fab0 f080 	clz	r0, r0
  58:	9300      	str	r3, [sp, #0]
  5a:	0940      	lsrs	r0, r0, #5
  5c:	f240 3379 	movw	r3, #889	@ 0x379
  60:	210c      	movs	r1, #12
  62:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			62: R_ARM_THM_CALL	SilverStarAssert_Check
  66:	74a5      	strb	r5, [r4, #18]
  68:	74e6      	strb	r6, [r4, #19]
  6a:	f1b8 0f00 	cmp.w	r8, #0
  6e:	d107      	bne.n	80 <SystemSourceSelector_GnssSelectionPublish+0x80>
  70:	4638      	mov	r0, r7
  72:	b002      	add	sp, #8
  74:	e8bd 41f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, lr}
  78:	f7ff bffe 	b.w	0 <PlatformCritical_Exit>
			78: R_ARM_THM_JUMP24	PlatformCritical_Exit
  7c:	2000      	movs	r0, #0
  7e:	e7dd      	b.n	3c <SystemSourceSelector_GnssSelectionPublish+0x3c>
  80:	f7ff fffe 	bl	0 <SystemTime_GetMonotonicUs>
			80: R_ARM_THM_CALL	SystemTime_GetMonotonicUs
  84:	e9c4 010c 	strd	r0, r1, [r4, #48]	@ 0x30
  88:	4638      	mov	r0, r7
  8a:	b002      	add	sp, #8
  8c:	e8bd 41f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, lr}
  90:	f7ff bffe 	b.w	0 <PlatformCritical_Exit>
			90: R_ARM_THM_JUMP24	PlatformCritical_Exit
	...
			94: R_ARM_ABS32	.bss.s_gnss
			98: R_ARM_ABS32	.rodata.SystemSourceSelector_GnssSelectionPublish.str1.4

Disassembly of section .text.SystemSourceSelector_EventWrite:

00000000 <SystemSourceSelector_EventWrite>:
   0:	b510      	push	{r4, lr}
   2:	7841      	ldrb	r1, [r0, #1]
   4:	b090      	sub	sp, #64	@ 0x40
   6:	2300      	movs	r3, #0
   8:	29ff      	cmp	r1, #255	@ 0xff
   a:	e9cd 3302 	strd	r3, r3, [sp, #8]
   e:	e9cd 3304 	strd	r3, r3, [sp, #16]
  12:	e9cd 3306 	strd	r3, r3, [sp, #24]
  16:	e9cd 3308 	strd	r3, r3, [sp, #32]
  1a:	e9cd 330a 	strd	r3, r3, [sp, #40]	@ 0x28
  1e:	e9cd 330c 	strd	r3, r3, [sp, #48]	@ 0x30
  22:	e9cd 330e 	strd	r3, r3, [sp, #56]	@ 0x38
  26:	4604      	mov	r4, r0
  28:	d116      	bne.n	58 <SystemSourceSelector_EventWrite+0x58>
  2a:	78a1      	ldrb	r1, [r4, #2]
  2c:	29ff      	cmp	r1, #255	@ 0xff
  2e:	d004      	beq.n	3a <SystemSourceSelector_EventWrite+0x3a>
  30:	7820      	ldrb	r0, [r4, #0]
  32:	aa09      	add	r2, sp, #36	@ 0x24
  34:	f7ff fffe 	bl	0 <ProjectDeviceInstance_DescriptorGet>
			34: R_ARM_THM_CALL	ProjectDeviceInstance_DescriptorGet
  38:	b9a0      	cbnz	r0, 64 <SystemSourceSelector_EventWrite+0x64>
  3a:	f7ff fffe 	bl	0 <SystemTime_GetMonotonicUs>
			3a: R_ARM_THM_CALL	SystemTime_GetMonotonicUs
  3e:	f8bd c024 	ldrh.w	ip, [sp, #36]	@ 0x24
  42:	f8bd 2008 	ldrh.w	r2, [sp, #8]
  46:	6823      	ldr	r3, [r4, #0]
  48:	ea42 420c 	orr.w	r2, r2, ip, lsl #16
  4c:	9200      	str	r2, [sp, #0]
  4e:	222d      	movs	r2, #45	@ 0x2d
  50:	f7ff fffe 	bl	0 <LoggerBus_EventPush>
			50: R_ARM_THM_CALL	LoggerBus_EventPush
  54:	b010      	add	sp, #64	@ 0x40
  56:	bd10      	pop	{r4, pc}
  58:	7800      	ldrb	r0, [r0, #0]
  5a:	aa02      	add	r2, sp, #8
  5c:	f7ff fffe 	bl	0 <ProjectDeviceInstance_DescriptorGet>
			5c: R_ARM_THM_CALL	ProjectDeviceInstance_DescriptorGet
  60:	2800      	cmp	r0, #0
  62:	d0e2      	beq.n	2a <SystemSourceSelector_EventWrite+0x2a>
  64:	2003      	movs	r0, #3
  66:	b010      	add	sp, #64	@ 0x40
  68:	bd10      	pop	{r4, pc}
  6a:	bf00      	nop

Disassembly of section .text.SystemSourceSelector_EventRecord:

00000000 <SystemSourceSelector_EventRecord>:
   0:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
   4:	b084      	sub	sp, #16
   6:	f04f 0802 	mov.w	r8, #2
   a:	460e      	mov	r6, r1
   c:	4614      	mov	r4, r2
   e:	210c      	movs	r1, #12
  10:	4a1d      	ldr	r2, [pc, #116]	@ (88 <SystemSourceSelector_EventRecord+0x88>)
  12:	f8cd 8000 	str.w	r8, [sp]
  16:	4607      	mov	r7, r0
  18:	461d      	mov	r5, r3
  1a:	2001      	movs	r0, #1
  1c:	23dd      	movs	r3, #221	@ 0xdd
  1e:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			1e: R_ARM_THM_CALL	SilverStarAssert_Check
  22:	4a19      	ldr	r2, [pc, #100]	@ (88 <SystemSourceSelector_EventRecord+0x88>)
  24:	f8cd 8000 	str.w	r8, [sp]
  28:	23e1      	movs	r3, #225	@ 0xe1
  2a:	210c      	movs	r1, #12
  2c:	2001      	movs	r0, #1
  2e:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			2e: R_ARM_THM_CALL	SilverStarAssert_Check
  32:	42a6      	cmp	r6, r4
  34:	d104      	bne.n	40 <SystemSourceSelector_EventRecord+0x40>
  36:	2d03      	cmp	r5, #3
  38:	d002      	beq.n	40 <SystemSourceSelector_EventRecord+0x40>
  3a:	b004      	add	sp, #16
  3c:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
  40:	2200      	movs	r2, #0
  42:	f367 0207 	bfi	r2, r7, #0, #8
  46:	f366 220f 	bfi	r2, r6, #8, #8
  4a:	f364 4217 	bfi	r2, r4, #16, #8
  4e:	f365 621f 	bfi	r2, r5, #24, #8
  52:	a803      	add	r0, sp, #12
  54:	9203      	str	r2, [sp, #12]
  56:	f7ff fffe 	bl	0 <SystemSourceSelector_EventRecord>
			56: R_ARM_THM_CALL	SystemSourceSelector_EventWrite
  5a:	2800      	cmp	r0, #0
  5c:	d0ed      	beq.n	3a <SystemSourceSelector_EventRecord+0x3a>
  5e:	f7ff fffe 	bl	0 <PlatformCritical_Enter>
			5e: R_ARM_THM_CALL	PlatformCritical_Enter
  62:	490a      	ldr	r1, [pc, #40]	@ (8c <SystemSourceSelector_EventRecord+0x8c>)
  64:	780b      	ldrb	r3, [r1, #0]
  66:	2b03      	cmp	r3, #3
  68:	d809      	bhi.n	7e <SystemSourceSelector_EventRecord+0x7e>
  6a:	4a09      	ldr	r2, [pc, #36]	@ (90 <SystemSourceSelector_EventRecord+0x90>)
  6c:	f802 7023 	strb.w	r7, [r2, r3, lsl #2]
  70:	eb02 0283 	add.w	r2, r2, r3, lsl #2
  74:	3301      	adds	r3, #1
  76:	7056      	strb	r6, [r2, #1]
  78:	7094      	strb	r4, [r2, #2]
  7a:	70d5      	strb	r5, [r2, #3]
  7c:	700b      	strb	r3, [r1, #0]
  7e:	b004      	add	sp, #16
  80:	e8bd 41f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, lr}
  84:	f7ff bffe 	b.w	0 <PlatformCritical_Exit>
			84: R_ARM_THM_JUMP24	PlatformCritical_Exit
	...
			88: R_ARM_ABS32	.rodata.SystemSourceSelector_GnssSelectionPublish.str1.4
			8c: R_ARM_ABS32	.bss.s_pending_event_count
			90: R_ARM_ABS32	.bss.s_pending_events

Disassembly of section .text.SystemSourceSelector_ImuFreshSelect:

00000000 <SystemSourceSelector_ImuFreshSelect>:
   0:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
   4:	4d52      	ldr	r5, [pc, #328]	@ (150 <SystemSourceSelector_ImuFreshSelect+0x150>)
   6:	4a53      	ldr	r2, [pc, #332]	@ (154 <SystemSourceSelector_ImuFreshSelect+0x154>)
   8:	7b28      	ldrb	r0, [r5, #12]
   a:	b0a0      	sub	sp, #128	@ 0x80
   c:	2804      	cmp	r0, #4
   e:	f04f 0304 	mov.w	r3, #4
  12:	bf8c      	ite	hi
  14:	2000      	movhi	r0, #0
  16:	2001      	movls	r0, #1
  18:	9300      	str	r3, [sp, #0]
  1a:	210c      	movs	r1, #12
  1c:	f44f 73ce 	mov.w	r3, #412	@ 0x19c
  20:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			20: R_ARM_THM_CALL	SilverStarAssert_Check
  24:	7c28      	ldrb	r0, [r5, #16]
  26:	4a4b      	ldr	r2, [pc, #300]	@ (154 <SystemSourceSelector_ImuFreshSelect+0x154>)
  28:	2801      	cmp	r0, #1
  2a:	f04f 0305 	mov.w	r3, #5
  2e:	9300      	str	r3, [sp, #0]
  30:	f04f 010c 	mov.w	r1, #12
  34:	f240 139f 	movw	r3, #415	@ 0x19f
  38:	bf8c      	ite	hi
  3a:	2000      	movhi	r0, #0
  3c:	2001      	movls	r0, #1
  3e:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			3e: R_ARM_THM_CALL	SilverStarAssert_Check
  42:	2400      	movs	r4, #0
  44:	462f      	mov	r7, r5
  46:	7b28      	ldrb	r0, [r5, #12]
  48:	fa5f f884 	uxtb.w	r8, r4
  4c:	4540      	cmp	r0, r8
  4e:	d909      	bls.n	64 <SystemSourceSelector_ImuFreshSelect+0x64>
  50:	f817 6b01 	ldrb.w	r6, [r7], #1
  54:	19ab      	adds	r3, r5, r6
  56:	791a      	ldrb	r2, [r3, #4]
  58:	b10a      	cbz	r2, 5e <SystemSourceSelector_ImuFreshSelect+0x5e>
  5a:	7a1b      	ldrb	r3, [r3, #8]
  5c:	b93b      	cbnz	r3, 6e <SystemSourceSelector_ImuFreshSelect+0x6e>
  5e:	3401      	adds	r4, #1
  60:	2c04      	cmp	r4, #4
  62:	d1f0      	bne.n	46 <SystemSourceSelector_ImuFreshSelect+0x46>
  64:	26ff      	movs	r6, #255	@ 0xff
  66:	4630      	mov	r0, r6
  68:	b020      	add	sp, #128	@ 0x80
  6a:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
  6e:	42b0      	cmp	r0, r6
  70:	f04f 0303 	mov.w	r3, #3
  74:	bf94      	ite	ls
  76:	2000      	movls	r0, #0
  78:	2001      	movhi	r0, #1
  7a:	4a36      	ldr	r2, [pc, #216]	@ (154 <SystemSourceSelector_ImuFreshSelect+0x154>)
  7c:	9300      	str	r3, [sp, #0]
  7e:	210c      	movs	r1, #12
  80:	f240 1371 	movw	r3, #369	@ 0x171
  84:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			84: R_ARM_THM_CALL	SilverStarAssert_Check
  88:	2304      	movs	r3, #4
  8a:	9300      	str	r3, [sp, #0]
  8c:	7b28      	ldrb	r0, [r5, #12]
  8e:	4a31      	ldr	r2, [pc, #196]	@ (154 <SystemSourceSelector_ImuFreshSelect+0x154>)
  90:	4298      	cmp	r0, r3
  92:	bf8c      	ite	hi
  94:	2000      	movhi	r0, #0
  96:	2001      	movls	r0, #1
  98:	f44f 73ba 	mov.w	r3, #372	@ 0x174
  9c:	210c      	movs	r1, #12
  9e:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			9e: R_ARM_THM_CALL	SilverStarAssert_Check
  a2:	2228      	movs	r2, #40	@ 0x28
  a4:	2100      	movs	r1, #0
  a6:	a802      	add	r0, sp, #8
  a8:	f7ff fffe 	bl	0 <memset>
			a8: R_ARM_THM_CALL	memset
  ac:	2100      	movs	r1, #0
  ae:	2250      	movs	r2, #80	@ 0x50
  b0:	a80c      	add	r0, sp, #48	@ 0x30
  b2:	f7ff fffe 	bl	0 <memset>
			b2: R_ARM_THM_CALL	memset
  b6:	a902      	add	r1, sp, #8
  b8:	4630      	mov	r0, r6
  ba:	f7ff fffe 	bl	0 <ProjectImuInstance_HealthGet>
			ba: R_ARM_THM_CALL	ProjectImuInstance_HealthGet
  be:	2800      	cmp	r0, #0
  c0:	d1cd      	bne.n	5e <SystemSourceSelector_ImuFreshSelect+0x5e>
  c2:	f89d 302c 	ldrb.w	r3, [sp, #44]	@ 0x2c
  c6:	2b00      	cmp	r3, #0
  c8:	d0c9      	beq.n	5e <SystemSourceSelector_ImuFreshSelect+0x5e>
  ca:	f89d 302d 	ldrb.w	r3, [sp, #45]	@ 0x2d
  ce:	2b00      	cmp	r3, #0
  d0:	d0c5      	beq.n	5e <SystemSourceSelector_ImuFreshSelect+0x5e>
  d2:	f89d 302e 	ldrb.w	r3, [sp, #46]	@ 0x2e
  d6:	2b00      	cmp	r3, #0
  d8:	d0c1      	beq.n	5e <SystemSourceSelector_ImuFreshSelect+0x5e>
  da:	a90c      	add	r1, sp, #48	@ 0x30
  dc:	4630      	mov	r0, r6
  de:	f7ff fffe 	bl	0 <ProjectImuInstance_LatestSampleGet>
			de: R_ARM_THM_CALL	ProjectImuInstance_LatestSampleGet
  e2:	2800      	cmp	r0, #0
  e4:	d1bb      	bne.n	5e <SystemSourceSelector_ImuFreshSelect+0x5e>
  e6:	9b1e      	ldr	r3, [sp, #120]	@ 0x78
  e8:	f003 0303 	and.w	r3, r3, #3
  ec:	2b03      	cmp	r3, #3
  ee:	d1b6      	bne.n	5e <SystemSourceSelector_ImuFreshSelect+0x5e>
  f0:	f7ff fffe 	bl	0 <SystemTime_GetMonotonicUs>
			f0: R_ARM_THM_CALL	SystemTime_GetMonotonicUs
  f4:	e9dd 320e 	ldrd	r3, r2, [sp, #56]	@ 0x38
  f8:	ea53 0c02 	orrs.w	ip, r3, r2
  fc:	d0af      	beq.n	5e <SystemSourceSelector_ImuFreshSelect+0x5e>
  fe:	4298      	cmp	r0, r3
 100:	eb71 0c02 	sbcs.w	ip, r1, r2
 104:	d3ab      	bcc.n	5e <SystemSourceSelector_ImuFreshSelect+0x5e>
 106:	1ac0      	subs	r0, r0, r3
 108:	eb61 0102 	sbc.w	r1, r1, r2
 10c:	4a12      	ldr	r2, [pc, #72]	@ (158 <SystemSourceSelector_ImuFreshSelect+0x158>)
 10e:	2300      	movs	r3, #0
 110:	4282      	cmp	r2, r0
 112:	418b      	sbcs	r3, r1
 114:	d3a3      	bcc.n	5e <SystemSourceSelector_ImuFreshSelect+0x5e>
 116:	ed9f 7a11 	vldr	s14, [pc, #68]	@ 15c <SystemSourceSelector_ImuFreshSelect+0x15c>
 11a:	ab17      	add	r3, sp, #92	@ 0x5c
 11c:	aa1a      	add	r2, sp, #104	@ 0x68
 11e:	ecf3 7a01 	vldmia	r3!, {s15}
 122:	eef0 7ae7 	vabs.f32	s15, s15
 126:	eef4 7a47 	vcmp.f32	s15, s14
 12a:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 12e:	d896      	bhi.n	5e <SystemSourceSelector_ImuFreshSelect+0x5e>
 130:	edd3 7a02 	vldr	s15, [r3, #8]
 134:	eef0 7ae7 	vabs.f32	s15, s15
 138:	eef4 7a47 	vcmp.f32	s15, s14
 13c:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 140:	d88d      	bhi.n	5e <SystemSourceSelector_ImuFreshSelect+0x5e>
 142:	4293      	cmp	r3, r2
 144:	d1eb      	bne.n	11e <SystemSourceSelector_ImuFreshSelect+0x11e>
 146:	73ae      	strb	r6, [r5, #14]
 148:	f885 800f 	strb.w	r8, [r5, #15]
 14c:	e78b      	b.n	66 <SystemSourceSelector_ImuFreshSelect+0x66>
 14e:	bf00      	nop
	...
			150: R_ARM_ABS32	.bss.s_imu
			154: R_ARM_ABS32	.rodata.SystemSourceSelector_GnssSelectionPublish.str1.4
 158:	0003d090 	.word	0x0003d090
 15c:	7f7fffff 	.word	0x7f7fffff

Disassembly of section .text.SystemSourceSelector_TelemetryCandidateStart:

00000000 <SystemSourceSelector_TelemetryCandidateStart>:
   0:	b570      	push	{r4, r5, r6, lr}
   2:	4d2f      	ldr	r5, [pc, #188]	@ (c0 <SystemSourceSelector_TelemetryCandidateStart+0xc0>)
   4:	182b      	adds	r3, r5, r0
   6:	b082      	sub	sp, #8
   8:	7a1a      	ldrb	r2, [r3, #8]
   a:	4604      	mov	r4, r0
   c:	bb32      	cbnz	r2, 5c <SystemSourceSelector_TelemetryCandidateStart+0x5c>
   e:	7b1a      	ldrb	r2, [r3, #12]
  10:	bb22      	cbnz	r2, 5c <SystemSourceSelector_TelemetryCandidateStart+0x5c>
  12:	791b      	ldrb	r3, [r3, #4]
  14:	b38b      	cbz	r3, 7a <SystemSourceSelector_TelemetryCandidateStart+0x7a>
  16:	4620      	mov	r0, r4
  18:	f7ff fffe 	bl	0 <ProjectTelemetryInstance_Start>
			18: R_ARM_THM_CALL	ProjectTelemetryInstance_Start
  1c:	2302      	movs	r3, #2
  1e:	2810      	cmp	r0, #16
  20:	9300      	str	r3, [sp, #0]
  22:	4a28      	ldr	r2, [pc, #160]	@ (c4 <SystemSourceSelector_TelemetryCandidateStart+0xc4>)
  24:	4606      	mov	r6, r0
  26:	f240 630c 	movw	r3, #1548	@ 0x60c
  2a:	f04f 010c 	mov.w	r1, #12
  2e:	d938      	bls.n	a2 <SystemSourceSelector_TelemetryCandidateStart+0xa2>
  30:	2000      	movs	r0, #0
  32:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			32: R_ARM_THM_CALL	SilverStarAssert_Check
  36:	4425      	add	r5, r4
  38:	2301      	movs	r3, #1
  3a:	4620      	mov	r0, r4
  3c:	732b      	strb	r3, [r5, #12]
  3e:	f7ff fffe 	bl	0 <ProjectTelemetryInstance_Stop>
			3e: R_ARM_THM_CALL	ProjectTelemetryInstance_Stop
  42:	280d      	cmp	r0, #13
  44:	d82a      	bhi.n	9c <SystemSourceSelector_TelemetryCandidateStart+0x9c>
  46:	f243 4303 	movw	r3, #13315	@ 0x3403
  4a:	40c3      	lsrs	r3, r0
  4c:	07db      	lsls	r3, r3, #31
  4e:	d525      	bpl.n	9c <SystemSourceSelector_TelemetryCandidateStart+0x9c>
  50:	2300      	movs	r3, #0
  52:	732b      	strb	r3, [r5, #12]
  54:	712b      	strb	r3, [r5, #4]
  56:	2000      	movs	r0, #0
  58:	b002      	add	sp, #8
  5a:	bd70      	pop	{r4, r5, r6, pc}
  5c:	4620      	mov	r0, r4
  5e:	f7ff fffe 	bl	0 <ProjectTelemetryInstance_Stop>
			5e: R_ARM_THM_CALL	ProjectTelemetryInstance_Stop
  62:	280d      	cmp	r0, #13
  64:	d817      	bhi.n	96 <SystemSourceSelector_TelemetryCandidateStart+0x96>
  66:	f243 4303 	movw	r3, #13315	@ 0x3403
  6a:	40c3      	lsrs	r3, r0
  6c:	07d8      	lsls	r0, r3, #31
  6e:	d512      	bpl.n	96 <SystemSourceSelector_TelemetryCandidateStart+0x96>
  70:	192b      	adds	r3, r5, r4
  72:	2200      	movs	r2, #0
  74:	721a      	strb	r2, [r3, #8]
  76:	731a      	strb	r2, [r3, #12]
  78:	711a      	strb	r2, [r3, #4]
  7a:	4620      	mov	r0, r4
  7c:	f7ff fffe 	bl	0 <ProjectTelemetryInstance_Init>
			7c: R_ARM_THM_CALL	ProjectTelemetryInstance_Init
  80:	280d      	cmp	r0, #13
  82:	d8e8      	bhi.n	56 <SystemSourceSelector_TelemetryCandidateStart+0x56>
  84:	f243 4303 	movw	r3, #13315	@ 0x3403
  88:	40c3      	lsrs	r3, r0
  8a:	07d9      	lsls	r1, r3, #31
  8c:	d5e3      	bpl.n	56 <SystemSourceSelector_TelemetryCandidateStart+0x56>
  8e:	192b      	adds	r3, r5, r4
  90:	2201      	movs	r2, #1
  92:	711a      	strb	r2, [r3, #4]
  94:	e7bf      	b.n	16 <SystemSourceSelector_TelemetryCandidateStart+0x16>
  96:	4425      	add	r5, r4
  98:	2301      	movs	r3, #1
  9a:	732b      	strb	r3, [r5, #12]
  9c:	2002      	movs	r0, #2
  9e:	b002      	add	sp, #8
  a0:	bd70      	pop	{r4, r5, r6, pc}
  a2:	2001      	movs	r0, #1
  a4:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			a4: R_ARM_THM_CALL	SilverStarAssert_Check
  a8:	2e0d      	cmp	r6, #13
  aa:	d8c4      	bhi.n	36 <SystemSourceSelector_TelemetryCandidateStart+0x36>
  ac:	f243 4303 	movw	r3, #13315	@ 0x3403
  b0:	40f3      	lsrs	r3, r6
  b2:	07da      	lsls	r2, r3, #31
  b4:	d5bf      	bpl.n	36 <SystemSourceSelector_TelemetryCandidateStart+0x36>
  b6:	4425      	add	r5, r4
  b8:	2001      	movs	r0, #1
  ba:	7228      	strb	r0, [r5, #8]
  bc:	b002      	add	sp, #8
  be:	bd70      	pop	{r4, r5, r6, pc}
	...
			c0: R_ARM_ABS32	.bss.s_telemetry
			c4: R_ARM_ABS32	.rodata.SystemSourceSelector_GnssSelectionPublish.str1.4

Disassembly of section .text.SystemSourceSelector_PrimaryInstanceGet:

00000000 <SystemSourceSelector_PrimaryInstanceGet>:
   0:	b5f0      	push	{r4, r5, r6, r7, lr}
   2:	b08b      	sub	sp, #44	@ 0x2c
   4:	2302      	movs	r3, #2
   6:	4a1c      	ldr	r2, [pc, #112]	@ (78 <SystemSourceSelector_PrimaryInstanceGet+0x78>)
   8:	9300      	str	r3, [sp, #0]
   a:	210c      	movs	r1, #12
   c:	f44f 73a1 	mov.w	r3, #322	@ 0x142
  10:	4607      	mov	r7, r0
  12:	2001      	movs	r0, #1
  14:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			14: R_ARM_THM_CALL	SilverStarAssert_Check
  18:	4638      	mov	r0, r7
  1a:	f7ff fffe 	bl	0 <ProjectDeviceInstance_CountGet>
			1a: R_ARM_THM_CALL	ProjectDeviceInstance_CountGet
  1e:	2304      	movs	r3, #4
  20:	2804      	cmp	r0, #4
  22:	4606      	mov	r6, r0
  24:	9300      	str	r3, [sp, #0]
  26:	4a14      	ldr	r2, [pc, #80]	@ (78 <SystemSourceSelector_PrimaryInstanceGet+0x78>)
  28:	f240 1347 	movw	r3, #327	@ 0x147
  2c:	f04f 010c 	mov.w	r1, #12
  30:	bf8c      	ite	hi
  32:	2000      	movhi	r0, #0
  34:	2001      	movls	r0, #1
  36:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			36: R_ARM_THM_CALL	SilverStarAssert_Check
  3a:	2400      	movs	r4, #0
  3c:	b2e5      	uxtb	r5, r4
  3e:	42ae      	cmp	r6, r5
  40:	aa03      	add	r2, sp, #12
  42:	4629      	mov	r1, r5
  44:	4638      	mov	r0, r7
  46:	d909      	bls.n	5c <SystemSourceSelector_PrimaryInstanceGet+0x5c>
  48:	f7ff fffe 	bl	0 <ProjectDeviceInstance_DescriptorGet>
			48: R_ARM_THM_CALL	ProjectDeviceInstance_DescriptorGet
  4c:	b918      	cbnz	r0, 56 <SystemSourceSelector_PrimaryInstanceGet+0x56>
  4e:	f8bd 3014 	ldrh.w	r3, [sp, #20]
  52:	071b      	lsls	r3, r3, #28
  54:	d40a      	bmi.n	6c <SystemSourceSelector_PrimaryInstanceGet+0x6c>
  56:	3401      	adds	r4, #1
  58:	2c04      	cmp	r4, #4
  5a:	d1ef      	bne.n	3c <SystemSourceSelector_PrimaryInstanceGet+0x3c>
  5c:	fab6 f686 	clz	r6, r6
  60:	0976      	lsrs	r6, r6, #5
  62:	4276      	negs	r6, r6
  64:	b2f5      	uxtb	r5, r6
  66:	4628      	mov	r0, r5
  68:	b00b      	add	sp, #44	@ 0x2c
  6a:	bdf0      	pop	{r4, r5, r6, r7, pc}
  6c:	2dff      	cmp	r5, #255	@ 0xff
  6e:	d0f5      	beq.n	5c <SystemSourceSelector_PrimaryInstanceGet+0x5c>
  70:	4628      	mov	r0, r5
  72:	b00b      	add	sp, #44	@ 0x2c
  74:	bdf0      	pop	{r4, r5, r6, r7, pc}
  76:	bf00      	nop
  78:	00000000 	.word	0x00000000
			78: R_ARM_ABS32	.rodata.SystemSourceSelector_GnssSelectionPublish.str1.4

Disassembly of section .text.SystemSourceSelector_PassiveInit:

00000000 <SystemSourceSelector_PassiveInit>:
   0:	e92d 43f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, lr}
   4:	b083      	sub	sp, #12
   6:	4605      	mov	r5, r0
   8:	f7ff fffe 	bl	0 <ProjectDeviceInstance_CountGet>
			8: R_ARM_THM_CALL	ProjectDeviceInstance_CountGet
   c:	2302      	movs	r3, #2
   e:	4a22      	ldr	r2, [pc, #136]	@ (98 <SystemSourceSelector_PassiveInit+0x98>)
  10:	9300      	str	r3, [sp, #0]
  12:	210c      	movs	r1, #12
  14:	f640 0314 	movw	r3, #2068	@ 0x814
  18:	4606      	mov	r6, r0
  1a:	2001      	movs	r0, #1
  1c:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			1c: R_ARM_THM_CALL	SilverStarAssert_Check
  20:	2e04      	cmp	r6, #4
  22:	f04f 0304 	mov.w	r3, #4
  26:	9300      	str	r3, [sp, #0]
  28:	4a1b      	ldr	r2, [pc, #108]	@ (98 <SystemSourceSelector_PassiveInit+0x98>)
  2a:	f640 031a 	movw	r3, #2074	@ 0x81a
  2e:	f04f 010c 	mov.w	r1, #12
  32:	bf8c      	ite	hi
  34:	2000      	movhi	r0, #0
  36:	2001      	movls	r0, #1
  38:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			38: R_ARM_THM_CALL	SilverStarAssert_Check
  3c:	2400      	movs	r4, #0
  3e:	46a0      	mov	r8, r4
  40:	f04f 0910 	mov.w	r9, #16
  44:	f243 4703 	movw	r7, #13315	@ 0x3403
  48:	b2e0      	uxtb	r0, r4
  4a:	4286      	cmp	r6, r0
  4c:	d914      	bls.n	78 <SystemSourceSelector_PassiveInit+0x78>
  4e:	2d04      	cmp	r5, #4
  50:	d01e      	beq.n	90 <SystemSourceSelector_PassiveInit+0x90>
  52:	2d05      	cmp	r5, #5
  54:	d019      	beq.n	8a <SystemSourceSelector_PassiveInit+0x8a>
  56:	f7ff fffe 	bl	0 <ProjectBarometerInstance_Init>
			56: R_ARM_THM_CALL	ProjectBarometerInstance_Init
  5a:	280d      	cmp	r0, #13
  5c:	d810      	bhi.n	80 <SystemSourceSelector_PassiveInit+0x80>
  5e:	fa27 f300 	lsr.w	r3, r7, r0
  62:	07db      	lsls	r3, r3, #31
  64:	d50c      	bpl.n	80 <SystemSourceSelector_PassiveInit+0x80>
  66:	f108 0801 	add.w	r8, r8, #1
  6a:	fa5f f888 	uxtb.w	r8, r8
  6e:	f04f 0900 	mov.w	r9, #0
  72:	3401      	adds	r4, #1
  74:	2c04      	cmp	r4, #4
  76:	d1e7      	bne.n	48 <SystemSourceSelector_PassiveInit+0x48>
  78:	4648      	mov	r0, r9
  7a:	b003      	add	sp, #12
  7c:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
  80:	f1b8 0f00 	cmp.w	r8, #0
  84:	bf08      	it	eq
  86:	4681      	moveq	r9, r0
  88:	e7f3      	b.n	72 <SystemSourceSelector_PassiveInit+0x72>
  8a:	f7ff fffe 	bl	0 <ProjectAttitudeInstance_Init>
			8a: R_ARM_THM_CALL	ProjectAttitudeInstance_Init
  8e:	e7e4      	b.n	5a <SystemSourceSelector_PassiveInit+0x5a>
  90:	f7ff fffe 	bl	0 <ProjectMagnetometerInstance_Init>
			90: R_ARM_THM_CALL	ProjectMagnetometerInstance_Init
  94:	e7e1      	b.n	5a <SystemSourceSelector_PassiveInit+0x5a>
  96:	bf00      	nop
  98:	00000000 	.word	0x00000000
			98: R_ARM_ABS32	.rodata.SystemSourceSelector_GnssSelectionPublish.str1.4

Disassembly of section .text.SystemSourceSelector_PassiveStart:

00000000 <SystemSourceSelector_PassiveStart>:
   0:	e92d 43f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, lr}
   4:	b083      	sub	sp, #12
   6:	4605      	mov	r5, r0
   8:	f7ff fffe 	bl	0 <ProjectDeviceInstance_CountGet>
			8: R_ARM_THM_CALL	ProjectDeviceInstance_CountGet
   c:	2302      	movs	r3, #2
   e:	4a22      	ldr	r2, [pc, #136]	@ (98 <SystemSourceSelector_PassiveStart+0x98>)
  10:	9300      	str	r3, [sp, #0]
  12:	210c      	movs	r1, #12
  14:	f640 0351 	movw	r3, #2129	@ 0x851
  18:	4606      	mov	r6, r0
  1a:	2001      	movs	r0, #1
  1c:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			1c: R_ARM_THM_CALL	SilverStarAssert_Check
  20:	2e04      	cmp	r6, #4
  22:	f04f 0304 	mov.w	r3, #4
  26:	9300      	str	r3, [sp, #0]
  28:	4a1b      	ldr	r2, [pc, #108]	@ (98 <SystemSourceSelector_PassiveStart+0x98>)
  2a:	f640 0357 	movw	r3, #2135	@ 0x857
  2e:	f04f 010c 	mov.w	r1, #12
  32:	bf8c      	ite	hi
  34:	2000      	movhi	r0, #0
  36:	2001      	movls	r0, #1
  38:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			38: R_ARM_THM_CALL	SilverStarAssert_Check
  3c:	2400      	movs	r4, #0
  3e:	46a0      	mov	r8, r4
  40:	f04f 0910 	mov.w	r9, #16
  44:	f243 4703 	movw	r7, #13315	@ 0x3403
  48:	b2e0      	uxtb	r0, r4
  4a:	4286      	cmp	r6, r0
  4c:	d914      	bls.n	78 <SystemSourceSelector_PassiveStart+0x78>
  4e:	2d04      	cmp	r5, #4
  50:	d01e      	beq.n	90 <SystemSourceSelector_PassiveStart+0x90>
  52:	2d05      	cmp	r5, #5
  54:	d019      	beq.n	8a <SystemSourceSelector_PassiveStart+0x8a>
  56:	f7ff fffe 	bl	0 <ProjectBarometerInstance_Start>
			56: R_ARM_THM_CALL	ProjectBarometerInstance_Start
  5a:	280d      	cmp	r0, #13
  5c:	d810      	bhi.n	80 <SystemSourceSelector_PassiveStart+0x80>
  5e:	fa27 f300 	lsr.w	r3, r7, r0
  62:	07db      	lsls	r3, r3, #31
  64:	d50c      	bpl.n	80 <SystemSourceSelector_PassiveStart+0x80>
  66:	f108 0801 	add.w	r8, r8, #1
  6a:	fa5f f888 	uxtb.w	r8, r8
  6e:	f04f 0900 	mov.w	r9, #0
  72:	3401      	adds	r4, #1
  74:	2c04      	cmp	r4, #4
  76:	d1e7      	bne.n	48 <SystemSourceSelector_PassiveStart+0x48>
  78:	4648      	mov	r0, r9
  7a:	b003      	add	sp, #12
  7c:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
  80:	f1b8 0f00 	cmp.w	r8, #0
  84:	bf08      	it	eq
  86:	4681      	moveq	r9, r0
  88:	e7f3      	b.n	72 <SystemSourceSelector_PassiveStart+0x72>
  8a:	f7ff fffe 	bl	0 <ProjectAttitudeInstance_Start>
			8a: R_ARM_THM_CALL	ProjectAttitudeInstance_Start
  8e:	e7e4      	b.n	5a <SystemSourceSelector_PassiveStart+0x5a>
  90:	f7ff fffe 	bl	0 <ProjectMagnetometerInstance_Start>
			90: R_ARM_THM_CALL	ProjectMagnetometerInstance_Start
  94:	e7e1      	b.n	5a <SystemSourceSelector_PassiveStart+0x5a>
  96:	bf00      	nop
  98:	00000000 	.word	0x00000000
			98: R_ARM_ABS32	.rodata.SystemSourceSelector_GnssSelectionPublish.str1.4

Disassembly of section .text.SystemSourceSelector_PassiveStop:

00000000 <SystemSourceSelector_PassiveStop>:
   0:	b5f0      	push	{r4, r5, r6, r7, lr}
   2:	b083      	sub	sp, #12
   4:	4605      	mov	r5, r0
   6:	f7ff fffe 	bl	0 <ProjectDeviceInstance_CountGet>
			6: R_ARM_THM_CALL	ProjectDeviceInstance_CountGet
   a:	2302      	movs	r3, #2
   c:	4a24      	ldr	r2, [pc, #144]	@ (a0 <SystemSourceSelector_PassiveStop+0xa0>)
   e:	9300      	str	r3, [sp, #0]
  10:	210c      	movs	r1, #12
  12:	f640 038d 	movw	r3, #2189	@ 0x88d
  16:	4606      	mov	r6, r0
  18:	2001      	movs	r0, #1
  1a:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			1a: R_ARM_THM_CALL	SilverStarAssert_Check
  1e:	2e04      	cmp	r6, #4
  20:	f04f 0304 	mov.w	r3, #4
  24:	9300      	str	r3, [sp, #0]
  26:	4a1e      	ldr	r2, [pc, #120]	@ (a0 <SystemSourceSelector_PassiveStop+0xa0>)
  28:	f640 0393 	movw	r3, #2195	@ 0x893
  2c:	f04f 010c 	mov.w	r1, #12
  30:	bf8c      	ite	hi
  32:	2000      	movhi	r0, #0
  34:	2001      	movls	r0, #1
  36:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			36: R_ARM_THM_CALL	SilverStarAssert_Check
  3a:	2400      	movs	r4, #0
  3c:	4627      	mov	r7, r4
  3e:	b2e0      	uxtb	r0, r4
  40:	4286      	cmp	r6, r0
  42:	d90c      	bls.n	5e <SystemSourceSelector_PassiveStop+0x5e>
  44:	2d04      	cmp	r5, #4
  46:	d013      	beq.n	70 <SystemSourceSelector_PassiveStop+0x70>
  48:	2d05      	cmp	r5, #5
  4a:	d024      	beq.n	96 <SystemSourceSelector_PassiveStop+0x96>
  4c:	f7ff fffe 	bl	0 <ProjectBarometerInstance_Stop>
			4c: R_ARM_THM_CALL	ProjectBarometerInstance_Stop
  50:	b990      	cbnz	r0, 78 <SystemSourceSelector_PassiveStop+0x78>
  52:	3401      	adds	r4, #1
  54:	2c04      	cmp	r4, #4
  56:	b2e0      	uxtb	r0, r4
  58:	d001      	beq.n	5e <SystemSourceSelector_PassiveStop+0x5e>
  5a:	42b0      	cmp	r0, r6
  5c:	d3f4      	bcc.n	48 <SystemSourceSelector_PassiveStop+0x48>
  5e:	4638      	mov	r0, r7
  60:	b003      	add	sp, #12
  62:	bdf0      	pop	{r4, r5, r6, r7, pc}
  64:	3401      	adds	r4, #1
  66:	2c04      	cmp	r4, #4
  68:	b2e0      	uxtb	r0, r4
  6a:	d0f8      	beq.n	5e <SystemSourceSelector_PassiveStop+0x5e>
  6c:	4286      	cmp	r6, r0
  6e:	d9f6      	bls.n	5e <SystemSourceSelector_PassiveStop+0x5e>
  70:	f7ff fffe 	bl	0 <ProjectMagnetometerInstance_Stop>
			70: R_ARM_THM_CALL	ProjectMagnetometerInstance_Stop
  74:	2800      	cmp	r0, #0
  76:	d0f5      	beq.n	64 <SystemSourceSelector_PassiveStop+0x64>
  78:	3401      	adds	r4, #1
  7a:	2802      	cmp	r0, #2
  7c:	bf18      	it	ne
  7e:	4607      	movne	r7, r0
  80:	2c04      	cmp	r4, #4
  82:	d1dc      	bne.n	3e <SystemSourceSelector_PassiveStop+0x3e>
  84:	4638      	mov	r0, r7
  86:	b003      	add	sp, #12
  88:	bdf0      	pop	{r4, r5, r6, r7, pc}
  8a:	3401      	adds	r4, #1
  8c:	2c04      	cmp	r4, #4
  8e:	b2e0      	uxtb	r0, r4
  90:	d0e5      	beq.n	5e <SystemSourceSelector_PassiveStop+0x5e>
  92:	4286      	cmp	r6, r0
  94:	d9e3      	bls.n	5e <SystemSourceSelector_PassiveStop+0x5e>
  96:	f7ff fffe 	bl	0 <ProjectAttitudeInstance_Stop>
			96: R_ARM_THM_CALL	ProjectAttitudeInstance_Stop
  9a:	2800      	cmp	r0, #0
  9c:	d1ec      	bne.n	78 <SystemSourceSelector_PassiveStop+0x78>
  9e:	e7f4      	b.n	8a <SystemSourceSelector_PassiveStop+0x8a>
  a0:	00000000 	.word	0x00000000
			a0: R_ARM_ABS32	.rodata.SystemSourceSelector_GnssSelectionPublish.str1.4

Disassembly of section .text.SystemSourceSelector_OrderBuild.part.0.constprop.0:

00000000 <SystemSourceSelector_OrderBuild.part.0.constprop.0>:
   0:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
   4:	b08a      	sub	sp, #40	@ 0x28
   6:	4617      	mov	r7, r2
   8:	229b      	movs	r2, #155	@ 0x9b
   a:	9200      	str	r2, [sp, #0]
   c:	4b19      	ldr	r3, [pc, #100]	@ (74 <SystemSourceSelector_OrderBuild.part.0.constprop.0+0x74>)
   e:	4680      	mov	r8, r0
  10:	460e      	mov	r6, r1
  12:	220c      	movs	r2, #12
  14:	2101      	movs	r1, #1
  16:	4638      	mov	r0, r7
  18:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			18: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  1c:	2400      	movs	r4, #0
  1e:	b2e5      	uxtb	r5, r4
  20:	42b4      	cmp	r4, r6
  22:	aa03      	add	r2, sp, #12
  24:	4640      	mov	r0, r8
  26:	4629      	mov	r1, r5
  28:	d009      	beq.n	3e <SystemSourceSelector_OrderBuild.part.0.constprop.0+0x3e>
  2a:	f7ff fffe 	bl	0 <ProjectDeviceInstance_DescriptorGet>
			2a: R_ARM_THM_CALL	ProjectDeviceInstance_DescriptorGet
  2e:	b918      	cbnz	r0, 38 <SystemSourceSelector_OrderBuild.part.0.constprop.0+0x38>
  30:	f8bd 3014 	ldrh.w	r3, [sp, #20]
  34:	071b      	lsls	r3, r3, #28
  36:	d405      	bmi.n	44 <SystemSourceSelector_OrderBuild.part.0.constprop.0+0x44>
  38:	3401      	adds	r4, #1
  3a:	2c04      	cmp	r4, #4
  3c:	d1ef      	bne.n	1e <SystemSourceSelector_OrderBuild.part.0.constprop.0+0x1e>
  3e:	b1ae      	cbz	r6, 6c <SystemSourceSelector_OrderBuild.part.0.constprop.0+0x6c>
  40:	2500      	movs	r5, #0
  42:	e001      	b.n	48 <SystemSourceSelector_OrderBuild.part.0.constprop.0+0x48>
  44:	2dff      	cmp	r5, #255	@ 0xff
  46:	d0fa      	beq.n	3e <SystemSourceSelector_OrderBuild.part.0.constprop.0+0x3e>
  48:	703d      	strb	r5, [r7, #0]
  4a:	2300      	movs	r3, #0
  4c:	2001      	movs	r0, #1
  4e:	b2dc      	uxtb	r4, r3
  50:	42a6      	cmp	r6, r4
  52:	f103 0301 	add.w	r3, r3, #1
  56:	d906      	bls.n	66 <SystemSourceSelector_OrderBuild.part.0.constprop.0+0x66>
  58:	42a5      	cmp	r5, r4
  5a:	d002      	beq.n	62 <SystemSourceSelector_OrderBuild.part.0.constprop.0+0x62>
  5c:	1c42      	adds	r2, r0, #1
  5e:	543c      	strb	r4, [r7, r0]
  60:	b2d0      	uxtb	r0, r2
  62:	2b04      	cmp	r3, #4
  64:	d1f3      	bne.n	4e <SystemSourceSelector_OrderBuild.part.0.constprop.0+0x4e>
  66:	b00a      	add	sp, #40	@ 0x28
  68:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
  6c:	4630      	mov	r0, r6
  6e:	b00a      	add	sp, #40	@ 0x28
  70:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
  74:	00000000 	.word	0x00000000
			74: R_ARM_ABS32	.rodata.SystemSourceSelector_GnssSelectionPublish.str1.4

Disassembly of section .text.SystemSourceSelector_TelemetryNextStart:

00000000 <SystemSourceSelector_TelemetryNextStart>:
   0:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
   4:	4e4b      	ldr	r6, [pc, #300]	@ (134 <SystemSourceSelector_TelemetryNextStart+0x134>)
   6:	4a4c      	ldr	r2, [pc, #304]	@ (138 <SystemSourceSelector_TelemetryNextStart+0x138>)
   8:	7c31      	ldrb	r1, [r6, #16]
   a:	b08e      	sub	sp, #56	@ 0x38
   c:	2904      	cmp	r1, #4
   e:	f04f 030a 	mov.w	r3, #10
  12:	4680      	mov	r8, r0
  14:	9300      	str	r3, [sp, #0]
  16:	bf88      	it	hi
  18:	2000      	movhi	r0, #0
  1a:	f44f 63c4 	mov.w	r3, #1568	@ 0x620
  1e:	bf98      	it	ls
  20:	2001      	movls	r0, #1
  22:	210c      	movs	r1, #12
  24:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			24: R_ARM_THM_CALL	SilverStarAssert_Check
  28:	7cb3      	ldrb	r3, [r6, #18]
  2a:	2bff      	cmp	r3, #255	@ 0xff
  2c:	d075      	beq.n	11a <SystemSourceSelector_TelemetryNextStart+0x11a>
  2e:	7cf2      	ldrb	r2, [r6, #19]
  30:	7c31      	ldrb	r1, [r6, #16]
  32:	4291      	cmp	r1, r2
  34:	d84f      	bhi.n	d6 <SystemSourceSelector_TelemetryNextStart+0xd6>
  36:	2000      	movs	r0, #0
  38:	2305      	movs	r3, #5
  3a:	9300      	str	r3, [sp, #0]
  3c:	4a3e      	ldr	r2, [pc, #248]	@ (138 <SystemSourceSelector_TelemetryNextStart+0x138>)
  3e:	f240 6322 	movw	r3, #1570	@ 0x622
  42:	210c      	movs	r1, #12
  44:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			44: R_ARM_THM_CALL	SilverStarAssert_Check
  48:	2700      	movs	r7, #0
  4a:	f04f 0903 	mov.w	r9, #3
  4e:	7c30      	ldrb	r0, [r6, #16]
  50:	b2fc      	uxtb	r4, r7
  52:	42a0      	cmp	r0, r4
  54:	d939      	bls.n	ca <SystemSourceSelector_TelemetryNextStart+0xca>
  56:	7cb3      	ldrb	r3, [r6, #18]
  58:	2bff      	cmp	r3, #255	@ 0xff
  5a:	d007      	beq.n	6c <SystemSourceSelector_TelemetryNextStart+0x6c>
  5c:	7cf4      	ldrb	r4, [r6, #19]
  5e:	443c      	add	r4, r7
  60:	3401      	adds	r4, #1
  62:	fbb4 f3f0 	udiv	r3, r4, r0
  66:	fb00 4413 	mls	r4, r0, r3, r4
  6a:	b2e4      	uxtb	r4, r4
  6c:	5d35      	ldrb	r5, [r6, r4]
  6e:	2d03      	cmp	r5, #3
  70:	d855      	bhi.n	11e <SystemSourceSelector_TelemetryNextStart+0x11e>
  72:	42a8      	cmp	r0, r5
  74:	f240 6335 	movw	r3, #1589	@ 0x635
  78:	bf94      	ite	ls
  7a:	2000      	movls	r0, #0
  7c:	2001      	movhi	r0, #1
  7e:	4a2e      	ldr	r2, [pc, #184]	@ (138 <SystemSourceSelector_TelemetryNextStart+0x138>)
  80:	f8cd 9000 	str.w	r9, [sp]
  84:	210c      	movs	r1, #12
  86:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			86: R_ARM_THM_CALL	SilverStarAssert_Check
  8a:	7cb3      	ldrb	r3, [r6, #18]
  8c:	42ab      	cmp	r3, r5
  8e:	d028      	beq.n	e2 <SystemSourceSelector_TelemetryNextStart+0xe2>
  90:	1973      	adds	r3, r6, r5
  92:	f893 3027 	ldrb.w	r3, [r3, #39]	@ 0x27
  96:	b16b      	cbz	r3, b4 <SystemSourceSelector_TelemetryNextStart+0xb4>
  98:	f7ff fffe 	bl	0 <SystemTime_GetMonotonicUs>
			98: R_ARM_THM_CALL	SystemTime_GetMonotonicUs
  9c:	2300      	movs	r3, #0
  9e:	f44f 727a 	mov.w	r2, #1000	@ 0x3e8
  a2:	f7ff fffe 	bl	0 <__aeabi_uldivmod>
			a2: R_ARM_THM_CALL	__aeabi_uldivmod
  a6:	eb06 0385 	add.w	r3, r6, r5, lsl #2
  aa:	6adb      	ldr	r3, [r3, #44]	@ 0x2c
  ac:	1ac0      	subs	r0, r0, r3
  ae:	f5b0 4ffa 	cmp.w	r0, #32000	@ 0x7d00
  b2:	d307      	bcc.n	c4 <SystemSourceSelector_TelemetryNextStart+0xc4>
  b4:	4628      	mov	r0, r5
  b6:	f7ff fffe 	bl	0 <SystemSourceSelector_TelemetryNextStart>
			b6: R_ARM_THM_CALL	SystemSourceSelector_TelemetryCandidateStart
  ba:	2802      	cmp	r0, #2
  bc:	4682      	mov	sl, r0
  be:	d004      	beq.n	ca <SystemSourceSelector_TelemetryNextStart+0xca>
  c0:	2801      	cmp	r0, #1
  c2:	d012      	beq.n	ea <SystemSourceSelector_TelemetryNextStart+0xea>
  c4:	3701      	adds	r7, #1
  c6:	2f04      	cmp	r7, #4
  c8:	d1c1      	bne.n	4e <SystemSourceSelector_TelemetryNextStart+0x4e>
  ca:	f04f 0a00 	mov.w	sl, #0
  ce:	4650      	mov	r0, sl
  d0:	b00e      	add	sp, #56	@ 0x38
  d2:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
  d6:	5cb0      	ldrb	r0, [r6, r2]
  d8:	1ac0      	subs	r0, r0, r3
  da:	fab0 f080 	clz	r0, r0
  de:	0940      	lsrs	r0, r0, #5
  e0:	e7aa      	b.n	38 <SystemSourceSelector_TelemetryNextStart+0x38>
  e2:	f1b8 0f00 	cmp.w	r8, #0
  e6:	d1d3      	bne.n	90 <SystemSourceSelector_TelemetryNextStart+0x90>
  e8:	e7ec      	b.n	c4 <SystemSourceSelector_TelemetryNextStart+0xc4>
  ea:	2300      	movs	r3, #0
  ec:	f886 3025 	strb.w	r3, [r6, #37]	@ 0x25
  f0:	82b3      	strh	r3, [r6, #20]
  f2:	2200      	movs	r2, #0
  f4:	2300      	movs	r3, #0
  f6:	4628      	mov	r0, r5
  f8:	a902      	add	r1, sp, #8
  fa:	e9c6 2306 	strd	r2, r3, [r6, #24]
  fe:	74b5      	strb	r5, [r6, #18]
 100:	74f4      	strb	r4, [r6, #19]
 102:	f7ff fffe 	bl	0 <ProjectTelemetryInstance_HealthGet>
			102: R_ARM_THM_CALL	ProjectTelemetryInstance_HealthGet
 106:	2800      	cmp	r0, #0
 108:	d1e1      	bne.n	ce <SystemSourceSelector_TelemetryNextStart+0xce>
 10a:	9a06      	ldr	r2, [sp, #24]
 10c:	9b08      	ldr	r3, [sp, #32]
 10e:	4650      	mov	r0, sl
 110:	e9c6 2306 	strd	r2, r3, [r6, #24]
 114:	b00e      	add	sp, #56	@ 0x38
 116:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
 11a:	2001      	movs	r0, #1
 11c:	e78c      	b.n	38 <SystemSourceSelector_TelemetryNextStart+0x38>
 11e:	2303      	movs	r3, #3
 120:	9300      	str	r3, [sp, #0]
 122:	4a05      	ldr	r2, [pc, #20]	@ (138 <SystemSourceSelector_TelemetryNextStart+0x138>)
 124:	f240 6331 	movw	r3, #1585	@ 0x631
 128:	210c      	movs	r1, #12
 12a:	2000      	movs	r0, #0
 12c:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			12c: R_ARM_THM_CALL	SilverStarAssert_Check
 130:	e7cb      	b.n	ca <SystemSourceSelector_TelemetryNextStart+0xca>
 132:	bf00      	nop
	...
			134: R_ARM_ABS32	.bss.s_telemetry
			138: R_ARM_ABS32	.rodata.SystemSourceSelector_GnssSelectionPublish.str1.4

Disassembly of section .text.SystemSourceSelector_TelemetryRecoveryTry:

00000000 <SystemSourceSelector_TelemetryRecoveryTry>:
   0:	e92d 43f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, lr}
   4:	b083      	sub	sp, #12
   6:	4606      	mov	r6, r0
   8:	f7ff fffe 	bl	0 <SystemTime_GetMonotonicUs>
			8: R_ARM_THM_CALL	SystemTime_GetMonotonicUs
   c:	2300      	movs	r3, #0
   e:	f44f 727a 	mov.w	r2, #1000	@ 0x3e8
  12:	f7ff fffe 	bl	0 <__aeabi_uldivmod>
			12: R_ARM_THM_CALL	__aeabi_uldivmod
  16:	4c60      	ldr	r4, [pc, #384]	@ (198 <SystemSourceSelector_TelemetryRecoveryTry+0x198>)
  18:	4605      	mov	r5, r0
  1a:	f104 070b 	add.w	r7, r4, #11
  1e:	7c20      	ldrb	r0, [r4, #16]
  20:	4639      	mov	r1, r7
  22:	2300      	movs	r3, #0
  24:	b2da      	uxtb	r2, r3
  26:	4290      	cmp	r0, r2
  28:	f103 0301 	add.w	r3, r3, #1
  2c:	d904      	bls.n	38 <SystemSourceSelector_TelemetryRecoveryTry+0x38>
  2e:	f811 2f01 	ldrb.w	r2, [r1, #1]!
  32:	bb3a      	cbnz	r2, 84 <SystemSourceSelector_TelemetryRecoveryTry+0x84>
  34:	2b04      	cmp	r3, #4
  36:	d1f5      	bne.n	24 <SystemSourceSelector_TelemetryRecoveryTry+0x24>
  38:	f894 7024 	ldrb.w	r7, [r4, #36]	@ 0x24
  3c:	4a57      	ldr	r2, [pc, #348]	@ (19c <SystemSourceSelector_TelemetryRecoveryTry+0x19c>)
  3e:	2f06      	cmp	r7, #6
  40:	f04f 0305 	mov.w	r3, #5
  44:	9300      	str	r3, [sp, #0]
  46:	bf88      	it	hi
  48:	2000      	movhi	r0, #0
  4a:	f240 639c 	movw	r3, #1692	@ 0x69c
  4e:	bf98      	it	ls
  50:	2001      	movls	r0, #1
  52:	210c      	movs	r1, #12
  54:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			54: R_ARM_THM_CALL	SilverStarAssert_Check
  58:	6a23      	ldr	r3, [r4, #32]
  5a:	1aea      	subs	r2, r5, r3
  5c:	f44f 737a 	mov.w	r3, #1000	@ 0x3e8
  60:	40bb      	lsls	r3, r7
  62:	429a      	cmp	r2, r3
  64:	d30a      	bcc.n	7c <SystemSourceSelector_TelemetryRecoveryTry+0x7c>
  66:	4630      	mov	r0, r6
  68:	6225      	str	r5, [r4, #32]
  6a:	f7ff fffe 	bl	0 <SystemSourceSelector_TelemetryRecoveryTry>
			6a: R_ARM_THM_CALL	SystemSourceSelector_TelemetryNextStart
  6e:	2800      	cmp	r0, #0
  70:	f040 8084 	bne.w	17c <SystemSourceSelector_TelemetryRecoveryTry+0x17c>
  74:	f894 3024 	ldrb.w	r3, [r4, #36]	@ 0x24
  78:	2b04      	cmp	r3, #4
  7a:	d978      	bls.n	16e <SystemSourceSelector_TelemetryRecoveryTry+0x16e>
  7c:	2000      	movs	r0, #0
  7e:	b003      	add	sp, #12
  80:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
  84:	f894 6024 	ldrb.w	r6, [r4, #36]	@ 0x24
  88:	4a44      	ldr	r2, [pc, #272]	@ (19c <SystemSourceSelector_TelemetryRecoveryTry+0x19c>)
  8a:	2e06      	cmp	r6, #6
  8c:	f04f 0305 	mov.w	r3, #5
  90:	9300      	str	r3, [sp, #0]
  92:	f04f 010c 	mov.w	r1, #12
  96:	f240 639c 	movw	r3, #1692	@ 0x69c
  9a:	bf8c      	ite	hi
  9c:	2000      	movhi	r0, #0
  9e:	2001      	movls	r0, #1
  a0:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			a0: R_ARM_THM_CALL	SilverStarAssert_Check
  a4:	6a23      	ldr	r3, [r4, #32]
  a6:	1aeb      	subs	r3, r5, r3
  a8:	2e00      	cmp	r6, #0
  aa:	d058      	beq.n	15e <SystemSourceSelector_TelemetryRecoveryTry+0x15e>
  ac:	3e01      	subs	r6, #1
  ae:	b2f6      	uxtb	r6, r6
  b0:	f44f 727a 	mov.w	r2, #1000	@ 0x3e8
  b4:	40b2      	lsls	r2, r6
  b6:	4293      	cmp	r3, r2
  b8:	d3e0      	bcc.n	7c <SystemSourceSelector_TelemetryRecoveryTry+0x7c>
  ba:	6225      	str	r5, [r4, #32]
  bc:	4c36      	ldr	r4, [pc, #216]	@ (198 <SystemSourceSelector_TelemetryRecoveryTry+0x198>)
  be:	2600      	movs	r6, #0
  c0:	46a0      	mov	r8, r4
  c2:	f894 c010 	ldrb.w	ip, [r4, #16]
  c6:	4a35      	ldr	r2, [pc, #212]	@ (19c <SystemSourceSelector_TelemetryRecoveryTry+0x19c>)
  c8:	b2f5      	uxtb	r5, r6
  ca:	45ac      	cmp	ip, r5
  cc:	f04f 0003 	mov.w	r0, #3
  d0:	f240 6377 	movw	r3, #1655	@ 0x677
  d4:	f04f 010c 	mov.w	r1, #12
  d8:	d9d0      	bls.n	7c <SystemSourceSelector_TelemetryRecoveryTry+0x7c>
  da:	f818 5b01 	ldrb.w	r5, [r8], #1
  de:	4285      	cmp	r5, r0
  e0:	d853      	bhi.n	18a <SystemSourceSelector_TelemetryRecoveryTry+0x18a>
  e2:	45ac      	cmp	ip, r5
  e4:	eb04 0905 	add.w	r9, r4, r5
  e8:	9000      	str	r0, [sp, #0]
  ea:	bf94      	ite	ls
  ec:	2000      	movls	r0, #0
  ee:	2001      	movhi	r0, #1
  f0:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			f0: R_ARM_THM_CALL	SilverStarAssert_Check
  f4:	f899 300c 	ldrb.w	r3, [r9, #12]
  f8:	3601      	adds	r6, #1
  fa:	2b00      	cmp	r3, #0
  fc:	d03b      	beq.n	176 <SystemSourceSelector_TelemetryRecoveryTry+0x176>
  fe:	4628      	mov	r0, r5
 100:	f7ff fffe 	bl	0 <ProjectTelemetryInstance_Stop>
			100: R_ARM_THM_CALL	ProjectTelemetryInstance_Stop
 104:	280d      	cmp	r0, #13
 106:	d82e      	bhi.n	166 <SystemSourceSelector_TelemetryRecoveryTry+0x166>
 108:	f243 4303 	movw	r3, #13315	@ 0x3403
 10c:	40c3      	lsrs	r3, r0
 10e:	07db      	lsls	r3, r3, #31
 110:	d529      	bpl.n	166 <SystemSourceSelector_TelemetryRecoveryTry+0x166>
 112:	2300      	movs	r3, #0
 114:	7c21      	ldrb	r1, [r4, #16]
 116:	f889 300c 	strb.w	r3, [r9, #12]
 11a:	f889 3008 	strb.w	r3, [r9, #8]
 11e:	f889 3004 	strb.w	r3, [r9, #4]
 122:	b2da      	uxtb	r2, r3
 124:	4291      	cmp	r1, r2
 126:	f103 0301 	add.w	r3, r3, #1
 12a:	d904      	bls.n	136 <SystemSourceSelector_TelemetryRecoveryTry+0x136>
 12c:	f817 2f01 	ldrb.w	r2, [r7, #1]!
 130:	b92a      	cbnz	r2, 13e <SystemSourceSelector_TelemetryRecoveryTry+0x13e>
 132:	2b04      	cmp	r3, #4
 134:	d1f5      	bne.n	122 <SystemSourceSelector_TelemetryRecoveryTry+0x122>
 136:	2300      	movs	r3, #0
 138:	f884 3024 	strb.w	r3, [r4, #36]	@ 0x24
 13c:	6223      	str	r3, [r4, #32]
 13e:	7ca2      	ldrb	r2, [r4, #18]
 140:	4295      	cmp	r5, r2
 142:	d09b      	beq.n	7c <SystemSourceSelector_TelemetryRecoveryTry+0x7c>
 144:	f894 3025 	ldrb.w	r3, [r4, #37]	@ 0x25
 148:	2b00      	cmp	r3, #0
 14a:	d097      	beq.n	7c <SystemSourceSelector_TelemetryRecoveryTry+0x7c>
 14c:	2303      	movs	r3, #3
 14e:	4629      	mov	r1, r5
 150:	2006      	movs	r0, #6
 152:	f7ff fffe 	bl	0 <SystemSourceSelector_TelemetryRecoveryTry>
			152: R_ARM_THM_CALL	SystemSourceSelector_EventRecord
 156:	2300      	movs	r3, #0
 158:	f884 3025 	strb.w	r3, [r4, #37]	@ 0x25
 15c:	e78e      	b.n	7c <SystemSourceSelector_TelemetryRecoveryTry+0x7c>
 15e:	f5b3 7f7a 	cmp.w	r3, #1000	@ 0x3e8
 162:	d2aa      	bcs.n	ba <SystemSourceSelector_TelemetryRecoveryTry+0xba>
 164:	e78a      	b.n	7c <SystemSourceSelector_TelemetryRecoveryTry+0x7c>
 166:	f894 3024 	ldrb.w	r3, [r4, #36]	@ 0x24
 16a:	2b05      	cmp	r3, #5
 16c:	d886      	bhi.n	7c <SystemSourceSelector_TelemetryRecoveryTry+0x7c>
 16e:	3301      	adds	r3, #1
 170:	f884 3024 	strb.w	r3, [r4, #36]	@ 0x24
 174:	e782      	b.n	7c <SystemSourceSelector_TelemetryRecoveryTry+0x7c>
 176:	2e04      	cmp	r6, #4
 178:	d080      	beq.n	7c <SystemSourceSelector_TelemetryRecoveryTry+0x7c>
 17a:	e7a2      	b.n	c2 <SystemSourceSelector_TelemetryRecoveryTry+0xc2>
 17c:	2300      	movs	r3, #0
 17e:	f884 3024 	strb.w	r3, [r4, #36]	@ 0x24
 182:	6223      	str	r3, [r4, #32]
 184:	b003      	add	sp, #12
 186:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
 18a:	9000      	str	r0, [sp, #0]
 18c:	f240 6373 	movw	r3, #1651	@ 0x673
 190:	2000      	movs	r0, #0
 192:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			192: R_ARM_THM_CALL	SilverStarAssert_Check
 196:	e771      	b.n	7c <SystemSourceSelector_TelemetryRecoveryTry+0x7c>
	...
			198: R_ARM_ABS32	.bss.s_telemetry
			19c: R_ARM_ABS32	.rodata.SystemSourceSelector_GnssSelectionPublish.str1.4

Disassembly of section .text.SystemSourceSelector_TelemetrySwitchIfAvailable:

00000000 <SystemSourceSelector_TelemetrySwitchIfAvailable>:
   0:	b5f0      	push	{r4, r5, r6, r7, lr}
   2:	4c27      	ldr	r4, [pc, #156]	@ (a0 <SystemSourceSelector_TelemetrySwitchIfAvailable+0xa0>)
   4:	b083      	sub	sp, #12
   6:	4606      	mov	r6, r0
   8:	2000      	movs	r0, #0
   a:	7ca5      	ldrb	r5, [r4, #18]
   c:	f7ff fffe 	bl	0 <SystemSourceSelector_TelemetrySwitchIfAvailable>
			c: R_ARM_THM_CALL	SystemSourceSelector_TelemetryRecoveryTry
  10:	b908      	cbnz	r0, 16 <SystemSourceSelector_TelemetrySwitchIfAvailable+0x16>
  12:	b003      	add	sp, #12
  14:	bdf0      	pop	{r4, r5, r6, r7, pc}
  16:	4628      	mov	r0, r5
  18:	f7ff fffe 	bl	0 <ProjectTelemetryInstance_Stop>
			18: R_ARM_THM_CALL	ProjectTelemetryInstance_Stop
  1c:	280d      	cmp	r0, #13
  1e:	d82b      	bhi.n	78 <SystemSourceSelector_TelemetrySwitchIfAvailable+0x78>
  20:	f243 4303 	movw	r3, #13315	@ 0x3403
  24:	40c3      	lsrs	r3, r0
  26:	07db      	lsls	r3, r3, #31
  28:	d526      	bpl.n	78 <SystemSourceSelector_TelemetrySwitchIfAvailable+0x78>
  2a:	7c20      	ldrb	r0, [r4, #16]
  2c:	4a1d      	ldr	r2, [pc, #116]	@ (a4 <SystemSourceSelector_TelemetrySwitchIfAvailable+0xa4>)
  2e:	1967      	adds	r7, r4, r5
  30:	2300      	movs	r3, #0
  32:	42a8      	cmp	r0, r5
  34:	723b      	strb	r3, [r7, #8]
  36:	f04f 0303 	mov.w	r3, #3
  3a:	bf94      	ite	ls
  3c:	2000      	movls	r0, #0
  3e:	2001      	movhi	r0, #1
  40:	9300      	str	r3, [sp, #0]
  42:	210c      	movs	r1, #12
  44:	f240 634e 	movw	r3, #1614	@ 0x64e
  48:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			48: R_ARM_THM_CALL	SilverStarAssert_Check
  4c:	2301      	movs	r3, #1
  4e:	f887 3027 	strb.w	r3, [r7, #39]	@ 0x27
  52:	f7ff fffe 	bl	0 <SystemTime_GetMonotonicUs>
			52: R_ARM_THM_CALL	SystemTime_GetMonotonicUs
  56:	f44f 727a 	mov.w	r2, #1000	@ 0x3e8
  5a:	2300      	movs	r3, #0
  5c:	f7ff fffe 	bl	0 <__aeabi_uldivmod>
			5c: R_ARM_THM_CALL	__aeabi_uldivmod
  60:	eb04 0785 	add.w	r7, r4, r5, lsl #2
  64:	7ca2      	ldrb	r2, [r4, #18]
  66:	62f8      	str	r0, [r7, #44]	@ 0x2c
  68:	4633      	mov	r3, r6
  6a:	4629      	mov	r1, r5
  6c:	2006      	movs	r0, #6
  6e:	b003      	add	sp, #12
  70:	e8bd 40f0 	ldmia.w	sp!, {r4, r5, r6, r7, lr}
  74:	f7ff bffe 	b.w	0 <SystemSourceSelector_TelemetrySwitchIfAvailable>
			74: R_ARM_THM_JUMP24	SystemSourceSelector_EventRecord
  78:	4425      	add	r5, r4
  7a:	2601      	movs	r6, #1
  7c:	2300      	movs	r3, #0
  7e:	722b      	strb	r3, [r5, #8]
  80:	732e      	strb	r6, [r5, #12]
  82:	f884 6025 	strb.w	r6, [r4, #37]	@ 0x25
  86:	f7ff fffe 	bl	0 <SystemTime_GetMonotonicUs>
			86: R_ARM_THM_CALL	SystemTime_GetMonotonicUs
  8a:	f44f 727a 	mov.w	r2, #1000	@ 0x3e8
  8e:	2300      	movs	r3, #0
  90:	f7ff fffe 	bl	0 <__aeabi_uldivmod>
			90: R_ARM_THM_CALL	__aeabi_uldivmod
  94:	f884 6024 	strb.w	r6, [r4, #36]	@ 0x24
  98:	6220      	str	r0, [r4, #32]
  9a:	b003      	add	sp, #12
  9c:	bdf0      	pop	{r4, r5, r6, r7, pc}
  9e:	bf00      	nop
	...
			a0: R_ARM_ABS32	.bss.s_telemetry
			a4: R_ARM_ABS32	.rodata.SystemSourceSelector_GnssSelectionPublish.str1.4

Disassembly of section .text.SystemSourceSelector_PendingEventsFlush:

00000000 <SystemSourceSelector_PendingEventsFlush>:
   0:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
   4:	4f35      	ldr	r7, [pc, #212]	@ (dc <SystemSourceSelector_PendingEventsFlush+0xdc>)
   6:	4d36      	ldr	r5, [pc, #216]	@ (e0 <SystemSourceSelector_PendingEventsFlush+0xe0>)
   8:	7838      	ldrb	r0, [r7, #0]
   a:	4a36      	ldr	r2, [pc, #216]	@ (e4 <SystemSourceSelector_PendingEventsFlush+0xe4>)
   c:	f8df 80d8 	ldr.w	r8, [pc, #216]	@ e8 <SystemSourceSelector_PendingEventsFlush+0xe8>
  10:	b084      	sub	sp, #16
  12:	2804      	cmp	r0, #4
  14:	f04f 030a 	mov.w	r3, #10
  18:	bf8c      	ite	hi
  1a:	2000      	movhi	r0, #0
  1c:	2001      	movls	r0, #1
  1e:	9300      	str	r3, [sp, #0]
  20:	210c      	movs	r1, #12
  22:	f240 130b 	movw	r3, #267	@ 0x10b
  26:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			26: R_ARM_THM_CALL	SilverStarAssert_Check
  2a:	7828      	ldrb	r0, [r5, #0]
  2c:	4a2d      	ldr	r2, [pc, #180]	@ (e4 <SystemSourceSelector_PendingEventsFlush+0xe4>)
  2e:	2801      	cmp	r0, #1
  30:	f04f 0305 	mov.w	r3, #5
  34:	9300      	str	r3, [sp, #0]
  36:	bf88      	it	hi
  38:	2000      	movhi	r0, #0
  3a:	f240 130f 	movw	r3, #271	@ 0x10f
  3e:	bf98      	it	ls
  40:	2001      	movls	r0, #1
  42:	210c      	movs	r1, #12
  44:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			44: R_ARM_THM_CALL	SilverStarAssert_Check
  48:	2404      	movs	r4, #4
  4a:	f04f 0901 	mov.w	r9, #1
  4e:	f7ff fffe 	bl	0 <PlatformCritical_Enter>
			4e: R_ARM_THM_CALL	PlatformCritical_Enter
  52:	783a      	ldrb	r2, [r7, #0]
  54:	4603      	mov	r3, r0
  56:	2a00      	cmp	r2, #0
  58:	d03a      	beq.n	d0 <SystemSourceSelector_PendingEventsFlush+0xd0>
  5a:	f895 a000 	ldrb.w	sl, [r5]
  5e:	f1ba 0f00 	cmp.w	sl, #0
  62:	d135      	bne.n	d0 <SystemSourceSelector_PendingEventsFlush+0xd0>
  64:	f8d8 3000 	ldr.w	r3, [r8]
  68:	9303      	str	r3, [sp, #12]
  6a:	f885 9000 	strb.w	r9, [r5]
  6e:	f7ff fffe 	bl	0 <PlatformCritical_Exit>
			6e: R_ARM_THM_CALL	PlatformCritical_Exit
  72:	a803      	add	r0, sp, #12
  74:	f7ff fffe 	bl	0 <SystemSourceSelector_PendingEventsFlush>
			74: R_ARM_THM_CALL	SystemSourceSelector_EventWrite
  78:	4606      	mov	r6, r0
  7a:	f7ff fffe 	bl	0 <PlatformCritical_Enter>
			7a: R_ARM_THM_CALL	PlatformCritical_Enter
  7e:	b136      	cbz	r6, 8e <SystemSourceSelector_PendingEventsFlush+0x8e>
  80:	f885 a000 	strb.w	sl, [r5]
  84:	b004      	add	sp, #16
  86:	e8bd 47f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
  8a:	f7ff bffe 	b.w	0 <PlatformCritical_Exit>
			8a: R_ARM_THM_JUMP24	PlatformCritical_Exit
  8e:	783b      	ldrb	r3, [r7, #0]
  90:	2b01      	cmp	r3, #1
  92:	f04f 0200 	mov.w	r2, #0
  96:	d90f      	bls.n	b8 <SystemSourceSelector_PendingEventsFlush+0xb8>
  98:	f8d8 1004 	ldr.w	r1, [r8, #4]
  9c:	f8c8 1000 	str.w	r1, [r8]
  a0:	2b02      	cmp	r3, #2
  a2:	d009      	beq.n	b8 <SystemSourceSelector_PendingEventsFlush+0xb8>
  a4:	f8d8 1008 	ldr.w	r1, [r8, #8]
  a8:	f8c8 1004 	str.w	r1, [r8, #4]
  ac:	2b03      	cmp	r3, #3
  ae:	bf1c      	itt	ne
  b0:	f8d8 100c 	ldrne.w	r1, [r8, #12]
  b4:	f8c8 1008 	strne.w	r1, [r8, #8]
  b8:	3b01      	subs	r3, #1
  ba:	3c01      	subs	r4, #1
  bc:	703b      	strb	r3, [r7, #0]
  be:	702a      	strb	r2, [r5, #0]
  c0:	f7ff fffe 	bl	0 <PlatformCritical_Exit>
			c0: R_ARM_THM_CALL	PlatformCritical_Exit
  c4:	f014 04ff 	ands.w	r4, r4, #255	@ 0xff
  c8:	d1c1      	bne.n	4e <SystemSourceSelector_PendingEventsFlush+0x4e>
  ca:	b004      	add	sp, #16
  cc:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
  d0:	4618      	mov	r0, r3
  d2:	b004      	add	sp, #16
  d4:	e8bd 47f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
  d8:	f7ff bffe 	b.w	0 <PlatformCritical_Exit>
			d8: R_ARM_THM_JUMP24	PlatformCritical_Exit
	...
			dc: R_ARM_ABS32	.bss.s_pending_event_count
			e0: R_ARM_ABS32	.bss.s_pending_event_flush_active
			e4: R_ARM_ABS32	.rodata.SystemSourceSelector_GnssSelectionPublish.str1.4
			e8: R_ARM_ABS32	.bss.s_pending_events

Disassembly of section .text.SystemSourceSelector_ImuSelectAndLock:

00000000 <SystemSourceSelector_ImuSelectAndLock>:
   0:	b570      	push	{r4, r5, r6, lr}
   2:	4d1f      	ldr	r5, [pc, #124]	@ (80 <SystemSourceSelector_ImuSelectAndLock+0x80>)
   4:	4a1f      	ldr	r2, [pc, #124]	@ (84 <SystemSourceSelector_ImuSelectAndLock+0x84>)
   6:	7b28      	ldrb	r0, [r5, #12]
   8:	b082      	sub	sp, #8
   a:	2804      	cmp	r0, #4
   c:	f04f 0304 	mov.w	r3, #4
  10:	bf8c      	ite	hi
  12:	2000      	movhi	r0, #0
  14:	2001      	movls	r0, #1
  16:	9300      	str	r3, [sp, #0]
  18:	210c      	movs	r1, #12
  1a:	f44f 73dd 	mov.w	r3, #442	@ 0x1ba
  1e:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			1e: R_ARM_THM_CALL	SilverStarAssert_Check
  22:	7c28      	ldrb	r0, [r5, #16]
  24:	4a17      	ldr	r2, [pc, #92]	@ (84 <SystemSourceSelector_ImuSelectAndLock+0x84>)
  26:	2801      	cmp	r0, #1
  28:	f04f 0605 	mov.w	r6, #5
  2c:	9600      	str	r6, [sp, #0]
  2e:	f240 13bd 	movw	r3, #445	@ 0x1bd
  32:	bf8c      	ite	hi
  34:	2000      	movhi	r0, #0
  36:	2001      	movls	r0, #1
  38:	210c      	movs	r1, #12
  3a:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			3a: R_ARM_THM_CALL	SilverStarAssert_Check
  3e:	7c2c      	ldrb	r4, [r5, #16]
  40:	b14c      	cbz	r4, 56 <SystemSourceSelector_ImuSelectAndLock+0x56>
  42:	7bac      	ldrb	r4, [r5, #14]
  44:	f1a4 04ff 	sub.w	r4, r4, #255	@ 0xff
  48:	fab4 f484 	clz	r4, r4
  4c:	0964      	lsrs	r4, r4, #5
  4e:	0064      	lsls	r4, r4, #1
  50:	4620      	mov	r0, r4
  52:	b002      	add	sp, #8
  54:	bd70      	pop	{r4, r5, r6, pc}
  56:	f7ff fffe 	bl	0 <SystemSourceSelector_ImuSelectAndLock>
			56: R_ARM_THM_CALL	SystemSourceSelector_ImuFreshSelect
  5a:	28ff      	cmp	r0, #255	@ 0xff
  5c:	4602      	mov	r2, r0
  5e:	d00c      	beq.n	7a <SystemSourceSelector_ImuSelectAndLock+0x7a>
  60:	7b69      	ldrb	r1, [r5, #13]
  62:	2001      	movs	r0, #1
  64:	29ff      	cmp	r1, #255	@ 0xff
  66:	7428      	strb	r0, [r5, #16]
  68:	d0f2      	beq.n	50 <SystemSourceSelector_ImuSelectAndLock+0x50>
  6a:	4291      	cmp	r1, r2
  6c:	d0f0      	beq.n	50 <SystemSourceSelector_ImuSelectAndLock+0x50>
  6e:	4633      	mov	r3, r6
  70:	f7ff fffe 	bl	0 <SystemSourceSelector_ImuSelectAndLock>
			70: R_ARM_THM_CALL	SystemSourceSelector_EventRecord
  74:	4620      	mov	r0, r4
  76:	b002      	add	sp, #8
  78:	bd70      	pop	{r4, r5, r6, pc}
  7a:	2402      	movs	r4, #2
  7c:	e7e8      	b.n	50 <SystemSourceSelector_ImuSelectAndLock+0x50>
  7e:	bf00      	nop
	...
			80: R_ARM_ABS32	.bss.s_imu
			84: R_ARM_ABS32	.rodata.SystemSourceSelector_GnssSelectionPublish.str1.4

Disassembly of section .text.SystemSourceSelector_ImuActiveInstanceGet:

00000000 <SystemSourceSelector_ImuActiveInstanceGet>:
   0:	b140      	cbz	r0, 14 <SystemSourceSelector_ImuActiveInstanceGet+0x14>
   2:	4b05      	ldr	r3, [pc, #20]	@ (18 <SystemSourceSelector_ImuActiveInstanceGet+0x18>)
   4:	7b9b      	ldrb	r3, [r3, #14]
   6:	2bff      	cmp	r3, #255	@ 0xff
   8:	d002      	beq.n	10 <SystemSourceSelector_ImuActiveInstanceGet+0x10>
   a:	7003      	strb	r3, [r0, #0]
   c:	2000      	movs	r0, #0
   e:	4770      	bx	lr
  10:	2002      	movs	r0, #2
  12:	4770      	bx	lr
  14:	2005      	movs	r0, #5
  16:	4770      	bx	lr
  18:	00000000 	.word	0x00000000
			18: R_ARM_ABS32	.bss.s_imu

Disassembly of section .text.SystemSourceSelector_GnssActiveInstanceGet:

00000000 <SystemSourceSelector_GnssActiveInstanceGet>:
   0:	b510      	push	{r4, lr}
   2:	b1d8      	cbz	r0, 3c <SystemSourceSelector_GnssActiveInstanceGet+0x3c>
   4:	4604      	mov	r4, r0
   6:	f7ff fffe 	bl	0 <PlatformCritical_Enter>
			6: R_ARM_THM_CALL	PlatformCritical_Enter
   a:	4b0f      	ldr	r3, [pc, #60]	@ (48 <SystemSourceSelector_GnssActiveInstanceGet+0x48>)
   c:	7c1a      	ldrb	r2, [r3, #16]
   e:	2a04      	cmp	r2, #4
  10:	d904      	bls.n	1c <SystemSourceSelector_GnssActiveInstanceGet+0x1c>
  12:	2409      	movs	r4, #9
  14:	f7ff fffe 	bl	0 <PlatformCritical_Exit>
			14: R_ARM_THM_CALL	PlatformCritical_Exit
  18:	4620      	mov	r0, r4
  1a:	bd10      	pop	{r4, pc}
  1c:	7c99      	ldrb	r1, [r3, #18]
  1e:	29ff      	cmp	r1, #255	@ 0xff
  20:	d00f      	beq.n	42 <SystemSourceSelector_GnssActiveInstanceGet+0x42>
  22:	428a      	cmp	r2, r1
  24:	d9f5      	bls.n	12 <SystemSourceSelector_GnssActiveInstanceGet+0x12>
  26:	f893 c013 	ldrb.w	ip, [r3, #19]
  2a:	4562      	cmp	r2, ip
  2c:	d9f1      	bls.n	12 <SystemSourceSelector_GnssActiveInstanceGet+0x12>
  2e:	f813 300c 	ldrb.w	r3, [r3, ip]
  32:	428b      	cmp	r3, r1
  34:	d1ed      	bne.n	12 <SystemSourceSelector_GnssActiveInstanceGet+0x12>
  36:	7023      	strb	r3, [r4, #0]
  38:	2400      	movs	r4, #0
  3a:	e7eb      	b.n	14 <SystemSourceSelector_GnssActiveInstanceGet+0x14>
  3c:	2405      	movs	r4, #5
  3e:	4620      	mov	r0, r4
  40:	bd10      	pop	{r4, pc}
  42:	2402      	movs	r4, #2
  44:	e7e6      	b.n	14 <SystemSourceSelector_GnssActiveInstanceGet+0x14>
  46:	bf00      	nop
  48:	00000000 	.word	0x00000000
			48: R_ARM_ABS32	.bss.s_gnss

Disassembly of section .text.SystemSourceSelector_TelemetryActiveInstanceGet:

00000000 <SystemSourceSelector_TelemetryActiveInstanceGet>:
   0:	b140      	cbz	r0, 14 <SystemSourceSelector_TelemetryActiveInstanceGet+0x14>
   2:	4b05      	ldr	r3, [pc, #20]	@ (18 <SystemSourceSelector_TelemetryActiveInstanceGet+0x18>)
   4:	7c9b      	ldrb	r3, [r3, #18]
   6:	2bff      	cmp	r3, #255	@ 0xff
   8:	d002      	beq.n	10 <SystemSourceSelector_TelemetryActiveInstanceGet+0x10>
   a:	7003      	strb	r3, [r0, #0]
   c:	2000      	movs	r0, #0
   e:	4770      	bx	lr
  10:	2002      	movs	r0, #2
  12:	4770      	bx	lr
  14:	2005      	movs	r0, #5
  16:	4770      	bx	lr
  18:	00000000 	.word	0x00000000
			18: R_ARM_ABS32	.bss.s_telemetry

Disassembly of section .text.SystemSourceSelector_TelemetryConsecutiveTimeoutCountGet:

00000000 <SystemSourceSelector_TelemetryConsecutiveTimeoutCountGet>:
   0:	4b01      	ldr	r3, [pc, #4]	@ (8 <SystemSourceSelector_TelemetryConsecutiveTimeoutCountGet+0x8>)
   2:	8a98      	ldrh	r0, [r3, #20]
   4:	4770      	bx	lr
   6:	bf00      	nop
   8:	00000000 	.word	0x00000000
			8: R_ARM_ABS32	.bss.s_telemetry

Disassembly of section .text.SystemImu_NameGet:

00000000 <SystemImu_NameGet>:
   0:	4b0a      	ldr	r3, [pc, #40]	@ (2c <SystemImu_NameGet+0x2c>)
   2:	7b98      	ldrb	r0, [r3, #14]
   4:	28ff      	cmp	r0, #255	@ 0xff
   6:	d101      	bne.n	c <SystemImu_NameGet+0xc>
   8:	4809      	ldr	r0, [pc, #36]	@ (30 <SystemImu_NameGet+0x30>)
   a:	4770      	bx	lr
   c:	b500      	push	{lr}
   e:	b087      	sub	sp, #28
  10:	a901      	add	r1, sp, #4
  12:	f7ff fffe 	bl	0 <ProjectImuInstance_InfoGet>
			12: R_ARM_THM_CALL	ProjectImuInstance_InfoGet
  16:	b920      	cbnz	r0, 22 <SystemImu_NameGet+0x22>
  18:	9801      	ldr	r0, [sp, #4]
  1a:	b110      	cbz	r0, 22 <SystemImu_NameGet+0x22>
  1c:	b007      	add	sp, #28
  1e:	f85d fb04 	ldr.w	pc, [sp], #4
  22:	4803      	ldr	r0, [pc, #12]	@ (30 <SystemImu_NameGet+0x30>)
  24:	b007      	add	sp, #28
  26:	f85d fb04 	ldr.w	pc, [sp], #4
  2a:	bf00      	nop
	...
			2c: R_ARM_ABS32	.bss.s_imu
			30: R_ARM_ABS32	.rodata.SystemImu_NameGet.str1.4

Disassembly of section .text.SystemImu_Init:

00000000 <SystemImu_Init>:
   0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
   4:	4c41      	ldr	r4, [pc, #260]	@ (10c <SystemImu_Init+0x10c>)
   6:	b083      	sub	sp, #12
   8:	2500      	movs	r5, #0
   a:	22ff      	movs	r2, #255	@ 0xff
   c:	f64f 73ff 	movw	r3, #65535	@ 0xffff
  10:	60e5      	str	r5, [r4, #12]
  12:	e9c4 5500 	strd	r5, r5, [r4]
  16:	60a5      	str	r5, [r4, #8]
  18:	7425      	strb	r5, [r4, #16]
  1a:	73e2      	strb	r2, [r4, #15]
  1c:	f8a4 300d 	strh.w	r3, [r4, #13]
  20:	f7ff fffe 	bl	0 <ProjectImuInstance_CountGet>
			20: R_ARM_THM_CALL	ProjectImuInstance_CountGet
  24:	2804      	cmp	r0, #4
  26:	7320      	strb	r0, [r4, #12]
  28:	d868      	bhi.n	fc <SystemImu_Init+0xfc>
  2a:	4601      	mov	r1, r0
  2c:	4622      	mov	r2, r4
  2e:	2001      	movs	r0, #1
  30:	f7ff fffe 	bl	0 <SystemImu_Init>
			30: R_ARM_THM_CALL	SystemSourceSelector_OrderBuild.part.0.constprop.0
  34:	7320      	strb	r0, [r4, #12]
  36:	2800      	cmp	r0, #0
  38:	d15d      	bne.n	f6 <SystemImu_Init+0xf6>
  3a:	2600      	movs	r6, #0
  3c:	f8df 80cc 	ldr.w	r8, [pc, #204]	@ 10c <SystemImu_Init+0x10c>
  40:	46b2      	mov	sl, r6
  42:	f04f 0b10 	mov.w	fp, #16
  46:	fa5f f986 	uxtb.w	r9, r6
  4a:	4548      	cmp	r0, r9
  4c:	4a30      	ldr	r2, [pc, #192]	@ (110 <SystemImu_Init+0x110>)
  4e:	f240 2339 	movw	r3, #569	@ 0x239
  52:	f04f 010c 	mov.w	r1, #12
  56:	d945      	bls.n	e4 <SystemImu_Init+0xe4>
  58:	f898 7000 	ldrb.w	r7, [r8]
  5c:	2503      	movs	r5, #3
  5e:	4287      	cmp	r7, r0
  60:	bf2c      	ite	cs
  62:	2000      	movcs	r0, #0
  64:	2001      	movcc	r0, #1
  66:	9500      	str	r5, [sp, #0]
  68:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			68: R_ARM_THM_CALL	SilverStarAssert_Check
  6c:	4638      	mov	r0, r7
  6e:	f7ff fffe 	bl	0 <ProjectImuInstance_Init>
			6e: R_ARM_THM_CALL	ProjectImuInstance_Init
  72:	2810      	cmp	r0, #16
  74:	f04f 0302 	mov.w	r3, #2
  78:	4605      	mov	r5, r0
  7a:	d912      	bls.n	a2 <SystemImu_Init+0xa2>
  7c:	9300      	str	r3, [sp, #0]
  7e:	4a24      	ldr	r2, [pc, #144]	@ (110 <SystemImu_Init+0x110>)
  80:	f44f 730f 	mov.w	r3, #572	@ 0x23c
  84:	210c      	movs	r1, #12
  86:	2000      	movs	r0, #0
  88:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			88: R_ARM_THM_CALL	SilverStarAssert_Check
  8c:	3601      	adds	r6, #1
  8e:	f1bb 0f10 	cmp.w	fp, #16
  92:	bf08      	it	eq
  94:	46ab      	moveq	fp, r5
  96:	2e04      	cmp	r6, #4
  98:	d024      	beq.n	e4 <SystemImu_Init+0xe4>
  9a:	7b20      	ldrb	r0, [r4, #12]
  9c:	f108 0801 	add.w	r8, r8, #1
  a0:	e7d1      	b.n	46 <SystemImu_Init+0x46>
  a2:	4a1b      	ldr	r2, [pc, #108]	@ (110 <SystemImu_Init+0x110>)
  a4:	9300      	str	r3, [sp, #0]
  a6:	210c      	movs	r1, #12
  a8:	f44f 730f 	mov.w	r3, #572	@ 0x23c
  ac:	2001      	movs	r0, #1
  ae:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			ae: R_ARM_THM_CALL	SilverStarAssert_Check
  b2:	2d0d      	cmp	r5, #13
  b4:	f10a 0201 	add.w	r2, sl, #1
  b8:	d8e8      	bhi.n	8c <SystemImu_Init+0x8c>
  ba:	f243 4303 	movw	r3, #13315	@ 0x3403
  be:	40eb      	lsrs	r3, r5
  c0:	07db      	lsls	r3, r3, #31
  c2:	d5e3      	bpl.n	8c <SystemImu_Init+0x8c>
  c4:	fa5f fa82 	uxtb.w	sl, r2
  c8:	7ba2      	ldrb	r2, [r4, #14]
  ca:	19e3      	adds	r3, r4, r7
  cc:	2aff      	cmp	r2, #255	@ 0xff
  ce:	f106 0601 	add.w	r6, r6, #1
  d2:	f04f 0101 	mov.w	r1, #1
  d6:	bf04      	itt	eq
  d8:	73a7      	strbeq	r7, [r4, #14]
  da:	f884 900f 	strbeq.w	r9, [r4, #15]
  de:	2e04      	cmp	r6, #4
  e0:	7119      	strb	r1, [r3, #4]
  e2:	d1da      	bne.n	9a <SystemImu_Init+0x9a>
  e4:	f1ba 0f00 	cmp.w	sl, #0
  e8:	bf18      	it	ne
  ea:	f04f 0b00 	movne.w	fp, #0
  ee:	4658      	mov	r0, fp
  f0:	b003      	add	sp, #12
  f2:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
  f6:	7823      	ldrb	r3, [r4, #0]
  f8:	7363      	strb	r3, [r4, #13]
  fa:	e79e      	b.n	3a <SystemImu_Init+0x3a>
  fc:	f04f 0b0b 	mov.w	fp, #11
 100:	4658      	mov	r0, fp
 102:	7325      	strb	r5, [r4, #12]
 104:	b003      	add	sp, #12
 106:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 10a:	bf00      	nop
	...
			10c: R_ARM_ABS32	.bss.s_imu
			110: R_ARM_ABS32	.rodata.SystemSourceSelector_GnssSelectionPublish.str1.4

Disassembly of section .text.SystemImu_Start:

00000000 <SystemImu_Start>:
   0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
   4:	4e35      	ldr	r6, [pc, #212]	@ (dc <SystemImu_Start+0xdc>)
   6:	4a36      	ldr	r2, [pc, #216]	@ (e0 <SystemImu_Start+0xe0>)
   8:	7b30      	ldrb	r0, [r6, #12]
   a:	b083      	sub	sp, #12
   c:	2804      	cmp	r0, #4
   e:	f04f 030a 	mov.w	r3, #10
  12:	9300      	str	r3, [sp, #0]
  14:	f04f 010c 	mov.w	r1, #12
  18:	f240 235e 	movw	r3, #606	@ 0x25e
  1c:	bf8c      	ite	hi
  1e:	2000      	movhi	r0, #0
  20:	2001      	movls	r0, #1
  22:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			22: R_ARM_THM_CALL	SilverStarAssert_Check
  26:	2400      	movs	r4, #0
  28:	46a2      	mov	sl, r4
  2a:	4637      	mov	r7, r6
  2c:	f04f 0802 	mov.w	r8, #2
  30:	f04f 0903 	mov.w	r9, #3
  34:	7b30      	ldrb	r0, [r6, #12]
  36:	4a2a      	ldr	r2, [pc, #168]	@ (e0 <SystemImu_Start+0xe0>)
  38:	b2e5      	uxtb	r5, r4
  3a:	42a8      	cmp	r0, r5
  3c:	f240 2369 	movw	r3, #617	@ 0x269
  40:	f04f 010c 	mov.w	r1, #12
  44:	d92a      	bls.n	9c <SystemImu_Start+0x9c>
  46:	f817 5b01 	ldrb.w	r5, [r7], #1
  4a:	f8cd 9000 	str.w	r9, [sp]
  4e:	42a8      	cmp	r0, r5
  50:	eb06 0b05 	add.w	fp, r6, r5
  54:	bf94      	ite	ls
  56:	2000      	movls	r0, #0
  58:	2001      	movhi	r0, #1
  5a:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			5a: R_ARM_THM_CALL	SilverStarAssert_Check
  5e:	f89b 3004 	ldrb.w	r3, [fp, #4]
  62:	4628      	mov	r0, r5
  64:	b1bb      	cbz	r3, 96 <SystemImu_Start+0x96>
  66:	f04f 0300 	mov.w	r3, #0
  6a:	f88b 3008 	strb.w	r3, [fp, #8]
  6e:	f7ff fffe 	bl	0 <ProjectImuInstance_Start>
			6e: R_ARM_THM_CALL	ProjectImuInstance_Start
  72:	2810      	cmp	r0, #16
  74:	4605      	mov	r5, r0
  76:	f04f 0302 	mov.w	r3, #2
  7a:	f04f 0000 	mov.w	r0, #0
  7e:	d915      	bls.n	ac <SystemImu_Start+0xac>
  80:	9300      	str	r3, [sp, #0]
  82:	4a17      	ldr	r2, [pc, #92]	@ (e0 <SystemImu_Start+0xe0>)
  84:	f240 2371 	movw	r3, #625	@ 0x271
  88:	210c      	movs	r1, #12
  8a:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			8a: R_ARM_THM_CALL	SilverStarAssert_Check
  8e:	f1b8 0f02 	cmp.w	r8, #2
  92:	bf08      	it	eq
  94:	46a8      	moveq	r8, r5
  96:	3401      	adds	r4, #1
  98:	2c04      	cmp	r4, #4
  9a:	d1cb      	bne.n	34 <SystemImu_Start+0x34>
  9c:	f1ba 0f00 	cmp.w	sl, #0
  a0:	bf0c      	ite	eq
  a2:	4640      	moveq	r0, r8
  a4:	2000      	movne	r0, #0
  a6:	b003      	add	sp, #12
  a8:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
  ac:	9300      	str	r3, [sp, #0]
  ae:	4a0c      	ldr	r2, [pc, #48]	@ (e0 <SystemImu_Start+0xe0>)
  b0:	f240 2371 	movw	r3, #625	@ 0x271
  b4:	210c      	movs	r1, #12
  b6:	2001      	movs	r0, #1
  b8:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			b8: R_ARM_THM_CALL	SilverStarAssert_Check
  bc:	2d0d      	cmp	r5, #13
  be:	d8e6      	bhi.n	8e <SystemImu_Start+0x8e>
  c0:	f243 4303 	movw	r3, #13315	@ 0x3403
  c4:	40eb      	lsrs	r3, r5
  c6:	07db      	lsls	r3, r3, #31
  c8:	f10a 0201 	add.w	r2, sl, #1
  cc:	d5df      	bpl.n	8e <SystemImu_Start+0x8e>
  ce:	2301      	movs	r3, #1
  d0:	fa5f fa82 	uxtb.w	sl, r2
  d4:	f88b 3008 	strb.w	r3, [fp, #8]
  d8:	e7dd      	b.n	96 <SystemImu_Start+0x96>
  da:	bf00      	nop
	...
			dc: R_ARM_ABS32	.bss.s_imu
			e0: R_ARM_ABS32	.rodata.SystemSourceSelector_GnssSelectionPublish.str1.4

Disassembly of section .text.SystemImu_Stop:

00000000 <SystemImu_Stop>:
   0:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
   4:	4d0d      	ldr	r5, [pc, #52]	@ (3c <SystemImu_Stop+0x3c>)
   6:	2400      	movs	r4, #0
   8:	462f      	mov	r7, r5
   a:	46a1      	mov	r9, r4
   c:	46a0      	mov	r8, r4
   e:	7b2a      	ldrb	r2, [r5, #12]
  10:	b2e3      	uxtb	r3, r4
  12:	429a      	cmp	r2, r3
  14:	d90f      	bls.n	36 <SystemImu_Stop+0x36>
  16:	f817 0b01 	ldrb.w	r0, [r7], #1
  1a:	182e      	adds	r6, r5, r0
  1c:	7a33      	ldrb	r3, [r6, #8]
  1e:	b13b      	cbz	r3, 30 <SystemImu_Stop+0x30>
  20:	f7ff fffe 	bl	0 <ProjectImuInstance_Stop>
			20: R_ARM_THM_CALL	ProjectImuInstance_Stop
  24:	2800      	cmp	r0, #0
  26:	bf18      	it	ne
  28:	f04f 0907 	movne.w	r9, #7
  2c:	f886 8008 	strb.w	r8, [r6, #8]
  30:	3401      	adds	r4, #1
  32:	2c04      	cmp	r4, #4
  34:	d1eb      	bne.n	e <SystemImu_Stop+0xe>
  36:	4648      	mov	r0, r9
  38:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
  3c:	00000000 	.word	0x00000000
			3c: R_ARM_ABS32	.bss.s_imu

Disassembly of section .text.SystemImu_RuntimeOwnerActivate:

00000000 <SystemImu_RuntimeOwnerActivate>:
   0:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
   4:	4e0d      	ldr	r6, [pc, #52]	@ (3c <SystemImu_RuntimeOwnerActivate+0x3c>)
   6:	2400      	movs	r4, #0
   8:	4637      	mov	r7, r6
   a:	f04f 0802 	mov.w	r8, #2
   e:	7b32      	ldrb	r2, [r6, #12]
  10:	b2e3      	uxtb	r3, r4
  12:	429a      	cmp	r2, r3
  14:	d90e      	bls.n	34 <SystemImu_RuntimeOwnerActivate+0x34>
  16:	f817 5b01 	ldrb.w	r5, [r7], #1
  1a:	1973      	adds	r3, r6, r5
  1c:	4628      	mov	r0, r5
  1e:	791b      	ldrb	r3, [r3, #4]
  20:	b12b      	cbz	r3, 2e <SystemImu_RuntimeOwnerActivate+0x2e>
  22:	f7ff fffe 	bl	0 <ProjectImuInstance_RuntimeOwnerActivate>
			22: R_ARM_THM_CALL	ProjectImuInstance_RuntimeOwnerActivate
  26:	7bb3      	ldrb	r3, [r6, #14]
  28:	42ab      	cmp	r3, r5
  2a:	bf08      	it	eq
  2c:	4680      	moveq	r8, r0
  2e:	3401      	adds	r4, #1
  30:	2c04      	cmp	r4, #4
  32:	d1ec      	bne.n	e <SystemImu_RuntimeOwnerActivate+0xe>
  34:	4640      	mov	r0, r8
  36:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
  3a:	bf00      	nop
  3c:	00000000 	.word	0x00000000
			3c: R_ARM_ABS32	.bss.s_imu

Disassembly of section .text.SystemImu_Process:

00000000 <SystemImu_Process>:
   0:	b570      	push	{r4, r5, r6, lr}
   2:	4d0f      	ldr	r5, [pc, #60]	@ (40 <SystemImu_Process+0x40>)
   4:	2400      	movs	r4, #0
   6:	462e      	mov	r6, r5
   8:	7b2a      	ldrb	r2, [r5, #12]
   a:	b2e3      	uxtb	r3, r4
   c:	429a      	cmp	r2, r3
   e:	d907      	bls.n	20 <SystemImu_Process+0x20>
  10:	f816 0b01 	ldrb.w	r0, [r6], #1
  14:	182b      	adds	r3, r5, r0
  16:	7a1b      	ldrb	r3, [r3, #8]
  18:	b943      	cbnz	r3, 2c <SystemImu_Process+0x2c>
  1a:	3401      	adds	r4, #1
  1c:	2c04      	cmp	r4, #4
  1e:	d1f3      	bne.n	8 <SystemImu_Process+0x8>
  20:	7c2b      	ldrb	r3, [r5, #16]
  22:	b133      	cbz	r3, 32 <SystemImu_Process+0x32>
  24:	e8bd 4070 	ldmia.w	sp!, {r4, r5, r6, lr}
  28:	f7ff bffe 	b.w	0 <SystemImu_Process>
			28: R_ARM_THM_JUMP24	SystemSourceSelector_PendingEventsFlush
  2c:	f7ff fffe 	bl	0 <ProjectImuInstance_Process>
			2c: R_ARM_THM_CALL	ProjectImuInstance_Process
  30:	e7f3      	b.n	1a <SystemImu_Process+0x1a>
  32:	f7ff fffe 	bl	0 <SystemImu_Process>
			32: R_ARM_THM_CALL	SystemSourceSelector_ImuFreshSelect
  36:	e8bd 4070 	ldmia.w	sp!, {r4, r5, r6, lr}
  3a:	f7ff bffe 	b.w	0 <SystemImu_Process>
			3a: R_ARM_THM_JUMP24	SystemSourceSelector_PendingEventsFlush
  3e:	bf00      	nop
  40:	00000000 	.word	0x00000000
			40: R_ARM_ABS32	.bss.s_imu

Disassembly of section .text.SystemImu_InfoGet:

00000000 <SystemImu_InfoGet>:
   0:	4601      	mov	r1, r0
   2:	b138      	cbz	r0, 14 <SystemImu_InfoGet+0x14>
   4:	4b04      	ldr	r3, [pc, #16]	@ (18 <SystemImu_InfoGet+0x18>)
   6:	7b98      	ldrb	r0, [r3, #14]
   8:	28ff      	cmp	r0, #255	@ 0xff
   a:	d001      	beq.n	10 <SystemImu_InfoGet+0x10>
   c:	f7ff bffe 	b.w	0 <ProjectImuInstance_InfoGet>
			c: R_ARM_THM_JUMP24	ProjectImuInstance_InfoGet
  10:	2002      	movs	r0, #2
  12:	4770      	bx	lr
  14:	2005      	movs	r0, #5
  16:	4770      	bx	lr
  18:	00000000 	.word	0x00000000
			18: R_ARM_ABS32	.bss.s_imu

Disassembly of section .text.SystemImu_CapabilitiesGet:

00000000 <SystemImu_CapabilitiesGet>:
   0:	4601      	mov	r1, r0
   2:	b138      	cbz	r0, 14 <SystemImu_CapabilitiesGet+0x14>
   4:	4b04      	ldr	r3, [pc, #16]	@ (18 <SystemImu_CapabilitiesGet+0x18>)
   6:	7b98      	ldrb	r0, [r3, #14]
   8:	28ff      	cmp	r0, #255	@ 0xff
   a:	d001      	beq.n	10 <SystemImu_CapabilitiesGet+0x10>
   c:	f7ff bffe 	b.w	0 <ProjectImuInstance_CapabilitiesGet>
			c: R_ARM_THM_JUMP24	ProjectImuInstance_CapabilitiesGet
  10:	2002      	movs	r0, #2
  12:	4770      	bx	lr
  14:	2005      	movs	r0, #5
  16:	4770      	bx	lr
  18:	00000000 	.word	0x00000000
			18: R_ARM_ABS32	.bss.s_imu

Disassembly of section .text.SystemImu_HealthGet:

00000000 <SystemImu_HealthGet>:
   0:	4601      	mov	r1, r0
   2:	b138      	cbz	r0, 14 <SystemImu_HealthGet+0x14>
   4:	4b04      	ldr	r3, [pc, #16]	@ (18 <SystemImu_HealthGet+0x18>)
   6:	7b98      	ldrb	r0, [r3, #14]
   8:	28ff      	cmp	r0, #255	@ 0xff
   a:	d001      	beq.n	10 <SystemImu_HealthGet+0x10>
   c:	f7ff bffe 	b.w	0 <ProjectImuInstance_HealthGet>
			c: R_ARM_THM_JUMP24	ProjectImuInstance_HealthGet
  10:	2002      	movs	r0, #2
  12:	4770      	bx	lr
  14:	2005      	movs	r0, #5
  16:	4770      	bx	lr
  18:	00000000 	.word	0x00000000
			18: R_ARM_ABS32	.bss.s_imu

Disassembly of section .text.SystemImu_IoDiagnosticsGet:

00000000 <SystemImu_IoDiagnosticsGet>:
   0:	4601      	mov	r1, r0
   2:	b138      	cbz	r0, 14 <SystemImu_IoDiagnosticsGet+0x14>
   4:	4b04      	ldr	r3, [pc, #16]	@ (18 <SystemImu_IoDiagnosticsGet+0x18>)
   6:	7b98      	ldrb	r0, [r3, #14]
   8:	28ff      	cmp	r0, #255	@ 0xff
   a:	d001      	beq.n	10 <SystemImu_IoDiagnosticsGet+0x10>
   c:	f7ff bffe 	b.w	0 <ProjectImuInstance_IoDiagnosticsGet>
			c: R_ARM_THM_JUMP24	ProjectImuInstance_IoDiagnosticsGet
  10:	2002      	movs	r0, #2
  12:	4770      	bx	lr
  14:	2005      	movs	r0, #5
  16:	4770      	bx	lr
  18:	00000000 	.word	0x00000000
			18: R_ARM_ABS32	.bss.s_imu

Disassembly of section .text.SystemImu_IoDetailGet:

00000000 <SystemImu_IoDetailGet>:
   0:	4601      	mov	r1, r0
   2:	b138      	cbz	r0, 14 <SystemImu_IoDetailGet+0x14>
   4:	4b04      	ldr	r3, [pc, #16]	@ (18 <SystemImu_IoDetailGet+0x18>)
   6:	7b98      	ldrb	r0, [r3, #14]
   8:	28ff      	cmp	r0, #255	@ 0xff
   a:	d001      	beq.n	10 <SystemImu_IoDetailGet+0x10>
   c:	f7ff bffe 	b.w	0 <ProjectImuInstance_IoDetailGet>
			c: R_ARM_THM_JUMP24	ProjectImuInstance_IoDetailGet
  10:	2002      	movs	r0, #2
  12:	4770      	bx	lr
  14:	2005      	movs	r0, #5
  16:	4770      	bx	lr
  18:	00000000 	.word	0x00000000
			18: R_ARM_ABS32	.bss.s_imu

Disassembly of section .text.SystemImu_LatestSampleGet:

00000000 <SystemImu_LatestSampleGet>:
   0:	b198      	cbz	r0, 2a <SystemImu_LatestSampleGet+0x2a>
   2:	b538      	push	{r3, r4, r5, lr}
   4:	4d0a      	ldr	r5, [pc, #40]	@ (30 <SystemImu_LatestSampleGet+0x30>)
   6:	7c2b      	ldrb	r3, [r5, #16]
   8:	4604      	mov	r4, r0
   a:	b13b      	cbz	r3, 1c <SystemImu_LatestSampleGet+0x1c>
   c:	7ba8      	ldrb	r0, [r5, #14]
   e:	28ff      	cmp	r0, #255	@ 0xff
  10:	d009      	beq.n	26 <SystemImu_LatestSampleGet+0x26>
  12:	4621      	mov	r1, r4
  14:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
  18:	f7ff bffe 	b.w	0 <ProjectImuInstance_LatestSampleGet>
			18: R_ARM_THM_JUMP24	ProjectImuInstance_LatestSampleGet
  1c:	f7ff fffe 	bl	0 <SystemImu_LatestSampleGet>
			1c: R_ARM_THM_CALL	SystemSourceSelector_ImuFreshSelect
  20:	7ba8      	ldrb	r0, [r5, #14]
  22:	28ff      	cmp	r0, #255	@ 0xff
  24:	d1f5      	bne.n	12 <SystemImu_LatestSampleGet+0x12>
  26:	2002      	movs	r0, #2
  28:	bd38      	pop	{r3, r4, r5, pc}
  2a:	2005      	movs	r0, #5
  2c:	4770      	bx	lr
  2e:	bf00      	nop
  30:	00000000 	.word	0x00000000
			30: R_ARM_ABS32	.bss.s_imu

Disassembly of section .text.SystemImu_NextSampleGet:

00000000 <SystemImu_NextSampleGet>:
   0:	4601      	mov	r1, r0
   2:	b138      	cbz	r0, 14 <SystemImu_NextSampleGet+0x14>
   4:	4b04      	ldr	r3, [pc, #16]	@ (18 <SystemImu_NextSampleGet+0x18>)
   6:	7b98      	ldrb	r0, [r3, #14]
   8:	28ff      	cmp	r0, #255	@ 0xff
   a:	d001      	beq.n	10 <SystemImu_NextSampleGet+0x10>
   c:	f7ff bffe 	b.w	0 <ProjectImuInstance_NextSampleGet>
			c: R_ARM_THM_JUMP24	ProjectImuInstance_NextSampleGet
  10:	2002      	movs	r0, #2
  12:	4770      	bx	lr
  14:	2005      	movs	r0, #5
  16:	4770      	bx	lr
  18:	00000000 	.word	0x00000000
			18: R_ARM_ABS32	.bss.s_imu

Disassembly of section .text.SystemImu_SelfTestRun:

00000000 <SystemImu_SelfTestRun>:
   0:	4601      	mov	r1, r0
   2:	b138      	cbz	r0, 14 <SystemImu_SelfTestRun+0x14>
   4:	4b04      	ldr	r3, [pc, #16]	@ (18 <SystemImu_SelfTestRun+0x18>)
   6:	7b98      	ldrb	r0, [r3, #14]
   8:	28ff      	cmp	r0, #255	@ 0xff
   a:	d001      	beq.n	10 <SystemImu_SelfTestRun+0x10>
   c:	f7ff bffe 	b.w	0 <ProjectImuInstance_SelfTestRun>
			c: R_ARM_THM_JUMP24	ProjectImuInstance_SelfTestRun
  10:	2002      	movs	r0, #2
  12:	4770      	bx	lr
  14:	2005      	movs	r0, #5
  16:	4770      	bx	lr
  18:	00000000 	.word	0x00000000
			18: R_ARM_ABS32	.bss.s_imu

Disassembly of section .text.SystemImu_ConfigApply:

00000000 <SystemImu_ConfigApply>:
   0:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
   4:	b090      	sub	sp, #64	@ 0x40
   6:	2800      	cmp	r0, #0
   8:	d046      	beq.n	98 <SystemImu_ConfigApply+0x98>
   a:	460f      	mov	r7, r1
   c:	2900      	cmp	r1, #0
   e:	d043      	beq.n	98 <SystemImu_ConfigApply+0x98>
  10:	f44f 7248 	mov.w	r2, #800	@ 0x320
  14:	9200      	str	r2, [sp, #0]
  16:	4b23      	ldr	r3, [pc, #140]	@ (a4 <SystemImu_ConfigApply+0xa4>)
  18:	4c23      	ldr	r4, [pc, #140]	@ (a8 <SystemImu_ConfigApply+0xa8>)
  1a:	220c      	movs	r2, #12
  1c:	2104      	movs	r1, #4
  1e:	4606      	mov	r6, r0
  20:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			20: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  24:	f104 0804 	add.w	r8, r4, #4
  28:	4625      	mov	r5, r4
  2a:	f04f 0902 	mov.w	r9, #2
  2e:	f894 c00c 	ldrb.w	ip, [r4, #12]
  32:	1b2b      	subs	r3, r5, r4
  34:	b2db      	uxtb	r3, r3
  36:	459c      	cmp	ip, r3
  38:	f04f 0234 	mov.w	r2, #52	@ 0x34
  3c:	f04f 0100 	mov.w	r1, #0
  40:	a803      	add	r0, sp, #12
  42:	d925      	bls.n	90 <SystemImu_ConfigApply+0x90>
  44:	f815 ab01 	ldrb.w	sl, [r5], #1
  48:	eb04 030a 	add.w	r3, r4, sl
  4c:	791b      	ldrb	r3, [r3, #4]
  4e:	b1eb      	cbz	r3, 8c <SystemImu_ConfigApply+0x8c>
  50:	f7ff fffe 	bl	0 <memset>
			50: R_ARM_THM_CALL	memset
  54:	aa03      	add	r2, sp, #12
  56:	4631      	mov	r1, r6
  58:	4650      	mov	r0, sl
  5a:	f7ff fffe 	bl	0 <ProjectImuInstance_ConfigApply>
			5a: R_ARM_THM_CALL	ProjectImuInstance_ConfigApply
  5e:	7ba3      	ldrb	r3, [r4, #14]
  60:	4553      	cmp	r3, sl
  62:	d113      	bne.n	8c <SystemImu_ConfigApply+0x8c>
  64:	f10d 0e0c 	add.w	lr, sp, #12
  68:	4681      	mov	r9, r0
  6a:	e8be 000f 	ldmia.w	lr!, {r0, r1, r2, r3}
  6e:	46bc      	mov	ip, r7
  70:	e8ac 000f 	stmia.w	ip!, {r0, r1, r2, r3}
  74:	e8be 000f 	ldmia.w	lr!, {r0, r1, r2, r3}
  78:	e8ac 000f 	stmia.w	ip!, {r0, r1, r2, r3}
  7c:	e8be 000f 	ldmia.w	lr!, {r0, r1, r2, r3}
  80:	e8ac 000f 	stmia.w	ip!, {r0, r1, r2, r3}
  84:	f8de 3000 	ldr.w	r3, [lr]
  88:	f8cc 3000 	str.w	r3, [ip]
  8c:	4545      	cmp	r5, r8
  8e:	d1ce      	bne.n	2e <SystemImu_ConfigApply+0x2e>
  90:	4648      	mov	r0, r9
  92:	b010      	add	sp, #64	@ 0x40
  94:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
  98:	f04f 0905 	mov.w	r9, #5
  9c:	4648      	mov	r0, r9
  9e:	b010      	add	sp, #64	@ 0x40
  a0:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
	...
			a4: R_ARM_ABS32	.rodata.SystemSourceSelector_GnssSelectionPublish.str1.4
			a8: R_ARM_ABS32	.bss.s_imu

Disassembly of section .text.SystemImu_ConfigVerify:

00000000 <SystemImu_ConfigVerify>:
   0:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
   4:	b090      	sub	sp, #64	@ 0x40
   6:	2800      	cmp	r0, #0
   8:	d046      	beq.n	98 <SystemImu_ConfigVerify+0x98>
   a:	460f      	mov	r7, r1
   c:	2900      	cmp	r1, #0
   e:	d043      	beq.n	98 <SystemImu_ConfigVerify+0x98>
  10:	f240 3243 	movw	r2, #835	@ 0x343
  14:	9200      	str	r2, [sp, #0]
  16:	4b23      	ldr	r3, [pc, #140]	@ (a4 <SystemImu_ConfigVerify+0xa4>)
  18:	4c23      	ldr	r4, [pc, #140]	@ (a8 <SystemImu_ConfigVerify+0xa8>)
  1a:	220c      	movs	r2, #12
  1c:	2104      	movs	r1, #4
  1e:	4606      	mov	r6, r0
  20:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			20: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  24:	f104 0804 	add.w	r8, r4, #4
  28:	4625      	mov	r5, r4
  2a:	f04f 0902 	mov.w	r9, #2
  2e:	f894 c00c 	ldrb.w	ip, [r4, #12]
  32:	1b2b      	subs	r3, r5, r4
  34:	b2db      	uxtb	r3, r3
  36:	459c      	cmp	ip, r3
  38:	f04f 0234 	mov.w	r2, #52	@ 0x34
  3c:	f04f 0100 	mov.w	r1, #0
  40:	a803      	add	r0, sp, #12
  42:	d925      	bls.n	90 <SystemImu_ConfigVerify+0x90>
  44:	f815 ab01 	ldrb.w	sl, [r5], #1
  48:	eb04 030a 	add.w	r3, r4, sl
  4c:	791b      	ldrb	r3, [r3, #4]
  4e:	b1eb      	cbz	r3, 8c <SystemImu_ConfigVerify+0x8c>
  50:	f7ff fffe 	bl	0 <memset>
			50: R_ARM_THM_CALL	memset
  54:	aa03      	add	r2, sp, #12
  56:	4631      	mov	r1, r6
  58:	4650      	mov	r0, sl
  5a:	f7ff fffe 	bl	0 <ProjectImuInstance_ConfigVerify>
			5a: R_ARM_THM_CALL	ProjectImuInstance_ConfigVerify
  5e:	7ba3      	ldrb	r3, [r4, #14]
  60:	4553      	cmp	r3, sl
  62:	d113      	bne.n	8c <SystemImu_ConfigVerify+0x8c>
  64:	f10d 0e0c 	add.w	lr, sp, #12
  68:	4681      	mov	r9, r0
  6a:	e8be 000f 	ldmia.w	lr!, {r0, r1, r2, r3}
  6e:	46bc      	mov	ip, r7
  70:	e8ac 000f 	stmia.w	ip!, {r0, r1, r2, r3}
  74:	e8be 000f 	ldmia.w	lr!, {r0, r1, r2, r3}
  78:	e8ac 000f 	stmia.w	ip!, {r0, r1, r2, r3}
  7c:	e8be 000f 	ldmia.w	lr!, {r0, r1, r2, r3}
  80:	e8ac 000f 	stmia.w	ip!, {r0, r1, r2, r3}
  84:	f8de 3000 	ldr.w	r3, [lr]
  88:	f8cc 3000 	str.w	r3, [ip]
  8c:	4545      	cmp	r5, r8
  8e:	d1ce      	bne.n	2e <SystemImu_ConfigVerify+0x2e>
  90:	4648      	mov	r0, r9
  92:	b010      	add	sp, #64	@ 0x40
  94:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
  98:	f04f 0905 	mov.w	r9, #5
  9c:	4648      	mov	r0, r9
  9e:	b010      	add	sp, #64	@ 0x40
  a0:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
	...
			a4: R_ARM_ABS32	.rodata.SystemSourceSelector_GnssSelectionPublish.str1.4
			a8: R_ARM_ABS32	.bss.s_imu

Disassembly of section .text.SystemImu_EffectiveConfigGet:

00000000 <SystemImu_EffectiveConfigGet>:
   0:	4601      	mov	r1, r0
   2:	b138      	cbz	r0, 14 <SystemImu_EffectiveConfigGet+0x14>
   4:	4b04      	ldr	r3, [pc, #16]	@ (18 <SystemImu_EffectiveConfigGet+0x18>)
   6:	7b98      	ldrb	r0, [r3, #14]
   8:	28ff      	cmp	r0, #255	@ 0xff
   a:	d001      	beq.n	10 <SystemImu_EffectiveConfigGet+0x10>
   c:	f7ff bffe 	b.w	0 <ProjectImuInstance_EffectiveConfigGet>
			c: R_ARM_THM_JUMP24	ProjectImuInstance_EffectiveConfigGet
  10:	2002      	movs	r0, #2
  12:	4770      	bx	lr
  14:	2005      	movs	r0, #5
  16:	4770      	bx	lr
  18:	00000000 	.word	0x00000000
			18: R_ARM_ABS32	.bss.s_imu

Disassembly of section .text.SystemImu_NoiseCharacteristicsGet:

00000000 <SystemImu_NoiseCharacteristicsGet>:
   0:	4601      	mov	r1, r0
   2:	b138      	cbz	r0, 14 <SystemImu_NoiseCharacteristicsGet+0x14>
   4:	4b04      	ldr	r3, [pc, #16]	@ (18 <SystemImu_NoiseCharacteristicsGet+0x18>)
   6:	7b98      	ldrb	r0, [r3, #14]
   8:	28ff      	cmp	r0, #255	@ 0xff
   a:	d001      	beq.n	10 <SystemImu_NoiseCharacteristicsGet+0x10>
   c:	f7ff bffe 	b.w	0 <ProjectImuInstance_NoiseCharacteristicsGet>
			c: R_ARM_THM_JUMP24	ProjectImuInstance_NoiseCharacteristicsGet
  10:	2002      	movs	r0, #2
  12:	4770      	bx	lr
  14:	2005      	movs	r0, #5
  16:	4770      	bx	lr
  18:	00000000 	.word	0x00000000
			18: R_ARM_ABS32	.bss.s_imu

Disassembly of section .text.SystemGnss_NameGet:

00000000 <SystemGnss_NameGet>:
   0:	4b0a      	ldr	r3, [pc, #40]	@ (2c <SystemGnss_NameGet+0x2c>)
   2:	7c98      	ldrb	r0, [r3, #18]
   4:	28ff      	cmp	r0, #255	@ 0xff
   6:	d101      	bne.n	c <SystemGnss_NameGet+0xc>
   8:	4809      	ldr	r0, [pc, #36]	@ (30 <SystemGnss_NameGet+0x30>)
   a:	4770      	bx	lr
   c:	b500      	push	{lr}
   e:	b087      	sub	sp, #28
  10:	a901      	add	r1, sp, #4
  12:	f7ff fffe 	bl	0 <ProjectGnssInstance_InfoGet>
			12: R_ARM_THM_CALL	ProjectGnssInstance_InfoGet
  16:	b920      	cbnz	r0, 22 <SystemGnss_NameGet+0x22>
  18:	9801      	ldr	r0, [sp, #4]
  1a:	b110      	cbz	r0, 22 <SystemGnss_NameGet+0x22>
  1c:	b007      	add	sp, #28
  1e:	f85d fb04 	ldr.w	pc, [sp], #4
  22:	4803      	ldr	r0, [pc, #12]	@ (30 <SystemGnss_NameGet+0x30>)
  24:	b007      	add	sp, #28
  26:	f85d fb04 	ldr.w	pc, [sp], #4
  2a:	bf00      	nop
	...
			2c: R_ARM_ABS32	.bss.s_gnss
			30: R_ARM_ABS32	.rodata.SystemGnss_NameGet.str1.4

Disassembly of section .text.SystemGnss_Init:

00000000 <SystemGnss_Init>:
   0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
   4:	4c46      	ldr	r4, [pc, #280]	@ (120 <SystemGnss_Init+0x120>)
   6:	b083      	sub	sp, #12
   8:	2238      	movs	r2, #56	@ 0x38
   a:	2100      	movs	r1, #0
   c:	4620      	mov	r0, r4
   e:	f7ff fffe 	bl	0 <memset>
			e: R_ARM_THM_CALL	memset
  12:	22ff      	movs	r2, #255	@ 0xff
  14:	f64f 73ff 	movw	r3, #65535	@ 0xffff
  18:	74e2      	strb	r2, [r4, #19]
  1a:	f8a4 3011 	strh.w	r3, [r4, #17]
  1e:	f7ff fffe 	bl	0 <ProjectGnssInstance_CountGet>
			1e: R_ARM_THM_CALL	ProjectGnssInstance_CountGet
  22:	2804      	cmp	r0, #4
  24:	7420      	strb	r0, [r4, #16]
  26:	d872      	bhi.n	10e <SystemGnss_Init+0x10e>
  28:	4601      	mov	r1, r0
  2a:	4622      	mov	r2, r4
  2c:	2002      	movs	r0, #2
  2e:	f7ff fffe 	bl	0 <SystemGnss_Init>
			2e: R_ARM_THM_CALL	SystemSourceSelector_OrderBuild.part.0.constprop.0
  32:	7420      	strb	r0, [r4, #16]
  34:	2800      	cmp	r0, #0
  36:	d167      	bne.n	108 <SystemGnss_Init+0x108>
  38:	2600      	movs	r6, #0
  3a:	f8df 90e4 	ldr.w	r9, [pc, #228]	@ 120 <SystemGnss_Init+0x120>
  3e:	46b3      	mov	fp, r6
  40:	f04f 0810 	mov.w	r8, #16
  44:	fa5f fa86 	uxtb.w	sl, r6
  48:	4550      	cmp	r0, sl
  4a:	4a36      	ldr	r2, [pc, #216]	@ (124 <SystemGnss_Init+0x124>)
  4c:	f240 4355 	movw	r3, #1109	@ 0x455
  50:	f04f 010c 	mov.w	r1, #12
  54:	d945      	bls.n	e2 <SystemGnss_Init+0xe2>
  56:	f899 7000 	ldrb.w	r7, [r9]
  5a:	2503      	movs	r5, #3
  5c:	4287      	cmp	r7, r0
  5e:	bf2c      	ite	cs
  60:	2000      	movcs	r0, #0
  62:	2001      	movcc	r0, #1
  64:	9500      	str	r5, [sp, #0]
  66:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			66: R_ARM_THM_CALL	SilverStarAssert_Check
  6a:	4638      	mov	r0, r7
  6c:	f7ff fffe 	bl	0 <ProjectGnssInstance_Init>
			6c: R_ARM_THM_CALL	ProjectGnssInstance_Init
  70:	2810      	cmp	r0, #16
  72:	f04f 0302 	mov.w	r3, #2
  76:	4605      	mov	r5, r0
  78:	d912      	bls.n	a0 <SystemGnss_Init+0xa0>
  7a:	9300      	str	r3, [sp, #0]
  7c:	4a29      	ldr	r2, [pc, #164]	@ (124 <SystemGnss_Init+0x124>)
  7e:	f44f 638b 	mov.w	r3, #1112	@ 0x458
  82:	210c      	movs	r1, #12
  84:	2000      	movs	r0, #0
  86:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			86: R_ARM_THM_CALL	SilverStarAssert_Check
  8a:	f1b8 0f10 	cmp.w	r8, #16
  8e:	bf08      	it	eq
  90:	46a8      	moveq	r8, r5
  92:	3601      	adds	r6, #1
  94:	2e04      	cmp	r6, #4
  96:	d024      	beq.n	e2 <SystemGnss_Init+0xe2>
  98:	7c20      	ldrb	r0, [r4, #16]
  9a:	f109 0901 	add.w	r9, r9, #1
  9e:	e7d1      	b.n	44 <SystemGnss_Init+0x44>
  a0:	4a20      	ldr	r2, [pc, #128]	@ (124 <SystemGnss_Init+0x124>)
  a2:	9300      	str	r3, [sp, #0]
  a4:	210c      	movs	r1, #12
  a6:	f44f 638b 	mov.w	r3, #1112	@ 0x458
  aa:	2001      	movs	r0, #1
  ac:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			ac: R_ARM_THM_CALL	SilverStarAssert_Check
  b0:	2d0d      	cmp	r5, #13
  b2:	f10b 0201 	add.w	r2, fp, #1
  b6:	d8e8      	bhi.n	8a <SystemGnss_Init+0x8a>
  b8:	f243 4303 	movw	r3, #13315	@ 0x3403
  bc:	40eb      	lsrs	r3, r5
  be:	07db      	lsls	r3, r3, #31
  c0:	d5e3      	bpl.n	8a <SystemGnss_Init+0x8a>
  c2:	fa5f fb82 	uxtb.w	fp, r2
  c6:	7ca2      	ldrb	r2, [r4, #18]
  c8:	19e3      	adds	r3, r4, r7
  ca:	2101      	movs	r1, #1
  cc:	2aff      	cmp	r2, #255	@ 0xff
  ce:	7119      	strb	r1, [r3, #4]
  d0:	d1df      	bne.n	92 <SystemGnss_Init+0x92>
  d2:	4651      	mov	r1, sl
  d4:	4638      	mov	r0, r7
  d6:	2200      	movs	r2, #0
  d8:	3601      	adds	r6, #1
  da:	f7ff fffe 	bl	0 <SystemGnss_Init>
			da: R_ARM_THM_CALL	SystemSourceSelector_GnssSelectionPublish
  de:	2e04      	cmp	r6, #4
  e0:	d1da      	bne.n	98 <SystemGnss_Init+0x98>
  e2:	7ca2      	ldrb	r2, [r4, #18]
  e4:	2aff      	cmp	r2, #255	@ 0xff
  e6:	d006      	beq.n	f6 <SystemGnss_Init+0xf6>
  e8:	7c61      	ldrb	r1, [r4, #17]
  ea:	428a      	cmp	r2, r1
  ec:	d003      	beq.n	f6 <SystemGnss_Init+0xf6>
  ee:	2305      	movs	r3, #5
  f0:	2002      	movs	r0, #2
  f2:	f7ff fffe 	bl	0 <SystemGnss_Init>
			f2: R_ARM_THM_CALL	SystemSourceSelector_EventRecord
  f6:	f1bb 0f00 	cmp.w	fp, #0
  fa:	bf18      	it	ne
  fc:	f04f 0800 	movne.w	r8, #0
 100:	4640      	mov	r0, r8
 102:	b003      	add	sp, #12
 104:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 108:	7823      	ldrb	r3, [r4, #0]
 10a:	7463      	strb	r3, [r4, #17]
 10c:	e794      	b.n	38 <SystemGnss_Init+0x38>
 10e:	f04f 080b 	mov.w	r8, #11
 112:	2300      	movs	r3, #0
 114:	4640      	mov	r0, r8
 116:	7423      	strb	r3, [r4, #16]
 118:	b003      	add	sp, #12
 11a:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 11e:	bf00      	nop
	...
			120: R_ARM_ABS32	.bss.s_gnss
			124: R_ARM_ABS32	.rodata.SystemSourceSelector_GnssSelectionPublish.str1.4

Disassembly of section .text.SystemGnss_Start:

00000000 <SystemGnss_Start>:
   0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
   4:	4c5c      	ldr	r4, [pc, #368]	@ (178 <SystemGnss_Start+0x178>)
   6:	4a5d      	ldr	r2, [pc, #372]	@ (17c <SystemGnss_Start+0x17c>)
   8:	7c20      	ldrb	r0, [r4, #16]
   a:	b087      	sub	sp, #28
   c:	2804      	cmp	r0, #4
   e:	f04f 030a 	mov.w	r3, #10
  12:	bf8c      	ite	hi
  14:	2000      	movhi	r0, #0
  16:	2001      	movls	r0, #1
  18:	9300      	str	r3, [sp, #0]
  1a:	210c      	movs	r1, #12
  1c:	f240 4386 	movw	r3, #1158	@ 0x486
  20:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			20: R_ARM_THM_CALL	SilverStarAssert_Check
  24:	7ca3      	ldrb	r3, [r4, #18]
  26:	2001      	movs	r0, #1
  28:	2bff      	cmp	r3, #255	@ 0xff
  2a:	7560      	strb	r0, [r4, #21]
  2c:	d004      	beq.n	38 <SystemGnss_Start+0x38>
  2e:	7c20      	ldrb	r0, [r4, #16]
  30:	4298      	cmp	r0, r3
  32:	bf94      	ite	ls
  34:	2000      	movls	r0, #0
  36:	2001      	movhi	r0, #1
  38:	2303      	movs	r3, #3
  3a:	9300      	str	r3, [sp, #0]
  3c:	4a4f      	ldr	r2, [pc, #316]	@ (17c <SystemGnss_Start+0x17c>)
  3e:	f240 4389 	movw	r3, #1161	@ 0x489
  42:	210c      	movs	r1, #12
  44:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			44: R_ARM_THM_CALL	SilverStarAssert_Check
  48:	7ca3      	ldrb	r3, [r4, #18]
  4a:	2bff      	cmp	r3, #255	@ 0xff
  4c:	f000 808b 	beq.w	166 <SystemGnss_Start+0x166>
  50:	7ce2      	ldrb	r2, [r4, #19]
  52:	7c21      	ldrb	r1, [r4, #16]
  54:	4291      	cmp	r1, r2
  56:	d85e      	bhi.n	116 <SystemGnss_Start+0x116>
  58:	2000      	movs	r0, #0
  5a:	2305      	movs	r3, #5
  5c:	9300      	str	r3, [sp, #0]
  5e:	210c      	movs	r1, #12
  60:	f240 438c 	movw	r3, #1164	@ 0x48c
  64:	4a45      	ldr	r2, [pc, #276]	@ (17c <SystemGnss_Start+0x17c>)
  66:	f8df 9110 	ldr.w	r9, [pc, #272]	@ 178 <SystemGnss_Start+0x178>
  6a:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			6a: R_ARM_THM_CALL	SilverStarAssert_Check
  6e:	21ff      	movs	r1, #255	@ 0xff
  70:	2302      	movs	r3, #2
  72:	e9cd 3104 	strd	r3, r1, [sp, #16]
  76:	2500      	movs	r5, #0
  78:	9503      	str	r5, [sp, #12]
  7a:	7c20      	ldrb	r0, [r4, #16]
  7c:	fa5f f885 	uxtb.w	r8, r5
  80:	4540      	cmp	r0, r8
  82:	d933      	bls.n	ec <SystemGnss_Start+0xec>
  84:	f819 7b01 	ldrb.w	r7, [r9], #1
  88:	4a3c      	ldr	r2, [pc, #240]	@ (17c <SystemGnss_Start+0x17c>)
  8a:	42b8      	cmp	r0, r7
  8c:	f04f 0303 	mov.w	r3, #3
  90:	eb04 0607 	add.w	r6, r4, r7
  94:	9300      	str	r3, [sp, #0]
  96:	bf98      	it	ls
  98:	2000      	movls	r0, #0
  9a:	f240 4399 	movw	r3, #1177	@ 0x499
  9e:	bf88      	it	hi
  a0:	2001      	movhi	r0, #1
  a2:	210c      	movs	r1, #12
  a4:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			a4: R_ARM_THM_CALL	SilverStarAssert_Check
  a8:	7933      	ldrb	r3, [r6, #4]
  aa:	b1e3      	cbz	r3, e6 <SystemGnss_Start+0xe6>
  ac:	4638      	mov	r0, r7
  ae:	f04f 0a00 	mov.w	sl, #0
  b2:	f04f 0b01 	mov.w	fp, #1
  b6:	f886 a008 	strb.w	sl, [r6, #8]
  ba:	f886 b00c 	strb.w	fp, [r6, #12]
  be:	f7ff fffe 	bl	0 <ProjectGnssInstance_Start>
			be: R_ARM_THM_CALL	ProjectGnssInstance_Start
  c2:	2810      	cmp	r0, #16
  c4:	4607      	mov	r7, r0
  c6:	d92c      	bls.n	122 <SystemGnss_Start+0x122>
  c8:	2302      	movs	r3, #2
  ca:	9300      	str	r3, [sp, #0]
  cc:	4a2b      	ldr	r2, [pc, #172]	@ (17c <SystemGnss_Start+0x17c>)
  ce:	4650      	mov	r0, sl
  d0:	f44f 638f 	mov.w	r3, #1144	@ 0x478
  d4:	210c      	movs	r1, #12
  d6:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			d6: R_ARM_THM_CALL	SilverStarAssert_Check
  da:	9a04      	ldr	r2, [sp, #16]
  dc:	4613      	mov	r3, r2
  de:	2a02      	cmp	r2, #2
  e0:	bf08      	it	eq
  e2:	463b      	moveq	r3, r7
  e4:	9304      	str	r3, [sp, #16]
  e6:	3501      	adds	r5, #1
  e8:	2d04      	cmp	r5, #4
  ea:	d1c6      	bne.n	7a <SystemGnss_Start+0x7a>
  ec:	7ca5      	ldrb	r5, [r4, #18]
  ee:	9905      	ldr	r1, [sp, #20]
  f0:	2dff      	cmp	r5, #255	@ 0xff
  f2:	d008      	beq.n	106 <SystemGnss_Start+0x106>
  f4:	29ff      	cmp	r1, #255	@ 0xff
  f6:	d006      	beq.n	106 <SystemGnss_Start+0x106>
  f8:	2200      	movs	r2, #0
  fa:	5c60      	ldrb	r0, [r4, r1]
  fc:	f7ff fffe 	bl	0 <SystemGnss_Start>
			fc: R_ARM_THM_CALL	SystemSourceSelector_GnssSelectionPublish
 100:	7ca2      	ldrb	r2, [r4, #18]
 102:	4295      	cmp	r5, r2
 104:	d131      	bne.n	16a <SystemGnss_Start+0x16a>
 106:	9b03      	ldr	r3, [sp, #12]
 108:	9804      	ldr	r0, [sp, #16]
 10a:	2b00      	cmp	r3, #0
 10c:	bf18      	it	ne
 10e:	2000      	movne	r0, #0
 110:	b007      	add	sp, #28
 112:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 116:	5ca0      	ldrb	r0, [r4, r2]
 118:	1ac0      	subs	r0, r0, r3
 11a:	fab0 f080 	clz	r0, r0
 11e:	0940      	lsrs	r0, r0, #5
 120:	e79b      	b.n	5a <SystemGnss_Start+0x5a>
 122:	2302      	movs	r3, #2
 124:	9300      	str	r3, [sp, #0]
 126:	4a15      	ldr	r2, [pc, #84]	@ (17c <SystemGnss_Start+0x17c>)
 128:	f44f 638f 	mov.w	r3, #1144	@ 0x478
 12c:	210c      	movs	r1, #12
 12e:	4658      	mov	r0, fp
 130:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			130: R_ARM_THM_CALL	SilverStarAssert_Check
 134:	2f0d      	cmp	r7, #13
 136:	d8d0      	bhi.n	da <SystemGnss_Start+0xda>
 138:	f243 4303 	movw	r3, #13315	@ 0x3403
 13c:	40fb      	lsrs	r3, r7
 13e:	07db      	lsls	r3, r3, #31
 140:	d5cb      	bpl.n	da <SystemGnss_Start+0xda>
 142:	9b03      	ldr	r3, [sp, #12]
 144:	f886 b008 	strb.w	fp, [r6, #8]
 148:	3301      	adds	r3, #1
 14a:	b2db      	uxtb	r3, r3
 14c:	9303      	str	r3, [sp, #12]
 14e:	7ce3      	ldrb	r3, [r4, #19]
 150:	f886 a00c 	strb.w	sl, [r6, #12]
 154:	4543      	cmp	r3, r8
 156:	d8c6      	bhi.n	e6 <SystemGnss_Start+0xe6>
 158:	9a05      	ldr	r2, [sp, #20]
 15a:	4613      	mov	r3, r2
 15c:	2aff      	cmp	r2, #255	@ 0xff
 15e:	bf08      	it	eq
 160:	4643      	moveq	r3, r8
 162:	9305      	str	r3, [sp, #20]
 164:	e7bf      	b.n	e6 <SystemGnss_Start+0xe6>
 166:	2001      	movs	r0, #1
 168:	e777      	b.n	5a <SystemGnss_Start+0x5a>
 16a:	2305      	movs	r3, #5
 16c:	4629      	mov	r1, r5
 16e:	2002      	movs	r0, #2
 170:	f7ff fffe 	bl	0 <SystemGnss_Start>
			170: R_ARM_THM_CALL	SystemSourceSelector_EventRecord
 174:	e7c7      	b.n	106 <SystemGnss_Start+0x106>
 176:	bf00      	nop
	...
			178: R_ARM_ABS32	.bss.s_gnss
			17c: R_ARM_ABS32	.rodata.SystemSourceSelector_GnssSelectionPublish.str1.4

Disassembly of section .text.SystemGnss_Stop:

00000000 <SystemGnss_Stop>:
   0:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
   4:	4e10      	ldr	r6, [pc, #64]	@ (48 <SystemGnss_Stop+0x48>)
   6:	2300      	movs	r3, #0
   8:	461d      	mov	r5, r3
   a:	f8a6 3015 	strh.w	r3, [r6, #21]
   e:	46b0      	mov	r8, r6
  10:	461f      	mov	r7, r3
  12:	7c32      	ldrb	r2, [r6, #16]
  14:	b2eb      	uxtb	r3, r5
  16:	429a      	cmp	r2, r3
  18:	d910      	bls.n	3c <SystemGnss_Stop+0x3c>
  1a:	f818 4b01 	ldrb.w	r4, [r8], #1
  1e:	1933      	adds	r3, r6, r4
  20:	4620      	mov	r0, r4
  22:	7a1a      	ldrb	r2, [r3, #8]
  24:	b90a      	cbnz	r2, 2a <SystemGnss_Stop+0x2a>
  26:	7b1b      	ldrb	r3, [r3, #12]
  28:	b12b      	cbz	r3, 36 <SystemGnss_Stop+0x36>
  2a:	f7ff fffe 	bl	0 <ProjectGnssInstance_Stop>
			2a: R_ARM_THM_CALL	ProjectGnssInstance_Stop
  2e:	4434      	add	r4, r6
  30:	b938      	cbnz	r0, 42 <SystemGnss_Stop+0x42>
  32:	7220      	strb	r0, [r4, #8]
  34:	7320      	strb	r0, [r4, #12]
  36:	3501      	adds	r5, #1
  38:	2d04      	cmp	r5, #4
  3a:	d1ea      	bne.n	12 <SystemGnss_Stop+0x12>
  3c:	4638      	mov	r0, r7
  3e:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
  42:	2707      	movs	r7, #7
  44:	e7f7      	b.n	36 <SystemGnss_Stop+0x36>
  46:	bf00      	nop
  48:	00000000 	.word	0x00000000
			48: R_ARM_ABS32	.bss.s_gnss

Disassembly of section .text.SystemGnss_RuntimeOwnerActivate:

00000000 <SystemGnss_RuntimeOwnerActivate>:
   0:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
   4:	4d0e      	ldr	r5, [pc, #56]	@ (40 <SystemGnss_RuntimeOwnerActivate+0x40>)
   6:	2301      	movs	r3, #1
   8:	75ab      	strb	r3, [r5, #22]
   a:	462f      	mov	r7, r5
   c:	2400      	movs	r4, #0
   e:	f04f 0802 	mov.w	r8, #2
  12:	7c2a      	ldrb	r2, [r5, #16]
  14:	b2e3      	uxtb	r3, r4
  16:	429a      	cmp	r2, r3
  18:	d90e      	bls.n	38 <SystemGnss_RuntimeOwnerActivate+0x38>
  1a:	f817 6b01 	ldrb.w	r6, [r7], #1
  1e:	19ab      	adds	r3, r5, r6
  20:	4630      	mov	r0, r6
  22:	791b      	ldrb	r3, [r3, #4]
  24:	b12b      	cbz	r3, 32 <SystemGnss_RuntimeOwnerActivate+0x32>
  26:	f7ff fffe 	bl	0 <ProjectGnssInstance_RuntimeOwnerActivate>
			26: R_ARM_THM_CALL	ProjectGnssInstance_RuntimeOwnerActivate
  2a:	7cab      	ldrb	r3, [r5, #18]
  2c:	42b3      	cmp	r3, r6
  2e:	bf08      	it	eq
  30:	4680      	moveq	r8, r0
  32:	3401      	adds	r4, #1
  34:	2c04      	cmp	r4, #4
  36:	d1ec      	bne.n	12 <SystemGnss_RuntimeOwnerActivate+0x12>
  38:	4640      	mov	r0, r8
  3a:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
  3e:	bf00      	nop
  40:	00000000 	.word	0x00000000
			40: R_ARM_ABS32	.bss.s_gnss

Disassembly of section .text.SystemGnss_Process:

00000000 <SystemGnss_Process>:
   0:	e92d 43f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, lr}
   4:	4caf      	ldr	r4, [pc, #700]	@ (2c4 <SystemGnss_Process+0x2c4>)
   6:	7c27      	ldrb	r7, [r4, #16]
   8:	b097      	sub	sp, #92	@ 0x5c
   a:	2500      	movs	r5, #0
   c:	4626      	mov	r6, r4
   e:	b2eb      	uxtb	r3, r5
  10:	42bb      	cmp	r3, r7
  12:	d209      	bcs.n	28 <SystemGnss_Process+0x28>
  14:	f816 0b01 	ldrb.w	r0, [r6], #1
  18:	1823      	adds	r3, r4, r0
  1a:	7a1b      	ldrb	r3, [r3, #8]
  1c:	2b00      	cmp	r3, #0
  1e:	f040 8131 	bne.w	284 <SystemGnss_Process+0x284>
  22:	3501      	adds	r5, #1
  24:	2d04      	cmp	r5, #4
  26:	d1f2      	bne.n	e <SystemGnss_Process+0xe>
  28:	2f04      	cmp	r7, #4
  2a:	f04f 030a 	mov.w	r3, #10
  2e:	9300      	str	r3, [sp, #0]
  30:	bf88      	it	hi
  32:	2000      	movhi	r0, #0
  34:	f240 338e 	movw	r3, #910	@ 0x38e
  38:	bf98      	it	ls
  3a:	2001      	movls	r0, #1
  3c:	4aa2      	ldr	r2, [pc, #648]	@ (2c8 <SystemGnss_Process+0x2c8>)
  3e:	210c      	movs	r1, #12
  40:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			40: R_ARM_THM_CALL	SilverStarAssert_Check
  44:	7ca3      	ldrb	r3, [r4, #18]
  46:	2bff      	cmp	r3, #255	@ 0xff
  48:	d060      	beq.n	10c <SystemGnss_Process+0x10c>
  4a:	7c20      	ldrb	r0, [r4, #16]
  4c:	4a9e      	ldr	r2, [pc, #632]	@ (2c8 <SystemGnss_Process+0x2c8>)
  4e:	4298      	cmp	r0, r3
  50:	f04f 0303 	mov.w	r3, #3
  54:	bf94      	ite	ls
  56:	2000      	movls	r0, #0
  58:	2001      	movhi	r0, #1
  5a:	9300      	str	r3, [sp, #0]
  5c:	210c      	movs	r1, #12
  5e:	f240 3391 	movw	r3, #913	@ 0x391
  62:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			62: R_ARM_THM_CALL	SilverStarAssert_Check
  66:	7ce3      	ldrb	r3, [r4, #19]
  68:	7c22      	ldrb	r2, [r4, #16]
  6a:	429a      	cmp	r2, r3
  6c:	f200 810e 	bhi.w	28c <SystemGnss_Process+0x28c>
  70:	2000      	movs	r0, #0
  72:	2305      	movs	r3, #5
  74:	4a94      	ldr	r2, [pc, #592]	@ (2c8 <SystemGnss_Process+0x2c8>)
  76:	9300      	str	r3, [sp, #0]
  78:	210c      	movs	r1, #12
  7a:	f240 3393 	movw	r3, #915	@ 0x393
  7e:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			7e: R_ARM_THM_CALL	SilverStarAssert_Check
  82:	2100      	movs	r1, #0
  84:	2228      	movs	r2, #40	@ 0x28
  86:	a802      	add	r0, sp, #8
  88:	f7ff fffe 	bl	0 <memset>
			88: R_ARM_THM_CALL	memset
  8c:	7ca0      	ldrb	r0, [r4, #18]
  8e:	a902      	add	r1, sp, #8
  90:	f7ff fffe 	bl	0 <ProjectGnssInstance_HealthGet>
			90: R_ARM_THM_CALL	ProjectGnssInstance_HealthGet
  94:	2800      	cmp	r0, #0
  96:	f040 8100 	bne.w	29a <SystemGnss_Process+0x29a>
  9a:	f89d 502c 	ldrb.w	r5, [sp, #44]	@ 0x2c
  9e:	2d00      	cmp	r5, #0
  a0:	f040 8114 	bne.w	2cc <SystemGnss_Process+0x2cc>
  a4:	f04f 0803 	mov.w	r8, #3
  a8:	7c20      	ldrb	r0, [r4, #16]
  aa:	4a87      	ldr	r2, [pc, #540]	@ (2c8 <SystemGnss_Process+0x2c8>)
  ac:	b2ee      	uxtb	r6, r5
  ae:	4286      	cmp	r6, r0
  b0:	f44f 736a 	mov.w	r3, #936	@ 0x3a8
  b4:	f04f 010c 	mov.w	r1, #12
  b8:	d228      	bcs.n	10c <SystemGnss_Process+0x10c>
  ba:	7ce7      	ldrb	r7, [r4, #19]
  bc:	42b7      	cmp	r7, r6
  be:	d022      	beq.n	106 <SystemGnss_Process+0x106>
  c0:	5d67      	ldrb	r7, [r4, r5]
  c2:	f8cd 8000 	str.w	r8, [sp]
  c6:	42b8      	cmp	r0, r7
  c8:	bf94      	ite	ls
  ca:	2000      	movls	r0, #0
  cc:	2001      	movhi	r0, #1
  ce:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			ce: R_ARM_THM_CALL	SilverStarAssert_Check
  d2:	19e3      	adds	r3, r4, r7
  d4:	791a      	ldrb	r2, [r3, #4]
  d6:	b1b2      	cbz	r2, 106 <SystemGnss_Process+0x106>
  d8:	7a1b      	ldrb	r3, [r3, #8]
  da:	2228      	movs	r2, #40	@ 0x28
  dc:	b19b      	cbz	r3, 106 <SystemGnss_Process+0x106>
  de:	2100      	movs	r1, #0
  e0:	a80c      	add	r0, sp, #48	@ 0x30
  e2:	f7ff fffe 	bl	0 <memset>
			e2: R_ARM_THM_CALL	memset
  e6:	a90c      	add	r1, sp, #48	@ 0x30
  e8:	4638      	mov	r0, r7
  ea:	f7ff fffe 	bl	0 <ProjectGnssInstance_HealthGet>
			ea: R_ARM_THM_CALL	ProjectGnssInstance_HealthGet
  ee:	b950      	cbnz	r0, 106 <SystemGnss_Process+0x106>
  f0:	f89d 3054 	ldrb.w	r3, [sp, #84]	@ 0x54
  f4:	b13b      	cbz	r3, 106 <SystemGnss_Process+0x106>
  f6:	f89d 3055 	ldrb.w	r3, [sp, #85]	@ 0x55
  fa:	b123      	cbz	r3, 106 <SystemGnss_Process+0x106>
  fc:	f89d 3056 	ldrb.w	r3, [sp, #86]	@ 0x56
 100:	2b00      	cmp	r3, #0
 102:	f040 8134 	bne.w	36e <SystemGnss_Process+0x36e>
 106:	3501      	adds	r5, #1
 108:	2d04      	cmp	r5, #4
 10a:	d1cd      	bne.n	a8 <SystemGnss_Process+0xa8>
 10c:	f7ff fffe 	bl	0 <SystemTime_GetMonotonicUs>
			10c: R_ARM_THM_CALL	SystemTime_GetMonotonicUs
 110:	7d63      	ldrb	r3, [r4, #21]
 112:	4607      	mov	r7, r0
 114:	460e      	mov	r6, r1
 116:	2b00      	cmp	r3, #0
 118:	f000 80af 	beq.w	27a <SystemGnss_Process+0x27a>
 11c:	7c25      	ldrb	r5, [r4, #16]
 11e:	2d00      	cmp	r5, #0
 120:	f000 80ab 	beq.w	27a <SystemGnss_Process+0x27a>
 124:	7ca0      	ldrb	r0, [r4, #18]
 126:	28ff      	cmp	r0, #255	@ 0xff
 128:	d00f      	beq.n	14a <SystemGnss_Process+0x14a>
 12a:	a90c      	add	r1, sp, #48	@ 0x30
 12c:	f7ff fffe 	bl	0 <ProjectGnssInstance_HealthGet>
			12c: R_ARM_THM_CALL	ProjectGnssInstance_HealthGet
 130:	7ca2      	ldrb	r2, [r4, #18]
 132:	2800      	cmp	r0, #0
 134:	f000 80d7 	beq.w	2e6 <SystemGnss_Process+0x2e6>
 138:	2aff      	cmp	r2, #255	@ 0xff
 13a:	d005      	beq.n	148 <SystemGnss_Process+0x148>
 13c:	f7ff fffe 	bl	0 <PlatformCritical_Enter>
			13c: R_ARM_THM_CALL	PlatformCritical_Enter
 140:	e9c4 760c 	strd	r7, r6, [r4, #48]	@ 0x30
 144:	f7ff fffe 	bl	0 <PlatformCritical_Exit>
			144: R_ARM_THM_CALL	PlatformCritical_Exit
 148:	7c25      	ldrb	r5, [r4, #16]
 14a:	4638      	mov	r0, r7
 14c:	4631      	mov	r1, r6
 14e:	f44f 727a 	mov.w	r2, #1000	@ 0x3e8
 152:	2300      	movs	r3, #0
 154:	f7ff fffe 	bl	0 <__aeabi_uldivmod>
			154: R_ARM_THM_CALL	__aeabi_uldivmod
 158:	2700      	movs	r7, #0
 15a:	4680      	mov	r8, r0
 15c:	f44f 797a 	mov.w	r9, #1000	@ 0x3e8
 160:	b2fb      	uxtb	r3, r7
 162:	42ab      	cmp	r3, r5
 164:	f080 8089 	bcs.w	27a <SystemGnss_Process+0x27a>
 168:	7d23      	ldrb	r3, [r4, #20]
 16a:	443b      	add	r3, r7
 16c:	fbb3 f2f5 	udiv	r2, r3, r5
 170:	fb05 3612 	mls	r6, r5, r2, r3
 174:	5da5      	ldrb	r5, [r4, r6]
 176:	1963      	adds	r3, r4, r5
 178:	7a1b      	ldrb	r3, [r3, #8]
 17a:	2b00      	cmp	r3, #0
 17c:	f040 808f 	bne.w	29e <SystemGnss_Process+0x29e>
 180:	1dab      	adds	r3, r5, #6
 182:	1962      	adds	r2, r4, r5
 184:	eb04 0383 	add.w	r3, r4, r3, lsl #2
 188:	7dd1      	ldrb	r1, [r2, #23]
 18a:	685a      	ldr	r2, [r3, #4]
 18c:	fa09 f101 	lsl.w	r1, r9, r1
 190:	eba8 0202 	sub.w	r2, r8, r2
 194:	428a      	cmp	r2, r1
 196:	f0c0 8090 	bcc.w	2ba <SystemGnss_Process+0x2ba>
 19a:	f8c3 8004 	str.w	r8, [r3, #4]
 19e:	230a      	movs	r3, #10
 1a0:	9300      	str	r3, [sp, #0]
 1a2:	7c20      	ldrb	r0, [r4, #16]
 1a4:	4a48      	ldr	r2, [pc, #288]	@ (2c8 <SystemGnss_Process+0x2c8>)
 1a6:	1c71      	adds	r1, r6, #1
 1a8:	2804      	cmp	r0, #4
 1aa:	fbb1 f7f0 	udiv	r7, r1, r0
 1ae:	fb00 1117 	mls	r1, r0, r7, r1
 1b2:	7521      	strb	r1, [r4, #20]
 1b4:	bf8c      	ite	hi
 1b6:	2000      	movhi	r0, #0
 1b8:	2001      	movls	r0, #1
 1ba:	f240 33cb 	movw	r3, #971	@ 0x3cb
 1be:	210c      	movs	r1, #12
 1c0:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			1c0: R_ARM_THM_CALL	SilverStarAssert_Check
 1c4:	7c20      	ldrb	r0, [r4, #16]
 1c6:	4285      	cmp	r5, r0
 1c8:	b2f6      	uxtb	r6, r6
 1ca:	f080 808a 	bcs.w	2e2 <SystemGnss_Process+0x2e2>
 1ce:	4286      	cmp	r6, r0
 1d0:	bf2c      	ite	cs
 1d2:	2000      	movcs	r0, #0
 1d4:	2001      	movcc	r0, #1
 1d6:	2303      	movs	r3, #3
 1d8:	4a3b      	ldr	r2, [pc, #236]	@ (2c8 <SystemGnss_Process+0x2c8>)
 1da:	9300      	str	r3, [sp, #0]
 1dc:	210c      	movs	r1, #12
 1de:	f240 33cd 	movw	r3, #973	@ 0x3cd
 1e2:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			1e2: R_ARM_THM_CALL	SilverStarAssert_Check
 1e6:	1963      	adds	r3, r4, r5
 1e8:	7a1a      	ldrb	r2, [r3, #8]
 1ea:	b90a      	cbnz	r2, 1f0 <SystemGnss_Process+0x1f0>
 1ec:	7b1b      	ldrb	r3, [r3, #12]
 1ee:	b17b      	cbz	r3, 210 <SystemGnss_Process+0x210>
 1f0:	4628      	mov	r0, r5
 1f2:	f7ff fffe 	bl	0 <ProjectGnssInstance_Stop>
			1f2: R_ARM_THM_CALL	ProjectGnssInstance_Stop
 1f6:	280d      	cmp	r0, #13
 1f8:	f200 8098 	bhi.w	32c <SystemGnss_Process+0x32c>
 1fc:	f243 4303 	movw	r3, #13315	@ 0x3403
 200:	40c3      	lsrs	r3, r0
 202:	07d8      	lsls	r0, r3, #31
 204:	f140 8092 	bpl.w	32c <SystemGnss_Process+0x32c>
 208:	1963      	adds	r3, r4, r5
 20a:	2200      	movs	r2, #0
 20c:	721a      	strb	r2, [r3, #8]
 20e:	731a      	strb	r2, [r3, #12]
 210:	1967      	adds	r7, r4, r5
 212:	793b      	ldrb	r3, [r7, #4]
 214:	b963      	cbnz	r3, 230 <SystemGnss_Process+0x230>
 216:	4628      	mov	r0, r5
 218:	f7ff fffe 	bl	0 <ProjectGnssInstance_Init>
			218: R_ARM_THM_CALL	ProjectGnssInstance_Init
 21c:	280d      	cmp	r0, #13
 21e:	f200 8085 	bhi.w	32c <SystemGnss_Process+0x32c>
 222:	f243 4303 	movw	r3, #13315	@ 0x3403
 226:	40c3      	lsrs	r3, r0
 228:	07d9      	lsls	r1, r3, #31
 22a:	d57f      	bpl.n	32c <SystemGnss_Process+0x32c>
 22c:	2301      	movs	r3, #1
 22e:	713b      	strb	r3, [r7, #4]
 230:	1967      	adds	r7, r4, r5
 232:	2301      	movs	r3, #1
 234:	4628      	mov	r0, r5
 236:	733b      	strb	r3, [r7, #12]
 238:	f7ff fffe 	bl	0 <ProjectGnssInstance_Start>
			238: R_ARM_THM_CALL	ProjectGnssInstance_Start
 23c:	7dfb      	ldrb	r3, [r7, #23]
 23e:	2b04      	cmp	r3, #4
 240:	bf9c      	itt	ls
 242:	3301      	addls	r3, #1
 244:	75fb      	strbls	r3, [r7, #23]
 246:	280d      	cmp	r0, #13
 248:	d817      	bhi.n	27a <SystemGnss_Process+0x27a>
 24a:	f243 4703 	movw	r7, #13315	@ 0x3403
 24e:	fa27 f000 	lsr.w	r0, r7, r0
 252:	07c2      	lsls	r2, r0, #31
 254:	d511      	bpl.n	27a <SystemGnss_Process+0x27a>
 256:	1963      	adds	r3, r4, r5
 258:	2101      	movs	r1, #1
 25a:	7da2      	ldrb	r2, [r4, #22]
 25c:	7219      	strb	r1, [r3, #8]
 25e:	2100      	movs	r1, #0
 260:	7319      	strb	r1, [r3, #12]
 262:	2a00      	cmp	r2, #0
 264:	d169      	bne.n	33a <SystemGnss_Process+0x33a>
 266:	7ca4      	ldrb	r4, [r4, #18]
 268:	2cff      	cmp	r4, #255	@ 0xff
 26a:	d074      	beq.n	356 <SystemGnss_Process+0x356>
 26c:	42a5      	cmp	r5, r4
 26e:	d104      	bne.n	27a <SystemGnss_Process+0x27a>
 270:	2201      	movs	r2, #1
 272:	4631      	mov	r1, r6
 274:	4628      	mov	r0, r5
 276:	f7ff fffe 	bl	0 <SystemGnss_Process>
			276: R_ARM_THM_CALL	SystemSourceSelector_GnssSelectionPublish
 27a:	b017      	add	sp, #92	@ 0x5c
 27c:	e8bd 43f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, lr}
 280:	f7ff bffe 	b.w	0 <SystemGnss_Process>
			280: R_ARM_THM_JUMP24	SystemSourceSelector_PendingEventsFlush
 284:	f7ff fffe 	bl	0 <ProjectGnssInstance_Process>
			284: R_ARM_THM_CALL	ProjectGnssInstance_Process
 288:	7c27      	ldrb	r7, [r4, #16]
 28a:	e6ca      	b.n	22 <SystemGnss_Process+0x22>
 28c:	5ce0      	ldrb	r0, [r4, r3]
 28e:	7ca3      	ldrb	r3, [r4, #18]
 290:	1ac0      	subs	r0, r0, r3
 292:	fab0 f080 	clz	r0, r0
 296:	0940      	lsrs	r0, r0, #5
 298:	e6eb      	b.n	72 <SystemGnss_Process+0x72>
 29a:	2500      	movs	r5, #0
 29c:	e702      	b.n	a4 <SystemGnss_Process+0xa4>
 29e:	2300      	movs	r3, #0
 2a0:	a902      	add	r1, sp, #8
 2a2:	4628      	mov	r0, r5
 2a4:	f88d 3008 	strb.w	r3, [sp, #8]
 2a8:	f7ff fffe 	bl	0 <ProjectGnssInstance_RecoveryBusyGet>
			2a8: R_ARM_THM_CALL	ProjectGnssInstance_RecoveryBusyGet
 2ac:	f89d 3008 	ldrb.w	r3, [sp, #8]
 2b0:	f000 00fb 	and.w	r0, r0, #251	@ 0xfb
 2b4:	4318      	orrs	r0, r3
 2b6:	a90c      	add	r1, sp, #48	@ 0x30
 2b8:	d02c      	beq.n	314 <SystemGnss_Process+0x314>
 2ba:	3701      	adds	r7, #1
 2bc:	2f04      	cmp	r7, #4
 2be:	d0dc      	beq.n	27a <SystemGnss_Process+0x27a>
 2c0:	7c25      	ldrb	r5, [r4, #16]
 2c2:	e74d      	b.n	160 <SystemGnss_Process+0x160>
	...
			2c4: R_ARM_ABS32	.bss.s_gnss
			2c8: R_ARM_ABS32	.rodata.SystemSourceSelector_GnssSelectionPublish.str1.4
 2cc:	f89d 502d 	ldrb.w	r5, [sp, #45]	@ 0x2d
 2d0:	2d00      	cmp	r5, #0
 2d2:	f43f aee7 	beq.w	a4 <SystemGnss_Process+0xa4>
 2d6:	f89d 502e 	ldrb.w	r5, [sp, #46]	@ 0x2e
 2da:	2d00      	cmp	r5, #0
 2dc:	f43f aee2 	beq.w	a4 <SystemGnss_Process+0xa4>
 2e0:	e714      	b.n	10c <SystemGnss_Process+0x10c>
 2e2:	2000      	movs	r0, #0
 2e4:	e777      	b.n	1d6 <SystemGnss_Process+0x1d6>
 2e6:	f89d 3054 	ldrb.w	r3, [sp, #84]	@ 0x54
 2ea:	2b00      	cmp	r3, #0
 2ec:	f43f af24 	beq.w	138 <SystemGnss_Process+0x138>
 2f0:	f89d 3055 	ldrb.w	r3, [sp, #85]	@ 0x55
 2f4:	2b00      	cmp	r3, #0
 2f6:	f43f af1f 	beq.w	138 <SystemGnss_Process+0x138>
 2fa:	f89d 3056 	ldrb.w	r3, [sp, #86]	@ 0x56
 2fe:	2b00      	cmp	r3, #0
 300:	f43f af1a 	beq.w	138 <SystemGnss_Process+0x138>
 304:	18a3      	adds	r3, r4, r2
 306:	7ddb      	ldrb	r3, [r3, #23]
 308:	2b00      	cmp	r3, #0
 30a:	d13d      	bne.n	388 <SystemGnss_Process+0x388>
 30c:	4422      	add	r2, r4
 30e:	2300      	movs	r3, #0
 310:	75d3      	strb	r3, [r2, #23]
 312:	e7b2      	b.n	27a <SystemGnss_Process+0x27a>
 314:	4628      	mov	r0, r5
 316:	f7ff fffe 	bl	0 <ProjectGnssInstance_HealthGet>
			316: R_ARM_THM_CALL	ProjectGnssInstance_HealthGet
 31a:	2800      	cmp	r0, #0
 31c:	f47f af30 	bne.w	180 <SystemGnss_Process+0x180>
 320:	f89d 3056 	ldrb.w	r3, [sp, #86]	@ 0x56
 324:	2b00      	cmp	r3, #0
 326:	f43f af2b 	beq.w	180 <SystemGnss_Process+0x180>
 32a:	e7c6      	b.n	2ba <SystemGnss_Process+0x2ba>
 32c:	4425      	add	r5, r4
 32e:	7deb      	ldrb	r3, [r5, #23]
 330:	2b04      	cmp	r3, #4
 332:	d8a2      	bhi.n	27a <SystemGnss_Process+0x27a>
 334:	3301      	adds	r3, #1
 336:	75eb      	strb	r3, [r5, #23]
 338:	e79f      	b.n	27a <SystemGnss_Process+0x27a>
 33a:	4628      	mov	r0, r5
 33c:	f7ff fffe 	bl	0 <ProjectGnssInstance_RuntimeOwnerActivate>
			33c: R_ARM_THM_CALL	ProjectGnssInstance_RuntimeOwnerActivate
 340:	280d      	cmp	r0, #13
 342:	d802      	bhi.n	34a <SystemGnss_Process+0x34a>
 344:	40c7      	lsrs	r7, r0
 346:	07fb      	lsls	r3, r7, #31
 348:	d48d      	bmi.n	266 <SystemGnss_Process+0x266>
 34a:	4425      	add	r5, r4
 34c:	2200      	movs	r2, #0
 34e:	2301      	movs	r3, #1
 350:	722a      	strb	r2, [r5, #8]
 352:	732b      	strb	r3, [r5, #12]
 354:	e791      	b.n	27a <SystemGnss_Process+0x27a>
 356:	4631      	mov	r1, r6
 358:	4628      	mov	r0, r5
 35a:	2201      	movs	r2, #1
 35c:	f7ff fffe 	bl	0 <SystemGnss_Process>
			35c: R_ARM_THM_CALL	SystemSourceSelector_GnssSelectionPublish
 360:	2303      	movs	r3, #3
 362:	2002      	movs	r0, #2
 364:	462a      	mov	r2, r5
 366:	4621      	mov	r1, r4
 368:	f7ff fffe 	bl	0 <SystemGnss_Process>
			368: R_ARM_THM_CALL	SystemSourceSelector_EventRecord
 36c:	e785      	b.n	27a <SystemGnss_Process+0x27a>
 36e:	7ca5      	ldrb	r5, [r4, #18]
 370:	4631      	mov	r1, r6
 372:	4638      	mov	r0, r7
 374:	2201      	movs	r2, #1
 376:	f7ff fffe 	bl	0 <SystemGnss_Process>
			376: R_ARM_THM_CALL	SystemSourceSelector_GnssSelectionPublish
 37a:	2306      	movs	r3, #6
 37c:	2002      	movs	r0, #2
 37e:	463a      	mov	r2, r7
 380:	4629      	mov	r1, r5
 382:	f7ff fffe 	bl	0 <SystemGnss_Process>
			382: R_ARM_THM_CALL	SystemSourceSelector_EventRecord
 386:	e6c1      	b.n	10c <SystemGnss_Process+0x10c>
 388:	4611      	mov	r1, r2
 38a:	2303      	movs	r3, #3
 38c:	2002      	movs	r0, #2
 38e:	f7ff fffe 	bl	0 <SystemGnss_Process>
			38e: R_ARM_THM_CALL	SystemSourceSelector_EventRecord
 392:	7ca2      	ldrb	r2, [r4, #18]
 394:	e7ba      	b.n	30c <SystemGnss_Process+0x30c>
 396:	bf00      	nop

Disassembly of section .text.SystemGnss_InfoGet:

00000000 <SystemGnss_InfoGet>:
   0:	4601      	mov	r1, r0
   2:	b138      	cbz	r0, 14 <SystemGnss_InfoGet+0x14>
   4:	4b04      	ldr	r3, [pc, #16]	@ (18 <SystemGnss_InfoGet+0x18>)
   6:	7c98      	ldrb	r0, [r3, #18]
   8:	28ff      	cmp	r0, #255	@ 0xff
   a:	d001      	beq.n	10 <SystemGnss_InfoGet+0x10>
   c:	f7ff bffe 	b.w	0 <ProjectGnssInstance_InfoGet>
			c: R_ARM_THM_JUMP24	ProjectGnssInstance_InfoGet
  10:	2002      	movs	r0, #2
  12:	4770      	bx	lr
  14:	2005      	movs	r0, #5
  16:	4770      	bx	lr
  18:	00000000 	.word	0x00000000
			18: R_ARM_ABS32	.bss.s_gnss

Disassembly of section .text.SystemGnss_CapabilitiesGet:

00000000 <SystemGnss_CapabilitiesGet>:
   0:	4601      	mov	r1, r0
   2:	b138      	cbz	r0, 14 <SystemGnss_CapabilitiesGet+0x14>
   4:	4b04      	ldr	r3, [pc, #16]	@ (18 <SystemGnss_CapabilitiesGet+0x18>)
   6:	7c98      	ldrb	r0, [r3, #18]
   8:	28ff      	cmp	r0, #255	@ 0xff
   a:	d001      	beq.n	10 <SystemGnss_CapabilitiesGet+0x10>
   c:	f7ff bffe 	b.w	0 <ProjectGnssInstance_CapabilitiesGet>
			c: R_ARM_THM_JUMP24	ProjectGnssInstance_CapabilitiesGet
  10:	2002      	movs	r0, #2
  12:	4770      	bx	lr
  14:	2005      	movs	r0, #5
  16:	4770      	bx	lr
  18:	00000000 	.word	0x00000000
			18: R_ARM_ABS32	.bss.s_gnss

Disassembly of section .text.SystemGnss_HealthGet:

00000000 <SystemGnss_HealthGet>:
   0:	4601      	mov	r1, r0
   2:	b138      	cbz	r0, 14 <SystemGnss_HealthGet+0x14>
   4:	4b04      	ldr	r3, [pc, #16]	@ (18 <SystemGnss_HealthGet+0x18>)
   6:	7c98      	ldrb	r0, [r3, #18]
   8:	28ff      	cmp	r0, #255	@ 0xff
   a:	d001      	beq.n	10 <SystemGnss_HealthGet+0x10>
   c:	f7ff bffe 	b.w	0 <ProjectGnssInstance_HealthGet>
			c: R_ARM_THM_JUMP24	ProjectGnssInstance_HealthGet
  10:	2002      	movs	r0, #2
  12:	4770      	bx	lr
  14:	2005      	movs	r0, #5
  16:	4770      	bx	lr
  18:	00000000 	.word	0x00000000
			18: R_ARM_ABS32	.bss.s_gnss

Disassembly of section .text.SystemGnss_IoDiagnosticsGet:

00000000 <SystemGnss_IoDiagnosticsGet>:
   0:	4601      	mov	r1, r0
   2:	b138      	cbz	r0, 14 <SystemGnss_IoDiagnosticsGet+0x14>
   4:	4b04      	ldr	r3, [pc, #16]	@ (18 <SystemGnss_IoDiagnosticsGet+0x18>)
   6:	7c98      	ldrb	r0, [r3, #18]
   8:	28ff      	cmp	r0, #255	@ 0xff
   a:	d001      	beq.n	10 <SystemGnss_IoDiagnosticsGet+0x10>
   c:	f7ff bffe 	b.w	0 <ProjectGnssInstance_IoDiagnosticsGet>
			c: R_ARM_THM_JUMP24	ProjectGnssInstance_IoDiagnosticsGet
  10:	2002      	movs	r0, #2
  12:	4770      	bx	lr
  14:	2005      	movs	r0, #5
  16:	4770      	bx	lr
  18:	00000000 	.word	0x00000000
			18: R_ARM_ABS32	.bss.s_gnss

Disassembly of section .text.SystemGnss_IoDetailGet:

00000000 <SystemGnss_IoDetailGet>:
   0:	4601      	mov	r1, r0
   2:	b138      	cbz	r0, 14 <SystemGnss_IoDetailGet+0x14>
   4:	4b04      	ldr	r3, [pc, #16]	@ (18 <SystemGnss_IoDetailGet+0x18>)
   6:	7c98      	ldrb	r0, [r3, #18]
   8:	28ff      	cmp	r0, #255	@ 0xff
   a:	d001      	beq.n	10 <SystemGnss_IoDetailGet+0x10>
   c:	f7ff bffe 	b.w	0 <ProjectGnssInstance_IoDetailGet>
			c: R_ARM_THM_JUMP24	ProjectGnssInstance_IoDetailGet
  10:	2002      	movs	r0, #2
  12:	4770      	bx	lr
  14:	2005      	movs	r0, #5
  16:	4770      	bx	lr
  18:	00000000 	.word	0x00000000
			18: R_ARM_ABS32	.bss.s_gnss

Disassembly of section .text.SystemGnss_LatestSampleGet:

00000000 <SystemGnss_LatestSampleGet>:
   0:	b570      	push	{r4, r5, r6, lr}
   2:	b082      	sub	sp, #8
   4:	b330      	cbz	r0, 54 <SystemGnss_LatestSampleGet+0x54>
   6:	4605      	mov	r5, r0
   8:	f7ff fffe 	bl	0 <PlatformCritical_Enter>
			8: R_ARM_THM_CALL	PlatformCritical_Enter
   c:	4606      	mov	r6, r0
   e:	f10d 0007 	add.w	r0, sp, #7
  12:	f7ff fffe 	bl	0 <SystemGnss_LatestSampleGet>
			12: R_ARM_THM_CALL	SystemSourceSelector_GnssActiveInstanceGet
  16:	4604      	mov	r4, r0
  18:	b128      	cbz	r0, 26 <SystemGnss_LatestSampleGet+0x26>
  1a:	4630      	mov	r0, r6
  1c:	f7ff fffe 	bl	0 <PlatformCritical_Exit>
			1c: R_ARM_THM_CALL	PlatformCritical_Exit
  20:	4620      	mov	r0, r4
  22:	b002      	add	sp, #8
  24:	bd70      	pop	{r4, r5, r6, pc}
  26:	f89d 0007 	ldrb.w	r0, [sp, #7]
  2a:	4629      	mov	r1, r5
  2c:	f7ff fffe 	bl	0 <ProjectGnssInstance_LatestSampleGet>
			2c: R_ARM_THM_CALL	ProjectGnssInstance_LatestSampleGet
  30:	4604      	mov	r4, r0
  32:	2800      	cmp	r0, #0
  34:	d1f1      	bne.n	1a <SystemGnss_LatestSampleGet+0x1a>
  36:	4b09      	ldr	r3, [pc, #36]	@ (5c <SystemGnss_LatestSampleGet+0x5c>)
  38:	e9d3 230c 	ldrd	r2, r3, [r3, #48]	@ 0x30
  3c:	ea52 0103 	orrs.w	r1, r2, r3
  40:	d0eb      	beq.n	1a <SystemGnss_LatestSampleGet+0x1a>
  42:	68a9      	ldr	r1, [r5, #8]
  44:	428a      	cmp	r2, r1
  46:	68ea      	ldr	r2, [r5, #12]
  48:	4193      	sbcs	r3, r2
  4a:	bf2c      	ite	cs
  4c:	2401      	movcs	r4, #1
  4e:	2400      	movcc	r4, #0
  50:	0064      	lsls	r4, r4, #1
  52:	e7e2      	b.n	1a <SystemGnss_LatestSampleGet+0x1a>
  54:	2405      	movs	r4, #5
  56:	4620      	mov	r0, r4
  58:	b002      	add	sp, #8
  5a:	bd70      	pop	{r4, r5, r6, pc}
  5c:	00000000 	.word	0x00000000
			5c: R_ARM_ABS32	.bss.s_gnss

Disassembly of section .text.SystemGnss_TimeGet:

00000000 <SystemGnss_TimeGet>:
   0:	4601      	mov	r1, r0
   2:	b138      	cbz	r0, 14 <SystemGnss_TimeGet+0x14>
   4:	4b04      	ldr	r3, [pc, #16]	@ (18 <SystemGnss_TimeGet+0x18>)
   6:	7c98      	ldrb	r0, [r3, #18]
   8:	28ff      	cmp	r0, #255	@ 0xff
   a:	d001      	beq.n	10 <SystemGnss_TimeGet+0x10>
   c:	f7ff bffe 	b.w	0 <ProjectGnssInstance_TimeGet>
			c: R_ARM_THM_JUMP24	ProjectGnssInstance_TimeGet
  10:	2002      	movs	r0, #2
  12:	4770      	bx	lr
  14:	2005      	movs	r0, #5
  16:	4770      	bx	lr
  18:	00000000 	.word	0x00000000
			18: R_ARM_ABS32	.bss.s_gnss

Disassembly of section .text.SystemGnss_SelfTestRun:

00000000 <SystemGnss_SelfTestRun>:
   0:	4601      	mov	r1, r0
   2:	b138      	cbz	r0, 14 <SystemGnss_SelfTestRun+0x14>
   4:	4b04      	ldr	r3, [pc, #16]	@ (18 <SystemGnss_SelfTestRun+0x18>)
   6:	7c98      	ldrb	r0, [r3, #18]
   8:	28ff      	cmp	r0, #255	@ 0xff
   a:	d001      	beq.n	10 <SystemGnss_SelfTestRun+0x10>
   c:	f7ff bffe 	b.w	0 <ProjectGnssInstance_SelfTestRun>
			c: R_ARM_THM_JUMP24	ProjectGnssInstance_SelfTestRun
  10:	2002      	movs	r0, #2
  12:	4770      	bx	lr
  14:	2005      	movs	r0, #5
  16:	4770      	bx	lr
  18:	00000000 	.word	0x00000000
			18: R_ARM_ABS32	.bss.s_gnss

Disassembly of section .text.SystemGnss_ConfigApply:

00000000 <SystemGnss_ConfigApply>:
   0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
   4:	b091      	sub	sp, #68	@ 0x44
   6:	2800      	cmp	r0, #0
   8:	d054      	beq.n	b4 <SystemGnss_ConfigApply+0xb4>
   a:	460f      	mov	r7, r1
   c:	2900      	cmp	r1, #0
   e:	d051      	beq.n	b4 <SystemGnss_ConfigApply+0xb4>
  10:	f240 524e 	movw	r2, #1358	@ 0x54e
  14:	9200      	str	r2, [sp, #0]
  16:	4b2a      	ldr	r3, [pc, #168]	@ (c0 <SystemGnss_ConfigApply+0xc0>)
  18:	4c2a      	ldr	r4, [pc, #168]	@ (c4 <SystemGnss_ConfigApply+0xc4>)
  1a:	220c      	movs	r2, #12
  1c:	2104      	movs	r1, #4
  1e:	4606      	mov	r6, r0
  20:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			20: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  24:	f104 0904 	add.w	r9, r4, #4
  28:	4625      	mov	r5, r4
  2a:	f04f 0a02 	mov.w	sl, #2
  2e:	f04f 0800 	mov.w	r8, #0
  32:	f894 c010 	ldrb.w	ip, [r4, #16]
  36:	f8cd 8008 	str.w	r8, [sp, #8]
  3a:	1b2b      	subs	r3, r5, r4
  3c:	b2db      	uxtb	r3, r3
  3e:	459c      	cmp	ip, r3
  40:	f04f 0234 	mov.w	r2, #52	@ 0x34
  44:	f04f 0100 	mov.w	r1, #0
  48:	a803      	add	r0, sp, #12
  4a:	d92d      	bls.n	a8 <SystemGnss_ConfigApply+0xa8>
  4c:	f815 bb01 	ldrb.w	fp, [r5], #1
  50:	eb04 030b 	add.w	r3, r4, fp
  54:	791b      	ldrb	r3, [r3, #4]
  56:	b32b      	cbz	r3, a4 <SystemGnss_ConfigApply+0xa4>
  58:	f7ff fffe 	bl	0 <memset>
			58: R_ARM_THM_CALL	memset
  5c:	a902      	add	r1, sp, #8
  5e:	4658      	mov	r0, fp
  60:	f7ff fffe 	bl	0 <ProjectGnssInstance_CapabilitiesGet>
			60: R_ARM_THM_CALL	ProjectGnssInstance_CapabilitiesGet
  64:	b910      	cbnz	r0, 6c <SystemGnss_ConfigApply+0x6c>
  66:	9b02      	ldr	r3, [sp, #8]
  68:	051b      	lsls	r3, r3, #20
  6a:	d421      	bmi.n	b0 <SystemGnss_ConfigApply+0xb0>
  6c:	aa03      	add	r2, sp, #12
  6e:	4631      	mov	r1, r6
  70:	4658      	mov	r0, fp
  72:	f7ff fffe 	bl	0 <ProjectGnssInstance_ConfigApply>
			72: R_ARM_THM_CALL	ProjectGnssInstance_ConfigApply
  76:	7ca3      	ldrb	r3, [r4, #18]
  78:	455b      	cmp	r3, fp
  7a:	d113      	bne.n	a4 <SystemGnss_ConfigApply+0xa4>
  7c:	f10d 0e0c 	add.w	lr, sp, #12
  80:	4682      	mov	sl, r0
  82:	e8be 000f 	ldmia.w	lr!, {r0, r1, r2, r3}
  86:	46bc      	mov	ip, r7
  88:	e8ac 000f 	stmia.w	ip!, {r0, r1, r2, r3}
  8c:	e8be 000f 	ldmia.w	lr!, {r0, r1, r2, r3}
  90:	e8ac 000f 	stmia.w	ip!, {r0, r1, r2, r3}
  94:	e8be 000f 	ldmia.w	lr!, {r0, r1, r2, r3}
  98:	e8ac 000f 	stmia.w	ip!, {r0, r1, r2, r3}
  9c:	f8de 3000 	ldr.w	r3, [lr]
  a0:	f8cc 3000 	str.w	r3, [ip]
  a4:	454d      	cmp	r5, r9
  a6:	d1c4      	bne.n	32 <SystemGnss_ConfigApply+0x32>
  a8:	4650      	mov	r0, sl
  aa:	b011      	add	sp, #68	@ 0x44
  ac:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
  b0:	200c      	movs	r0, #12
  b2:	e7e0      	b.n	76 <SystemGnss_ConfigApply+0x76>
  b4:	f04f 0a05 	mov.w	sl, #5
  b8:	4650      	mov	r0, sl
  ba:	b011      	add	sp, #68	@ 0x44
  bc:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
	...
			c0: R_ARM_ABS32	.rodata.SystemSourceSelector_GnssSelectionPublish.str1.4
			c4: R_ARM_ABS32	.bss.s_gnss

Disassembly of section .text.SystemGnss_ConfigVerify:

00000000 <SystemGnss_ConfigVerify>:
   0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
   4:	b091      	sub	sp, #68	@ 0x44
   6:	2800      	cmp	r0, #0
   8:	d054      	beq.n	b4 <SystemGnss_ConfigVerify+0xb4>
   a:	460f      	mov	r7, r1
   c:	2900      	cmp	r1, #0
   e:	d051      	beq.n	b4 <SystemGnss_ConfigVerify+0xb4>
  10:	f240 5275 	movw	r2, #1397	@ 0x575
  14:	9200      	str	r2, [sp, #0]
  16:	4b2a      	ldr	r3, [pc, #168]	@ (c0 <SystemGnss_ConfigVerify+0xc0>)
  18:	4c2a      	ldr	r4, [pc, #168]	@ (c4 <SystemGnss_ConfigVerify+0xc4>)
  1a:	220c      	movs	r2, #12
  1c:	2104      	movs	r1, #4
  1e:	4606      	mov	r6, r0
  20:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			20: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  24:	f104 0904 	add.w	r9, r4, #4
  28:	4625      	mov	r5, r4
  2a:	f04f 0a02 	mov.w	sl, #2
  2e:	f04f 0800 	mov.w	r8, #0
  32:	f894 c010 	ldrb.w	ip, [r4, #16]
  36:	f8cd 8008 	str.w	r8, [sp, #8]
  3a:	1b2b      	subs	r3, r5, r4
  3c:	b2db      	uxtb	r3, r3
  3e:	459c      	cmp	ip, r3
  40:	f04f 0234 	mov.w	r2, #52	@ 0x34
  44:	f04f 0100 	mov.w	r1, #0
  48:	a803      	add	r0, sp, #12
  4a:	d92d      	bls.n	a8 <SystemGnss_ConfigVerify+0xa8>
  4c:	f815 bb01 	ldrb.w	fp, [r5], #1
  50:	eb04 030b 	add.w	r3, r4, fp
  54:	791b      	ldrb	r3, [r3, #4]
  56:	b32b      	cbz	r3, a4 <SystemGnss_ConfigVerify+0xa4>
  58:	f7ff fffe 	bl	0 <memset>
			58: R_ARM_THM_CALL	memset
  5c:	a902      	add	r1, sp, #8
  5e:	4658      	mov	r0, fp
  60:	f7ff fffe 	bl	0 <ProjectGnssInstance_CapabilitiesGet>
			60: R_ARM_THM_CALL	ProjectGnssInstance_CapabilitiesGet
  64:	b910      	cbnz	r0, 6c <SystemGnss_ConfigVerify+0x6c>
  66:	9b02      	ldr	r3, [sp, #8]
  68:	051b      	lsls	r3, r3, #20
  6a:	d421      	bmi.n	b0 <SystemGnss_ConfigVerify+0xb0>
  6c:	aa03      	add	r2, sp, #12
  6e:	4631      	mov	r1, r6
  70:	4658      	mov	r0, fp
  72:	f7ff fffe 	bl	0 <ProjectGnssInstance_ConfigVerify>
			72: R_ARM_THM_CALL	ProjectGnssInstance_ConfigVerify
  76:	7ca3      	ldrb	r3, [r4, #18]
  78:	455b      	cmp	r3, fp
  7a:	d113      	bne.n	a4 <SystemGnss_ConfigVerify+0xa4>
  7c:	f10d 0e0c 	add.w	lr, sp, #12
  80:	4682      	mov	sl, r0
  82:	e8be 000f 	ldmia.w	lr!, {r0, r1, r2, r3}
  86:	46bc      	mov	ip, r7
  88:	e8ac 000f 	stmia.w	ip!, {r0, r1, r2, r3}
  8c:	e8be 000f 	ldmia.w	lr!, {r0, r1, r2, r3}
  90:	e8ac 000f 	stmia.w	ip!, {r0, r1, r2, r3}
  94:	e8be 000f 	ldmia.w	lr!, {r0, r1, r2, r3}
  98:	e8ac 000f 	stmia.w	ip!, {r0, r1, r2, r3}
  9c:	f8de 3000 	ldr.w	r3, [lr]
  a0:	f8cc 3000 	str.w	r3, [ip]
  a4:	454d      	cmp	r5, r9
  a6:	d1c4      	bne.n	32 <SystemGnss_ConfigVerify+0x32>
  a8:	4650      	mov	r0, sl
  aa:	b011      	add	sp, #68	@ 0x44
  ac:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
  b0:	200c      	movs	r0, #12
  b2:	e7e0      	b.n	76 <SystemGnss_ConfigVerify+0x76>
  b4:	f04f 0a05 	mov.w	sl, #5
  b8:	4650      	mov	r0, sl
  ba:	b011      	add	sp, #68	@ 0x44
  bc:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
	...
			c0: R_ARM_ABS32	.rodata.SystemSourceSelector_GnssSelectionPublish.str1.4
			c4: R_ARM_ABS32	.bss.s_gnss

Disassembly of section .text.SystemGnss_EffectiveConfigGet:

00000000 <SystemGnss_EffectiveConfigGet>:
   0:	4601      	mov	r1, r0
   2:	b138      	cbz	r0, 14 <SystemGnss_EffectiveConfigGet+0x14>
   4:	4b04      	ldr	r3, [pc, #16]	@ (18 <SystemGnss_EffectiveConfigGet+0x18>)
   6:	7c98      	ldrb	r0, [r3, #18]
   8:	28ff      	cmp	r0, #255	@ 0xff
   a:	d001      	beq.n	10 <SystemGnss_EffectiveConfigGet+0x10>
   c:	f7ff bffe 	b.w	0 <ProjectGnssInstance_EffectiveConfigGet>
			c: R_ARM_THM_JUMP24	ProjectGnssInstance_EffectiveConfigGet
  10:	2002      	movs	r0, #2
  12:	4770      	bx	lr
  14:	2005      	movs	r0, #5
  16:	4770      	bx	lr
  18:	00000000 	.word	0x00000000
			18: R_ARM_ABS32	.bss.s_gnss

Disassembly of section .text.SystemGnss_NoiseCharacteristicsGet:

00000000 <SystemGnss_NoiseCharacteristicsGet>:
   0:	4601      	mov	r1, r0
   2:	b138      	cbz	r0, 14 <SystemGnss_NoiseCharacteristicsGet+0x14>
   4:	4b04      	ldr	r3, [pc, #16]	@ (18 <SystemGnss_NoiseCharacteristicsGet+0x18>)
   6:	7c98      	ldrb	r0, [r3, #18]
   8:	28ff      	cmp	r0, #255	@ 0xff
   a:	d001      	beq.n	10 <SystemGnss_NoiseCharacteristicsGet+0x10>
   c:	f7ff bffe 	b.w	0 <ProjectGnssInstance_NoiseCharacteristicsGet>
			c: R_ARM_THM_JUMP24	ProjectGnssInstance_NoiseCharacteristicsGet
  10:	2002      	movs	r0, #2
  12:	4770      	bx	lr
  14:	2005      	movs	r0, #5
  16:	4770      	bx	lr
  18:	00000000 	.word	0x00000000
			18: R_ARM_ABS32	.bss.s_gnss

Disassembly of section .text.SystemGnss_HardwareConfigRead:

00000000 <SystemGnss_HardwareConfigRead>:
   0:	4601      	mov	r1, r0
   2:	b138      	cbz	r0, 14 <SystemGnss_HardwareConfigRead+0x14>
   4:	4b04      	ldr	r3, [pc, #16]	@ (18 <SystemGnss_HardwareConfigRead+0x18>)
   6:	7c98      	ldrb	r0, [r3, #18]
   8:	28ff      	cmp	r0, #255	@ 0xff
   a:	d001      	beq.n	10 <SystemGnss_HardwareConfigRead+0x10>
   c:	f7ff bffe 	b.w	0 <ProjectGnssInstance_HardwareConfigRead>
			c: R_ARM_THM_JUMP24	ProjectGnssInstance_HardwareConfigRead
  10:	2002      	movs	r0, #2
  12:	4770      	bx	lr
  14:	2005      	movs	r0, #5
  16:	4770      	bx	lr
  18:	00000000 	.word	0x00000000
			18: R_ARM_ABS32	.bss.s_gnss

Disassembly of section .text.SystemGnss_LastConfigReportGet:

00000000 <SystemGnss_LastConfigReportGet>:
   0:	4601      	mov	r1, r0
   2:	b138      	cbz	r0, 14 <SystemGnss_LastConfigReportGet+0x14>
   4:	4b04      	ldr	r3, [pc, #16]	@ (18 <SystemGnss_LastConfigReportGet+0x18>)
   6:	7c98      	ldrb	r0, [r3, #18]
   8:	28ff      	cmp	r0, #255	@ 0xff
   a:	d001      	beq.n	10 <SystemGnss_LastConfigReportGet+0x10>
   c:	f7ff bffe 	b.w	0 <ProjectGnssInstance_LastConfigReportGet>
			c: R_ARM_THM_JUMP24	ProjectGnssInstance_LastConfigReportGet
  10:	2002      	movs	r0, #2
  12:	4770      	bx	lr
  14:	2005      	movs	r0, #5
  16:	4770      	bx	lr
  18:	00000000 	.word	0x00000000
			18: R_ARM_ABS32	.bss.s_gnss

Disassembly of section .text.SystemGnss_SatelliteDiagnosticsRead:

00000000 <SystemGnss_SatelliteDiagnosticsRead>:
   0:	4601      	mov	r1, r0
   2:	b138      	cbz	r0, 14 <SystemGnss_SatelliteDiagnosticsRead+0x14>
   4:	4b04      	ldr	r3, [pc, #16]	@ (18 <SystemGnss_SatelliteDiagnosticsRead+0x18>)
   6:	7c98      	ldrb	r0, [r3, #18]
   8:	28ff      	cmp	r0, #255	@ 0xff
   a:	d001      	beq.n	10 <SystemGnss_SatelliteDiagnosticsRead+0x10>
   c:	f7ff bffe 	b.w	0 <ProjectGnssInstance_SatelliteDiagnosticsRead>
			c: R_ARM_THM_JUMP24	ProjectGnssInstance_SatelliteDiagnosticsRead
  10:	2002      	movs	r0, #2
  12:	4770      	bx	lr
  14:	2005      	movs	r0, #5
  16:	4770      	bx	lr
  18:	00000000 	.word	0x00000000
			18: R_ARM_ABS32	.bss.s_gnss

Disassembly of section .text.SystemGnss_LatestSatelliteDiagnosticsGet:

00000000 <SystemGnss_LatestSatelliteDiagnosticsGet>:
   0:	4601      	mov	r1, r0
   2:	b138      	cbz	r0, 14 <SystemGnss_LatestSatelliteDiagnosticsGet+0x14>
   4:	4b04      	ldr	r3, [pc, #16]	@ (18 <SystemGnss_LatestSatelliteDiagnosticsGet+0x18>)
   6:	7c98      	ldrb	r0, [r3, #18]
   8:	28ff      	cmp	r0, #255	@ 0xff
   a:	d001      	beq.n	10 <SystemGnss_LatestSatelliteDiagnosticsGet+0x10>
   c:	f7ff bffe 	b.w	0 <ProjectGnssInstance_LatestSatelliteDiagnosticsGet>
			c: R_ARM_THM_JUMP24	ProjectGnssInstance_LatestSatelliteDiagnosticsGet
  10:	2002      	movs	r0, #2
  12:	4770      	bx	lr
  14:	2005      	movs	r0, #5
  16:	4770      	bx	lr
  18:	00000000 	.word	0x00000000
			18: R_ARM_ABS32	.bss.s_gnss

Disassembly of section .text.SystemGnss_RfDiagnosticsRead:

00000000 <SystemGnss_RfDiagnosticsRead>:
   0:	4601      	mov	r1, r0
   2:	b138      	cbz	r0, 14 <SystemGnss_RfDiagnosticsRead+0x14>
   4:	4b04      	ldr	r3, [pc, #16]	@ (18 <SystemGnss_RfDiagnosticsRead+0x18>)
   6:	7c98      	ldrb	r0, [r3, #18]
   8:	28ff      	cmp	r0, #255	@ 0xff
   a:	d001      	beq.n	10 <SystemGnss_RfDiagnosticsRead+0x10>
   c:	f7ff bffe 	b.w	0 <ProjectGnssInstance_RfDiagnosticsRead>
			c: R_ARM_THM_JUMP24	ProjectGnssInstance_RfDiagnosticsRead
  10:	2002      	movs	r0, #2
  12:	4770      	bx	lr
  14:	2005      	movs	r0, #5
  16:	4770      	bx	lr
  18:	00000000 	.word	0x00000000
			18: R_ARM_ABS32	.bss.s_gnss

Disassembly of section .text.SystemGnss_LatestRfDiagnosticsGet:

00000000 <SystemGnss_LatestRfDiagnosticsGet>:
   0:	4601      	mov	r1, r0
   2:	b138      	cbz	r0, 14 <SystemGnss_LatestRfDiagnosticsGet+0x14>
   4:	4b04      	ldr	r3, [pc, #16]	@ (18 <SystemGnss_LatestRfDiagnosticsGet+0x18>)
   6:	7c98      	ldrb	r0, [r3, #18]
   8:	28ff      	cmp	r0, #255	@ 0xff
   a:	d001      	beq.n	10 <SystemGnss_LatestRfDiagnosticsGet+0x10>
   c:	f7ff bffe 	b.w	0 <ProjectGnssInstance_LatestRfDiagnosticsGet>
			c: R_ARM_THM_JUMP24	ProjectGnssInstance_LatestRfDiagnosticsGet
  10:	2002      	movs	r0, #2
  12:	4770      	bx	lr
  14:	2005      	movs	r0, #5
  16:	4770      	bx	lr
  18:	00000000 	.word	0x00000000
			18: R_ARM_ABS32	.bss.s_gnss

Disassembly of section .text.SystemTelemetry_NameGet:

00000000 <SystemTelemetry_NameGet>:
   0:	4b0a      	ldr	r3, [pc, #40]	@ (2c <SystemTelemetry_NameGet+0x2c>)
   2:	7c98      	ldrb	r0, [r3, #18]
   4:	28ff      	cmp	r0, #255	@ 0xff
   6:	d101      	bne.n	c <SystemTelemetry_NameGet+0xc>
   8:	4809      	ldr	r0, [pc, #36]	@ (30 <SystemTelemetry_NameGet+0x30>)
   a:	4770      	bx	lr
   c:	b500      	push	{lr}
   e:	b087      	sub	sp, #28
  10:	a901      	add	r1, sp, #4
  12:	f7ff fffe 	bl	0 <ProjectTelemetryInstance_InfoGet>
			12: R_ARM_THM_CALL	ProjectTelemetryInstance_InfoGet
  16:	b920      	cbnz	r0, 22 <SystemTelemetry_NameGet+0x22>
  18:	9801      	ldr	r0, [sp, #4]
  1a:	b110      	cbz	r0, 22 <SystemTelemetry_NameGet+0x22>
  1c:	b007      	add	sp, #28
  1e:	f85d fb04 	ldr.w	pc, [sp], #4
  22:	4803      	ldr	r0, [pc, #12]	@ (30 <SystemTelemetry_NameGet+0x30>)
  24:	b007      	add	sp, #28
  26:	f85d fb04 	ldr.w	pc, [sp], #4
  2a:	bf00      	nop
	...
			2c: R_ARM_ABS32	.bss.s_telemetry
			30: R_ARM_ABS32	.rodata.SystemTelemetry_NameGet.str1.4

Disassembly of section .text.SystemTelemetry_Init:

00000000 <SystemTelemetry_Init>:
   0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
   4:	4c54      	ldr	r4, [pc, #336]	@ (158 <SystemTelemetry_Init+0x158>)
   6:	7c20      	ldrb	r0, [r4, #16]
   8:	b083      	sub	sp, #12
   a:	2300      	movs	r3, #0
   c:	f104 010b 	add.w	r1, r4, #11
  10:	b2da      	uxtb	r2, r3
  12:	4290      	cmp	r0, r2
  14:	f103 0301 	add.w	r3, r3, #1
  18:	d906      	bls.n	28 <SystemTelemetry_Init+0x28>
  1a:	f811 2f01 	ldrb.w	r2, [r1, #1]!
  1e:	2a00      	cmp	r2, #0
  20:	f040 8093 	bne.w	14a <SystemTelemetry_Init+0x14a>
  24:	2b04      	cmp	r3, #4
  26:	d1f3      	bne.n	10 <SystemTelemetry_Init+0x10>
  28:	2100      	movs	r1, #0
  2a:	223c      	movs	r2, #60	@ 0x3c
  2c:	484a      	ldr	r0, [pc, #296]	@ (158 <SystemTelemetry_Init+0x158>)
  2e:	f7ff fffe 	bl	0 <memset>
			2e: R_ARM_THM_CALL	memset
  32:	22ff      	movs	r2, #255	@ 0xff
  34:	f64f 73ff 	movw	r3, #65535	@ 0xffff
  38:	74e2      	strb	r2, [r4, #19]
  3a:	f8a4 3011 	strh.w	r3, [r4, #17]
  3e:	f7ff fffe 	bl	0 <ProjectTelemetryInstance_CountGet>
			3e: R_ARM_THM_CALL	ProjectTelemetryInstance_CountGet
  42:	2804      	cmp	r0, #4
  44:	4601      	mov	r1, r0
  46:	7420      	strb	r0, [r4, #16]
  48:	d84f      	bhi.n	ea <SystemTelemetry_Init+0xea>
  4a:	4a43      	ldr	r2, [pc, #268]	@ (158 <SystemTelemetry_Init+0x158>)
  4c:	2006      	movs	r0, #6
  4e:	f7ff fffe 	bl	0 <SystemTelemetry_Init>
			4e: R_ARM_THM_CALL	SystemSourceSelector_OrderBuild.part.0.constprop.0
  52:	7420      	strb	r0, [r4, #16]
  54:	b108      	cbz	r0, 5a <SystemTelemetry_Init+0x5a>
  56:	7823      	ldrb	r3, [r4, #0]
  58:	7463      	strb	r3, [r4, #17]
  5a:	2600      	movs	r6, #0
  5c:	fa5f fa86 	uxtb.w	sl, r6
  60:	4550      	cmp	r0, sl
  62:	f8df 90f4 	ldr.w	r9, [pc, #244]	@ 158 <SystemTelemetry_Init+0x158>
  66:	4a3d      	ldr	r2, [pc, #244]	@ (15c <SystemTelemetry_Init+0x15c>)
  68:	46b3      	mov	fp, r6
  6a:	f04f 0810 	mov.w	r8, #16
  6e:	f240 7337 	movw	r3, #1847	@ 0x737
  72:	d92b      	bls.n	cc <SystemTelemetry_Init+0xcc>
  74:	f899 7000 	ldrb.w	r7, [r9]
  78:	2103      	movs	r1, #3
  7a:	4287      	cmp	r7, r0
  7c:	bf2c      	ite	cs
  7e:	2000      	movcs	r0, #0
  80:	2001      	movcc	r0, #1
  82:	9100      	str	r1, [sp, #0]
  84:	210c      	movs	r1, #12
  86:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			86: R_ARM_THM_CALL	SilverStarAssert_Check
  8a:	4638      	mov	r0, r7
  8c:	f7ff fffe 	bl	0 <ProjectTelemetryInstance_Init>
			8c: R_ARM_THM_CALL	ProjectTelemetryInstance_Init
  90:	2810      	cmp	r0, #16
  92:	f04f 0302 	mov.w	r3, #2
  96:	4605      	mov	r5, r0
  98:	d92f      	bls.n	fa <SystemTelemetry_Init+0xfa>
  9a:	9300      	str	r3, [sp, #0]
  9c:	4a2f      	ldr	r2, [pc, #188]	@ (15c <SystemTelemetry_Init+0x15c>)
  9e:	f240 733a 	movw	r3, #1850	@ 0x73a
  a2:	210c      	movs	r1, #12
  a4:	2000      	movs	r0, #0
  a6:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			a6: R_ARM_THM_CALL	SilverStarAssert_Check
  aa:	f1b8 0f10 	cmp.w	r8, #16
  ae:	bf08      	it	eq
  b0:	46a8      	moveq	r8, r5
  b2:	3601      	adds	r6, #1
  b4:	2e04      	cmp	r6, #4
  b6:	d009      	beq.n	cc <SystemTelemetry_Init+0xcc>
  b8:	7c20      	ldrb	r0, [r4, #16]
  ba:	4a28      	ldr	r2, [pc, #160]	@ (15c <SystemTelemetry_Init+0x15c>)
  bc:	fa5f fa86 	uxtb.w	sl, r6
  c0:	4550      	cmp	r0, sl
  c2:	f109 0901 	add.w	r9, r9, #1
  c6:	f240 7337 	movw	r3, #1847	@ 0x737
  ca:	d8d3      	bhi.n	74 <SystemTelemetry_Init+0x74>
  cc:	7ca2      	ldrb	r2, [r4, #18]
  ce:	2aff      	cmp	r2, #255	@ 0xff
  d0:	d002      	beq.n	d8 <SystemTelemetry_Init+0xd8>
  d2:	7c61      	ldrb	r1, [r4, #17]
  d4:	428a      	cmp	r2, r1
  d6:	d12e      	bne.n	136 <SystemTelemetry_Init+0x136>
  d8:	f1bb 0f00 	cmp.w	fp, #0
  dc:	bf18      	it	ne
  de:	f04f 0800 	movne.w	r8, #0
  e2:	4640      	mov	r0, r8
  e4:	b003      	add	sp, #12
  e6:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
  ea:	f04f 080b 	mov.w	r8, #11
  ee:	2300      	movs	r3, #0
  f0:	4640      	mov	r0, r8
  f2:	7423      	strb	r3, [r4, #16]
  f4:	b003      	add	sp, #12
  f6:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
  fa:	4a18      	ldr	r2, [pc, #96]	@ (15c <SystemTelemetry_Init+0x15c>)
  fc:	9300      	str	r3, [sp, #0]
  fe:	210c      	movs	r1, #12
 100:	f240 733a 	movw	r3, #1850	@ 0x73a
 104:	2001      	movs	r0, #1
 106:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			106: R_ARM_THM_CALL	SilverStarAssert_Check
 10a:	2d0d      	cmp	r5, #13
 10c:	f10b 0201 	add.w	r2, fp, #1
 110:	d8cb      	bhi.n	aa <SystemTelemetry_Init+0xaa>
 112:	f243 4303 	movw	r3, #13315	@ 0x3403
 116:	40eb      	lsrs	r3, r5
 118:	07db      	lsls	r3, r3, #31
 11a:	d5c6      	bpl.n	aa <SystemTelemetry_Init+0xaa>
 11c:	fa5f fb82 	uxtb.w	fp, r2
 120:	7ca2      	ldrb	r2, [r4, #18]
 122:	19e3      	adds	r3, r4, r7
 124:	2aff      	cmp	r2, #255	@ 0xff
 126:	f04f 0101 	mov.w	r1, #1
 12a:	7119      	strb	r1, [r3, #4]
 12c:	bf04      	itt	eq
 12e:	74a7      	strbeq	r7, [r4, #18]
 130:	f884 a013 	strbeq.w	sl, [r4, #19]
 134:	e7bd      	b.n	b2 <SystemTelemetry_Init+0xb2>
 136:	2308      	movs	r3, #8
 138:	2006      	movs	r0, #6
 13a:	f7ff fffe 	bl	0 <SystemTelemetry_Init>
			13a: R_ARM_THM_CALL	SystemSourceSelector_EventRecord
 13e:	f1bb 0f00 	cmp.w	fp, #0
 142:	bf18      	it	ne
 144:	f04f 0800 	movne.w	r8, #0
 148:	e7cb      	b.n	e2 <SystemTelemetry_Init+0xe2>
 14a:	f04f 080f 	mov.w	r8, #15
 14e:	4640      	mov	r0, r8
 150:	b003      	add	sp, #12
 152:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 156:	bf00      	nop
	...
			158: R_ARM_ABS32	.bss.s_telemetry
			15c: R_ARM_ABS32	.rodata.SystemSourceSelector_GnssSelectionPublish.str1.4

Disassembly of section .text.SystemTelemetry_Start:

00000000 <SystemTelemetry_Start>:
   0:	b530      	push	{r4, r5, lr}
   2:	4c37      	ldr	r4, [pc, #220]	@ (e0 <SystemTelemetry_Start+0xe0>)
   4:	4a37      	ldr	r2, [pc, #220]	@ (e4 <SystemTelemetry_Start+0xe4>)
   6:	7c20      	ldrb	r0, [r4, #16]
   8:	b08f      	sub	sp, #60	@ 0x3c
   a:	2804      	cmp	r0, #4
   c:	f04f 030a 	mov.w	r3, #10
  10:	9300      	str	r3, [sp, #0]
  12:	f04f 010c 	mov.w	r1, #12
  16:	f240 735a 	movw	r3, #1882	@ 0x75a
  1a:	bf8c      	ite	hi
  1c:	2000      	movhi	r0, #0
  1e:	2001      	movls	r0, #1
  20:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			20: R_ARM_THM_CALL	SilverStarAssert_Check
  24:	2201      	movs	r2, #1
  26:	7c20      	ldrb	r0, [r4, #16]
  28:	f884 2026 	strb.w	r2, [r4, #38]	@ 0x26
  2c:	2300      	movs	r3, #0
  2e:	f104 010b 	add.w	r1, r4, #11
  32:	b2da      	uxtb	r2, r3
  34:	4290      	cmp	r0, r2
  36:	f103 0301 	add.w	r3, r3, #1
  3a:	d92f      	bls.n	9c <SystemTelemetry_Start+0x9c>
  3c:	f811 2f01 	ldrb.w	r2, [r1, #1]!
  40:	2a00      	cmp	r2, #0
  42:	d136      	bne.n	b2 <SystemTelemetry_Start+0xb2>
  44:	2b04      	cmp	r3, #4
  46:	d1f4      	bne.n	32 <SystemTelemetry_Start+0x32>
  48:	7ca3      	ldrb	r3, [r4, #18]
  4a:	2bff      	cmp	r3, #255	@ 0xff
  4c:	d018      	beq.n	80 <SystemTelemetry_Start+0x80>
  4e:	4283      	cmp	r3, r0
  50:	f04f 0303 	mov.w	r3, #3
  54:	bf2c      	ite	cs
  56:	2000      	movcs	r0, #0
  58:	2001      	movcc	r0, #1
  5a:	4a22      	ldr	r2, [pc, #136]	@ (e4 <SystemTelemetry_Start+0xe4>)
  5c:	9300      	str	r3, [sp, #0]
  5e:	210c      	movs	r1, #12
  60:	f240 7361 	movw	r3, #1889	@ 0x761
  64:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			64: R_ARM_THM_CALL	SilverStarAssert_Check
  68:	7ca5      	ldrb	r5, [r4, #18]
  6a:	4628      	mov	r0, r5
  6c:	f7ff fffe 	bl	0 <SystemTelemetry_Start>
			6c: R_ARM_THM_CALL	SystemSourceSelector_TelemetryCandidateStart
  70:	2801      	cmp	r0, #1
  72:	d008      	beq.n	86 <SystemTelemetry_Start+0x86>
  74:	2802      	cmp	r0, #2
  76:	d01f      	beq.n	b8 <SystemTelemetry_Start+0xb8>
  78:	2000      	movs	r0, #0
  7a:	f7ff fffe 	bl	0 <SystemTelemetry_Start>
			7a: R_ARM_THM_CALL	SystemSourceSelector_TelemetryNextStart
  7e:	b980      	cbnz	r0, a2 <SystemTelemetry_Start+0xa2>
  80:	2002      	movs	r0, #2
  82:	b00f      	add	sp, #60	@ 0x3c
  84:	bd30      	pop	{r4, r5, pc}
  86:	ed9f 7b14 	vldr	d7, [pc, #80]	@ d8 <SystemTelemetry_Start+0xd8>
  8a:	7ca0      	ldrb	r0, [r4, #18]
  8c:	2300      	movs	r3, #0
  8e:	28ff      	cmp	r0, #255	@ 0xff
  90:	ed84 7b06 	vstr	d7, [r4, #24]
  94:	82a3      	strh	r3, [r4, #20]
  96:	d112      	bne.n	be <SystemTelemetry_Start+0xbe>
  98:	2000      	movs	r0, #0
  9a:	e7f2      	b.n	82 <SystemTelemetry_Start+0x82>
  9c:	2800      	cmp	r0, #0
  9e:	d0ef      	beq.n	80 <SystemTelemetry_Start+0x80>
  a0:	e7d2      	b.n	48 <SystemTelemetry_Start+0x48>
  a2:	2006      	movs	r0, #6
  a4:	7ca2      	ldrb	r2, [r4, #18]
  a6:	2308      	movs	r3, #8
  a8:	4629      	mov	r1, r5
  aa:	f7ff fffe 	bl	0 <SystemTelemetry_Start>
			aa: R_ARM_THM_CALL	SystemSourceSelector_EventRecord
  ae:	2000      	movs	r0, #0
  b0:	e7e7      	b.n	82 <SystemTelemetry_Start+0x82>
  b2:	200f      	movs	r0, #15
  b4:	b00f      	add	sp, #60	@ 0x3c
  b6:	bd30      	pop	{r4, r5, pc}
  b8:	2007      	movs	r0, #7
  ba:	b00f      	add	sp, #60	@ 0x3c
  bc:	bd30      	pop	{r4, r5, pc}
  be:	a902      	add	r1, sp, #8
  c0:	f7ff fffe 	bl	0 <ProjectTelemetryInstance_HealthGet>
			c0: R_ARM_THM_CALL	ProjectTelemetryInstance_HealthGet
  c4:	2800      	cmp	r0, #0
  c6:	d1e7      	bne.n	98 <SystemTelemetry_Start+0x98>
  c8:	9a06      	ldr	r2, [sp, #24]
  ca:	9b08      	ldr	r3, [sp, #32]
  cc:	e9c4 2306 	strd	r2, r3, [r4, #24]
  d0:	e7e2      	b.n	98 <SystemTelemetry_Start+0x98>
  d2:	bf00      	nop
  d4:	f3af 8000 	nop.w
	...
			e0: R_ARM_ABS32	.bss.s_telemetry
			e4: R_ARM_ABS32	.rodata.SystemSourceSelector_GnssSelectionPublish.str1.4

Disassembly of section .text.SystemTelemetry_Stop:

00000000 <SystemTelemetry_Stop>:
   0:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
   2:	4c1e      	ldr	r4, [pc, #120]	@ (7c <SystemTelemetry_Stop+0x7c>)
   4:	7c20      	ldrb	r0, [r4, #16]
   6:	2300      	movs	r3, #0
   8:	f104 010b 	add.w	r1, r4, #11
   c:	b2da      	uxtb	r2, r3
   e:	4282      	cmp	r2, r0
  10:	f103 0301 	add.w	r3, r3, #1
  14:	d22e      	bcs.n	74 <SystemTelemetry_Stop+0x74>
  16:	f811 5f01 	ldrb.w	r5, [r1, #1]!
  1a:	bb6d      	cbnz	r5, 78 <SystemTelemetry_Stop+0x78>
  1c:	2b04      	cmp	r3, #4
  1e:	d1f5      	bne.n	c <SystemTelemetry_Stop+0xc>
  20:	7ca0      	ldrb	r0, [r4, #18]
  22:	2700      	movs	r7, #0
  24:	28ff      	cmp	r0, #255	@ 0xff
  26:	f884 7026 	strb.w	r7, [r4, #38]	@ 0x26
  2a:	d020      	beq.n	6e <SystemTelemetry_Stop+0x6e>
  2c:	f7ff fffe 	bl	0 <ProjectTelemetryInstance_Stop>
			2c: R_ARM_THM_CALL	ProjectTelemetryInstance_Stop
  30:	7ca3      	ldrb	r3, [r4, #18]
  32:	18e1      	adds	r1, r4, r3
  34:	280d      	cmp	r0, #13
  36:	4606      	mov	r6, r0
  38:	720f      	strb	r7, [r1, #8]
  3a:	d807      	bhi.n	4c <SystemTelemetry_Stop+0x4c>
  3c:	f243 4203 	movw	r2, #13315	@ 0x3403
  40:	40c2      	lsrs	r2, r0
  42:	07d2      	lsls	r2, r2, #31
  44:	d502      	bpl.n	4c <SystemTelemetry_Stop+0x4c>
  46:	730f      	strb	r7, [r1, #12]
  48:	4630      	mov	r0, r6
  4a:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
  4c:	4423      	add	r3, r4
  4e:	2701      	movs	r7, #1
  50:	731f      	strb	r7, [r3, #12]
  52:	2d00      	cmp	r5, #0
  54:	d1f8      	bne.n	48 <SystemTelemetry_Stop+0x48>
  56:	f7ff fffe 	bl	0 <SystemTime_GetMonotonicUs>
			56: R_ARM_THM_CALL	SystemTime_GetMonotonicUs
  5a:	f44f 727a 	mov.w	r2, #1000	@ 0x3e8
  5e:	2300      	movs	r3, #0
  60:	f7ff fffe 	bl	0 <__aeabi_uldivmod>
			60: R_ARM_THM_CALL	__aeabi_uldivmod
  64:	f884 7024 	strb.w	r7, [r4, #36]	@ 0x24
  68:	6220      	str	r0, [r4, #32]
  6a:	4630      	mov	r0, r6
  6c:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
  6e:	2602      	movs	r6, #2
  70:	4630      	mov	r0, r6
  72:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
  74:	2500      	movs	r5, #0
  76:	e7d3      	b.n	20 <SystemTelemetry_Stop+0x20>
  78:	2501      	movs	r5, #1
  7a:	e7d1      	b.n	20 <SystemTelemetry_Stop+0x20>
  7c:	00000000 	.word	0x00000000
			7c: R_ARM_ABS32	.bss.s_telemetry

Disassembly of section .text.SystemTelemetry_Send:

00000000 <SystemTelemetry_Send>:
   0:	b1e8      	cbz	r0, 3e <SystemTelemetry_Send+0x3e>
   2:	460a      	mov	r2, r1
   4:	b1d9      	cbz	r1, 3e <SystemTelemetry_Send+0x3e>
   6:	4b11      	ldr	r3, [pc, #68]	@ (4c <SystemTelemetry_Send+0x4c>)
   8:	4601      	mov	r1, r0
   a:	7c98      	ldrb	r0, [r3, #18]
   c:	28ff      	cmp	r0, #255	@ 0xff
   e:	d01a      	beq.n	46 <SystemTelemetry_Send+0x46>
  10:	b530      	push	{r4, r5, lr}
  12:	181c      	adds	r4, r3, r0
  14:	7a24      	ldrb	r4, [r4, #8]
  16:	b1a4      	cbz	r4, 42 <SystemTelemetry_Send+0x42>
  18:	7c1d      	ldrb	r5, [r3, #16]
  1a:	f103 0c0b 	add.w	ip, r3, #11
  1e:	2300      	movs	r3, #0
  20:	fa5f fe83 	uxtb.w	lr, r3
  24:	4575      	cmp	r5, lr
  26:	f103 0301 	add.w	r3, r3, #1
  2a:	d904      	bls.n	36 <SystemTelemetry_Send+0x36>
  2c:	f81c 4f01 	ldrb.w	r4, [ip, #1]!
  30:	b93c      	cbnz	r4, 42 <SystemTelemetry_Send+0x42>
  32:	2b04      	cmp	r3, #4
  34:	d1f4      	bne.n	20 <SystemTelemetry_Send+0x20>
  36:	e8bd 4030 	ldmia.w	sp!, {r4, r5, lr}
  3a:	f7ff bffe 	b.w	0 <ProjectTelemetryInstance_Send>
			3a: R_ARM_THM_JUMP24	ProjectTelemetryInstance_Send
  3e:	2005      	movs	r0, #5
  40:	4770      	bx	lr
  42:	2002      	movs	r0, #2
  44:	bd30      	pop	{r4, r5, pc}
  46:	2002      	movs	r0, #2
  48:	4770      	bx	lr
  4a:	bf00      	nop
  4c:	00000000 	.word	0x00000000
			4c: R_ARM_ABS32	.bss.s_telemetry

Disassembly of section .text.SystemTelemetry_SendControl:

00000000 <SystemTelemetry_SendControl>:
   0:	b570      	push	{r4, r5, r6, lr}
   2:	4613      	mov	r3, r2
   4:	4605      	mov	r5, r0
   6:	b10a      	cbz	r2, c <SystemTelemetry_SendControl+0xc>
   8:	2200      	movs	r2, #0
   a:	601a      	str	r2, [r3, #0]
   c:	b305      	cbz	r5, 50 <SystemTelemetry_SendControl+0x50>
   e:	b1f9      	cbz	r1, 50 <SystemTelemetry_SendControl+0x50>
  10:	4c10      	ldr	r4, [pc, #64]	@ (54 <SystemTelemetry_SendControl+0x54>)
  12:	7ca0      	ldrb	r0, [r4, #18]
  14:	28ff      	cmp	r0, #255	@ 0xff
  16:	d019      	beq.n	4c <SystemTelemetry_SendControl+0x4c>
  18:	1822      	adds	r2, r4, r0
  1a:	7a12      	ldrb	r2, [r2, #8]
  1c:	b1b2      	cbz	r2, 4c <SystemTelemetry_SendControl+0x4c>
  1e:	7c26      	ldrb	r6, [r4, #16]
  20:	f104 0e0b 	add.w	lr, r4, #11
  24:	f04f 0c00 	mov.w	ip, #0
  28:	fa5f f48c 	uxtb.w	r4, ip
  2c:	42a6      	cmp	r6, r4
  2e:	f10c 0c01 	add.w	ip, ip, #1
  32:	d905      	bls.n	40 <SystemTelemetry_SendControl+0x40>
  34:	f81e 2f01 	ldrb.w	r2, [lr, #1]!
  38:	b942      	cbnz	r2, 4c <SystemTelemetry_SendControl+0x4c>
  3a:	f1bc 0f04 	cmp.w	ip, #4
  3e:	d1f3      	bne.n	28 <SystemTelemetry_SendControl+0x28>
  40:	460a      	mov	r2, r1
  42:	4629      	mov	r1, r5
  44:	e8bd 4070 	ldmia.w	sp!, {r4, r5, r6, lr}
  48:	f7ff bffe 	b.w	0 <ProjectTelemetryInstance_SendControl>
			48: R_ARM_THM_JUMP24	ProjectTelemetryInstance_SendControl
  4c:	2002      	movs	r0, #2
  4e:	bd70      	pop	{r4, r5, r6, pc}
  50:	2005      	movs	r0, #5
  52:	bd70      	pop	{r4, r5, r6, pc}
  54:	00000000 	.word	0x00000000
			54: R_ARM_ABS32	.bss.s_telemetry

Disassembly of section .text.SystemTelemetry_TxResultGet:

00000000 <SystemTelemetry_TxResultGet>:
   0:	b1e8      	cbz	r0, 3e <SystemTelemetry_TxResultGet+0x3e>
   2:	460a      	mov	r2, r1
   4:	b1d9      	cbz	r1, 3e <SystemTelemetry_TxResultGet+0x3e>
   6:	4b11      	ldr	r3, [pc, #68]	@ (4c <SystemTelemetry_TxResultGet+0x4c>)
   8:	4601      	mov	r1, r0
   a:	7c98      	ldrb	r0, [r3, #18]
   c:	28ff      	cmp	r0, #255	@ 0xff
   e:	d01a      	beq.n	46 <SystemTelemetry_TxResultGet+0x46>
  10:	b530      	push	{r4, r5, lr}
  12:	181c      	adds	r4, r3, r0
  14:	7a24      	ldrb	r4, [r4, #8]
  16:	b1a4      	cbz	r4, 42 <SystemTelemetry_TxResultGet+0x42>
  18:	7c1d      	ldrb	r5, [r3, #16]
  1a:	f103 0c0b 	add.w	ip, r3, #11
  1e:	2300      	movs	r3, #0
  20:	fa5f fe83 	uxtb.w	lr, r3
  24:	4575      	cmp	r5, lr
  26:	f103 0301 	add.w	r3, r3, #1
  2a:	d904      	bls.n	36 <SystemTelemetry_TxResultGet+0x36>
  2c:	f81c 4f01 	ldrb.w	r4, [ip, #1]!
  30:	b93c      	cbnz	r4, 42 <SystemTelemetry_TxResultGet+0x42>
  32:	2b04      	cmp	r3, #4
  34:	d1f4      	bne.n	20 <SystemTelemetry_TxResultGet+0x20>
  36:	e8bd 4030 	ldmia.w	sp!, {r4, r5, lr}
  3a:	f7ff bffe 	b.w	0 <ProjectTelemetryInstance_TxResultGet>
			3a: R_ARM_THM_JUMP24	ProjectTelemetryInstance_TxResultGet
  3e:	2005      	movs	r0, #5
  40:	4770      	bx	lr
  42:	2002      	movs	r0, #2
  44:	bd30      	pop	{r4, r5, pc}
  46:	2002      	movs	r0, #2
  48:	4770      	bx	lr
  4a:	bf00      	nop
  4c:	00000000 	.word	0x00000000
			4c: R_ARM_ABS32	.bss.s_telemetry

Disassembly of section .text.SystemTelemetry_Receive:

00000000 <SystemTelemetry_Receive>:
   0:	b320      	cbz	r0, 4c <SystemTelemetry_Receive+0x4c>
   2:	4613      	mov	r3, r2
   4:	b312      	cbz	r2, 4c <SystemTelemetry_Receive+0x4c>
   6:	b530      	push	{r4, r5, lr}
   8:	460d      	mov	r5, r1
   a:	b309      	cbz	r1, 50 <SystemTelemetry_Receive+0x50>
   c:	4c11      	ldr	r4, [pc, #68]	@ (54 <SystemTelemetry_Receive+0x54>)
   e:	4601      	mov	r1, r0
  10:	7ca0      	ldrb	r0, [r4, #18]
  12:	28ff      	cmp	r0, #255	@ 0xff
  14:	d018      	beq.n	48 <SystemTelemetry_Receive+0x48>
  16:	1822      	adds	r2, r4, r0
  18:	7a12      	ldrb	r2, [r2, #8]
  1a:	b1aa      	cbz	r2, 48 <SystemTelemetry_Receive+0x48>
  1c:	7c22      	ldrb	r2, [r4, #16]
  1e:	f104 0e0b 	add.w	lr, r4, #11
  22:	f04f 0c00 	mov.w	ip, #0
  26:	fa5f f48c 	uxtb.w	r4, ip
  2a:	42a2      	cmp	r2, r4
  2c:	f10c 0c01 	add.w	ip, ip, #1
  30:	d905      	bls.n	3e <SystemTelemetry_Receive+0x3e>
  32:	f81e 4f01 	ldrb.w	r4, [lr, #1]!
  36:	b93c      	cbnz	r4, 48 <SystemTelemetry_Receive+0x48>
  38:	f1bc 0f04 	cmp.w	ip, #4
  3c:	d1f3      	bne.n	26 <SystemTelemetry_Receive+0x26>
  3e:	462a      	mov	r2, r5
  40:	e8bd 4030 	ldmia.w	sp!, {r4, r5, lr}
  44:	f7ff bffe 	b.w	0 <ProjectTelemetryInstance_Receive>
			44: R_ARM_THM_JUMP24	ProjectTelemetryInstance_Receive
  48:	2002      	movs	r0, #2
  4a:	bd30      	pop	{r4, r5, pc}
  4c:	2005      	movs	r0, #5
  4e:	4770      	bx	lr
  50:	2005      	movs	r0, #5
  52:	bd30      	pop	{r4, r5, pc}
  54:	00000000 	.word	0x00000000
			54: R_ARM_ABS32	.bss.s_telemetry

Disassembly of section .text.SystemTelemetry_Process:

00000000 <SystemTelemetry_Process>:
   0:	b570      	push	{r4, r5, r6, lr}
   2:	4c5a      	ldr	r4, [pc, #360]	@ (16c <SystemTelemetry_Process+0x16c>)
   4:	7c20      	ldrb	r0, [r4, #16]
   6:	b08e      	sub	sp, #56	@ 0x38
   8:	2300      	movs	r3, #0
   a:	f104 010b 	add.w	r1, r4, #11
   e:	b2da      	uxtb	r2, r3
  10:	4290      	cmp	r0, r2
  12:	f103 0301 	add.w	r3, r3, #1
  16:	d905      	bls.n	24 <SystemTelemetry_Process+0x24>
  18:	f811 2f01 	ldrb.w	r2, [r1, #1]!
  1c:	2a00      	cmp	r2, #0
  1e:	d171      	bne.n	104 <SystemTelemetry_Process+0x104>
  20:	2b04      	cmp	r3, #4
  22:	d1f4      	bne.n	e <SystemTelemetry_Process+0xe>
  24:	f894 3026 	ldrb.w	r3, [r4, #38]	@ 0x26
  28:	b153      	cbz	r3, 40 <SystemTelemetry_Process+0x40>
  2a:	7ca5      	ldrb	r5, [r4, #18]
  2c:	2dff      	cmp	r5, #255	@ 0xff
  2e:	d002      	beq.n	36 <SystemTelemetry_Process+0x36>
  30:	1963      	adds	r3, r4, r5
  32:	7a1b      	ldrb	r3, [r3, #8]
  34:	b97b      	cbnz	r3, 56 <SystemTelemetry_Process+0x56>
  36:	2001      	movs	r0, #1
  38:	f7ff fffe 	bl	0 <SystemTelemetry_Process>
			38: R_ARM_THM_CALL	SystemSourceSelector_TelemetryRecoveryTry
  3c:	2800      	cmp	r0, #0
  3e:	d169      	bne.n	114 <SystemTelemetry_Process+0x114>
  40:	7ca5      	ldrb	r5, [r4, #18]
  42:	2dff      	cmp	r5, #255	@ 0xff
  44:	d002      	beq.n	4c <SystemTelemetry_Process+0x4c>
  46:	1963      	adds	r3, r4, r5
  48:	7a1b      	ldrb	r3, [r3, #8]
  4a:	b923      	cbnz	r3, 56 <SystemTelemetry_Process+0x56>
  4c:	b00e      	add	sp, #56	@ 0x38
  4e:	e8bd 4070 	ldmia.w	sp!, {r4, r5, r6, lr}
  52:	f7ff bffe 	b.w	0 <SystemTelemetry_Process>
			52: R_ARM_THM_JUMP24	SystemSourceSelector_PendingEventsFlush
  56:	1963      	adds	r3, r4, r5
  58:	7b1b      	ldrb	r3, [r3, #12]
  5a:	2b00      	cmp	r3, #0
  5c:	d1f6      	bne.n	4c <SystemTelemetry_Process+0x4c>
  5e:	4628      	mov	r0, r5
  60:	f7ff fffe 	bl	0 <ProjectTelemetryInstance_Process>
			60: R_ARM_THM_CALL	ProjectTelemetryInstance_Process
  64:	7c20      	ldrb	r0, [r4, #16]
  66:	4a42      	ldr	r2, [pc, #264]	@ (170 <SystemTelemetry_Process+0x170>)
  68:	2804      	cmp	r0, #4
  6a:	f04f 030a 	mov.w	r3, #10
  6e:	9300      	str	r3, [sp, #0]
  70:	bf88      	it	hi
  72:	2000      	movhi	r0, #0
  74:	f240 63de 	movw	r3, #1758	@ 0x6de
  78:	bf98      	it	ls
  7a:	2001      	movls	r0, #1
  7c:	210c      	movs	r1, #12
  7e:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			7e: R_ARM_THM_CALL	SilverStarAssert_Check
  82:	7ca3      	ldrb	r3, [r4, #18]
  84:	2bff      	cmp	r3, #255	@ 0xff
  86:	d0e1      	beq.n	4c <SystemTelemetry_Process+0x4c>
  88:	7c20      	ldrb	r0, [r4, #16]
  8a:	4a39      	ldr	r2, [pc, #228]	@ (170 <SystemTelemetry_Process+0x170>)
  8c:	4298      	cmp	r0, r3
  8e:	f04f 0603 	mov.w	r6, #3
  92:	bf94      	ite	ls
  94:	2000      	movls	r0, #0
  96:	2001      	movhi	r0, #1
  98:	f240 63e1 	movw	r3, #1761	@ 0x6e1
  9c:	210c      	movs	r1, #12
  9e:	9600      	str	r6, [sp, #0]
  a0:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			a0: R_ARM_THM_CALL	SilverStarAssert_Check
  a4:	8aa0      	ldrh	r0, [r4, #20]
  a6:	4a32      	ldr	r2, [pc, #200]	@ (170 <SystemTelemetry_Process+0x170>)
  a8:	280a      	cmp	r0, #10
  aa:	f04f 0305 	mov.w	r3, #5
  ae:	bf8c      	ite	hi
  b0:	2000      	movhi	r0, #0
  b2:	2001      	movls	r0, #1
  b4:	9300      	str	r3, [sp, #0]
  b6:	210c      	movs	r1, #12
  b8:	f240 63e3 	movw	r3, #1763	@ 0x6e3
  bc:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			bc: R_ARM_THM_CALL	SilverStarAssert_Check
  c0:	7ca0      	ldrb	r0, [r4, #18]
  c2:	a902      	add	r1, sp, #8
  c4:	f7ff fffe 	bl	0 <ProjectTelemetryInstance_HealthGet>
			c4: R_ARM_THM_CALL	ProjectTelemetryInstance_HealthGet
  c8:	4605      	mov	r5, r0
  ca:	bb50      	cbnz	r0, 122 <SystemTelemetry_Process+0x122>
  cc:	f89d 3033 	ldrb.w	r3, [sp, #51]	@ 0x33
  d0:	b33b      	cbz	r3, 122 <SystemTelemetry_Process+0x122>
  d2:	f89d 3034 	ldrb.w	r3, [sp, #52]	@ 0x34
  d6:	b323      	cbz	r3, 122 <SystemTelemetry_Process+0x122>
  d8:	f894 3025 	ldrb.w	r3, [r4, #37]	@ 0x25
  dc:	2b00      	cmp	r3, #0
  de:	d134      	bne.n	14a <SystemTelemetry_Process+0x14a>
  e0:	9a06      	ldr	r2, [sp, #24]
  e2:	69a0      	ldr	r0, [r4, #24]
  e4:	9b08      	ldr	r3, [sp, #32]
  e6:	69e1      	ldr	r1, [r4, #28]
  e8:	4282      	cmp	r2, r0
  ea:	e9c4 2306 	strd	r2, r3, [r4, #24]
  ee:	d01f      	beq.n	130 <SystemTelemetry_Process+0x130>
  f0:	7ca2      	ldrb	r2, [r4, #18]
  f2:	4422      	add	r2, r4
  f4:	2300      	movs	r3, #0
  f6:	82a3      	strh	r3, [r4, #20]
  f8:	f884 3024 	strb.w	r3, [r4, #36]	@ 0x24
  fc:	6223      	str	r3, [r4, #32]
  fe:	f882 3027 	strb.w	r3, [r2, #39]	@ 0x27
 102:	e7a3      	b.n	4c <SystemTelemetry_Process+0x4c>
 104:	2000      	movs	r0, #0
 106:	f7ff fffe 	bl	0 <SystemTelemetry_Process>
			106: R_ARM_THM_CALL	SystemSourceSelector_TelemetryRecoveryTry
 10a:	b00e      	add	sp, #56	@ 0x38
 10c:	e8bd 4070 	ldmia.w	sp!, {r4, r5, r6, lr}
 110:	f7ff bffe 	b.w	0 <SystemTelemetry_Process>
			110: R_ARM_THM_JUMP24	SystemSourceSelector_PendingEventsFlush
 114:	7ca2      	ldrb	r2, [r4, #18]
 116:	2303      	movs	r3, #3
 118:	4629      	mov	r1, r5
 11a:	2006      	movs	r0, #6
 11c:	f7ff fffe 	bl	0 <SystemTelemetry_Process>
			11c: R_ARM_THM_CALL	SystemSourceSelector_EventRecord
 120:	e78e      	b.n	40 <SystemTelemetry_Process+0x40>
 122:	2301      	movs	r3, #1
 124:	2003      	movs	r0, #3
 126:	f884 3025 	strb.w	r3, [r4, #37]	@ 0x25
 12a:	f7ff fffe 	bl	0 <SystemTelemetry_Process>
			12a: R_ARM_THM_CALL	SystemSourceSelector_TelemetrySwitchIfAvailable
 12e:	e78d      	b.n	4c <SystemTelemetry_Process+0x4c>
 130:	1a5b      	subs	r3, r3, r1
 132:	d08b      	beq.n	4c <SystemTelemetry_Process+0x4c>
 134:	8aa2      	ldrh	r2, [r4, #20]
 136:	f1c2 010a 	rsb	r1, r2, #10
 13a:	428b      	cmp	r3, r1
 13c:	d30e      	bcc.n	15c <SystemTelemetry_Process+0x15c>
 13e:	230a      	movs	r3, #10
 140:	82a3      	strh	r3, [r4, #20]
 142:	2007      	movs	r0, #7
 144:	f7ff fffe 	bl	0 <SystemTelemetry_Process>
			144: R_ARM_THM_CALL	SystemSourceSelector_TelemetrySwitchIfAvailable
 148:	e780      	b.n	4c <SystemTelemetry_Process+0x4c>
 14a:	7ca2      	ldrb	r2, [r4, #18]
 14c:	4633      	mov	r3, r6
 14e:	4611      	mov	r1, r2
 150:	2006      	movs	r0, #6
 152:	f7ff fffe 	bl	0 <SystemTelemetry_Process>
			152: R_ARM_THM_CALL	SystemSourceSelector_EventRecord
 156:	f884 5025 	strb.w	r5, [r4, #37]	@ 0x25
 15a:	e7c1      	b.n	e0 <SystemTelemetry_Process+0xe0>
 15c:	4413      	add	r3, r2
 15e:	b29b      	uxth	r3, r3
 160:	2b09      	cmp	r3, #9
 162:	82a3      	strh	r3, [r4, #20]
 164:	f67f af72 	bls.w	4c <SystemTelemetry_Process+0x4c>
 168:	e7eb      	b.n	142 <SystemTelemetry_Process+0x142>
 16a:	bf00      	nop
	...
			16c: R_ARM_ABS32	.bss.s_telemetry
			170: R_ARM_ABS32	.rodata.SystemSourceSelector_GnssSelectionPublish.str1.4

Disassembly of section .text.SystemTelemetry_InfoGet:

00000000 <SystemTelemetry_InfoGet>:
   0:	4601      	mov	r1, r0
   2:	b138      	cbz	r0, 14 <SystemTelemetry_InfoGet+0x14>
   4:	4b04      	ldr	r3, [pc, #16]	@ (18 <SystemTelemetry_InfoGet+0x18>)
   6:	7c98      	ldrb	r0, [r3, #18]
   8:	28ff      	cmp	r0, #255	@ 0xff
   a:	d001      	beq.n	10 <SystemTelemetry_InfoGet+0x10>
   c:	f7ff bffe 	b.w	0 <ProjectTelemetryInstance_InfoGet>
			c: R_ARM_THM_JUMP24	ProjectTelemetryInstance_InfoGet
  10:	2002      	movs	r0, #2
  12:	4770      	bx	lr
  14:	2005      	movs	r0, #5
  16:	4770      	bx	lr
  18:	00000000 	.word	0x00000000
			18: R_ARM_ABS32	.bss.s_telemetry

Disassembly of section .text.SystemTelemetry_CapabilitiesGet:

00000000 <SystemTelemetry_CapabilitiesGet>:
   0:	4601      	mov	r1, r0
   2:	b138      	cbz	r0, 14 <SystemTelemetry_CapabilitiesGet+0x14>
   4:	4b04      	ldr	r3, [pc, #16]	@ (18 <SystemTelemetry_CapabilitiesGet+0x18>)
   6:	7c98      	ldrb	r0, [r3, #18]
   8:	28ff      	cmp	r0, #255	@ 0xff
   a:	d001      	beq.n	10 <SystemTelemetry_CapabilitiesGet+0x10>
   c:	f7ff bffe 	b.w	0 <ProjectTelemetryInstance_CapabilitiesGet>
			c: R_ARM_THM_JUMP24	ProjectTelemetryInstance_CapabilitiesGet
  10:	2002      	movs	r0, #2
  12:	4770      	bx	lr
  14:	2005      	movs	r0, #5
  16:	4770      	bx	lr
  18:	00000000 	.word	0x00000000
			18: R_ARM_ABS32	.bss.s_telemetry

Disassembly of section .text.SystemTelemetry_HealthGet:

00000000 <SystemTelemetry_HealthGet>:
   0:	b1d0      	cbz	r0, 38 <SystemTelemetry_HealthGet+0x38>
   2:	4b10      	ldr	r3, [pc, #64]	@ (44 <SystemTelemetry_HealthGet+0x44>)
   4:	4601      	mov	r1, r0
   6:	7c98      	ldrb	r0, [r3, #18]
   8:	28ff      	cmp	r0, #255	@ 0xff
   a:	d013      	beq.n	34 <SystemTelemetry_HealthGet+0x34>
   c:	b500      	push	{lr}
   e:	f103 0c0b 	add.w	ip, r3, #11
  12:	f893 e010 	ldrb.w	lr, [r3, #16]
  16:	2300      	movs	r3, #0
  18:	b2da      	uxtb	r2, r3
  1a:	4596      	cmp	lr, r2
  1c:	f103 0301 	add.w	r3, r3, #1
  20:	d904      	bls.n	2c <SystemTelemetry_HealthGet+0x2c>
  22:	f81c 2f01 	ldrb.w	r2, [ip, #1]!
  26:	b94a      	cbnz	r2, 3c <SystemTelemetry_HealthGet+0x3c>
  28:	2b04      	cmp	r3, #4
  2a:	d1f5      	bne.n	18 <SystemTelemetry_HealthGet+0x18>
  2c:	f85d eb04 	ldr.w	lr, [sp], #4
  30:	f7ff bffe 	b.w	0 <ProjectTelemetryInstance_HealthGet>
			30: R_ARM_THM_JUMP24	ProjectTelemetryInstance_HealthGet
  34:	2002      	movs	r0, #2
  36:	4770      	bx	lr
  38:	2005      	movs	r0, #5
  3a:	4770      	bx	lr
  3c:	2002      	movs	r0, #2
  3e:	f85d fb04 	ldr.w	pc, [sp], #4
  42:	bf00      	nop
  44:	00000000 	.word	0x00000000
			44: R_ARM_ABS32	.bss.s_telemetry

Disassembly of section .text.SystemTelemetry_IoDiagnosticsGet:

00000000 <SystemTelemetry_IoDiagnosticsGet>:
   0:	4601      	mov	r1, r0
   2:	b138      	cbz	r0, 14 <SystemTelemetry_IoDiagnosticsGet+0x14>
   4:	4b04      	ldr	r3, [pc, #16]	@ (18 <SystemTelemetry_IoDiagnosticsGet+0x18>)
   6:	7c98      	ldrb	r0, [r3, #18]
   8:	28ff      	cmp	r0, #255	@ 0xff
   a:	d001      	beq.n	10 <SystemTelemetry_IoDiagnosticsGet+0x10>
   c:	f7ff bffe 	b.w	0 <ProjectTelemetryInstance_IoDiagnosticsGet>
			c: R_ARM_THM_JUMP24	ProjectTelemetryInstance_IoDiagnosticsGet
  10:	2002      	movs	r0, #2
  12:	4770      	bx	lr
  14:	2005      	movs	r0, #5
  16:	4770      	bx	lr
  18:	00000000 	.word	0x00000000
			18: R_ARM_ABS32	.bss.s_telemetry

Disassembly of section .text.SystemTelemetry_SelfTestRun:

00000000 <SystemTelemetry_SelfTestRun>:
   0:	4601      	mov	r1, r0
   2:	b138      	cbz	r0, 14 <SystemTelemetry_SelfTestRun+0x14>
   4:	4b04      	ldr	r3, [pc, #16]	@ (18 <SystemTelemetry_SelfTestRun+0x18>)
   6:	7c98      	ldrb	r0, [r3, #18]
   8:	28ff      	cmp	r0, #255	@ 0xff
   a:	d001      	beq.n	10 <SystemTelemetry_SelfTestRun+0x10>
   c:	f7ff bffe 	b.w	0 <ProjectTelemetryInstance_SelfTestRun>
			c: R_ARM_THM_JUMP24	ProjectTelemetryInstance_SelfTestRun
  10:	2002      	movs	r0, #2
  12:	4770      	bx	lr
  14:	2005      	movs	r0, #5
  16:	4770      	bx	lr
  18:	00000000 	.word	0x00000000
			18: R_ARM_ABS32	.bss.s_telemetry

Disassembly of section .text.SystemTelemetry_MtuGet:

00000000 <SystemTelemetry_MtuGet>:
   0:	4601      	mov	r1, r0
   2:	b138      	cbz	r0, 14 <SystemTelemetry_MtuGet+0x14>
   4:	4b04      	ldr	r3, [pc, #16]	@ (18 <SystemTelemetry_MtuGet+0x18>)
   6:	7c98      	ldrb	r0, [r3, #18]
   8:	28ff      	cmp	r0, #255	@ 0xff
   a:	d001      	beq.n	10 <SystemTelemetry_MtuGet+0x10>
   c:	f7ff bffe 	b.w	0 <ProjectTelemetryInstance_MtuGet>
			c: R_ARM_THM_JUMP24	ProjectTelemetryInstance_MtuGet
  10:	2002      	movs	r0, #2
  12:	4770      	bx	lr
  14:	2005      	movs	r0, #5
  16:	4770      	bx	lr
  18:	00000000 	.word	0x00000000
			18: R_ARM_ABS32	.bss.s_telemetry

Disassembly of section .text.SystemBarometer_NameGet:

00000000 <SystemBarometer_NameGet>:
   0:	b500      	push	{lr}
   2:	2003      	movs	r0, #3
   4:	b087      	sub	sp, #28
   6:	f7ff fffe 	bl	0 <SystemBarometer_NameGet>
			6: R_ARM_THM_CALL	SystemSourceSelector_PrimaryInstanceGet
   a:	28ff      	cmp	r0, #255	@ 0xff
   c:	d103      	bne.n	16 <SystemBarometer_NameGet+0x16>
   e:	4807      	ldr	r0, [pc, #28]	@ (2c <SystemBarometer_NameGet+0x2c>)
  10:	b007      	add	sp, #28
  12:	f85d fb04 	ldr.w	pc, [sp], #4
  16:	a901      	add	r1, sp, #4
  18:	f7ff fffe 	bl	0 <ProjectBarometerInstance_InfoGet>
			18: R_ARM_THM_CALL	ProjectBarometerInstance_InfoGet
  1c:	2800      	cmp	r0, #0
  1e:	d1f6      	bne.n	e <SystemBarometer_NameGet+0xe>
  20:	9801      	ldr	r0, [sp, #4]
  22:	2800      	cmp	r0, #0
  24:	d0f3      	beq.n	e <SystemBarometer_NameGet+0xe>
  26:	b007      	add	sp, #28
  28:	f85d fb04 	ldr.w	pc, [sp], #4
  2c:	00000000 	.word	0x00000000
			2c: R_ARM_ABS32	.rodata.SystemBarometer_NameGet.str1.4

Disassembly of section .text.SystemBarometer_Init:

00000000 <SystemBarometer_Init>:
   0:	2003      	movs	r0, #3
   2:	f7ff bffe 	b.w	0 <SystemBarometer_Init>
			2: R_ARM_THM_JUMP24	SystemSourceSelector_PassiveInit
   6:	bf00      	nop

Disassembly of section .text.SystemBarometer_Start:

00000000 <SystemBarometer_Start>:
   0:	2003      	movs	r0, #3
   2:	f7ff bffe 	b.w	0 <SystemBarometer_Start>
			2: R_ARM_THM_JUMP24	SystemSourceSelector_PassiveStart
   6:	bf00      	nop

Disassembly of section .text.SystemBarometer_Stop:

00000000 <SystemBarometer_Stop>:
   0:	2003      	movs	r0, #3
   2:	f7ff bffe 	b.w	0 <SystemBarometer_Stop>
			2: R_ARM_THM_JUMP24	SystemSourceSelector_PassiveStop
   6:	bf00      	nop

Disassembly of section .text.SystemBarometer_Process:

00000000 <SystemBarometer_Process>:
   0:	b530      	push	{r4, r5, lr}
   2:	2003      	movs	r0, #3
   4:	b083      	sub	sp, #12
   6:	f7ff fffe 	bl	0 <ProjectDeviceInstance_CountGet>
			6: R_ARM_THM_CALL	ProjectDeviceInstance_CountGet
   a:	2304      	movs	r3, #4
   c:	2804      	cmp	r0, #4
   e:	4605      	mov	r5, r0
  10:	9300      	str	r3, [sp, #0]
  12:	4a0b      	ldr	r2, [pc, #44]	@ (40 <SystemBarometer_Process+0x40>)
  14:	f640 03c2 	movw	r3, #2242	@ 0x8c2
  18:	f04f 010c 	mov.w	r1, #12
  1c:	bf8c      	ite	hi
  1e:	2000      	movhi	r0, #0
  20:	2001      	movls	r0, #1
  22:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			22: R_ARM_THM_CALL	SilverStarAssert_Check
  26:	2400      	movs	r4, #0
  28:	b2e0      	uxtb	r0, r4
  2a:	4285      	cmp	r5, r0
  2c:	d904      	bls.n	38 <SystemBarometer_Process+0x38>
  2e:	3401      	adds	r4, #1
  30:	f7ff fffe 	bl	0 <ProjectBarometerInstance_Process>
			30: R_ARM_THM_CALL	ProjectBarometerInstance_Process
  34:	2c04      	cmp	r4, #4
  36:	d1f7      	bne.n	28 <SystemBarometer_Process+0x28>
  38:	2000      	movs	r0, #0
  3a:	b003      	add	sp, #12
  3c:	bd30      	pop	{r4, r5, pc}
  3e:	bf00      	nop
  40:	00000000 	.word	0x00000000
			40: R_ARM_ABS32	.rodata.SystemSourceSelector_GnssSelectionPublish.str1.4

Disassembly of section .text.SystemBarometer_InfoGet:

00000000 <SystemBarometer_InfoGet>:
   0:	b510      	push	{r4, lr}
   2:	4604      	mov	r4, r0
   4:	2003      	movs	r0, #3
   6:	f7ff fffe 	bl	0 <SystemBarometer_InfoGet>
			6: R_ARM_THM_CALL	SystemSourceSelector_PrimaryInstanceGet
   a:	b144      	cbz	r4, 1e <SystemBarometer_InfoGet+0x1e>
   c:	28ff      	cmp	r0, #255	@ 0xff
   e:	d004      	beq.n	1a <SystemBarometer_InfoGet+0x1a>
  10:	4621      	mov	r1, r4
  12:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
  16:	f7ff bffe 	b.w	0 <ProjectBarometerInstance_InfoGet>
			16: R_ARM_THM_JUMP24	ProjectBarometerInstance_InfoGet
  1a:	2002      	movs	r0, #2
  1c:	bd10      	pop	{r4, pc}
  1e:	2005      	movs	r0, #5
  20:	bd10      	pop	{r4, pc}
  22:	bf00      	nop

Disassembly of section .text.SystemBarometer_CapabilitiesGet:

00000000 <SystemBarometer_CapabilitiesGet>:
   0:	b510      	push	{r4, lr}
   2:	4604      	mov	r4, r0
   4:	2003      	movs	r0, #3
   6:	f7ff fffe 	bl	0 <SystemBarometer_CapabilitiesGet>
			6: R_ARM_THM_CALL	SystemSourceSelector_PrimaryInstanceGet
   a:	b144      	cbz	r4, 1e <SystemBarometer_CapabilitiesGet+0x1e>
   c:	28ff      	cmp	r0, #255	@ 0xff
   e:	d004      	beq.n	1a <SystemBarometer_CapabilitiesGet+0x1a>
  10:	4621      	mov	r1, r4
  12:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
  16:	f7ff bffe 	b.w	0 <ProjectBarometerInstance_CapabilitiesGet>
			16: R_ARM_THM_JUMP24	ProjectBarometerInstance_CapabilitiesGet
  1a:	2002      	movs	r0, #2
  1c:	bd10      	pop	{r4, pc}
  1e:	2005      	movs	r0, #5
  20:	bd10      	pop	{r4, pc}
  22:	bf00      	nop

Disassembly of section .text.SystemBarometer_HealthGet:

00000000 <SystemBarometer_HealthGet>:
   0:	b510      	push	{r4, lr}
   2:	4604      	mov	r4, r0
   4:	2003      	movs	r0, #3
   6:	f7ff fffe 	bl	0 <SystemBarometer_HealthGet>
			6: R_ARM_THM_CALL	SystemSourceSelector_PrimaryInstanceGet
   a:	b144      	cbz	r4, 1e <SystemBarometer_HealthGet+0x1e>
   c:	28ff      	cmp	r0, #255	@ 0xff
   e:	d004      	beq.n	1a <SystemBarometer_HealthGet+0x1a>
  10:	4621      	mov	r1, r4
  12:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
  16:	f7ff bffe 	b.w	0 <ProjectBarometerInstance_HealthGet>
			16: R_ARM_THM_JUMP24	ProjectBarometerInstance_HealthGet
  1a:	2002      	movs	r0, #2
  1c:	bd10      	pop	{r4, pc}
  1e:	2005      	movs	r0, #5
  20:	bd10      	pop	{r4, pc}
  22:	bf00      	nop

Disassembly of section .text.SystemBarometer_LatestSampleGet:

00000000 <SystemBarometer_LatestSampleGet>:
   0:	b510      	push	{r4, lr}
   2:	4604      	mov	r4, r0
   4:	2003      	movs	r0, #3
   6:	f7ff fffe 	bl	0 <SystemBarometer_LatestSampleGet>
			6: R_ARM_THM_CALL	SystemSourceSelector_PrimaryInstanceGet
   a:	b144      	cbz	r4, 1e <SystemBarometer_LatestSampleGet+0x1e>
   c:	28ff      	cmp	r0, #255	@ 0xff
   e:	d004      	beq.n	1a <SystemBarometer_LatestSampleGet+0x1a>
  10:	4621      	mov	r1, r4
  12:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
  16:	f7ff bffe 	b.w	0 <ProjectBarometerInstance_LatestSampleGet>
			16: R_ARM_THM_JUMP24	ProjectBarometerInstance_LatestSampleGet
  1a:	2002      	movs	r0, #2
  1c:	bd10      	pop	{r4, pc}
  1e:	2005      	movs	r0, #5
  20:	bd10      	pop	{r4, pc}
  22:	bf00      	nop

Disassembly of section .text.SystemBarometer_SelfTestRun:

00000000 <SystemBarometer_SelfTestRun>:
   0:	b510      	push	{r4, lr}
   2:	4604      	mov	r4, r0
   4:	2003      	movs	r0, #3
   6:	f7ff fffe 	bl	0 <SystemBarometer_SelfTestRun>
			6: R_ARM_THM_CALL	SystemSourceSelector_PrimaryInstanceGet
   a:	b144      	cbz	r4, 1e <SystemBarometer_SelfTestRun+0x1e>
   c:	28ff      	cmp	r0, #255	@ 0xff
   e:	d004      	beq.n	1a <SystemBarometer_SelfTestRun+0x1a>
  10:	4621      	mov	r1, r4
  12:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
  16:	f7ff bffe 	b.w	0 <ProjectBarometerInstance_SelfTestRun>
			16: R_ARM_THM_JUMP24	ProjectBarometerInstance_SelfTestRun
  1a:	2002      	movs	r0, #2
  1c:	bd10      	pop	{r4, pc}
  1e:	2005      	movs	r0, #5
  20:	bd10      	pop	{r4, pc}
  22:	bf00      	nop

Disassembly of section .text.SystemBarometer_ConfigApply:

00000000 <SystemBarometer_ConfigApply>:
   0:	b538      	push	{r3, r4, r5, lr}
   2:	4604      	mov	r4, r0
   4:	2003      	movs	r0, #3
   6:	460d      	mov	r5, r1
   8:	f7ff fffe 	bl	0 <SystemBarometer_ConfigApply>
			8: R_ARM_THM_CALL	SystemSourceSelector_PrimaryInstanceGet
   c:	b144      	cbz	r4, 20 <SystemBarometer_ConfigApply+0x20>
   e:	b13d      	cbz	r5, 20 <SystemBarometer_ConfigApply+0x20>
  10:	28ff      	cmp	r0, #255	@ 0xff
  12:	d007      	beq.n	24 <SystemBarometer_ConfigApply+0x24>
  14:	462a      	mov	r2, r5
  16:	4621      	mov	r1, r4
  18:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
  1c:	f7ff bffe 	b.w	0 <ProjectBarometerInstance_ConfigApply>
			1c: R_ARM_THM_JUMP24	ProjectBarometerInstance_ConfigApply
  20:	2005      	movs	r0, #5
  22:	bd38      	pop	{r3, r4, r5, pc}
  24:	2002      	movs	r0, #2
  26:	bd38      	pop	{r3, r4, r5, pc}

Disassembly of section .text.SystemBarometer_ConfigVerify:

00000000 <SystemBarometer_ConfigVerify>:
   0:	b538      	push	{r3, r4, r5, lr}
   2:	4604      	mov	r4, r0
   4:	2003      	movs	r0, #3
   6:	460d      	mov	r5, r1
   8:	f7ff fffe 	bl	0 <SystemBarometer_ConfigVerify>
			8: R_ARM_THM_CALL	SystemSourceSelector_PrimaryInstanceGet
   c:	b144      	cbz	r4, 20 <SystemBarometer_ConfigVerify+0x20>
   e:	b13d      	cbz	r5, 20 <SystemBarometer_ConfigVerify+0x20>
  10:	28ff      	cmp	r0, #255	@ 0xff
  12:	d007      	beq.n	24 <SystemBarometer_ConfigVerify+0x24>
  14:	462a      	mov	r2, r5
  16:	4621      	mov	r1, r4
  18:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
  1c:	f7ff bffe 	b.w	0 <ProjectBarometerInstance_ConfigVerify>
			1c: R_ARM_THM_JUMP24	ProjectBarometerInstance_ConfigVerify
  20:	2005      	movs	r0, #5
  22:	bd38      	pop	{r3, r4, r5, pc}
  24:	2002      	movs	r0, #2
  26:	bd38      	pop	{r3, r4, r5, pc}

Disassembly of section .text.SystemBarometer_EffectiveConfigGet:

00000000 <SystemBarometer_EffectiveConfigGet>:
   0:	b510      	push	{r4, lr}
   2:	4604      	mov	r4, r0
   4:	2003      	movs	r0, #3
   6:	f7ff fffe 	bl	0 <SystemBarometer_EffectiveConfigGet>
			6: R_ARM_THM_CALL	SystemSourceSelector_PrimaryInstanceGet
   a:	b144      	cbz	r4, 1e <SystemBarometer_EffectiveConfigGet+0x1e>
   c:	28ff      	cmp	r0, #255	@ 0xff
   e:	d004      	beq.n	1a <SystemBarometer_EffectiveConfigGet+0x1a>
  10:	4621      	mov	r1, r4
  12:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
  16:	f7ff bffe 	b.w	0 <ProjectBarometerInstance_EffectiveConfigGet>
			16: R_ARM_THM_JUMP24	ProjectBarometerInstance_EffectiveConfigGet
  1a:	2002      	movs	r0, #2
  1c:	bd10      	pop	{r4, pc}
  1e:	2005      	movs	r0, #5
  20:	bd10      	pop	{r4, pc}
  22:	bf00      	nop

Disassembly of section .text.SystemBarometer_NoiseCharacteristicsGet:

00000000 <SystemBarometer_NoiseCharacteristicsGet>:
   0:	b510      	push	{r4, lr}
   2:	4604      	mov	r4, r0
   4:	2003      	movs	r0, #3
   6:	f7ff fffe 	bl	0 <SystemBarometer_NoiseCharacteristicsGet>
			6: R_ARM_THM_CALL	SystemSourceSelector_PrimaryInstanceGet
   a:	b144      	cbz	r4, 1e <SystemBarometer_NoiseCharacteristicsGet+0x1e>
   c:	28ff      	cmp	r0, #255	@ 0xff
   e:	d004      	beq.n	1a <SystemBarometer_NoiseCharacteristicsGet+0x1a>
  10:	4621      	mov	r1, r4
  12:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
  16:	f7ff bffe 	b.w	0 <ProjectBarometerInstance_NoiseCharacteristicsGet>
			16: R_ARM_THM_JUMP24	ProjectBarometerInstance_NoiseCharacteristicsGet
  1a:	2002      	movs	r0, #2
  1c:	bd10      	pop	{r4, pc}
  1e:	2005      	movs	r0, #5
  20:	bd10      	pop	{r4, pc}
  22:	bf00      	nop

Disassembly of section .text.SystemMagnetometer_NameGet:

00000000 <SystemMagnetometer_NameGet>:
   0:	b500      	push	{lr}
   2:	2004      	movs	r0, #4
   4:	b087      	sub	sp, #28
   6:	f7ff fffe 	bl	0 <SystemMagnetometer_NameGet>
			6: R_ARM_THM_CALL	SystemSourceSelector_PrimaryInstanceGet
   a:	28ff      	cmp	r0, #255	@ 0xff
   c:	d103      	bne.n	16 <SystemMagnetometer_NameGet+0x16>
   e:	4807      	ldr	r0, [pc, #28]	@ (2c <SystemMagnetometer_NameGet+0x2c>)
  10:	b007      	add	sp, #28
  12:	f85d fb04 	ldr.w	pc, [sp], #4
  16:	a901      	add	r1, sp, #4
  18:	f7ff fffe 	bl	0 <ProjectMagnetometerInstance_InfoGet>
			18: R_ARM_THM_CALL	ProjectMagnetometerInstance_InfoGet
  1c:	2800      	cmp	r0, #0
  1e:	d1f6      	bne.n	e <SystemMagnetometer_NameGet+0xe>
  20:	9801      	ldr	r0, [sp, #4]
  22:	2800      	cmp	r0, #0
  24:	d0f3      	beq.n	e <SystemMagnetometer_NameGet+0xe>
  26:	b007      	add	sp, #28
  28:	f85d fb04 	ldr.w	pc, [sp], #4
  2c:	00000000 	.word	0x00000000
			2c: R_ARM_ABS32	.rodata.SystemMagnetometer_NameGet.str1.4

Disassembly of section .text.SystemMagnetometer_Init:

00000000 <SystemMagnetometer_Init>:
   0:	2004      	movs	r0, #4
   2:	f7ff bffe 	b.w	0 <SystemMagnetometer_Init>
			2: R_ARM_THM_JUMP24	SystemSourceSelector_PassiveInit
   6:	bf00      	nop

Disassembly of section .text.SystemMagnetometer_Start:

00000000 <SystemMagnetometer_Start>:
   0:	2004      	movs	r0, #4
   2:	f7ff bffe 	b.w	0 <SystemMagnetometer_Start>
			2: R_ARM_THM_JUMP24	SystemSourceSelector_PassiveStart
   6:	bf00      	nop

Disassembly of section .text.SystemMagnetometer_Stop:

00000000 <SystemMagnetometer_Stop>:
   0:	2004      	movs	r0, #4
   2:	f7ff bffe 	b.w	0 <SystemMagnetometer_Stop>
			2: R_ARM_THM_JUMP24	SystemSourceSelector_PassiveStop
   6:	bf00      	nop

Disassembly of section .text.SystemMagnetometer_Process:

00000000 <SystemMagnetometer_Process>:
   0:	b530      	push	{r4, r5, lr}
   2:	2004      	movs	r0, #4
   4:	b083      	sub	sp, #12
   6:	f7ff fffe 	bl	0 <ProjectDeviceInstance_CountGet>
			6: R_ARM_THM_CALL	ProjectDeviceInstance_CountGet
   a:	2304      	movs	r3, #4
   c:	2804      	cmp	r0, #4
   e:	4605      	mov	r5, r0
  10:	9300      	str	r3, [sp, #0]
  12:	4a0b      	ldr	r2, [pc, #44]	@ (40 <SystemMagnetometer_Process+0x40>)
  14:	f640 03c2 	movw	r3, #2242	@ 0x8c2
  18:	f04f 010c 	mov.w	r1, #12
  1c:	bf8c      	ite	hi
  1e:	2000      	movhi	r0, #0
  20:	2001      	movls	r0, #1
  22:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			22: R_ARM_THM_CALL	SilverStarAssert_Check
  26:	2400      	movs	r4, #0
  28:	b2e0      	uxtb	r0, r4
  2a:	4285      	cmp	r5, r0
  2c:	d904      	bls.n	38 <SystemMagnetometer_Process+0x38>
  2e:	3401      	adds	r4, #1
  30:	f7ff fffe 	bl	0 <ProjectMagnetometerInstance_Process>
			30: R_ARM_THM_CALL	ProjectMagnetometerInstance_Process
  34:	2c04      	cmp	r4, #4
  36:	d1f7      	bne.n	28 <SystemMagnetometer_Process+0x28>
  38:	2000      	movs	r0, #0
  3a:	b003      	add	sp, #12
  3c:	bd30      	pop	{r4, r5, pc}
  3e:	bf00      	nop
  40:	00000000 	.word	0x00000000
			40: R_ARM_ABS32	.rodata.SystemSourceSelector_GnssSelectionPublish.str1.4

Disassembly of section .text.SystemMagnetometer_InfoGet:

00000000 <SystemMagnetometer_InfoGet>:
   0:	b510      	push	{r4, lr}
   2:	4604      	mov	r4, r0
   4:	2004      	movs	r0, #4
   6:	f7ff fffe 	bl	0 <SystemMagnetometer_InfoGet>
			6: R_ARM_THM_CALL	SystemSourceSelector_PrimaryInstanceGet
   a:	b144      	cbz	r4, 1e <SystemMagnetometer_InfoGet+0x1e>
   c:	28ff      	cmp	r0, #255	@ 0xff
   e:	d004      	beq.n	1a <SystemMagnetometer_InfoGet+0x1a>
  10:	4621      	mov	r1, r4
  12:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
  16:	f7ff bffe 	b.w	0 <ProjectMagnetometerInstance_InfoGet>
			16: R_ARM_THM_JUMP24	ProjectMagnetometerInstance_InfoGet
  1a:	2002      	movs	r0, #2
  1c:	bd10      	pop	{r4, pc}
  1e:	2005      	movs	r0, #5
  20:	bd10      	pop	{r4, pc}
  22:	bf00      	nop

Disassembly of section .text.SystemMagnetometer_CapabilitiesGet:

00000000 <SystemMagnetometer_CapabilitiesGet>:
   0:	b510      	push	{r4, lr}
   2:	4604      	mov	r4, r0
   4:	2004      	movs	r0, #4
   6:	f7ff fffe 	bl	0 <SystemMagnetometer_CapabilitiesGet>
			6: R_ARM_THM_CALL	SystemSourceSelector_PrimaryInstanceGet
   a:	b144      	cbz	r4, 1e <SystemMagnetometer_CapabilitiesGet+0x1e>
   c:	28ff      	cmp	r0, #255	@ 0xff
   e:	d004      	beq.n	1a <SystemMagnetometer_CapabilitiesGet+0x1a>
  10:	4621      	mov	r1, r4
  12:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
  16:	f7ff bffe 	b.w	0 <ProjectMagnetometerInstance_CapabilitiesGet>
			16: R_ARM_THM_JUMP24	ProjectMagnetometerInstance_CapabilitiesGet
  1a:	2002      	movs	r0, #2
  1c:	bd10      	pop	{r4, pc}
  1e:	2005      	movs	r0, #5
  20:	bd10      	pop	{r4, pc}
  22:	bf00      	nop

Disassembly of section .text.SystemMagnetometer_HealthGet:

00000000 <SystemMagnetometer_HealthGet>:
   0:	b510      	push	{r4, lr}
   2:	4604      	mov	r4, r0
   4:	2004      	movs	r0, #4
   6:	f7ff fffe 	bl	0 <SystemMagnetometer_HealthGet>
			6: R_ARM_THM_CALL	SystemSourceSelector_PrimaryInstanceGet
   a:	b144      	cbz	r4, 1e <SystemMagnetometer_HealthGet+0x1e>
   c:	28ff      	cmp	r0, #255	@ 0xff
   e:	d004      	beq.n	1a <SystemMagnetometer_HealthGet+0x1a>
  10:	4621      	mov	r1, r4
  12:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
  16:	f7ff bffe 	b.w	0 <ProjectMagnetometerInstance_HealthGet>
			16: R_ARM_THM_JUMP24	ProjectMagnetometerInstance_HealthGet
  1a:	2002      	movs	r0, #2
  1c:	bd10      	pop	{r4, pc}
  1e:	2005      	movs	r0, #5
  20:	bd10      	pop	{r4, pc}
  22:	bf00      	nop

Disassembly of section .text.SystemMagnetometer_LatestSampleGet:

00000000 <SystemMagnetometer_LatestSampleGet>:
   0:	b570      	push	{r4, r5, r6, lr}
   2:	4604      	mov	r4, r0
   4:	b08a      	sub	sp, #40	@ 0x28
   6:	2004      	movs	r0, #4
   8:	f7ff fffe 	bl	0 <SystemMagnetometer_LatestSampleGet>
			8: R_ARM_THM_CALL	SystemSourceSelector_PrimaryInstanceGet
   c:	2c00      	cmp	r4, #0
   e:	d03e      	beq.n	8e <SystemMagnetometer_LatestSampleGet+0x8e>
  10:	28ff      	cmp	r0, #255	@ 0xff
  12:	4606      	mov	r6, r0
  14:	d037      	beq.n	86 <SystemMagnetometer_LatestSampleGet+0x86>
  16:	4621      	mov	r1, r4
  18:	f7ff fffe 	bl	0 <ProjectMagnetometerInstance_LatestSampleGet>
			18: R_ARM_THM_CALL	ProjectMagnetometerInstance_LatestSampleGet
  1c:	4605      	mov	r5, r0
  1e:	b110      	cbz	r0, 26 <SystemMagnetometer_LatestSampleGet+0x26>
  20:	4628      	mov	r0, r5
  22:	b00a      	add	sp, #40	@ 0x28
  24:	bd70      	pop	{r4, r5, r6, pc}
  26:	aa03      	add	r2, sp, #12
  28:	4631      	mov	r1, r6
  2a:	2004      	movs	r0, #4
  2c:	f7ff fffe 	bl	0 <ProjectDeviceInstance_DescriptorGet>
			2c: R_ARM_THM_CALL	ProjectDeviceInstance_DescriptorGet
  30:	4605      	mov	r5, r0
  32:	2800      	cmp	r0, #0
  34:	d1f4      	bne.n	20 <SystemMagnetometer_LatestSampleGet+0x20>
  36:	f640 13a3 	movw	r3, #2467	@ 0x9a3
  3a:	9300      	str	r3, [sp, #0]
  3c:	220c      	movs	r2, #12
  3e:	4b16      	ldr	r3, [pc, #88]	@ (98 <SystemMagnetometer_LatestSampleGet+0x98>)
  40:	2108      	movs	r1, #8
  42:	4620      	mov	r0, r4
  44:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			44: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  48:	f640 13a5 	movw	r3, #2469	@ 0x9a5
  4c:	9300      	str	r3, [sp, #0]
  4e:	a803      	add	r0, sp, #12
  50:	4b11      	ldr	r3, [pc, #68]	@ (98 <SystemMagnetometer_LatestSampleGet+0x98>)
  52:	220c      	movs	r2, #12
  54:	2104      	movs	r1, #4
  56:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			56: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  5a:	f8bd 200e 	ldrh.w	r2, [sp, #14]
  5e:	f8bd 300c 	ldrh.w	r3, [sp, #12]
  62:	86e2      	strh	r2, [r4, #54]	@ 0x36
  64:	8723      	strh	r3, [r4, #56]	@ 0x38
  66:	f884 603a 	strb.w	r6, [r4, #58]	@ 0x3a
  6a:	4621      	mov	r1, r4
  6c:	4630      	mov	r0, r6
  6e:	f7ff fffe 	bl	0 <SystemMagCalibration_SampleApply>
			6e: R_ARM_THM_CALL	SystemMagCalibration_SampleApply
  72:	2801      	cmp	r0, #1
  74:	d9d4      	bls.n	20 <SystemMagnetometer_LatestSampleGet+0x20>
  76:	6b23      	ldr	r3, [r4, #48]	@ 0x30
  78:	f884 5034 	strb.w	r5, [r4, #52]	@ 0x34
  7c:	f023 0304 	bic.w	r3, r3, #4
  80:	6323      	str	r3, [r4, #48]	@ 0x30
  82:	2508      	movs	r5, #8
  84:	e7cc      	b.n	20 <SystemMagnetometer_LatestSampleGet+0x20>
  86:	2502      	movs	r5, #2
  88:	4628      	mov	r0, r5
  8a:	b00a      	add	sp, #40	@ 0x28
  8c:	bd70      	pop	{r4, r5, r6, pc}
  8e:	2505      	movs	r5, #5
  90:	4628      	mov	r0, r5
  92:	b00a      	add	sp, #40	@ 0x28
  94:	bd70      	pop	{r4, r5, r6, pc}
  96:	bf00      	nop
  98:	00000000 	.word	0x00000000
			98: R_ARM_ABS32	.rodata.SystemSourceSelector_GnssSelectionPublish.str1.4

Disassembly of section .text.SystemMagnetometer_SelfTestRun:

00000000 <SystemMagnetometer_SelfTestRun>:
   0:	b510      	push	{r4, lr}
   2:	4604      	mov	r4, r0
   4:	2004      	movs	r0, #4
   6:	f7ff fffe 	bl	0 <SystemMagnetometer_SelfTestRun>
			6: R_ARM_THM_CALL	SystemSourceSelector_PrimaryInstanceGet
   a:	b144      	cbz	r4, 1e <SystemMagnetometer_SelfTestRun+0x1e>
   c:	28ff      	cmp	r0, #255	@ 0xff
   e:	d004      	beq.n	1a <SystemMagnetometer_SelfTestRun+0x1a>
  10:	4621      	mov	r1, r4
  12:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
  16:	f7ff bffe 	b.w	0 <ProjectMagnetometerInstance_SelfTestRun>
			16: R_ARM_THM_JUMP24	ProjectMagnetometerInstance_SelfTestRun
  1a:	2002      	movs	r0, #2
  1c:	bd10      	pop	{r4, pc}
  1e:	2005      	movs	r0, #5
  20:	bd10      	pop	{r4, pc}
  22:	bf00      	nop

Disassembly of section .text.SystemMagnetometer_ConfigApply:

00000000 <SystemMagnetometer_ConfigApply>:
   0:	b538      	push	{r3, r4, r5, lr}
   2:	4604      	mov	r4, r0
   4:	2004      	movs	r0, #4
   6:	460d      	mov	r5, r1
   8:	f7ff fffe 	bl	0 <SystemMagnetometer_ConfigApply>
			8: R_ARM_THM_CALL	SystemSourceSelector_PrimaryInstanceGet
   c:	b144      	cbz	r4, 20 <SystemMagnetometer_ConfigApply+0x20>
   e:	b13d      	cbz	r5, 20 <SystemMagnetometer_ConfigApply+0x20>
  10:	28ff      	cmp	r0, #255	@ 0xff
  12:	d007      	beq.n	24 <SystemMagnetometer_ConfigApply+0x24>
  14:	462a      	mov	r2, r5
  16:	4621      	mov	r1, r4
  18:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
  1c:	f7ff bffe 	b.w	0 <ProjectMagnetometerInstance_ConfigApply>
			1c: R_ARM_THM_JUMP24	ProjectMagnetometerInstance_ConfigApply
  20:	2005      	movs	r0, #5
  22:	bd38      	pop	{r3, r4, r5, pc}
  24:	2002      	movs	r0, #2
  26:	bd38      	pop	{r3, r4, r5, pc}

Disassembly of section .text.SystemMagnetometer_ConfigVerify:

00000000 <SystemMagnetometer_ConfigVerify>:
   0:	b538      	push	{r3, r4, r5, lr}
   2:	4604      	mov	r4, r0
   4:	2004      	movs	r0, #4
   6:	460d      	mov	r5, r1
   8:	f7ff fffe 	bl	0 <SystemMagnetometer_ConfigVerify>
			8: R_ARM_THM_CALL	SystemSourceSelector_PrimaryInstanceGet
   c:	b144      	cbz	r4, 20 <SystemMagnetometer_ConfigVerify+0x20>
   e:	b13d      	cbz	r5, 20 <SystemMagnetometer_ConfigVerify+0x20>
  10:	28ff      	cmp	r0, #255	@ 0xff
  12:	d007      	beq.n	24 <SystemMagnetometer_ConfigVerify+0x24>
  14:	462a      	mov	r2, r5
  16:	4621      	mov	r1, r4
  18:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
  1c:	f7ff bffe 	b.w	0 <ProjectMagnetometerInstance_ConfigVerify>
			1c: R_ARM_THM_JUMP24	ProjectMagnetometerInstance_ConfigVerify
  20:	2005      	movs	r0, #5
  22:	bd38      	pop	{r3, r4, r5, pc}
  24:	2002      	movs	r0, #2
  26:	bd38      	pop	{r3, r4, r5, pc}

Disassembly of section .text.SystemMagnetometer_EffectiveConfigGet:

00000000 <SystemMagnetometer_EffectiveConfigGet>:
   0:	b510      	push	{r4, lr}
   2:	4604      	mov	r4, r0
   4:	2004      	movs	r0, #4
   6:	f7ff fffe 	bl	0 <SystemMagnetometer_EffectiveConfigGet>
			6: R_ARM_THM_CALL	SystemSourceSelector_PrimaryInstanceGet
   a:	b144      	cbz	r4, 1e <SystemMagnetometer_EffectiveConfigGet+0x1e>
   c:	28ff      	cmp	r0, #255	@ 0xff
   e:	d004      	beq.n	1a <SystemMagnetometer_EffectiveConfigGet+0x1a>
  10:	4621      	mov	r1, r4
  12:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
  16:	f7ff bffe 	b.w	0 <ProjectMagnetometerInstance_EffectiveConfigGet>
			16: R_ARM_THM_JUMP24	ProjectMagnetometerInstance_EffectiveConfigGet
  1a:	2002      	movs	r0, #2
  1c:	bd10      	pop	{r4, pc}
  1e:	2005      	movs	r0, #5
  20:	bd10      	pop	{r4, pc}
  22:	bf00      	nop

Disassembly of section .text.SystemHardwareQuaternion_NameGet:

00000000 <SystemHardwareQuaternion_NameGet>:
   0:	b500      	push	{lr}
   2:	2005      	movs	r0, #5
   4:	b087      	sub	sp, #28
   6:	f7ff fffe 	bl	0 <SystemHardwareQuaternion_NameGet>
			6: R_ARM_THM_CALL	SystemSourceSelector_PrimaryInstanceGet
   a:	28ff      	cmp	r0, #255	@ 0xff
   c:	d103      	bne.n	16 <SystemHardwareQuaternion_NameGet+0x16>
   e:	4807      	ldr	r0, [pc, #28]	@ (2c <SystemHardwareQuaternion_NameGet+0x2c>)
  10:	b007      	add	sp, #28
  12:	f85d fb04 	ldr.w	pc, [sp], #4
  16:	a901      	add	r1, sp, #4
  18:	f7ff fffe 	bl	0 <ProjectAttitudeInstance_InfoGet>
			18: R_ARM_THM_CALL	ProjectAttitudeInstance_InfoGet
  1c:	2800      	cmp	r0, #0
  1e:	d1f6      	bne.n	e <SystemHardwareQuaternion_NameGet+0xe>
  20:	9801      	ldr	r0, [sp, #4]
  22:	2800      	cmp	r0, #0
  24:	d0f3      	beq.n	e <SystemHardwareQuaternion_NameGet+0xe>
  26:	b007      	add	sp, #28
  28:	f85d fb04 	ldr.w	pc, [sp], #4
  2c:	00000000 	.word	0x00000000
			2c: R_ARM_ABS32	.rodata.SystemHardwareQuaternion_NameGet.str1.4

Disassembly of section .text.SystemHardwareQuaternion_Init:

00000000 <SystemHardwareQuaternion_Init>:
   0:	2005      	movs	r0, #5
   2:	f7ff bffe 	b.w	0 <SystemHardwareQuaternion_Init>
			2: R_ARM_THM_JUMP24	SystemSourceSelector_PassiveInit
   6:	bf00      	nop

Disassembly of section .text.SystemHardwareQuaternion_Start:

00000000 <SystemHardwareQuaternion_Start>:
   0:	2005      	movs	r0, #5
   2:	f7ff bffe 	b.w	0 <SystemHardwareQuaternion_Start>
			2: R_ARM_THM_JUMP24	SystemSourceSelector_PassiveStart
   6:	bf00      	nop

Disassembly of section .text.SystemHardwareQuaternion_Stop:

00000000 <SystemHardwareQuaternion_Stop>:
   0:	2005      	movs	r0, #5
   2:	f7ff bffe 	b.w	0 <SystemHardwareQuaternion_Stop>
			2: R_ARM_THM_JUMP24	SystemSourceSelector_PassiveStop
   6:	bf00      	nop

Disassembly of section .text.SystemHardwareQuaternion_Process:

00000000 <SystemHardwareQuaternion_Process>:
   0:	4770      	bx	lr
   2:	bf00      	nop

Disassembly of section .text.SystemHardwareQuaternion_InfoGet:

00000000 <SystemHardwareQuaternion_InfoGet>:
   0:	b510      	push	{r4, lr}
   2:	4604      	mov	r4, r0
   4:	2005      	movs	r0, #5
   6:	f7ff fffe 	bl	0 <SystemHardwareQuaternion_InfoGet>
			6: R_ARM_THM_CALL	SystemSourceSelector_PrimaryInstanceGet
   a:	b144      	cbz	r4, 1e <SystemHardwareQuaternion_InfoGet+0x1e>
   c:	28ff      	cmp	r0, #255	@ 0xff
   e:	d004      	beq.n	1a <SystemHardwareQuaternion_InfoGet+0x1a>
  10:	4621      	mov	r1, r4
  12:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
  16:	f7ff bffe 	b.w	0 <ProjectAttitudeInstance_InfoGet>
			16: R_ARM_THM_JUMP24	ProjectAttitudeInstance_InfoGet
  1a:	2002      	movs	r0, #2
  1c:	bd10      	pop	{r4, pc}
  1e:	2005      	movs	r0, #5
  20:	bd10      	pop	{r4, pc}
  22:	bf00      	nop

Disassembly of section .text.SystemHardwareQuaternion_CapabilitiesGet:

00000000 <SystemHardwareQuaternion_CapabilitiesGet>:
   0:	b510      	push	{r4, lr}
   2:	4604      	mov	r4, r0
   4:	2005      	movs	r0, #5
   6:	f7ff fffe 	bl	0 <SystemHardwareQuaternion_CapabilitiesGet>
			6: R_ARM_THM_CALL	SystemSourceSelector_PrimaryInstanceGet
   a:	b144      	cbz	r4, 1e <SystemHardwareQuaternion_CapabilitiesGet+0x1e>
   c:	28ff      	cmp	r0, #255	@ 0xff
   e:	d004      	beq.n	1a <SystemHardwareQuaternion_CapabilitiesGet+0x1a>
  10:	4621      	mov	r1, r4
  12:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
  16:	f7ff bffe 	b.w	0 <ProjectAttitudeInstance_CapabilitiesGet>
			16: R_ARM_THM_JUMP24	ProjectAttitudeInstance_CapabilitiesGet
  1a:	2002      	movs	r0, #2
  1c:	bd10      	pop	{r4, pc}
  1e:	2005      	movs	r0, #5
  20:	bd10      	pop	{r4, pc}
  22:	bf00      	nop

Disassembly of section .text.SystemHardwareQuaternion_HealthGet:

00000000 <SystemHardwareQuaternion_HealthGet>:
   0:	b510      	push	{r4, lr}
   2:	4604      	mov	r4, r0
   4:	2005      	movs	r0, #5
   6:	f7ff fffe 	bl	0 <SystemHardwareQuaternion_HealthGet>
			6: R_ARM_THM_CALL	SystemSourceSelector_PrimaryInstanceGet
   a:	b144      	cbz	r4, 1e <SystemHardwareQuaternion_HealthGet+0x1e>
   c:	28ff      	cmp	r0, #255	@ 0xff
   e:	d004      	beq.n	1a <SystemHardwareQuaternion_HealthGet+0x1a>
  10:	4621      	mov	r1, r4
  12:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
  16:	f7ff bffe 	b.w	0 <ProjectAttitudeInstance_HealthGet>
			16: R_ARM_THM_JUMP24	ProjectAttitudeInstance_HealthGet
  1a:	2002      	movs	r0, #2
  1c:	bd10      	pop	{r4, pc}
  1e:	2005      	movs	r0, #5
  20:	bd10      	pop	{r4, pc}
  22:	bf00      	nop

Disassembly of section .text.SystemHardwareQuaternion_LatestSampleGet:

00000000 <SystemHardwareQuaternion_LatestSampleGet>:
   0:	b510      	push	{r4, lr}
   2:	4604      	mov	r4, r0
   4:	2005      	movs	r0, #5
   6:	f7ff fffe 	bl	0 <SystemHardwareQuaternion_LatestSampleGet>
			6: R_ARM_THM_CALL	SystemSourceSelector_PrimaryInstanceGet
   a:	b144      	cbz	r4, 1e <SystemHardwareQuaternion_LatestSampleGet+0x1e>
   c:	28ff      	cmp	r0, #255	@ 0xff
   e:	d004      	beq.n	1a <SystemHardwareQuaternion_LatestSampleGet+0x1a>
  10:	4621      	mov	r1, r4
  12:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
  16:	f7ff bffe 	b.w	0 <ProjectAttitudeInstance_LatestSampleGet>
			16: R_ARM_THM_JUMP24	ProjectAttitudeInstance_LatestSampleGet
  1a:	2002      	movs	r0, #2
  1c:	bd10      	pop	{r4, pc}
  1e:	2005      	movs	r0, #5
  20:	bd10      	pop	{r4, pc}
  22:	bf00      	nop

Disassembly of section .text.SystemHardwareQuaternion_SelfTestRun:

00000000 <SystemHardwareQuaternion_SelfTestRun>:
   0:	b510      	push	{r4, lr}
   2:	4604      	mov	r4, r0
   4:	2005      	movs	r0, #5
   6:	f7ff fffe 	bl	0 <SystemHardwareQuaternion_SelfTestRun>
			6: R_ARM_THM_CALL	SystemSourceSelector_PrimaryInstanceGet
   a:	b144      	cbz	r4, 1e <SystemHardwareQuaternion_SelfTestRun+0x1e>
   c:	28ff      	cmp	r0, #255	@ 0xff
   e:	d004      	beq.n	1a <SystemHardwareQuaternion_SelfTestRun+0x1a>
  10:	4621      	mov	r1, r4
  12:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
  16:	f7ff bffe 	b.w	0 <ProjectAttitudeInstance_SelfTestRun>
			16: R_ARM_THM_JUMP24	ProjectAttitudeInstance_SelfTestRun
  1a:	2002      	movs	r0, #2
  1c:	bd10      	pop	{r4, pc}
  1e:	2005      	movs	r0, #5
  20:	bd10      	pop	{r4, pc}
  22:	bf00      	nop

Disassembly of section .text.SystemHardwareQuaternion_ConfigApply:

00000000 <SystemHardwareQuaternion_ConfigApply>:
   0:	b538      	push	{r3, r4, r5, lr}
   2:	4604      	mov	r4, r0
   4:	2005      	movs	r0, #5
   6:	460d      	mov	r5, r1
   8:	f7ff fffe 	bl	0 <SystemHardwareQuaternion_ConfigApply>
			8: R_ARM_THM_CALL	SystemSourceSelector_PrimaryInstanceGet
   c:	b144      	cbz	r4, 20 <SystemHardwareQuaternion_ConfigApply+0x20>
   e:	b13d      	cbz	r5, 20 <SystemHardwareQuaternion_ConfigApply+0x20>
  10:	28ff      	cmp	r0, #255	@ 0xff
  12:	d007      	beq.n	24 <SystemHardwareQuaternion_ConfigApply+0x24>
  14:	462a      	mov	r2, r5
  16:	4621      	mov	r1, r4
  18:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
  1c:	f7ff bffe 	b.w	0 <ProjectAttitudeInstance_ConfigApply>
			1c: R_ARM_THM_JUMP24	ProjectAttitudeInstance_ConfigApply
  20:	2005      	movs	r0, #5
  22:	bd38      	pop	{r3, r4, r5, pc}
  24:	2002      	movs	r0, #2
  26:	bd38      	pop	{r3, r4, r5, pc}

Disassembly of section .text.SystemHardwareQuaternion_ConfigVerify:

00000000 <SystemHardwareQuaternion_ConfigVerify>:
   0:	b538      	push	{r3, r4, r5, lr}
   2:	4604      	mov	r4, r0
   4:	2005      	movs	r0, #5
   6:	460d      	mov	r5, r1
   8:	f7ff fffe 	bl	0 <SystemHardwareQuaternion_ConfigVerify>
			8: R_ARM_THM_CALL	SystemSourceSelector_PrimaryInstanceGet
   c:	b144      	cbz	r4, 20 <SystemHardwareQuaternion_ConfigVerify+0x20>
   e:	b13d      	cbz	r5, 20 <SystemHardwareQuaternion_ConfigVerify+0x20>
  10:	28ff      	cmp	r0, #255	@ 0xff
  12:	d007      	beq.n	24 <SystemHardwareQuaternion_ConfigVerify+0x24>
  14:	462a      	mov	r2, r5
  16:	4621      	mov	r1, r4
  18:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
  1c:	f7ff bffe 	b.w	0 <ProjectAttitudeInstance_ConfigVerify>
			1c: R_ARM_THM_JUMP24	ProjectAttitudeInstance_ConfigVerify
  20:	2005      	movs	r0, #5
  22:	bd38      	pop	{r3, r4, r5, pc}
  24:	2002      	movs	r0, #2
  26:	bd38      	pop	{r3, r4, r5, pc}

Disassembly of section .text.SystemHardwareQuaternion_EffectiveConfigGet:

00000000 <SystemHardwareQuaternion_EffectiveConfigGet>:
   0:	b510      	push	{r4, lr}
   2:	4604      	mov	r4, r0
   4:	2005      	movs	r0, #5
   6:	f7ff fffe 	bl	0 <SystemHardwareQuaternion_EffectiveConfigGet>
			6: R_ARM_THM_CALL	SystemSourceSelector_PrimaryInstanceGet
   a:	b144      	cbz	r4, 1e <SystemHardwareQuaternion_EffectiveConfigGet+0x1e>
   c:	28ff      	cmp	r0, #255	@ 0xff
   e:	d004      	beq.n	1a <SystemHardwareQuaternion_EffectiveConfigGet+0x1a>
  10:	4621      	mov	r1, r4
  12:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
  16:	f7ff bffe 	b.w	0 <ProjectAttitudeInstance_EffectiveConfigGet>
			16: R_ARM_THM_JUMP24	ProjectAttitudeInstance_EffectiveConfigGet
  1a:	2002      	movs	r0, #2
  1c:	bd10      	pop	{r4, pc}
  1e:	2005      	movs	r0, #5
  20:	bd10      	pop	{r4, pc}
  22:	bf00      	nop
