
D:\python_software\SilverStar\.work\dev013_navclosure02\eskf15_1_default03\build\FCCG\SilverStar_F407\Release\auto\Algorithm\Estimator\ESKF15\Src\navigation_eskf_recovery_configuration.o:     file format elf32-littlearm


Disassembly of section .text.NavigationEskfRecoveryConfiguration_Encode.part.0:

00000000 <NavigationEskfRecoveryConfiguration_Encode.part.0>:
   0:	b530      	push	{r4, r5, lr}
   2:	4604      	mov	r4, r0
   4:	4811      	ldr	r0, [pc, #68]	@ (4c <NavigationEskfRecoveryConfiguration_Encode.part.0+0x4c>)
   6:	2300      	movs	r3, #0
   8:	6023      	str	r3, [r4, #0]
   a:	6063      	str	r3, [r4, #4]
   c:	60a3      	str	r3, [r4, #8]
   e:	60e3      	str	r3, [r4, #12]
  10:	6123      	str	r3, [r4, #16]
  12:	6163      	str	r3, [r4, #20]
  14:	61a3      	str	r3, [r4, #24]
  16:	f100 053c 	add.w	r5, r0, #60	@ 0x3c
  1a:	f04f 0e1c 	mov.w	lr, #28
  1e:	f850 cb04 	ldr.w	ip, [r0], #4
  22:	eb04 020e 	add.w	r2, r4, lr
  26:	2300      	movs	r3, #0
  28:	fa2c f103 	lsr.w	r1, ip, r3
  2c:	3308      	adds	r3, #8
  2e:	2b20      	cmp	r3, #32
  30:	f802 1b01 	strb.w	r1, [r2], #1
  34:	d1f8      	bne.n	28 <NavigationEskfRecoveryConfiguration_Encode.part.0+0x28>
  36:	42a8      	cmp	r0, r5
  38:	f10e 0e04 	add.w	lr, lr, #4
  3c:	d1ef      	bne.n	1e <NavigationEskfRecoveryConfiguration_Encode.part.0+0x1e>
  3e:	2000      	movs	r0, #0
  40:	65a0      	str	r0, [r4, #88]	@ 0x58
  42:	65e0      	str	r0, [r4, #92]	@ 0x5c
  44:	6620      	str	r0, [r4, #96]	@ 0x60
  46:	6660      	str	r0, [r4, #100]	@ 0x64
  48:	bd30      	pop	{r4, r5, pc}
  4a:	bf00      	nop
  4c:	00000064 	.word	0x00000064
			4c: R_ARM_ABS32	.rodata.s_configuration

Disassembly of section .text.NavigationEskfRecoveryConfiguration_Get:

00000000 <NavigationEskfRecoveryConfiguration_Get>:
   0:	4800      	ldr	r0, [pc, #0]	@ (4 <NavigationEskfRecoveryConfiguration_Get+0x4>)
   2:	4770      	bx	lr
   4:	00000000 	.word	0x00000000
			4: R_ARM_ABS32	.rodata.s_configuration

Disassembly of section .text.NavigationEskfRecoveryConfiguration_Encode:

00000000 <NavigationEskfRecoveryConfiguration_Encode>:
   0:	4b0d      	ldr	r3, [pc, #52]	@ (38 <NavigationEskfRecoveryConfiguration_Encode+0x38>)
   2:	4298      	cmp	r0, r3
   4:	b510      	push	{r4, lr}
   6:	d809      	bhi.n	1c <NavigationEskfRecoveryConfiguration_Encode+0x1c>
   8:	b130      	cbz	r0, 18 <NavigationEskfRecoveryConfiguration_Encode+0x18>
   a:	1a1b      	subs	r3, r3, r0
   c:	2b67      	cmp	r3, #103	@ 0x67
   e:	bf8c      	ite	hi
  10:	2400      	movhi	r4, #0
  12:	2401      	movls	r4, #1
  14:	2967      	cmp	r1, #103	@ 0x67
  16:	d808      	bhi.n	2a <NavigationEskfRecoveryConfiguration_Encode+0x2a>
  18:	2001      	movs	r0, #1
  1a:	bd10      	pop	{r4, pc}
  1c:	1ac3      	subs	r3, r0, r3
  1e:	2bc7      	cmp	r3, #199	@ 0xc7
  20:	bf8c      	ite	hi
  22:	2400      	movhi	r4, #0
  24:	2401      	movls	r4, #1
  26:	2967      	cmp	r1, #103	@ 0x67
  28:	d9f6      	bls.n	18 <NavigationEskfRecoveryConfiguration_Encode+0x18>
  2a:	2c00      	cmp	r4, #0
  2c:	d1f4      	bne.n	18 <NavigationEskfRecoveryConfiguration_Encode+0x18>
  2e:	f7ff fffe 	bl	0 <NavigationEskfRecoveryConfiguration_Encode>
			2e: R_ARM_THM_CALL	NavigationEskfRecoveryConfiguration_Encode.part.0
  32:	4620      	mov	r0, r4
  34:	bd10      	pop	{r4, pc}
  36:	bf00      	nop
  38:	00000000 	.word	0x00000000
			38: R_ARM_ABS32	.rodata.s_configuration

Disassembly of section .text.NavigationEskfRecoveryConfiguration_Validate:

00000000 <NavigationEskfRecoveryConfiguration_Validate>:
   0:	b510      	push	{r4, lr}
   2:	4b17      	ldr	r3, [pc, #92]	@ (60 <NavigationEskfRecoveryConfiguration_Validate+0x60>)
   4:	b09a      	sub	sp, #104	@ 0x68
   6:	466a      	mov	r2, sp
   8:	429a      	cmp	r2, r3
   a:	d821      	bhi.n	50 <NavigationEskfRecoveryConfiguration_Validate+0x50>
   c:	1a9b      	subs	r3, r3, r2
   e:	2b67      	cmp	r3, #103	@ 0x67
  10:	d922      	bls.n	58 <NavigationEskfRecoveryConfiguration_Validate+0x58>
  12:	4668      	mov	r0, sp
  14:	f7ff fffe 	bl	0 <NavigationEskfRecoveryConfiguration_Validate>
			14: R_ARM_THM_CALL	NavigationEskfRecoveryConfiguration_Encode.part.0
  18:	4c12      	ldr	r4, [pc, #72]	@ (64 <NavigationEskfRecoveryConfiguration_Validate+0x64>)
  1a:	f04f 32ff 	mov.w	r2, #4294967295
  1e:	eb0d 0102 	add.w	r1, sp, r2
  22:	f10d 0c67 	add.w	ip, sp, #103	@ 0x67
  26:	f811 3f01 	ldrb.w	r3, [r1, #1]!
  2a:	2008      	movs	r0, #8
  2c:	405a      	eors	r2, r3
  2e:	f342 0300 	sbfx	r3, r2, #0, #1
  32:	3801      	subs	r0, #1
  34:	4023      	ands	r3, r4
  36:	f010 00ff 	ands.w	r0, r0, #255	@ 0xff
  3a:	ea83 0252 	eor.w	r2, r3, r2, lsr #1
  3e:	d1f6      	bne.n	2e <NavigationEskfRecoveryConfiguration_Validate+0x2e>
  40:	458c      	cmp	ip, r1
  42:	d1f0      	bne.n	26 <NavigationEskfRecoveryConfiguration_Validate+0x26>
  44:	4b08      	ldr	r3, [pc, #32]	@ (68 <NavigationEskfRecoveryConfiguration_Validate+0x68>)
  46:	429a      	cmp	r2, r3
  48:	bf18      	it	ne
  4a:	2003      	movne	r0, #3
  4c:	b01a      	add	sp, #104	@ 0x68
  4e:	bd10      	pop	{r4, pc}
  50:	ebad 0303 	sub.w	r3, sp, r3
  54:	2bc7      	cmp	r3, #199	@ 0xc7
  56:	d8dc      	bhi.n	12 <NavigationEskfRecoveryConfiguration_Validate+0x12>
  58:	2001      	movs	r0, #1
  5a:	b01a      	add	sp, #104	@ 0x68
  5c:	bd10      	pop	{r4, pc}
  5e:	bf00      	nop
  60:	00000000 	.word	0x00000000
			60: R_ARM_ABS32	.rodata.s_configuration
  64:	edb88320 	.word	0xedb88320
  68:	28e0fdd0 	.word	0x28e0fdd0
