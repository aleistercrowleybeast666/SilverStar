
D:\python_software\SilverStar\.work\dev013_navclosure02\eskf15_1_default03\build\FCCG\SilverStar_F407\Release\auto\Algorithm\Estimator\ESKF15\Src\navigation_eskf_horizon.o:     file format elf32-littlearm


Disassembly of section .text.Horizon_BodyValid:

00000000 <Horizon_BodyValid>:
   0:	b570      	push	{r4, r5, r6, lr}
   2:	ed2d 8b02 	vpush	{d8}
   6:	ed90 8a0c 	vldr	s16, [r0, #48]	@ 0x30
   a:	eddf 8a36 	vldr	s17, [pc, #216]	@ e4 <Horizon_BodyValid+0xe4>
   e:	eef0 7ac8 	vabs.f32	s15, s16
  12:	eef4 7a68 	vcmp.f32	s15, s17
  16:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  1a:	d85e      	bhi.n	da <Horizon_BodyValid+0xda>
  1c:	eeb5 8ac0 	vcmpe.f32	s16, #0.0
  20:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  24:	d959      	bls.n	da <Horizon_BodyValid+0xda>
  26:	eddf 7a30 	vldr	s15, [pc, #192]	@ e8 <Horizon_BodyValid+0xe8>
  2a:	eeb4 8ae7 	vcmpe.f32	s16, s15
  2e:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  32:	dc52      	bgt.n	da <Horizon_BodyValid+0xda>
  34:	4604      	mov	r4, r0
  36:	6c00      	ldr	r0, [r0, #64]	@ 0x40
  38:	6ba2      	ldr	r2, [r4, #56]	@ 0x38
  3a:	6c61      	ldr	r1, [r4, #68]	@ 0x44
  3c:	6be6      	ldr	r6, [r4, #60]	@ 0x3c
  3e:	4282      	cmp	r2, r0
  40:	eb76 0301 	sbcs.w	r3, r6, r1
  44:	d249      	bcs.n	da <Horizon_BodyValid+0xda>
  46:	6d23      	ldr	r3, [r4, #80]	@ 0x50
  48:	f013 0572 	ands.w	r5, r3, #114	@ 0x72
  4c:	d145      	bne.n	da <Horizon_BodyValid+0xda>
  4e:	1a80      	subs	r0, r0, r2
  50:	eb61 0106 	sbc.w	r1, r1, r6
  54:	f7ff fffe 	bl	0 <__aeabi_ul2f>
			54: R_ARM_THM_CALL	__aeabi_ul2f
  58:	eddf 6a24 	vldr	s13, [pc, #144]	@ ec <Horizon_BodyValid+0xec>
  5c:	ed9f 7a24 	vldr	s14, [pc, #144]	@ f0 <Horizon_BodyValid+0xf0>
  60:	ee07 0a90 	vmov	s15, r0
  64:	ee67 7aa6 	vmul.f32	s15, s15, s13
  68:	ee77 7ac8 	vsub.f32	s15, s15, s16
  6c:	eef0 7ae7 	vabs.f32	s15, s15
  70:	eef4 7ac7 	vcmpe.f32	s15, s14
  74:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  78:	dc2f      	bgt.n	da <Horizon_BodyValid+0xda>
  7a:	f104 020c 	add.w	r2, r4, #12
  7e:	4623      	mov	r3, r4
  80:	ecf3 7a01 	vldmia	r3!, {s15}
  84:	eef0 7ae7 	vabs.f32	s15, s15
  88:	eef4 7a68 	vcmp.f32	s15, s17
  8c:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  90:	d823      	bhi.n	da <Horizon_BodyValid+0xda>
  92:	edd3 7a05 	vldr	s15, [r3, #20]
  96:	eef0 7ae7 	vabs.f32	s15, s15
  9a:	eef4 7a68 	vcmp.f32	s15, s17
  9e:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  a2:	d81a      	bhi.n	da <Horizon_BodyValid+0xda>
  a4:	4293      	cmp	r3, r2
  a6:	d1eb      	bne.n	80 <Horizon_BodyValid+0x80>
  a8:	ed9f 7a0e 	vldr	s14, [pc, #56]	@ e4 <Horizon_BodyValid+0xe4>
  ac:	3418      	adds	r4, #24
  ae:	ecf3 7a01 	vldmia	r3!, {s15}
  b2:	eef0 7ae7 	vabs.f32	s15, s15
  b6:	eef4 7a47 	vcmp.f32	s15, s14
  ba:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  be:	d80c      	bhi.n	da <Horizon_BodyValid+0xda>
  c0:	edd3 7a05 	vldr	s15, [r3, #20]
  c4:	eef0 7ae7 	vabs.f32	s15, s15
  c8:	eef4 7a47 	vcmp.f32	s15, s14
  cc:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  d0:	d803      	bhi.n	da <Horizon_BodyValid+0xda>
  d2:	42a3      	cmp	r3, r4
  d4:	d1eb      	bne.n	ae <Horizon_BodyValid+0xae>
  d6:	2001      	movs	r0, #1
  d8:	e000      	b.n	dc <Horizon_BodyValid+0xdc>
  da:	2000      	movs	r0, #0
  dc:	ecbd 8b02 	vpop	{d8}
  e0:	bd70      	pop	{r4, r5, r6, pc}
  e2:	bf00      	nop
  e4:	7f7fffff 	.word	0x7f7fffff
  e8:	3ca3d70a 	.word	0x3ca3d70a
  ec:	358637bd 	.word	0x358637bd
  f0:	360637bd 	.word	0x360637bd

Disassembly of section .text.Horizon_NominalValid.part.0:

00000000 <Horizon_NominalValid.part.0>:
   0:	ed9f 6a3f 	vldr	s12, [pc, #252]	@ 100 <Horizon_NominalValid.part.0+0x100>
   4:	eddf 6a3f 	vldr	s13, [pc, #252]	@ 104 <Horizon_NominalValid.part.0+0x104>
   8:	f100 0218 	add.w	r2, r0, #24
   c:	4603      	mov	r3, r0
   e:	f100 0128 	add.w	r1, r0, #40	@ 0x28
  12:	ecf2 7a01 	vldmia	r2!, {s15}
  16:	eeb0 7ae7 	vabs.f32	s14, s15
  1a:	eeb4 7a66 	vcmp.f32	s14, s13
  1e:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  22:	d86b      	bhi.n	fc <Horizon_NominalValid.part.0+0xfc>
  24:	ee67 7aa7 	vmul.f32	s15, s15, s15
  28:	428a      	cmp	r2, r1
  2a:	ee36 6a27 	vadd.f32	s12, s12, s15
  2e:	d1f0      	bne.n	12 <Horizon_NominalValid.part.0+0x12>
  30:	eddf 5a33 	vldr	s11, [pc, #204]	@ 100 <Horizon_NominalValid.part.0+0x100>
  34:	eddf 6a33 	vldr	s13, [pc, #204]	@ 104 <Horizon_NominalValid.part.0+0x104>
  38:	eeb0 5a65 	vmov.f32	s10, s11
  3c:	300c      	adds	r0, #12
  3e:	ecf3 7a01 	vldmia	r3!, {s15}
  42:	eef0 7ae7 	vabs.f32	s15, s15
  46:	eef4 7a66 	vcmp.f32	s15, s13
  4a:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  4e:	d855      	bhi.n	fc <Horizon_NominalValid.part.0+0xfc>
  50:	edd3 7a02 	vldr	s15, [r3, #8]
  54:	eef0 7ae7 	vabs.f32	s15, s15
  58:	eef4 7a66 	vcmp.f32	s15, s13
  5c:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  60:	d84c      	bhi.n	fc <Horizon_NominalValid.part.0+0xfc>
  62:	edd3 7a09 	vldr	s15, [r3, #36]	@ 0x24
  66:	eeb0 7ae7 	vabs.f32	s14, s15
  6a:	eeb4 7a66 	vcmp.f32	s14, s13
  6e:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  72:	d843      	bhi.n	fc <Horizon_NominalValid.part.0+0xfc>
  74:	ed93 7a0c 	vldr	s14, [r3, #48]	@ 0x30
  78:	eef0 4ac7 	vabs.f32	s9, s14
  7c:	eef4 4a66 	vcmp.f32	s9, s13
  80:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  84:	d83a      	bhi.n	fc <Horizon_NominalValid.part.0+0xfc>
  86:	ee67 7aa7 	vmul.f32	s15, s15, s15
  8a:	ee27 7a07 	vmul.f32	s14, s14, s14
  8e:	4283      	cmp	r3, r0
  90:	ee35 5a27 	vadd.f32	s10, s10, s15
  94:	ee75 5a87 	vadd.f32	s11, s11, s14
  98:	d1d1      	bne.n	3e <Horizon_NominalValid.part.0+0x3e>
  9a:	eef0 7ac6 	vabs.f32	s15, s12
  9e:	eef4 7a66 	vcmp.f32	s15, s13
  a2:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  a6:	d829      	bhi.n	fc <Horizon_NominalValid.part.0+0xfc>
  a8:	eef0 7ac5 	vabs.f32	s15, s10
  ac:	eef4 7a66 	vcmp.f32	s15, s13
  b0:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  b4:	d822      	bhi.n	fc <Horizon_NominalValid.part.0+0xfc>
  b6:	eef0 7ae5 	vabs.f32	s15, s11
  ba:	eef4 7a66 	vcmp.f32	s15, s13
  be:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  c2:	d81b      	bhi.n	fc <Horizon_NominalValid.part.0+0xfc>
  c4:	eef7 7a00 	vmov.f32	s15, #112	@ 0x3f800000  1.0
  c8:	ee36 6a67 	vsub.f32	s12, s12, s15
  cc:	ed9f 7a0e 	vldr	s14, [pc, #56]	@ 108 <Horizon_NominalValid.part.0+0x108>
  d0:	eeb0 6ac6 	vabs.f32	s12, s12
  d4:	eeb4 6ac7 	vcmpe.f32	s12, s14
  d8:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  dc:	d80e      	bhi.n	fc <Horizon_NominalValid.part.0+0xfc>
  de:	eeb4 5ae7 	vcmpe.f32	s10, s15
  e2:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  e6:	d809      	bhi.n	fc <Horizon_NominalValid.part.0+0xfc>
  e8:	eef3 7a09 	vmov.f32	s15, #57	@ 0x41c80000  25.0
  ec:	eef4 5ae7 	vcmpe.f32	s11, s15
  f0:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  f4:	bf94      	ite	ls
  f6:	2001      	movls	r0, #1
  f8:	2000      	movhi	r0, #0
  fa:	4770      	bx	lr
  fc:	2000      	movs	r0, #0
  fe:	4770      	bx	lr
 100:	00000000 	.word	0x00000000
 104:	7f7fffff 	.word	0x7f7fffff
 108:	3b032336 	.word	0x3b032336

Disassembly of section .text.Horizon_Ready.part.0:

00000000 <Horizon_Ready.part.0>:
   0:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
   4:	f500 44a0 	add.w	r4, r0, #20480	@ 0x5000
   8:	f894 3653 	ldrb.w	r3, [r4, #1619]	@ 0x653
   c:	2b01      	cmp	r3, #1
   e:	d060      	beq.n	d2 <Horizon_Ready.part.0+0xd2>
  10:	d859      	bhi.n	c6 <Horizon_Ready.part.0+0xc6>
  12:	f8b4 3618 	ldrh.w	r3, [r4, #1560]	@ 0x618
  16:	2b9f      	cmp	r3, #159	@ 0x9f
  18:	d855      	bhi.n	c6 <Horizon_Ready.part.0+0xc6>
  1a:	f8b4 361a 	ldrh.w	r3, [r4, #1562]	@ 0x61a
  1e:	2ba0      	cmp	r3, #160	@ 0xa0
  20:	d851      	bhi.n	c6 <Horizon_Ready.part.0+0xc6>
  22:	f8b4 361c 	ldrh.w	r3, [r4, #1564]	@ 0x61c
  26:	2b40      	cmp	r3, #64	@ 0x40
  28:	d84d      	bhi.n	c6 <Horizon_Ready.part.0+0xc6>
  2a:	f8b4 261e 	ldrh.w	r2, [r4, #1566]	@ 0x61e
  2e:	4293      	cmp	r3, r2
  30:	d349      	bcc.n	c6 <Horizon_Ready.part.0+0xc6>
  32:	f8b4 3620 	ldrh.w	r3, [r4, #1568]	@ 0x620
  36:	4293      	cmp	r3, r2
  38:	d845      	bhi.n	c6 <Horizon_Ready.part.0+0xc6>
  3a:	f500 43ac 	add.w	r3, r0, #22016	@ 0x5600
  3e:	e9d0 76f2 	ldrd	r7, r6, [r0, #968]	@ 0x3c8
  42:	e953 1202 	ldrd	r1, r2, [r3, #-8]
  46:	428f      	cmp	r7, r1
  48:	eb76 0202 	sbcs.w	r2, r6, r2
  4c:	4605      	mov	r5, r0
  4e:	d33a      	bcc.n	c6 <Horizon_Ready.part.0+0xc6>
  50:	e9d3 a900 	ldrd	sl, r9, [r3]
  54:	45ba      	cmp	sl, r7
  56:	eb79 0306 	sbcs.w	r3, r9, r6
  5a:	d334      	bcc.n	c6 <Horizon_Ready.part.0+0xc6>
  5c:	f500 48ac 	add.w	r8, r0, #22016	@ 0x5600
  60:	e9d8 2302 	ldrd	r2, r3, [r8, #8]
  64:	4297      	cmp	r7, r2
  66:	eb76 0303 	sbcs.w	r3, r6, r3
  6a:	f108 0810 	add.w	r8, r8, #16
  6e:	d32a      	bcc.n	c6 <Horizon_Ready.part.0+0xc6>
  70:	f890 33d8 	ldrb.w	r3, [r0, #984]	@ 0x3d8
  74:	2b01      	cmp	r3, #1
  76:	d126      	bne.n	c6 <Horizon_Ready.part.0+0xc6>
  78:	f7ff fffe 	bl	0 <Horizon_Ready.part.0>
			78: R_ARM_THM_CALL	Horizon_NominalValid.part.0
  7c:	b318      	cbz	r0, c6 <Horizon_Ready.part.0+0xc6>
  7e:	f895 3b98 	ldrb.w	r3, [r5, #2968]	@ 0xb98
  82:	2b01      	cmp	r3, #1
  84:	d11f      	bne.n	c6 <Horizon_Ready.part.0+0xc6>
  86:	f505 60f8 	add.w	r0, r5, #1984	@ 0x7c0
  8a:	f7ff fffe 	bl	0 <Horizon_Ready.part.0>
			8a: R_ARM_THM_CALL	Horizon_NominalValid.part.0
  8e:	b1d0      	cbz	r0, c6 <Horizon_Ready.part.0+0xc6>
  90:	f8d5 2b88 	ldr.w	r2, [r5, #2952]	@ 0xb88
  94:	f8d5 3b8c 	ldr.w	r3, [r5, #2956]	@ 0xb8c
  98:	42ba      	cmp	r2, r7
  9a:	eb73 0606 	sbcs.w	r6, r3, r6
  9e:	d312      	bcc.n	c6 <Horizon_Ready.part.0+0xc6>
  a0:	4592      	cmp	sl, r2
  a2:	eb79 0303 	sbcs.w	r3, r9, r3
  a6:	d30e      	bcc.n	c6 <Horizon_Ready.part.0+0xc6>
  a8:	f245 6310 	movw	r3, #22032	@ 0x5610
  ac:	490a      	ldr	r1, [pc, #40]	@ (d8 <Horizon_Ready.part.0+0xd8>)
  ae:	58eb      	ldr	r3, [r5, r3]
  b0:	f8d8 2004 	ldr.w	r2, [r8, #4]
  b4:	185b      	adds	r3, r3, r1
  b6:	4909      	ldr	r1, [pc, #36]	@ (dc <Horizon_Ready.part.0+0xdc>)
  b8:	f162 0200 	sbc.w	r2, r2, #0
  bc:	2000      	movs	r0, #0
  be:	4299      	cmp	r1, r3
  c0:	eb70 0202 	sbcs.w	r2, r0, r2
  c4:	d203      	bcs.n	ce <Horizon_Ready.part.0+0xce>
  c6:	2301      	movs	r3, #1
  c8:	f884 3653 	strb.w	r3, [r4, #1619]	@ 0x653
  cc:	200a      	movs	r0, #10
  ce:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
  d2:	200c      	movs	r0, #12
  d4:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
  d8:	ffffd8f0 	.word	0xffffd8f0
  dc:	00083d60 	.word	0x00083d60

Disassembly of section .text.Horizon_Insert.part.0:

00000000 <Horizon_Insert.part.0>:
   0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
   4:	b087      	sub	sp, #28
   6:	9001      	str	r0, [sp, #4]
   8:	b349      	cbz	r1, 5e <Horizon_Insert.part.0+0x5e>
   a:	469a      	mov	sl, r3
   c:	9b01      	ldr	r3, [sp, #4]
   e:	428b      	cmp	r3, r1
  10:	4615      	mov	r5, r2
  12:	d829      	bhi.n	68 <Horizon_Insert.part.0+0x68>
  14:	1acb      	subs	r3, r1, r3
  16:	f245 6257 	movw	r2, #22103	@ 0x5657
  1a:	4293      	cmp	r3, r2
  1c:	bf8c      	ite	hi
  1e:	2300      	movhi	r3, #0
  20:	2301      	movls	r3, #1
  22:	b9e3      	cbnz	r3, 5e <Horizon_Insert.part.0+0x5e>
  24:	9b01      	ldr	r3, [sp, #4]
  26:	f503 48a0 	add.w	r8, r3, #20480	@ 0x5000
  2a:	f8b8 361e 	ldrh.w	r3, [r8, #1566]	@ 0x61e
  2e:	2b00      	cmp	r3, #0
  30:	f040 8185 	bne.w	33e <Horizon_Insert.part.0+0x33e>
  34:	f898 3651 	ldrb.w	r3, [r8, #1617]	@ 0x651
  38:	2b00      	cmp	r3, #0
  3a:	f000 8185 	beq.w	348 <Horizon_Insert.part.0+0x348>
  3e:	7f0a      	ldrb	r2, [r1, #28]
  40:	07d0      	lsls	r0, r2, #31
  42:	d50a      	bpl.n	5a <Horizon_Insert.part.0+0x5a>
  44:	2a04      	cmp	r2, #4
  46:	d80a      	bhi.n	5e <Horizon_Insert.part.0+0x5e>
  48:	694b      	ldr	r3, [r1, #20]
  4a:	2b03      	cmp	r3, #3
  4c:	d807      	bhi.n	5e <Horizon_Insert.part.0+0x5e>
  4e:	7f4b      	ldrb	r3, [r1, #29]
  50:	2b01      	cmp	r3, #1
  52:	d804      	bhi.n	5e <Horizon_Insert.part.0+0x5e>
  54:	f04f 0901 	mov.w	r9, #1
  58:	e019      	b.n	8e <Horizon_Insert.part.0+0x8e>
  5a:	2a04      	cmp	r2, #4
  5c:	d90b      	bls.n	76 <Horizon_Insert.part.0+0x76>
  5e:	2603      	movs	r6, #3
  60:	4630      	mov	r0, r6
  62:	b007      	add	sp, #28
  64:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
  68:	9b01      	ldr	r3, [sp, #4]
  6a:	1a5b      	subs	r3, r3, r1
  6c:	2b87      	cmp	r3, #135	@ 0x87
  6e:	bf8c      	ite	hi
  70:	2300      	movhi	r3, #0
  72:	2301      	movls	r3, #1
  74:	e7d5      	b.n	22 <Horizon_Insert.part.0+0x22>
  76:	694b      	ldr	r3, [r1, #20]
  78:	2b03      	cmp	r3, #3
  7a:	d8f0      	bhi.n	5e <Horizon_Insert.part.0+0x5e>
  7c:	2a04      	cmp	r2, #4
  7e:	d101      	bne.n	84 <Horizon_Insert.part.0+0x84>
  80:	2b01      	cmp	r3, #1
  82:	d1ec      	bne.n	5e <Horizon_Insert.part.0+0x5e>
  84:	7f4b      	ldrb	r3, [r1, #29]
  86:	2b01      	cmp	r3, #1
  88:	d8e9      	bhi.n	5e <Horizon_Insert.part.0+0x5e>
  8a:	f04f 0902 	mov.w	r9, #2
  8e:	e9d1 c700 	ldrd	ip, r7, [r1]
  92:	ea5c 0307 	orrs.w	r3, ip, r7
  96:	d0e2      	beq.n	5e <Horizon_Insert.part.0+0x5e>
  98:	edd1 7a17 	vldr	s15, [r1, #92]	@ 0x5c
  9c:	ed9f 7acb 	vldr	s14, [pc, #812]	@ 3cc <Horizon_Insert.part.0+0x3cc>
  a0:	eef0 6ae7 	vabs.f32	s13, s15
  a4:	eef4 6a47 	vcmp.f32	s13, s14
  a8:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  ac:	d8d7      	bhi.n	5e <Horizon_Insert.part.0+0x5e>
  ae:	eef5 7ac0 	vcmpe.f32	s15, #0.0
  b2:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  b6:	d9d2      	bls.n	5e <Horizon_Insert.part.0+0x5e>
  b8:	edd1 7a18 	vldr	s15, [r1, #96]	@ 0x60
  bc:	eef0 6ae7 	vabs.f32	s13, s15
  c0:	eef4 6a47 	vcmp.f32	s13, s14
  c4:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  c8:	d8c9      	bhi.n	5e <Horizon_Insert.part.0+0x5e>
  ca:	eef5 7ac0 	vcmpe.f32	s15, #0.0
  ce:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  d2:	d9c4      	bls.n	5e <Horizon_Insert.part.0+0x5e>
  d4:	e9d1 6e02 	ldrd	r6, lr, [r1, #8]
  d8:	ea56 030e 	orrs.w	r3, r6, lr
  dc:	d0bf      	beq.n	5e <Horizon_Insert.part.0+0x5e>
  de:	4566      	cmp	r6, ip
  e0:	eb7e 0307 	sbcs.w	r3, lr, r7
  e4:	d3bb      	bcc.n	5e <Horizon_Insert.part.0+0x5e>
  e6:	9b01      	ldr	r3, [sp, #4]
  e8:	f503 4bac 	add.w	fp, r3, #22016	@ 0x5600
  ec:	e9db 0300 	ldrd	r0, r3, [fp]
  f0:	42b0      	cmp	r0, r6
  f2:	9302      	str	r3, [sp, #8]
  f4:	eb73 030e 	sbcs.w	r3, r3, lr
  f8:	d3b1      	bcc.n	5e <Horizon_Insert.part.0+0x5e>
  fa:	9b01      	ldr	r3, [sp, #4]
  fc:	698c      	ldr	r4, [r1, #24]
  fe:	f8d3 33d4 	ldr.w	r3, [r3, #980]	@ 0x3d4
 102:	429c      	cmp	r4, r3
 104:	f040 8171 	bne.w	3ea <Horizon_Insert.part.0+0x3ea>
 108:	e95b 3402 	ldrd	r3, r4, [fp, #-8]
 10c:	459c      	cmp	ip, r3
 10e:	eb77 0304 	sbcs.w	r3, r7, r4
 112:	f0c0 816a 	bcc.w	3ea <Horizon_Insert.part.0+0x3ea>
 116:	ebb0 040c 	subs.w	r4, r0, ip
 11a:	9b02      	ldr	r3, [sp, #8]
 11c:	9003      	str	r0, [sp, #12]
 11e:	48ac      	ldr	r0, [pc, #688]	@ (3d0 <Horizon_Insert.part.0+0x3d0>)
 120:	eb63 0307 	sbc.w	r3, r3, r7
 124:	f04f 0b00 	mov.w	fp, #0
 128:	42a0      	cmp	r0, r4
 12a:	eb7b 0303 	sbcs.w	r3, fp, r3
 12e:	f0c0 8167 	bcc.w	400 <Horizon_Insert.part.0+0x400>
 132:	9c03      	ldr	r4, [sp, #12]
 134:	9b02      	ldr	r3, [sp, #8]
 136:	48a7      	ldr	r0, [pc, #668]	@ (3d4 <Horizon_Insert.part.0+0x3d4>)
 138:	1ba6      	subs	r6, r4, r6
 13a:	eb63 030e 	sbc.w	r3, r3, lr
 13e:	42b0      	cmp	r0, r6
 140:	eb7b 0303 	sbcs.w	r3, fp, r3
 144:	f0c0 815c 	bcc.w	400 <Horizon_Insert.part.0+0x400>
 148:	2a04      	cmp	r2, #4
 14a:	eef0 7a47 	vmov.f32	s15, s14
 14e:	bf08      	it	eq
 150:	f04f 0901 	moveq.w	r9, #1
 154:	465b      	mov	r3, fp
 156:	f101 0020 	add.w	r0, r1, #32
 15a:	ed90 7a00 	vldr	s14, [r0]
 15e:	eeb0 7ac7 	vabs.f32	s14, s14
 162:	eeb4 7a67 	vcmp.f32	s14, s15
 166:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 16a:	f63f af78 	bhi.w	5e <Horizon_Insert.part.0+0x5e>
 16e:	ed90 7a02 	vldr	s14, [r0, #8]
 172:	eef0 6ac7 	vabs.f32	s13, s14
 176:	eef4 6a67 	vcmp.f32	s13, s15
 17a:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 17e:	f63f af6e 	bhi.w	5e <Horizon_Insert.part.0+0x5e>
 182:	eeb5 7ac0 	vcmpe.f32	s14, #0.0
 186:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 18a:	f67f af68 	bls.w	5e <Horizon_Insert.part.0+0x5e>
 18e:	ed90 7a0d 	vldr	s14, [r0, #52]	@ 0x34
 192:	eef0 6ac7 	vabs.f32	s13, s14
 196:	eef4 6a67 	vcmp.f32	s13, s15
 19a:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 19e:	f100 0004 	add.w	r0, r0, #4
 1a2:	f63f af5c 	bhi.w	5e <Horizon_Insert.part.0+0x5e>
 1a6:	eeb5 7ac0 	vcmpe.f32	s14, #0.0
 1aa:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 1ae:	f67f af56 	bls.w	5e <Horizon_Insert.part.0+0x5e>
 1b2:	b923      	cbnz	r3, 1be <Horizon_Insert.part.0+0x1be>
 1b4:	f1b9 0f02 	cmp.w	r9, #2
 1b8:	f04f 0301 	mov.w	r3, #1
 1bc:	d0cd      	beq.n	15a <Horizon_Insert.part.0+0x15a>
 1be:	edd1 7a0c 	vldr	s15, [r1, #48]	@ 0x30
 1c2:	ed9f 7a82 	vldr	s14, [pc, #520]	@ 3cc <Horizon_Insert.part.0+0x3cc>
 1c6:	eef0 7ae7 	vabs.f32	s15, s15
 1ca:	eef4 7a47 	vcmp.f32	s15, s14
 1ce:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 1d2:	f63f af44 	bhi.w	5e <Horizon_Insert.part.0+0x5e>
 1d6:	edd1 7a0d 	vldr	s15, [r1, #52]	@ 0x34
 1da:	eef0 7ae7 	vabs.f32	s15, s15
 1de:	eef4 7a47 	vcmp.f32	s15, s14
 1e2:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 1e6:	f63f af3a 	bhi.w	5e <Horizon_Insert.part.0+0x5e>
 1ea:	edd1 7a0e 	vldr	s15, [r1, #56]	@ 0x38
 1ee:	eef0 7ae7 	vabs.f32	s15, s15
 1f2:	eef4 7a47 	vcmp.f32	s15, s14
 1f6:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 1fa:	f63f af30 	bhi.w	5e <Horizon_Insert.part.0+0x5e>
 1fe:	2a04      	cmp	r2, #4
 200:	f000 80cb 	beq.w	39a <Horizon_Insert.part.0+0x39a>
 204:	694b      	ldr	r3, [r1, #20]
 206:	9801      	ldr	r0, [sp, #4]
 208:	f603 23ba 	addw	r3, r3, #2746	@ 0xaba
 20c:	eb00 03c3 	add.w	r3, r0, r3, lsl #3
 210:	2001      	movs	r0, #1
 212:	f893 e004 	ldrb.w	lr, [r3, #4]
 216:	fa00 f202 	lsl.w	r2, r0, r2
 21a:	b2d2      	uxtb	r2, r2
 21c:	6908      	ldr	r0, [r1, #16]
 21e:	f1be 0f00 	cmp.w	lr, #0
 222:	d007      	beq.n	234 <Horizon_Insert.part.0+0x234>
 224:	681e      	ldr	r6, [r3, #0]
 226:	42b0      	cmp	r0, r6
 228:	f000 80be 	beq.w	3a8 <Horizon_Insert.part.0+0x3a8>
 22c:	1b86      	subs	r6, r0, r6
 22e:	2e00      	cmp	r6, #0
 230:	f2c0 80b8 	blt.w	3a4 <Horizon_Insert.part.0+0x3a4>
 234:	6018      	str	r0, [r3, #0]
 236:	711a      	strb	r2, [r3, #4]
 238:	7f4e      	ldrb	r6, [r1, #29]
 23a:	2e01      	cmp	r6, #1
 23c:	f47f af0f 	bne.w	5e <Horizon_Insert.part.0+0x5e>
 240:	9b01      	ldr	r3, [sp, #4]
 242:	e9d3 23f2 	ldrd	r2, r3, [r3, #968]	@ 0x3c8
 246:	4594      	cmp	ip, r2
 248:	419f      	sbcs	r7, r3
 24a:	f0c0 80b3 	bcc.w	3b4 <Horizon_Insert.part.0+0x3b4>
 24e:	f8b8 761c 	ldrh.w	r7, [r8, #1564]	@ 0x61c
 252:	2f40      	cmp	r7, #64	@ 0x40
 254:	f000 80c0 	beq.w	3d8 <Horizon_Insert.part.0+0x3d8>
 258:	9b01      	ldr	r3, [sp, #4]
 25a:	eb07 1907 	add.w	r9, r7, r7, lsl #4
 25e:	eb03 09c9 	add.w	r9, r3, r9, lsl #3
 262:	ebc7 03c7 	rsb	r3, r7, r7, lsl #3
 266:	eb05 0283 	add.w	r2, r5, r3, lsl #2
 26a:	f607 43cf 	addw	r3, r7, #3279	@ 0xccf
 26e:	eb05 0b03 	add.w	fp, r5, r3
 272:	f1a7 0340 	sub.w	r3, r7, #64	@ 0x40
 276:	f509 594d 	add.w	r9, r9, #13120	@ 0x3340
 27a:	b29b      	uxth	r3, r3
 27c:	e9cd 3602 	strd	r3, r6, [sp, #8]
 280:	e9cd a804 	strd	sl, r8, [sp, #16]
 284:	f109 0908 	add.w	r9, r9, #8
 288:	460e      	mov	r6, r1
 28a:	4690      	mov	r8, r2
 28c:	2288      	movs	r2, #136	@ 0x88
 28e:	2f00      	cmp	r7, #0
 290:	f000 80ad 	beq.w	3ee <Horizon_Insert.part.0+0x3ee>
 294:	f8d6 e000 	ldr.w	lr, [r6]
 298:	f8d9 c000 	ldr.w	ip, [r9]
 29c:	6874      	ldr	r4, [r6, #4]
 29e:	f8d9 3004 	ldr.w	r3, [r9, #4]
 2a2:	45e6      	cmp	lr, ip
 2a4:	eb74 0a03 	sbcs.w	sl, r4, r3
 2a8:	4649      	mov	r1, r9
 2aa:	eb09 0002 	add.w	r0, r9, r2
 2ae:	d355      	bcc.n	35c <Horizon_Insert.part.0+0x35c>
 2b0:	429c      	cmp	r4, r3
 2b2:	bf08      	it	eq
 2b4:	45e6      	cmpeq	lr, ip
 2b6:	d04c      	beq.n	352 <Horizon_Insert.part.0+0x352>
 2b8:	4631      	mov	r1, r6
 2ba:	e9dd 6a03 	ldrd	r6, sl, [sp, #12]
 2be:	eb07 1307 	add.w	r3, r7, r7, lsl #4
 2c2:	f243 4b38 	movw	fp, #13368	@ 0x3438
 2c6:	f8dd 8014 	ldr.w	r8, [sp, #20]
 2ca:	eb0b 0bc3 	add.w	fp, fp, r3, lsl #3
 2ce:	ea4f 1907 	mov.w	r9, r7, lsl #4
 2d2:	9b01      	ldr	r3, [sp, #4]
 2d4:	eb09 0007 	add.w	r0, r9, r7
 2d8:	eb03 00c0 	add.w	r0, r3, r0, lsl #3
 2dc:	f500 504f 	add.w	r0, r0, #13248	@ 0x33c0
 2e0:	3010      	adds	r0, #16
 2e2:	2288      	movs	r2, #136	@ 0x88
 2e4:	f7ff fffe 	bl	0 <memcpy>
			2e4: R_ARM_THM_CALL	memcpy
 2e8:	b19d      	cbz	r5, 312 <Horizon_Insert.part.0+0x312>
 2ea:	46d6      	mov	lr, sl
 2ec:	e8be 000f 	ldmia.w	lr!, {r0, r1, r2, r3}
 2f0:	ebc7 0cc7 	rsb	ip, r7, r7, lsl #3
 2f4:	eb05 0c8c 	add.w	ip, r5, ip, lsl #2
 2f8:	f50c 6cba 	add.w	ip, ip, #1488	@ 0x5d0
 2fc:	e8ac 000f 	stmia.w	ip!, {r0, r1, r2, r3}
 300:	e89e 0007 	ldmia.w	lr, {r0, r1, r2}
 304:	443d      	add	r5, r7
 306:	f04f 0a00 	mov.w	sl, #0
 30a:	e88c 0007 	stmia.w	ip, {r0, r1, r2}
 30e:	f885 acd0 	strb.w	sl, [r5, #3280]	@ 0xcd0
 312:	9c01      	ldr	r4, [sp, #4]
 314:	2220      	movs	r2, #32
 316:	eb04 000b 	add.w	r0, r4, fp
 31a:	2100      	movs	r1, #0
 31c:	44b9      	add	r9, r7
 31e:	f7ff fffe 	bl	0 <memset>
			31e: R_ARM_THM_CALL	memset
 322:	eb04 09c9 	add.w	r9, r4, r9, lsl #3
 326:	f8b8 361c 	ldrh.w	r3, [r8, #1564]	@ 0x61c
 32a:	f509 5950 	add.w	r9, r9, #13312	@ 0x3400
 32e:	f04f 527e 	mov.w	r2, #1065353216	@ 0x3f800000
 332:	3301      	adds	r3, #1
 334:	f8c9 203c 	str.w	r2, [r9, #60]	@ 0x3c
 338:	f8a8 361c 	strh.w	r3, [r8, #1564]	@ 0x61c
 33c:	e690      	b.n	60 <Horizon_Insert.part.0+0x60>
 33e:	260d      	movs	r6, #13
 340:	4630      	mov	r0, r6
 342:	b007      	add	sp, #28
 344:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 348:	260c      	movs	r6, #12
 34a:	4630      	mov	r0, r6
 34c:	b007      	add	sp, #28
 34e:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 352:	7f34      	ldrb	r4, [r6, #28]
 354:	f899 301c 	ldrb.w	r3, [r9, #28]
 358:	429c      	cmp	r4, r3
 35a:	d2ad      	bcs.n	2b8 <Horizon_Insert.part.0+0x2b8>
 35c:	3f01      	subs	r7, #1
 35e:	f7ff fffe 	bl	0 <memcpy>
			35e: R_ARM_THM_CALL	memcpy
 362:	b2bf      	uxth	r7, r7
 364:	f1a9 0988 	sub.w	r9, r9, #136	@ 0x88
 368:	b175      	cbz	r5, 388 <Horizon_Insert.part.0+0x388>
 36a:	f208 5cb4 	addw	ip, r8, #1460	@ 0x5b4
 36e:	e8bc 000f 	ldmia.w	ip!, {r0, r1, r2, r3}
 372:	f508 64ba 	add.w	r4, r8, #1488	@ 0x5d0
 376:	c40f      	stmia	r4!, {r0, r1, r2, r3}
 378:	e89c 0007 	ldmia.w	ip, {r0, r1, r2}
 37c:	e884 0007 	stmia.w	r4, {r0, r1, r2}
 380:	f89b 3000 	ldrb.w	r3, [fp]
 384:	f88b 3001 	strb.w	r3, [fp, #1]
 388:	9b02      	ldr	r3, [sp, #8]
 38a:	429f      	cmp	r7, r3
 38c:	f1a8 081c 	sub.w	r8, r8, #28
 390:	f10b 3bff 	add.w	fp, fp, #4294967295
 394:	f47f af7a 	bne.w	28c <Horizon_Insert.part.0+0x28c>
 398:	e78e      	b.n	2b8 <Horizon_Insert.part.0+0x2b8>
 39a:	9b01      	ldr	r3, [sp, #4]
 39c:	f503 43ab 	add.w	r3, r3, #21888	@ 0x5580
 3a0:	3370      	adds	r3, #112	@ 0x70
 3a2:	e735      	b.n	210 <Horizon_Insert.part.0+0x210>
 3a4:	2609      	movs	r6, #9
 3a6:	e65b      	b.n	60 <Horizon_Insert.part.0+0x60>
 3a8:	ea12 0f0e 	tst.w	r2, lr
 3ac:	d10b      	bne.n	3c6 <Horizon_Insert.part.0+0x3c6>
 3ae:	ea42 020e 	orr.w	r2, r2, lr
 3b2:	e73f      	b.n	234 <Horizon_Insert.part.0+0x234>
 3b4:	f8d8 362c 	ldr.w	r3, [r8, #1580]	@ 0x62c
 3b8:	1c59      	adds	r1, r3, #1
 3ba:	bf1c      	itt	ne
 3bc:	3301      	addne	r3, #1
 3be:	f8c8 362c 	strne.w	r3, [r8, #1580]	@ 0x62c
 3c2:	2605      	movs	r6, #5
 3c4:	e64c      	b.n	60 <Horizon_Insert.part.0+0x60>
 3c6:	2607      	movs	r6, #7
 3c8:	e64a      	b.n	60 <Horizon_Insert.part.0+0x60>
 3ca:	bf00      	nop
 3cc:	7f7fffff 	.word	0x7f7fffff
 3d0:	000927c0 	.word	0x000927c0
 3d4:	0007a120 	.word	0x0007a120
 3d8:	f8d8 3630 	ldr.w	r3, [r8, #1584]	@ 0x630
 3dc:	1c5a      	adds	r2, r3, #1
 3de:	bf1c      	itt	ne
 3e0:	3301      	addne	r3, #1
 3e2:	f8c8 3630 	strne.w	r3, [r8, #1584]	@ 0x630
 3e6:	2606      	movs	r6, #6
 3e8:	e63a      	b.n	60 <Horizon_Insert.part.0+0x60>
 3ea:	2608      	movs	r6, #8
 3ec:	e638      	b.n	60 <Horizon_Insert.part.0+0x60>
 3ee:	4631      	mov	r1, r6
 3f0:	f8dd 8014 	ldr.w	r8, [sp, #20]
 3f4:	e9dd 6a03 	ldrd	r6, sl, [sp, #12]
 3f8:	f243 4b38 	movw	fp, #13368	@ 0x3438
 3fc:	46b9      	mov	r9, r7
 3fe:	e768      	b.n	2d2 <Horizon_Insert.part.0+0x2d2>
 400:	2604      	movs	r6, #4
 402:	e62d      	b.n	60 <Horizon_Insert.part.0+0x60>

Disassembly of section .text.Horizon_CompletionPop:

00000000 <Horizon_CompletionPop>:
   0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
   4:	b085      	sub	sp, #20
   6:	2800      	cmp	r0, #0
   8:	f000 808d 	beq.w	126 <Horizon_CompletionPop+0x126>
   c:	f500 47a0 	add.w	r7, r0, #20480	@ 0x5000
  10:	4699      	mov	r9, r3
  12:	f897 3652 	ldrb.w	r3, [r7, #1618]	@ 0x652
  16:	2b01      	cmp	r3, #1
  18:	4683      	mov	fp, r0
  1a:	f040 808a 	bne.w	132 <Horizon_CompletionPop+0x132>
  1e:	460c      	mov	r4, r1
  20:	4616      	mov	r6, r2
  22:	f7ff fffe 	bl	0 <Horizon_CompletionPop>
			22: R_ARM_THM_CALL	Horizon_Ready.part.0
  26:	9000      	str	r0, [sp, #0]
  28:	2800      	cmp	r0, #0
  2a:	d174      	bne.n	116 <Horizon_CompletionPop+0x116>
  2c:	2c00      	cmp	r4, #0
  2e:	d07a      	beq.n	126 <Horizon_CompletionPop+0x126>
  30:	45a3      	cmp	fp, r4
  32:	d874      	bhi.n	11e <Horizon_CompletionPop+0x11e>
  34:	eba4 020b 	sub.w	r2, r4, fp
  38:	f245 6357 	movw	r3, #22103	@ 0x5657
  3c:	429a      	cmp	r2, r3
  3e:	d972      	bls.n	126 <Horizon_CompletionPop+0x126>
  40:	f8b7 561e 	ldrh.w	r5, [r7, #1566]	@ 0x61e
  44:	2d00      	cmp	r5, #0
  46:	d07a      	beq.n	13e <Horizon_CompletionPop+0x13e>
  48:	f8b7 8620 	ldrh.w	r8, [r7, #1568]	@ 0x620
  4c:	eb08 1108 	add.w	r1, r8, r8, lsl #4
  50:	eb0b 01c1 	add.w	r1, fp, r1, lsl #3
  54:	f501 514f 	add.w	r1, r1, #13248	@ 0x33c0
  58:	4620      	mov	r0, r4
  5a:	2288      	movs	r2, #136	@ 0x88
  5c:	3110      	adds	r1, #16
  5e:	f7ff fffe 	bl	0 <memcpy>
			5e: R_ARM_THM_CALL	memcpy
  62:	b146      	cbz	r6, 76 <Horizon_CompletionPop+0x76>
  64:	44b0      	add	r8, r6
  66:	f898 3cd0 	ldrb.w	r3, [r8, #3280]	@ 0xcd0
  6a:	f889 3000 	strb.w	r3, [r9]
  6e:	f8b7 8620 	ldrh.w	r8, [r7, #1568]	@ 0x620
  72:	f8b7 561e 	ldrh.w	r5, [r7, #1566]	@ 0x61e
  76:	f108 0801 	add.w	r8, r8, #1
  7a:	fa1f f888 	uxth.w	r8, r8
  7e:	4545      	cmp	r5, r8
  80:	f8a7 8620 	strh.w	r8, [r7, #1568]	@ 0x620
  84:	d147      	bne.n	116 <Horizon_CompletionPop+0x116>
  86:	f8b7 361c 	ldrh.w	r3, [r7, #1564]	@ 0x61c
  8a:	f505 624d 	add.w	r2, r5, #3280	@ 0xcd0
  8e:	1b5b      	subs	r3, r3, r5
  90:	ebc5 08c5 	rsb	r8, r5, r5, lsl #3
  94:	b29b      	uxth	r3, r3
  96:	eb05 1905 	add.w	r9, r5, r5, lsl #4
  9a:	f50b 5b4f 	add.w	fp, fp, #13248	@ 0x33c0
  9e:	ea4f 0888 	mov.w	r8, r8, lsl #2
  a2:	9201      	str	r2, [sp, #4]
  a4:	f106 0240 	add.w	r2, r6, #64	@ 0x40
  a8:	e9cd 3702 	strd	r3, r7, [sp, #8]
  ac:	f10b 0b10 	add.w	fp, fp, #16
  b0:	f508 68ba 	add.w	r8, r8, #1488	@ 0x5d0
  b4:	ea4f 09c9 	mov.w	r9, r9, lsl #3
  b8:	4635      	mov	r5, r6
  ba:	eb03 0a06 	add.w	sl, r3, r6
  be:	4634      	mov	r4, r6
  c0:	4617      	mov	r7, r2
  c2:	e019      	b.n	f8 <Horizon_CompletionPop+0xf8>
  c4:	4658      	mov	r0, fp
  c6:	f7ff fffe 	bl	0 <memcpy>
			c6: R_ARM_THM_CALL	memcpy
  ca:	f10b 0b88 	add.w	fp, fp, #136	@ 0x88
  ce:	eb05 0e08 	add.w	lr, r5, r8
  d2:	f505 6cba 	add.w	ip, r5, #1488	@ 0x5d0
  d6:	351c      	adds	r5, #28
  d8:	b15e      	cbz	r6, f2 <Horizon_CompletionPop+0xf2>
  da:	e8be 000f 	ldmia.w	lr!, {r0, r1, r2, r3}
  de:	e8ac 000f 	stmia.w	ip!, {r0, r1, r2, r3}
  e2:	e89e 0007 	ldmia.w	lr, {r0, r1, r2}
  e6:	e88c 0007 	stmia.w	ip, {r0, r1, r2}
  ea:	9b01      	ldr	r3, [sp, #4]
  ec:	5ce3      	ldrb	r3, [r4, r3]
  ee:	f884 3cd0 	strb.w	r3, [r4, #3280]	@ 0xcd0
  f2:	3401      	adds	r4, #1
  f4:	42bc      	cmp	r4, r7
  f6:	d005      	beq.n	104 <Horizon_CompletionPop+0x104>
  f8:	4554      	cmp	r4, sl
  fa:	f04f 0288 	mov.w	r2, #136	@ 0x88
  fe:	eb0b 0109 	add.w	r1, fp, r9
 102:	d1df      	bne.n	c4 <Horizon_CompletionPop+0xc4>
 104:	e9dd 3702 	ldrd	r3, r7, [sp, #8]
 108:	2200      	movs	r2, #0
 10a:	f8a7 361c 	strh.w	r3, [r7, #1564]	@ 0x61c
 10e:	f8a7 261e 	strh.w	r2, [r7, #1566]	@ 0x61e
 112:	f8a7 2620 	strh.w	r2, [r7, #1568]	@ 0x620
 116:	9800      	ldr	r0, [sp, #0]
 118:	b005      	add	sp, #20
 11a:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 11e:	ebab 0304 	sub.w	r3, fp, r4
 122:	2b87      	cmp	r3, #135	@ 0x87
 124:	d88c      	bhi.n	40 <Horizon_CompletionPop+0x40>
 126:	2303      	movs	r3, #3
 128:	9300      	str	r3, [sp, #0]
 12a:	9800      	ldr	r0, [sp, #0]
 12c:	b005      	add	sp, #20
 12e:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 132:	230c      	movs	r3, #12
 134:	9300      	str	r3, [sp, #0]
 136:	9800      	ldr	r0, [sp, #0]
 138:	b005      	add	sp, #20
 13a:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 13e:	230e      	movs	r3, #14
 140:	9300      	str	r3, [sp, #0]
 142:	9800      	ldr	r0, [sp, #0]
 144:	b005      	add	sp, #20
 146:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 14a:	bf00      	nop

Disassembly of section .text.Horizon_PropagateTo:

00000000 <Horizon_PropagateTo>:
   0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
   4:	ed2d 8b02 	vpush	{d8}
   8:	b0b5      	sub	sp, #212	@ 0xd4
   a:	e9d1 9bf2 	ldrd	r9, fp, [r1, #968]	@ 0x3c8
   e:	9b40      	ldr	r3, [sp, #256]	@ 0x100
  10:	9303      	str	r3, [sp, #12]
  12:	9b41      	ldr	r3, [sp, #260]	@ 0x104
  14:	9304      	str	r3, [sp, #16]
  16:	f500 43a0 	add.w	r3, r0, #20480	@ 0x5000
  1a:	e9cd 3105 	strd	r3, r1, [sp, #20]
  1e:	ed9f 8aac 	vldr	s16, [pc, #688]	@ 2d0 <Horizon_PropagateTo+0x2d0>
  22:	9207      	str	r2, [sp, #28]
  24:	4604      	mov	r4, r0
  26:	2600      	movs	r6, #0
  28:	e0a4      	b.n	174 <Horizon_PropagateTo+0x174>
  2a:	f504 43ac 	add.w	r3, r4, #22016	@ 0x5600
  2e:	3310      	adds	r3, #16
  30:	f853 2c08 	ldr.w	r2, [r3, #-8]
  34:	f853 8c04 	ldr.w	r8, [r3, #-4]
  38:	9201      	str	r2, [sp, #4]
  3a:	9b01      	ldr	r3, [sp, #4]
  3c:	ea4f 1e85 	mov.w	lr, r5, lsl #6
  40:	e9cd 3816 	strd	r3, r8, [sp, #88]	@ 0x58
  44:	f60e 33d8 	addw	r3, lr, #3032	@ 0xbd8
  48:	eb04 0a03 	add.w	sl, r4, r3
  4c:	58e0      	ldr	r0, [r4, r3]
  4e:	f8da 1004 	ldr.w	r1, [sl, #4]
  52:	f8da 2008 	ldr.w	r2, [sl, #8]
  56:	f8da 300c 	ldr.w	r3, [sl, #12]
  5a:	af08      	add	r7, sp, #32
  5c:	c70f      	stmia	r7!, {r0, r1, r2, r3}
  5e:	eb04 1585 	add.w	r5, r4, r5, lsl #6
  62:	f8da 0010 	ldr.w	r0, [sl, #16]
  66:	f8da 1014 	ldr.w	r1, [sl, #20]
  6a:	f8d5 abd4 	ldr.w	sl, [r5, #3028]	@ 0xbd4
  6e:	f8cd a064 	str.w	sl, [sp, #100]	@ 0x64
  72:	f50e 6e3f 	add.w	lr, lr, #3056	@ 0xbf0
  76:	f605 4308 	addw	r3, r5, #3080	@ 0xc08
  7a:	eb04 0c0e 	add.w	ip, r4, lr
  7e:	c703      	stmia	r7!, {r0, r1}
  80:	f8d5 7bd0 	ldr.w	r7, [r5, #3024]	@ 0xbd0
  84:	f8d5 5c0c 	ldr.w	r5, [r5, #3084]	@ 0xc0c
  88:	681b      	ldr	r3, [r3, #0]
  8a:	951c      	str	r5, [sp, #112]	@ 0x70
  8c:	f8d4 53d4 	ldr.w	r5, [r4, #980]	@ 0x3d4
  90:	f854 000e 	ldr.w	r0, [r4, lr]
  94:	f8dc 1004 	ldr.w	r1, [ip, #4]
  98:	9314      	str	r3, [sp, #80]	@ 0x50
  9a:	951b      	str	r5, [sp, #108]	@ 0x6c
  9c:	f8dc 300c 	ldr.w	r3, [ip, #12]
  a0:	f8d4 53d0 	ldr.w	r5, [r4, #976]	@ 0x3d0
  a4:	f8dc 2008 	ldr.w	r2, [ip, #8]
  a8:	951a      	str	r5, [sp, #104]	@ 0x68
  aa:	ad0e      	add	r5, sp, #56	@ 0x38
  ac:	9718      	str	r7, [sp, #96]	@ 0x60
  ae:	c50f      	stmia	r5!, {r0, r1, r2, r3}
  b0:	45b9      	cmp	r9, r7
  b2:	f8dc 0010 	ldr.w	r0, [ip, #16]
  b6:	f8dc 1014 	ldr.w	r1, [ip, #20]
  ba:	eb7b 030a 	sbcs.w	r3, fp, sl
  be:	c503      	stmia	r5!, {r0, r1}
  c0:	d255      	bcs.n	16e <Horizon_PropagateTo+0x16e>
  c2:	9b03      	ldr	r3, [sp, #12]
  c4:	9a04      	ldr	r2, [sp, #16]
  c6:	9302      	str	r3, [sp, #8]
  c8:	429f      	cmp	r7, r3
  ca:	4613      	mov	r3, r2
  cc:	eb7a 0303 	sbcs.w	r3, sl, r3
  d0:	4615      	mov	r5, r2
  d2:	a908      	add	r1, sp, #32
  d4:	f04f 0258 	mov.w	r2, #88	@ 0x58
  d8:	a81e      	add	r0, sp, #120	@ 0x78
  da:	bf3c      	itt	cc
  dc:	9702      	strcc	r7, [sp, #8]
  de:	4655      	movcc	r5, sl
  e0:	f7ff fffe 	bl	0 <memcpy>
			e0: R_ARM_THM_CALL	memcpy
  e4:	9b02      	ldr	r3, [sp, #8]
  e6:	455d      	cmp	r5, fp
  e8:	bf08      	it	eq
  ea:	454b      	cmpeq	r3, r9
  ec:	d03f      	beq.n	16e <Horizon_PropagateTo+0x16e>
  ee:	a808      	add	r0, sp, #32
  f0:	f7ff fffe 	bl	0 <Horizon_PropagateTo>
			f0: R_ARM_THM_CALL	Horizon_BodyValid
  f4:	2800      	cmp	r0, #0
  f6:	d075      	beq.n	1e4 <Horizon_PropagateTo+0x1e4>
  f8:	9a01      	ldr	r2, [sp, #4]
  fa:	4591      	cmp	r9, r2
  fc:	eb7b 0308 	sbcs.w	r3, fp, r8
 100:	d36a      	bcc.n	1d8 <Horizon_PropagateTo+0x1d8>
 102:	9b02      	ldr	r3, [sp, #8]
 104:	454b      	cmp	r3, r9
 106:	eb75 030b 	sbcs.w	r3, r5, fp
 10a:	d365      	bcc.n	1d8 <Horizon_PropagateTo+0x1d8>
 10c:	45d8      	cmp	r8, fp
 10e:	bf08      	it	eq
 110:	454a      	cmpeq	r2, r9
 112:	f000 80b7 	beq.w	284 <Horizon_PropagateTo+0x284>
 116:	9b01      	ldr	r3, [sp, #4]
 118:	9a06      	ldr	r2, [sp, #24]
 11a:	1aff      	subs	r7, r7, r3
 11c:	eb6a 0a08 	sbc.w	sl, sl, r8
 120:	087f      	lsrs	r7, r7, #1
 122:	e9d2 01f2 	ldrd	r0, r1, [r2, #968]	@ 0x3c8
 126:	ea47 77ca 	orr.w	r7, r7, sl, lsl #31
 12a:	9a02      	ldr	r2, [sp, #8]
 12c:	18ff      	adds	r7, r7, r3
 12e:	eb48 035a 	adc.w	r3, r8, sl, lsr #1
 132:	42ba      	cmp	r2, r7
 134:	eb75 0203 	sbcs.w	r2, r5, r3
 138:	bf3c      	itt	cc
 13a:	9f02      	ldrcc	r7, [sp, #8]
 13c:	462b      	movcc	r3, r5
 13e:	42b8      	cmp	r0, r7
 140:	eb71 0203 	sbcs.w	r2, r1, r3
 144:	f10d 0a20 	add.w	sl, sp, #32
 148:	f0c0 8099 	bcc.w	27e <Horizon_PropagateTo+0x27e>
 14c:	f10d 0a2c 	add.w	sl, sp, #44	@ 0x2c
 150:	e9dd 7318 	ldrd	r7, r3, [sp, #96]	@ 0x60
 154:	9a02      	ldr	r2, [sp, #8]
 156:	42ba      	cmp	r2, r7
 158:	eb75 0203 	sbcs.w	r2, r5, r3
 15c:	bf3c      	itt	cc
 15e:	9f02      	ldrcc	r7, [sp, #8]
 160:	462b      	movcc	r3, r5
 162:	42b8      	cmp	r0, r7
 164:	eb71 0203 	sbcs.w	r2, r1, r3
 168:	4681      	mov	r9, r0
 16a:	468b      	mov	fp, r1
 16c:	d340      	bcc.n	1f0 <Horizon_PropagateTo+0x1f0>
 16e:	3601      	adds	r6, #1
 170:	2ea0      	cmp	r6, #160	@ 0xa0
 172:	d02b      	beq.n	1cc <Horizon_PropagateTo+0x1cc>
 174:	9905      	ldr	r1, [sp, #20]
 176:	f8b1 261a 	ldrh.w	r2, [r1, #1562]	@ 0x61a
 17a:	b2b3      	uxth	r3, r6
 17c:	429a      	cmp	r2, r3
 17e:	d925      	bls.n	1cc <Horizon_PropagateTo+0x1cc>
 180:	e9dd 3203 	ldrd	r3, r2, [sp, #12]
 184:	455a      	cmp	r2, fp
 186:	bf08      	it	eq
 188:	454b      	cmpeq	r3, r9
 18a:	f000 809a 	beq.w	2c2 <Horizon_PropagateTo+0x2c2>
 18e:	f8b1 3618 	ldrh.w	r3, [r1, #1560]	@ 0x618
 192:	4a50      	ldr	r2, [pc, #320]	@ (2d4 <Horizon_PropagateTo+0x2d4>)
 194:	4433      	add	r3, r6
 196:	fba2 2503 	umull	r2, r5, r2, r3
 19a:	09ed      	lsrs	r5, r5, #7
 19c:	eb05 0585 	add.w	r5, r5, r5, lsl #2
 1a0:	eba3 1545 	sub.w	r5, r3, r5, lsl #5
 1a4:	2e00      	cmp	r6, #0
 1a6:	f43f af40 	beq.w	2a <Horizon_PropagateTo+0x2a>
 1aa:	4a4a      	ldr	r2, [pc, #296]	@ (2d4 <Horizon_PropagateTo+0x2d4>)
 1ac:	339f      	adds	r3, #159	@ 0x9f
 1ae:	fba2 1203 	umull	r1, r2, r2, r3
 1b2:	09d2      	lsrs	r2, r2, #7
 1b4:	eb02 0282 	add.w	r2, r2, r2, lsl #2
 1b8:	eba3 1342 	sub.w	r3, r3, r2, lsl #5
 1bc:	eb04 1383 	add.w	r3, r4, r3, lsl #6
 1c0:	f8d3 2bd0 	ldr.w	r2, [r3, #3024]	@ 0xbd0
 1c4:	f8d3 8bd4 	ldr.w	r8, [r3, #3028]	@ 0xbd4
 1c8:	9201      	str	r2, [sp, #4]
 1ca:	e736      	b.n	3a <Horizon_PropagateTo+0x3a>
 1cc:	e9dd 3203 	ldrd	r3, r2, [sp, #12]
 1d0:	455a      	cmp	r2, fp
 1d2:	bf08      	it	eq
 1d4:	454b      	cmpeq	r3, r9
 1d6:	d074      	beq.n	2c2 <Horizon_PropagateTo+0x2c2>
 1d8:	2009      	movs	r0, #9
 1da:	b035      	add	sp, #212	@ 0xd4
 1dc:	ecbd 8b02 	vpop	{d8}
 1e0:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 1e4:	200a      	movs	r0, #10
 1e6:	b035      	add	sp, #212	@ 0xd4
 1e8:	ecbd 8b02 	vpop	{d8}
 1ec:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 1f0:	f04f 0901 	mov.w	r9, #1
 1f4:	902c      	str	r0, [sp, #176]	@ 0xb0
 1f6:	1a38      	subs	r0, r7, r0
 1f8:	e9cd 172d 	strd	r1, r7, [sp, #180]	@ 0xb4
 1fc:	eb63 0101 	sbc.w	r1, r3, r1
 200:	932f      	str	r3, [sp, #188]	@ 0xbc
 202:	f7ff fffe 	bl	0 <__aeabi_ul2f>
			202: R_ARM_THM_CALL	__aeabi_ul2f
 206:	9a05      	ldr	r2, [sp, #20]
 208:	ee07 0a90 	vmov	s15, r0
 20c:	f8d2 8624 	ldr.w	r8, [r2, #1572]	@ 0x624
 210:	e89a 0007 	ldmia.w	sl, {r0, r1, r2}
 214:	f10a 0318 	add.w	r3, sl, #24
 218:	f10d 0b78 	add.w	fp, sp, #120	@ 0x78
 21c:	e88b 0007 	stmia.w	fp, {r0, r1, r2}
 220:	e893 0007 	ldmia.w	r3, {r0, r1, r2}
 224:	f10d 0e90 	add.w	lr, sp, #144	@ 0x90
 228:	e88e 0007 	stmia.w	lr, {r0, r1, r2}
 22c:	e89a 0007 	ldmia.w	sl, {r0, r1, r2}
 230:	f10d 0c84 	add.w	ip, sp, #132	@ 0x84
 234:	e88c 0007 	stmia.w	ip, {r0, r1, r2}
 238:	e893 0007 	ldmia.w	r3, {r0, r1, r2}
 23c:	ee67 7a88 	vmul.f32	s15, s15, s16
 240:	af27      	add	r7, sp, #156	@ 0x9c
 242:	f5b8 7f50 	cmp.w	r8, #832	@ 0x340
 246:	edcd 7a2a 	vstr	s15, [sp, #168]	@ 0xa8
 24a:	e887 0007 	stmia.w	r7, {r0, r1, r2}
 24e:	d236      	bcs.n	2be <Horizon_PropagateTo+0x2be>
 250:	9a05      	ldr	r2, [sp, #20]
 252:	f108 0301 	add.w	r3, r8, #1
 256:	f8c2 3624 	str.w	r3, [r2, #1572]	@ 0x624
 25a:	e9dd 0106 	ldrd	r0, r1, [sp, #24]
 25e:	465b      	mov	r3, fp
 260:	f504 623a 	add.w	r2, r4, #2976	@ 0xba0
 264:	f7ff fffe 	bl	0 <NavigationEskf_Predict>
			264: R_ARM_THM_CALL	NavigationEskf_Predict
 268:	2800      	cmp	r0, #0
 26a:	d1bb      	bne.n	1e4 <Horizon_PropagateTo+0x1e4>
 26c:	f1b9 0f00 	cmp.w	r9, #0
 270:	d129      	bne.n	2c6 <Horizon_PropagateTo+0x2c6>
 272:	9b06      	ldr	r3, [sp, #24]
 274:	f10a 0a0c 	add.w	sl, sl, #12
 278:	e9d3 01f2 	ldrd	r0, r1, [r3, #968]	@ 0x3c8
 27c:	e768      	b.n	150 <Horizon_PropagateTo+0x150>
 27e:	f04f 0900 	mov.w	r9, #0
 282:	e7b7      	b.n	1f4 <Horizon_PropagateTo+0x1f4>
 284:	9b03      	ldr	r3, [sp, #12]
 286:	42bb      	cmp	r3, r7
 288:	9b04      	ldr	r3, [sp, #16]
 28a:	eb73 030a 	sbcs.w	r3, r3, sl
 28e:	f4ff af42 	bcc.w	116 <Horizon_PropagateTo+0x116>
 292:	9a05      	ldr	r2, [sp, #20]
 294:	f8d2 3624 	ldr.w	r3, [r2, #1572]	@ 0x624
 298:	f5b3 7f50 	cmp.w	r3, #832	@ 0x340
 29c:	d20f      	bcs.n	2be <Horizon_PropagateTo+0x2be>
 29e:	e9dd 5106 	ldrd	r5, r1, [sp, #24]
 2a2:	3301      	adds	r3, #1
 2a4:	f8c2 3624 	str.w	r3, [r2, #1572]	@ 0x624
 2a8:	4628      	mov	r0, r5
 2aa:	ab08      	add	r3, sp, #32
 2ac:	f504 623a 	add.w	r2, r4, #2976	@ 0xba0
 2b0:	f7ff fffe 	bl	0 <NavigationEskf_Predict>
			2b0: R_ARM_THM_CALL	NavigationEskf_Predict
 2b4:	2800      	cmp	r0, #0
 2b6:	d195      	bne.n	1e4 <Horizon_PropagateTo+0x1e4>
 2b8:	e9d5 9bf2 	ldrd	r9, fp, [r5, #968]	@ 0x3c8
 2bc:	e757      	b.n	16e <Horizon_PropagateTo+0x16e>
 2be:	2006      	movs	r0, #6
 2c0:	e78b      	b.n	1da <Horizon_PropagateTo+0x1da>
 2c2:	2000      	movs	r0, #0
 2c4:	e789      	b.n	1da <Horizon_PropagateTo+0x1da>
 2c6:	9b06      	ldr	r3, [sp, #24]
 2c8:	e9d3 9bf2 	ldrd	r9, fp, [r3, #968]	@ 0x3c8
 2cc:	e74f      	b.n	16e <Horizon_PropagateTo+0x16e>
 2ce:	bf00      	nop
 2d0:	358637bd 	.word	0x358637bd
 2d4:	cccccccd 	.word	0xcccccccd

Disassembly of section .text.Horizon_Advance.part.0:

00000000 <Horizon_Advance.part.0>:
   0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
   4:	ed2d 8b02 	vpush	{d8}
   8:	b0c9      	sub	sp, #292	@ 0x124
   a:	4288      	cmp	r0, r1
   c:	4680      	mov	r8, r0
   e:	9105      	str	r1, [sp, #20]
  10:	4691      	mov	r9, r2
  12:	461c      	mov	r4, r3
  14:	f200 80d1 	bhi.w	1ba <Horizon_Advance.part.0+0x1ba>
  18:	1a0b      	subs	r3, r1, r0
  1a:	f245 6257 	movw	r2, #22103	@ 0x5657
  1e:	4293      	cmp	r3, r2
  20:	bf8c      	ite	hi
  22:	2300      	movhi	r3, #0
  24:	2301      	movls	r3, #1
  26:	2b00      	cmp	r3, #0
  28:	f040 80c1 	bne.w	1ae <Horizon_Advance.part.0+0x1ae>
  2c:	45c8      	cmp	r8, r9
  2e:	bf95      	itete	ls
  30:	eba9 0308 	subls.w	r3, r9, r8
  34:	eba8 0309 	subhi.w	r3, r8, r9
  38:	f245 6257 	movwls	r2, #22103	@ 0x5657
  3c:	f640 4243 	movwhi	r2, #3139	@ 0xc43
  40:	4293      	cmp	r3, r2
  42:	bf8c      	ite	hi
  44:	2300      	movhi	r3, #0
  46:	2301      	movls	r3, #1
  48:	2b00      	cmp	r3, #0
  4a:	f040 80b0 	bne.w	1ae <Horizon_Advance.part.0+0x1ae>
  4e:	45a0      	cmp	r8, r4
  50:	f200 80bb 	bhi.w	1ca <Horizon_Advance.part.0+0x1ca>
  54:	eba4 0308 	sub.w	r3, r4, r8
  58:	f245 6257 	movw	r2, #22103	@ 0x5657
  5c:	4293      	cmp	r3, r2
  5e:	bf8c      	ite	hi
  60:	2300      	movhi	r3, #0
  62:	2301      	movls	r3, #1
  64:	2b00      	cmp	r3, #0
  66:	f040 80a2 	bne.w	1ae <Horizon_Advance.part.0+0x1ae>
  6a:	9b05      	ldr	r3, [sp, #20]
  6c:	454b      	cmp	r3, r9
  6e:	f0c0 80b3 	bcc.w	1d8 <Horizon_Advance.part.0+0x1d8>
  72:	eba3 0309 	sub.w	r3, r3, r9
  76:	f640 4243 	movw	r2, #3139	@ 0xc43
  7a:	4293      	cmp	r3, r2
  7c:	bf8c      	ite	hi
  7e:	2300      	movhi	r3, #0
  80:	2301      	movls	r3, #1
  82:	2b00      	cmp	r3, #0
  84:	f040 8093 	bne.w	1ae <Horizon_Advance.part.0+0x1ae>
  88:	9b05      	ldr	r3, [sp, #20]
  8a:	42a3      	cmp	r3, r4
  8c:	f200 80ad 	bhi.w	1ea <Horizon_Advance.part.0+0x1ea>
  90:	1ae3      	subs	r3, r4, r3
  92:	f5b3 7f78 	cmp.w	r3, #992	@ 0x3e0
  96:	bf2c      	ite	cs
  98:	2300      	movcs	r3, #0
  9a:	2301      	movcc	r3, #1
  9c:	2b00      	cmp	r3, #0
  9e:	f040 8086 	bne.w	1ae <Horizon_Advance.part.0+0x1ae>
  a2:	45a1      	cmp	r9, r4
  a4:	f200 80a8 	bhi.w	1f8 <Horizon_Advance.part.0+0x1f8>
  a8:	eba4 0309 	sub.w	r3, r4, r9
  ac:	f640 4243 	movw	r2, #3139	@ 0xc43
  b0:	4293      	cmp	r3, r2
  b2:	bf8c      	ite	hi
  b4:	2300      	movhi	r3, #0
  b6:	2301      	movls	r3, #1
  b8:	2b00      	cmp	r3, #0
  ba:	d178      	bne.n	1ae <Horizon_Advance.part.0+0x1ae>
  bc:	f508 4ba0 	add.w	fp, r8, #20480	@ 0x5000
  c0:	f8bb 361e 	ldrh.w	r3, [fp, #1566]	@ 0x61e
  c4:	2b00      	cmp	r3, #0
  c6:	f040 83e3 	bne.w	890 <Horizon_Advance.part.0+0x890>
  ca:	f89b 3651 	ldrb.w	r3, [fp, #1617]	@ 0x651
  ce:	2b00      	cmp	r3, #0
  d0:	f000 8099 	beq.w	206 <Horizon_Advance.part.0+0x206>
  d4:	4620      	mov	r0, r4
  d6:	f7ff fffe 	bl	0 <NavigationEskf_ConfigValidate>
			d6: R_ARM_THM_CALL	NavigationEskf_ConfigValidate
  da:	2800      	cmp	r0, #0
  dc:	d162      	bne.n	1a4 <Horizon_Advance.part.0+0x1a4>
  de:	f508 633a 	add.w	r3, r8, #2976	@ 0xba0
  e2:	ed94 7a00 	vldr	s14, [r4]
  e6:	edd3 7a00 	vldr	s15, [r3]
  ea:	9315      	str	r3, [sp, #84]	@ 0x54
  ec:	eeb4 7a67 	vcmp.f32	s14, s15
  f0:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  f4:	d156      	bne.n	1a4 <Horizon_Advance.part.0+0x1a4>
  f6:	ed94 7a01 	vldr	s14, [r4, #4]
  fa:	edd3 7a01 	vldr	s15, [r3, #4]
  fe:	eeb4 7a67 	vcmp.f32	s14, s15
 102:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 106:	d14d      	bne.n	1a4 <Horizon_Advance.part.0+0x1a4>
 108:	ed94 7a02 	vldr	s14, [r4, #8]
 10c:	edd3 7a02 	vldr	s15, [r3, #8]
 110:	eeb4 7a67 	vcmp.f32	s14, s15
 114:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 118:	d144      	bne.n	1a4 <Horizon_Advance.part.0+0x1a4>
 11a:	ed94 7a03 	vldr	s14, [r4, #12]
 11e:	edd3 7a03 	vldr	s15, [r3, #12]
 122:	eeb4 7a67 	vcmp.f32	s14, s15
 126:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 12a:	d13b      	bne.n	1a4 <Horizon_Advance.part.0+0x1a4>
 12c:	ed94 7a04 	vldr	s14, [r4, #16]
 130:	edd3 7a04 	vldr	s15, [r3, #16]
 134:	eeb4 7a67 	vcmp.f32	s14, s15
 138:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 13c:	d132      	bne.n	1a4 <Horizon_Advance.part.0+0x1a4>
 13e:	ed94 7a05 	vldr	s14, [r4, #20]
 142:	edd3 7a05 	vldr	s15, [r3, #20]
 146:	eeb4 7a67 	vcmp.f32	s14, s15
 14a:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 14e:	d129      	bne.n	1a4 <Horizon_Advance.part.0+0x1a4>
 150:	ed94 7a06 	vldr	s14, [r4, #24]
 154:	edd3 7a06 	vldr	s15, [r3, #24]
 158:	eeb4 7a67 	vcmp.f32	s14, s15
 15c:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 160:	d120      	bne.n	1a4 <Horizon_Advance.part.0+0x1a4>
 162:	ed94 7a07 	vldr	s14, [r4, #28]
 166:	edd3 7a07 	vldr	s15, [r3, #28]
 16a:	eeb4 7a67 	vcmp.f32	s14, s15
 16e:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 172:	d117      	bne.n	1a4 <Horizon_Advance.part.0+0x1a4>
 174:	ed94 7a08 	vldr	s14, [r4, #32]
 178:	edd3 7a08 	vldr	s15, [r3, #32]
 17c:	eeb4 7a67 	vcmp.f32	s14, s15
 180:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 184:	d10e      	bne.n	1a4 <Horizon_Advance.part.0+0x1a4>
 186:	ed94 7a09 	vldr	s14, [r4, #36]	@ 0x24
 18a:	edd3 7a09 	vldr	s15, [r3, #36]	@ 0x24
 18e:	eeb4 7a67 	vcmp.f32	s14, s15
 192:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 196:	d105      	bne.n	1a4 <Horizon_Advance.part.0+0x1a4>
 198:	f894 2028 	ldrb.w	r2, [r4, #40]	@ 0x28
 19c:	f898 3bc8 	ldrb.w	r3, [r8, #3016]	@ 0xbc8
 1a0:	429a      	cmp	r2, r3
 1a2:	d032      	beq.n	20a <Horizon_Advance.part.0+0x20a>
 1a4:	2301      	movs	r3, #1
 1a6:	f88b 3653 	strb.w	r3, [fp, #1619]	@ 0x653
 1aa:	2008      	movs	r0, #8
 1ac:	e000      	b.n	1b0 <Horizon_Advance.part.0+0x1b0>
 1ae:	2003      	movs	r0, #3
 1b0:	b049      	add	sp, #292	@ 0x124
 1b2:	ecbd 8b02 	vpop	{d8}
 1b6:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 1ba:	9b05      	ldr	r3, [sp, #20]
 1bc:	1ac3      	subs	r3, r0, r3
 1be:	f5b3 7f78 	cmp.w	r3, #992	@ 0x3e0
 1c2:	bf2c      	ite	cs
 1c4:	2300      	movcs	r3, #0
 1c6:	2301      	movcc	r3, #1
 1c8:	e72d      	b.n	26 <Horizon_Advance.part.0+0x26>
 1ca:	eba8 0304 	sub.w	r3, r8, r4
 1ce:	2b2b      	cmp	r3, #43	@ 0x2b
 1d0:	bf8c      	ite	hi
 1d2:	2300      	movhi	r3, #0
 1d4:	2301      	movls	r3, #1
 1d6:	e745      	b.n	64 <Horizon_Advance.part.0+0x64>
 1d8:	9b05      	ldr	r3, [sp, #20]
 1da:	eba9 0303 	sub.w	r3, r9, r3
 1de:	f5b3 7f78 	cmp.w	r3, #992	@ 0x3e0
 1e2:	bf2c      	ite	cs
 1e4:	2300      	movcs	r3, #0
 1e6:	2301      	movcc	r3, #1
 1e8:	e74b      	b.n	82 <Horizon_Advance.part.0+0x82>
 1ea:	9b05      	ldr	r3, [sp, #20]
 1ec:	1b1b      	subs	r3, r3, r4
 1ee:	2b2b      	cmp	r3, #43	@ 0x2b
 1f0:	bf8c      	ite	hi
 1f2:	2300      	movhi	r3, #0
 1f4:	2301      	movls	r3, #1
 1f6:	e751      	b.n	9c <Horizon_Advance.part.0+0x9c>
 1f8:	eba9 0304 	sub.w	r3, r9, r4
 1fc:	2b2b      	cmp	r3, #43	@ 0x2b
 1fe:	bf8c      	ite	hi
 200:	2300      	movhi	r3, #0
 202:	2301      	movls	r3, #1
 204:	e758      	b.n	b8 <Horizon_Advance.part.0+0xb8>
 206:	200c      	movs	r0, #12
 208:	e7d2      	b.n	1b0 <Horizon_Advance.part.0+0x1b0>
 20a:	f508 41ac 	add.w	r1, r8, #22016	@ 0x5600
 20e:	f245 6310 	movw	r3, #22032	@ 0x5610
 212:	f851 0c08 	ldr.w	r0, [r1, #-8]
 216:	f8d1 a000 	ldr.w	sl, [r1]
 21a:	f858 2003 	ldr.w	r2, [r8, r3]
 21e:	f8d1 c004 	ldr.w	ip, [r1, #4]
 222:	9116      	str	r1, [sp, #88]	@ 0x58
 224:	eb08 0403 	add.w	r4, r8, r3
 228:	f851 3c04 	ldr.w	r3, [r1, #-4]
 22c:	900f      	str	r0, [sp, #60]	@ 0x3c
 22e:	6861      	ldr	r1, [r4, #4]
 230:	9310      	str	r3, [sp, #64]	@ 0x40
 232:	ebba 0000 	subs.w	r0, sl, r0
 236:	eb6c 0303 	sbc.w	r3, ip, r3
 23a:	4290      	cmp	r0, r2
 23c:	418b      	sbcs	r3, r1
 23e:	940a      	str	r4, [sp, #40]	@ 0x28
 240:	d305      	bcc.n	24e <Horizon_Advance.part.0+0x24e>
 242:	ebba 0302 	subs.w	r3, sl, r2
 246:	930f      	str	r3, [sp, #60]	@ 0x3c
 248:	eb6c 0301 	sbc.w	r3, ip, r1
 24c:	9310      	str	r3, [sp, #64]	@ 0x40
 24e:	2700      	movs	r7, #0
 250:	f88b 7655 	strb.w	r7, [fp, #1621]	@ 0x655
 254:	f8cb 7624 	str.w	r7, [fp, #1572]	@ 0x624
 258:	f8d8 07cc 	ldr.w	r0, [r8, #1996]	@ 0x7cc
 25c:	f8d8 17d0 	ldr.w	r1, [r8, #2000]	@ 0x7d0
 260:	f8d8 27d4 	ldr.w	r2, [r8, #2004]	@ 0x7d4
 264:	ed9f 8ac6 	vldr	s16, [pc, #792]	@ 580 <Horizon_Advance.part.0+0x580>
 268:	f8bb 661a 	ldrh.w	r6, [fp, #1562]	@ 0x61a
 26c:	f508 44ac 	add.w	r4, r8, #22016	@ 0x5600
 270:	ab30      	add	r3, sp, #192	@ 0xc0
 272:	c307      	stmia	r3!, {r0, r1, r2}
 274:	f245 6344 	movw	r3, #22084	@ 0x5644
 278:	6ce2      	ldr	r2, [r4, #76]	@ 0x4c
 27a:	f858 0003 	ldr.w	r0, [r8, r3]
 27e:	6ca1      	ldr	r1, [r4, #72]	@ 0x48
 280:	3444      	adds	r4, #68	@ 0x44
 282:	ab19      	add	r3, sp, #100	@ 0x64
 284:	c307      	stmia	r3!, {r0, r1, r2}
 286:	9417      	str	r4, [sp, #92]	@ 0x5c
 288:	f208 75cc 	addw	r5, r8, #1996	@ 0x7cc
 28c:	4cbd      	ldr	r4, [pc, #756]	@ (584 <Horizon_Advance.part.0+0x584>)
 28e:	f8d8 2b88 	ldr.w	r2, [r8, #2952]	@ 0xb88
 292:	f8d8 3b8c 	ldr.w	r3, [r8, #2956]	@ 0xb8c
 296:	9506      	str	r5, [sp, #24]
 298:	42b7      	cmp	r7, r6
 29a:	d028      	beq.n	2ee <Horizon_Advance.part.0+0x2ee>
 29c:	f8bb 1618 	ldrh.w	r1, [fp, #1560]	@ 0x618
 2a0:	4439      	add	r1, r7
 2a2:	fba4 0501 	umull	r0, r5, r4, r1
 2a6:	09ed      	lsrs	r5, r5, #7
 2a8:	eb05 0585 	add.w	r5, r5, r5, lsl #2
 2ac:	eba1 1545 	sub.w	r5, r1, r5, lsl #5
 2b0:	eb08 1e85 	add.w	lr, r8, r5, lsl #6
 2b4:	4675      	mov	r5, lr
 2b6:	2f00      	cmp	r7, #0
 2b8:	f040 81d1 	bne.w	65e <Horizon_Advance.part.0+0x65e>
 2bc:	f8de 0bd0 	ldr.w	r0, [lr, #3024]	@ 0xbd0
 2c0:	f8de 1bd4 	ldr.w	r1, [lr, #3028]	@ 0xbd4
 2c4:	4282      	cmp	r2, r0
 2c6:	eb73 0101 	sbcs.w	r1, r3, r1
 2ca:	f60e 4e08 	addw	lr, lr, #3080	@ 0xc08
 2ce:	f080 81f5 	bcs.w	6bc <Horizon_Advance.part.0+0x6bc>
 2d2:	990a      	ldr	r1, [sp, #40]	@ 0x28
 2d4:	e951 0102 	ldrd	r0, r1, [r1, #-8]
 2d8:	4290      	cmp	r0, r2
 2da:	4199      	sbcs	r1, r3
 2dc:	f0c0 81e9 	bcc.w	6b2 <Horizon_Advance.part.0+0x6b2>
 2e0:	edde 7a00 	vldr	s15, [lr]
 2e4:	2701      	movs	r7, #1
 2e6:	42b7      	cmp	r7, r6
 2e8:	ee38 8a27 	vadd.f32	s16, s16, s15
 2ec:	d1d6      	bne.n	29c <Horizon_Advance.part.0+0x29c>
 2ee:	459c      	cmp	ip, r3
 2f0:	bf08      	it	eq
 2f2:	4592      	cmpeq	sl, r2
 2f4:	9d06      	ldr	r5, [sp, #24]
 2f6:	d02b      	beq.n	350 <Horizon_Advance.part.0+0x350>
 2f8:	eddf 7aa3 	vldr	s15, [pc, #652]	@ 588 <Horizon_Advance.part.0+0x588>
 2fc:	eeb0 7ac8 	vabs.f32	s14, s16
 300:	eeb4 7a67 	vcmp.f32	s14, s15
 304:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 308:	f200 81a4 	bhi.w	654 <Horizon_Advance.part.0+0x654>
 30c:	eeb5 8ac0 	vcmpe.f32	s16, #0.0
 310:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 314:	f240 819e 	bls.w	654 <Horizon_Advance.part.0+0x654>
 318:	e9cd ac00 	strd	sl, ip, [sp]
 31c:	464a      	mov	r2, r9
 31e:	f508 61f8 	add.w	r1, r8, #1984	@ 0x7c0
 322:	4640      	mov	r0, r8
 324:	f7ff fffe 	bl	0 <Horizon_Advance.part.0>
			324: R_ARM_THM_CALL	Horizon_PropagateTo
 328:	2800      	cmp	r0, #0
 32a:	f040 8194 	bne.w	656 <Horizon_Advance.part.0+0x656>
 32e:	462b      	mov	r3, r5
 330:	a930      	add	r1, sp, #192	@ 0xc0
 332:	aa19      	add	r2, sp, #100	@ 0x64
 334:	f508 60fb 	add.w	r0, r8, #2008	@ 0x7d8
 338:	ecf3 7a01 	vldmia	r3!, {s15}
 33c:	ecb1 7a01 	vldmia	r1!, {s14}
 340:	ee77 7ac7 	vsub.f32	s15, s15, s14
 344:	4283      	cmp	r3, r0
 346:	ee87 7a88 	vdiv.f32	s14, s15, s16
 34a:	eca2 7a01 	vstmia	r2!, {s14}
 34e:	d1f3      	bne.n	338 <Horizon_Advance.part.0+0x338>
 350:	eddd 7a19 	vldr	s15, [sp, #100]	@ 0x64
 354:	ed9f 7a8c 	vldr	s14, [pc, #560]	@ 588 <Horizon_Advance.part.0+0x588>
 358:	eef0 7ae7 	vabs.f32	s15, s15
 35c:	eef4 7a47 	vcmp.f32	s15, s14
 360:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 364:	f200 8176 	bhi.w	654 <Horizon_Advance.part.0+0x654>
 368:	eddd 7a1a 	vldr	s15, [sp, #104]	@ 0x68
 36c:	eef0 7ae7 	vabs.f32	s15, s15
 370:	eef4 7a47 	vcmp.f32	s15, s14
 374:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 378:	f200 816c 	bhi.w	654 <Horizon_Advance.part.0+0x654>
 37c:	eddd 7a1b 	vldr	s15, [sp, #108]	@ 0x6c
 380:	eef0 7ae7 	vabs.f32	s15, s15
 384:	eef4 7a47 	vcmp.f32	s15, s14
 388:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 38c:	f200 8162 	bhi.w	654 <Horizon_Advance.part.0+0x654>
 390:	f508 7378 	add.w	r3, r8, #992	@ 0x3e0
 394:	4618      	mov	r0, r3
 396:	f44f 7278 	mov.w	r2, #992	@ 0x3e0
 39a:	4641      	mov	r1, r8
 39c:	930b      	str	r3, [sp, #44]	@ 0x2c
 39e:	f7ff fffe 	bl	0 <memcpy>
			39e: R_ARM_THM_CALL	memcpy
 3a2:	9b54      	ldr	r3, [sp, #336]	@ 0x150
 3a4:	b13b      	cbz	r3, 3b6 <Horizon_Advance.part.0+0x3b6>
 3a6:	9b54      	ldr	r3, [sp, #336]	@ 0x150
 3a8:	2270      	movs	r2, #112	@ 0x70
 3aa:	f103 01a0 	add.w	r1, r3, #160	@ 0xa0
 3ae:	f503 7088 	add.w	r0, r3, #272	@ 0x110
 3b2:	f7ff fffe 	bl	0 <memcpy>
			3b2: R_ARM_THM_CALL	memcpy
 3b6:	f508 5650 	add.w	r6, r8, #13312	@ 0x3400
 3ba:	2300      	movs	r3, #0
 3bc:	9c54      	ldr	r4, [sp, #336]	@ 0x150
 3be:	f8cd 9030 	str.w	r9, [sp, #48]	@ 0x30
 3c2:	3638      	adds	r6, #56	@ 0x38
 3c4:	4699      	mov	r9, r3
 3c6:	f8bb 361c 	ldrh.w	r3, [fp, #1564]	@ 0x61c
 3ca:	fa1f f189 	uxth.w	r1, r9
 3ce:	428b      	cmp	r3, r1
 3d0:	f240 8265 	bls.w	89e <Horizon_Advance.part.0+0x89e>
 3d4:	e956 231a 	ldrd	r2, r3, [r6, #-104]	@ 0x68
 3d8:	980f      	ldr	r0, [sp, #60]	@ 0x3c
 3da:	4290      	cmp	r0, r2
 3dc:	9810      	ldr	r0, [sp, #64]	@ 0x40
 3de:	4198      	sbcs	r0, r3
 3e0:	f0c0 825d 	bcc.w	89e <Horizon_Advance.part.0+0x89e>
 3e4:	e9cd 2300 	strd	r2, r3, [sp]
 3e8:	f856 3c18 	ldr.w	r3, [r6, #-24]
 3ec:	f8cb 3634 	str.w	r3, [fp, #1588]	@ 0x634
 3f0:	f04f 0301 	mov.w	r3, #1
 3f4:	e9dd 120b 	ldrd	r1, r2, [sp, #44]	@ 0x2c
 3f8:	f88b 3655 	strb.w	r3, [fp, #1621]	@ 0x655
 3fc:	4640      	mov	r0, r8
 3fe:	f7ff fffe 	bl	0 <Horizon_Advance.part.0>
			3fe: R_ARM_THM_CALL	Horizon_PropagateTo
 402:	4686      	mov	lr, r0
 404:	2800      	cmp	r0, #0
 406:	f040 8126 	bne.w	656 <Horizon_Advance.part.0+0x656>
 40a:	f1a6 074c 	sub.w	r7, r6, #76	@ 0x4c
 40e:	cf0f      	ldmia	r7!, {r0, r1, r2, r3}
 410:	ad25      	add	r5, sp, #148	@ 0x94
 412:	c50f      	stmia	r5!, {r0, r1, r2, r3}
 414:	cf0f      	ldmia	r7!, {r0, r1, r2, r3}
 416:	c50f      	stmia	r5!, {r0, r1, r2, r3}
 418:	e897 0007 	ldmia.w	r7, {r0, r1, r2}
 41c:	f89d c094 	ldrb.w	ip, [sp, #148]	@ 0x94
 420:	f1bc 0f04 	cmp.w	ip, #4
 424:	e885 0007 	stmia.w	r5, {r0, r1, r2}
 428:	f000 814a 	beq.w	6c0 <Horizon_Advance.part.0+0x6c0>
 42c:	9b0a      	ldr	r3, [sp, #40]	@ 0x28
 42e:	e956 011a 	ldrd	r0, r1, [r6, #-104]	@ 0x68
 432:	f853 2c08 	ldr.w	r2, [r3, #-8]
 436:	f853 3c04 	ldr.w	r3, [r3, #-4]
 43a:	920d      	str	r2, [sp, #52]	@ 0x34
 43c:	4299      	cmp	r1, r3
 43e:	bf08      	it	eq
 440:	4290      	cmpeq	r0, r2
 442:	930e      	str	r3, [sp, #56]	@ 0x38
 444:	f000 8212 	beq.w	86c <Horizon_Advance.part.0+0x86c>
 448:	e9cd 4911 	strd	r4, r9, [sp, #68]	@ 0x44
 44c:	e9cd 6c13 	strd	r6, ip, [sp, #76]	@ 0x4c
 450:	e9cd 0107 	strd	r0, r1, [sp, #28]
 454:	f8bb 361a 	ldrh.w	r3, [fp, #1562]	@ 0x61a
 458:	9309      	str	r3, [sp, #36]	@ 0x24
 45a:	2700      	movs	r7, #0
 45c:	f8cd b018 	str.w	fp, [sp, #24]
 460:	9b09      	ldr	r3, [sp, #36]	@ 0x24
 462:	42bb      	cmp	r3, r7
 464:	f000 8123 	beq.w	6ae <Horizon_Advance.part.0+0x6ae>
 468:	9b06      	ldr	r3, [sp, #24]
 46a:	4c46      	ldr	r4, [pc, #280]	@ (584 <Horizon_Advance.part.0+0x584>)
 46c:	f8b3 2618 	ldrh.w	r2, [r3, #1560]	@ 0x618
 470:	443a      	add	r2, r7
 472:	f102 039f 	add.w	r3, r2, #159	@ 0x9f
 476:	fba4 0103 	umull	r0, r1, r4, r3
 47a:	09c9      	lsrs	r1, r1, #7
 47c:	eb01 0181 	add.w	r1, r1, r1, lsl #2
 480:	eba3 1341 	sub.w	r3, r3, r1, lsl #5
 484:	fba4 1402 	umull	r1, r4, r4, r2
 488:	09e4      	lsrs	r4, r4, #7
 48a:	eb04 0484 	add.w	r4, r4, r4, lsl #2
 48e:	eb08 1383 	add.w	r3, r8, r3, lsl #6
 492:	eba2 1444 	sub.w	r4, r2, r4, lsl #5
 496:	2f00      	cmp	r7, #0
 498:	f000 810d 	beq.w	6b6 <Horizon_Advance.part.0+0x6b6>
 49c:	f8d3 5bd0 	ldr.w	r5, [r3, #3024]	@ 0xbd0
 4a0:	f8d3 9bd4 	ldr.w	r9, [r3, #3028]	@ 0xbd4
 4a4:	ea4f 1c84 	mov.w	ip, r4, lsl #6
 4a8:	f60c 33d8 	addw	r3, ip, #3032	@ 0xbd8
 4ac:	eb08 1484 	add.w	r4, r8, r4, lsl #6
 4b0:	eb08 0e03 	add.w	lr, r8, r3
 4b4:	f858 0003 	ldr.w	r0, [r8, r3]
 4b8:	f8d4 bbd0 	ldr.w	fp, [r4, #3024]	@ 0xbd0
 4bc:	f8d4 abd4 	ldr.w	sl, [r4, #3028]	@ 0xbd4
 4c0:	f8de 1004 	ldr.w	r1, [lr, #4]
 4c4:	f8de 2008 	ldr.w	r2, [lr, #8]
 4c8:	f8cd b100 	str.w	fp, [sp, #256]	@ 0x100
 4cc:	f604 4308 	addw	r3, r4, #3080	@ 0xc08
 4d0:	f8d4 4c0c 	ldr.w	r4, [r4, #3084]	@ 0xc0c
 4d4:	9444      	str	r4, [sp, #272]	@ 0x110
 4d6:	681b      	ldr	r3, [r3, #0]
 4d8:	f8d8 43d4 	ldr.w	r4, [r8, #980]	@ 0x3d4
 4dc:	933c      	str	r3, [sp, #240]	@ 0xf0
 4de:	9443      	str	r4, [sp, #268]	@ 0x10c
 4e0:	f8de 300c 	ldr.w	r3, [lr, #12]
 4e4:	f8d8 43d0 	ldr.w	r4, [r8, #976]	@ 0x3d0
 4e8:	9442      	str	r4, [sp, #264]	@ 0x108
 4ea:	ac30      	add	r4, sp, #192	@ 0xc0
 4ec:	e9cd 593e 	strd	r5, r9, [sp, #248]	@ 0xf8
 4f0:	f8cd a104 	str.w	sl, [sp, #260]	@ 0x104
 4f4:	c40f      	stmia	r4!, {r0, r1, r2, r3}
 4f6:	f50c 6c3f 	add.w	ip, ip, #3056	@ 0xbf0
 4fa:	f8de 0010 	ldr.w	r0, [lr, #16]
 4fe:	f8de 1014 	ldr.w	r1, [lr, #20]
 502:	eb08 060c 	add.w	r6, r8, ip
 506:	c403      	stmia	r4!, {r0, r1}
 508:	68b2      	ldr	r2, [r6, #8]
 50a:	f858 000c 	ldr.w	r0, [r8, ip]
 50e:	6871      	ldr	r1, [r6, #4]
 510:	68f3      	ldr	r3, [r6, #12]
 512:	c40f      	stmia	r4!, {r0, r1, r2, r3}
 514:	6971      	ldr	r1, [r6, #20]
 516:	6930      	ldr	r0, [r6, #16]
 518:	9a07      	ldr	r2, [sp, #28]
 51a:	c403      	stmia	r4!, {r0, r1}
 51c:	9908      	ldr	r1, [sp, #32]
 51e:	42aa      	cmp	r2, r5
 520:	eb71 0309 	sbcs.w	r3, r1, r9
 524:	f107 0701 	add.w	r7, r7, #1
 528:	f0c0 80be 	bcc.w	6a8 <Horizon_Advance.part.0+0x6a8>
 52c:	4593      	cmp	fp, r2
 52e:	eb7a 0301 	sbcs.w	r3, sl, r1
 532:	f0c0 80b9 	bcc.w	6a8 <Horizon_Advance.part.0+0x6a8>
 536:	462a      	mov	r2, r5
 538:	465d      	mov	r5, fp
 53a:	1aad      	subs	r5, r5, r2
 53c:	464b      	mov	r3, r9
 53e:	e9dd 0107 	ldrd	r0, r1, [sp, #28]
 542:	eb6a 0a03 	sbc.w	sl, sl, r3
 546:	086d      	lsrs	r5, r5, #1
 548:	ea45 75ca 	orr.w	r5, r5, sl, lsl #31
 54c:	18ad      	adds	r5, r5, r2
 54e:	eb43 035a 	adc.w	r3, r3, sl, lsr #1
 552:	4285      	cmp	r5, r0
 554:	418b      	sbcs	r3, r1
 556:	bf34      	ite	cc
 558:	230c      	movcc	r3, #12
 55a:	2300      	movcs	r3, #0
 55c:	f503 7390 	add.w	r3, r3, #288	@ 0x120
 560:	446b      	add	r3, sp
 562:	3b60      	subs	r3, #96	@ 0x60
 564:	e893 0007 	ldmia.w	r3, {r0, r1, r2}
 568:	ad2d      	add	r5, sp, #180	@ 0xb4
 56a:	e885 0007 	stmia.w	r5, {r0, r1, r2}
 56e:	e9dd 6c13 	ldrd	r6, ip, [sp, #76]	@ 0x4c
 572:	9c11      	ldr	r4, [sp, #68]	@ 0x44
 574:	f8dd 9048 	ldr.w	r9, [sp, #72]	@ 0x48
 578:	f8dd b018 	ldr.w	fp, [sp, #24]
 57c:	e006      	b.n	58c <Horizon_Advance.part.0+0x58c>
 57e:	bf00      	nop
 580:	00000000 	.word	0x00000000
 584:	cccccccd 	.word	0xcccccccd
 588:	7f7fffff 	.word	0x7f7fffff
 58c:	f8db 3624 	ldr.w	r3, [fp, #1572]	@ 0x624
 590:	f5b3 7f50 	cmp.w	r3, #832	@ 0x340
 594:	f080 817a 	bcs.w	88c <Horizon_Advance.part.0+0x88c>
 598:	3301      	adds	r3, #1
 59a:	f8cb 3624 	str.w	r3, [fp, #1572]	@ 0x624
 59e:	9b54      	ldr	r3, [sp, #336]	@ 0x150
 5a0:	2b00      	cmp	r3, #0
 5a2:	f000 809a 	beq.w	6da <Horizon_Advance.part.0+0x6da>
 5a6:	f1bc 0f03 	cmp.w	ip, #3
 5aa:	f200 8096 	bhi.w	6da <Horizon_Advance.part.0+0x6da>
 5ae:	f856 3c58 	ldr.w	r3, [r6, #-88]
 5b2:	9333      	str	r3, [sp, #204]	@ 0xcc
 5b4:	f856 3c50 	ldr.w	r3, [r6, #-80]
 5b8:	9334      	str	r3, [sp, #208]	@ 0xd0
 5ba:	f856 3c54 	ldr.w	r3, [r6, #-84]
 5be:	9332      	str	r3, [sp, #200]	@ 0xc8
 5c0:	9b54      	ldr	r3, [sp, #336]	@ 0x150
 5c2:	f8d3 30ec 	ldr.w	r3, [r3, #236]	@ 0xec
 5c6:	9335      	str	r3, [sp, #212]	@ 0xd4
 5c8:	e956 2318 	ldrd	r2, r3, [r6, #-96]	@ 0x60
 5cc:	ad25      	add	r5, sp, #148	@ 0x94
 5ce:	e9cd 2330 	strd	r2, r3, [sp, #192]	@ 0xc0
 5d2:	cd0f      	ldmia	r5!, {r0, r1, r2, r3}
 5d4:	af36      	add	r7, sp, #216	@ 0xd8
 5d6:	c70f      	stmia	r7!, {r0, r1, r2, r3}
 5d8:	cd0f      	ldmia	r5!, {r0, r1, r2, r3}
 5da:	c70f      	stmia	r7!, {r0, r1, r2, r3}
 5dc:	e895 0007 	ldmia.w	r5, {r0, r1, r2}
 5e0:	f504 6eba 	add.w	lr, r4, #1488	@ 0x5d0
 5e4:	e887 0007 	stmia.w	r7, {r0, r1, r2}
 5e8:	e8be 000f 	ldmia.w	lr!, {r0, r1, r2, r3}
 5ec:	f50d 7c82 	add.w	ip, sp, #260	@ 0x104
 5f0:	e8ac 000f 	stmia.w	ip!, {r0, r1, r2, r3}
 5f4:	ab30      	add	r3, sp, #192	@ 0xc0
 5f6:	9302      	str	r3, [sp, #8]
 5f8:	9b54      	ldr	r3, [sp, #336]	@ 0x150
 5fa:	9301      	str	r3, [sp, #4]
 5fc:	f10d 0a70 	add.w	sl, sp, #112	@ 0x70
 600:	9b15      	ldr	r3, [sp, #84]	@ 0x54
 602:	f8cd a00c 	str.w	sl, [sp, #12]
 606:	9300      	str	r3, [sp, #0]
 608:	e89e 0007 	ldmia.w	lr, {r0, r1, r2}
 60c:	9b54      	ldr	r3, [sp, #336]	@ 0x150
 60e:	e88c 0007 	stmia.w	ip, {r0, r1, r2}
 612:	9954      	ldr	r1, [sp, #336]	@ 0x150
 614:	9a0c      	ldr	r2, [sp, #48]	@ 0x30
 616:	980b      	ldr	r0, [sp, #44]	@ 0x2c
 618:	f503 73c0 	add.w	r3, r3, #384	@ 0x180
 61c:	f501 7188 	add.w	r1, r1, #272	@ 0x110
 620:	f7ff fffe 	bl	0 <NavigationEskfRecovery_UpdateCandidateRevision2>
			620: R_ARM_THM_CALL	NavigationEskfRecovery_UpdateCandidateRevision2
 624:	4607      	mov	r7, r0
 626:	e8ba 000f 	ldmia.w	sl!, {r0, r1, r2, r3}
 62a:	4635      	mov	r5, r6
 62c:	c50f      	stmia	r5!, {r0, r1, r2, r3}
 62e:	e89a 000f 	ldmia.w	sl, {r0, r1, r2, r3}
 632:	e885 000f 	stmia.w	r5, {r0, r1, r2, r3}
 636:	9b54      	ldr	r3, [sp, #336]	@ 0x150
 638:	f89d c090 	ldrb.w	ip, [sp, #144]	@ 0x90
 63c:	f503 634d 	add.w	r3, r3, #3280	@ 0xcd0
 640:	f803 c009 	strb.w	ip, [r3, r9]
 644:	2f00      	cmp	r7, #0
 646:	f000 8125 	beq.w	894 <Horizon_Advance.part.0+0x894>
 64a:	3f07      	subs	r7, #7
 64c:	b2ff      	uxtb	r7, r7
 64e:	2f01      	cmp	r7, #1
 650:	f240 8120 	bls.w	894 <Horizon_Advance.part.0+0x894>
 654:	200a      	movs	r0, #10
 656:	2301      	movs	r3, #1
 658:	f88b 3653 	strb.w	r3, [fp, #1619]	@ 0x653
 65c:	e5a8      	b.n	1b0 <Horizon_Advance.part.0+0x1b0>
 65e:	319f      	adds	r1, #159	@ 0x9f
 660:	fba4 e001 	umull	lr, r0, r4, r1
 664:	09c0      	lsrs	r0, r0, #7
 666:	eb00 0080 	add.w	r0, r0, r0, lsl #2
 66a:	eba1 1140 	sub.w	r1, r1, r0, lsl #5
 66e:	f8d5 0bd0 	ldr.w	r0, [r5, #3024]	@ 0xbd0
 672:	eb08 1e81 	add.w	lr, r8, r1, lsl #6
 676:	f8d5 1bd4 	ldr.w	r1, [r5, #3028]	@ 0xbd4
 67a:	4282      	cmp	r2, r0
 67c:	eb73 0101 	sbcs.w	r1, r3, r1
 680:	f107 0701 	add.w	r7, r7, #1
 684:	f605 4508 	addw	r5, r5, #3080	@ 0xc08
 688:	d20a      	bcs.n	6a0 <Horizon_Advance.part.0+0x6a0>
 68a:	f8de 1bd0 	ldr.w	r1, [lr, #3024]	@ 0xbd0
 68e:	f8de 0bd4 	ldr.w	r0, [lr, #3028]	@ 0xbd4
 692:	4291      	cmp	r1, r2
 694:	4198      	sbcs	r0, r3
 696:	d30c      	bcc.n	6b2 <Horizon_Advance.part.0+0x6b2>
 698:	edd5 7a00 	vldr	s15, [r5]
 69c:	ee38 8a27 	vadd.f32	s16, s16, s15
 6a0:	2fa0      	cmp	r7, #160	@ 0xa0
 6a2:	f47f adf9 	bne.w	298 <Horizon_Advance.part.0+0x298>
 6a6:	e622      	b.n	2ee <Horizon_Advance.part.0+0x2ee>
 6a8:	2fa0      	cmp	r7, #160	@ 0xa0
 6aa:	f47f aed9 	bne.w	460 <Horizon_Advance.part.0+0x460>
 6ae:	f8dd b018 	ldr.w	fp, [sp, #24]
 6b2:	2009      	movs	r0, #9
 6b4:	e7cf      	b.n	656 <Horizon_Advance.part.0+0x656>
 6b6:	e9dd 590d 	ldrd	r5, r9, [sp, #52]	@ 0x34
 6ba:	e6f3      	b.n	4a4 <Horizon_Advance.part.0+0x4a4>
 6bc:	2701      	movs	r7, #1
 6be:	e5eb      	b.n	298 <Horizon_Advance.part.0+0x298>
 6c0:	f8db 3624 	ldr.w	r3, [fp, #1572]	@ 0x624
 6c4:	f8cd e0bc 	str.w	lr, [sp, #188]	@ 0xbc
 6c8:	f5b3 7f50 	cmp.w	r3, #832	@ 0x340
 6cc:	e9cd ee2d 	strd	lr, lr, [sp, #180]	@ 0xb4
 6d0:	f080 80dc 	bcs.w	88c <Horizon_Advance.part.0+0x88c>
 6d4:	3301      	adds	r3, #1
 6d6:	f8cb 3624 	str.w	r3, [fp, #1572]	@ 0x624
 6da:	e9dd 010b 	ldrd	r0, r1, [sp, #44]	@ 0x2c
 6de:	9a15      	ldr	r2, [sp, #84]	@ 0x54
 6e0:	9600      	str	r6, [sp, #0]
 6e2:	ab25      	add	r3, sp, #148	@ 0x94
 6e4:	f7ff fffe 	bl	0 <NavigationEskf_UpdateRevision2>
			6e4: R_ARM_THM_CALL	NavigationEskf_UpdateRevision2
 6e8:	2804      	cmp	r0, #4
 6ea:	d0b3      	beq.n	654 <Horizon_Advance.part.0+0x654>
 6ec:	2805      	cmp	r0, #5
 6ee:	f000 80d4 	beq.w	89a <Horizon_Advance.part.0+0x89a>
 6f2:	2803      	cmp	r0, #3
 6f4:	d0ae      	beq.n	654 <Horizon_Advance.part.0+0x654>
 6f6:	f109 0901 	add.w	r9, r9, #1
 6fa:	f1b9 0f40 	cmp.w	r9, #64	@ 0x40
 6fe:	f106 0688 	add.w	r6, r6, #136	@ 0x88
 702:	f104 041c 	add.w	r4, r4, #28
 706:	f47f ae5e 	bne.w	3c6 <Horizon_Advance.part.0+0x3c6>
 70a:	464c      	mov	r4, r9
 70c:	f8dd 9030 	ldr.w	r9, [sp, #48]	@ 0x30
 710:	9b0f      	ldr	r3, [sp, #60]	@ 0x3c
 712:	9300      	str	r3, [sp, #0]
 714:	9b10      	ldr	r3, [sp, #64]	@ 0x40
 716:	9301      	str	r3, [sp, #4]
 718:	2300      	movs	r3, #0
 71a:	990b      	ldr	r1, [sp, #44]	@ 0x2c
 71c:	f88b 3655 	strb.w	r3, [fp, #1621]	@ 0x655
 720:	464a      	mov	r2, r9
 722:	4640      	mov	r0, r8
 724:	f7ff fffe 	bl	0 <Horizon_Advance.part.0>
			724: R_ARM_THM_CALL	Horizon_PropagateTo
 728:	2800      	cmp	r0, #0
 72a:	d194      	bne.n	656 <Horizon_Advance.part.0+0x656>
 72c:	f508 66f8 	add.w	r6, r8, #1984	@ 0x7c0
 730:	990b      	ldr	r1, [sp, #44]	@ 0x2c
 732:	f44f 7278 	mov.w	r2, #992	@ 0x3e0
 736:	4630      	mov	r0, r6
 738:	f7ff fffe 	bl	0 <memcpy>
			738: R_ARM_THM_CALL	memcpy
 73c:	9b16      	ldr	r3, [sp, #88]	@ 0x58
 73e:	ed93 7b00 	vldr	d7, [r3]
 742:	464a      	mov	r2, r9
 744:	ed8d 7b00 	vstr	d7, [sp]
 748:	4631      	mov	r1, r6
 74a:	4640      	mov	r0, r8
 74c:	f7ff fffe 	bl	0 <Horizon_Advance.part.0>
			74c: R_ARM_THM_CALL	Horizon_PropagateTo
 750:	2800      	cmp	r0, #0
 752:	d180      	bne.n	656 <Horizon_Advance.part.0+0x656>
 754:	990b      	ldr	r1, [sp, #44]	@ 0x2c
 756:	f44f 7278 	mov.w	r2, #992	@ 0x3e0
 75a:	4640      	mov	r0, r8
 75c:	f7ff fffe 	bl	0 <memcpy>
			75c: R_ARM_THM_CALL	memcpy
 760:	9805      	ldr	r0, [sp, #20]
 762:	4631      	mov	r1, r6
 764:	f44f 7278 	mov.w	r2, #992	@ 0x3e0
 768:	f7ff fffe 	bl	0 <memcpy>
			768: R_ARM_THM_CALL	memcpy
 76c:	9b54      	ldr	r3, [sp, #336]	@ 0x150
 76e:	b133      	cbz	r3, 77e <Horizon_Advance.part.0+0x77e>
 770:	2270      	movs	r2, #112	@ 0x70
 772:	f503 7188 	add.w	r1, r3, #272	@ 0x110
 776:	f103 00a0 	add.w	r0, r3, #160	@ 0xa0
 77a:	f7ff fffe 	bl	0 <memcpy>
			77a: R_ARM_THM_CALL	memcpy
 77e:	ab19      	add	r3, sp, #100	@ 0x64
 780:	cb07      	ldmia	r3!, {r0, r1, r2}
 782:	f245 6344 	movw	r3, #22084	@ 0x5644
 786:	f245 6510 	movw	r5, #22032	@ 0x5610
 78a:	f848 0003 	str.w	r0, [r8, r3]
 78e:	9b17      	ldr	r3, [sp, #92]	@ 0x5c
 790:	9816      	ldr	r0, [sp, #88]	@ 0x58
 792:	6059      	str	r1, [r3, #4]
 794:	609a      	str	r2, [r3, #8]
 796:	6803      	ldr	r3, [r0, #0]
 798:	f850 2c08 	ldr.w	r2, [r0, #-8]
 79c:	f858 1005 	ldr.w	r1, [r8, r5]
 7a0:	f8ab 461e 	strh.w	r4, [fp, #1566]	@ 0x61e
 7a4:	1a9a      	subs	r2, r3, r2
 7a6:	6843      	ldr	r3, [r0, #4]
 7a8:	f850 0c04 	ldr.w	r0, [r0, #-4]
 7ac:	eb63 0300 	sbc.w	r3, r3, r0
 7b0:	428a      	cmp	r2, r1
 7b2:	990a      	ldr	r1, [sp, #40]	@ 0x28
 7b4:	f8db 2624 	ldr.w	r2, [fp, #1572]	@ 0x624
 7b8:	6849      	ldr	r1, [r1, #4]
 7ba:	418b      	sbcs	r3, r1
 7bc:	f8db 3628 	ldr.w	r3, [fp, #1576]	@ 0x628
 7c0:	f04f 0600 	mov.w	r6, #0
 7c4:	bf34      	ite	cc
 7c6:	2501      	movcc	r5, #1
 7c8:	4635      	movcs	r5, r6
 7ca:	429a      	cmp	r2, r3
 7cc:	f8ab 6620 	strh.w	r6, [fp, #1568]	@ 0x620
 7d0:	f88b 5654 	strb.w	r5, [fp, #1620]	@ 0x654
 7d4:	d901      	bls.n	7da <Horizon_Advance.part.0+0x7da>
 7d6:	f8cb 2628 	str.w	r2, [fp, #1576]	@ 0x628
 7da:	f8bb 261a 	ldrh.w	r2, [fp, #1562]	@ 0x61a
 7de:	f8df a0c8 	ldr.w	sl, [pc, #200]	@ 8a8 <Horizon_Advance.part.0+0x8a8>
 7e2:	9506      	str	r5, [sp, #24]
 7e4:	f1a2 0ea0 	sub.w	lr, r2, #160	@ 0xa0
 7e8:	fa1f fe8e 	uxth.w	lr, lr
 7ec:	f508 40ac 	add.w	r0, r8, #22016	@ 0x5600
 7f0:	4676      	mov	r6, lr
 7f2:	f8dd e028 	ldr.w	lr, [sp, #40]	@ 0x28
 7f6:	3038      	adds	r0, #56	@ 0x38
 7f8:	f04f 0901 	mov.w	r9, #1
 7fc:	b39a      	cbz	r2, 866 <Horizon_Advance.part.0+0x866>
 7fe:	f8bb 3618 	ldrh.w	r3, [fp, #1560]	@ 0x618
 802:	eb08 1583 	add.w	r5, r8, r3, lsl #6
 806:	0199      	lsls	r1, r3, #6
 808:	3301      	adds	r3, #1
 80a:	fbaa 7403 	umull	r7, r4, sl, r3
 80e:	09e4      	lsrs	r4, r4, #7
 810:	eb04 0484 	add.w	r4, r4, r4, lsl #2
 814:	eba3 1344 	sub.w	r3, r3, r4, lsl #5
 818:	f8d8 43cc 	ldr.w	r4, [r8, #972]	@ 0x3cc
 81c:	f8d5 7bd0 	ldr.w	r7, [r5, #3024]	@ 0xbd0
 820:	9405      	str	r4, [sp, #20]
 822:	f8d8 43c8 	ldr.w	r4, [r8, #968]	@ 0x3c8
 826:	f8d5 5bd4 	ldr.w	r5, [r5, #3028]	@ 0xbd4
 82a:	42bc      	cmp	r4, r7
 82c:	9c05      	ldr	r4, [sp, #20]
 82e:	f102 32ff 	add.w	r2, r2, #4294967295
 832:	f601 31e4 	addw	r1, r1, #3044	@ 0xbe4
 836:	41ac      	sbcs	r4, r5
 838:	b292      	uxth	r2, r2
 83a:	eb08 0c01 	add.w	ip, r8, r1
 83e:	d312      	bcc.n	866 <Horizon_Advance.part.0+0x866>
 840:	e94e 7502 	strd	r7, r5, [lr, #-8]
 844:	4296      	cmp	r6, r2
 846:	f858 4001 	ldr.w	r4, [r8, r1]
 84a:	f8dc 5008 	ldr.w	r5, [ip, #8]
 84e:	f8dc 1004 	ldr.w	r1, [ip, #4]
 852:	6041      	str	r1, [r0, #4]
 854:	6085      	str	r5, [r0, #8]
 856:	6004      	str	r4, [r0, #0]
 858:	f8ab 3618 	strh.w	r3, [fp, #1560]	@ 0x618
 85c:	f88b 9650 	strb.w	r9, [fp, #1616]	@ 0x650
 860:	f8ab 261a 	strh.w	r2, [fp, #1562]	@ 0x61a
 864:	d1ca      	bne.n	7fc <Horizon_Advance.part.0+0x7fc>
 866:	9d06      	ldr	r5, [sp, #24]
 868:	0068      	lsls	r0, r5, #1
 86a:	e4a1      	b.n	1b0 <Horizon_Advance.part.0+0x1b0>
 86c:	f89b 3650 	ldrb.w	r3, [fp, #1616]	@ 0x650
 870:	2b00      	cmp	r3, #0
 872:	f43f ade9 	beq.w	448 <Horizon_Advance.part.0+0x448>
 876:	f245 6238 	movw	r2, #22072	@ 0x5638
 87a:	eb08 0302 	add.w	r3, r8, r2
 87e:	f858 0002 	ldr.w	r0, [r8, r2]
 882:	6859      	ldr	r1, [r3, #4]
 884:	689a      	ldr	r2, [r3, #8]
 886:	ab2d      	add	r3, sp, #180	@ 0xb4
 888:	c307      	stmia	r3!, {r0, r1, r2}
 88a:	e67f      	b.n	58c <Horizon_Advance.part.0+0x58c>
 88c:	2006      	movs	r0, #6
 88e:	e6e2      	b.n	656 <Horizon_Advance.part.0+0x656>
 890:	200d      	movs	r0, #13
 892:	e48d      	b.n	1b0 <Horizon_Advance.part.0+0x1b0>
 894:	f89d 008d 	ldrb.w	r0, [sp, #141]	@ 0x8d
 898:	e726      	b.n	6e8 <Horizon_Advance.part.0+0x6e8>
 89a:	200b      	movs	r0, #11
 89c:	e6db      	b.n	656 <Horizon_Advance.part.0+0x656>
 89e:	f8dd 9030 	ldr.w	r9, [sp, #48]	@ 0x30
 8a2:	460c      	mov	r4, r1
 8a4:	e734      	b.n	710 <Horizon_Advance.part.0+0x710>
 8a6:	bf00      	nop
 8a8:	cccccccd 	.word	0xcccccccd

Disassembly of section .text.NavigationEskfHorizon_Reset:

00000000 <NavigationEskfHorizon_Reset>:
   0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
   4:	b097      	sub	sp, #92	@ 0x5c
   6:	e9dd 8a20 	ldrd	r8, sl, [sp, #128]	@ 0x80
   a:	2800      	cmp	r0, #0
   c:	f000 80d7 	beq.w	1be <NavigationEskfHorizon_Reset+0x1be>
  10:	460d      	mov	r5, r1
  12:	2900      	cmp	r1, #0
  14:	f000 80d3 	beq.w	1be <NavigationEskfHorizon_Reset+0x1be>
  18:	4616      	mov	r6, r2
  1a:	2a00      	cmp	r2, #0
  1c:	f000 80cf 	beq.w	1be <NavigationEskfHorizon_Reset+0x1be>
  20:	461f      	mov	r7, r3
  22:	2b00      	cmp	r3, #0
  24:	f000 80cb 	beq.w	1be <NavigationEskfHorizon_Reset+0x1be>
  28:	4281      	cmp	r1, r0
  2a:	4604      	mov	r4, r0
  2c:	f0c0 80cc 	bcc.w	1c8 <NavigationEskfHorizon_Reset+0x1c8>
  30:	1a0b      	subs	r3, r1, r0
  32:	f245 6257 	movw	r2, #22103	@ 0x5657
  36:	4293      	cmp	r3, r2
  38:	bf8c      	ite	hi
  3a:	2300      	movhi	r3, #0
  3c:	2301      	movls	r3, #1
  3e:	2b00      	cmp	r3, #0
  40:	f040 80bd 	bne.w	1be <NavigationEskfHorizon_Reset+0x1be>
  44:	42b4      	cmp	r4, r6
  46:	bf95      	itete	ls
  48:	1b33      	subls	r3, r6, r4
  4a:	1ba3      	subhi	r3, r4, r6
  4c:	f245 6257 	movwls	r2, #22103	@ 0x5657
  50:	f640 4243 	movwhi	r2, #3139	@ 0xc43
  54:	4293      	cmp	r3, r2
  56:	bf8c      	ite	hi
  58:	2300      	movhi	r3, #0
  5a:	2301      	movls	r3, #1
  5c:	2b00      	cmp	r3, #0
  5e:	f040 80ae 	bne.w	1be <NavigationEskfHorizon_Reset+0x1be>
  62:	42bc      	cmp	r4, r7
  64:	f240 80a5 	bls.w	1b2 <NavigationEskfHorizon_Reset+0x1b2>
  68:	1be3      	subs	r3, r4, r7
  6a:	2b2b      	cmp	r3, #43	@ 0x2b
  6c:	f240 80a7 	bls.w	1be <NavigationEskfHorizon_Reset+0x1be>
  70:	42b5      	cmp	r5, r6
  72:	f0c0 80b0 	bcc.w	1d6 <NavigationEskfHorizon_Reset+0x1d6>
  76:	1bab      	subs	r3, r5, r6
  78:	f640 4243 	movw	r2, #3139	@ 0xc43
  7c:	4293      	cmp	r3, r2
  7e:	bf8c      	ite	hi
  80:	2300      	movhi	r3, #0
  82:	2301      	movls	r3, #1
  84:	2b00      	cmp	r3, #0
  86:	f040 809a 	bne.w	1be <NavigationEskfHorizon_Reset+0x1be>
  8a:	42be      	cmp	r6, r7
  8c:	f200 80aa 	bhi.w	1e4 <NavigationEskfHorizon_Reset+0x1e4>
  90:	eba7 0906 	sub.w	r9, r7, r6
  94:	f640 4343 	movw	r3, #3139	@ 0xc43
  98:	4599      	cmp	r9, r3
  9a:	bf8c      	ite	hi
  9c:	f04f 0900 	movhi.w	r9, #0
  a0:	f04f 0901 	movls.w	r9, #1
  a4:	f1b9 0f00 	cmp.w	r9, #0
  a8:	f040 8089 	bne.w	1be <NavigationEskfHorizon_Reset+0x1be>
  ac:	f504 43a0 	add.w	r3, r4, #20480	@ 0x5000
  b0:	461a      	mov	r2, r3
  b2:	2301      	movs	r3, #1
  b4:	f882 3653 	strb.w	r3, [r2, #1619]	@ 0x653
  b8:	f895 b3d8 	ldrb.w	fp, [r5, #984]	@ 0x3d8
  bc:	9205      	str	r2, [sp, #20]
  be:	459b      	cmp	fp, r3
  c0:	d17d      	bne.n	1be <NavigationEskfHorizon_Reset+0x1be>
  c2:	4b4e      	ldr	r3, [pc, #312]	@ (1fc <NavigationEskfHorizon_Reset+0x1fc>)
  c4:	494e      	ldr	r1, [pc, #312]	@ (200 <NavigationEskfHorizon_Reset+0x200>)
  c6:	eb18 0303 	adds.w	r3, r8, r3
  ca:	f16a 0200 	sbc.w	r2, sl, #0
  ce:	4299      	cmp	r1, r3
  d0:	eb79 0202 	sbcs.w	r2, r9, r2
  d4:	d373      	bcc.n	1be <NavigationEskfHorizon_Reset+0x1be>
  d6:	4638      	mov	r0, r7
  d8:	f7ff fffe 	bl	0 <NavigationEskf_ConfigValidate>
			d8: R_ARM_THM_CALL	NavigationEskf_ConfigValidate
  dc:	2800      	cmp	r0, #0
  de:	d16e      	bne.n	1be <NavigationEskfHorizon_Reset+0x1be>
  e0:	6828      	ldr	r0, [r5, #0]
  e2:	6869      	ldr	r1, [r5, #4]
  e4:	68aa      	ldr	r2, [r5, #8]
  e6:	f10d 0c18 	add.w	ip, sp, #24
  ea:	4663      	mov	r3, ip
  ec:	c307      	stmia	r3!, {r0, r1, r2}
  ee:	68e8      	ldr	r0, [r5, #12]
  f0:	6929      	ldr	r1, [r5, #16]
  f2:	696a      	ldr	r2, [r5, #20]
  f4:	c307      	stmia	r3!, {r0, r1, r2}
  f6:	6a6b      	ldr	r3, [r5, #36]	@ 0x24
  f8:	69a8      	ldr	r0, [r5, #24]
  fa:	69e9      	ldr	r1, [r5, #28]
  fc:	6a2a      	ldr	r2, [r5, #32]
  fe:	f10d 0c30 	add.w	ip, sp, #48	@ 0x30
 102:	e8ac 000f 	stmia.w	ip!, {r0, r1, r2, r3}
 106:	6aa8      	ldr	r0, [r5, #40]	@ 0x28
 108:	6ae9      	ldr	r1, [r5, #44]	@ 0x2c
 10a:	6b2a      	ldr	r2, [r5, #48]	@ 0x30
 10c:	4663      	mov	r3, ip
 10e:	c307      	stmia	r3!, {r0, r1, r2}
 110:	6b68      	ldr	r0, [r5, #52]	@ 0x34
 112:	6ba9      	ldr	r1, [r5, #56]	@ 0x38
 114:	6bea      	ldr	r2, [r5, #60]	@ 0x3c
 116:	c307      	stmia	r3!, {r0, r1, r2}
 118:	f8d5 33d4 	ldr.w	r3, [r5, #980]	@ 0x3d4
 11c:	9303      	str	r3, [sp, #12]
 11e:	f8d5 33d0 	ldr.w	r3, [r5, #976]	@ 0x3d0
 122:	9302      	str	r3, [sp, #8]
 124:	ed95 7bf2 	vldr	d7, [r5, #968]	@ 0x3c8
 128:	a906      	add	r1, sp, #24
 12a:	460a      	mov	r2, r1
 12c:	ed8d 7b00 	vstr	d7, [sp]
 130:	4631      	mov	r1, r6
 132:	f105 0340 	add.w	r3, r5, #64	@ 0x40
 136:	f504 7078 	add.w	r0, r4, #992	@ 0x3e0
 13a:	f7ff fffe 	bl	0 <NavigationEskf_Initialize>
			13a: R_ARM_THM_CALL	NavigationEskf_Initialize
 13e:	4606      	mov	r6, r0
 140:	2800      	cmp	r0, #0
 142:	d159      	bne.n	1f8 <NavigationEskfHorizon_Reset+0x1f8>
 144:	4649      	mov	r1, r9
 146:	f245 6258 	movw	r2, #22104	@ 0x5658
 14a:	4620      	mov	r0, r4
 14c:	f7ff fffe 	bl	0 <memset>
			14c: R_ARM_THM_CALL	memset
 150:	4629      	mov	r1, r5
 152:	f44f 7278 	mov.w	r2, #992	@ 0x3e0
 156:	4620      	mov	r0, r4
 158:	f7ff fffe 	bl	0 <memcpy>
			158: R_ARM_THM_CALL	memcpy
 15c:	4629      	mov	r1, r5
 15e:	f44f 7278 	mov.w	r2, #992	@ 0x3e0
 162:	f504 60f8 	add.w	r0, r4, #1984	@ 0x7c0
 166:	f7ff fffe 	bl	0 <memcpy>
			166: R_ARM_THM_CALL	memcpy
 16a:	cf0f      	ldmia	r7!, {r0, r1, r2, r3}
 16c:	f504 693a 	add.w	r9, r4, #2976	@ 0xba0
 170:	ed95 7bf2 	vldr	d7, [r5, #968]	@ 0x3c8
 174:	e8a9 000f 	stmia.w	r9!, {r0, r1, r2, r3}
 178:	cf0f      	ldmia	r7!, {r0, r1, r2, r3}
 17a:	e8a9 000f 	stmia.w	r9!, {r0, r1, r2, r3}
 17e:	e897 0007 	ldmia.w	r7, {r0, r1, r2}
 182:	f245 6c10 	movw	ip, #22032	@ 0x5610
 186:	e889 0007 	stmia.w	r9, {r0, r1, r2}
 18a:	eb04 050c 	add.w	r5, r4, ip
 18e:	9a05      	ldr	r2, [sp, #20]
 190:	f504 4eac 	add.w	lr, r4, #22016	@ 0x5600
 194:	ed0e 7b02 	vstr	d7, [lr, #-8]
 198:	ed8e 7b00 	vstr	d7, [lr]
 19c:	ed05 7b02 	vstr	d7, [r5, #-8]
 1a0:	f844 800c 	str.w	r8, [r4, ip]
 1a4:	f8c5 a004 	str.w	sl, [r5, #4]
 1a8:	f882 b652 	strb.w	fp, [r2, #1618]	@ 0x652
 1ac:	f882 b654 	strb.w	fp, [r2, #1620]	@ 0x654
 1b0:	e006      	b.n	1c0 <NavigationEskfHorizon_Reset+0x1c0>
 1b2:	1b3a      	subs	r2, r7, r4
 1b4:	f245 6357 	movw	r3, #22103	@ 0x5657
 1b8:	429a      	cmp	r2, r3
 1ba:	f63f af59 	bhi.w	70 <NavigationEskfHorizon_Reset+0x70>
 1be:	2603      	movs	r6, #3
 1c0:	4630      	mov	r0, r6
 1c2:	b017      	add	sp, #92	@ 0x5c
 1c4:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 1c8:	1a43      	subs	r3, r0, r1
 1ca:	f5b3 7f78 	cmp.w	r3, #992	@ 0x3e0
 1ce:	bf2c      	ite	cs
 1d0:	2300      	movcs	r3, #0
 1d2:	2301      	movcc	r3, #1
 1d4:	e733      	b.n	3e <NavigationEskfHorizon_Reset+0x3e>
 1d6:	1b73      	subs	r3, r6, r5
 1d8:	f5b3 7f78 	cmp.w	r3, #992	@ 0x3e0
 1dc:	bf2c      	ite	cs
 1de:	2300      	movcs	r3, #0
 1e0:	2301      	movcc	r3, #1
 1e2:	e74f      	b.n	84 <NavigationEskfHorizon_Reset+0x84>
 1e4:	eba6 0907 	sub.w	r9, r6, r7
 1e8:	f1b9 0f2b 	cmp.w	r9, #43	@ 0x2b
 1ec:	bf8c      	ite	hi
 1ee:	f04f 0900 	movhi.w	r9, #0
 1f2:	f04f 0901 	movls.w	r9, #1
 1f6:	e755      	b.n	a4 <NavigationEskfHorizon_Reset+0xa4>
 1f8:	260a      	movs	r6, #10
 1fa:	e7e1      	b.n	1c0 <NavigationEskfHorizon_Reset+0x1c0>
 1fc:	ffffd8f0 	.word	0xffffd8f0
 200:	00083d60 	.word	0x00083d60

Disassembly of section .text.NavigationEskfHorizon_BodyReceive:

00000000 <NavigationEskfHorizon_BodyReceive>:
   0:	e92d 4ff8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, lr}
   4:	2800      	cmp	r0, #0
   6:	f000 80a0 	beq.w	14a <NavigationEskfHorizon_BodyReceive+0x14a>
   a:	f500 47a0 	add.w	r7, r0, #20480	@ 0x5000
   e:	4604      	mov	r4, r0
  10:	f897 3652 	ldrb.w	r3, [r7, #1618]	@ 0x652
  14:	2b01      	cmp	r3, #1
  16:	f040 80a3 	bne.w	160 <NavigationEskfHorizon_BodyReceive+0x160>
  1a:	460e      	mov	r6, r1
  1c:	f7ff fffe 	bl	0 <NavigationEskfHorizon_BodyReceive>
			1c: R_ARM_THM_CALL	Horizon_Ready.part.0
  20:	4605      	mov	r5, r0
  22:	2800      	cmp	r0, #0
  24:	f040 808a 	bne.w	13c <NavigationEskfHorizon_BodyReceive+0x13c>
  28:	2e00      	cmp	r6, #0
  2a:	f000 808e 	beq.w	14a <NavigationEskfHorizon_BodyReceive+0x14a>
  2e:	42a6      	cmp	r6, r4
  30:	f0c0 8087 	bcc.w	142 <NavigationEskfHorizon_BodyReceive+0x142>
  34:	1b32      	subs	r2, r6, r4
  36:	f245 6357 	movw	r3, #22103	@ 0x5657
  3a:	429a      	cmp	r2, r3
  3c:	f240 8085 	bls.w	14a <NavigationEskfHorizon_BodyReceive+0x14a>
  40:	f8b7 361e 	ldrh.w	r3, [r7, #1566]	@ 0x61e
  44:	2b00      	cmp	r3, #0
  46:	f040 808f 	bne.w	168 <NavigationEskfHorizon_BodyReceive+0x168>
  4a:	6cb2      	ldr	r2, [r6, #72]	@ 0x48
  4c:	f8d4 33d0 	ldr.w	r3, [r4, #976]	@ 0x3d0
  50:	429a      	cmp	r2, r3
  52:	d17e      	bne.n	152 <NavigationEskfHorizon_BodyReceive+0x152>
  54:	6cf2      	ldr	r2, [r6, #76]	@ 0x4c
  56:	f8d4 33d4 	ldr.w	r3, [r4, #980]	@ 0x3d4
  5a:	429a      	cmp	r2, r3
  5c:	d179      	bne.n	152 <NavigationEskfHorizon_BodyReceive+0x152>
  5e:	f504 48ac 	add.w	r8, r4, #22016	@ 0x5600
  62:	e9d6 020e 	ldrd	r0, r2, [r6, #56]	@ 0x38
  66:	e9d8 1300 	ldrd	r1, r3, [r8]
  6a:	429a      	cmp	r2, r3
  6c:	bf08      	it	eq
  6e:	4288      	cmpeq	r0, r1
  70:	f040 8081 	bne.w	176 <NavigationEskfHorizon_BodyReceive+0x176>
  74:	4630      	mov	r0, r6
  76:	f7ff fffe 	bl	0 <NavigationEskfHorizon_BodyReceive>
			76: R_ARM_THM_CALL	Horizon_BodyValid
  7a:	2800      	cmp	r0, #0
  7c:	d07b      	beq.n	176 <NavigationEskfHorizon_BodyReceive+0x176>
  7e:	f897 3651 	ldrb.w	r3, [r7, #1617]	@ 0x651
  82:	2b00      	cmp	r3, #0
  84:	d174      	bne.n	170 <NavigationEskfHorizon_BodyReceive+0x170>
  86:	f8b7 361a 	ldrh.w	r3, [r7, #1562]	@ 0x61a
  8a:	2ba0      	cmp	r3, #160	@ 0xa0
  8c:	d078      	beq.n	180 <NavigationEskfHorizon_BodyReceive+0x180>
  8e:	f8b7 2618 	ldrh.w	r2, [r7, #1560]	@ 0x618
  92:	f8d6 e050 	ldr.w	lr, [r6, #80]	@ 0x50
  96:	edd6 7a0c 	vldr	s15, [r6, #48]	@ 0x30
  9a:	441a      	add	r2, r3
  9c:	4b3e      	ldr	r3, [pc, #248]	@ (198 <NavigationEskfHorizon_BodyReceive+0x198>)
  9e:	fba3 1302 	umull	r1, r3, r3, r2
  a2:	09db      	lsrs	r3, r3, #7
  a4:	eb03 0383 	add.w	r3, r3, r3, lsl #2
  a8:	ed96 6b10 	vldr	d6, [r6, #64]	@ 0x40
  ac:	eba2 1343 	sub.w	r3, r2, r3, lsl #5
  b0:	eb04 1083 	add.w	r0, r4, r3, lsl #6
  b4:	f500 6a3d 	add.w	sl, r0, #3024	@ 0xbd0
  b8:	ed8a 6b00 	vstr	d6, [sl]
  bc:	f600 4908 	addw	r9, r0, #3080	@ 0xc08
  c0:	019b      	lsls	r3, r3, #6
  c2:	edc9 7a00 	vstr	s15, [r9]
  c6:	f603 3cd8 	addw	ip, r3, #3032	@ 0xbd8
  ca:	f8c0 ec0c 	str.w	lr, [r0, #3084]	@ 0xc0c
  ce:	6830      	ldr	r0, [r6, #0]
  d0:	f8d6 e004 	ldr.w	lr, [r6, #4]
  d4:	f8d6 a008 	ldr.w	sl, [r6, #8]
  d8:	f8d6 900c 	ldr.w	r9, [r6, #12]
  dc:	f844 000c 	str.w	r0, [r4, ip]
  e0:	eb04 010c 	add.w	r1, r4, ip
  e4:	f503 633f 	add.w	r3, r3, #3056	@ 0xbf0
  e8:	f8c1 e004 	str.w	lr, [r1, #4]
  ec:	f8c1 a008 	str.w	sl, [r1, #8]
  f0:	f8c1 900c 	str.w	r9, [r1, #12]
  f4:	6930      	ldr	r0, [r6, #16]
  f6:	f8d6 e014 	ldr.w	lr, [r6, #20]
  fa:	f8c1 e014 	str.w	lr, [r1, #20]
  fe:	6108      	str	r0, [r1, #16]
 100:	69b1      	ldr	r1, [r6, #24]
 102:	69f0      	ldr	r0, [r6, #28]
 104:	f8d6 e020 	ldr.w	lr, [r6, #32]
 108:	f8d6 c024 	ldr.w	ip, [r6, #36]	@ 0x24
 10c:	50e1      	str	r1, [r4, r3]
 10e:	18e2      	adds	r2, r4, r3
 110:	f04f 0b01 	mov.w	fp, #1
 114:	6050      	str	r0, [r2, #4]
 116:	f8c2 e008 	str.w	lr, [r2, #8]
 11a:	f8c2 c00c 	str.w	ip, [r2, #12]
 11e:	6ab1      	ldr	r1, [r6, #40]	@ 0x28
 120:	6af0      	ldr	r0, [r6, #44]	@ 0x2c
 122:	6150      	str	r0, [r2, #20]
 124:	6111      	str	r1, [r2, #16]
 126:	f8b7 361a 	ldrh.w	r3, [r7, #1562]	@ 0x61a
 12a:	445b      	add	r3, fp
 12c:	f8a7 361a 	strh.w	r3, [r7, #1562]	@ 0x61a
 130:	e9d6 2310 	ldrd	r2, r3, [r6, #64]	@ 0x40
 134:	e9c8 2300 	strd	r2, r3, [r8]
 138:	f887 b651 	strb.w	fp, [r7, #1617]	@ 0x651
 13c:	4628      	mov	r0, r5
 13e:	e8bd 8ff8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, pc}
 142:	1ba3      	subs	r3, r4, r6
 144:	2b57      	cmp	r3, #87	@ 0x57
 146:	f63f af7b 	bhi.w	40 <NavigationEskfHorizon_BodyReceive+0x40>
 14a:	2503      	movs	r5, #3
 14c:	4628      	mov	r0, r5
 14e:	e8bd 8ff8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, pc}
 152:	2301      	movs	r3, #1
 154:	2508      	movs	r5, #8
 156:	f887 3653 	strb.w	r3, [r7, #1619]	@ 0x653
 15a:	4628      	mov	r0, r5
 15c:	e8bd 8ff8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, pc}
 160:	250c      	movs	r5, #12
 162:	4628      	mov	r0, r5
 164:	e8bd 8ff8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, pc}
 168:	250d      	movs	r5, #13
 16a:	4628      	mov	r0, r5
 16c:	e8bd 8ff8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, pc}
 170:	6d33      	ldr	r3, [r6, #80]	@ 0x50
 172:	0719      	lsls	r1, r3, #28
 174:	d587      	bpl.n	86 <NavigationEskfHorizon_BodyReceive+0x86>
 176:	2301      	movs	r3, #1
 178:	f887 3653 	strb.w	r3, [r7, #1619]	@ 0x653
 17c:	2509      	movs	r5, #9
 17e:	e7dd      	b.n	13c <NavigationEskfHorizon_BodyReceive+0x13c>
 180:	f8d7 3630 	ldr.w	r3, [r7, #1584]	@ 0x630
 184:	1c5a      	adds	r2, r3, #1
 186:	bf1c      	itt	ne
 188:	3301      	addne	r3, #1
 18a:	f8c7 3630 	strne.w	r3, [r7, #1584]	@ 0x630
 18e:	2301      	movs	r3, #1
 190:	f887 3653 	strb.w	r3, [r7, #1619]	@ 0x653
 194:	2506      	movs	r5, #6
 196:	e7d1      	b.n	13c <NavigationEskfHorizon_BodyReceive+0x13c>
 198:	cccccccd 	.word	0xcccccccd

Disassembly of section .text.NavigationEskfHorizon_Insert:

00000000 <NavigationEskfHorizon_Insert>:
   0:	b1b0      	cbz	r0, 30 <NavigationEskfHorizon_Insert+0x30>
   2:	b570      	push	{r4, r5, r6, lr}
   4:	f500 43a0 	add.w	r3, r0, #20480	@ 0x5000
   8:	4604      	mov	r4, r0
   a:	f893 3652 	ldrb.w	r3, [r3, #1618]	@ 0x652
   e:	2b01      	cmp	r3, #1
  10:	d10b      	bne.n	2a <NavigationEskfHorizon_Insert+0x2a>
  12:	460d      	mov	r5, r1
  14:	f7ff fffe 	bl	0 <NavigationEskfHorizon_Insert>
			14: R_ARM_THM_CALL	Horizon_Ready.part.0
  18:	4603      	mov	r3, r0
  1a:	b938      	cbnz	r0, 2c <NavigationEskfHorizon_Insert+0x2c>
  1c:	4602      	mov	r2, r0
  1e:	4629      	mov	r1, r5
  20:	4620      	mov	r0, r4
  22:	e8bd 4070 	ldmia.w	sp!, {r4, r5, r6, lr}
  26:	f7ff bffe 	b.w	0 <NavigationEskfHorizon_Insert>
			26: R_ARM_THM_JUMP24	Horizon_Insert.part.0
  2a:	230c      	movs	r3, #12
  2c:	4618      	mov	r0, r3
  2e:	bd70      	pop	{r4, r5, r6, pc}
  30:	2303      	movs	r3, #3
  32:	4618      	mov	r0, r3
  34:	4770      	bx	lr
  36:	bf00      	nop

Disassembly of section .text.NavigationEskfHorizon_Advance:

00000000 <NavigationEskfHorizon_Advance>:
   0:	b300      	cbz	r0, 44 <NavigationEskfHorizon_Advance+0x44>
   2:	b5f0      	push	{r4, r5, r6, r7, lr}
   4:	461f      	mov	r7, r3
   6:	f500 43a0 	add.w	r3, r0, #20480	@ 0x5000
   a:	b083      	sub	sp, #12
   c:	f893 3652 	ldrb.w	r3, [r3, #1618]	@ 0x652
  10:	2b01      	cmp	r3, #1
  12:	4604      	mov	r4, r0
  14:	d113      	bne.n	3e <NavigationEskfHorizon_Advance+0x3e>
  16:	460d      	mov	r5, r1
  18:	4616      	mov	r6, r2
  1a:	f7ff fffe 	bl	0 <NavigationEskfHorizon_Advance>
			1a: R_ARM_THM_CALL	Horizon_Ready.part.0
  1e:	b948      	cbnz	r0, 34 <NavigationEskfHorizon_Advance+0x34>
  20:	b155      	cbz	r5, 38 <NavigationEskfHorizon_Advance+0x38>
  22:	b14e      	cbz	r6, 38 <NavigationEskfHorizon_Advance+0x38>
  24:	b147      	cbz	r7, 38 <NavigationEskfHorizon_Advance+0x38>
  26:	9000      	str	r0, [sp, #0]
  28:	463b      	mov	r3, r7
  2a:	4632      	mov	r2, r6
  2c:	4629      	mov	r1, r5
  2e:	4620      	mov	r0, r4
  30:	f7ff fffe 	bl	0 <NavigationEskfHorizon_Advance>
			30: R_ARM_THM_CALL	Horizon_Advance.part.0
  34:	b003      	add	sp, #12
  36:	bdf0      	pop	{r4, r5, r6, r7, pc}
  38:	2003      	movs	r0, #3
  3a:	b003      	add	sp, #12
  3c:	bdf0      	pop	{r4, r5, r6, r7, pc}
  3e:	200c      	movs	r0, #12
  40:	b003      	add	sp, #12
  42:	bdf0      	pop	{r4, r5, r6, r7, pc}
  44:	2003      	movs	r0, #3
  46:	4770      	bx	lr

Disassembly of section .text.NavigationEskfHorizon_CompletionPop:

00000000 <NavigationEskfHorizon_CompletionPop>:
   0:	2300      	movs	r3, #0
   2:	461a      	mov	r2, r3
   4:	f7ff bffe 	b.w	0 <NavigationEskfHorizon_CompletionPop>
			4: R_ARM_THM_JUMP24	Horizon_CompletionPop

Disassembly of section .text.NavigationEskfHorizonRecovery_Reset:

00000000 <NavigationEskfHorizonRecovery_Reset>:
   0:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
   4:	2800      	cmp	r0, #0
   6:	d055      	beq.n	b4 <NavigationEskfHorizonRecovery_Reset+0xb4>
   8:	2900      	cmp	r1, #0
   a:	d053      	beq.n	b4 <NavigationEskfHorizonRecovery_Reset+0xb4>
   c:	4615      	mov	r5, r2
   e:	2a00      	cmp	r2, #0
  10:	d050      	beq.n	b4 <NavigationEskfHorizonRecovery_Reset+0xb4>
  12:	461e      	mov	r6, r3
  14:	2b00      	cmp	r3, #0
  16:	d04d      	beq.n	b4 <NavigationEskfHorizonRecovery_Reset+0xb4>
  18:	6c92      	ldr	r2, [r2, #72]	@ 0x48
  1a:	f8d1 33d4 	ldr.w	r3, [r1, #980]	@ 0x3d4
  1e:	429a      	cmp	r2, r3
  20:	d148      	bne.n	b4 <NavigationEskfHorizonRecovery_Reset+0xb4>
  22:	f891 33d8 	ldrb.w	r3, [r1, #984]	@ 0x3d8
  26:	2b01      	cmp	r3, #1
  28:	d144      	bne.n	b4 <NavigationEskfHorizonRecovery_Reset+0xb4>
  2a:	4281      	cmp	r1, r0
  2c:	4604      	mov	r4, r0
  2e:	d345      	bcc.n	bc <NavigationEskfHorizonRecovery_Reset+0xbc>
  30:	1a09      	subs	r1, r1, r0
  32:	f640 5317 	movw	r3, #3351	@ 0xd17
  36:	4299      	cmp	r1, r3
  38:	bf8c      	ite	hi
  3a:	2100      	movhi	r1, #0
  3c:	2101      	movls	r1, #1
  3e:	bbc9      	cbnz	r1, b4 <NavigationEskfHorizonRecovery_Reset+0xb4>
  40:	42ac      	cmp	r4, r5
  42:	d834      	bhi.n	ae <NavigationEskfHorizonRecovery_Reset+0xae>
  44:	1b2a      	subs	r2, r5, r4
  46:	f640 5317 	movw	r3, #3351	@ 0xd17
  4a:	429a      	cmp	r2, r3
  4c:	d932      	bls.n	b4 <NavigationEskfHorizonRecovery_Reset+0xb4>
  4e:	42b4      	cmp	r4, r6
  50:	d83b      	bhi.n	ca <NavigationEskfHorizonRecovery_Reset+0xca>
  52:	eba6 0804 	sub.w	r8, r6, r4
  56:	f640 5317 	movw	r3, #3351	@ 0xd17
  5a:	4598      	cmp	r8, r3
  5c:	bf8c      	ite	hi
  5e:	f04f 0800 	movhi.w	r8, #0
  62:	f04f 0801 	movls.w	r8, #1
  66:	f1b8 0f00 	cmp.w	r8, #0
  6a:	d123      	bne.n	b4 <NavigationEskfHorizonRecovery_Reset+0xb4>
  6c:	4631      	mov	r1, r6
  6e:	4628      	mov	r0, r5
  70:	f7ff fffe 	bl	0 <NavigationEskfRecovery_PolicyValidate>
			70: R_ARM_THM_CALL	NavigationEskfRecovery_PolicyValidate
  74:	4607      	mov	r7, r0
  76:	b9e8      	cbnz	r0, b4 <NavigationEskfHorizonRecovery_Reset+0xb4>
  78:	4641      	mov	r1, r8
  7a:	f640 5218 	movw	r2, #3352	@ 0xd18
  7e:	4620      	mov	r0, r4
  80:	f7ff fffe 	bl	0 <memset>
			80: R_ARM_THM_CALL	memset
  84:	22a0      	movs	r2, #160	@ 0xa0
  86:	4631      	mov	r1, r6
  88:	4620      	mov	r0, r4
  8a:	f7ff fffe 	bl	0 <memcpy>
			8a: R_ARM_THM_CALL	memcpy
  8e:	2270      	movs	r2, #112	@ 0x70
  90:	4629      	mov	r1, r5
  92:	f104 00a0 	add.w	r0, r4, #160	@ 0xa0
  96:	f7ff fffe 	bl	0 <memcpy>
			96: R_ARM_THM_CALL	memcpy
  9a:	2270      	movs	r2, #112	@ 0x70
  9c:	4629      	mov	r1, r5
  9e:	f504 7088 	add.w	r0, r4, #272	@ 0x110
  a2:	f7ff fffe 	bl	0 <memcpy>
			a2: R_ARM_THM_CALL	memcpy
  a6:	2301      	movs	r3, #1
  a8:	f884 3d10 	strb.w	r3, [r4, #3344]	@ 0xd10
  ac:	e003      	b.n	b6 <NavigationEskfHorizonRecovery_Reset+0xb6>
  ae:	1b63      	subs	r3, r4, r5
  b0:	2b6f      	cmp	r3, #111	@ 0x6f
  b2:	d8cc      	bhi.n	4e <NavigationEskfHorizonRecovery_Reset+0x4e>
  b4:	2703      	movs	r7, #3
  b6:	4638      	mov	r0, r7
  b8:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
  bc:	1a41      	subs	r1, r0, r1
  be:	f5b1 7f78 	cmp.w	r1, #992	@ 0x3e0
  c2:	bf2c      	ite	cs
  c4:	2100      	movcs	r1, #0
  c6:	2101      	movcc	r1, #1
  c8:	e7b9      	b.n	3e <NavigationEskfHorizonRecovery_Reset+0x3e>
  ca:	eba4 0806 	sub.w	r8, r4, r6
  ce:	f1b8 0f9f 	cmp.w	r8, #159	@ 0x9f
  d2:	bf8c      	ite	hi
  d4:	f04f 0800 	movhi.w	r8, #0
  d8:	f04f 0801 	movls.w	r8, #1
  dc:	e7c3      	b.n	66 <NavigationEskfHorizonRecovery_Reset+0x66>
  de:	bf00      	nop

Disassembly of section .text.NavigationEskfHorizonRecovery_Insert:

00000000 <NavigationEskfHorizonRecovery_Insert>:
   0:	2900      	cmp	r1, #0
   2:	d061      	beq.n	c8 <NavigationEskfHorizonRecovery_Insert+0xc8>
   4:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
   8:	461e      	mov	r6, r3
   a:	b13b      	cbz	r3, 1c <NavigationEskfHorizonRecovery_Insert+0x1c>
   c:	4614      	mov	r4, r2
   e:	b12a      	cbz	r2, 1c <NavigationEskfHorizonRecovery_Insert+0x1c>
  10:	4605      	mov	r5, r0
  12:	b118      	cbz	r0, 1c <NavigationEskfHorizonRecovery_Insert+0x1c>
  14:	f892 3d10 	ldrb.w	r3, [r2, #3344]	@ 0xd10
  18:	2b01      	cmp	r3, #1
  1a:	d002      	beq.n	22 <NavigationEskfHorizonRecovery_Insert+0x22>
  1c:	2003      	movs	r0, #3
  1e:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
  22:	f8d2 20e8 	ldr.w	r2, [r2, #232]	@ 0xe8
  26:	f8d0 33d4 	ldr.w	r3, [r0, #980]	@ 0x3d4
  2a:	429a      	cmp	r2, r3
  2c:	d1f6      	bne.n	1c <NavigationEskfHorizonRecovery_Insert+0x1c>
  2e:	f500 43ac 	add.w	r3, r0, #22016	@ 0x5600
  32:	e9d3 0300 	ldrd	r0, r3, [r3]
  36:	f8d4 20e0 	ldr.w	r2, [r4, #224]	@ 0xe0
  3a:	460f      	mov	r7, r1
  3c:	f8d4 10e4 	ldr.w	r1, [r4, #228]	@ 0xe4
  40:	4290      	cmp	r0, r2
  42:	418b      	sbcs	r3, r1
  44:	d3ea      	bcc.n	1c <NavigationEskfHorizonRecovery_Insert+0x1c>
  46:	4621      	mov	r1, r4
  48:	f104 00a0 	add.w	r0, r4, #160	@ 0xa0
  4c:	f7ff fffe 	bl	0 <NavigationEskfRecovery_PolicyValidate>
			4c: R_ARM_THM_CALL	NavigationEskfRecovery_PolicyValidate
  50:	2800      	cmp	r0, #0
  52:	d1e3      	bne.n	1c <NavigationEskfHorizonRecovery_Insert+0x1c>
  54:	42a5      	cmp	r5, r4
  56:	bf2b      	itete	cs
  58:	1b2b      	subcs	r3, r5, r4
  5a:	1b63      	subcc	r3, r4, r5
  5c:	f640 5217 	movwcs	r2, #3351	@ 0xd17
  60:	f245 6257 	movwcc	r2, #22103	@ 0x5657
  64:	4293      	cmp	r3, r2
  66:	bf8c      	ite	hi
  68:	2300      	movhi	r3, #0
  6a:	2301      	movls	r3, #1
  6c:	2b00      	cmp	r3, #0
  6e:	d1d5      	bne.n	1c <NavigationEskfHorizonRecovery_Insert+0x1c>
  70:	42bc      	cmp	r4, r7
  72:	d82b      	bhi.n	cc <NavigationEskfHorizonRecovery_Insert+0xcc>
  74:	1b3a      	subs	r2, r7, r4
  76:	f640 5317 	movw	r3, #3351	@ 0xd17
  7a:	429a      	cmp	r2, r3
  7c:	d9ce      	bls.n	1c <NavigationEskfHorizonRecovery_Insert+0x1c>
  7e:	42b4      	cmp	r4, r6
  80:	d829      	bhi.n	d6 <NavigationEskfHorizonRecovery_Insert+0xd6>
  82:	1b33      	subs	r3, r6, r4
  84:	f640 5217 	movw	r2, #3351	@ 0xd17
  88:	4293      	cmp	r3, r2
  8a:	bf8c      	ite	hi
  8c:	2300      	movhi	r3, #0
  8e:	2301      	movls	r3, #1
  90:	2b00      	cmp	r3, #0
  92:	d1c3      	bne.n	1c <NavigationEskfHorizonRecovery_Insert+0x1c>
  94:	42b5      	cmp	r5, r6
  96:	d824      	bhi.n	e2 <NavigationEskfHorizonRecovery_Insert+0xe2>
  98:	1b72      	subs	r2, r6, r5
  9a:	f245 6357 	movw	r3, #22103	@ 0x5657
  9e:	429a      	cmp	r2, r3
  a0:	d9bc      	bls.n	1c <NavigationEskfHorizonRecovery_Insert+0x1c>
  a2:	f505 43a0 	add.w	r3, r5, #20480	@ 0x5000
  a6:	f893 3652 	ldrb.w	r3, [r3, #1618]	@ 0x652
  aa:	2b01      	cmp	r3, #1
  ac:	d11d      	bne.n	ea <NavigationEskfHorizonRecovery_Insert+0xea>
  ae:	4628      	mov	r0, r5
  b0:	f7ff fffe 	bl	0 <NavigationEskfHorizonRecovery_Insert>
			b0: R_ARM_THM_CALL	Horizon_Ready.part.0
  b4:	2800      	cmp	r0, #0
  b6:	d1b2      	bne.n	1e <NavigationEskfHorizonRecovery_Insert+0x1e>
  b8:	4633      	mov	r3, r6
  ba:	4622      	mov	r2, r4
  bc:	4639      	mov	r1, r7
  be:	4628      	mov	r0, r5
  c0:	e8bd 41f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, lr}
  c4:	f7ff bffe 	b.w	0 <NavigationEskfHorizonRecovery_Insert>
			c4: R_ARM_THM_JUMP24	Horizon_Insert.part.0
  c8:	2003      	movs	r0, #3
  ca:	4770      	bx	lr
  cc:	1be3      	subs	r3, r4, r7
  ce:	2b87      	cmp	r3, #135	@ 0x87
  d0:	d9a4      	bls.n	1c <NavigationEskfHorizonRecovery_Insert+0x1c>
  d2:	42b4      	cmp	r4, r6
  d4:	d9d5      	bls.n	82 <NavigationEskfHorizonRecovery_Insert+0x82>
  d6:	1ba3      	subs	r3, r4, r6
  d8:	2b1b      	cmp	r3, #27
  da:	bf8c      	ite	hi
  dc:	2300      	movhi	r3, #0
  de:	2301      	movls	r3, #1
  e0:	e7d6      	b.n	90 <NavigationEskfHorizonRecovery_Insert+0x90>
  e2:	1bab      	subs	r3, r5, r6
  e4:	2b1b      	cmp	r3, #27
  e6:	d8dc      	bhi.n	a2 <NavigationEskfHorizonRecovery_Insert+0xa2>
  e8:	e798      	b.n	1c <NavigationEskfHorizonRecovery_Insert+0x1c>
  ea:	200c      	movs	r0, #12
  ec:	e797      	b.n	1e <NavigationEskfHorizonRecovery_Insert+0x1e>
  ee:	bf00      	nop

Disassembly of section .text.NavigationEskfHorizonRecovery_Advance:

00000000 <NavigationEskfHorizonRecovery_Advance>:
   0:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
   4:	9c06      	ldr	r4, [sp, #24]
   6:	b134      	cbz	r4, 16 <NavigationEskfHorizonRecovery_Advance+0x16>
   8:	4605      	mov	r5, r0
   a:	b120      	cbz	r0, 16 <NavigationEskfHorizonRecovery_Advance+0x16>
   c:	4698      	mov	r8, r3
   e:	f894 3d10 	ldrb.w	r3, [r4, #3344]	@ 0xd10
  12:	2b01      	cmp	r3, #1
  14:	d002      	beq.n	1c <NavigationEskfHorizonRecovery_Advance+0x1c>
  16:	2003      	movs	r0, #3
  18:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
  1c:	f8d0 33d4 	ldr.w	r3, [r0, #980]	@ 0x3d4
  20:	4617      	mov	r7, r2
  22:	f8d4 20e8 	ldr.w	r2, [r4, #232]	@ 0xe8
  26:	429a      	cmp	r2, r3
  28:	d1f5      	bne.n	16 <NavigationEskfHorizonRecovery_Advance+0x16>
  2a:	f500 43ac 	add.w	r3, r0, #22016	@ 0x5600
  2e:	e9d3 0300 	ldrd	r0, r3, [r3]
  32:	f8d4 20e0 	ldr.w	r2, [r4, #224]	@ 0xe0
  36:	460e      	mov	r6, r1
  38:	f8d4 10e4 	ldr.w	r1, [r4, #228]	@ 0xe4
  3c:	4290      	cmp	r0, r2
  3e:	418b      	sbcs	r3, r1
  40:	d3e9      	bcc.n	16 <NavigationEskfHorizonRecovery_Advance+0x16>
  42:	4621      	mov	r1, r4
  44:	f104 00a0 	add.w	r0, r4, #160	@ 0xa0
  48:	f7ff fffe 	bl	0 <NavigationEskfRecovery_PolicyValidate>
			48: R_ARM_THM_CALL	NavigationEskfRecovery_PolicyValidate
  4c:	2800      	cmp	r0, #0
  4e:	d1e2      	bne.n	16 <NavigationEskfHorizonRecovery_Advance+0x16>
  50:	42a5      	cmp	r5, r4
  52:	bf2b      	itete	cs
  54:	1b28      	subcs	r0, r5, r4
  56:	1b60      	subcc	r0, r4, r5
  58:	f640 5317 	movwcs	r3, #3351	@ 0xd17
  5c:	f245 6357 	movwcc	r3, #22103	@ 0x5657
  60:	4298      	cmp	r0, r3
  62:	bf8c      	ite	hi
  64:	2000      	movhi	r0, #0
  66:	2001      	movls	r0, #1
  68:	2800      	cmp	r0, #0
  6a:	d1d4      	bne.n	16 <NavigationEskfHorizonRecovery_Advance+0x16>
  6c:	42b4      	cmp	r4, r6
  6e:	d83d      	bhi.n	ec <NavigationEskfHorizonRecovery_Advance+0xec>
  70:	1b33      	subs	r3, r6, r4
  72:	f640 5217 	movw	r2, #3351	@ 0xd17
  76:	4293      	cmp	r3, r2
  78:	bf8c      	ite	hi
  7a:	2300      	movhi	r3, #0
  7c:	2301      	movls	r3, #1
  7e:	2b00      	cmp	r3, #0
  80:	d1c9      	bne.n	16 <NavigationEskfHorizonRecovery_Advance+0x16>
  82:	42bc      	cmp	r4, r7
  84:	bf95      	itete	ls
  86:	1b3b      	subls	r3, r7, r4
  88:	1be3      	subhi	r3, r4, r7
  8a:	f640 5217 	movwls	r2, #3351	@ 0xd17
  8e:	f640 4243 	movwhi	r2, #3139	@ 0xc43
  92:	4293      	cmp	r3, r2
  94:	bf8c      	ite	hi
  96:	2300      	movhi	r3, #0
  98:	2301      	movls	r3, #1
  9a:	2b00      	cmp	r3, #0
  9c:	d1bb      	bne.n	16 <NavigationEskfHorizonRecovery_Advance+0x16>
  9e:	4544      	cmp	r4, r8
  a0:	d82b      	bhi.n	fa <NavigationEskfHorizonRecovery_Advance+0xfa>
  a2:	eba8 0304 	sub.w	r3, r8, r4
  a6:	f640 5217 	movw	r2, #3351	@ 0xd17
  aa:	4293      	cmp	r3, r2
  ac:	bf8c      	ite	hi
  ae:	2300      	movhi	r3, #0
  b0:	2301      	movls	r3, #1
  b2:	2b00      	cmp	r3, #0
  b4:	d1af      	bne.n	16 <NavigationEskfHorizonRecovery_Advance+0x16>
  b6:	f505 43a0 	add.w	r3, r5, #20480	@ 0x5000
  ba:	f893 3652 	ldrb.w	r3, [r3, #1618]	@ 0x652
  be:	2b01      	cmp	r3, #1
  c0:	d122      	bne.n	108 <NavigationEskfHorizonRecovery_Advance+0x108>
  c2:	4628      	mov	r0, r5
  c4:	f7ff fffe 	bl	0 <NavigationEskfHorizonRecovery_Advance>
			c4: R_ARM_THM_CALL	Horizon_Ready.part.0
  c8:	2800      	cmp	r0, #0
  ca:	d1a5      	bne.n	18 <NavigationEskfHorizonRecovery_Advance+0x18>
  cc:	2e00      	cmp	r6, #0
  ce:	d0a2      	beq.n	16 <NavigationEskfHorizonRecovery_Advance+0x16>
  d0:	2f00      	cmp	r7, #0
  d2:	d0a0      	beq.n	16 <NavigationEskfHorizonRecovery_Advance+0x16>
  d4:	f1b8 0f00 	cmp.w	r8, #0
  d8:	d09d      	beq.n	16 <NavigationEskfHorizonRecovery_Advance+0x16>
  da:	9406      	str	r4, [sp, #24]
  dc:	4643      	mov	r3, r8
  de:	463a      	mov	r2, r7
  e0:	4631      	mov	r1, r6
  e2:	4628      	mov	r0, r5
  e4:	e8bd 41f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, lr}
  e8:	f7ff bffe 	b.w	0 <NavigationEskfHorizonRecovery_Advance>
			e8: R_ARM_THM_JUMP24	Horizon_Advance.part.0
  ec:	1ba3      	subs	r3, r4, r6
  ee:	f5b3 7f78 	cmp.w	r3, #992	@ 0x3e0
  f2:	bf2c      	ite	cs
  f4:	2300      	movcs	r3, #0
  f6:	2301      	movcc	r3, #1
  f8:	e7c1      	b.n	7e <NavigationEskfHorizonRecovery_Advance+0x7e>
  fa:	eba4 0308 	sub.w	r3, r4, r8
  fe:	2b2b      	cmp	r3, #43	@ 0x2b
 100:	bf8c      	ite	hi
 102:	2300      	movhi	r3, #0
 104:	2301      	movls	r3, #1
 106:	e7d4      	b.n	b2 <NavigationEskfHorizonRecovery_Advance+0xb2>
 108:	200c      	movs	r0, #12
 10a:	e785      	b.n	18 <NavigationEskfHorizonRecovery_Advance+0x18>

Disassembly of section .text.NavigationEskfHorizonRecovery_CompletionPop:

00000000 <NavigationEskfHorizonRecovery_CompletionPop>:
   0:	b169      	cbz	r1, 1e <NavigationEskfHorizonRecovery_CompletionPop+0x1e>
   2:	b163      	cbz	r3, 1e <NavigationEskfHorizonRecovery_CompletionPop+0x1e>
   4:	b15a      	cbz	r2, 1e <NavigationEskfHorizonRecovery_CompletionPop+0x1e>
   6:	b570      	push	{r4, r5, r6, lr}
   8:	4605      	mov	r5, r0
   a:	b082      	sub	sp, #8
   c:	b120      	cbz	r0, 18 <NavigationEskfHorizonRecovery_CompletionPop+0x18>
   e:	460c      	mov	r4, r1
  10:	f892 1d10 	ldrb.w	r1, [r2, #3344]	@ 0xd10
  14:	2901      	cmp	r1, #1
  16:	d004      	beq.n	22 <NavigationEskfHorizonRecovery_CompletionPop+0x22>
  18:	2003      	movs	r0, #3
  1a:	b002      	add	sp, #8
  1c:	bd70      	pop	{r4, r5, r6, pc}
  1e:	2003      	movs	r0, #3
  20:	4770      	bx	lr
  22:	f8d2 00e8 	ldr.w	r0, [r2, #232]	@ 0xe8
  26:	f8d5 13d4 	ldr.w	r1, [r5, #980]	@ 0x3d4
  2a:	4288      	cmp	r0, r1
  2c:	d1f4      	bne.n	18 <NavigationEskfHorizonRecovery_CompletionPop+0x18>
  2e:	f505 41ac 	add.w	r1, r5, #22016	@ 0x5600
  32:	e9d1 6100 	ldrd	r6, r1, [r1]
  36:	f8d2 00e0 	ldr.w	r0, [r2, #224]	@ 0xe0
  3a:	4286      	cmp	r6, r0
  3c:	f8d2 00e4 	ldr.w	r0, [r2, #228]	@ 0xe4
  40:	4181      	sbcs	r1, r0
  42:	d3e9      	bcc.n	18 <NavigationEskfHorizonRecovery_CompletionPop+0x18>
  44:	4611      	mov	r1, r2
  46:	f102 00a0 	add.w	r0, r2, #160	@ 0xa0
  4a:	9301      	str	r3, [sp, #4]
  4c:	9200      	str	r2, [sp, #0]
  4e:	f7ff fffe 	bl	0 <NavigationEskfRecovery_PolicyValidate>
			4e: R_ARM_THM_CALL	NavigationEskfRecovery_PolicyValidate
  52:	2800      	cmp	r0, #0
  54:	d1e0      	bne.n	18 <NavigationEskfHorizonRecovery_CompletionPop+0x18>
  56:	9a00      	ldr	r2, [sp, #0]
  58:	9b01      	ldr	r3, [sp, #4]
  5a:	4295      	cmp	r5, r2
  5c:	bf2b      	itete	cs
  5e:	1aa9      	subcs	r1, r5, r2
  60:	1b51      	subcc	r1, r2, r5
  62:	f640 5017 	movwcs	r0, #3351	@ 0xd17
  66:	f245 6057 	movwcc	r0, #22103	@ 0x5657
  6a:	4281      	cmp	r1, r0
  6c:	bf8c      	ite	hi
  6e:	2100      	movhi	r1, #0
  70:	2101      	movls	r1, #1
  72:	2900      	cmp	r1, #0
  74:	d1d0      	bne.n	18 <NavigationEskfHorizonRecovery_CompletionPop+0x18>
  76:	42a2      	cmp	r2, r4
  78:	d822      	bhi.n	c0 <NavigationEskfHorizonRecovery_CompletionPop+0xc0>
  7a:	1aa1      	subs	r1, r4, r2
  7c:	f640 5017 	movw	r0, #3351	@ 0xd17
  80:	4281      	cmp	r1, r0
  82:	bf8c      	ite	hi
  84:	2100      	movhi	r1, #0
  86:	2101      	movls	r1, #1
  88:	2900      	cmp	r1, #0
  8a:	d1c5      	bne.n	18 <NavigationEskfHorizonRecovery_CompletionPop+0x18>
  8c:	429a      	cmp	r2, r3
  8e:	d804      	bhi.n	9a <NavigationEskfHorizonRecovery_CompletionPop+0x9a>
  90:	1a98      	subs	r0, r3, r2
  92:	f640 5117 	movw	r1, #3351	@ 0xd17
  96:	4288      	cmp	r0, r1
  98:	d9be      	bls.n	18 <NavigationEskfHorizonRecovery_CompletionPop+0x18>
  9a:	429d      	cmp	r5, r3
  9c:	d804      	bhi.n	a8 <NavigationEskfHorizonRecovery_CompletionPop+0xa8>
  9e:	1b58      	subs	r0, r3, r5
  a0:	f245 6157 	movw	r1, #22103	@ 0x5657
  a4:	4288      	cmp	r0, r1
  a6:	d9b7      	bls.n	18 <NavigationEskfHorizonRecovery_CompletionPop+0x18>
  a8:	429c      	cmp	r4, r3
  aa:	d802      	bhi.n	b2 <NavigationEskfHorizonRecovery_CompletionPop+0xb2>
  ac:	1b19      	subs	r1, r3, r4
  ae:	2987      	cmp	r1, #135	@ 0x87
  b0:	d9b2      	bls.n	18 <NavigationEskfHorizonRecovery_CompletionPop+0x18>
  b2:	4621      	mov	r1, r4
  b4:	4628      	mov	r0, r5
  b6:	b002      	add	sp, #8
  b8:	e8bd 4070 	ldmia.w	sp!, {r4, r5, r6, lr}
  bc:	f7ff bffe 	b.w	0 <NavigationEskfHorizonRecovery_CompletionPop>
			bc: R_ARM_THM_JUMP24	Horizon_CompletionPop
  c0:	1b11      	subs	r1, r2, r4
  c2:	2987      	cmp	r1, #135	@ 0x87
  c4:	bf8c      	ite	hi
  c6:	2100      	movhi	r1, #0
  c8:	2101      	movls	r1, #1
  ca:	e7dd      	b.n	88 <NavigationEskfHorizonRecovery_CompletionPop+0x88>
