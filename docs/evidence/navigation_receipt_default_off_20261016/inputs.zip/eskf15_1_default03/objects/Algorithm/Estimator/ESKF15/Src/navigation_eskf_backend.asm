
D:\python_software\SilverStar\.work\dev013_navclosure02\eskf15_1_default03\build\FCCG\SilverStar_F407\Release\auto\Algorithm\Estimator\ESKF15\Src\navigation_eskf_backend.o:     file format elf32-littlearm


Disassembly of section .text.Backend_StateLog:

00000000 <Backend_StateLog>:
   0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
   4:	b0cb      	sub	sp, #300	@ 0x12c
   6:	2402      	movs	r4, #2
   8:	f8df 9160 	ldr.w	r9, [pc, #352]	@ 16c <Backend_StateLog+0x16c>
   c:	9400      	str	r4, [sp, #0]
   e:	4621      	mov	r1, r4
  10:	4a50      	ldr	r2, [pc, #320]	@ (154 <Backend_StateLog+0x154>)
  12:	4e51      	ldr	r6, [pc, #324]	@ (158 <Backend_StateLog+0x158>)
  14:	4d51      	ldr	r5, [pc, #324]	@ (15c <Backend_StateLog+0x15c>)
  16:	f44f 73b7 	mov.w	r3, #366	@ 0x16e
  1a:	4680      	mov	r8, r0
  1c:	2001      	movs	r0, #1
  1e:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			1e: R_ARM_THM_CALL	SilverStarAssert_Check
  22:	f8d9 3000 	ldr.w	r3, [r9]
  26:	f44f 72a7 	mov.w	r2, #334	@ 0x14e
  2a:	9200      	str	r2, [sp, #0]
  2c:	1c58      	adds	r0, r3, #1
  2e:	4622      	mov	r2, r4
  30:	ac02      	add	r4, sp, #8
  32:	4b48      	ldr	r3, [pc, #288]	@ (154 <Backend_StateLog+0x154>)
  34:	f8c9 0000 	str.w	r0, [r9]
  38:	2104      	movs	r1, #4
  3a:	4620      	mov	r0, r4
  3c:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			3c: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  40:	227d      	movs	r2, #125	@ 0x7d
  42:	2100      	movs	r1, #0
  44:	f10d 001b 	add.w	r0, sp, #27
  48:	f7ff fffe 	bl	0 <memset>
			48: R_ARM_THM_CALL	memset
  4c:	f8d9 3000 	ldr.w	r3, [r9]
  50:	6023      	str	r3, [r4, #0]
  52:	f8d6 33d4 	ldr.w	r3, [r6, #980]	@ 0x3d4
  56:	682a      	ldr	r2, [r5, #0]
  58:	6063      	str	r3, [r4, #4]
  5a:	f8d6 33d0 	ldr.w	r3, [r6, #976]	@ 0x3d0
  5e:	60a3      	str	r3, [r4, #8]
  60:	60e2      	str	r2, [r4, #12]
  62:	4b3f      	ldr	r3, [pc, #252]	@ (160 <Backend_StateLog+0x160>)
  64:	f44f 7281 	mov.w	r2, #258	@ 0x102
  68:	8222      	strh	r2, [r4, #16]
  6a:	2203      	movs	r2, #3
  6c:	e9d6 01f2 	ldrd	r0, r1, [r6, #968]	@ 0x3c8
  70:	681b      	ldr	r3, [r3, #0]
  72:	74a2      	strb	r2, [r4, #18]
  74:	220f      	movs	r2, #15
  76:	f7ff fffe 	bl	0 <SystemNavigationHealth_OverallGet>
			76: R_ARM_THM_CALL	SystemNavigationHealth_OverallGet
  7a:	74e0      	strb	r0, [r4, #19]
  7c:	e896 0007 	ldmia.w	r6, {r0, r1, r2}
  80:	f106 0a0c 	add.w	sl, r6, #12
  84:	f10d 0b1c 	add.w	fp, sp, #28
  88:	e88b 0007 	stmia.w	fp, {r0, r1, r2}
  8c:	e89a 0007 	ldmia.w	sl, {r0, r1, r2}
  90:	f106 0318 	add.w	r3, r6, #24
  94:	f10d 0a28 	add.w	sl, sp, #40	@ 0x28
  98:	e88a 0007 	stmia.w	sl, {r0, r1, r2}
  9c:	cb0f      	ldmia	r3, {r0, r1, r2, r3}
  9e:	f10d 0a34 	add.w	sl, sp, #52	@ 0x34
  a2:	e88a 000f 	stmia.w	sl, {r0, r1, r2, r3}
  a6:	f106 0328 	add.w	r3, r6, #40	@ 0x28
  aa:	e893 0007 	ldmia.w	r3, {r0, r1, r2}
  ae:	ab11      	add	r3, sp, #68	@ 0x44
  b0:	e883 0007 	stmia.w	r3, {r0, r1, r2}
  b4:	f106 0334 	add.w	r3, r6, #52	@ 0x34
  b8:	e893 0007 	ldmia.w	r3, {r0, r1, r2}
  bc:	ab14      	add	r3, sp, #80	@ 0x50
  be:	e883 0007 	stmia.w	r3, {r0, r1, r2}
  c2:	46b6      	mov	lr, r6
  c4:	f10d 0c5c 	add.w	ip, sp, #92	@ 0x5c
  c8:	af26      	add	r7, sp, #152	@ 0x98
  ca:	f85e 3f40 	ldr.w	r3, [lr, #64]!
  ce:	f84c 3b04 	str.w	r3, [ip], #4
  d2:	4567      	cmp	r7, ip
  d4:	d1f9      	bne.n	ca <Backend_StateLog+0xca>
  d6:	e9d6 01f2 	ldrd	r0, r1, [r6, #968]	@ 0x3c8
  da:	4622      	mov	r2, r4
  dc:	f1b8 0f00 	cmp.w	r8, #0
  e0:	d034      	beq.n	14c <Backend_StateLog+0x14c>
  e2:	f7ff fffe 	bl	0 <LoggerBus_Eskf15InitialStatePush>
			e2: R_ARM_THM_CALL	LoggerBus_Eskf15InitialStatePush
  e6:	b118      	cbz	r0, f0 <Backend_StateLog+0xf0>
  e8:	4a1e      	ldr	r2, [pc, #120]	@ (164 <Backend_StateLog+0x164>)
  ea:	6813      	ldr	r3, [r2, #0]
  ec:	3301      	adds	r3, #1
  ee:	6013      	str	r3, [r2, #0]
  f0:	2402      	movs	r4, #2
  f2:	f44f 73b1 	mov.w	r3, #354	@ 0x162
  f6:	4621      	mov	r1, r4
  f8:	4a16      	ldr	r2, [pc, #88]	@ (154 <Backend_StateLog+0x154>)
  fa:	9400      	str	r4, [sp, #0]
  fc:	2001      	movs	r0, #1
  fe:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			fe: R_ARM_THM_CALL	SilverStarAssert_Check
 102:	227e      	movs	r2, #126	@ 0x7e
 104:	2100      	movs	r1, #0
 106:	f10d 00aa 	add.w	r0, sp, #170	@ 0xaa
 10a:	f7ff fffe 	bl	0 <memset>
			10a: R_ARM_THM_CALL	memset
 10e:	f8d9 3000 	ldr.w	r3, [r9]
 112:	9326      	str	r3, [sp, #152]	@ 0x98
 114:	f8d6 33d4 	ldr.w	r3, [r6, #980]	@ 0x3d4
 118:	9327      	str	r3, [sp, #156]	@ 0x9c
 11a:	f8d6 33d0 	ldr.w	r3, [r6, #976]	@ 0x3d0
 11e:	682d      	ldr	r5, [r5, #0]
 120:	f88d 40a8 	strb.w	r4, [sp, #168]	@ 0xa8
 124:	9328      	str	r3, [sp, #160]	@ 0xa0
 126:	f088 0401 	eor.w	r4, r8, #1
 12a:	e9d6 01f2 	ldrd	r0, r1, [r6, #968]	@ 0x3c8
 12e:	4b0e      	ldr	r3, [pc, #56]	@ (168 <Backend_StateLog+0x168>)
 130:	9529      	str	r5, [sp, #164]	@ 0xa4
 132:	463a      	mov	r2, r7
 134:	f88d 40a9 	strb.w	r4, [sp, #169]	@ 0xa9
 138:	f7ff fffe 	bl	0 <LoggerBus_Eskf15CovariancePush>
			138: R_ARM_THM_CALL	LoggerBus_Eskf15CovariancePush
 13c:	b118      	cbz	r0, 146 <Backend_StateLog+0x146>
 13e:	4a09      	ldr	r2, [pc, #36]	@ (164 <Backend_StateLog+0x164>)
 140:	6813      	ldr	r3, [r2, #0]
 142:	3301      	adds	r3, #1
 144:	6013      	str	r3, [r2, #0]
 146:	b04b      	add	sp, #300	@ 0x12c
 148:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 14c:	f7ff fffe 	bl	0 <LoggerBus_Eskf15StatePush>
			14c: R_ARM_THM_CALL	LoggerBus_Eskf15StatePush
 150:	e7c9      	b.n	e6 <Backend_StateLog+0xe6>
 152:	bf00      	nop
	...
			154: R_ARM_ABS32	.rodata.Backend_StateLog.str1.4
			158: R_ARM_ABS32	.bss.s_state
			15c: R_ARM_ABS32	.bss.s_calibration_generation
			160: R_ARM_ABS32	.bss.s_imu_quality_flags
			164: R_ARM_ABS32	.bss.s_log_failures
 168:	00000040 	.word	0x00000040
			168: R_ARM_ABS32	.bss.s_state
 16c:	00000000 	.word	0x00000000
			16c: R_ARM_ABS32	.bss.s_snapshot_id

Disassembly of section .text.Backend_EventApply:

00000000 <Backend_EventApply>:
   0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
   4:	b0b9      	sub	sp, #228	@ 0xe4
   6:	f44f 733d 	mov.w	r3, #756	@ 0x2f4
   a:	9300      	str	r3, [sp, #0]
   c:	460c      	mov	r4, r1
   e:	4bc6      	ldr	r3, [pc, #792]	@ (328 <Backend_EventApply+0x328>)
  10:	2108      	movs	r1, #8
  12:	4690      	mov	r8, r2
  14:	2202      	movs	r2, #2
  16:	4605      	mov	r5, r0
  18:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			18: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  1c:	f240 22f5 	movw	r2, #757	@ 0x2f5
  20:	4bc1      	ldr	r3, [pc, #772]	@ (328 <Backend_EventApply+0x328>)
  22:	9200      	str	r2, [sp, #0]
  24:	2108      	movs	r1, #8
  26:	2202      	movs	r2, #2
  28:	4620      	mov	r0, r4
  2a:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			2a: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  2e:	4bbf      	ldr	r3, [pc, #764]	@ (32c <Backend_EventApply+0x32c>)
  30:	f8d3 33d4 	ldr.w	r3, [r3, #980]	@ 0x3d4
  34:	61ab      	str	r3, [r5, #24]
  36:	7f2b      	ldrb	r3, [r5, #28]
  38:	2b03      	cmp	r3, #3
  3a:	d803      	bhi.n	44 <Backend_EventApply+0x44>
  3c:	2300      	movs	r3, #0
  3e:	632b      	str	r3, [r5, #48]	@ 0x30
  40:	636b      	str	r3, [r5, #52]	@ 0x34
  42:	63ab      	str	r3, [r5, #56]	@ 0x38
  44:	f44f 73d1 	mov.w	r3, #418	@ 0x1a2
  48:	f105 0b3c 	add.w	fp, r5, #60	@ 0x3c
  4c:	682e      	ldr	r6, [r5, #0]
  4e:	9300      	str	r3, [sp, #0]
  50:	2202      	movs	r2, #2
  52:	4bb5      	ldr	r3, [pc, #724]	@ (328 <Backend_EventApply+0x328>)
  54:	686f      	ldr	r7, [r5, #4]
  56:	2104      	movs	r1, #4
  58:	4658      	mov	r0, fp
  5a:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			5a: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  5e:	2300      	movs	r3, #0
  60:	4ab3      	ldr	r2, [pc, #716]	@ (330 <Backend_EventApply+0x330>)
  62:	646b      	str	r3, [r5, #68]	@ 0x44
  64:	e9c5 330f 	strd	r3, r3, [r5, #60]	@ 0x3c
  68:	f502 4180 	add.w	r1, r2, #16384	@ 0x4000
  6c:	f8b1 9248 	ldrh.w	r9, [r1, #584]	@ 0x248
  70:	f1b9 0f00 	cmp.w	r9, #0
  74:	d01f      	beq.n	b6 <Backend_EventApply+0xb6>
  76:	e9d2 a0f2 	ldrd	sl, r0, [r2, #968]	@ 0x3c8
  7a:	f8d2 17c0 	ldr.w	r1, [r2, #1984]	@ 0x7c0
  7e:	e9cd 5b04 	strd	r5, fp, [sp, #16]
  82:	4684      	mov	ip, r0
  84:	46a3      	mov	fp, r4
  86:	2b00      	cmp	r3, #0
  88:	f000 8172 	beq.w	370 <Backend_EventApply+0x370>
  8c:	e951 0210 	ldrd	r0, r2, [r1, #-64]	@ 0x40
  90:	4286      	cmp	r6, r0
  92:	eb77 0402 	sbcs.w	r4, r7, r2
  96:	f103 0301 	add.w	r3, r3, #1
  9a:	d306      	bcc.n	aa <Backend_EventApply+0xaa>
  9c:	e9d1 5400 	ldrd	r5, r4, [r1]
  a0:	42b5      	cmp	r5, r6
  a2:	eb74 0e07 	sbcs.w	lr, r4, r7
  a6:	f080 8297 	bcs.w	5d8 <Backend_EventApply+0x5d8>
  aa:	454b      	cmp	r3, r9
  ac:	f101 0140 	add.w	r1, r1, #64	@ 0x40
  b0:	d1e9      	bne.n	86 <Backend_EventApply+0x86>
  b2:	9d04      	ldr	r5, [sp, #16]
  b4:	465c      	mov	r4, fp
  b6:	f10d 0918 	add.w	r9, sp, #24
  ba:	4e9e      	ldr	r6, [pc, #632]	@ (334 <Backend_EventApply+0x334>)
  bc:	2220      	movs	r2, #32
  be:	2100      	movs	r1, #0
  c0:	4648      	mov	r0, r9
  c2:	f7ff fffe 	bl	0 <memset>
			c2: R_ARM_THM_CALL	memset
  c6:	f04f 537e 	mov.w	r3, #1065353216	@ 0x3f800000
  ca:	9307      	str	r3, [sp, #28]
  cc:	6833      	ldr	r3, [r6, #0]
  ce:	3301      	adds	r3, #1
  d0:	6033      	str	r3, [r6, #0]
  d2:	f7ff fffe 	bl	0 <SystemTime_GetMonotonicUs>
			d2: R_ARM_THM_CALL	SystemTime_GetMonotonicUs
  d6:	e9c6 0102 	strd	r0, r1, [r6, #8]
  da:	e9cd 5900 	strd	r5, r9, [sp]
  de:	6833      	ldr	r3, [r6, #0]
  e0:	4a95      	ldr	r2, [pc, #596]	@ (338 <Backend_EventApply+0x338>)
  e2:	4992      	ldr	r1, [pc, #584]	@ (32c <Backend_EventApply+0x32c>)
  e4:	4892      	ldr	r0, [pc, #584]	@ (330 <Backend_EventApply+0x330>)
  e6:	3301      	adds	r3, #1
  e8:	6033      	str	r3, [r6, #0]
  ea:	4b94      	ldr	r3, [pc, #592]	@ (33c <Backend_EventApply+0x33c>)
  ec:	f7ff fffe 	bl	0 <NavigationEskfReplay_Insert>
			ec: R_ARM_THM_CALL	NavigationEskfReplay_Insert
  f0:	2805      	cmp	r0, #5
  f2:	4607      	mov	r7, r0
  f4:	f240 8231 	bls.w	55a <Backend_EventApply+0x55a>
  f8:	2301      	movs	r3, #1
  fa:	f884 3075 	strb.w	r3, [r4, #117]	@ 0x75
  fe:	e9d6 ab02 	ldrd	sl, fp, [r6, #8]
 102:	f7ff fffe 	bl	0 <SystemTime_GetMonotonicUs>
			102: R_ARM_THM_CALL	SystemTime_GetMonotonicUs
 106:	e9cd 0102 	strd	r0, r1, [sp, #8]
 10a:	e9dd 0102 	ldrd	r0, r1, [sp, #8]
 10e:	4550      	cmp	r0, sl
 110:	460a      	mov	r2, r1
 112:	eb72 020b 	sbcs.w	r2, r2, fp
 116:	7f2b      	ldrb	r3, [r5, #28]
 118:	f080 81eb 	bcs.w	4f2 <Backend_EventApply+0x4f2>
 11c:	6832      	ldr	r2, [r6, #0]
 11e:	3201      	adds	r2, #1
 120:	6032      	str	r2, [r6, #0]
 122:	e9dd 1202 	ldrd	r1, r2, [sp, #8]
 126:	e9c6 1204 	strd	r1, r2, [r6, #16]
 12a:	2200      	movs	r2, #0
 12c:	6332      	str	r2, [r6, #48]	@ 0x30
 12e:	f886 3040 	strb.w	r3, [r6, #64]	@ 0x40
 132:	6b73      	ldr	r3, [r6, #52]	@ 0x34
 134:	6bf3      	ldr	r3, [r6, #60]	@ 0x3c
 136:	3301      	adds	r3, #1
 138:	d002      	beq.n	140 <Backend_EventApply+0x140>
 13a:	6bf3      	ldr	r3, [r6, #60]	@ 0x3c
 13c:	3301      	adds	r3, #1
 13e:	63f3      	str	r3, [r6, #60]	@ 0x3c
 140:	6833      	ldr	r3, [r6, #0]
 142:	3301      	adds	r3, #1
 144:	6033      	str	r3, [r6, #0]
 146:	f240 13e7 	movw	r3, #487	@ 0x1e7
 14a:	9300      	str	r3, [sp, #0]
 14c:	2202      	movs	r2, #2
 14e:	4b76      	ldr	r3, [pc, #472]	@ (328 <Backend_EventApply+0x328>)
 150:	2108      	movs	r1, #8
 152:	4628      	mov	r0, r5
 154:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			154: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
 158:	f44f 73f4 	mov.w	r3, #488	@ 0x1e8
 15c:	4648      	mov	r0, r9
 15e:	9300      	str	r3, [sp, #0]
 160:	2202      	movs	r2, #2
 162:	4b71      	ldr	r3, [pc, #452]	@ (328 <Backend_EventApply+0x328>)
 164:	2104      	movs	r1, #4
 166:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			166: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
 16a:	2230      	movs	r2, #48	@ 0x30
 16c:	2100      	movs	r1, #0
 16e:	a80e      	add	r0, sp, #56	@ 0x38
 170:	f7ff fffe 	bl	0 <memset>
			170: R_ARM_THM_CALL	memset
 174:	4a72      	ldr	r2, [pc, #456]	@ (340 <Backend_EventApply+0x340>)
 176:	4b73      	ldr	r3, [pc, #460]	@ (344 <Backend_EventApply+0x344>)
 178:	486c      	ldr	r0, [pc, #432]	@ (32c <Backend_EventApply+0x32c>)
 17a:	6819      	ldr	r1, [r3, #0]
 17c:	6813      	ldr	r3, [r2, #0]
 17e:	3301      	adds	r3, #1
 180:	6223      	str	r3, [r4, #32]
 182:	6013      	str	r3, [r2, #0]
 184:	f8d0 33d4 	ldr.w	r3, [r0, #980]	@ 0x3d4
 188:	6263      	str	r3, [r4, #36]	@ 0x24
 18a:	696b      	ldr	r3, [r5, #20]
 18c:	e9c4 310a 	strd	r3, r1, [r4, #40]	@ 0x28
 190:	8bab      	ldrh	r3, [r5, #28]
 192:	7f6a      	ldrb	r2, [r5, #29]
 194:	8623      	strh	r3, [r4, #48]	@ 0x30
 196:	e9d5 ab00 	ldrd	sl, fp, [r5]
 19a:	6929      	ldr	r1, [r5, #16]
 19c:	e9c4 ab04 	strd	sl, fp, [r4, #16]
 1a0:	e9d5 ab02 	ldrd	sl, fp, [r5, #8]
 1a4:	e9c4 ab02 	strd	sl, fp, [r4, #8]
 1a8:	e9d0 abf2 	ldrd	sl, fp, [r0, #968]	@ 0x3c8
 1ac:	6721      	str	r1, [r4, #112]	@ 0x70
 1ae:	e9c4 ab06 	strd	sl, fp, [r4, #24]
 1b2:	2f00      	cmp	r7, #0
 1b4:	f000 8194 	beq.w	4e0 <Backend_EventApply+0x4e0>
 1b8:	3710      	adds	r7, #16
 1ba:	2300      	movs	r3, #0
 1bc:	b2ff      	uxtb	r7, r7
 1be:	f884 3032 	strb.w	r3, [r4, #50]	@ 0x32
 1c2:	ab08      	add	r3, sp, #32
 1c4:	e893 0003 	ldmia.w	r3, {r0, r1}
 1c8:	ed9d 7a07 	vldr	s14, [sp, #28]
 1cc:	9b06      	ldr	r3, [sp, #24]
 1ce:	6563      	str	r3, [r4, #84]	@ 0x54
 1d0:	9315      	str	r3, [sp, #84]	@ 0x54
 1d2:	f104 063c 	add.w	r6, r4, #60	@ 0x3c
 1d6:	ab0a      	add	r3, sp, #40	@ 0x28
 1d8:	f884 7033 	strb.w	r7, [r4, #51]	@ 0x33
 1dc:	ed84 7a18 	vstr	s14, [r4, #96]	@ 0x60
 1e0:	e886 0003 	stmia.w	r6, {r0, r1}
 1e4:	e893 0003 	ldmia.w	r3, {r0, r1}
 1e8:	f104 094c 	add.w	r9, r4, #76	@ 0x4c
 1ec:	e889 0003 	stmia.w	r9, {r0, r1}
 1f0:	f105 0320 	add.w	r3, r5, #32
 1f4:	e893 0003 	ldmia.w	r3, {r0, r1}
 1f8:	f104 0a34 	add.w	sl, r4, #52	@ 0x34
 1fc:	e88a 0003 	stmia.w	sl, {r0, r1}
 200:	692b      	ldr	r3, [r5, #16]
 202:	9314      	str	r3, [sp, #80]	@ 0x50
 204:	696b      	ldr	r3, [r5, #20]
 206:	f88d 205c 	strb.w	r2, [sp, #92]	@ 0x5c
 20a:	f88d 3061 	strb.w	r3, [sp, #97]	@ 0x61
 20e:	e9d5 2302 	ldrd	r2, r3, [r5, #8]
 212:	e9cd 230e 	strd	r2, r3, [sp, #56]	@ 0x38
 216:	e9d5 2300 	ldrd	r2, r3, [r5]
 21a:	edd4 7a16 	vldr	s15, [r4, #88]	@ 0x58
 21e:	edd4 6a17 	vldr	s13, [r4, #92]	@ 0x5c
 222:	e9cd 2310 	strd	r2, r3, [sp, #64]	@ 0x40
 226:	4b41      	ldr	r3, [pc, #260]	@ (32c <Backend_EventApply+0x32c>)
 228:	ee67 7aa6 	vmul.f32	s15, s15, s13
 22c:	e9d3 23f2 	ldrd	r2, r3, [r3, #968]	@ 0x3c8
 230:	ee67 7a87 	vmul.f32	s15, s15, s14
 234:	e9cd 2312 	strd	r2, r3, [sp, #72]	@ 0x48
 238:	edcd 7a16 	vstr	s15, [sp, #88]	@ 0x58
 23c:	f894 3032 	ldrb.w	r3, [r4, #50]	@ 0x32
 240:	f88d 305d 	strb.w	r3, [sp, #93]	@ 0x5d
 244:	b16b      	cbz	r3, 262 <Backend_EventApply+0x262>
 246:	ed9d 7a0c 	vldr	s14, [sp, #48]	@ 0x30
 24a:	eeb5 7ac0 	vcmpe.f32	s14, #0.0
 24e:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 252:	f340 81bf 	ble.w	5d4 <Backend_EventApply+0x5d4>
 256:	f89d 3035 	ldrb.w	r3, [sp, #53]	@ 0x35
 25a:	2b01      	cmp	r3, #1
 25c:	bf8c      	ite	hi
 25e:	2300      	movhi	r3, #0
 260:	2301      	movls	r3, #1
 262:	eeb7 7a00 	vmov.f32	s14, #112	@ 0x3f800000  1.0
 266:	eef4 7ac7 	vcmpe.f32	s15, s14
 26a:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
 26e:	f88d 305e 	strb.w	r3, [sp, #94]	@ 0x5e
 272:	7f28      	ldrb	r0, [r5, #28]
 274:	f88d 7060 	strb.w	r7, [sp, #96]	@ 0x60
 278:	bfcc      	ite	gt
 27a:	2301      	movgt	r3, #1
 27c:	2300      	movle	r3, #0
 27e:	a90e      	add	r1, sp, #56	@ 0x38
 280:	f88d 305f 	strb.w	r3, [sp, #95]	@ 0x5f
 284:	f7ff fffe 	bl	0 <SystemNavigationHealth_Observe>
			284: R_ARM_THM_CALL	SystemNavigationHealth_Observe
 288:	b118      	cbz	r0, 292 <Backend_EventApply+0x292>
 28a:	4a2f      	ldr	r2, [pc, #188]	@ (348 <Backend_EventApply+0x348>)
 28c:	6813      	ldr	r3, [r2, #0]
 28e:	3301      	adds	r3, #1
 290:	6013      	str	r3, [r2, #0]
 292:	f894 7033 	ldrb.w	r7, [r4, #51]	@ 0x33
 296:	f44f 73dc 	mov.w	r3, #440	@ 0x1b8
 29a:	2f05      	cmp	r7, #5
 29c:	9300      	str	r3, [sp, #0]
 29e:	f04f 0202 	mov.w	r2, #2
 2a2:	4b21      	ldr	r3, [pc, #132]	@ (328 <Backend_EventApply+0x328>)
 2a4:	f894 5030 	ldrb.w	r5, [r4, #48]	@ 0x30
 2a8:	f04f 0108 	mov.w	r1, #8
 2ac:	4640      	mov	r0, r8
 2ae:	bf28      	it	cs
 2b0:	2703      	movcs	r7, #3
 2b2:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			2b2: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
 2b6:	2102      	movs	r1, #2
 2b8:	9100      	str	r1, [sp, #0]
 2ba:	f894 0030 	ldrb.w	r0, [r4, #48]	@ 0x30
 2be:	4a1a      	ldr	r2, [pc, #104]	@ (328 <Backend_EventApply+0x328>)
 2c0:	2804      	cmp	r0, #4
 2c2:	bf8c      	ite	hi
 2c4:	2000      	movhi	r0, #0
 2c6:	2001      	movls	r0, #1
 2c8:	f240 13b9 	movw	r3, #441	@ 0x1b9
 2cc:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			2cc: R_ARM_THM_CALL	SilverStarAssert_Check
 2d0:	f894 2030 	ldrb.w	r2, [r4, #48]	@ 0x30
 2d4:	f8d8 1184 	ldr.w	r1, [r8, #388]	@ 0x184
 2d8:	f8dd e058 	ldr.w	lr, [sp, #88]	@ 0x58
 2dc:	f89d 005e 	ldrb.w	r0, [sp, #94]	@ 0x5e
 2e0:	2a03      	cmp	r2, #3
 2e2:	d872      	bhi.n	3ca <Backend_EventApply+0x3ca>
 2e4:	ea4f 0c45 	mov.w	ip, r5, lsl #1
 2e8:	2a01      	cmp	r2, #1
 2ea:	f005 0301 	and.w	r3, r5, #1
 2ee:	f00c 0502 	and.w	r5, ip, #2
 2f2:	bf8c      	ite	hi
 2f4:	f04f 0c02 	movhi.w	ip, #2
 2f8:	f04f 0c01 	movls.w	ip, #1
 2fc:	ea4c 0101 	orr.w	r1, ip, r1
 300:	f8c8 1184 	str.w	r1, [r8, #388]	@ 0x184
 304:	f1c3 0302 	rsb	r3, r3, #2
 308:	f105 0541 	add.w	r5, r5, #65	@ 0x41
 30c:	b2db      	uxtb	r3, r3
 30e:	f104 0140 	add.w	r1, r4, #64	@ 0x40
 312:	f8d4 b03c 	ldr.w	fp, [r4, #60]	@ 0x3c
 316:	f8d1 c00c 	ldr.w	ip, [r1, #12]
 31a:	eb08 0585 	add.w	r5, r8, r5, lsl #2
 31e:	eb06 0383 	add.w	r3, r6, r3, lsl #2
 322:	d928      	bls.n	376 <Backend_EventApply+0x376>
 324:	e012      	b.n	34c <Backend_EventApply+0x34c>
 326:	bf00      	nop
	...
			328: R_ARM_ABS32	.rodata.Backend_StateLog.str1.4
			32c: R_ARM_ABS32	.bss.s_state
			330: R_ARM_ABS32	.bss.silverstar_auto_eskf_history
			334: R_ARM_ABS32	.bss.s_eskf_replay_timing
			338: R_ARM_ABS32	.bss.silverstar_auto_eskf_work
			33c: R_ARM_ABS32	.rodata.s_config
			340: R_ARM_ABS32	.bss.s_operation
			344: R_ARM_ABS32	.bss.s_calibration_generation
			348: R_ARM_ABS32	.bss.s_log_failures
 34c:	428b      	cmp	r3, r1
 34e:	f8c5 b00c 	str.w	fp, [r5, #12]
 352:	f8c5 c028 	str.w	ip, [r5, #40]	@ 0x28
 356:	d01f      	beq.n	398 <Backend_EventApply+0x398>
 358:	f851 bb04 	ldr.w	fp, [r1], #4
 35c:	3504      	adds	r5, #4
 35e:	f8d1 c00c 	ldr.w	ip, [r1, #12]
 362:	f8c5 c028 	str.w	ip, [r5, #40]	@ 0x28
 366:	428b      	cmp	r3, r1
 368:	f8c5 b00c 	str.w	fp, [r5, #12]
 36c:	d1f4      	bne.n	358 <Backend_EventApply+0x358>
 36e:	e013      	b.n	398 <Backend_EventApply+0x398>
 370:	4650      	mov	r0, sl
 372:	4662      	mov	r2, ip
 374:	e68c      	b.n	90 <Backend_EventApply+0x90>
 376:	428b      	cmp	r3, r1
 378:	f8c5 b000 	str.w	fp, [r5]
 37c:	f8c5 c01c 	str.w	ip, [r5, #28]
 380:	d00a      	beq.n	398 <Backend_EventApply+0x398>
 382:	f851 bb04 	ldr.w	fp, [r1], #4
 386:	3504      	adds	r5, #4
 388:	f8d1 c00c 	ldr.w	ip, [r1, #12]
 38c:	f8c5 c01c 	str.w	ip, [r5, #28]
 390:	428b      	cmp	r3, r1
 392:	f8c5 b000 	str.w	fp, [r5]
 396:	d1f4      	bne.n	382 <Backend_EventApply+0x382>
 398:	2a01      	cmp	r2, #1
 39a:	6d63      	ldr	r3, [r4, #84]	@ 0x54
 39c:	f240 810c 	bls.w	5b8 <Backend_EventApply+0x5b8>
 3a0:	2a02      	cmp	r2, #2
 3a2:	f8c8 3140 	str.w	r3, [r8, #320]	@ 0x140
 3a6:	f8c8 e14c 	str.w	lr, [r8, #332]	@ 0x14c
 3aa:	d003      	beq.n	3b4 <Backend_EventApply+0x3b4>
 3ac:	f898 31af 	ldrb.w	r3, [r8, #431]	@ 0x1af
 3b0:	42bb      	cmp	r3, r7
 3b2:	d901      	bls.n	3b8 <Backend_EventApply+0x3b8>
 3b4:	f888 71af 	strb.w	r7, [r8, #431]	@ 0x1af
 3b8:	2800      	cmp	r0, #0
 3ba:	f000 8133 	beq.w	624 <Backend_EventApply+0x624>
 3be:	f8d8 3168 	ldr.w	r3, [r8, #360]	@ 0x168
 3c2:	3301      	adds	r3, #1
 3c4:	f8c8 3168 	str.w	r3, [r8, #360]	@ 0x168
 3c8:	e018      	b.n	3fc <Backend_EventApply+0x3fc>
 3ca:	6ce3      	ldr	r3, [r4, #76]	@ 0x4c
 3cc:	6be2      	ldr	r2, [r4, #60]	@ 0x3c
 3ce:	f888 71b0 	strb.w	r7, [r8, #432]	@ 0x1b0
 3d2:	f041 0104 	orr.w	r1, r1, #4
 3d6:	f8c8 3138 	str.w	r3, [r8, #312]	@ 0x138
 3da:	6d63      	ldr	r3, [r4, #84]	@ 0x54
 3dc:	f8c8 1184 	str.w	r1, [r8, #388]	@ 0x184
 3e0:	f8c8 211c 	str.w	r2, [r8, #284]	@ 0x11c
 3e4:	f8c8 e150 	str.w	lr, [r8, #336]	@ 0x150
 3e8:	f8c8 3144 	str.w	r3, [r8, #324]	@ 0x144
 3ec:	2800      	cmp	r0, #0
 3ee:	f040 80dd 	bne.w	5ac <Backend_EventApply+0x5ac>
 3f2:	f8d8 3178 	ldr.w	r3, [r8, #376]	@ 0x178
 3f6:	3301      	adds	r3, #1
 3f8:	f8c8 3178 	str.w	r3, [r8, #376]	@ 0x178
 3fc:	f44f 7395 	mov.w	r3, #298	@ 0x12a
 400:	9300      	str	r3, [sp, #0]
 402:	2202      	movs	r2, #2
 404:	4b8d      	ldr	r3, [pc, #564]	@ (63c <Backend_EventApply+0x63c>)
 406:	2108      	movs	r1, #8
 408:	4620      	mov	r0, r4
 40a:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			40a: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
 40e:	2102      	movs	r1, #2
 410:	9100      	str	r1, [sp, #0]
 412:	f894 0030 	ldrb.w	r0, [r4, #48]	@ 0x30
 416:	4a89      	ldr	r2, [pc, #548]	@ (63c <Backend_EventApply+0x63c>)
 418:	2804      	cmp	r0, #4
 41a:	bf8c      	ite	hi
 41c:	2000      	movhi	r0, #0
 41e:	2001      	movls	r0, #1
 420:	f240 132b 	movw	r3, #299	@ 0x12b
 424:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			424: R_ARM_THM_CALL	SilverStarAssert_Check
 428:	ed94 7b00 	vldr	d7, [r4]
 42c:	ed8d 7b1a 	vstr	d7, [sp, #104]	@ 0x68
 430:	ed94 7b02 	vldr	d7, [r4, #8]
 434:	2301      	movs	r3, #1
 436:	f88d 30d8 	strb.w	r3, [sp, #216]	@ 0xd8
 43a:	6d63      	ldr	r3, [r4, #84]	@ 0x54
 43c:	932f      	str	r3, [sp, #188]	@ 0xbc
 43e:	ed8d 7b1c 	vstr	d7, [sp, #112]	@ 0x70
 442:	6da3      	ldr	r3, [r4, #88]	@ 0x58
 444:	9330      	str	r3, [sp, #192]	@ 0xc0
 446:	ed94 7b04 	vldr	d7, [r4, #16]
 44a:	6de3      	ldr	r3, [r4, #92]	@ 0x5c
 44c:	9331      	str	r3, [sp, #196]	@ 0xc4
 44e:	6e23      	ldr	r3, [r4, #96]	@ 0x60
 450:	9332      	str	r3, [sp, #200]	@ 0xc8
 452:	ed8d 7b1e 	vstr	d7, [sp, #120]	@ 0x78
 456:	6a63      	ldr	r3, [r4, #36]	@ 0x24
 458:	9323      	str	r3, [sp, #140]	@ 0x8c
 45a:	ed94 7b06 	vldr	d7, [r4, #24]
 45e:	6aa3      	ldr	r3, [r4, #40]	@ 0x28
 460:	9324      	str	r3, [sp, #144]	@ 0x90
 462:	6ae3      	ldr	r3, [r4, #44]	@ 0x2c
 464:	9325      	str	r3, [sp, #148]	@ 0x94
 466:	ed8d 7b20 	vstr	d7, [sp, #128]	@ 0x80
 46a:	6a23      	ldr	r3, [r4, #32]
 46c:	9322      	str	r3, [sp, #136]	@ 0x88
 46e:	ed94 7b1a 	vldr	d7, [r4, #104]	@ 0x68
 472:	6b23      	ldr	r3, [r4, #48]	@ 0x30
 474:	f894 0075 	ldrb.w	r0, [r4, #117]	@ 0x75
 478:	9326      	str	r3, [sp, #152]	@ 0x98
 47a:	2100      	movs	r1, #0
 47c:	f894 3074 	ldrb.w	r3, [r4, #116]	@ 0x74
 480:	f88d 30d9 	strb.w	r3, [sp, #217]	@ 0xd9
 484:	ed8d 7b34 	vstr	d7, [sp, #208]	@ 0xd0
 488:	f88d 00da 	strb.w	r0, [sp, #218]	@ 0xda
 48c:	f88d 10db 	strb.w	r1, [sp, #219]	@ 0xdb
 490:	6f21      	ldr	r1, [r4, #112]	@ 0x70
 492:	9137      	str	r1, [sp, #220]	@ 0xdc
 494:	e89a 0003 	ldmia.w	sl, {r0, r1}
 498:	f10d 0e9c 	add.w	lr, sp, #156	@ 0x9c
 49c:	e88e 0003 	stmia.w	lr, {r0, r1}
 4a0:	e896 0003 	ldmia.w	r6, {r0, r1}
 4a4:	f10d 0ca4 	add.w	ip, sp, #164	@ 0xa4
 4a8:	f104 0744 	add.w	r7, r4, #68	@ 0x44
 4ac:	e88c 0003 	stmia.w	ip, {r0, r1}
 4b0:	e897 0003 	ldmia.w	r7, {r0, r1}
 4b4:	ad2b      	add	r5, sp, #172	@ 0xac
 4b6:	e885 0003 	stmia.w	r5, {r0, r1}
 4ba:	e899 0003 	ldmia.w	r9, {r0, r1}
 4be:	ab2d      	add	r3, sp, #180	@ 0xb4
 4c0:	e883 0003 	stmia.w	r3, {r0, r1}
 4c4:	4b5e      	ldr	r3, [pc, #376]	@ (640 <Backend_EventApply+0x640>)
 4c6:	aa1a      	add	r2, sp, #104	@ 0x68
 4c8:	e9d3 01f2 	ldrd	r0, r1, [r3, #968]	@ 0x3c8
 4cc:	f7ff fffe 	bl	0 <LoggerBus_Eskf15MeasurementPush>
			4cc: R_ARM_THM_CALL	LoggerBus_Eskf15MeasurementPush
 4d0:	b118      	cbz	r0, 4da <Backend_EventApply+0x4da>
 4d2:	4a5c      	ldr	r2, [pc, #368]	@ (644 <Backend_EventApply+0x644>)
 4d4:	6813      	ldr	r3, [r2, #0]
 4d6:	3301      	adds	r3, #1
 4d8:	6013      	str	r3, [r2, #0]
 4da:	b039      	add	sp, #228	@ 0xe4
 4dc:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 4e0:	f413 437f 	ands.w	r3, r3, #65280	@ 0xff00
 4e4:	bf18      	it	ne
 4e6:	2301      	movne	r3, #1
 4e8:	f89d 7035 	ldrb.w	r7, [sp, #53]	@ 0x35
 4ec:	f884 3032 	strb.w	r3, [r4, #50]	@ 0x32
 4f0:	e667      	b.n	1c2 <Backend_EventApply+0x1c2>
 4f2:	9903      	ldr	r1, [sp, #12]
 4f4:	ebb0 020a 	subs.w	r2, r0, sl
 4f8:	eb61 000b 	sbc.w	r0, r1, fp
 4fc:	f04f 31ff 	mov.w	r1, #4294967295
 500:	2800      	cmp	r0, #0
 502:	d140      	bne.n	586 <Backend_EventApply+0x586>
 504:	6831      	ldr	r1, [r6, #0]
 506:	e9dd ab02 	ldrd	sl, fp, [sp, #8]
 50a:	3101      	adds	r1, #1
 50c:	6031      	str	r1, [r6, #0]
 50e:	e9c6 ab04 	strd	sl, fp, [r6, #16]
 512:	6332      	str	r2, [r6, #48]	@ 0x30
 514:	f886 3040 	strb.w	r3, [r6, #64]	@ 0x40
 518:	6b71      	ldr	r1, [r6, #52]	@ 0x34
 51a:	4291      	cmp	r1, r2
 51c:	d204      	bcs.n	528 <Backend_EventApply+0x528>
 51e:	6372      	str	r2, [r6, #52]	@ 0x34
 520:	e9c6 ab06 	strd	sl, fp, [r6, #24]
 524:	f886 3041 	strb.w	r3, [r6, #65]	@ 0x41
 528:	f644 631f 	movw	r3, #19999	@ 0x4e1f
 52c:	429a      	cmp	r2, r3
 52e:	f67f ae01 	bls.w	134 <Backend_EventApply+0x134>
 532:	6bb3      	ldr	r3, [r6, #56]	@ 0x38
 534:	3301      	adds	r3, #1
 536:	f43f adfd 	beq.w	134 <Backend_EventApply+0x134>
 53a:	e9d6 2308 	ldrd	r2, r3, [r6, #32]
 53e:	431a      	orrs	r2, r3
 540:	bf04      	itt	eq
 542:	e9dd 2302 	ldrdeq	r2, r3, [sp, #8]
 546:	e9c6 2308 	strdeq	r2, r3, [r6, #32]
 54a:	e9dd 2302 	ldrd	r2, r3, [sp, #8]
 54e:	e9c6 230a 	strd	r2, r3, [r6, #40]	@ 0x28
 552:	6bb3      	ldr	r3, [r6, #56]	@ 0x38
 554:	3301      	adds	r3, #1
 556:	63b3      	str	r3, [r6, #56]	@ 0x38
 558:	e5ec      	b.n	134 <Backend_EventApply+0x134>
 55a:	4b3b      	ldr	r3, [pc, #236]	@ (648 <Backend_EventApply+0x648>)
 55c:	5c1b      	ldrb	r3, [r3, r0]
 55e:	f884 3075 	strb.w	r3, [r4, #117]	@ 0x75
 562:	2800      	cmp	r0, #0
 564:	f47f adcb 	bne.w	fe <Backend_EventApply+0xfe>
 568:	7f6b      	ldrb	r3, [r5, #29]
 56a:	2b00      	cmp	r3, #0
 56c:	f43f adc7 	beq.w	fe <Backend_EventApply+0xfe>
 570:	e9d5 0100 	ldrd	r0, r1, [r5]
 574:	f894 3074 	ldrb.w	r3, [r4, #116]	@ 0x74
 578:	f043 0302 	orr.w	r3, r3, #2
 57c:	e9c4 011a 	strd	r0, r1, [r4, #104]	@ 0x68
 580:	f884 3074 	strb.w	r3, [r4, #116]	@ 0x74
 584:	e5bb      	b.n	fe <Backend_EventApply+0xfe>
 586:	6832      	ldr	r2, [r6, #0]
 588:	e9dd ab02 	ldrd	sl, fp, [sp, #8]
 58c:	3201      	adds	r2, #1
 58e:	6032      	str	r2, [r6, #0]
 590:	e9c6 ab04 	strd	sl, fp, [r6, #16]
 594:	6331      	str	r1, [r6, #48]	@ 0x30
 596:	f886 3040 	strb.w	r3, [r6, #64]	@ 0x40
 59a:	6b72      	ldr	r2, [r6, #52]	@ 0x34
 59c:	3201      	adds	r2, #1
 59e:	d0c8      	beq.n	532 <Backend_EventApply+0x532>
 5a0:	6371      	str	r1, [r6, #52]	@ 0x34
 5a2:	e9c6 ab06 	strd	sl, fp, [r6, #24]
 5a6:	f886 3041 	strb.w	r3, [r6, #65]	@ 0x41
 5aa:	e7c2      	b.n	532 <Backend_EventApply+0x532>
 5ac:	f8d8 316c 	ldr.w	r3, [r8, #364]	@ 0x16c
 5b0:	3301      	adds	r3, #1
 5b2:	f8c8 316c 	str.w	r3, [r8, #364]	@ 0x16c
 5b6:	e721      	b.n	3fc <Backend_EventApply+0x3fc>
 5b8:	f8c8 313c 	str.w	r3, [r8, #316]	@ 0x13c
 5bc:	f8c8 e148 	str.w	lr, [r8, #328]	@ 0x148
 5c0:	bb5a      	cbnz	r2, 61a <Backend_EventApply+0x61a>
 5c2:	f888 71ae 	strb.w	r7, [r8, #430]	@ 0x1ae
 5c6:	b398      	cbz	r0, 630 <Backend_EventApply+0x630>
 5c8:	f8d8 3164 	ldr.w	r3, [r8, #356]	@ 0x164
 5cc:	3301      	adds	r3, #1
 5ce:	f8c8 3164 	str.w	r3, [r8, #356]	@ 0x164
 5d2:	e713      	b.n	3fc <Backend_EventApply+0x3fc>
 5d4:	2300      	movs	r3, #0
 5d6:	e644      	b.n	262 <Backend_EventApply+0x262>
 5d8:	1a36      	subs	r6, r6, r0
 5da:	46ac      	mov	ip, r5
 5dc:	eb67 0702 	sbc.w	r7, r7, r2
 5e0:	46a6      	mov	lr, r4
 5e2:	ebbc 0c00 	subs.w	ip, ip, r0
 5e6:	eb6e 0e02 	sbc.w	lr, lr, r2
 5ea:	ea4f 0c5c 	mov.w	ip, ip, lsr #1
 5ee:	ea4c 7cce 	orr.w	ip, ip, lr, lsl #31
 5f2:	45b4      	cmp	ip, r6
 5f4:	ea4f 0e5e 	mov.w	lr, lr, lsr #1
 5f8:	eb7e 0e07 	sbcs.w	lr, lr, r7
 5fc:	bf34      	ite	cc
 5fe:	230c      	movcc	r3, #12
 600:	2300      	movcs	r3, #0
 602:	3308      	adds	r3, #8
 604:	18ca      	adds	r2, r1, r3
 606:	58c8      	ldr	r0, [r1, r3]
 608:	6851      	ldr	r1, [r2, #4]
 60a:	6892      	ldr	r2, [r2, #8]
 60c:	9d04      	ldr	r5, [sp, #16]
 60e:	465c      	mov	r4, fp
 610:	f8dd b014 	ldr.w	fp, [sp, #20]
 614:	e8ab 0007 	stmia.w	fp!, {r0, r1, r2}
 618:	e54d      	b.n	b6 <Backend_EventApply+0xb6>
 61a:	f898 31ae 	ldrb.w	r3, [r8, #430]	@ 0x1ae
 61e:	42bb      	cmp	r3, r7
 620:	d9d1      	bls.n	5c6 <Backend_EventApply+0x5c6>
 622:	e7ce      	b.n	5c2 <Backend_EventApply+0x5c2>
 624:	f8d8 3174 	ldr.w	r3, [r8, #372]	@ 0x174
 628:	3301      	adds	r3, #1
 62a:	f8c8 3174 	str.w	r3, [r8, #372]	@ 0x174
 62e:	e6e5      	b.n	3fc <Backend_EventApply+0x3fc>
 630:	f8d8 3170 	ldr.w	r3, [r8, #368]	@ 0x170
 634:	3301      	adds	r3, #1
 636:	f8c8 3170 	str.w	r3, [r8, #368]	@ 0x170
 63a:	e6df      	b.n	3fc <Backend_EventApply+0x3fc>
	...
			63c: R_ARM_ABS32	.rodata.Backend_StateLog.str1.4
			640: R_ARM_ABS32	.bss.s_state
			644: R_ARM_ABS32	.bss.s_log_failures
			648: R_ARM_ABS32	.rodata.CSWTCH.98

Disassembly of section .text.SystemNavigationBackend_Reset:

00000000 <SystemNavigationBackend_Reset>:
   0:	4819      	ldr	r0, [pc, #100]	@ (68 <SystemNavigationBackend_Reset+0x68>)
   2:	491a      	ldr	r1, [pc, #104]	@ (6c <SystemNavigationBackend_Reset+0x6c>)
   4:	4b1a      	ldr	r3, [pc, #104]	@ (70 <SystemNavigationBackend_Reset+0x70>)
   6:	4a1b      	ldr	r2, [pc, #108]	@ (74 <SystemNavigationBackend_Reset+0x74>)
   8:	b510      	push	{r4, lr}
   a:	2400      	movs	r4, #0
   c:	700c      	strb	r4, [r1, #0]
   e:	7004      	strb	r4, [r0, #0]
  10:	4919      	ldr	r1, [pc, #100]	@ (78 <SystemNavigationBackend_Reset+0x78>)
  12:	481a      	ldr	r0, [pc, #104]	@ (7c <SystemNavigationBackend_Reset+0x7c>)
  14:	701c      	strb	r4, [r3, #0]
  16:	4b1a      	ldr	r3, [pc, #104]	@ (80 <SystemNavigationBackend_Reset+0x80>)
  18:	7014      	strb	r4, [r2, #0]
  1a:	f880 43d8 	strb.w	r4, [r0, #984]	@ 0x3d8
  1e:	600c      	str	r4, [r1, #0]
  20:	2248      	movs	r2, #72	@ 0x48
  22:	4621      	mov	r1, r4
  24:	4817      	ldr	r0, [pc, #92]	@ (84 <SystemNavigationBackend_Reset+0x84>)
  26:	601c      	str	r4, [r3, #0]
  28:	f7ff fffe 	bl	0 <memset>
			28: R_ARM_THM_CALL	memset
  2c:	ed9f 7b0c 	vldr	d7, [pc, #48]	@ 60 <SystemNavigationBackend_Reset+0x60>
  30:	4b15      	ldr	r3, [pc, #84]	@ (88 <SystemNavigationBackend_Reset+0x88>)
  32:	4916      	ldr	r1, [pc, #88]	@ (8c <SystemNavigationBackend_Reset+0x8c>)
  34:	4a16      	ldr	r2, [pc, #88]	@ (90 <SystemNavigationBackend_Reset+0x90>)
  36:	ed83 7b00 	vstr	d7, [r3]
  3a:	2000      	movs	r0, #0
  3c:	4b15      	ldr	r3, [pc, #84]	@ (94 <SystemNavigationBackend_Reset+0x94>)
  3e:	6008      	str	r0, [r1, #0]
  40:	7014      	strb	r4, [r2, #0]
  42:	4815      	ldr	r0, [pc, #84]	@ (98 <SystemNavigationBackend_Reset+0x98>)
  44:	4915      	ldr	r1, [pc, #84]	@ (9c <SystemNavigationBackend_Reset+0x9c>)
  46:	4a16      	ldr	r2, [pc, #88]	@ (a0 <SystemNavigationBackend_Reset+0xa0>)
  48:	701c      	strb	r4, [r3, #0]
  4a:	6004      	str	r4, [r0, #0]
  4c:	600c      	str	r4, [r1, #0]
  4e:	6014      	str	r4, [r2, #0]
  50:	4814      	ldr	r0, [pc, #80]	@ (a4 <SystemNavigationBackend_Reset+0xa4>)
  52:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
  56:	f7ff bffe 	b.w	0 <NavigationWindow_Reset>
			56: R_ARM_THM_JUMP24	NavigationWindow_Reset
  5a:	bf00      	nop
  5c:	f3af 8000 	nop.w
	...
			68: R_ARM_ABS32	.bss.s_active
			6c: R_ARM_ABS32	.bss.s_started
			70: R_ARM_ABS32	.bss.s_baro_seen
			74: R_ARM_ABS32	.bss.s_gnss_seen
			78: R_ARM_ABS32	.bss.s_operation
			7c: R_ARM_ABS32	.bss.s_state
			80: R_ARM_ABS32	.bss.s_snapshot_id
			84: R_ARM_ABS32	.bss.s_frame
			88: R_ARM_ABS32	.bss.s_native_week_us
			8c: R_ARM_ABS32	.bss.s_baro_origin
			90: R_ARM_ABS32	.bss.s_baro_origin_valid
			94: R_ARM_ABS32	.bss.s_input_faulted
			98: R_ARM_ABS32	.bss.s_native_tow_ms
			9c: R_ARM_ABS32	.bss.s_log_failures
			a0: R_ARM_ABS32	.bss.s_imu_quality_flags
			a4: R_ARM_ABS32	.bss.silverstar_auto_eskf_window

Disassembly of section .text.SystemNavigationBackend_Initialize:

00000000 <SystemNavigationBackend_Initialize>:
   0:	e92d 4df0 	stmdb	sp!, {r4, r5, r6, r7, r8, sl, fp, lr}
   4:	ed2d 8b02 	vpush	{d8}
   8:	b096      	sub	sp, #88	@ 0x58
   a:	4604      	mov	r4, r0
   c:	460d      	mov	r5, r1
   e:	4616      	mov	r6, r2
  10:	2100      	movs	r1, #0
  12:	2240      	movs	r2, #64	@ 0x40
  14:	a806      	add	r0, sp, #24
  16:	f89d 8080 	ldrb.w	r8, [sp, #128]	@ 0x80
  1a:	eeb0 8a40 	vmov.f32	s16, s0
  1e:	461f      	mov	r7, r3
  20:	f7ff fffe 	bl	0 <memset>
			20: R_ARM_THM_CALL	memset
  24:	2c00      	cmp	r4, #0
  26:	f000 8097 	beq.w	158 <SystemNavigationBackend_Initialize+0x158>
  2a:	2d00      	cmp	r5, #0
  2c:	f000 8094 	beq.w	158 <SystemNavigationBackend_Initialize+0x158>
  30:	2e01      	cmp	r6, #1
  32:	f200 8091 	bhi.w	158 <SystemNavigationBackend_Initialize+0x158>
  36:	eddf 7a51 	vldr	s15, [pc, #324]	@ 17c <SystemNavigationBackend_Initialize+0x17c>
  3a:	eeb0 7ac8 	vabs.f32	s14, s16
  3e:	eeb4 7a67 	vcmp.f32	s14, s15
  42:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  46:	f200 8087 	bhi.w	158 <SystemNavigationBackend_Initialize+0x158>
  4a:	23de      	movs	r3, #222	@ 0xde
  4c:	9300      	str	r3, [sp, #0]
  4e:	2202      	movs	r2, #2
  50:	4b4b      	ldr	r3, [pc, #300]	@ (180 <SystemNavigationBackend_Initialize+0x180>)
  52:	2104      	movs	r1, #4
  54:	4620      	mov	r0, r4
  56:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			56: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  5a:	23df      	movs	r3, #223	@ 0xdf
  5c:	4628      	mov	r0, r5
  5e:	9300      	str	r3, [sp, #0]
  60:	2202      	movs	r2, #2
  62:	4b47      	ldr	r3, [pc, #284]	@ (180 <SystemNavigationBackend_Initialize+0x180>)
  64:	2108      	movs	r1, #8
  66:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			66: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  6a:	f7ff fffe 	bl	0 <SystemNavigationBackend_Initialize>
			6a: R_ARM_THM_CALL	SystemNavigationBackend_Reset
  6e:	4845      	ldr	r0, [pc, #276]	@ (184 <SystemNavigationBackend_Initialize+0x184>)
  70:	f7ff fffe 	bl	0 <NavigationEskf_ConfigValidate>
			70: R_ARM_THM_CALL	NavigationEskf_ConfigValidate
  74:	2800      	cmp	r0, #0
  76:	d176      	bne.n	166 <SystemNavigationBackend_Initialize+0x166>
  78:	4843      	ldr	r0, [pc, #268]	@ (188 <SystemNavigationBackend_Initialize+0x188>)
  7a:	f7ff fffe 	bl	0 <NavigationWindow_ConfigValidate>
			7a: R_ARM_THM_CALL	NavigationWindow_ConfigValidate
  7e:	2800      	cmp	r0, #0
  80:	d171      	bne.n	166 <SystemNavigationBackend_Initialize+0x166>
  82:	f10d 0017 	add.w	r0, sp, #23
  86:	f7ff fffe 	bl	0 <SystemSourceSelector_ImuActiveInstanceGet>
			86: R_ARM_THM_CALL	SystemSourceSelector_ImuActiveInstanceGet
  8a:	2800      	cmp	r0, #0
  8c:	d172      	bne.n	174 <SystemNavigationBackend_Initialize+0x174>
  8e:	6820      	ldr	r0, [r4, #0]
  90:	6861      	ldr	r1, [r4, #4]
  92:	68a2      	ldr	r2, [r4, #8]
  94:	68e3      	ldr	r3, [r4, #12]
  96:	f895 c074 	ldrb.w	ip, [r5, #116]	@ 0x74
  9a:	ac0c      	add	r4, sp, #48	@ 0x30
  9c:	c40f      	stmia	r4!, {r0, r1, r2, r3}
  9e:	f1bc 0f00 	cmp.w	ip, #0
  a2:	d01f      	beq.n	e4 <SystemNavigationBackend_Initialize+0xe4>
  a4:	4839      	ldr	r0, [pc, #228]	@ (18c <SystemNavigationBackend_Initialize+0x18c>)
  a6:	f7ff fffe 	bl	0 <SystemSourceSelector_GnssActiveInstanceGet>
			a6: R_ARM_THM_CALL	SystemSourceSelector_GnssActiveInstanceGet
  aa:	2800      	cmp	r0, #0
  ac:	d162      	bne.n	174 <SystemNavigationBackend_Initialize+0x174>
  ae:	e9d5 2310 	ldrd	r2, r3, [r5, #64]	@ 0x40
  b2:	6be9      	ldr	r1, [r5, #60]	@ 0x3c
  b4:	4836      	ldr	r0, [pc, #216]	@ (190 <SystemNavigationBackend_Initialize+0x190>)
  b6:	f7ff fffe 	bl	0 <GeoLocalFrame_Init>
			b6: R_ARM_THM_CALL	GeoLocalFrame_Init
  ba:	2800      	cmp	r0, #0
  bc:	d05a      	beq.n	174 <SystemNavigationBackend_Initialize+0x174>
  be:	f895 0070 	ldrb.w	r0, [r5, #112]	@ 0x70
  c2:	a909      	add	r1, sp, #36	@ 0x24
  c4:	354c      	adds	r5, #76	@ 0x4c
  c6:	2300      	movs	r3, #0
  c8:	fa20 f203 	lsr.w	r2, r0, r3
  cc:	f012 0f01 	tst.w	r2, #1
  d0:	bf1c      	itt	ne
  d2:	682a      	ldrne	r2, [r5, #0]
  d4:	600a      	strne	r2, [r1, #0]
  d6:	3301      	adds	r3, #1
  d8:	2b03      	cmp	r3, #3
  da:	f105 0504 	add.w	r5, r5, #4
  de:	f101 0104 	add.w	r1, r1, #4
  e2:	d1f1      	bne.n	c8 <SystemNavigationBackend_Initialize+0xc8>
  e4:	2100      	movs	r1, #0
  e6:	482b      	ldr	r0, [pc, #172]	@ (194 <SystemNavigationBackend_Initialize+0x194>)
  e8:	f44f 7261 	mov.w	r2, #900	@ 0x384
  ec:	f7ff fffe 	bl	0 <memset>
			ec: R_ARM_THM_CALL	memset
  f0:	4929      	ldr	r1, [pc, #164]	@ (198 <SystemNavigationBackend_Initialize+0x198>)
  f2:	4b28      	ldr	r3, [pc, #160]	@ (194 <SystemNavigationBackend_Initialize+0x194>)
  f4:	f101 003c 	add.w	r0, r1, #60	@ 0x3c
  f8:	f851 2b04 	ldr.w	r2, [r1], #4
  fc:	f843 2b40 	str.w	r2, [r3], #64
 100:	4281      	cmp	r1, r0
 102:	d1f9      	bne.n	f8 <SystemNavigationBackend_Initialize+0xf8>
 104:	f89d 3017 	ldrb.w	r3, [sp, #23]
 108:	4824      	ldr	r0, [pc, #144]	@ (19c <SystemNavigationBackend_Initialize+0x19c>)
 10a:	e9cd 3702 	strd	r3, r7, [sp, #8]
 10e:	4b21      	ldr	r3, [pc, #132]	@ (194 <SystemNavigationBackend_Initialize+0x194>)
 110:	f04f 0a00 	mov.w	sl, #0
 114:	f04f 0b00 	mov.w	fp, #0
 118:	e9cd ab00 	strd	sl, fp, [sp]
 11c:	aa06      	add	r2, sp, #24
 11e:	4619      	mov	r1, r3
 120:	f7ff fffe 	bl	0 <NavigationEskf_Initialize>
			120: R_ARM_THM_CALL	NavigationEskf_Initialize
 124:	b9f8      	cbnz	r0, 166 <SystemNavigationBackend_Initialize+0x166>
 126:	4a1e      	ldr	r2, [pc, #120]	@ (1a0 <SystemNavigationBackend_Initialize+0x1a0>)
 128:	491c      	ldr	r1, [pc, #112]	@ (19c <SystemNavigationBackend_Initialize+0x19c>)
 12a:	481e      	ldr	r0, [pc, #120]	@ (1a4 <SystemNavigationBackend_Initialize+0x1a4>)
 12c:	f7ff fffe 	bl	0 <NavigationEskfReplay_Reset>
			12c: R_ARM_THM_CALL	NavigationEskfReplay_Reset
 130:	4604      	mov	r4, r0
 132:	bb08      	cbnz	r0, 178 <SystemNavigationBackend_Initialize+0x178>
 134:	4b1c      	ldr	r3, [pc, #112]	@ (1a8 <SystemNavigationBackend_Initialize+0x1a8>)
 136:	ed83 8a00 	vstr	s16, [r3]
 13a:	4b1c      	ldr	r3, [pc, #112]	@ (1ac <SystemNavigationBackend_Initialize+0x1ac>)
 13c:	701e      	strb	r6, [r3, #0]
 13e:	4b1c      	ldr	r3, [pc, #112]	@ (1b0 <SystemNavigationBackend_Initialize+0x1b0>)
 140:	f883 8000 	strb.w	r8, [r3]
 144:	f7ff fffe 	bl	0 <SystemCalibration_GenerationGet>
			144: R_ARM_THM_CALL	SystemCalibration_GenerationGet
 148:	4b1a      	ldr	r3, [pc, #104]	@ (1b4 <SystemNavigationBackend_Initialize+0x1b4>)
 14a:	4602      	mov	r2, r0
 14c:	4659      	mov	r1, fp
 14e:	4650      	mov	r0, sl
 150:	601a      	str	r2, [r3, #0]
 152:	f7ff fffe 	bl	0 <SystemNavigationHealth_Reset>
			152: R_ARM_THM_CALL	SystemNavigationHealth_Reset
 156:	e000      	b.n	15a <SystemNavigationBackend_Initialize+0x15a>
 158:	2405      	movs	r4, #5
 15a:	4620      	mov	r0, r4
 15c:	b016      	add	sp, #88	@ 0x58
 15e:	ecbd 8b02 	vpop	{d8}
 162:	e8bd 8df0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, sl, fp, pc}
 166:	2408      	movs	r4, #8
 168:	4620      	mov	r0, r4
 16a:	b016      	add	sp, #88	@ 0x58
 16c:	ecbd 8b02 	vpop	{d8}
 170:	e8bd 8df0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, sl, fp, pc}
 174:	2402      	movs	r4, #2
 176:	e7f0      	b.n	15a <SystemNavigationBackend_Initialize+0x15a>
 178:	240b      	movs	r4, #11
 17a:	e7ee      	b.n	15a <SystemNavigationBackend_Initialize+0x15a>
 17c:	7f7fffff 	.word	0x7f7fffff
	...
			180: R_ARM_ABS32	.rodata.Backend_StateLog.str1.4
			184: R_ARM_ABS32	.rodata.s_config
			188: R_ARM_ABS32	.rodata.s_window_config
			18c: R_ARM_ABS32	.bss.s_gnss_source
			190: R_ARM_ABS32	.bss.s_frame
			194: R_ARM_ABS32	.bss.silverstar_auto_eskf_work
			198: R_ARM_ABS32	.rodata.s_initial_diagonal
			19c: R_ARM_ABS32	.bss.s_state
			1a0: R_ARM_ABS32	.bss.s_body_history
			1a4: R_ARM_ABS32	.bss.silverstar_auto_eskf_history
			1a8: R_ARM_ABS32	.bss.s_baro_origin
			1ac: R_ARM_ABS32	.bss.s_baro_origin_valid
			1b0: R_ARM_ABS32	.bss.s_active
			1b4: R_ARM_ABS32	.bss.s_calibration_generation

Disassembly of section .text.SystemNavigationBackend_SnapshotGet:

00000000 <SystemNavigationBackend_SnapshotGet>:
   0:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
   4:	b082      	sub	sp, #8
   6:	2800      	cmp	r0, #0
   8:	f000 8089 	beq.w	11e <SystemNavigationBackend_SnapshotGet+0x11e>
   c:	4e46      	ldr	r6, [pc, #280]	@ (128 <SystemNavigationBackend_SnapshotGet+0x128>)
   e:	f896 33d8 	ldrb.w	r3, [r6, #984]	@ 0x3d8
  12:	2b00      	cmp	r3, #0
  14:	d078      	beq.n	108 <SystemNavigationBackend_SnapshotGet+0x108>
  16:	4b45      	ldr	r3, [pc, #276]	@ (12c <SystemNavigationBackend_SnapshotGet+0x12c>)
  18:	781f      	ldrb	r7, [r3, #0]
  1a:	2f00      	cmp	r7, #0
  1c:	d174      	bne.n	108 <SystemNavigationBackend_SnapshotGet+0x108>
  1e:	f240 4346 	movw	r3, #1094	@ 0x446
  22:	9300      	str	r3, [sp, #0]
  24:	2202      	movs	r2, #2
  26:	4b42      	ldr	r3, [pc, #264]	@ (130 <SystemNavigationBackend_SnapshotGet+0x130>)
  28:	2108      	movs	r1, #8
  2a:	4604      	mov	r4, r0
  2c:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			2c: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  30:	e9d6 23f2 	ldrd	r2, r3, [r6, #968]	@ 0x3c8
  34:	e9c4 2300 	strd	r2, r3, [r4]
  38:	4a3e      	ldr	r2, [pc, #248]	@ (134 <SystemNavigationBackend_SnapshotGet+0x134>)
  3a:	4b3f      	ldr	r3, [pc, #252]	@ (138 <SystemNavigationBackend_SnapshotGet+0x138>)
  3c:	f892 1040 	ldrb.w	r1, [r2, #64]	@ 0x40
  40:	781a      	ldrb	r2, [r3, #0]
  42:	4b3e      	ldr	r3, [pc, #248]	@ (13c <SystemNavigationBackend_SnapshotGet+0x13c>)
  44:	f896 53d8 	ldrb.w	r5, [r6, #984]	@ 0x3d8
  48:	7818      	ldrb	r0, [r3, #0]
  4a:	463b      	mov	r3, r7
  4c:	f365 0307 	bfi	r3, r5, #0, #8
  50:	f360 230f 	bfi	r3, r0, #8, #8
  54:	f361 4317 	bfi	r3, r1, #16, #8
  58:	f362 631f 	bfi	r3, r2, #24, #8
  5c:	f8c4 31a8 	str.w	r3, [r4, #424]	@ 0x1a8
  60:	f8d4 3180 	ldr.w	r3, [r4, #384]	@ 0x180
  64:	b909      	cbnz	r1, 6a <SystemNavigationBackend_SnapshotGet+0x6a>
  66:	f043 0302 	orr.w	r3, r3, #2
  6a:	2a00      	cmp	r2, #0
  6c:	d151      	bne.n	112 <SystemNavigationBackend_SnapshotGet+0x112>
  6e:	4934      	ldr	r1, [pc, #208]	@ (140 <SystemNavigationBackend_SnapshotGet+0x140>)
  70:	f8c4 1100 	str.w	r1, [r4, #256]	@ 0x100
  74:	f043 0204 	orr.w	r2, r3, #4
  78:	4b2b      	ldr	r3, [pc, #172]	@ (128 <SystemNavigationBackend_SnapshotGet+0x128>)
  7a:	f8c4 2180 	str.w	r2, [r4, #384]	@ 0x180
  7e:	cb07      	ldmia	r3!, {r0, r1, r2}
  80:	60e0      	str	r0, [r4, #12]
  82:	6121      	str	r1, [r4, #16]
  84:	6162      	str	r2, [r4, #20]
  86:	f1a3 060c 	sub.w	r6, r3, #12
  8a:	f103 0534 	add.w	r5, r3, #52	@ 0x34
  8e:	cb07      	ldmia	r3!, {r0, r1, r2}
  90:	61a0      	str	r0, [r4, #24]
  92:	61e1      	str	r1, [r4, #28]
  94:	6222      	str	r2, [r4, #32]
  96:	469a      	mov	sl, r3
  98:	e8ba 000f 	ldmia.w	sl!, {r0, r1, r2, r3}
  9c:	f104 0840 	add.w	r8, r4, #64	@ 0x40
  a0:	f104 0c70 	add.w	ip, r4, #112	@ 0x70
  a4:	f104 0958 	add.w	r9, r4, #88	@ 0x58
  a8:	46b6      	mov	lr, r6
  aa:	6260      	str	r0, [r4, #36]	@ 0x24
  ac:	62a1      	str	r1, [r4, #40]	@ 0x28
  ae:	62e2      	str	r2, [r4, #44]	@ 0x2c
  b0:	6323      	str	r3, [r4, #48]	@ 0x30
  b2:	f8de 2040 	ldr.w	r2, [lr, #64]	@ 0x40
  b6:	f848 2b04 	str.w	r2, [r8], #4
  ba:	f1ac 0318 	sub.w	r3, ip, #24
  be:	462a      	mov	r2, r5
  c0:	f852 1b04 	ldr.w	r1, [r2], #4
  c4:	f843 1b04 	str.w	r1, [r3], #4
  c8:	4563      	cmp	r3, ip
  ca:	d1f9      	bne.n	c0 <SystemNavigationBackend_SnapshotGet+0xc0>
  cc:	45c8      	cmp	r8, r9
  ce:	f10e 0e40 	add.w	lr, lr, #64	@ 0x40
  d2:	f105 053c 	add.w	r5, r5, #60	@ 0x3c
  d6:	f103 0c18 	add.w	ip, r3, #24
  da:	d1ea      	bne.n	b2 <SystemNavigationBackend_SnapshotGet+0xb2>
  dc:	e9d6 01f2 	ldrd	r0, r1, [r6, #968]	@ 0x3c8
  e0:	f7ff fffe 	bl	0 <SystemNavigationHealth_DegradedGet>
			e0: R_ARM_THM_CALL	SystemNavigationHealth_DegradedGet
  e4:	f8d4 3180 	ldr.w	r3, [r4, #384]	@ 0x180
  e8:	b1b0      	cbz	r0, 118 <SystemNavigationBackend_SnapshotGet+0x118>
  ea:	f043 0380 	orr.w	r3, r3, #128	@ 0x80
  ee:	4a15      	ldr	r2, [pc, #84]	@ (144 <SystemNavigationBackend_SnapshotGet+0x144>)
  f0:	f8c4 3180 	str.w	r3, [r4, #384]	@ 0x180
  f4:	6812      	ldr	r2, [r2, #0]
  f6:	b142      	cbz	r2, 10a <SystemNavigationBackend_SnapshotGet+0x10a>
  f8:	f443 7380 	orr.w	r3, r3, #256	@ 0x100
  fc:	4638      	mov	r0, r7
  fe:	f8c4 3180 	str.w	r3, [r4, #384]	@ 0x180
 102:	b002      	add	sp, #8
 104:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
 108:	2702      	movs	r7, #2
 10a:	4638      	mov	r0, r7
 10c:	b002      	add	sp, #8
 10e:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
 112:	f023 0204 	bic.w	r2, r3, #4
 116:	e7af      	b.n	78 <SystemNavigationBackend_SnapshotGet+0x78>
 118:	f023 0380 	bic.w	r3, r3, #128	@ 0x80
 11c:	e7e7      	b.n	ee <SystemNavigationBackend_SnapshotGet+0xee>
 11e:	2705      	movs	r7, #5
 120:	4638      	mov	r0, r7
 122:	b002      	add	sp, #8
 124:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
	...
			128: R_ARM_ABS32	.bss.s_state
			12c: R_ARM_ABS32	.bss.s_input_faulted
			130: R_ARM_ABS32	.rodata.Backend_StateLog.str1.4
			134: R_ARM_ABS32	.bss.s_frame
			138: R_ARM_ABS32	.bss.s_baro_origin_valid
			13c: R_ARM_ABS32	.bss.s_active
 140:	7fc00000 	.word	0x7fc00000
 144:	00000000 	.word	0x00000000
			144: R_ARM_ABS32	.bss.s_log_failures

Disassembly of section .text.SystemNavigationBackend_Predict:

00000000 <SystemNavigationBackend_Predict>:
   0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
   4:	ed2d 8b04 	vpush	{d8-d9}
   8:	f5ad 7d03 	sub.w	sp, sp, #524	@ 0x20c
   c:	2800      	cmp	r0, #0
   e:	f000 845c 	beq.w	8ca <SystemNavigationBackend_Predict+0x8ca>
  12:	460d      	mov	r5, r1
  14:	2900      	cmp	r1, #0
  16:	f000 8458 	beq.w	8ca <SystemNavigationBackend_Predict+0x8ca>
  1a:	edd0 7a03 	vldr	s15, [r0, #12]
  1e:	ed9f 7ac4 	vldr	s14, [pc, #784]	@ 330 <SystemNavigationBackend_Predict+0x330>
  22:	eef0 6ae7 	vabs.f32	s13, s15
  26:	eef4 6a47 	vcmp.f32	s13, s14
  2a:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  2e:	4604      	mov	r4, r0
  30:	f200 844b 	bhi.w	8ca <SystemNavigationBackend_Predict+0x8ca>
  34:	eef5 7ac0 	vcmpe.f32	s15, #0.0
  38:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  3c:	f240 8445 	bls.w	8ca <SystemNavigationBackend_Predict+0x8ca>
  40:	ed9f 7abc 	vldr	s14, [pc, #752]	@ 334 <SystemNavigationBackend_Predict+0x334>
  44:	eef4 7ac7 	vcmpe.f32	s15, s14
  48:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
  4c:	f300 843d 	bgt.w	8ca <SystemNavigationBackend_Predict+0x8ca>
  50:	f240 42c2 	movw	r2, #1218	@ 0x4c2
  54:	4bb8      	ldr	r3, [pc, #736]	@ (338 <SystemNavigationBackend_Predict+0x338>)
  56:	9200      	str	r2, [sp, #0]
  58:	2108      	movs	r1, #8
  5a:	2202      	movs	r2, #2
  5c:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			5c: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  60:	f240 42c3 	movw	r2, #1219	@ 0x4c3
  64:	4bb4      	ldr	r3, [pc, #720]	@ (338 <SystemNavigationBackend_Predict+0x338>)
  66:	9200      	str	r2, [sp, #0]
  68:	2108      	movs	r1, #8
  6a:	2202      	movs	r2, #2
  6c:	4628      	mov	r0, r5
  6e:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			6e: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  72:	4bb2      	ldr	r3, [pc, #712]	@ (33c <SystemNavigationBackend_Predict+0x33c>)
  74:	f893 a000 	ldrb.w	sl, [r3]
  78:	f1ba 0f00 	cmp.w	sl, #0
  7c:	f040 8474 	bne.w	968 <SystemNavigationBackend_Predict+0x968>
  80:	4baf      	ldr	r3, [pc, #700]	@ (340 <SystemNavigationBackend_Predict+0x340>)
  82:	781b      	ldrb	r3, [r3, #0]
  84:	2b00      	cmp	r3, #0
  86:	f000 8428 	beq.w	8da <SystemNavigationBackend_Predict+0x8da>
  8a:	f8df 92f4 	ldr.w	r9, [pc, #756]	@ 380 <SystemNavigationBackend_Predict+0x380>
  8e:	f899 33d8 	ldrb.w	r3, [r9, #984]	@ 0x3d8
  92:	2b00      	cmp	r3, #0
  94:	f000 8421 	beq.w	8da <SystemNavigationBackend_Predict+0x8da>
  98:	f240 4386 	movw	r3, #1158	@ 0x486
  9c:	9300      	str	r3, [sp, #0]
  9e:	2202      	movs	r2, #2
  a0:	4ba5      	ldr	r3, [pc, #660]	@ (338 <SystemNavigationBackend_Predict+0x338>)
  a2:	2108      	movs	r1, #8
  a4:	4620      	mov	r0, r4
  a6:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			a6: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  aa:	ae20      	add	r6, sp, #128	@ 0x80
  ac:	f240 4387 	movw	r3, #1159	@ 0x487
  b0:	2202      	movs	r2, #2
  b2:	9300      	str	r3, [sp, #0]
  b4:	2108      	movs	r1, #8
  b6:	4ba0      	ldr	r3, [pc, #640]	@ (338 <SystemNavigationBackend_Predict+0x338>)
  b8:	4630      	mov	r0, r6
  ba:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			ba: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  be:	ed94 8a03 	vldr	s16, [r4, #12]
  c2:	ed9f 0aa0 	vldr	s0, [pc, #640]	@ 344 <SystemNavigationBackend_Predict+0x344>
  c6:	ee28 0a00 	vmul.f32	s0, s16, s0
  ca:	f7ff fffe 	bl	0 <llroundf>
			ca: R_ARM_THM_CALL	llroundf
  ce:	e9d4 b300 	ldrd	fp, r3, [r4]
  d2:	4583      	cmp	fp, r0
  d4:	eb73 0201 	sbcs.w	r2, r3, r1
  d8:	4688      	mov	r8, r1
  da:	4607      	mov	r7, r0
  dc:	9305      	str	r3, [sp, #20]
  de:	f0c0 83f4 	bcc.w	8ca <SystemNavigationBackend_Predict+0x8ca>
  e2:	4651      	mov	r1, sl
  e4:	2224      	movs	r2, #36	@ 0x24
  e6:	a82d      	add	r0, sp, #180	@ 0xb4
  e8:	f7ff fffe 	bl	0 <memset>
			e8: R_ARM_THM_CALL	memset
  ec:	9b05      	ldr	r3, [sp, #20]
  ee:	6aa0      	ldr	r0, [r4, #40]	@ 0x28
  f0:	6ae1      	ldr	r1, [r4, #44]	@ 0x2c
  f2:	6473      	str	r3, [r6, #68]	@ 0x44
  f4:	ebbb 0707 	subs.w	r7, fp, r7
  f8:	eb63 0208 	sbc.w	r2, r3, r8
  fc:	63f2      	str	r2, [r6, #60]	@ 0x3c
  fe:	6b63      	ldr	r3, [r4, #52]	@ 0x34
 100:	6b22      	ldr	r2, [r4, #48]	@ 0x30
 102:	63b7      	str	r7, [r6, #56]	@ 0x38
 104:	4637      	mov	r7, r6
 106:	c70f      	stmia	r7!, {r0, r1, r2, r3}
 108:	6ba0      	ldr	r0, [r4, #56]	@ 0x38
 10a:	6be1      	ldr	r1, [r4, #60]	@ 0x3c
 10c:	6ca2      	ldr	r2, [r4, #72]	@ 0x48
 10e:	6ce3      	ldr	r3, [r4, #76]	@ 0x4c
 110:	ed86 8a0c 	vstr	s16, [r6, #48]	@ 0x30
 114:	c703      	stmia	r7!, {r0, r1}
 116:	6c61      	ldr	r1, [r4, #68]	@ 0x44
 118:	6c20      	ldr	r0, [r4, #64]	@ 0x40
 11a:	f8c6 b040 	str.w	fp, [r6, #64]	@ 0x40
 11e:	c70f      	stmia	r7!, {r0, r1, r2, r3}
 120:	4a89      	ldr	r2, [pc, #548]	@ (348 <SystemNavigationBackend_Predict+0x348>)
 122:	6da3      	ldr	r3, [r4, #88]	@ 0x58
 124:	6013      	str	r3, [r2, #0]
 126:	6533      	str	r3, [r6, #80]	@ 0x50
 128:	f8d9 33d4 	ldr.w	r3, [r9, #980]	@ 0x3d4
 12c:	64f3      	str	r3, [r6, #76]	@ 0x4c
 12e:	f8d9 33d0 	ldr.w	r3, [r9, #976]	@ 0x3d0
 132:	64b3      	str	r3, [r6, #72]	@ 0x48
 134:	6d20      	ldr	r0, [r4, #80]	@ 0x50
 136:	6d61      	ldr	r1, [r4, #84]	@ 0x54
 138:	f240 4365 	movw	r3, #1125	@ 0x465
 13c:	c703      	stmia	r7!, {r0, r1}
 13e:	2202      	movs	r2, #2
 140:	9300      	str	r3, [sp, #0]
 142:	2108      	movs	r1, #8
 144:	4b7c      	ldr	r3, [pc, #496]	@ (338 <SystemNavigationBackend_Predict+0x338>)
 146:	4f81      	ldr	r7, [pc, #516]	@ (34c <SystemNavigationBackend_Predict+0x34c>)
 148:	4630      	mov	r0, r6
 14a:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			14a: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
 14e:	2305      	movs	r3, #5
 150:	9300      	str	r3, [sp, #0]
 152:	f899 03d8 	ldrb.w	r0, [r9, #984]	@ 0x3d8
 156:	4a78      	ldr	r2, [pc, #480]	@ (338 <SystemNavigationBackend_Predict+0x338>)
 158:	3800      	subs	r0, #0
 15a:	f240 4366 	movw	r3, #1126	@ 0x466
 15e:	bf18      	it	ne
 160:	2001      	movne	r0, #1
 162:	2102      	movs	r1, #2
 164:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			164: R_ARM_THM_CALL	SilverStarAssert_Check
 168:	783b      	ldrb	r3, [r7, #0]
 16a:	2b00      	cmp	r3, #0
 16c:	f000 83bd 	beq.w	8ea <SystemNavigationBackend_Predict+0x8ea>
 170:	f240 3303 	movw	r3, #771	@ 0x303
 174:	2700      	movs	r7, #0
 176:	f8a5 31ae 	strh.w	r3, [r5, #430]	@ 0x1ae
 17a:	2303      	movs	r3, #3
 17c:	6d30      	ldr	r0, [r6, #80]	@ 0x50
 17e:	f8c5 7184 	str.w	r7, [r5, #388]	@ 0x184
 182:	f885 31b0 	strb.w	r3, [r5, #432]	@ 0x1b0
 186:	f7ff fffe 	bl	0 <SystemNavigationHealth_ImuQualityRecord>
			186: R_ARM_THM_CALL	SystemNavigationHealth_ImuQualityRecord
 18a:	f240 1379 	movw	r3, #377	@ 0x179
 18e:	68a4      	ldr	r4, [r4, #8]
 190:	9300      	str	r3, [sp, #0]
 192:	2202      	movs	r2, #2
 194:	4b68      	ldr	r3, [pc, #416]	@ (338 <SystemNavigationBackend_Predict+0x338>)
 196:	2108      	movs	r1, #8
 198:	4630      	mov	r0, r6
 19a:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			19a: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
 19e:	6b33      	ldr	r3, [r6, #48]	@ 0x30
 1a0:	935e      	str	r3, [sp, #376]	@ 0x178
 1a2:	6cb3      	ldr	r3, [r6, #72]	@ 0x48
 1a4:	935b      	str	r3, [sp, #364]	@ 0x16c
 1a6:	4b6a      	ldr	r3, [pc, #424]	@ (350 <SystemNavigationBackend_Predict+0x350>)
 1a8:	976b      	str	r7, [sp, #428]	@ 0x1ac
 1aa:	681b      	ldr	r3, [r3, #0]
 1ac:	935c      	str	r3, [sp, #368]	@ 0x170
 1ae:	6d33      	ldr	r3, [r6, #80]	@ 0x50
 1b0:	935d      	str	r3, [sp, #372]	@ 0x174
 1b2:	e9d6 230e 	ldrd	r2, r3, [r6, #56]	@ 0x38
 1b6:	46b6      	mov	lr, r6
 1b8:	e9cd 2356 	strd	r2, r3, [sp, #344]	@ 0x158
 1bc:	e8be 000f 	ldmia.w	lr!, {r0, r1, r2, r3}
 1c0:	e9d6 ab10 	ldrd	sl, fp, [r6, #64]	@ 0x40
 1c4:	f50d 7cbe 	add.w	ip, sp, #380	@ 0x17c
 1c8:	945a      	str	r4, [sp, #360]	@ 0x168
 1ca:	e9cd ab58 	strd	sl, fp, [sp, #352]	@ 0x160
 1ce:	e8ac 000f 	stmia.w	ip!, {r0, r1, r2, r3}
 1d2:	e89e 0003 	ldmia.w	lr, {r0, r1}
 1d6:	ac26      	add	r4, sp, #152	@ 0x98
 1d8:	e88c 0003 	stmia.w	ip, {r0, r1}
 1dc:	cc0f      	ldmia	r4!, {r0, r1, r2, r3}
 1de:	af65      	add	r7, sp, #404	@ 0x194
 1e0:	c70f      	stmia	r7!, {r0, r1, r2, r3}
 1e2:	e894 0003 	ldmia.w	r4, {r0, r1}
 1e6:	aa56      	add	r2, sp, #344	@ 0x158
 1e8:	e887 0003 	stmia.w	r7, {r0, r1}
 1ec:	4650      	mov	r0, sl
 1ee:	4659      	mov	r1, fp
 1f0:	f7ff fffe 	bl	0 <LoggerBus_Eskf15BodyInputPush>
			1f0: R_ARM_THM_CALL	LoggerBus_Eskf15BodyInputPush
 1f4:	2800      	cmp	r0, #0
 1f6:	f040 838d 	bne.w	914 <SystemNavigationBackend_Predict+0x914>
 1fa:	4f56      	ldr	r7, [pc, #344]	@ (354 <SystemNavigationBackend_Predict+0x354>)
 1fc:	9600      	str	r6, [sp, #0]
 1fe:	e897 0007 	ldmia.w	r7, {r0, r1, r2}
 202:	ac08      	add	r4, sp, #32
 204:	e884 0007 	stmia.w	r4, {r0, r1, r2}
 208:	4b53      	ldr	r3, [pc, #332]	@ (358 <SystemNavigationBackend_Predict+0x358>)
 20a:	4a54      	ldr	r2, [pc, #336]	@ (35c <SystemNavigationBackend_Predict+0x35c>)
 20c:	4854      	ldr	r0, [pc, #336]	@ (360 <SystemNavigationBackend_Predict+0x360>)
 20e:	f1a7 010c 	sub.w	r1, r7, #12
 212:	f7ff fffe 	bl	0 <NavigationEskfReplay_Predict>
			212: R_ARM_THM_CALL	NavigationEskfReplay_Predict
 216:	2800      	cmp	r0, #0
 218:	f040 83f7 	bne.w	a0a <SystemNavigationBackend_Predict+0xa0a>
 21c:	edd6 6a0c 	vldr	s13, [r6, #48]	@ 0x30
 220:	463b      	mov	r3, r7
 222:	f105 0234 	add.w	r2, r5, #52	@ 0x34
 226:	f105 0140 	add.w	r1, r5, #64	@ 0x40
 22a:	ecf3 7a01 	vldmia	r3!, {s15}
 22e:	ecb4 7a01 	vldmia	r4!, {s14}
 232:	ee77 7ac7 	vsub.f32	s15, s15, s14
 236:	ee87 7aa6 	vdiv.f32	s14, s15, s13
 23a:	eca2 7a01 	vstmia	r2!, {s14}
 23e:	428a      	cmp	r2, r1
 240:	d1f3      	bne.n	22a <SystemNavigationBackend_Predict+0x22a>
 242:	f240 339b 	movw	r3, #923	@ 0x39b
 246:	9300      	str	r3, [sp, #0]
 248:	2202      	movs	r2, #2
 24a:	4b3b      	ldr	r3, [pc, #236]	@ (338 <SystemNavigationBackend_Predict+0x338>)
 24c:	2108      	movs	r1, #8
 24e:	4628      	mov	r0, r5
 250:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			250: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
 254:	2305      	movs	r3, #5
 256:	9300      	str	r3, [sp, #0]
 258:	f899 03d8 	ldrb.w	r0, [r9, #984]	@ 0x3d8
 25c:	4a36      	ldr	r2, [pc, #216]	@ (338 <SystemNavigationBackend_Predict+0x338>)
 25e:	3800      	subs	r0, #0
 260:	bf18      	it	ne
 262:	2001      	movne	r0, #1
 264:	f44f 7367 	mov.w	r3, #924	@ 0x39c
 268:	2102      	movs	r1, #2
 26a:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			26a: R_ARM_THM_CALL	SilverStarAssert_Check
 26e:	a856      	add	r0, sp, #344	@ 0x158
 270:	f7ff fffe 	bl	0 <SystemGnss_ReceiptSnapshotGet>
			270: R_ARM_THM_CALL	SystemGnss_ReceiptSnapshotGet
 274:	2809      	cmp	r0, #9
 276:	9006      	str	r0, [sp, #24]
 278:	f000 8351 	beq.w	91e <SystemNavigationBackend_Predict+0x91e>
 27c:	9b06      	ldr	r3, [sp, #24]
 27e:	2b00      	cmp	r3, #0
 280:	f040 826b 	bne.w	75a <SystemNavigationBackend_Predict+0x75a>
 284:	4c37      	ldr	r4, [pc, #220]	@ (364 <SystemNavigationBackend_Predict+0x364>)
 286:	f894 3040 	ldrb.w	r3, [r4, #64]	@ 0x40
 28a:	2b00      	cmp	r3, #0
 28c:	f000 8265 	beq.w	75a <SystemNavigationBackend_Predict+0x75a>
 290:	f8d9 23c8 	ldr.w	r2, [r9, #968]	@ 0x3c8
 294:	9858      	ldr	r0, [sp, #352]	@ 0x160
 296:	f8d9 33cc 	ldr.w	r3, [r9, #972]	@ 0x3cc
 29a:	9959      	ldr	r1, [sp, #356]	@ 0x164
 29c:	4282      	cmp	r2, r0
 29e:	eb73 0101 	sbcs.w	r1, r3, r1
 2a2:	f0c0 825a 	bcc.w	75a <SystemNavigationBackend_Predict+0x75a>
 2a6:	4e30      	ldr	r6, [pc, #192]	@ (368 <SystemNavigationBackend_Predict+0x368>)
 2a8:	4830      	ldr	r0, [pc, #192]	@ (36c <SystemNavigationBackend_Predict+0x36c>)
 2aa:	7837      	ldrb	r7, [r6, #0]
 2ac:	f89d 1201 	ldrb.w	r1, [sp, #513]	@ 0x201
 2b0:	7800      	ldrb	r0, [r0, #0]
 2b2:	2f00      	cmp	r7, #0
 2b4:	f000 83ad 	beq.w	a12 <SystemNavigationBackend_Predict+0xa12>
 2b8:	4281      	cmp	r1, r0
 2ba:	f000 8403 	beq.w	ac4 <SystemNavigationBackend_Predict+0xac4>
 2be:	4b2b      	ldr	r3, [pc, #172]	@ (36c <SystemNavigationBackend_Predict+0x36c>)
 2c0:	4a2b      	ldr	r2, [pc, #172]	@ (370 <SystemNavigationBackend_Predict+0x370>)
 2c2:	7019      	strb	r1, [r3, #0]
 2c4:	4b2b      	ldr	r3, [pc, #172]	@ (374 <SystemNavigationBackend_Predict+0x374>)
 2c6:	482c      	ldr	r0, [pc, #176]	@ (378 <SystemNavigationBackend_Predict+0x378>)
 2c8:	2100      	movs	r1, #0
 2ca:	f04f 0a00 	mov.w	sl, #0
 2ce:	f04f 0b00 	mov.w	fp, #0
 2d2:	e9c3 ab00 	strd	sl, fp, [r3]
 2d6:	6011      	str	r1, [r2, #0]
 2d8:	f7ff fffe 	bl	0 <NavigationWindow_Reset>
			2d8: R_ARM_THM_CALL	NavigationWindow_Reset
 2dc:	e9d9 23f2 	ldrd	r2, r3, [r9, #968]	@ 0x3c8
 2e0:	4826      	ldr	r0, [pc, #152]	@ (37c <SystemNavigationBackend_Predict+0x37c>)
 2e2:	9f5b      	ldr	r7, [sp, #364]	@ 0x16c
 2e4:	6007      	str	r7, [r0, #0]
 2e6:	2101      	movs	r1, #1
 2e8:	a856      	add	r0, sp, #344	@ 0x158
 2ea:	7031      	strb	r1, [r6, #0]
 2ec:	f7ff fffe 	bl	0 <SystemGnssQuality_Evaluate>
			2ec: R_ARM_THM_CALL	SystemGnssQuality_Evaluate
 2f0:	2800      	cmp	r0, #0
 2f2:	f040 83b3 	bne.w	a5c <SystemNavigationBackend_Predict+0xa5c>
 2f6:	f89d 6190 	ldrb.w	r6, [sp, #400]	@ 0x190
 2fa:	f006 0701 	and.w	r7, r6, #1
 2fe:	f006 0602 	and.w	r6, r6, #2
 302:	f89d 31c8 	ldrb.w	r3, [sp, #456]	@ 0x1c8
 306:	9a5b      	ldr	r2, [sp, #364]	@ 0x16c
 308:	f885 31ac 	strb.w	r3, [r5, #428]	@ 0x1ac
 30c:	e9dd 0158 	ldrd	r0, r1, [sp, #352]	@ 0x160
 310:	2b07      	cmp	r3, #7
 312:	e9c5 0162 	strd	r0, r1, [r5, #392]	@ 0x188
 316:	f8c5 2198 	str.w	r2, [r5, #408]	@ 0x198
 31a:	f000 83a4 	beq.w	a66 <SystemNavigationBackend_Predict+0xa66>
 31e:	f003 0303 	and.w	r3, r3, #3
 322:	f1a3 0303 	sub.w	r3, r3, #3
 326:	fab3 f383 	clz	r3, r3
 32a:	095b      	lsrs	r3, r3, #5
 32c:	005b      	lsls	r3, r3, #1
 32e:	e029      	b.n	384 <SystemNavigationBackend_Predict+0x384>
 330:	7f7fffff 	.word	0x7f7fffff
 334:	3ca3d70a 	.word	0x3ca3d70a
	...
			338: R_ARM_ABS32	.rodata.Backend_StateLog.str1.4
			33c: R_ARM_ABS32	.bss.s_input_faulted
			340: R_ARM_ABS32	.bss.s_active
 344:	49742400 	.word	0x49742400
	...
			348: R_ARM_ABS32	.bss.s_imu_quality_flags
			34c: R_ARM_ABS32	.bss.s_started
			350: R_ARM_ABS32	.bss.s_calibration_generation
 354:	0000000c 	.word	0x0000000c
			354: R_ARM_ABS32	.bss.s_state
	...
			358: R_ARM_ABS32	.rodata.s_config
			35c: R_ARM_ABS32	.bss.silverstar_auto_eskf_work
			360: R_ARM_ABS32	.bss.silverstar_auto_eskf_history
			364: R_ARM_ABS32	.bss.s_frame
			368: R_ARM_ABS32	.bss.s_gnss_seen
			36c: R_ARM_ABS32	.bss.s_gnss_source
			370: R_ARM_ABS32	.bss.s_native_tow_ms
			374: R_ARM_ABS32	.bss.s_native_week_us
			378: R_ARM_ABS32	.bss.silverstar_auto_eskf_window
			37c: R_ARM_ABS32	.bss.s_gnss_sequence
			380: R_ARM_ABS32	.bss.s_state
 384:	f885 31ad 	strb.w	r3, [r5, #429]	@ 0x1ad
 388:	ab69      	add	r3, sp, #420	@ 0x1a4
 38a:	cb07      	ldmia	r3!, {r0, r1, r2}
 38c:	f8c5 00f4 	str.w	r0, [r5, #244]	@ 0xf4
 390:	f8c5 10f8 	str.w	r1, [r5, #248]	@ 0xf8
 394:	f8c5 20fc 	str.w	r2, [r5, #252]	@ 0xfc
 398:	2f00      	cmp	r7, #0
 39a:	f000 835c 	beq.w	a56 <SystemNavigationBackend_Predict+0xa56>
 39e:	e9dd 1265 	ldrd	r1, r2, [sp, #404]	@ 0x194
 3a2:	2e00      	cmp	r6, #0
 3a4:	f000 8355 	beq.w	a52 <SystemNavigationBackend_Predict+0xa52>
 3a8:	9b67      	ldr	r3, [sp, #412]	@ 0x19c
 3aa:	a80b      	add	r0, sp, #44	@ 0x2c
 3ac:	9000      	str	r0, [sp, #0]
 3ae:	48cc      	ldr	r0, [pc, #816]	@ (6e0 <SystemNavigationBackend_Predict+0x6e0>)
 3b0:	f7ff fffe 	bl	0 <GeoLocalFrame_ToEnu>
			3b0: R_ARM_THM_CALL	GeoLocalFrame_ToEnu
 3b4:	2800      	cmp	r0, #0
 3b6:	f000 837b 	beq.w	ab0 <SystemNavigationBackend_Predict+0xab0>
 3ba:	ab0b      	add	r3, sp, #44	@ 0x2c
 3bc:	cb07      	ldmia	r3!, {r0, r1, r2}
 3be:	f89d 4174 	ldrb.w	r4, [sp, #372]	@ 0x174
 3c2:	f8c5 00e8 	str.w	r0, [r5, #232]	@ 0xe8
 3c6:	f8c5 10ec 	str.w	r1, [r5, #236]	@ 0xec
 3ca:	f89d 01cb 	ldrb.w	r0, [sp, #459]	@ 0x1cb
 3ce:	f8c5 20f0 	str.w	r2, [r5, #240]	@ 0xf0
 3d2:	f3c4 0180 	ubfx	r1, r4, #2, #1
 3d6:	f7ff fffe 	bl	0 <NavigationQuality_SatelliteVarianceScale>
			3d6: R_ARM_THM_CALL	NavigationQuality_SatelliteVarianceScale
 3da:	f44f 73c5 	mov.w	r3, #394	@ 0x18a
 3de:	9300      	str	r3, [sp, #0]
 3e0:	2202      	movs	r2, #2
 3e2:	4bc0      	ldr	r3, [pc, #768]	@ (6e4 <SystemNavigationBackend_Predict+0x6e4>)
 3e4:	2108      	movs	r1, #8
 3e6:	a856      	add	r0, sp, #344	@ 0x158
 3e8:	eeb0 8a40 	vmov.f32	s16, s0
 3ec:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			3ec: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
 3f0:	f240 138b 	movw	r3, #395	@ 0x18b
 3f4:	9300      	str	r3, [sp, #0]
 3f6:	2202      	movs	r2, #2
 3f8:	4bba      	ldr	r3, [pc, #744]	@ (6e4 <SystemNavigationBackend_Predict+0x6e4>)
 3fa:	2104      	movs	r1, #4
 3fc:	a80b      	add	r0, sp, #44	@ 0x2c
 3fe:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			3fe: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
 402:	f89d 3200 	ldrb.w	r3, [sp, #512]	@ 0x200
 406:	2b00      	cmp	r3, #0
 408:	f040 82d1 	bne.w	9ae <SystemNavigationBackend_Predict+0x9ae>
 40c:	9a5b      	ldr	r2, [sp, #364]	@ 0x16c
 40e:	9b78      	ldr	r3, [sp, #480]	@ 0x1e0
 410:	4293      	cmp	r3, r2
 412:	f040 82cc 	bne.w	9ae <SystemNavigationBackend_Predict+0x9ae>
 416:	9c79      	ldr	r4, [sp, #484]	@ 0x1e4
 418:	4bb3      	ldr	r3, [pc, #716]	@ (6e8 <SystemNavigationBackend_Predict+0x6e8>)
 41a:	429c      	cmp	r4, r3
 41c:	f200 82c7 	bhi.w	9ae <SystemNavigationBackend_Predict+0x9ae>
 420:	4eb2      	ldr	r6, [pc, #712]	@ (6ec <SystemNavigationBackend_Predict+0x6ec>)
 422:	6833      	ldr	r3, [r6, #0]
 424:	429c      	cmp	r4, r3
 426:	f0c0 8360 	bcc.w	aea <SystemNavigationBackend_Predict+0xaea>
 42a:	4bb1      	ldr	r3, [pc, #708]	@ (6f0 <SystemNavigationBackend_Predict+0x6f0>)
 42c:	6034      	str	r4, [r6, #0]
 42e:	e9d3 1300 	ldrd	r1, r3, [r3]
 432:	f44f 707a 	mov.w	r0, #1000	@ 0x3e8
 436:	ae36      	add	r6, sp, #216	@ 0xd8
 438:	fbe4 1300 	umlal	r1, r3, r4, r0
 43c:	2700      	movs	r7, #0
 43e:	f8ad 70fe 	strh.w	r7, [sp, #254]	@ 0xfe
 442:	f8d9 03d4 	ldr.w	r0, [r9, #980]	@ 0x3d4
 446:	6130      	str	r0, [r6, #16]
 448:	e9c6 1300 	strd	r1, r3, [r6]
 44c:	a90b      	add	r1, sp, #44	@ 0x2c
 44e:	c903      	ldmia	r1, {r0, r1}
 450:	f89d 4201 	ldrb.w	r4, [sp, #513]	@ 0x201
 454:	f89d 3190 	ldrb.w	r3, [sp, #400]	@ 0x190
 458:	af3b      	add	r7, sp, #236	@ 0xec
 45a:	e9c6 2402 	strd	r2, r4, [r6, #8]
 45e:	e887 0003 	stmia.w	r7, {r0, r1}
 462:	a969      	add	r1, sp, #420	@ 0x1a4
 464:	c903      	ldmia	r1, {r0, r1}
 466:	f003 0c01 	and.w	ip, r3, #1
 46a:	ac3d      	add	r4, sp, #244	@ 0xf4
 46c:	f3c3 0380 	ubfx	r3, r3, #2, #1
 470:	e884 0003 	stmia.w	r4, {r0, r1}
 474:	4632      	mov	r2, r6
 476:	499f      	ldr	r1, [pc, #636]	@ (6f4 <SystemNavigationBackend_Predict+0x6f4>)
 478:	f886 c024 	strb.w	ip, [r6, #36]	@ 0x24
 47c:	f886 3025 	strb.w	r3, [r6, #37]	@ 0x25
 480:	489d      	ldr	r0, [pc, #628]	@ (6f8 <SystemNavigationBackend_Predict+0x6f8>)
 482:	f7ff fffe 	bl	0 <NavigationWindow_Receive>
			482: R_ARM_THM_CALL	NavigationWindow_Receive
 486:	e9dd 2336 	ldrd	r2, r3, [sp, #216]	@ 0xd8
 48a:	499a      	ldr	r1, [pc, #616]	@ (6f4 <SystemNavigationBackend_Predict+0x6f4>)
 48c:	489a      	ldr	r0, [pc, #616]	@ (6f8 <SystemNavigationBackend_Predict+0x6f8>)
 48e:	f7ff fffe 	bl	0 <NavigationWindow_VarianceScale>
			48e: R_ARM_THM_CALL	NavigationWindow_VarianceScale
 492:	eef0 9a40 	vmov.f32	s19, s0
 496:	f04f 0800 	mov.w	r8, #0
 49a:	ed9f 9a98 	vldr	s18, [pc, #608]	@ 6fc <SystemNavigationBackend_Predict+0x6fc>
 49e:	9507      	str	r5, [sp, #28]
 4a0:	ac0e      	add	r4, sp, #56	@ 0x38
 4a2:	4647      	mov	r7, r8
 4a4:	fa5f fa87 	uxtb.w	sl, r7
 4a8:	f00a 0801 	and.w	r8, sl, #1
 4ac:	f1c8 0802 	rsb	r8, r8, #2
 4b0:	fa5f f388 	uxtb.w	r3, r8
 4b4:	9305      	str	r3, [sp, #20]
 4b6:	ea4f 054a 	mov.w	r5, sl, lsl #1
 4ba:	f240 332e 	movw	r3, #814	@ 0x32e
 4be:	2f01      	cmp	r7, #1
 4c0:	9300      	str	r3, [sp, #0]
 4c2:	f005 0502 	and.w	r5, r5, #2
 4c6:	4b87      	ldr	r3, [pc, #540]	@ (6e4 <SystemNavigationBackend_Predict+0x6e4>)
 4c8:	f04f 0202 	mov.w	r2, #2
 4cc:	f04f 0108 	mov.w	r1, #8
 4d0:	a856      	add	r0, sp, #344	@ 0x158
 4d2:	f240 8267 	bls.w	9a4 <SystemNavigationBackend_Predict+0x9a4>
 4d6:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			4d6: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
 4da:	f44f 7b87 	mov.w	fp, #270	@ 0x10e
 4de:	2302      	movs	r3, #2
 4e0:	4a80      	ldr	r2, [pc, #512]	@ (6e4 <SystemNavigationBackend_Predict+0x6e4>)
 4e2:	9300      	str	r3, [sp, #0]
 4e4:	2102      	movs	r1, #2
 4e6:	f240 332f 	movw	r3, #815	@ 0x32f
 4ea:	2001      	movs	r0, #1
 4ec:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			4ec: R_ARM_THM_CALL	SilverStarAssert_Check
 4f0:	2248      	movs	r2, #72	@ 0x48
 4f2:	2100      	movs	r1, #0
 4f4:	4620      	mov	r0, r4
 4f6:	f7ff fffe 	bl	0 <memset>
			4f6: R_ARM_THM_CALL	memset
 4fa:	2278      	movs	r2, #120	@ 0x78
 4fc:	2100      	movs	r1, #0
 4fe:	a838      	add	r0, sp, #224	@ 0xe0
 500:	f7ff fffe 	bl	0 <memset>
			500: R_ARM_THM_CALL	memset
 504:	f89d 3190 	ldrb.w	r3, [sp, #400]	@ 0x190
 508:	f8cd b004 	str.w	fp, [sp, #4]
 50c:	40fb      	lsrs	r3, r7
 50e:	2f00      	cmp	r7, #0
 510:	f003 0301 	and.w	r3, r3, #1
 514:	eef7 7a00 	vmov.f32	s15, #112	@ 0x3f800000  1.0
 518:	f884 a01c 	strb.w	sl, [r4, #28]
 51c:	bf08      	it	eq
 51e:	eef0 7a69 	vmoveq.f32	s15, s19
 522:	9402      	str	r4, [sp, #8]
 524:	7763      	strb	r3, [r4, #29]
 526:	f89d 3168 	ldrb.w	r3, [sp, #360]	@ 0x168
 52a:	ed86 8a16 	vstr	s16, [r6, #88]	@ 0x58
 52e:	edc6 7a17 	vstr	s15, [r6, #92]	@ 0x5c
 532:	9300      	str	r3, [sp, #0]
 534:	9b5b      	ldr	r3, [sp, #364]	@ 0x16c
 536:	6123      	str	r3, [r4, #16]
 538:	4b71      	ldr	r3, [pc, #452]	@ (700 <SystemNavigationBackend_Predict+0x700>)
 53a:	781b      	ldrb	r3, [r3, #0]
 53c:	6163      	str	r3, [r4, #20]
 53e:	e9dd 0158 	ldrd	r0, r1, [sp, #352]	@ 0x160
 542:	e9dd 2356 	ldrd	r2, r3, [sp, #344]	@ 0x158
 546:	e9c4 0102 	strd	r0, r1, [r4, #8]
 54a:	e9c6 2300 	strd	r2, r3, [r6]
 54e:	f7ff fffe 	bl	0 <SystemTime_MeasurementTimestampResolve>
			54e: R_ARM_THM_CALL	SystemTime_MeasurementTimestampResolve
 552:	2800      	cmp	r0, #0
 554:	f000 821a 	beq.w	98c <SystemNavigationBackend_Predict+0x98c>
 558:	f04f 0300 	mov.w	r3, #0
 55c:	7763      	strb	r3, [r4, #29]
 55e:	ab0b      	add	r3, sp, #44	@ 0x2c
 560:	f105 0b13 	add.w	fp, r5, #19
 564:	eb03 0885 	add.w	r8, r3, r5, lsl #2
 568:	ab56      	add	r3, sp, #344	@ 0x158
 56a:	eb03 0b8b 	add.w	fp, r3, fp, lsl #2
 56e:	4633      	mov	r3, r6
 570:	edd6 8a17 	vldr	s17, [r6, #92]	@ 0x5c
 574:	ad47      	add	r5, sp, #284	@ 0x11c
 576:	463e      	mov	r6, r7
 578:	f04f 0a00 	mov.w	sl, #0
 57c:	461f      	mov	r7, r3
 57e:	2e01      	cmp	r6, #1
 580:	eef0 0a49 	vmov.f32	s1, s18
 584:	f240 81de 	bls.w	944 <SystemNavigationBackend_Predict+0x944>
 588:	ed9b 0a03 	vldr	s0, [fp, #12]
 58c:	f7ff fffe 	bl	0 <fmaxf>
			58c: R_ARM_THM_CALL	fmaxf
 590:	f8db 1000 	ldr.w	r1, [fp]
 594:	ed85 0a00 	vstr	s0, [r5]
 598:	ee28 0a00 	vmul.f32	s0, s16, s0
 59c:	eb04 038a 	add.w	r3, r4, sl, lsl #2
 5a0:	ee60 7a28 	vmul.f32	s15, s0, s17
 5a4:	9a05      	ldr	r2, [sp, #20]
 5a6:	6219      	str	r1, [r3, #32]
 5a8:	edc3 7a0a 	vstr	s15, [r3, #40]	@ 0x28
 5ac:	f10a 0301 	add.w	r3, sl, #1
 5b0:	4293      	cmp	r3, r2
 5b2:	f105 0504 	add.w	r5, r5, #4
 5b6:	f108 0804 	add.w	r8, r8, #4
 5ba:	f10b 0b04 	add.w	fp, fp, #4
 5be:	f04f 0a01 	mov.w	sl, #1
 5c2:	d3dc      	bcc.n	57e <SystemNavigationBackend_Predict+0x57e>
 5c4:	463b      	mov	r3, r7
 5c6:	4637      	mov	r7, r6
 5c8:	9a07      	ldr	r2, [sp, #28]
 5ca:	4619      	mov	r1, r3
 5cc:	4620      	mov	r0, r4
 5ce:	3701      	adds	r7, #1
 5d0:	461e      	mov	r6, r3
 5d2:	f7ff fffe 	bl	0 <SystemNavigationBackend_Predict>
			5d2: R_ARM_THM_CALL	Backend_EventApply
 5d6:	2f04      	cmp	r7, #4
 5d8:	f47f af64 	bne.w	4a4 <SystemNavigationBackend_Predict+0x4a4>
 5dc:	2268      	movs	r2, #104	@ 0x68
 5de:	2100      	movs	r1, #0
 5e0:	4630      	mov	r0, r6
 5e2:	e9d9 8bf2 	ldrd	r8, fp, [r9, #968]	@ 0x3c8
 5e6:	9d07      	ldr	r5, [sp, #28]
 5e8:	f7ff fffe 	bl	0 <memset>
			5e8: R_ARM_THM_CALL	memset
 5ec:	f240 334f 	movw	r3, #847	@ 0x34f
 5f0:	9300      	str	r3, [sp, #0]
 5f2:	4652      	mov	r2, sl
 5f4:	4b3b      	ldr	r3, [pc, #236]	@ (6e4 <SystemNavigationBackend_Predict+0x6e4>)
 5f6:	2108      	movs	r1, #8
 5f8:	a856      	add	r0, sp, #344	@ 0x158
 5fa:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			5fa: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
 5fe:	f44f 7354 	mov.w	r3, #848	@ 0x350
 602:	4652      	mov	r2, sl
 604:	9300      	str	r3, [sp, #0]
 606:	2108      	movs	r1, #8
 608:	4b36      	ldr	r3, [pc, #216]	@ (6e4 <SystemNavigationBackend_Predict+0x6e4>)
 60a:	4630      	mov	r0, r6
 60c:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			60c: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
 610:	e9dd 0158 	ldrd	r0, r1, [sp, #352]	@ 0x160
 614:	f89d 2200 	ldrb.w	r2, [sp, #512]	@ 0x200
 618:	9b5b      	ldr	r3, [sp, #364]	@ 0x16c
 61a:	e9c6 8b04 	strd	r8, fp, [r6, #16]
 61e:	e9c6 0102 	strd	r0, r1, [r6, #8]
 622:	b91a      	cbnz	r2, 62c <SystemNavigationBackend_Predict+0x62c>
 624:	9a78      	ldr	r2, [sp, #480]	@ 0x1e0
 626:	429a      	cmp	r2, r3
 628:	f000 8253 	beq.w	ad2 <SystemNavigationBackend_Predict+0xad2>
 62c:	e9d6 0e00 	ldrd	r0, lr, [r6]
 630:	6333      	str	r3, [r6, #48]	@ 0x30
 632:	4b34      	ldr	r3, [pc, #208]	@ (704 <SystemNavigationBackend_Predict+0x704>)
 634:	f89d 7201 	ldrb.w	r7, [sp, #513]	@ 0x201
 638:	681b      	ldr	r3, [r3, #0]
 63a:	6377      	str	r7, [r6, #52]	@ 0x34
 63c:	f89d 7191 	ldrb.w	r7, [sp, #401]	@ 0x191
 640:	f89d 2174 	ldrb.w	r2, [sp, #372]	@ 0x174
 644:	63b3      	str	r3, [r6, #56]	@ 0x38
 646:	f886 7059 	strb.w	r7, [r6, #89]	@ 0x59
 64a:	4b2b      	ldr	r3, [pc, #172]	@ (6f8 <SystemNavigationBackend_Predict+0x6f8>)
 64c:	f89d 7192 	ldrb.w	r7, [sp, #402]	@ 0x192
 650:	f886 7063 	strb.w	r7, [r6, #99]	@ 0x63
 654:	f89d 71cb 	ldrb.w	r7, [sp, #459]	@ 0x1cb
 658:	f886 705f 	strb.w	r7, [r6, #95]	@ 0x5f
 65c:	f3c2 0280 	ubfx	r2, r2, #2, #1
 660:	f8d3 70a8 	ldr.w	r7, [r3, #168]	@ 0xa8
 664:	f886 2061 	strb.w	r2, [r6, #97]	@ 0x61
 668:	63f7      	str	r7, [r6, #60]	@ 0x3c
 66a:	6f9a      	ldr	r2, [r3, #120]	@ 0x78
 66c:	f893 70b4 	ldrb.w	r7, [r3, #180]	@ 0xb4
 670:	6fd9      	ldr	r1, [r3, #124]	@ 0x7c
 672:	f886 7062 	strb.w	r7, [r6, #98]	@ 0x62
 676:	ed93 7b28 	vldr	d7, [r3, #160]	@ 0xa0
 67a:	f8d3 70ac 	ldr.w	r7, [r3, #172]	@ 0xac
 67e:	6437      	str	r7, [r6, #64]	@ 0x40
 680:	4290      	cmp	r0, r2
 682:	f8d3 70b0 	ldr.w	r7, [r3, #176]	@ 0xb0
 686:	6477      	str	r7, [r6, #68]	@ 0x44
 688:	eb7e 0c01 	sbcs.w	ip, lr, r1
 68c:	f04f 0703 	mov.w	r7, #3
 690:	f886 7058 	strb.w	r7, [r6, #88]	@ 0x58
 694:	ed86 7b06 	vstr	d7, [r6, #24]
 698:	f893 7099 	ldrb.w	r7, [r3, #153]	@ 0x99
 69c:	6232      	str	r2, [r6, #32]
 69e:	6271      	str	r1, [r6, #36]	@ 0x24
 6a0:	f080 81bd 	bcs.w	a1e <SystemNavigationBackend_Predict+0xa1e>
 6a4:	f04f 30ff 	mov.w	r0, #4294967295
 6a8:	f04f 31ff 	mov.w	r1, #4294967295
 6ac:	e9c6 010a 	strd	r0, r1, [r6, #40]	@ 0x28
 6b0:	b10f      	cbz	r7, 6b6 <SystemNavigationBackend_Predict+0x6b6>
 6b2:	2204      	movs	r2, #4
 6b4:	9206      	str	r2, [sp, #24]
 6b6:	9a06      	ldr	r2, [sp, #24]
 6b8:	f886 2060 	strb.w	r2, [r6, #96]	@ 0x60
 6bc:	2200      	movs	r2, #0
 6be:	f886 205e 	strb.w	r2, [r6, #94]	@ 0x5e
 6c2:	f04f 527e 	mov.w	r2, #1065353216	@ 0x3f800000
 6c6:	6572      	str	r2, [r6, #84]	@ 0x54
 6c8:	4a0f      	ldr	r2, [pc, #60]	@ (708 <SystemNavigationBackend_Predict+0x708>)
 6ca:	f8d3 7088 	ldr.w	r7, [r3, #136]	@ 0x88
 6ce:	e892 0003 	ldmia.w	r2, {r0, r1}
 6d2:	ab48      	add	r3, sp, #288	@ 0x120
 6d4:	e883 0003 	stmia.w	r3, {r0, r1}
 6d8:	6537      	str	r7, [r6, #80]	@ 0x50
 6da:	2700      	movs	r7, #0
 6dc:	e016      	b.n	70c <SystemNavigationBackend_Predict+0x70c>
 6de:	bf00      	nop
	...
			6e0: R_ARM_ABS32	.bss.s_frame
			6e4: R_ARM_ABS32	.rodata.Backend_StateLog.str1.4
 6e8:	240c83ff 	.word	0x240c83ff
	...
			6ec: R_ARM_ABS32	.bss.s_native_tow_ms
			6f0: R_ARM_ABS32	.bss.s_native_week_us
			6f4: R_ARM_ABS32	.rodata.s_window_config
			6f8: R_ARM_ABS32	.bss.silverstar_auto_eskf_window
 6fc:	3cb851ec 	.word	0x3cb851ec
	...
			700: R_ARM_ABS32	.bss.s_gnss_source
			704: R_ARM_ABS32	.bss.s_calibration_generation
 708:	00000080 	.word	0x00000080
			708: R_ARM_ABS32	.bss.silverstar_auto_eskf_window
 70c:	9400      	str	r4, [sp, #0]
 70e:	4642      	mov	r2, r8
 710:	465b      	mov	r3, fp
 712:	b2f8      	uxtb	r0, r7
 714:	f7ff fffe 	bl	0 <SystemNavigationHealth_GroupGet>
			714: R_ARM_THM_CALL	SystemNavigationHealth_GroupGet
 718:	b920      	cbnz	r0, 724 <SystemNavigationBackend_Predict+0x724>
 71a:	6aa2      	ldr	r2, [r4, #40]	@ 0x28
 71c:	9b5b      	ldr	r3, [sp, #364]	@ 0x16c
 71e:	429a      	cmp	r2, r3
 720:	f000 8149 	beq.w	9b6 <SystemNavigationBackend_Predict+0x9b6>
 724:	3701      	adds	r7, #1
 726:	2f04      	cmp	r7, #4
 728:	d1f0      	bne.n	70c <SystemNavigationBackend_Predict+0x70c>
 72a:	2300      	movs	r3, #0
 72c:	220f      	movs	r2, #15
 72e:	4659      	mov	r1, fp
 730:	4640      	mov	r0, r8
 732:	f7ff fffe 	bl	0 <SystemNavigationHealth_OverallGet>
			732: R_ARM_THM_CALL	SystemNavigationHealth_OverallGet
 736:	4603      	mov	r3, r0
 738:	f886 305d 	strb.w	r3, [r6, #93]	@ 0x5d
 73c:	3b04      	subs	r3, #4
 73e:	bf18      	it	ne
 740:	2301      	movne	r3, #1
 742:	4640      	mov	r0, r8
 744:	4659      	mov	r1, fp
 746:	f886 305c 	strb.w	r3, [r6, #92]	@ 0x5c
 74a:	4632      	mov	r2, r6
 74c:	f7ff fffe 	bl	0 <LoggerBus_NavigationQualityPush>
			74c: R_ARM_THM_CALL	LoggerBus_NavigationQualityPush
 750:	b118      	cbz	r0, 75a <SystemNavigationBackend_Predict+0x75a>
 752:	4ac6      	ldr	r2, [pc, #792]	@ (a6c <SystemNavigationBackend_Predict+0xa6c>)
 754:	6813      	ldr	r3, [r2, #0]
 756:	3301      	adds	r3, #1
 758:	6013      	str	r3, [r2, #0]
 75a:	4bc5      	ldr	r3, [pc, #788]	@ (a70 <SystemNavigationBackend_Predict+0xa70>)
 75c:	781b      	ldrb	r3, [r3, #0]
 75e:	2b00      	cmp	r3, #0
 760:	f040 80e0 	bne.w	924 <SystemNavigationBackend_Predict+0x924>
 764:	4bc3      	ldr	r3, [pc, #780]	@ (a74 <SystemNavigationBackend_Predict+0xa74>)
 766:	781b      	ldrb	r3, [r3, #0]
 768:	2b00      	cmp	r3, #0
 76a:	f000 809d 	beq.w	8a8 <SystemNavigationBackend_Predict+0x8a8>
 76e:	ac0e      	add	r4, sp, #56	@ 0x38
 770:	4620      	mov	r0, r4
 772:	f7ff fffe 	bl	0 <EstimatorBus_PressureGetLatest>
			772: R_ARM_THM_CALL	EstimatorBus_PressureGetLatest
 776:	2800      	cmp	r0, #0
 778:	f000 8096 	beq.w	8a8 <SystemNavigationBackend_Predict+0x8a8>
 77c:	68a1      	ldr	r1, [r4, #8]
 77e:	f8d9 03c8 	ldr.w	r0, [r9, #968]	@ 0x3c8
 782:	68e2      	ldr	r2, [r4, #12]
 784:	f8d9 33cc 	ldr.w	r3, [r9, #972]	@ 0x3cc
 788:	4288      	cmp	r0, r1
 78a:	4193      	sbcs	r3, r2
 78c:	f0c0 808c 	bcc.w	8a8 <SystemNavigationBackend_Predict+0x8a8>
 790:	f8df b308 	ldr.w	fp, [pc, #776]	@ a9c <SystemNavigationBackend_Predict+0xa9c>
 794:	4fb8      	ldr	r7, [pc, #736]	@ (a78 <SystemNavigationBackend_Predict+0xa78>)
 796:	f89b 3000 	ldrb.w	r3, [fp]
 79a:	b123      	cbz	r3, 7a6 <SystemNavigationBackend_Predict+0x7a6>
 79c:	6962      	ldr	r2, [r4, #20]
 79e:	683b      	ldr	r3, [r7, #0]
 7a0:	429a      	cmp	r2, r3
 7a2:	f000 8081 	beq.w	8a8 <SystemNavigationBackend_Predict+0x8a8>
 7a6:	f894 0035 	ldrb.w	r0, [r4, #53]	@ 0x35
 7aa:	4ab4      	ldr	r2, [pc, #720]	@ (a7c <SystemNavigationBackend_Predict+0xa7c>)
 7ac:	2605      	movs	r6, #5
 7ae:	2801      	cmp	r0, #1
 7b0:	9600      	str	r6, [sp, #0]
 7b2:	bf8c      	ite	hi
 7b4:	2000      	movhi	r0, #0
 7b6:	2001      	movls	r0, #1
 7b8:	f44f 737a 	mov.w	r3, #1000	@ 0x3e8
 7bc:	2102      	movs	r1, #2
 7be:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			7be: R_ARM_THM_CALL	SilverStarAssert_Check
 7c2:	9600      	str	r6, [sp, #0]
 7c4:	f894 0034 	ldrb.w	r0, [r4, #52]	@ 0x34
 7c8:	4aac      	ldr	r2, [pc, #688]	@ (a7c <SystemNavigationBackend_Predict+0xa7c>)
 7ca:	2801      	cmp	r0, #1
 7cc:	bf8c      	ite	hi
 7ce:	2000      	movhi	r0, #0
 7d0:	2001      	movls	r0, #1
 7d2:	f240 33e9 	movw	r3, #1001	@ 0x3e9
 7d6:	2102      	movs	r1, #2
 7d8:	f7ff fffe 	bl	0 <SilverStarAssert_Check>
			7d8: R_ARM_THM_CALL	SilverStarAssert_Check
 7dc:	4ba8      	ldr	r3, [pc, #672]	@ (a80 <SystemNavigationBackend_Predict+0xa80>)
 7de:	ed94 8a09 	vldr	s16, [r4, #36]	@ 0x24
 7e2:	edd3 7a00 	vldr	s15, [r3]
 7e6:	f8d4 a014 	ldr.w	sl, [r4, #20]
 7ea:	f8d4 800c 	ldr.w	r8, [r4, #12]
 7ee:	f8c7 a000 	str.w	sl, [r7]
 7f2:	ee38 8a67 	vsub.f32	s16, s16, s15
 7f6:	ae36      	add	r6, sp, #216	@ 0xd8
 7f8:	68a7      	ldr	r7, [r4, #8]
 7fa:	ed85 8a40 	vstr	s16, [r5, #256]	@ 0x100
 7fe:	2301      	movs	r3, #1
 800:	2248      	movs	r2, #72	@ 0x48
 802:	2100      	movs	r1, #0
 804:	f8c5 a19c 	str.w	sl, [r5, #412]	@ 0x19c
 808:	f8c5 7190 	str.w	r7, [r5, #400]	@ 0x190
 80c:	f8c5 8194 	str.w	r8, [r5, #404]	@ 0x194
 810:	4630      	mov	r0, r6
 812:	f88b 3000 	strb.w	r3, [fp]
 816:	f7ff fffe 	bl	0 <memset>
			816: R_ARM_THM_CALL	memset
 81a:	2278      	movs	r2, #120	@ 0x78
 81c:	2100      	movs	r1, #0
 81e:	a858      	add	r0, sp, #352	@ 0x160
 820:	f7ff fffe 	bl	0 <memset>
			820: R_ARM_THM_CALL	memset
 824:	f8d9 23d0 	ldr.w	r2, [r9, #976]	@ 0x3d0
 828:	f894 3035 	ldrb.w	r3, [r4, #53]	@ 0x35
 82c:	6172      	str	r2, [r6, #20]
 82e:	2204      	movs	r2, #4
 830:	e9c6 7802 	strd	r7, r8, [r6, #8]
 834:	f8c6 a010 	str.w	sl, [r6, #16]
 838:	7732      	strb	r2, [r6, #28]
 83a:	b173      	cbz	r3, 85a <SystemNavigationBackend_Predict+0x85a>
 83c:	f894 3034 	ldrb.w	r3, [r4, #52]	@ 0x34
 840:	b15b      	cbz	r3, 85a <SystemNavigationBackend_Predict+0x85a>
 842:	e9d9 23f2 	ldrd	r2, r3, [r9, #968]	@ 0x3c8
 846:	498f      	ldr	r1, [pc, #572]	@ (a84 <SystemNavigationBackend_Predict+0xa84>)
 848:	1bd2      	subs	r2, r2, r7
 84a:	eb63 0308 	sbc.w	r3, r3, r8
 84e:	428a      	cmp	r2, r1
 850:	f173 0300 	sbcs.w	r3, r3, #0
 854:	bf34      	ite	cc
 856:	2301      	movcc	r3, #1
 858:	2300      	movcs	r3, #0
 85a:	ed94 0a0a 	vldr	s0, [r4, #40]	@ 0x28
 85e:	7773      	strb	r3, [r6, #29]
 860:	eef1 0a09 	vmov.f32	s1, #25	@ 0x40c80000  6.250
 864:	ed86 8a08 	vstr	s16, [r6, #32]
 868:	f7ff fffe 	bl	0 <fmaxf>
			868: R_ARM_THM_CALL	fmaxf
 86c:	9602      	str	r6, [sp, #8]
 86e:	7c23      	ldrb	r3, [r4, #16]
 870:	ed86 0a0a 	vstr	s0, [r6, #40]	@ 0x28
 874:	9300      	str	r3, [sp, #0]
 876:	f04f 537e 	mov.w	r3, #1065353216	@ 0x3f800000
 87a:	936c      	str	r3, [sp, #432]	@ 0x1b0
 87c:	936d      	str	r3, [sp, #436]	@ 0x1b4
 87e:	e9dd 230e 	ldrd	r2, r3, [sp, #56]	@ 0x38
 882:	4638      	mov	r0, r7
 884:	2700      	movs	r7, #0
 886:	4641      	mov	r1, r8
 888:	9701      	str	r7, [sp, #4]
 88a:	e9cd 2356 	strd	r2, r3, [sp, #344]	@ 0x158
 88e:	ed8d 0a67 	vstr	s0, [sp, #412]	@ 0x19c
 892:	f7ff fffe 	bl	0 <SystemTime_MeasurementTimestampResolve>
			892: R_ARM_THM_CALL	SystemTime_MeasurementTimestampResolve
 896:	2800      	cmp	r0, #0
 898:	f000 8102 	beq.w	aa0 <SystemNavigationBackend_Predict+0xaa0>
 89c:	7777      	strb	r7, [r6, #29]
 89e:	462a      	mov	r2, r5
 8a0:	a956      	add	r1, sp, #344	@ 0x158
 8a2:	4630      	mov	r0, r6
 8a4:	f7ff fffe 	bl	0 <SystemNavigationBackend_Predict>
			8a4: R_ARM_THM_CALL	Backend_EventApply
 8a8:	f8d5 2160 	ldr.w	r2, [r5, #352]	@ 0x160
 8ac:	68ab      	ldr	r3, [r5, #8]
 8ae:	3201      	adds	r2, #1
 8b0:	3301      	adds	r3, #1
 8b2:	f8c5 2160 	str.w	r2, [r5, #352]	@ 0x160
 8b6:	60ab      	str	r3, [r5, #8]
 8b8:	4628      	mov	r0, r5
 8ba:	f7ff fffe 	bl	0 <SystemNavigationBackend_Predict>
			8ba: R_ARM_THM_CALL	SystemNavigationBackend_SnapshotGet
 8be:	4604      	mov	r4, r0
 8c0:	2800      	cmp	r0, #0
 8c2:	d161      	bne.n	988 <SystemNavigationBackend_Predict+0x988>
 8c4:	f7ff fffe 	bl	0 <SystemNavigationBackend_Predict>
			8c4: R_ARM_THM_CALL	Backend_StateLog
 8c8:	e000      	b.n	8cc <SystemNavigationBackend_Predict+0x8cc>
 8ca:	2405      	movs	r4, #5
 8cc:	4620      	mov	r0, r4
 8ce:	f50d 7d03 	add.w	sp, sp, #524	@ 0x20c
 8d2:	ecbd 8b04 	vpop	{d8-d9}
 8d6:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 8da:	2402      	movs	r4, #2
 8dc:	4620      	mov	r0, r4
 8de:	f50d 7d03 	add.w	sp, sp, #524	@ 0x20c
 8e2:	ecbd 8b04 	vpop	{d8-d9}
 8e6:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 8ea:	e9d6 ab0e 	ldrd	sl, fp, [r6, #56]	@ 0x38
 8ee:	4a66      	ldr	r2, [pc, #408]	@ (a88 <SystemNavigationBackend_Predict+0xa88>)
 8f0:	4866      	ldr	r0, [pc, #408]	@ (a8c <SystemNavigationBackend_Predict+0xa8c>)
 8f2:	4649      	mov	r1, r9
 8f4:	e9c9 abf2 	strd	sl, fp, [r9, #968]	@ 0x3c8
 8f8:	f7ff fffe 	bl	0 <NavigationEskfReplay_Reset>
			8f8: R_ARM_THM_CALL	NavigationEskfReplay_Reset
 8fc:	2800      	cmp	r0, #0
 8fe:	d143      	bne.n	988 <SystemNavigationBackend_Predict+0x988>
 900:	e9d6 010e 	ldrd	r0, r1, [r6, #56]	@ 0x38
 904:	f7ff fffe 	bl	0 <SystemNavigationHealth_EpochSet>
			904: R_ARM_THM_CALL	SystemNavigationHealth_EpochSet
 908:	2001      	movs	r0, #1
 90a:	f7ff fffe 	bl	0 <SystemNavigationBackend_Predict>
			90a: R_ARM_THM_CALL	Backend_StateLog
 90e:	2301      	movs	r3, #1
 910:	703b      	strb	r3, [r7, #0]
 912:	e42d      	b.n	170 <SystemNavigationBackend_Predict+0x170>
 914:	4a55      	ldr	r2, [pc, #340]	@ (a6c <SystemNavigationBackend_Predict+0xa6c>)
 916:	6813      	ldr	r3, [r2, #0]
 918:	3301      	adds	r3, #1
 91a:	6013      	str	r3, [r2, #0]
 91c:	e46d      	b.n	1fa <SystemNavigationBackend_Predict+0x1fa>
 91e:	4a54      	ldr	r2, [pc, #336]	@ (a70 <SystemNavigationBackend_Predict+0xa70>)
 920:	2301      	movs	r3, #1
 922:	7013      	strb	r3, [r2, #0]
 924:	f8d5 3180 	ldr.w	r3, [r5, #384]	@ 0x180
 928:	f043 0308 	orr.w	r3, r3, #8
 92c:	2200      	movs	r2, #0
 92e:	f8c5 3180 	str.w	r3, [r5, #384]	@ 0x180
 932:	4b57      	ldr	r3, [pc, #348]	@ (a90 <SystemNavigationBackend_Predict+0xa90>)
 934:	f8a5 21a8 	strh.w	r2, [r5, #424]	@ 0x1a8
 938:	2010      	movs	r0, #16
 93a:	701a      	strb	r2, [r3, #0]
 93c:	f7ff fffe 	bl	0 <SystemNavigationHealth_ImuQualityRecord>
			93c: R_ARM_THM_CALL	SystemNavigationHealth_ImuQualityRecord
 940:	2408      	movs	r4, #8
 942:	e7c3      	b.n	8cc <SystemNavigationBackend_Predict+0x8cc>
 944:	eddd 0a70 	vldr	s1, [sp, #448]	@ 0x1c0
 948:	eddd 7a6f 	vldr	s15, [sp, #444]	@ 0x1bc
 94c:	bb3e      	cbnz	r6, 99e <SystemNavigationBackend_Predict+0x99e>
 94e:	eef0 0a67 	vmov.f32	s1, s15
 952:	eeb7 0a08 	vmov.f32	s0, #120	@ 0x3fc00000  1.5
 956:	f7ff fffe 	bl	0 <fmaxf>
			956: R_ARM_THM_CALL	fmaxf
 95a:	ee20 0a00 	vmul.f32	s0, s0, s0
 95e:	f8d8 1000 	ldr.w	r1, [r8]
 962:	ed85 0a00 	vstr	s0, [r5]
 966:	e617      	b.n	598 <SystemNavigationBackend_Predict+0x598>
 968:	f8d5 3180 	ldr.w	r3, [r5, #384]	@ 0x180
 96c:	4948      	ldr	r1, [pc, #288]	@ (a90 <SystemNavigationBackend_Predict+0xa90>)
 96e:	2200      	movs	r2, #0
 970:	f043 0308 	orr.w	r3, r3, #8
 974:	f8a5 21a8 	strh.w	r2, [r5, #424]	@ 0x1a8
 978:	f8c5 3180 	str.w	r3, [r5, #384]	@ 0x180
 97c:	2010      	movs	r0, #16
 97e:	700a      	strb	r2, [r1, #0]
 980:	2408      	movs	r4, #8
 982:	f7ff fffe 	bl	0 <SystemNavigationHealth_ImuQualityRecord>
			982: R_ARM_THM_CALL	SystemNavigationHealth_ImuQualityRecord
 986:	e7a1      	b.n	8cc <SystemNavigationBackend_Predict+0x8cc>
 988:	240b      	movs	r4, #11
 98a:	e79f      	b.n	8cc <SystemNavigationBackend_Predict+0x8cc>
 98c:	f89d 3168 	ldrb.w	r3, [sp, #360]	@ 0x168
 990:	2b00      	cmp	r3, #0
 992:	bf0c      	ite	eq
 994:	2309      	moveq	r3, #9
 996:	2305      	movne	r3, #5
 998:	f886 3074 	strb.w	r3, [r6, #116]	@ 0x74
 99c:	e5df      	b.n	55e <SystemNavigationBackend_Predict+0x55e>
 99e:	eeb0 0a04 	vmov.f32	s0, #4	@ 0x40200000  2.5
 9a2:	e7d8      	b.n	956 <SystemNavigationBackend_Predict+0x956>
 9a4:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			9a4: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
 9a8:	f04f 0b00 	mov.w	fp, #0
 9ac:	e597      	b.n	4de <SystemNavigationBackend_Predict+0x4de>
 9ae:	eef7 9a00 	vmov.f32	s19, #112	@ 0x3f800000  1.0
 9b2:	ae36      	add	r6, sp, #216	@ 0xd8
 9b4:	e56f      	b.n	496 <SystemNavigationBackend_Predict+0x496>
 9b6:	e9d4 0200 	ldrd	r0, r2, [r4]
 9ba:	e9dd 1358 	ldrd	r1, r3, [sp, #352]	@ 0x160
 9be:	429a      	cmp	r2, r3
 9c0:	bf08      	it	eq
 9c2:	4288      	cmpeq	r0, r1
 9c4:	f47f aeae 	bne.w	724 <SystemNavigationBackend_Predict+0x724>
 9c8:	e9d4 2304 	ldrd	r2, r3, [r4, #16]
 9cc:	459b      	cmp	fp, r3
 9ce:	bf08      	it	eq
 9d0:	4590      	cmpeq	r8, r2
 9d2:	d106      	bne.n	9e2 <SystemNavigationBackend_Predict+0x9e2>
 9d4:	f896 305a 	ldrb.w	r3, [r6, #90]	@ 0x5a
 9d8:	2201      	movs	r2, #1
 9da:	40ba      	lsls	r2, r7
 9dc:	4313      	orrs	r3, r2
 9de:	f886 305a 	strb.w	r3, [r6, #90]	@ 0x5a
 9e2:	f894 303b 	ldrb.w	r3, [r4, #59]	@ 0x3b
 9e6:	2b00      	cmp	r3, #0
 9e8:	f43f ae9c 	beq.w	724 <SystemNavigationBackend_Predict+0x724>
 9ec:	e9d4 2306 	ldrd	r2, r3, [r4, #24]
 9f0:	459b      	cmp	fp, r3
 9f2:	bf08      	it	eq
 9f4:	4590      	cmpeq	r8, r2
 9f6:	f47f ae95 	bne.w	724 <SystemNavigationBackend_Predict+0x724>
 9fa:	f896 305b 	ldrb.w	r3, [r6, #91]	@ 0x5b
 9fe:	2201      	movs	r2, #1
 a00:	40ba      	lsls	r2, r7
 a02:	4313      	orrs	r3, r2
 a04:	f886 305b 	strb.w	r3, [r6, #91]	@ 0x5b
 a08:	e68c      	b.n	724 <SystemNavigationBackend_Predict+0x724>
 a0a:	2010      	movs	r0, #16
 a0c:	f7ff fffe 	bl	0 <SystemNavigationHealth_ImuQualityRecord>
			a0c: R_ARM_THM_CALL	SystemNavigationHealth_ImuQualityRecord
 a10:	e796      	b.n	940 <SystemNavigationBackend_Predict+0x940>
 a12:	4281      	cmp	r1, r0
 a14:	f47f ac53 	bne.w	2be <SystemNavigationBackend_Predict+0x2be>
 a18:	9f5b      	ldr	r7, [sp, #364]	@ 0x16c
 a1a:	481e      	ldr	r0, [pc, #120]	@ (a94 <SystemNavigationBackend_Predict+0xa94>)
 a1c:	e462      	b.n	2e4 <SystemNavigationBackend_Predict+0x2e4>
 a1e:	1a82      	subs	r2, r0, r2
 a20:	eb6e 0101 	sbc.w	r1, lr, r1
 a24:	e9c6 210a 	strd	r2, r1, [r6, #40]	@ 0x28
 a28:	2f00      	cmp	r7, #0
 a2a:	f43f ae44 	beq.w	6b6 <SystemNavigationBackend_Predict+0x6b6>
 a2e:	ea50 000e 	orrs.w	r0, r0, lr
 a32:	f43f ae3e 	beq.w	6b2 <SystemNavigationBackend_Predict+0x6b2>
 a36:	4f18      	ldr	r7, [pc, #96]	@ (a98 <SystemNavigationBackend_Predict+0xa98>)
 a38:	2000      	movs	r0, #0
 a3a:	4297      	cmp	r7, r2
 a3c:	4188      	sbcs	r0, r1
 a3e:	f4ff ae38 	bcc.w	6b2 <SystemNavigationBackend_Predict+0x6b2>
 a42:	2201      	movs	r2, #1
 a44:	f886 205e 	strb.w	r2, [r6, #94]	@ 0x5e
 a48:	f886 2060 	strb.w	r2, [r6, #96]	@ 0x60
 a4c:	f8d3 208c 	ldr.w	r2, [r3, #140]	@ 0x8c
 a50:	e639      	b.n	6c6 <SystemNavigationBackend_Predict+0x6c6>
 a52:	68a3      	ldr	r3, [r4, #8]
 a54:	e4a9      	b.n	3aa <SystemNavigationBackend_Predict+0x3aa>
 a56:	e9d4 1200 	ldrd	r1, r2, [r4]
 a5a:	e4a2      	b.n	3a2 <SystemNavigationBackend_Predict+0x3a2>
 a5c:	2600      	movs	r6, #0
 a5e:	f8ad 6190 	strh.w	r6, [sp, #400]	@ 0x190
 a62:	4637      	mov	r7, r6
 a64:	e44d      	b.n	302 <SystemNavigationBackend_Predict+0x302>
 a66:	2303      	movs	r3, #3
 a68:	e48c      	b.n	384 <SystemNavigationBackend_Predict+0x384>
 a6a:	bf00      	nop
	...
			a6c: R_ARM_ABS32	.bss.s_log_failures
			a70: R_ARM_ABS32	.bss.s_input_faulted
			a74: R_ARM_ABS32	.bss.s_baro_origin_valid
			a78: R_ARM_ABS32	.bss.s_baro_sequence
			a7c: R_ARM_ABS32	.rodata.Backend_StateLog.str1.4
			a80: R_ARM_ABS32	.bss.s_baro_origin
 a84:	0007a121 	.word	0x0007a121
	...
			a88: R_ARM_ABS32	.bss.s_body_history
			a8c: R_ARM_ABS32	.bss.silverstar_auto_eskf_history
			a90: R_ARM_ABS32	.bss.s_active
			a94: R_ARM_ABS32	.bss.s_gnss_sequence
 a98:	005b8d80 	.word	0x005b8d80
 a9c:	00000000 	.word	0x00000000
			a9c: R_ARM_ABS32	.bss.s_baro_seen
 aa0:	7c23      	ldrb	r3, [r4, #16]
 aa2:	2b00      	cmp	r3, #0
 aa4:	bf0c      	ite	eq
 aa6:	2309      	moveq	r3, #9
 aa8:	2305      	movne	r3, #5
 aaa:	f88d 31cc 	strb.w	r3, [sp, #460]	@ 0x1cc
 aae:	e6f6      	b.n	89e <SystemNavigationBackend_Predict+0x89e>
 ab0:	f89d 3190 	ldrb.w	r3, [sp, #400]	@ 0x190
 ab4:	900d      	str	r0, [sp, #52]	@ 0x34
 ab6:	f023 0303 	bic.w	r3, r3, #3
 aba:	e9cd 000b 	strd	r0, r0, [sp, #44]	@ 0x2c
 abe:	f88d 3190 	strb.w	r3, [sp, #400]	@ 0x190
 ac2:	e47a      	b.n	3ba <SystemNavigationBackend_Predict+0x3ba>
 ac4:	4810      	ldr	r0, [pc, #64]	@ (b08 <SystemNavigationBackend_Predict+0xb08>)
 ac6:	9f5b      	ldr	r7, [sp, #364]	@ 0x16c
 ac8:	6801      	ldr	r1, [r0, #0]
 aca:	428f      	cmp	r7, r1
 acc:	f47f ac0a 	bne.w	2e4 <SystemNavigationBackend_Predict+0x2e4>
 ad0:	e643      	b.n	75a <SystemNavigationBackend_Predict+0x75a>
 ad2:	490e      	ldr	r1, [pc, #56]	@ (b0c <SystemNavigationBackend_Predict+0xb0c>)
 ad4:	9a79      	ldr	r2, [sp, #484]	@ 0x1e4
 ad6:	e9d1 0700 	ldrd	r0, r7, [r1]
 ada:	f44f 717a 	mov.w	r1, #1000	@ 0x3e8
 ade:	fbe2 0701 	umlal	r0, r7, r2, r1
 ae2:	e9c6 0700 	strd	r0, r7, [r6]
 ae6:	46be      	mov	lr, r7
 ae8:	e5a2      	b.n	630 <SystemNavigationBackend_Predict+0x630>
 aea:	4909      	ldr	r1, [pc, #36]	@ (b10 <SystemNavigationBackend_Predict+0xb10>)
 aec:	1b1b      	subs	r3, r3, r4
 aee:	428b      	cmp	r3, r1
 af0:	4b06      	ldr	r3, [pc, #24]	@ (b0c <SystemNavigationBackend_Predict+0xb0c>)
 af2:	f67f ac9b 	bls.w	42c <SystemNavigationBackend_Predict+0x42c>
 af6:	6819      	ldr	r1, [r3, #0]
 af8:	4806      	ldr	r0, [pc, #24]	@ (b14 <SystemNavigationBackend_Predict+0xb14>)
 afa:	1809      	adds	r1, r1, r0
 afc:	6019      	str	r1, [r3, #0]
 afe:	6859      	ldr	r1, [r3, #4]
 b00:	f141 018c 	adc.w	r1, r1, #140	@ 0x8c
 b04:	6059      	str	r1, [r3, #4]
 b06:	e491      	b.n	42c <SystemNavigationBackend_Predict+0x42c>
	...
			b08: R_ARM_ABS32	.bss.s_gnss_sequence
			b0c: R_ARM_ABS32	.bss.s_native_week_us
 b10:	12064200 	.word	0x12064200
 b14:	d0e3a000 	.word	0xd0e3a000

Disassembly of section .text.SystemNavigationBackend_BodyInputFill:

00000000 <SystemNavigationBackend_BodyInputFill>:
   0:	b5f0      	push	{r4, r5, r6, r7, lr}
   2:	b083      	sub	sp, #12
   4:	461f      	mov	r7, r3
   6:	f240 43e6 	movw	r3, #1254	@ 0x4e6
   a:	460e      	mov	r6, r1
   c:	4615      	mov	r5, r2
   e:	9300      	str	r3, [sp, #0]
  10:	2202      	movs	r2, #2
  12:	4b19      	ldr	r3, [pc, #100]	@ (78 <SystemNavigationBackend_BodyInputFill+0x78>)
  14:	2108      	movs	r1, #8
  16:	4604      	mov	r4, r0
  18:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			18: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  1c:	f240 43e7 	movw	r3, #1255	@ 0x4e7
  20:	9300      	str	r3, [sp, #0]
  22:	4630      	mov	r0, r6
  24:	4b14      	ldr	r3, [pc, #80]	@ (78 <SystemNavigationBackend_BodyInputFill+0x78>)
  26:	2202      	movs	r2, #2
  28:	2104      	movs	r1, #4
  2a:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			2a: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  2e:	f44f 629d 	mov.w	r2, #1256	@ 0x4e8
  32:	9200      	str	r2, [sp, #0]
  34:	4628      	mov	r0, r5
  36:	4b10      	ldr	r3, [pc, #64]	@ (78 <SystemNavigationBackend_BodyInputFill+0x78>)
  38:	2202      	movs	r2, #2
  3a:	2104      	movs	r1, #4
  3c:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			3c: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  40:	6833      	ldr	r3, [r6, #0]
  42:	6872      	ldr	r2, [r6, #4]
  44:	68b1      	ldr	r1, [r6, #8]
  46:	68f0      	ldr	r0, [r6, #12]
  48:	6360      	str	r0, [r4, #52]	@ 0x34
  4a:	62a3      	str	r3, [r4, #40]	@ 0x28
  4c:	62e2      	str	r2, [r4, #44]	@ 0x2c
  4e:	6321      	str	r1, [r4, #48]	@ 0x30
  50:	6933      	ldr	r3, [r6, #16]
  52:	6972      	ldr	r2, [r6, #20]
  54:	63e2      	str	r2, [r4, #60]	@ 0x3c
  56:	63a3      	str	r3, [r4, #56]	@ 0x38
  58:	682b      	ldr	r3, [r5, #0]
  5a:	686a      	ldr	r2, [r5, #4]
  5c:	68a9      	ldr	r1, [r5, #8]
  5e:	68e8      	ldr	r0, [r5, #12]
  60:	64e0      	str	r0, [r4, #76]	@ 0x4c
  62:	6423      	str	r3, [r4, #64]	@ 0x40
  64:	6462      	str	r2, [r4, #68]	@ 0x44
  66:	64a1      	str	r1, [r4, #72]	@ 0x48
  68:	692b      	ldr	r3, [r5, #16]
  6a:	696a      	ldr	r2, [r5, #20]
  6c:	6562      	str	r2, [r4, #84]	@ 0x54
  6e:	6523      	str	r3, [r4, #80]	@ 0x50
  70:	65a7      	str	r7, [r4, #88]	@ 0x58
  72:	b003      	add	sp, #12
  74:	bdf0      	pop	{r4, r5, r6, r7, pc}
  76:	bf00      	nop
  78:	00000000 	.word	0x00000000
			78: R_ARM_ABS32	.rodata.Backend_StateLog.str1.4
