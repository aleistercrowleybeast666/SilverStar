
D:\python_software\SilverStar\.work\dev013_navclosure02\eskf15_1_default03\build\FCCG\SilverStar_F407\Release\auto\Generated\Src\project_metadata.o:     file format elf32-littlearm


Disassembly of section .text.SystemDescriptor_DeviceCountGet:

00000000 <SystemDescriptor_DeviceCountGet>:
   0:	4b06      	ldr	r3, [pc, #24]	@ (1c <SystemDescriptor_DeviceCountGet+0x1c>)
   2:	2000      	movs	r0, #0
   4:	f503 719a 	add.w	r1, r3, #308	@ 0x134
   8:	891a      	ldrh	r2, [r3, #8]
   a:	331c      	adds	r3, #28
   c:	f002 0201 	and.w	r2, r2, #1
  10:	4410      	add	r0, r2
  12:	428b      	cmp	r3, r1
  14:	b280      	uxth	r0, r0
  16:	d1f7      	bne.n	8 <SystemDescriptor_DeviceCountGet+0x8>
  18:	4770      	bx	lr
  1a:	bf00      	nop
  1c:	00000000 	.word	0x00000000
			1c: R_ARM_ABS32	.rodata.s_device_descriptors

Disassembly of section .text.SystemDescriptor_DeviceGet:

00000000 <SystemDescriptor_DeviceGet>:
   0:	b379      	cbz	r1, 62 <SystemDescriptor_DeviceGet+0x62>
   2:	b530      	push	{r4, r5, lr}
   4:	b083      	sub	sp, #12
   6:	460c      	mov	r4, r1
   8:	2284      	movs	r2, #132	@ 0x84
   a:	4b17      	ldr	r3, [pc, #92]	@ (68 <SystemDescriptor_DeviceGet+0x68>)
   c:	9200      	str	r2, [sp, #0]
   e:	2104      	movs	r1, #4
  10:	2207      	movs	r2, #7
  12:	4605      	mov	r5, r0
  14:	4620      	mov	r0, r4
  16:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			16: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  1a:	4914      	ldr	r1, [pc, #80]	@ (6c <SystemDescriptor_DeviceGet+0x6c>)
  1c:	2200      	movs	r2, #0
  1e:	468c      	mov	ip, r1
  20:	4613      	mov	r3, r2
  22:	f8bc e008 	ldrh.w	lr, [ip, #8]
  26:	f01e 0f01 	tst.w	lr, #1
  2a:	f10c 0c1c 	add.w	ip, ip, #28
  2e:	d003      	beq.n	38 <SystemDescriptor_DeviceGet+0x38>
  30:	429d      	cmp	r5, r3
  32:	d008      	beq.n	46 <SystemDescriptor_DeviceGet+0x46>
  34:	3301      	adds	r3, #1
  36:	b29b      	uxth	r3, r3
  38:	3201      	adds	r2, #1
  3a:	2a0b      	cmp	r2, #11
  3c:	d1f1      	bne.n	22 <SystemDescriptor_DeviceGet+0x22>
  3e:	2305      	movs	r3, #5
  40:	4618      	mov	r0, r3
  42:	b003      	add	sp, #12
  44:	bd30      	pop	{r4, r5, pc}
  46:	ebc2 02c2 	rsb	r2, r2, r2, lsl #3
  4a:	eb01 0582 	add.w	r5, r1, r2, lsl #2
  4e:	cd0f      	ldmia	r5!, {r0, r1, r2, r3}
  50:	c40f      	stmia	r4!, {r0, r1, r2, r3}
  52:	e895 0007 	ldmia.w	r5, {r0, r1, r2}
  56:	2300      	movs	r3, #0
  58:	e884 0007 	stmia.w	r4, {r0, r1, r2}
  5c:	4618      	mov	r0, r3
  5e:	b003      	add	sp, #12
  60:	bd30      	pop	{r4, r5, pc}
  62:	2305      	movs	r3, #5
  64:	4618      	mov	r0, r3
  66:	4770      	bx	lr
	...
			68: R_ARM_ABS32	.rodata.SystemDescriptor_DeviceGet.str1.4
			6c: R_ARM_ABS32	.rodata.s_device_descriptors

Disassembly of section .text.SystemDescriptor_DeviceClassInstanceCountGet:

00000000 <SystemDescriptor_DeviceClassInstanceCountGet>:
   0:	4b08      	ldr	r3, [pc, #32]	@ (24 <SystemDescriptor_DeviceClassInstanceCountGet+0x24>)
   2:	4684      	mov	ip, r0
   4:	f503 719a 	add.w	r1, r3, #308	@ 0x134
   8:	2000      	movs	r0, #0
   a:	891a      	ldrh	r2, [r3, #8]
   c:	07d2      	lsls	r2, r2, #31
   e:	d504      	bpl.n	1a <SystemDescriptor_DeviceClassInstanceCountGet+0x1a>
  10:	791a      	ldrb	r2, [r3, #4]
  12:	4562      	cmp	r2, ip
  14:	bf04      	itt	eq
  16:	3001      	addeq	r0, #1
  18:	b2c0      	uxtbeq	r0, r0
  1a:	331c      	adds	r3, #28
  1c:	4299      	cmp	r1, r3
  1e:	d1f4      	bne.n	a <SystemDescriptor_DeviceClassInstanceCountGet+0xa>
  20:	4770      	bx	lr
  22:	bf00      	nop
  24:	00000000 	.word	0x00000000
			24: R_ARM_ABS32	.rodata.s_device_descriptors

Disassembly of section .text.SystemDescriptor_DeviceFind:

00000000 <SystemDescriptor_DeviceFind>:
   0:	b3a2      	cbz	r2, 6c <SystemDescriptor_DeviceFind+0x6c>
   2:	b570      	push	{r4, r5, r6, lr}
   4:	b082      	sub	sp, #8
   6:	4615      	mov	r5, r2
   8:	22b6      	movs	r2, #182	@ 0xb6
   a:	4b1a      	ldr	r3, [pc, #104]	@ (74 <SystemDescriptor_DeviceFind+0x74>)
   c:	9200      	str	r2, [sp, #0]
   e:	4604      	mov	r4, r0
  10:	2207      	movs	r2, #7
  12:	460e      	mov	r6, r1
  14:	4628      	mov	r0, r5
  16:	2104      	movs	r1, #4
  18:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			18: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  1c:	4a16      	ldr	r2, [pc, #88]	@ (78 <SystemDescriptor_DeviceFind+0x78>)
  1e:	f04f 0c00 	mov.w	ip, #0
  22:	4613      	mov	r3, r2
  24:	e006      	b.n	34 <SystemDescriptor_DeviceFind+0x34>
  26:	f10c 0c01 	add.w	ip, ip, #1
  2a:	f1bc 0f0b 	cmp.w	ip, #11
  2e:	f103 031c 	add.w	r3, r3, #28
  32:	d017      	beq.n	64 <SystemDescriptor_DeviceFind+0x64>
  34:	f8b3 e008 	ldrh.w	lr, [r3, #8]
  38:	f01e 0f01 	tst.w	lr, #1
  3c:	d0f3      	beq.n	26 <SystemDescriptor_DeviceFind+0x26>
  3e:	f893 e004 	ldrb.w	lr, [r3, #4]
  42:	45a6      	cmp	lr, r4
  44:	d1ef      	bne.n	26 <SystemDescriptor_DeviceFind+0x26>
  46:	7959      	ldrb	r1, [r3, #5]
  48:	42b1      	cmp	r1, r6
  4a:	d1ec      	bne.n	26 <SystemDescriptor_DeviceFind+0x26>
  4c:	ebcc 0ccc 	rsb	ip, ip, ip, lsl #3
  50:	eb02 048c 	add.w	r4, r2, ip, lsl #2
  54:	cc0f      	ldmia	r4!, {r0, r1, r2, r3}
  56:	c50f      	stmia	r5!, {r0, r1, r2, r3}
  58:	e894 0007 	ldmia.w	r4, {r0, r1, r2}
  5c:	2300      	movs	r3, #0
  5e:	e885 0007 	stmia.w	r5, {r0, r1, r2}
  62:	e000      	b.n	66 <SystemDescriptor_DeviceFind+0x66>
  64:	2310      	movs	r3, #16
  66:	4618      	mov	r0, r3
  68:	b002      	add	sp, #8
  6a:	bd70      	pop	{r4, r5, r6, pc}
  6c:	2305      	movs	r3, #5
  6e:	4618      	mov	r0, r3
  70:	4770      	bx	lr
  72:	bf00      	nop
	...
			74: R_ARM_ABS32	.rodata.SystemDescriptor_DeviceGet.str1.4
			78: R_ARM_ABS32	.rodata.s_device_descriptors

Disassembly of section .text.SystemDescriptor_AlgorithmCountGet:

00000000 <SystemDescriptor_AlgorithmCountGet>:
   0:	2004      	movs	r0, #4
   2:	4770      	bx	lr

Disassembly of section .text.SystemDescriptor_AlgorithmGet:

00000000 <SystemDescriptor_AlgorithmGet>:
   0:	468c      	mov	ip, r1
   2:	b149      	cbz	r1, 18 <SystemDescriptor_AlgorithmGet+0x18>
   4:	2803      	cmp	r0, #3
   6:	d807      	bhi.n	18 <SystemDescriptor_AlgorithmGet+0x18>
   8:	4b04      	ldr	r3, [pc, #16]	@ (1c <SystemDescriptor_AlgorithmGet+0x1c>)
   a:	eb03 1000 	add.w	r0, r3, r0, lsl #4
   e:	c80f      	ldmia	r0, {r0, r1, r2, r3}
  10:	e88c 000f 	stmia.w	ip, {r0, r1, r2, r3}
  14:	2000      	movs	r0, #0
  16:	4770      	bx	lr
  18:	2005      	movs	r0, #5
  1a:	4770      	bx	lr
  1c:	00000000 	.word	0x00000000
			1c: R_ARM_ABS32	.rodata.s_algorithm_descriptors

Disassembly of section .text.SystemDescriptor_ConfigDigestGet:

00000000 <SystemDescriptor_ConfigDigestGet>:
   0:	4800      	ldr	r0, [pc, #0]	@ (4 <SystemDescriptor_ConfigDigestGet+0x4>)
   2:	4770      	bx	lr
   4:	8c2e6b38 	.word	0x8c2e6b38
