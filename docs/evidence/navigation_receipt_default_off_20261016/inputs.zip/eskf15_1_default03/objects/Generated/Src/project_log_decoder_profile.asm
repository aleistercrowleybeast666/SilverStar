
D:\python_software\SilverStar\.work\dev013_navclosure02\eskf15_1_default03\build\FCCG\SilverStar_F407\Release\auto\Generated\Src\project_log_decoder_profile.o:     file format elf32-littlearm


Disassembly of section .text.ProjectLogDecoderProfile_Get:

00000000 <ProjectLogDecoderProfile_Get>:
   0:	b530      	push	{r4, r5, lr}
   2:	b083      	sub	sp, #12
   4:	221b      	movs	r2, #27
   6:	4b12      	ldr	r3, [pc, #72]	@ (50 <ProjectLogDecoderProfile_Get+0x50>)
   8:	9200      	str	r2, [sp, #0]
   a:	4604      	mov	r4, r0
   c:	2207      	movs	r2, #7
   e:	2102      	movs	r1, #2
  10:	f7ff fffe 	bl	0 <SilverStarAssert_ObjectCheck>
			10: R_ARM_THM_CALL	SilverStarAssert_ObjectCheck
  14:	2234      	movs	r2, #52	@ 0x34
  16:	2100      	movs	r1, #0
  18:	1d20      	adds	r0, r4, #4
  1a:	f7ff fffe 	bl	0 <memset>
			1a: R_ARM_THM_CALL	memset
  1e:	46a4      	mov	ip, r4
  20:	4b0c      	ldr	r3, [pc, #48]	@ (54 <ProjectLogDecoderProfile_Get+0x54>)
  22:	4d0d      	ldr	r5, [pc, #52]	@ (58 <ProjectLogDecoderProfile_Get+0x58>)
  24:	f84c 3b08 	str.w	r3, [ip], #8
  28:	f105 0e30 	add.w	lr, r5, #48	@ 0x30
  2c:	462c      	mov	r4, r5
  2e:	cc0f      	ldmia	r4!, {r0, r1, r2, r3}
  30:	4574      	cmp	r4, lr
  32:	f10c 0c10 	add.w	ip, ip, #16
  36:	f105 0510 	add.w	r5, r5, #16
  3a:	f84c 0c10 	str.w	r0, [ip, #-16]
  3e:	f84c 1c0c 	str.w	r1, [ip, #-12]
  42:	f84c 2c08 	str.w	r2, [ip, #-8]
  46:	f84c 3c04 	str.w	r3, [ip, #-4]
  4a:	d1ef      	bne.n	2c <ProjectLogDecoderProfile_Get+0x2c>
  4c:	b003      	add	sp, #12
  4e:	bd30      	pop	{r4, r5, pc}
  50:	00000000 	.word	0x00000000
			50: R_ARM_ABS32	.rodata.ProjectLogDecoderProfile_Get.str1.4
  54:	00020001 	.word	0x00020001
  58:	0000002c 	.word	0x0000002c
			58: R_ARM_ABS32	.rodata.ProjectLogDecoderProfile_Get.str1.4
