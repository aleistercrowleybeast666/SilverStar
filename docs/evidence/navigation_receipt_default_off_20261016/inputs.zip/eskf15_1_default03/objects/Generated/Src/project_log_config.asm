
D:\python_software\SilverStar\.work\dev013_navclosure02\eskf15_1_default03\build\FCCG\SilverStar_F407\Release\auto\Generated\Src\project_log_config.o:     file format elf32-littlearm


Disassembly of section .text.ProjectLogConfig_RecordSupported:

00000000 <ProjectLogConfig_RecordSupported>:
   0:	2811      	cmp	r0, #17
   2:	d809      	bhi.n	18 <ProjectLogConfig_RecordSupported+0x18>
   4:	2801      	cmp	r0, #1
   6:	d905      	bls.n	14 <ProjectLogConfig_RecordSupported+0x14>
   8:	4b09      	ldr	r3, [pc, #36]	@ (30 <ProjectLogConfig_RecordSupported+0x30>)
   a:	fa23 f000 	lsr.w	r0, r3, r0
   e:	f000 0001 	and.w	r0, r0, #1
  12:	4770      	bx	lr
  14:	2000      	movs	r0, #0
  16:	4770      	bx	lr
  18:	282a      	cmp	r0, #42	@ 0x2a
  1a:	d905      	bls.n	28 <ProjectLogConfig_RecordSupported+0x28>
  1c:	382d      	subs	r0, #45	@ 0x2d
  1e:	2801      	cmp	r0, #1
  20:	bf8c      	ite	hi
  22:	2000      	movhi	r0, #0
  24:	2001      	movls	r0, #1
  26:	4770      	bx	lr
  28:	3812      	subs	r0, #18
  2a:	bf18      	it	ne
  2c:	2001      	movne	r0, #1
  2e:	4770      	bx	lr
  30:	0003bc2c 	.word	0x0003bc2c

Disassembly of section .text.ProjectLogConfig_StreamCountGet:

00000000 <ProjectLogConfig_StreamCountGet>:
   0:	202a      	movs	r0, #42	@ 0x2a
   2:	4770      	bx	lr

Disassembly of section .text.ProjectLogConfig_StreamByIndexGet:

00000000 <ProjectLogConfig_StreamByIndexGet>:
   0:	2829      	cmp	r0, #41	@ 0x29
   2:	bf9d      	ittte	ls
   4:	4b03      	ldrls	r3, [pc, #12]	@ (14 <ProjectLogConfig_StreamByIndexGet+0x14>)
   6:	eb00 0040 	addls.w	r0, r0, r0, lsl #1
   a:	eb03 0080 	addls.w	r0, r3, r0, lsl #2
   e:	2000      	movhi	r0, #0
  10:	4770      	bx	lr
  12:	bf00      	nop
  14:	00000000 	.word	0x00000000
			14: R_ARM_ABS32	.rodata.s_project_log_streams
