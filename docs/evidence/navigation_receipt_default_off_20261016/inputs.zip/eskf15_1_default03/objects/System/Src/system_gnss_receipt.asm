
D:\python_software\SilverStar\.work\dev013_navclosure02\eskf15_1_default03\build\FCCG\SilverStar_F407\Release\auto\System\Src\system_gnss_receipt.o:     file format elf32-littlearm


Disassembly of section .text.SystemGnss_ReceiptSnapshotGet:

00000000 <SystemGnss_ReceiptSnapshotGet>:
   0:	b570      	push	{r4, r5, r6, lr}
   2:	b0ae      	sub	sp, #184	@ 0xb8
   4:	4605      	mov	r5, r0
   6:	22b0      	movs	r2, #176	@ 0xb0
   8:	2100      	movs	r1, #0
   a:	a802      	add	r0, sp, #8
   c:	f7ff fffe 	bl	0 <memset>
			c: R_ARM_THM_CALL	memset
  10:	23ff      	movs	r3, #255	@ 0xff
  12:	f88d 3007 	strb.w	r3, [sp, #7]
  16:	b1e5      	cbz	r5, 52 <SystemGnss_ReceiptSnapshotGet+0x52>
  18:	2302      	movs	r3, #2
  1a:	f88d 30b0 	strb.w	r3, [sp, #176]	@ 0xb0
  1e:	f7ff fffe 	bl	0 <PlatformCritical_Enter>
			1e: R_ARM_THM_CALL	PlatformCritical_Enter
  22:	4606      	mov	r6, r0
  24:	f10d 00b1 	add.w	r0, sp, #177	@ 0xb1
  28:	f7ff fffe 	bl	0 <SystemSourceSelector_GnssActiveInstanceGet>
			28: R_ARM_THM_CALL	SystemSourceSelector_GnssActiveInstanceGet
  2c:	4604      	mov	r4, r0
  2e:	b950      	cbnz	r0, 46 <SystemGnss_ReceiptSnapshotGet+0x46>
  30:	f89d 30b1 	ldrb.w	r3, [sp, #177]	@ 0xb1
  34:	2b03      	cmp	r3, #3
  36:	d910      	bls.n	5a <SystemGnss_ReceiptSnapshotGet+0x5a>
  38:	4630      	mov	r0, r6
  3a:	f7ff fffe 	bl	0 <PlatformCritical_Exit>
			3a: R_ARM_THM_CALL	PlatformCritical_Exit
  3e:	2409      	movs	r4, #9
  40:	4620      	mov	r0, r4
  42:	b02e      	add	sp, #184	@ 0xb8
  44:	bd70      	pop	{r4, r5, r6, pc}
  46:	4630      	mov	r0, r6
  48:	f7ff fffe 	bl	0 <PlatformCritical_Exit>
			48: R_ARM_THM_CALL	PlatformCritical_Exit
  4c:	4620      	mov	r0, r4
  4e:	b02e      	add	sp, #184	@ 0xb8
  50:	bd70      	pop	{r4, r5, r6, pc}
  52:	2405      	movs	r4, #5
  54:	4620      	mov	r0, r4
  56:	b02e      	add	sp, #184	@ 0xb8
  58:	bd70      	pop	{r4, r5, r6, pc}
  5a:	a802      	add	r0, sp, #8
  5c:	f7ff fffe 	bl	0 <SystemGnss_LatestSampleGet>
			5c: R_ARM_THM_CALL	SystemGnss_LatestSampleGet
  60:	4604      	mov	r4, r0
  62:	2800      	cmp	r0, #0
  64:	d1ef      	bne.n	46 <SystemGnss_ReceiptSnapshotGet+0x46>
  66:	a820      	add	r0, sp, #128	@ 0x80
  68:	f7ff fffe 	bl	0 <SystemGnss_TimeGet>
			68: R_ARM_THM_CALL	SystemGnss_TimeGet
  6c:	4603      	mov	r3, r0
  6e:	f10d 0007 	add.w	r0, sp, #7
  72:	f88d 30b0 	strb.w	r3, [sp, #176]	@ 0xb0
  76:	f7ff fffe 	bl	0 <SystemSourceSelector_GnssActiveInstanceGet>
			76: R_ARM_THM_CALL	SystemSourceSelector_GnssActiveInstanceGet
  7a:	4604      	mov	r4, r0
  7c:	2800      	cmp	r0, #0
  7e:	d1db      	bne.n	38 <SystemGnss_ReceiptSnapshotGet+0x38>
  80:	f89d 20b1 	ldrb.w	r2, [sp, #177]	@ 0xb1
  84:	f89d 3007 	ldrb.w	r3, [sp, #7]
  88:	429a      	cmp	r2, r3
  8a:	d1d5      	bne.n	38 <SystemGnss_ReceiptSnapshotGet+0x38>
  8c:	4630      	mov	r0, r6
  8e:	f7ff fffe 	bl	0 <PlatformCritical_Exit>
			8e: R_ARM_THM_CALL	PlatformCritical_Exit
  92:	22b0      	movs	r2, #176	@ 0xb0
  94:	a902      	add	r1, sp, #8
  96:	4628      	mov	r0, r5
  98:	f7ff fffe 	bl	0 <memcpy>
			98: R_ARM_THM_CALL	memcpy
  9c:	4620      	mov	r0, r4
  9e:	b02e      	add	sp, #184	@ 0xb8
  a0:	bd70      	pop	{r4, r5, r6, pc}
  a2:	bf00      	nop

Disassembly of section .text.SystemGnssReceipt_ClockBasisGet:

00000000 <SystemGnssReceipt_ClockBasisGet>:
   0:	4603      	mov	r3, r0
   2:	2800      	cmp	r0, #0
   4:	d043      	beq.n	8e <SystemGnssReceipt_ClockBasisGet+0x8e>
   6:	6942      	ldr	r2, [r0, #20]
   8:	b3ca      	cbz	r2, 7e <SystemGnssReceipt_ClockBasisGet+0x7e>
   a:	b4f0      	push	{r4, r5, r6, r7}
   c:	e9d0 4100 	ldrd	r4, r1, [r0]
  10:	ea54 0001 	orrs.w	r0, r4, r1
  14:	d030      	beq.n	78 <SystemGnssReceipt_ClockBasisGet+0x78>
  16:	e9d3 6502 	ldrd	r6, r5, [r3, #8]
  1a:	42a6      	cmp	r6, r4
  1c:	eb75 0001 	sbcs.w	r0, r5, r1
  20:	d32a      	bcc.n	78 <SystemGnssReceipt_ClockBasisGet+0x78>
  22:	7c1f      	ldrb	r7, [r3, #16]
  24:	bb6f      	cbnz	r7, 82 <SystemGnssReceipt_ClockBasisGet+0x82>
  26:	f893 00a8 	ldrb.w	r0, [r3, #168]	@ 0xa8
  2a:	bb88      	cbnz	r0, 90 <SystemGnssReceipt_ClockBasisGet+0x90>
  2c:	f8d3 7088 	ldr.w	r7, [r3, #136]	@ 0x88
  30:	42ba      	cmp	r2, r7
  32:	d122      	bne.n	7a <SystemGnssReceipt_ClockBasisGet+0x7a>
  34:	e9d3 721e 	ldrd	r7, r2, [r3, #120]	@ 0x78
  38:	4291      	cmp	r1, r2
  3a:	bf08      	it	eq
  3c:	42bc      	cmpeq	r4, r7
  3e:	d11c      	bne.n	7a <SystemGnssReceipt_ClockBasisGet+0x7a>
  40:	e9d3 1220 	ldrd	r1, r2, [r3, #128]	@ 0x80
  44:	4295      	cmp	r5, r2
  46:	bf08      	it	eq
  48:	428e      	cmpeq	r6, r1
  4a:	d116      	bne.n	7a <SystemGnssReceipt_ClockBasisGet+0x7a>
  4c:	4a11      	ldr	r2, [pc, #68]	@ (94 <SystemGnssReceipt_ClockBasisGet+0x94>)
  4e:	f8d3 108c 	ldr.w	r1, [r3, #140]	@ 0x8c
  52:	4291      	cmp	r1, r2
  54:	d811      	bhi.n	7a <SystemGnssReceipt_ClockBasisGet+0x7a>
  56:	f893 20a0 	ldrb.w	r2, [r3, #160]	@ 0xa0
  5a:	2a01      	cmp	r2, #1
  5c:	d10d      	bne.n	7a <SystemGnssReceipt_ClockBasisGet+0x7a>
  5e:	f893 209f 	ldrb.w	r2, [r3, #159]	@ 0x9f
  62:	2a01      	cmp	r2, #1
  64:	d109      	bne.n	7a <SystemGnssReceipt_ClockBasisGet+0x7a>
  66:	f893 00a1 	ldrb.w	r0, [r3, #161]	@ 0xa1
  6a:	f1a0 0001 	sub.w	r0, r0, #1
  6e:	fab0 f080 	clz	r0, r0
  72:	0940      	lsrs	r0, r0, #5
  74:	0040      	lsls	r0, r0, #1
  76:	e000      	b.n	7a <SystemGnssReceipt_ClockBasisGet+0x7a>
  78:	2000      	movs	r0, #0
  7a:	bcf0      	pop	{r4, r5, r6, r7}
  7c:	4770      	bx	lr
  7e:	4610      	mov	r0, r2
  80:	4770      	bx	lr
  82:	f1a7 0001 	sub.w	r0, r7, #1
  86:	fab0 f080 	clz	r0, r0
  8a:	0940      	lsrs	r0, r0, #5
  8c:	e7f5      	b.n	7a <SystemGnssReceipt_ClockBasisGet+0x7a>
  8e:	4770      	bx	lr
  90:	4638      	mov	r0, r7
  92:	e7f2      	b.n	7a <SystemGnssReceipt_ClockBasisGet+0x7a>
  94:	240c83ff 	.word	0x240c83ff
