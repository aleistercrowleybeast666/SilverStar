# 0.1.3 native Qt GUI / real read-only SWD verification

Owner: root integrator; base 39ee1c038c0f3c3f97fa8b8ab913828ca79c2537.
User authorized existing read-only bench GUI attach/detach/repeat/exit verification.
Native Computer Use node_repl/sky tool is not exposed; no OS UI Automation used.
QtTest drives this app's native Windows widgets with its real Controller/main,
real SwdWorker and audited default pyOCD backend. Settings/data are isolated here.
Only exact Horco 132765403520; ordinary healthy sessions read identity/state only.
No UART, CPU control, target memory write, flash, calibration or actuator operation.
Packet guard retained from prior approved bench; fault cases are explicitly injected.
ELF match implementation absent in existing SWD API; no new flash reader or scan.
Retain scripts, native widget PNGs, sources/configuration, commands, logs and hashes.
No cleanup authorized. Previous formal logs/archives and v0.1.2 are untouched.
