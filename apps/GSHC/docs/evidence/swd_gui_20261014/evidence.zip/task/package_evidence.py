"""Small native GUI evidence package; never cleanup or open hardware."""
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

task=Path(__file__).absolute().parent
root=task.parents[1]
destination=root/'apps/GSHC/docs/evidence/swd_gui_20261014'
destination.mkdir(exist_ok=True)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,data):path.write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding='utf-8')
def git(*args):return subprocess.run(['git',*args],cwd=root,capture_output=True,text=True,check=True).stdout.strip()

sys.path.insert(0,str(root/'apps/GSHC'))
from PySide6 import __version__ as qt_version
import pytest
write(task/'versions.json',{'python':sys.version,'executable':sys.executable,
 'PySide6':qt_version,'pytest':pytest.__version__,'base_commit':git('rev-parse','HEAD'),
 'branch':git('branch','--show-current'),'git_status':git('status','--short'),
 'v012_tag':git('rev-parse','v0.1.2'),'v012_peeled':git('rev-parse','v0.1.2^{}'),
 'method':'Windows QtTest, real app.main/Controller/SwdWorker/backend; no OS input automation'})
result=json.loads((task/'run03/result.json').read_text(encoding='utf-8'))
assert not result['errors'] and result['final']['packet_count']==144 and result['serial_open_calls']==0
assert result['dependency_discovery']['swd_path_env'] is None and not result['pyocd_loaded_before_main']
assert all(sha(root/name)==digest for name,digest in result['sources'].items())
packets=[json.loads(line) for line in (task/'run03/packets.jsonl').read_text().splitlines()]
assert len(packets)==144 and all(row['allowed'] for row in packets)
assert not any(row['phase'].startswith('injected') for row in packets)

rows=[]
for path in task.rglob('*'):
 if not path.is_file() or path.name=='inventory.json':continue
 relative=path.relative_to(task).as_posix()
 rows.append({'path':str(path),'relative':relative,'owner':'root / dev013 SWD GUI QA',
  'purpose':'retained source/configuration/GUI evidence' if not relative.startswith(('cache/','pytest01/'))
       else 'generated test/cache payload retained; no cleanup authorized',
  'bytes':path.stat().st_size,'sha256':sha(path),'cleanup_authorized':False})
write(task/'inventory.json',{'root':str(task),'utc':datetime.now(timezone.utc).isoformat(),
 'files':rows,'total_bytes':sum(row['bytes'] for row in rows),'cleanup_authorized':False})

payload={'task/'+p.relative_to(task).as_posix():p for p in task.rglob('*') if p.is_file()
 and p.relative_to(task).parts[0] not in ('cache','pytest01') and '__pycache__' not in p.parts}
sources=['apps/GSHC/services/i18n.py','apps/GSHC/transport/_swd_pyocd.py',
 'apps/GSHC/transport/swd_session.py','apps/GSHC/ui/swd_connection.py',
 'apps/GSHC/main.py','docs/public/GSHC/SWD_GUI_CHECK_20261014.md']
payload.update({'source/'+name:root/name for name in sources})
payload['packet_guard_source/bench_readonly.py']=root/'.work/dev013_swd_pyocd01/bench_readonly.py'
archive=destination/'evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as out:
 for name,path in sorted(payload.items()):out.write(path,name)
write(destination/'manifest.json',{'archive':'evidence.zip','bytes':archive.stat().st_size,
 'sha256':sha(archive),'entries':{name:{'bytes':path.stat().st_size,'sha256':sha(path)}
 for name,path in sorted(payload.items())}})
print('evidence',archive.stat().st_size,sha(archive),'retained task bytes',sum(row['bytes'] for row in rows))
