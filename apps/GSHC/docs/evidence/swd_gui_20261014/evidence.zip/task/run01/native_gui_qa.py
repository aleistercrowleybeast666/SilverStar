"""Native Windows QtTest + real Controller/main + real SWD; no OS input injection."""
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
import threading
import time
import traceback
from unittest.mock import patch

root = Path(__file__).absolute().parents[2]
task = Path(__file__).absolute().parent
sys.path.insert(0, str(root/'apps/GSHC'))
os.environ.pop('SILVERSTAR_SWD_PYOCD_PATH', None)
os.environ.pop('QT_QPA_PLATFORM', None)
os.environ['SILVERSTAR_GSHC_DATA_ROOT'] = str(task/'user_data')
sys.argv = [str(root/'apps/GSHC/main.py')]

from PySide6.QtCore import Qt, QSettings, QTimer
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication
QSettings.setDefaultFormat(QSettings.IniFormat)
QSettings.setPath(QSettings.IniFormat, QSettings.UserScope, str(task/'settings'))
from transport.probe_inventory import ProbeInventory_Read, ProbeInventoryResult
from transport.swd_session import SwdSession, SwdResult, SwdError, _ProbeOwners
from transport import _swd_pyocd as adapter
from threading import Event
import app

IDENTITY = r'USB\VID_FAED&PID_4870\132765403520'
result = {'base_commit':'39ee1c038c0f3c3f97fa8b8ab913828ca79c2537',
    'method':'QtTest on native Windows widgets; no OS mouse automation',
    'swd_path_env':os.environ.get('SILVERSTAR_SWD_PYOCD_PATH'),
    'qt_platform_env':os.environ.get('QT_QPA_PLATFORM'),'steps':[], 'releases':[], 'errors':[]}
phase = 'preflight'

def value(obj):
    if isinstance(obj,bytes): return obj.hex()
    return obj.value

def save():
    (task/'result.json').write_text(json.dumps(result,default=value,indent=2,ensure_ascii=False),encoding='utf-8')

def preflight():
    names=['openocd.exe','pyocd.exe','ST-LINK_gdbserver.exe','STM32_Programmer_CLI.exe',
        'STM32CubeProgrammer.exe','JLink.exe','JLinkGDBServer.exe','JLinkGDBServerCL.exe',
        'Ozone.exe','UV4.exe','gdb.exe','arm-none-eabi-gdb.exe']
    script="$names=@("+','.join("'"+n+"'" for n in names)+"); @(Get-CimInstance Win32_Process | Where-Object { $names -contains $_.Name } | Select-Object Name,ProcessId) | ConvertTo-Json -Compress"
    check=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',script],
        capture_output=True,text=True,timeout=20)
    result['process_check']={'utc':datetime.now(timezone.utc).isoformat(),'exit':check.returncode,
        'stdout':check.stdout,'stderr':check.stderr,'names':names}
    assert check.returncode==0 and check.stdout.strip() in ('','[]','null'), 'Debugger present/inspection failed'
    inventory=ProbeInventory_Read(Event())
    result['inventory']=asdict(inventory)
    matches=[p for p in inventory.probes if p.identity==IDENTITY]
    assert inventory.result==ProbeInventoryResult.Ready and len(matches)==1 and matches[0].host_status=='OK'
    source=['apps/GSHC/main.py','apps/GSHC/app.py','apps/GSHC/ui/swd_connection.py',
        'apps/GSHC/transport/_swd_pyocd.py','apps/GSHC/transport/swd_session.py','apps/GSHC/services/i18n.py']
    result['sources']={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in source}
    result['pyocd_loaded_before_main']='pyocd' in sys.modules
    save()

preflight()
guard_globals=runpy.run_path(str(root/'.work/dev013_swd_pyocd01/bench_readonly.py'),run_name='packet_guard')
packet_check=guard_globals['check_packet']
packet_log=(task/'packets.jsonl').open('x',encoding='utf-8')
packet_count=0
api_seen=None
original_bulk=adapter._BulkInterface

def audited_bulk(api,device,guard):
    global api_seen
    api_seen=api
    interface=original_bulk(api,device,guard)
    writer=interface.write
    select=0
    def write(data):
        nonlocal select
        global packet_count
        select=packet_check(data,select)
        if packet_count>=500 and data[0] not in (1,3):
            raise SwdError(SwdResult.BudgetExceeded,'GUI test packet budget exceeded')
        packet_count+=1
        packet_log.write(json.dumps({'utc':datetime.now(timezone.utc).isoformat(),
            'phase':phase,'tx':bytes(data).hex(),'allowed':True})+'\n');packet_log.flush()
        return writer(data)
    interface.write=write
    return interface

adapter._BulkInterface=audited_bulk
original_close=adapter.PyOcdMemAp.close

def observed_close(self):
    interface=self._interface
    original_close(self)
    result['releases'].append({'phase':phase,'utc':datetime.now(timezone.utc).isoformat(),
        'interface_present_before':interface is not None,
        'interface_dev_none':interface is None or interface.dev is None,
        'rx_thread_none':interface is None or interface.thread is None,
        'library_owner_released':not self._owned})
    save()

adapter.PyOcdMemAp.close=observed_close
original_controller=app.Controller.__init__
holder={}

def controller_init(self,*args,**kwargs):
    original_controller(self,*args,**kwargs)
    holder['controller']=self
    holder['qa']=GuiQa(self)

class GuiQa:
    def __init__(self,controller):
        self.c=controller;self.w=controller.window;self.m=controller.swd
        self.state='inventory';self.started=time.monotonic();self.entered=self.started
        self.reconnects=0;self.poll_start=0;self.busy_patch=None;self.before_packets=0
        self.timer=QTimer(self.w);self.timer.setInterval(100);self.timer.timeout.connect(self.tick)
        self.timer.start()

    def stage(self,name):
        global phase
        self.state=phase=name;self.entered=time.monotonic()

    def snapshot(self,name):
        application=QApplication.instance()
        assert application.platformName()=='windows', application.platformName()
        assert self.w.isVisible() and self.w.windowHandle().isExposed()
        filename=name+'.png'
        assert self.w.grab().save(str(task/filename))
        step={'name':name,'utc':datetime.now(timezone.utc).isoformat(),'platform':application.platformName(),
            'native_window_exposed':self.w.windowHandle().isExposed(),'png':filename,
            'status':self.m.status,'text':self.w.maintenance_page.swd_target_status.text(),
            'probe_identity':self.c.probes.selection.identity,
            'attach_enabled':self.w.maintenance_page.btn_swd_attach.isEnabled(),
            'detach_enabled':self.w.maintenance_page.btn_swd_detach.isEnabled(),'packet_count':packet_count}
        if self.m.snapshot:step['snapshot']=asdict(self.m.snapshot)
        result['steps'].append(step);save()

    def click(self,button):
        assert button.isEnabled() and button.isVisible(), button.text()
        QTest.mouseClick(button,Qt.LeftButton)

    def tick(self):
        try:self.advance()
        except Exception:
            result['errors'].append({'stage':self.state,'traceback':traceback.format_exc()})
            self.timer.stop()
            if self.busy_patch:self.busy_patch.stop();self.busy_patch=None
            os.environ.pop('SILVERSTAR_SWD_PYOCD_PATH',None)
            self.m.detach();self.c.probes.request_close();self.w.close();save()

    def healthy(self):
        if self.m.worker is None and self.m.snapshot is None:
            raise AssertionError(('Unexpected attachment refusal',self.m.status,self.m.detail))
        if self.m.snapshot is None:return False
        s=self.m.snapshot
        assert s.probe_identity==IDENTITY and s.cpuid==0x410FC241 and s.device_id==0x413 and s.revision_id==0x1007
        assert s.core_state in ('running','sleeping'), ('Target state changed; stop',s.core_state)
        assert not s.dhcsr & ((1<<17)|3), 'Halt/debug-enable state changed; stop'
        assert s.symbols=='unmatched'
        assert '0x413' in self.w.maintenance_page.swd_target_status.text()
        assert self.m.factory is SwdSession
        assert self.w.debug_status.text()==self.serial_baseline[0] and self.w.status.text()==self.serial_baseline[1]
        assert not self.w.probe_combo.isEnabled() and not self.w.btn_probe_refresh.isEnabled()
        assert not self.m.attach() and not self.c.probes.refresh()
        result['dependency_discovery']={'swd_path_env':os.environ.get('SILVERSTAR_SWD_PYOCD_PATH'),
            'pyocd_file':sys.modules['pyocd'].__file__,'default_deps':str(adapter._DEFAULT_DEPS)}
        return True

    def advance(self):
        assert time.monotonic()-self.started<70, 'GUI QA overall deadline'
        assert time.monotonic()-self.entered<24, ('GUI stage deadline',self.state)
        page=self.w.maintenance_page
        if self.state=='inventory':
            if self.c.probes.worker is not None:return
            assert self.c.probes.selection.identity==IDENTITY and self.m.worker is None and packet_count==0
            self.w.resize(1440,920)
            index=self.w.pages.indexOf(self.w.maintenance_scroll)
            QTest.mouseClick(self.w.pages.tabBar(),Qt.LeftButton,pos=self.w.pages.tabBar().tabRect(index).center())
            self.w.probe_combo.setCurrentIndex(0)
            QTest.keyClick(self.w.probe_combo,Qt.Key_End)
            assert self.w.probe_combo.currentData()==IDENTITY
            self.serial_baseline=(self.w.debug_status.text(),self.w.status.text())
            self.snapshot('01_selected_no_target')
            self.stage('connect1');self.click(page.btn_swd_attach)
        elif self.state in ('connect1','connect2','connect3'):
            if not self.healthy():return
            self.snapshot(self.state+'_running')
            self.poll_start=self.m.snapshot.received_ns
            self.stage('poll'+self.state[-1])
        elif self.state in ('poll1','poll2','poll3'):
            if self.m.snapshot is None or self.m.snapshot.received_ns==self.poll_start:return
            assert self.healthy()
            number=self.state[-1]
            self.snapshot('poll'+number+'_fresh')
            if number=='3':
                self.stage('close_attached');self.timer.stop()
                result['close_requested_while_attached']=self.m.worker is not None
                self.w.close();save()
            else:
                self.stage('detach'+number);self.click(page.btn_swd_detach)
        elif self.state in ('detach1','detach2'):
            if self.m.worker is not None:return
            assert self.m.status=='swd.detached' and self.m.snapshot is None and not adapter._LibraryOwner.locked()
            assert not _ProbeOwners and not any('CMSIS-DAPv2 receive' in t.name for t in threading.enumerate())
            self.snapshot(self.state+'_released')
            if self.state=='detach1':
                self.stage('connect2');self.click(page.btn_swd_attach)
            else:
                self.before_packets=packet_count
                self.busy_patch=patch.object(api_seen.bulk.usb.util,'claim_interface',
                    side_effect=api_seen.bulk.usb.core.USBError('Injected BUSY; no competing tool launched'))
                self.busy_patch.start();self.stage('injected_busy');self.click(page.btn_swd_attach)
        elif self.state=='injected_busy':
            if self.m.worker is not None:return
            assert self.m.status=='swd.busy' and self.m.snapshot is None and packet_count==self.before_packets
            assert not adapter._LibraryOwner.locked() and not _ProbeOwners
            self.snapshot('injected_busy_zero_dap')
            self.busy_patch.stop();self.busy_patch=None
            os.environ['SILVERSTAR_SWD_PYOCD_PATH']=str(task/'absent_runtime')
            self.stage('injected_missing_dependency');self.click(page.btn_swd_attach)
        elif self.state=='injected_missing_dependency':
            if self.m.worker is not None:return
            assert self.m.status=='swd.missing_dependency' and self.m.snapshot is None and packet_count==self.before_packets
            assert 'OpenOCD' not in page.swd_target_status.text()
            self.snapshot('injected_dependency_failure')
            os.environ.pop('SILVERSTAR_SWD_PYOCD_PATH',None)
            self.stage('connect3');self.click(page.btn_swd_attach)

app.Controller.__init__=controller_init
exit_code=2
try:
    with patch('transport.serial_backend.serial.Serial',side_effect=AssertionError('UART forbidden in SWD GUI QA')) as serial:
        code=app.main()
        result['app_exit_code']=code
        result['serial_open_calls']=serial.call_count
        c=holder.get('controller')
        result['final']={'window_hidden':not c.window.isVisible(),'swd_worker_none':c.swd.worker is None,
            'probe_worker_none':c.probes.worker is None,'library_owner_free':not adapter._LibraryOwner.locked(),
            'process_owners_empty':not _ProbeOwners,
            'rx_threads': [t.name for t in threading.enumerate() if 'CMSIS-DAPv2 receive' in t.name],
            'packet_count':packet_count,'phase':phase}
        assert not result['errors'] and phase=='close_attached' and code==0 and serial.call_count==0
        assert all(v for k,v in result['final'].items() if k in ('window_hidden','swd_worker_none','probe_worker_none','library_owner_free','process_owners_empty'))
        assert not result['final']['rx_threads']
        exit_code=0
except Exception:
    result['errors'].append({'stage':'outer','traceback':traceback.format_exc()})
finally:
    packet_log.close()
    adapter._BulkInterface=original_bulk
    adapter.PyOcdMemAp.close=original_close
    app.Controller.__init__=original_controller
    save()
    print(json.dumps({'exit':exit_code,'steps':len(result['steps']),'packets':packet_count,
        'errors':result['errors'],'final':result.get('final')},ensure_ascii=False),flush=True)
raise SystemExit(exit_code)
