"""Small retained audit evidence; do not copy the official archive into Git."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path(__file__).resolve().parents[2]
task=Path(__file__).resolve().parent
destination=root/'apps/GSHC/docs/evidence/swd_offline_audit_20261013'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=root,text=True,encoding='utf-8').strip()
test=json.loads((task/'backend_tests01.json').read_text(encoding='utf-8'))
assert test['exit_code']==0
for name,digest in test['inputs'].items():assert sha(root/name)==digest,name
assert all(row['equal'] for row in json.loads((task/'release_comparison.json').read_text())['comparisons'])
assert json.loads((task/'configuration03.json').read_text())['exit_code']==0
assert 'DEPRECATED' not in json.loads((task/'configuration03.json').read_text())['stderr']
assert (task/'COPYING.OpenOCD').is_file() and (task/'COPYING.libusb').is_file()
source_names=['apps/GSHC/transport/_swd_openocd.py','apps/GSHC/tests/test_swd_session.py',
              'docs/public/GSHC/SWD_OFFLINE_AUDIT_20261013.md','docs/public/GSHC/SWD_READ_ONLY_20261013.md']
metadata={'base_commit':git('rev-parse','HEAD'),'branch':git('branch','--show-current'),
    'frozen_tag_object':git('rev-parse','v0.1.2^{tag}'),'frozen_tag_commit':git('rev-parse','v0.1.2^{}'),
    'source_sha256':{name:sha(root/name) for name in source_names},'hardware_actions':False,
    'admission_changed':False,'installation_or_replacement':False}
assert metadata['frozen_tag_object']=='942f20ef64df3cb1aa65be7349361c409418aa0f'
assert metadata['frozen_tag_commit']=='c31c13cc0686a56a3184d4f207fd3816c5d39696'
(task/'final_state.json').write_text(json.dumps(metadata,indent=2),encoding='utf-8')
rows=[]
for path in sorted(task.rglob('*')):
    if not path.is_file() or path.name=='inventory.json':continue
    purpose=('Official reference archive; retained provenance evidence; not a cleanup target' if path.suffix=='.7z'
             else 'Generated synthetic fixture/cache; retained, no cleanup' if any(part.startswith('pytest_') for part in path.parts)
             else 'Retained offline source/provenance/configuration/test evidence')
    rows.append({'path':path.relative_to(root).as_posix(),'bytes':path.stat().st_size,'sha256':sha(path),
                 'owner':'root integrator','purpose':purpose})
(task/'inventory.json').write_text(json.dumps({'cleanup_authorized':False,'files':rows},indent=2),encoding='utf-8')
archive=destination/'evidence.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as output:
    for path in sorted(task.rglob('*')):
        if path.is_file() and path.suffix!='.7z' and not any(part.startswith('pytest_') for part in path.parts):
            output.write(path,'task/'+path.relative_to(task).as_posix())
    for name in source_names:output.write(root/name,'source/'+name)
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    entries=[{'path':item.filename,'bytes':item.file_size,
              'sha256':hashlib.sha256(check.read(item.filename)).hexdigest()} for item in check.infolist()]
manifest={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),
          'files':entries,'retained_task_bytes':sum(row['bytes'] for row in rows)}
(destination/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in manifest.items() if k!='files'},indent=2))
