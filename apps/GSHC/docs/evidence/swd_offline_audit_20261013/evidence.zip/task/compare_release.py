"""Stream selected archive entries to hashes. Do not extract/install executables."""
from pathlib import Path
import hashlib,json,subprocess
out=Path(__file__).resolve().parent
archive=out/'official_release.7z'
tar='C:/Windows/system32/tar.exe'
listing=subprocess.run([tar,'-tf',str(archive)],capture_output=True,text=True,timeout=30)
assert listing.returncode==0,listing.stderr
(out/'archive_entries.txt').write_text(listing.stdout,encoding='utf-8')
base=Path('D:/OpenOCD-20250710-0.12.0')
names=['bin/openocd.exe','share/openocd/scripts/target/stm32f4x.cfg',
       'share/openocd/scripts/interface/cmsis-dap.cfg']
rows=[]
for name in names:
    member='OpenOCD-20250710-0.12.0/'+name
    assert member in listing.stdout.splitlines()
    run=subprocess.run([tar,'-xOf',str(archive),member],capture_output=True,timeout=30)
    assert run.returncode==0,run.stderr
    data=(base/name).read_bytes()
    rows.append({'member':member,'bytes':len(run.stdout),'archive_sha256':hashlib.sha256(run.stdout).hexdigest(),
                 'installed_sha256':hashlib.sha256(data).hexdigest(),'equal':data==run.stdout})
metadata=[name for name in listing.stdout.splitlines() if any(word in name.lower() for word in ('version','revision','manifest','readme','license','copying','.pdb'))]
result={'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'comparisons':rows,'metadata_candidates':metadata}
(out/'release_comparison.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
