# 0.1.3 SWD offline blocker audit

Owner: root integrator. Base commit: 2aa9f27874fdcd56b4f0300ee85c9419a9f0c9fd.
Purpose: identify installed OpenOCD provenance, trace initialization/exit and
WinUSB ownership, and validate configuration without adapter initialization.
No probe opens, target communication, driver change, package installation,
program replacement, firmware build, reset, halt, flash or cleanup authorized.
Retain downloaded public source fragments, command logs and hashes here.
Any reference release archive is for byte comparison only, not execution/install.
