"""Add the upstream full license; retain the initial evidence digest and entries."""
from pathlib import Path
import hashlib,json,zipfile
root=Path(__file__).resolve().parents[2]
task=Path(__file__).resolve().parent
destination=root/'apps/GSHC/docs/evidence/swd_offline_audit_20261013'
archive=destination/'evidence.zip'
manifest=json.loads((destination/'manifest.json').read_text())
initial=manifest['sha256']
with zipfile.ZipFile(archive) as check:
    for row in manifest['files']:
        assert hashlib.sha256(check.read(row['path'])).hexdigest()==row['sha256']
with zipfile.ZipFile(archive,'a',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as output:
    output.write(task/'GPL-2.0.OpenOCD','task/LICENSES/preferred/GPL-2.0')
    output.write(task/'GPL-2.0.OpenOCD.json','task/GPL-2.0.OpenOCD.json')
    output.write(Path(__file__),'task/append_license.py')
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    for row in manifest['files']:
        assert hashlib.sha256(check.read(row['path'])).hexdigest()==row['sha256']
    manifest['files']=[{'path':item.filename,'bytes':item.file_size,
        'sha256':hashlib.sha256(check.read(item.filename)).hexdigest()} for item in check.infolist()]
manifest['initial_archive_sha256_before_full_license']=initial
manifest['bytes']=archive.stat().st_size
manifest['sha256']=hashlib.sha256(archive.read_bytes()).hexdigest()
inventory=json.loads((task/'inventory.json').read_text())
known={row['path'] for row in inventory['files']}
for path in (task/'GPL-2.0.OpenOCD',task/'GPL-2.0.OpenOCD.json',Path(__file__)):
    name=path.relative_to(root).as_posix()
    assert name not in known
    inventory['files'].append({'path':name,'bytes':path.stat().st_size,
        'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'owner':'root integrator',
        'purpose':'Retained full upstream license or its archival reproduction script'})
(task/'inventory.json').write_text(json.dumps(inventory,indent=2),encoding='utf-8')
manifest['retained_task_bytes']=sum(row['bytes'] for row in inventory['files'])
(destination/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print({k:v for k,v in manifest.items() if k!='files'})
