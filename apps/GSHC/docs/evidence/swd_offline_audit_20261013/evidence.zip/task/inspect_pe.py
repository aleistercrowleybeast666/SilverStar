"""Read-only PE/COFF metadata; no program loading or device access."""
from pathlib import Path
import hashlib,json,re,struct
p=Path('D:/OpenOCD-20250710-0.12.0/bin/openocd.exe');data=p.read_bytes()
pe=struct.unpack_from('<I',data,0x3c)[0]
machine,sections,timestamp,symbol_offset,symbol_count,opt_size,flags=struct.unpack_from('<HHIIIHH',data,pe+4)
rows=[]
for i in range(sections):
    offset=pe+24+opt_size+i*40
    name=data[offset:offset+8].split(b'\0')[0].decode('ascii','replace')
    size,address,raw_size,raw_offset=struct.unpack_from('<IIII',data,offset+8)
    rows.append({'name':name,'virtual_address':address,'bytes':raw_size,'offset':raw_offset})
strings=[]
for match in re.finditer(rb'[\x20-\x7e]{8,}',data):
    s=match.group().decode('ascii')
    if (any(word in s.lower() for word in ('sysprogs','libusb1','git version','2025-07','commit','cmsis_dap_init','cmsis_dap_reset','winusb_open'))
        or re.fullmatch('[0-9a-f]{40}',s)):
        strings.append({'offset':match.start(),'text':s[:400]})
result={'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'machine':hex(machine),
 'pe_timestamp':timestamp,'coff_symbol_count':symbol_count,'coff_symbol_offset':symbol_offset,'sections':rows,'selected_strings':strings}
out=Path(__file__).resolve().parent/'installed_pe.json'
out.write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
