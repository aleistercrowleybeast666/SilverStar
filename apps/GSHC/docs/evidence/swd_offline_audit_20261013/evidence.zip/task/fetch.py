"""Bounded public-source retrieval, never execute downloaded contents."""
from pathlib import Path
import hashlib,json,sys,urllib.request
out=Path(__file__).resolve().parent
name,url=sys.argv[1:3]
assert '/' not in name and '\\' not in name and not (out/name).exists()
request=urllib.request.Request(url,headers={'User-Agent':'SilverStar-offline-audit'})
with urllib.request.urlopen(request,timeout=15) as response:
    data=response.read(16*1024*1024+1)
    assert len(data)<=16*1024*1024
    metadata={'url':url,'final_url':response.url,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
(out/name).write_bytes(data)
(out/(name+'.json')).write_text(json.dumps(metadata,indent=2),encoding='utf-8')
print(json.dumps(metadata))
