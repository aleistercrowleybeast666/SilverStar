"""Parse configuration only: noinit first, omit init, shutdown in config mode."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'apps/GSHC'))
from transport.probe_inventory import HostProbe
from transport._swd_openocd import _Configuration
out=Path(__file__).resolve().parent
name=sys.argv[1] if len(sys.argv)>1 else 'configuration01'
assert name.replace('_','').isalnum() and not (out/(name+'.json')).exists()
probe=HostProbe(r'USB\VID_FAED&PID_4870\OFFLINE_NO_DEVICE','Offline audit','CMSIS-DAP',
               'FAED:4870','OFFLINE_NO_DEVICE','USB serial',('WINUSB',),'OK')
configuration=_Configuration(probe)
assert configuration[-1]=='init'
commands=['noinit']+configuration[:-1]+['shutdown']
assert 'init' not in commands
executable=Path('D:/OpenOCD-20250710-0.12.0/bin/openocd.exe')
args=[str(executable)]
for command in commands:args+=['-c',command]
run=subprocess.run(args,cwd=out,capture_output=True,timeout=5)
report={'command':args,'cwd':str(out),'executable_sha256':hashlib.sha256(executable.read_bytes()).hexdigest(),
        'exit_code':run.returncode,'stdout':run.stdout.decode('utf-8','replace'),
        'stderr':run.stderr.decode('utf-8','replace'),'adapter_init_requested':False,'synthetic_serial':True}
(out/(name+'.json')).write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
sys.exit(run.returncode)
