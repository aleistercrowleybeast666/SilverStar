"""Explicit small follow-up archive; no cleanup and no device access."""
from pathlib import Path
import datetime, hashlib, json, platform, subprocess, sys, zipfile
import PySide6, pytest, serial
root=Path(__file__).resolve().parents[2]
task=Path(__file__).resolve().parent
for name in ('ui_tests02','native_gui02'):
    record=json.loads((task/(name+'.json')).read_text(encoding='utf-8'))
    assert record['exit_code']==0
    for relative,sha in record['inputs'].items():
        assert hashlib.sha256((root/relative).read_bytes()).hexdigest()==sha,relative
raw=task/'host_diagnosis01.json'
public=json.loads(raw.read_text(encoding='utf-8'))
public['raw_observation_sha256']=hashlib.sha256(raw.read_bytes()).hexdigest()
public['redaction']='Unrelated Bluetooth hardware addresses omitted; raw record retained locally'
for port in public['serial_ports']:
    if str(port.get('hwid','')).startswith('BTHENUM'):
        port['hwid']='BTHENUM (hardware address omitted)'
(task/'host_diagnosis_public01.json').write_text(json.dumps(public,ensure_ascii=False,indent=2),encoding='utf-8')
versions=dict(python=sys.version,qt=PySide6.__version__,pytest=pytest.__version__,pyserial=serial.VERSION,platform=platform.platform())
(task/'versions.json').write_text(json.dumps(versions,indent=2),encoding='utf-8')
out=root/'apps/GSHC/docs/evidence/host_probe_alignment_20261013'
destination=out/'evidence.zip'; assert not destination.exists()
selected=[task/name for name in ('README.md','verify.py','gui_qa.py','diagnose_host.py','package_evidence.py',
    'host_diagnosis_public01.json','library_result.json','versions.json')]
for pattern in ('ui_tests*.json','ui_tests*.log','native_gui*.json','native_gui*.log'):
    selected.extend(task.glob(pattern))
for name in ('native01','native02'):
    selected.extend((task/name).glob('*.png'))
    selected.append(task/name/'qa.json')
manifest=[]
with zipfile.ZipFile(destination,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for path in sorted(set(selected)):
        resolved=path.resolve(); assert resolved.is_relative_to(task)
        assert 'library-helper' not in resolved.parts
        data=resolved.read_bytes(); relative=resolved.relative_to(task).as_posix()
        archive.writestr(relative,data)
        manifest.append(dict(path=relative,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
    archive.writestr('manifest.json',json.dumps(manifest,indent=2))
inventory=[]
for path in sorted(task.rglob('*')):
    if path.is_file() and path.name!='inventory.json':
        data=path.read_bytes()
        inventory.append(dict(path=path.relative_to(task).as_posix(),bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),
            owner='root integrator',purpose='private Library input' if 'library-helper' in path.parts else 'GSHC alignment and diagnosis evidence',
            retained=True,cleanup_authorized=False))
(task/'inventory.json').write_text(json.dumps(inventory,indent=2),encoding='utf-8')
summary=dict(base_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),entries=len(manifest)+1,
    archive_bytes=destination.stat().st_size,sha256=hashlib.sha256(destination.read_bytes()).hexdigest(),
    task_files=len(inventory),task_bytes=sum(x['bytes'] for x in inventory))
(out/'archive.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
