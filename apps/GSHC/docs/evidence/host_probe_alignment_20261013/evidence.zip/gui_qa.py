"""Native source GUI diagnosis/layout QA; serial construction is blocked."""
from dataclasses import asdict
from pathlib import Path
from unittest.mock import patch
import datetime, json, os, sys, time
from PySide6.QtCore import QPoint, QRect, QSettings
from PySide6.QtWidgets import QApplication
from PySide6.QtTest import QTest
from PySide6.QtGui import QFont, QFontDatabase
from app import Controller
from services.i18n import I18n
from ui.main_window import MainWindow
from transport.probe_inventory import ProbeInventory_Read

root=Path(__file__).resolve().parent
out=root/sys.argv[1]; out.mkdir(exist_ok=False)
application=QApplication([])
if os.environ.get('QT_QPA_PLATFORM')=='offscreen':
    QFontDatabase.addApplicationFont('C:/Windows/Fonts/msyh.ttc')
    application.setFont(QFont('Microsoft YaHei',10))
window=MainWindow(I18n(QSettings(str(out/'settings.ini'),QSettings.IniFormat)))
inventories=[]; geometry=[]
def enumerate_host(cancel):
    result=ProbeInventory_Read(cancel)
    inventories.append(dict(result=result.result.value,detail=result.detail,probes=[asdict(p) for p in result.probes]))
    return result
with patch('app.USER_DATA_ROOT',out/'user-data'), \
     patch('transport.serial_backend.serial.Serial',side_effect=AssertionError('No serial open authorized by this QA')) as serial_open:
    controller=Controller(window,probe_enumerator=enumerate_host)
    try:
        window.resize(1530,800); window.show()
        deadline=time.monotonic()+25
        while (controller.probes.worker is not None or controller.probes.status in ('probe.not_scanned','probe.busy')) and time.monotonic()<deadline:
            QTest.qWait(20)
        assert controller.probes.worker is None
        controller.probes.timer.stop()
        initial=dict(ground_port=window.port_combo.currentText(),maintenance_port=window.debug_port_combo.currentText(),
            selected_probe=controller.probes.selection.identity,maintenance_owner=controller.file_transfer.owner is not None,
            maintenance_open=window._debug_connected,maintenance_text=window.debug_status.text())
        for language in ('zh_CN','en_US'):
            window.i18n.set_language(language); window.retranslate_ui()
            for width in (1024,1280,1530,1920):
                window.resize(width,800); QTest.qWait(80)
                rect=lambda w: QRect(w.mapTo(window,QPoint()),w.size())
                bar=rect(window.header_bar)
                groups=[rect(w) for w in (window.header_connection_group,window.debug_connection_group,window.probe_group)]
                controls=[rect(w) for w in (window.port_combo,window.debug_port_combo,window.probe_combo)]
                assert all(bar.contains(g) for g in groups)
                for widget,group in zip((window.header_connection_group,window.debug_connection_group,window.probe_group),groups):
                    assert group.width()>=widget.minimumSizeHint().width(),(language,width,group,widget.minimumSizeHint())
                for button in (window.btn_refresh,window.btn_connect,window.btn_disconnect,window.btn_debug_connect,window.btn_debug_disconnect,window.btn_probe_refresh):
                    assert button.width()>=button.minimumSizeHint().width()
                for i,one in enumerate(groups):
                    for j,two in enumerate(groups[i+1:],i+1):
                        assert not one.intersects(two)
                        if one.top()==two.top(): assert abs(controls[i].center().y()-controls[j].center().y())<=1
                assert rect(window.probe_status).left()>rect(window.btn_probe_refresh).right()
                assert abs(rect(window.probe_status).center().y()-rect(window.probe_combo).center().y())<=1
                if width<=1280: assert window.width()==width
                if language=='zh_CN':
                    assert window.btn_probe_refresh.text()=='重新检测'
                    assert window.debug_status.text()=='未连接'
                    if width==1530: assert window._connection_layout_mode==0
                assert window.header_bar.grab().save(str(out/f'{language}_{width}_header.png'))
                geometry.append(dict(language=language,requested_width=width,actual_width=window.width(),mode=window._connection_layout_mode,
                    groups=[g.getRect() for g in groups],control_centers=[c.center().y() for c in controls]))
        assert controller.file_transfer.owner is None and not window._debug_connected
        assert serial_open.call_count==0
    finally:
        controller.shutdown(); window.close(); application.processEvents()
(out/'qa.json').write_text(json.dumps(dict(observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    qpa=os.environ.get('QT_QPA_PLATFORM'),scale=os.environ.get('QT_SCALE_FACTOR','1'),initial=initial,
    inventories=inventories,geometry=geometry,serial_open_calls=serial_open.call_count),ensure_ascii=False,indent=2),encoding='utf-8')
print('Native source GUI checked; initial state:',json.dumps(initial,ensure_ascii=False))
