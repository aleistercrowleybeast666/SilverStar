"""Read host metadata only. Never instantiate or open a serial/probe transport."""
from dataclasses import asdict
from pathlib import Path
from threading import Event
import datetime, hashlib, inspect, json, time
from serial.tools import list_ports
import serial.serialwin32
from transport.probe_inventory import ProbeInventory_Read

start=time.monotonic()
inventory=ProbeInventory_Read(Event())
ports=[]
for port in list_ports.comports():
    ports.append({key:getattr(port,key,None) for key in ('device','name','description','hwid','vid','pid','serial_number','location','manufacturer','product','interface')})
source=inspect.getsource(serial.serialwin32.Serial)
record=dict(observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-start,
    inventory=dict(result=inventory.result.value,detail=inventory.detail,probes=[asdict(p) for p in inventory.probes]),
    serial_ports=ports,serial_implementation_sha256=hashlib.sha256(source.encode('utf-8')).hexdigest(),
    serial_open_attempted=False,reason='Windows serial open configures DTR/RTS; reset-free wiring/driver behavior is not established',
    port_occupancy='unknown; no attempt to open or take over a port',firmware_response='not tested; no commands sent')
out=Path(__file__).with_name('host_diagnosis01.json')
assert not out.exists()
out.write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(record,ensure_ascii=False,indent=2))
