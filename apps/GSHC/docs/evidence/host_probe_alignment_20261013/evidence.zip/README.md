# Probe header alignment and safe connection diagnosis

Owner: root integrator. Base: 63445dbf7671541b9ed8bde5d149fc413242414b.
Purpose: 0.1.3 GSHC header alignment/localization and current host device diagnosis.
No SWD session, target control, firmware build, DTR/RTS transition or port probing.
Serial opening is conditional on verified device identity and reset-free behavior;
current wiring/control-line behavior is unproven, so do not open serial ports.
Private Library transfer inputs are excluded from delivered evidence.
All new generated output stays here; no cleanup authorized.
