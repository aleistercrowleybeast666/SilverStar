"""Retain scoped evidence and hashes, never cleanup or include runtime binaries."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

task=Path(__file__).absolute().parent
root=task.parents[1]
destination=root/'apps/GSHC/docs/evidence/swd_pyocd_20261014'
destination.mkdir(exist_ok=True)

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value): path.write_text(json.dumps(value,indent=2,ensure_ascii=False),encoding='utf-8')
def git(*args):
    run=subprocess.run(['git',*args],cwd=root,capture_output=True,text=True,check=True)
    return run.stdout.strip()

sys.path.insert(0,str(task/'deps'))
import pytest, PySide6, pyocd, usb, libusb_package
write(task/'tool_versions.json',{'utc':datetime.now(timezone.utc).isoformat(),
    'python':sys.version,'executable':sys.executable,'pytest':pytest.__version__,
    'PySide6':PySide6.__version__,'pyocd':pyocd.__version__,'pyusb':usb.__version__,
    'libusb-package':libusb_package.__version__,
    'libusb_dll':str(libusb_package.get_library_path()),'libusb_dll_sha256':sha(libusb_package.get_library_path()),
    'base_commit':'8ff26e9fb3d5b616efca91f3d46cca7f26e2d501','current_head':git('rev-parse','HEAD'),
    'branch':git('branch','--show-current'),'v012_tag':git('rev-parse','v0.1.2'),
    'v012_peeled':git('rev-parse','v0.1.2^{}')})

base=['apps/GSHC/tests/test_swd_pyocd.py','apps/GSHC/tests/test_swd_session.py',
      'apps/GSHC/tests/test_swd_guard.py','apps/GSHC/tests/test_swd_ui.py']
cases=[(1,base[:1],['-p','no:cacheprovider'],0,'17 passed; 1 cache config warning'),
       (2,base,['-o','cache_dir=.work/dev013_swd_pyocd01/cache'],1,'96 passed / 2 failed: child import path and old default assumption; USB descriptor enumeration only in stale test'),
       (3,base,['-o','cache_dir=.work/dev013_swd_pyocd01/cache'],2,'Collection IndentationError, no tests executed'),
       (4,base,['-o','cache_dir=.work/dev013_swd_pyocd01/cache'],0,'99 passed'),
       (5,base[:1],['-o','cache_dir=.work/dev013_swd_pyocd01/cache'],0,'18 passed incl actual DAP encoder'),
       (6,base+['apps/GSHC/tests/test_probe_inventory.py','apps/GSHC/tests/test_probe_ui.py'],
        ['-o','cache_dir=.work/dev013_swd_pyocd01/cache'],0,'143 passed / 49.28s')]
commands=[]
for number,files,extra,code,result in cases:
    label=f'pytest{number:02d}'
    commands.append({'command':[str(root/'.venv/Scripts/python.exe'),'-m','pytest',*files,'-q',*extra,
        '--basetemp='+'.work/dev013_swd_pyocd01/'+label], 'cwd':str(root),
        'environment':{'PYTHONIOENCODING':'utf-8','PYTHONDONTWRITEBYTECODE':'1',
            'PYTHONPATH':'apps/GSHC' if number<3 else 'apps/GSHC;apps/GSHC/tests',
            'QT_QPA_PLATFORM':'offscreen' if number in (2,3,4,6) else 'not set'},
        'exit_code':code,'result':result,'log':label+'.log','skips':'none reported'})
write(task/'test_commands.json',commands)

sources=['apps/GSHC/transport/_swd_pyocd.py','apps/GSHC/transport/swd_session.py',
 'apps/GSHC/swd_cli.py','apps/GSHC/ui/swd_connection.py','apps/GSHC/requirements-swd.txt',
 *base,'apps/GSHC/tests/test_probe_inventory.py','apps/GSHC/tests/test_probe_ui.py',
 'docs/public/GSHC/SWD_PYOCD_BENCH_20261014.md']
write(task/'dirty_source_snapshot.json',{'base_commit':'8ff26e9fb3d5b616efca91f3d46cca7f26e2d501',
    'files':{name:sha(root/name) for name in sources},'git_status':git('status','--short'),
    'note':'Snapshot represents tested current code. bench02 has separate pre-final host cleanup hashes; cli03 hashes match current backend.'})

inventory=[]
for path in task.rglob('*'):
    if not path.is_file() or path.name=='inventory.json': continue
    relative=path.relative_to(task).as_posix()
    category=('retained isolated runtime dependency' if relative.startswith('deps/') else
              'generated test/cache payload; retained, no cleanup authorization' if relative.startswith(('pytest','cache/','install_temp/')) else
              'retained source/evidence')
    inventory.append({'path':str(path),'relative':relative,'owner':'root / 0.1.3 SWD pyOCD task',
        'purpose':category,'bytes':path.stat().st_size,'sha256':sha(path),'cleanup_authorized':False})
write(task/'inventory.json',{'root':str(task),'utc':datetime.now(timezone.utc).isoformat(),'files':inventory,
    'total_bytes':sum(x['bytes'] for x in inventory),'no_cleanup':True})

selected={path.relative_to(task).as_posix():path for path in task.rglob('*') if path.is_file()
    and path.relative_to(task).parts[0] not in ('deps','cache','install_temp')
    and not path.relative_to(task).parts[0].startswith('pytest0')}
# Include the complete test logs, but exclude generated pytest payload directories.
selected.update({p.name:p for p in task.glob('pytest*.log')})
payload={'task/'+name:path for name,path in selected.items()}
payload.update({'source/'+name:root/name for name in sources})
for relative in ('pyocd-0.45.1.dist-info/licenses/LICENSE','pyusb-1.3.1.dist-info/LICENSE',
                 'libusb_package-1.0.30.0.dist-info/licenses/LICENSE'):
    payload['licenses/'+relative]=task/'deps'/relative
for relative in ('core/session.py','probe/cmsis_dap_probe.py',
    'probe/pydapaccess/dap_access_cmsis_dap.py','probe/pydapaccess/interface/pyusb_v2_backend.py',
    'coresight/dap.py','coresight/ap.py'):
    payload['audited_pyocd_v0.45.1/'+relative]=task/'deps/pyocd'/relative

archive=destination/'evidence_final.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as output:
    for name,path in sorted(payload.items()):output.write(path,name)
write(destination/'manifest_final.json',{'archive':'evidence_final.zip','bytes':archive.stat().st_size,'sha256':sha(archive),
    'entries':{name:{'bytes':path.stat().st_size,'sha256':sha(path)} for name,path in sorted(payload.items())}})
print('Evidence',archive.stat().st_size,sha(archive))
print('Task retained bytes',sum(x['bytes'] for x in inventory))
