# 0.1.3 isolated pyOCD read-only backend and controlled bench

Owner: root integrator. Base: 8ff26e9fb3d5b616efca91f3d46cca7f26e2d501.
User approved official PyPI pyOCD 0.45.1 and dependencies in this task's deps,
using existing Python, with no system Python/PATH/driver change or unrelated SDK.
User bench conditions: flight controller only, external 5V, SWDIO/SWCLK/GND only,
NRST and DAP power absent, physical actuators disconnected. Pose irrelevant.
Authorized bounded identification/state/RAM reads after safe low-level review.
No halt/reset/resume/flash/breakpoint/target writes/calibration/START or takeover.
Retain minimal dependency source/version evidence, test/bench commands and hashes.
No cleanup authorized. Existing logs, archives, fixtures and releases are preserved.
