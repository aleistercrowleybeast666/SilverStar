"""Approved isolated wheel-only install from official PyPI; no global mutation."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,datetime
task=Path(__file__).resolve().parent
root=task.parents[1]
deps=task/'deps'
assert task.resolve().is_relative_to(root.resolve()) and deps.parent==task
if deps.exists() and any(deps.iterdir()):raise SystemExit('Existing dependency payload: inspect before any install')
task_temp=task/'install_temp';task_temp.mkdir(exist_ok=True)
env=dict(os.environ,TMP=str(task_temp),TEMP=str(task_temp),PYTHONDONTWRITEBYTECODE='1',PIP_NO_CACHE_DIR='1',PIP_DISABLE_PIP_VERSION_CHECK='1')
common=[sys.executable,'-m','pip','install','--index-url','https://pypi.org/simple','--only-binary=:all:',
        '--no-cache-dir','--target',str(deps),'pyocd==0.45.1']
for name,extra in [('resolve',['--dry-run','--report',str(task/'pip_resolve.json')]),
                   ('install',['--report',str(task/'pip_install.json')])]:
    args=common+extra
    with (task/(name+'.log')).open('xb') as log:
        run=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
    (task/(name+'_command.json')).write_text(json.dumps({'command':args,'exit_code':run.returncode,
        'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2),encoding='utf-8')
    print(name,'exit',run.returncode,flush=True)
    if run.returncode:raise SystemExit(run.returncode)
report=json.loads((task/'pip_install.json').read_text())
rows=[]
for item in report['install']:
    url=item['download_info']['url']
    assert url.startswith('https://files.pythonhosted.org/'),url
    rows.append({'name':item['metadata']['name'],'version':item['metadata']['version'],'source':url,
                 'archive':item['download_info']['archive_info']})
assert any(x['name'].lower()=='pyocd' and x['version']=='0.45.1' for x in rows)
(task/'dependencies.json').write_text(json.dumps({'python':sys.version,'location':str(deps),
  'bytes':sum(p.stat().st_size for p in deps.rglob('*') if p.is_file()),'packages':rows},indent=2),encoding='utf-8')
print('installed',len(rows),'packages',flush=True)
