# GSHC probe-state semantics, 0.1.3

Owner: root integrator. Base: bfe933eebd8df3cd439ea6cd256c1c7e60e57a75.
Scope: clarify discovered/selected/absent probe and unimplemented SWD target
connection/readout; preserve the accepted layout and serial behavior.
All verification uses synthetic inventories. No device enumeration/open,
serial command, SWD session, firmware build, driver change, push or tag.
Generated evidence remains here; no cleanup authorized.
