"""Preserve small host-only evidence; no deletion or firmware packaging."""
from pathlib import Path
import datetime, hashlib, importlib.metadata, json, subprocess, sys, zipfile

root=Path(__file__).resolve().parents[2]
task=Path(__file__).resolve().parent
destination=root/'apps/GSHC/docs/evidence/swd_readonly_20261013'
destination.mkdir(parents=True,exist_ok=True)
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=root,text=True,encoding='utf-8').strip()
test=json.loads((task/'regression04.json').read_text(encoding='utf-8'))
assert test['exit_code']==0
for relative,digest in test['inputs'].items():
    assert sha(root/relative)==digest, 'Source changed since final regression: '+relative
sources=['apps/GSHC/'+name for name in (
    'app.py','swd_cli.py','transport/swd_session.py','transport/_swd_openocd.py',
    'ui/swd_connection.py','ui/probe_selection.py','ui/main_window.py','ui/maintenance_page.py',
    'services/i18n.py','tests/test_swd_session.py','tests/test_swd_ui.py','tests/test_probe_ui.py')]
sources+=['docs/public/GSHC/HOST_PROBE_SELECTION_20261013.md','docs/public/GSHC/SWD_READ_ONLY_20261013.md']
openocd=Path('D:/OpenOCD-20250710-0.12.0/bin/openocd.exe')
version=subprocess.run([str(openocd),'--version'],capture_output=True,text=True,timeout=5)
versions={'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'base_commit':git('rev-parse','HEAD'),'branch':git('branch','--show-current'),
    'python':sys.version,'packages':{n:importlib.metadata.version(n) for n in ('PySide6','pytest','pytest-qt','pyserial')},
    'openocd':{'path':str(openocd),'sha256':sha(openocd),'exit_code':version.returncode,
               'output':version.stdout+version.stderr,'device_opened':False},
    'frozen_tag_object':git('rev-parse','v0.1.2^{tag}'),
    'frozen_tag_commit':git('rev-parse','v0.1.2^{}'),
    'source_sha256':{name:sha(root/name) for name in sources}}
assert versions['frozen_tag_object']=='942f20ef64df3cb1aa65be7349361c409418aa0f'
assert versions['frozen_tag_commit']=='c31c13cc0686a56a3184d4f207fd3816c5d39696'
(task/'versions.json').write_text(json.dumps(versions,ensure_ascii=False,indent=2),encoding='utf-8')
paths=[]
for path in sorted(task.rglob('*')):
    if not path.is_file() or path.name=='inventory.json':continue
    purpose=('Generated, retained synthetic pytest fixture' if 'pytest_run04' in path.parts else
             'Retained host verification evidence / reproduction script')
    paths.append({'path':path.relative_to(root).as_posix(),'owner':'root integrator',
                  'purpose':purpose,'bytes':path.stat().st_size,'sha256':sha(path)})
inventory={'base_commit':versions['base_commit'],'cleanup_authorized':False,
    'notes':['Earlier pytest runs inherited the repository shared cache and OS pytest temp defaults; no cleanup was attempted.',
             'regression04 disables shared cache and uses the fresh task-owned pytest_run04 directory.',
             'Inventory excludes its own recursively changing hash. All source, evidence and fixtures are retained.'],
    'files':paths}
(task/'inventory.json').write_text(json.dumps(inventory,ensure_ascii=False,indent=2),encoding='utf-8')
archive=destination/'evidence.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as output:
    for path in sorted(task.rglob('*')):
        if path.is_file() and 'pytest_run04' not in path.parts:
            output.write(path,'task/'+path.relative_to(task).as_posix())
    earlier=root/'.work/dev013_probe03'
    for path in sorted(earlier.iterdir()):
        if path.is_file():output.write(path,'earlier_semantics/'+path.name)
    for name in sources:output.write(root/name,'source/'+name)
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    entries=[{'path':item.filename,'bytes':item.file_size,
              'sha256':hashlib.sha256(check.read(item.filename)).hexdigest()} for item in check.infolist()]
manifest={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),
          'files':entries,'retained_task_bytes':sum(row['bytes'] for row in paths)}
(destination/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in manifest.items() if k!='files'},indent=2))
