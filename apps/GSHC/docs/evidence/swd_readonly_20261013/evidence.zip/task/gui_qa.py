"""Own offscreen Qt surface; synthetic target and no hardware/device opens."""
from pathlib import Path
import json, sys, time
from unittest.mock import patch
from PySide6.QtCore import QObject, QSettings, QRect, QPoint
from PySide6.QtGui import QFont, QFontDatabase
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication
from services.i18n import I18n
from ui.main_window import MainWindow
from ui.probe_selection import ProbeSelectionManager
from ui.swd_connection import SwdConnectionManager
from transport.probe_inventory import ProbeInventory, ProbeInventoryResult
from transport.swd_session import SwdSession
from test_swd_session import PROBE, FakeMemory
def wait_for(predicate):
    deadline=time.monotonic()+4
    while not predicate() and time.monotonic()<deadline:
        QApplication.processEvents()
        time.sleep(.01)  # Yield the GIL to the file/pipe worker, unlike QTest.qWait.
    assert predicate()

out=Path(__file__).resolve().parent/sys.argv[1]
out.mkdir(exist_ok=False)
app=QApplication([])
QFontDatabase.addApplicationFont('C:/Windows/Fonts/msyh.ttc')
app.setFont(QFont('Microsoft YaHei',10))
window=MainWindow(I18n(QSettings(str(out/'settings.ini'),QSettings.IniFormat)))
window.render_timer.stop();window.gl_view.hide()
controller=QObject(window);controller.window=window
controller.probes=ProbeSelectionManager(controller,lambda _:ProbeInventory(ProbeInventoryResult.Ready,(PROBE,)))
wait_for(lambda:controller.probes.worker is None and bool(controller.probes.selection.identity))
backend=FakeMemory(None)
factory=lambda **kw:SwdSession(**kw,_backend_factory=lambda _:backend)
controller.swd=SwdConnectionManager(controller,factory)
window.on_close_requested=lambda:all([controller.swd.request_close(),controller.probes.request_close()])
window.pages.setCurrentWidget(window.maintenance_scroll)
window.resize(1280,850);window.show();QTest.qWait(100)
records=[]
for language in ('zh_CN','en_US'):
    window.i18n.set_language(language);window.retranslate_ui()
    controller.swd.factory=factory
    controller.swd.attach();wait_for(lambda:controller.swd.snapshot is not None)
    QTest.qWait(50)
    filename=f'{language}_mock_running.png';assert window.grab().save(str(out/filename))
    records.append({'file':filename,'status':controller.swd.status,'synthetic_target':True,
                    'size':[window.width(),window.height()]})
    controller.swd.detach();wait_for(lambda:controller.swd.worker is None)
    class TracedSession(SwdSession):
        def Swd_Attach(self,probe):
            print('ADMISSION START',language,flush=True)
            result=super().Swd_Attach(probe)
            print('ADMISSION END',result.result.value,flush=True)
            return result
    controller.swd.factory=TracedSession
    # Even a future accidental gate regression must not reach device/process open.
    with patch('subprocess.Popen',side_effect=AssertionError('No device process permitted in QA')):
        controller.swd.attach();wait_for(lambda:controller.swd.worker is None)
    assert controller.swd.status=='swd.safety_not_proven'
    QTest.qWait(50)
    filename=f'{language}_blocked.png';assert window.grab().save(str(out/filename))
    records.append({'file':filename,'status':controller.swd.status,'device_opened':False,
                    'detail':controller.swd.detail,'size':[window.width(),window.height()]})
    page=window.maintenance_page
    for button in (page.btn_swd_attach,page.btn_swd_detach):
        assert button.width()>=button.minimumSizeHint().width()
    assert page.swd_target_status.height()>=page.swd_target_status.heightForWidth(page.swd_target_status.width())
    label=window.probe_status
    assert label.height()>=label.heightForWidth(label.width())
window.close();QTest.qWait(50)
assert controller.swd.worker is None and controller.probes.worker is None
(out/'report.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(records,ensure_ascii=False,indent=2))
