# 0.1.3 SWD read-only groundwork — retained task inventory

Owner: root integrator, sole repository writer.
Base: bfe933eebd8df3cd439ea6cd256c1c7e60e57a75, existing local development branch.
Purpose: bounded Python/JSON/Qt SWD interface, synthetic target regression,
backend admission review, and retained evidence. Incorporates the pending
probe-state wording fix verified separately in `.work/dev013_probe03`.

This directory holds only this task's generated commands, logs, source hashes,
mock pipe fixtures and UI screenshots. No cleanup is authorized. Old task
directories, user inputs, frozen releases and firmware are not cleanup targets.
No hardware connection, serial command, firmware build, driver/package install,
tag, push or publication. OpenOCD --version and executable hashing are host-only.
Final inventory records each retained file's purpose, owner, size and SHA256.
