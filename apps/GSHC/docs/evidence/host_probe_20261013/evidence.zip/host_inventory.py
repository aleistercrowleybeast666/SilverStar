from dataclasses import asdict
from pathlib import Path
from threading import Event
import datetime, json, sys, time
from transport.probe_inventory import ProbeInventory_Read
start = time.monotonic()
result = ProbeInventory_Read(Event())
record = dict(observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    elapsed_seconds=time.monotonic()-start, result=result.result.value, detail=result.detail,
    probes=[asdict(p) for p in result.probes], boundary='Host PnP metadata only; no COM/USB interface or SWD session opened; occupancy and target unknown')
destination = Path(__file__).with_name(sys.argv[1] if len(sys.argv) > 1 else 'host_inventory01.json')
assert not destination.exists()
destination.write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(record,ensure_ascii=False,indent=2))
