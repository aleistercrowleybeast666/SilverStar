"""Reproduce the pre-existing navigation assertion using the exact base window."""
import hashlib, subprocess, sys, types, unittest
commit='258aaa6eea88b70218e936795035fae2e84ad317'
source=subprocess.check_output(['git','show',commit+':apps/GSHC/ui/main_window.py'])
print('baseline',commit,'main_window SHA256',hashlib.sha256(source).hexdigest(),flush=True)
module=types.ModuleType('probe_baseline_main_window')
sys.modules[module.__name__]=module
exec(compile(source,'base258aaa6/main_window.py','exec'),module.__dict__)
import test_ui_workflow
test_ui_workflow.MainWindow=module.MainWindow
suite=unittest.TestSuite([test_ui_workflow.UiWorkflowTests('test_release_pages_are_manually_selectable')])
result=unittest.TextTestRunner(verbosity=2).run(suite)
sys.exit(0 if result.wasSuccessful() else 1)
