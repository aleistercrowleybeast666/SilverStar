# GSHC host probe selection, 0.1.3

Owner: root integrator. Base: 258aaa6eea88b70218e936795035fae2e84ad317.
Purpose: host-only probe enumeration, asynchronous selection UI and layout tests.
No SWD session, COM open, target commands, driver changes or firmware builds.
Library helper/transfer metadata are private task input; exclude signed transfers
from delivered evidence. Generated QA and logs stay here. No cleanup authorized.
