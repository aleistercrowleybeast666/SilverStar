"""Windows Qt source GUI QA with one real host-only inventory; no serial/SWD opens."""
from pathlib import Path
from dataclasses import asdict
from unittest.mock import patch
import datetime, json, os, platform, sys, time
from PySide6 import __version__ as qt_version
from PySide6.QtCore import QPoint, QRect, QSettings
from PySide6.QtGui import QFont, QFontDatabase
from PySide6.QtWidgets import QApplication
from PySide6.QtTest import QTest
from app import Controller
from services.i18n import I18n
from ui.main_window import MainWindow
from transport.probe_inventory import HostProbe, ProbeInventory, ProbeInventoryResult, ProbeInventory_Read

root=Path(__file__).resolve().parent
out=root/sys.argv[1]
out.mkdir(exist_ok=False)
application=QApplication([])
if os.environ.get('QT_QPA_PLATFORM')=='offscreen':
    QFontDatabase.addApplicationFont('C:/Windows/Fonts/msyh.ttc')
    application.setFont(QFont('Microsoft YaHei',10))
window=MainWindow(I18n(QSettings(str(out/'settings.ini'),QSettings.IniFormat)))
records=[]
inventories=[]
def enumerate_host(cancel):
    if '--replay' in sys.argv:
        snapshot=json.loads((root/'host_inventory04.json').read_text(encoding='utf-8'))
        result=ProbeInventory(ProbeInventoryResult(snapshot['result']),tuple(HostProbe(**p) for p in snapshot['probes']))
    else:
        result=ProbeInventory_Read(cancel)
    inventories.append(dict(result=result.result.value,detail=result.detail,probes=[asdict(p) for p in result.probes]))
    return result
with patch('app.USER_DATA_ROOT',out/'user-data'), patch('transport.serial_backend.serial.Serial',side_effect=AssertionError('QA must not open serial')) as serial_open:
    controller=Controller(window,probe_enumerator=enumerate_host)
    try:
        window.pages.setCurrentIndex(3)
        window.resize(1280,800); window.show()
        deadline=time.monotonic()+25
        while (controller.probes.status in ('probe.not_scanned','probe.busy') or controller.probes.worker is not None) and time.monotonic()<deadline:
            QTest.qWait(20)
        assert controller.probes.worker is None
        assert controller.probes.status in ('probe.selected','probe.empty'),controller.probes.status
        controller.probes.timer.stop()
        for language in ('zh_CN','en_US'):
            window.i18n.set_language(language); window.retranslate_ui()
            for width in (1024,1280,1920):
                window.resize(width,800); QTest.qWait(100)
                rect=lambda w: QRect(w.mapTo(window,QPoint()),w.size())
                bar=rect(window.header_bar)
                groups=[rect(w) for w in (window.header_connection_group,window.debug_connection_group,window.probe_group)]
                assert all(bar.contains(group) for group in groups)
                assert all(not one.intersects(two) for i,one in enumerate(groups) for two in groups[i+1:])
                assert 0<=bar.right()-rect(window.btn_probe_refresh).right()<=20
                path=out/f'{language}_{width}_header.png'
                assert window.header_bar.grab().save(str(path))
                if language=='zh_CN' and width==1280:
                    assert window.grab().save(str(out/'zh_CN_1280_window.png'))
                if width<=1280: assert window.width()<=width
                records.append(dict(language=language,requested_width=width,actual_width=window.width(),
                    mode=window._connection_layout_mode,header=bar.getRect(),groups=[g.getRect() for g in groups],
                    selected=controller.probes.selection.identity,status=window.probe_status.text()))
        assert serial_open.call_count==0
    finally:
        controller.shutdown(); window.close(); application.processEvents()
(out/'qa.json').write_text(json.dumps(dict(observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    qt=qt_version,python=sys.version,platform=platform.platform(),qpa=os.environ.get('QT_QPA_PLATFORM'),
    scale=os.environ.get('QT_SCALE_FACTOR','1'),checks=records,inventories=inventories,replay='--replay' in sys.argv,
    serial_open_calls=serial_open.call_count),ensure_ascii=False,indent=2),encoding='utf-8')
print('GUI QA completed:',out)
