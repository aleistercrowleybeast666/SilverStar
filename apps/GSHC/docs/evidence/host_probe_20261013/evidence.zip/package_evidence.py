"""Package explicit generated evidence only; leave every task input in place."""
from pathlib import Path
import datetime, hashlib, json, subprocess, zipfile
root=Path(__file__).resolve().parents[2]
task=Path(__file__).resolve().parent
out=root/'apps/GSHC/docs/evidence/host_probe_20261013'
out.mkdir(parents=True,exist_ok=True)
destination=out/'evidence.zip'
assert not destination.exists()
record=json.loads((task/'probe_tests03.json').read_text(encoding='utf-8'))
assert record['exit_code']==0
for relative,sha in record['inputs'].items():
    assert hashlib.sha256((root/relative).read_bytes()).hexdigest()==sha,relative
selected=[]
for pattern in ('host_inventory*.json','probe_tests*.json','probe_tests*.log','gui_qa*.json','gui_qa*.log','baseline_navigation*.json','baseline_navigation*.log'):
    selected.extend(task.glob(pattern))
selected.extend(task/name for name in ('README.md','verify.py','gui_qa.py','host_inventory.py','baseline_navigation.py','versions.json','package_evidence.py'))
for name in ('gui02','gui03','gui04_replay'):
    folder=task/name
    selected.extend(folder.glob('*.png'))
    selected.append(folder/'qa.json')
manifest=[]
with zipfile.ZipFile(destination,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for path in sorted(set(selected)):
        resolved=path.resolve()
        assert resolved.is_relative_to(task)
        assert 'library-helper' not in resolved.parts
        data=resolved.read_bytes()
        relative=resolved.relative_to(task).as_posix()
        archive.writestr(relative,data)
        manifest.append(dict(path=relative,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
    archive.writestr('manifest.json',json.dumps(manifest,indent=2))
inventory=[]
for path in sorted(task.rglob('*')):
    if path.is_file() and path.name!='inventory.json':
        data=path.read_bytes()
        inventory.append(dict(path=path.relative_to(task).as_posix(),bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),
            owner='root integrator',purpose='private Library transfer input' if 'library-helper' in path.parts else 'host probe development / QA evidence',
            retained=True,cleanup_authorized=False))
(task/'inventory.json').write_text(json.dumps(inventory,indent=2),encoding='utf-8')
summary=dict(base_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),entries=len(manifest)+1,
    archive_bytes=destination.stat().st_size,sha256=hashlib.sha256(destination.read_bytes()).hexdigest(),
    task_files=len(inventory),task_bytes=sum(x['bytes'] for x in inventory))
(out/'archive.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
