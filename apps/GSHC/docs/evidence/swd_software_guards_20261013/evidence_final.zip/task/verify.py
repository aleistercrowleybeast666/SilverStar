"""Root-owned bounded host UI command evidence; no firmware build."""
from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys
root=Path(__file__).resolve().parents[2]
out=Path(__file__).resolve().parent
name=sys.argv[1]
assert name.replace('_','').isalnum()
assert not (out/(name+'.json')).exists() and not (out/(name+'.log')).exists()
inputs={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
        for p in (root/'apps/GSHC').rglob('*.py') if '__pycache__' not in p.parts}
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out/(name+'.log')).open('xb') as stream:
    run=subprocess.run(sys.argv[2:],cwd=root,stdout=stream,stderr=subprocess.STDOUT)
(out/(name+'.json')).write_text(json.dumps(dict(command=sys.argv[2:],cwd=str(root),started=started,
    finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=run.returncode,
    python=sys.version,environment={k:os.environ.get(k) for k in ('PYTHONPATH','QT_QPA_PLATFORM','QT_SCALE_FACTOR')},
    inputs=inputs),indent=2),encoding='utf-8')
print(name,'exit',run.returncode)
sys.exit(run.returncode)
