"""Metadata-only preflight; this is not a USB/HID handle ownership test."""
from pathlib import Path
import datetime,json,subprocess,sys
from threading import Event
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'apps/GSHC'))
from transport.probe_inventory import ProbeInventory_Read
from dataclasses import asdict
from enum import Enum
script="""$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[System.Text.UTF8Encoding]::new($false)
$names=@('openocd.exe','pyocd.exe','ST-LINK_gdbserver.exe','ST-LINK_CLI.exe','STM32_Programmer_CLI.exe','STM32CubeProgrammer.exe','JLink.exe','JLinkGDBServer.exe','JLinkGDBServerCL.exe','JLinkGDBServerCLExe.exe','Ozone.exe','UV4.exe')
$filter=($names|ForEach-Object {\"Name='$_'\"}) -join ' OR '
@{processes=@(Get-CimInstance Win32_Process -Filter $filter|Select-Object Name,ProcessId,CreationDate)}|ConvertTo-Json -Depth 4 -Compress
"""
run=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',script],capture_output=True,timeout=20)
inventory=ProbeInventory_Read(Event(),timeout=20)
result={'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'process_query_exit':run.returncode,'process_query':run.stdout.decode('utf-8-sig','replace'),
 'process_error':run.stderr.decode('utf-8-sig','replace'),'inventory':asdict(inventory),
 'device_opened':False,'target_identified':False,'scope':'Known executable names and host PnP metadata only; not a proof that a device is unoccupied'}
out=Path(__file__).resolve().parent/'host_preflight01.json'
assert not out.exists()
out.write_text(json.dumps(result,ensure_ascii=False,indent=2,default=lambda x:x.value if isinstance(x,Enum) else str(x)),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2,default=lambda x:x.value if isinstance(x,Enum) else str(x)))
