# 0.1.3 SWD software refusal and cleanup regression

Owner: root integrator. Base: 659ec97445a86af4e18a3f2e36cf4f8e50cc0572.
Purpose: pre/post failure evidence for Busy during attach, startup/claim refusal
and bounded owned-process/stream release. All target and child logs are synthetic.
No physical USB/HID/serial/SWD opens, driver/program install or replacement,
source-code backend build, firmware build, live gate change, push or cleanup.
Keep formal evidence and test inputs. During this task conditional read-only bench
permission arrived, with reported external 5V, three SWD wires, NRST absent and
actuators disconnected. Only the authorized process/PnP metadata preflight ran;
the unresolved pre-DAP ownership gate still blocks actual target connection.
