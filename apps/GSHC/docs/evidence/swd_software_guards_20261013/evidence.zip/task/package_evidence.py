"""Seal host-only guard evidence. No cleanup or device access."""
from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
import importlib.metadata
root=Path(__file__).resolve().parents[2]
task=Path(__file__).resolve().parent
destination=root/'apps/GSHC/docs/evidence/swd_software_guards_20261013'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=root,text=True,encoding='utf-8').strip()
test=json.loads((task/'regression04.json').read_text(encoding='utf-8'))
assert test['exit_code']==0
for name,digest in test['inputs'].items():assert sha(root/name)==digest,name
source_names=['apps/GSHC/transport/swd_session.py','apps/GSHC/transport/_swd_openocd.py',
              'apps/GSHC/tests/test_swd_guard.py','docs/public/GSHC/SWD_SOFTWARE_GUARDS_20261013.md',
              'docs/public/GSHC/SWD_READ_ONLY_20261013.md']
metadata={'base_commit':git('rev-parse','HEAD'),'branch':git('branch','--show-current'),'python':sys.version,
 'packages':{n:importlib.metadata.version(n) for n in ('pytest','PySide6','pytest-qt')},
 'frozen_tag_object':git('rev-parse','v0.1.2^{tag}'),'frozen_tag_commit':git('rev-parse','v0.1.2^{}'),
 'source_sha256':{name:sha(root/name) for name in source_names},
 'openocd_sha256':sha(Path('D:/OpenOCD-20250710-0.12.0/bin/openocd.exe')),
 'device_opened':False,'target_identified':False,'admission_changed':False}
assert metadata['frozen_tag_object']=='942f20ef64df3cb1aa65be7349361c409418aa0f'
assert metadata['frozen_tag_commit']=='c31c13cc0686a56a3184d4f207fd3816c5d39696'
assert metadata['openocd_sha256']=='3ee2ce721e7c2b0c0359b7a6a6b2a1f9a7c9a8dca3ad11db16b1085d57229cf7'
(task/'final_state.json').write_text(json.dumps(metadata,indent=2),encoding='utf-8')
marker={'command':['D:/OpenOCD-20250710-0.12.0/bin/openocd.exe','-c','noinit',
 '-c','gdb port disabled','-c','tcl port disabled','-c','telnet port disabled',
 '-c','echo SILVERSTAR_MEM_AP_INIT_COMPLETE','-c','shutdown'],
 'exit_code':0,'adapter_configured':False,'target_init':False,
 'stderr_sha256':sha(task/'marker_parse01.stderr.log'),'stdout_sha256':sha(task/'marker_parse01.stdout.log')}
assert b'SILVERSTAR_MEM_AP_INIT_COMPLETE' in (task/'marker_parse01.stderr.log').read_bytes()
assert (task/'marker_parse01.stdout.log').stat().st_size==0
(task/'marker_parse01.json').write_text(json.dumps(marker,indent=2),encoding='utf-8')
rows=[]
for path in sorted(task.rglob('*')):
    if not path.is_file() or path.name=='inventory.json':continue
    generated=any(part.startswith('pytest_') for part in path.parts)
    rows.append({'path':path.relative_to(root).as_posix(),'bytes':path.stat().st_size,'sha256':sha(path),
                 'owner':'root integrator','purpose':'Retained synthetic fixture/cache' if generated else
                 'Retained failure/normal host evidence and reproduction script'})
(task/'inventory.json').write_text(json.dumps({'cleanup_authorized':False,'files':rows},indent=2),encoding='utf-8')
archive=destination/'evidence.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as output:
    for path in sorted(task.rglob('*')):
        if path.is_file() and not any(part.startswith('pytest_') for part in path.parts):
            output.write(path,'task/'+path.relative_to(task).as_posix())
    for name in source_names:output.write(root/name,'source/'+name)
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    entries=[{'path':item.filename,'bytes':item.file_size,
              'sha256':hashlib.sha256(check.read(item.filename)).hexdigest()} for item in check.infolist()]
manifest={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),
          'files':entries,'retained_task_bytes':sum(row['bytes'] for row in rows)}
(destination/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in manifest.items() if k!='files'},indent=2))
