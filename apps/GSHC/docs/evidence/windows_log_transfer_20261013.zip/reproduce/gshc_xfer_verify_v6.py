from pathlib import Path

source = Path('.work/gshc_xfer_verify_v3.py').read_text(encoding='utf-8').replace('_v3', '_v6')
start = source.index('tests = [')
end = source.index('\ncommand = ', start)
source = source[:start] + "tests = ['test_file_service_client.py', 'test_file_transfer_ui.py', 'test_receive_pipeline.py', 'test_start_ack_state.py']" + source[end:]
source = source.replace("'six current-header cases included; earlier original-header six baseline failures retained separately'",
    "'No DPI cases in this focused follow-up; all six passed in v4. Final changes guard START pending and add error context; no geometry changes.'")
exec(compile(source, __file__, 'exec'))
