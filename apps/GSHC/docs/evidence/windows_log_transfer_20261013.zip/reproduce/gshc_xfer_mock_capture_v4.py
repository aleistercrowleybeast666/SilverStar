from pathlib import Path

source = Path('.work/gshc_xfer_mock_capture.py').read_text(encoding='utf-8').replace('_v3', '_v4')
exec(compile(source, __file__, 'exec'))
