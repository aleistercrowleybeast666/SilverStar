"""Read-only HEAD UI baseline in memory; no checkout replacement or hardware."""
import os
import subprocess
import sys
import types
from pathlib import Path

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / "apps/GSHC"))
sys.path.insert(0, str(root / "apps/GSHC/tests/validation"))
os.environ["QT_QPA_PLATFORM"] = "offscreen"
source = subprocess.check_output(["git", "show", "HEAD:apps/GSHC/ui/main_window.py"], cwd=root).decode("utf-8")
module = types.ModuleType("ui.main_window")
module.__file__ = str(root / "apps/GSHC/ui/main_window.py")
sys.modules["ui.main_window"] = module
exec(compile(source, module.__file__, "exec"), module.__dict__)
from port_geometry_probe import Probe_Run
width, height = (int(sys.argv[1]), int(sys.argv[2])) if len(sys.argv) > 2 else (1920, 1080)
label = f"head_header_baseline_{width}_{height}_{os.environ.get('QT_SCALE_FACTOR', '1.0')}"
Probe_Run(root / ".work/gshc_xfer_evidence" / label, width, height)
