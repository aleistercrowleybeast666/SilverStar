import os
from pathlib import Path
import sys
from unittest.mock import patch

root = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(root/'apps/GSHC'), str(root/'apps/GSHC/tests')]
os.environ['QT_QPA_PLATFORM'] = 'offscreen'
from test_file_transfer_ui import TransferUiTests
from test_file_service_client import MockTransport
from PySide6.QtTest import QTest

TransferUiTests.setUpClass()
case = TransferUiTests()
case.setUp()
try:
    wire = MockTransport()
    case.controller.file_transfer.transport_factory = lambda *_: wire
    case.window.debug_port_combo.setCurrentText('COM7')
    case.window.btn_debug_connect.click()
    case.wait_connected()
    with patch('ui.file_transfer.QFileDialog.getExistingDirectory', return_value=str(case.target)):
        case.window.action_download_copy.trigger()
        case.wait_finished()
    assert case.window._debug_connected and not wire.closed
    assert list(case.target.glob('*/manifest.json'))
    QTest.qWait(30)
    evidence = root/'.work/gshc_xfer_evidence_v3'
    case.window.grab().save(str(evidence/'windows_mock_connected_download.png'))
    case.window.maintenance_page.btn_details.click()
    QTest.qWait(30)
    case.window.maintenance_page.details.grab().save(str(evidence/'windows_readonly_details.png'))
    print('Mock persistent port / download / details capture PASS; no physical I/O')
finally:
    case.tearDown()
