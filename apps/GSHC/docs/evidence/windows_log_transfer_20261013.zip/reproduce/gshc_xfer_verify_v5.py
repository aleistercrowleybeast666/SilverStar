from pathlib import Path

source = Path('.work/gshc_xfer_verify_v3.py').read_text(encoding='utf-8').replace('_v3', '_v5')
start = source.index('tests = [')
end = source.index('\ncommand = ', start)
source = source[:start] + "tests = ['test_file_service_client.py', 'test_file_transfer_ui.py']" + source[end:]
source = source.replace("'six current-header cases included; earlier original-header six baseline failures retained separately'",
    "'No DPI cases in this final focused follow-up; all six passed in v4 before only error text/tests/docs changed'")
exec(compile(source, __file__, 'exec'))
