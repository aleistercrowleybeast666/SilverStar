import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
evidence = root / '.work/gshc_xfer_evidence_v3'
evidence.mkdir(exist_ok=True)
environment = dict(os.environ, PYTHONPATH=str(root / 'apps/GSHC'), QT_QPA_PLATFORM='offscreen',
    PYTHONIOENCODING='utf-8', TMP=str(root / '.work/gshc_xfer_tmp'), TEMP=str(root / '.work/gshc_xfer_tmp'),
    GSHC_TRANSFER_QA_DIR=str(evidence))
tests = ['test_device_export.py', 'test_file_service_client.py', 'test_file_transfer_ui.py',
    'test_data_paths.py', 'test_i18n.py', 'test_receive_pipeline.py', 'test_air_protocol.py',
    'test_port_gui.py', 'test_ui_workflow.py']
command = [sys.executable, '-m', 'pytest', *(f'apps/GSHC/tests/{name}' for name in tests),
    '-q', '--basetemp=.work/gshc_xfer_v3_final']
result = subprocess.run(command, cwd=root, env=environment, capture_output=True, text=True,
    encoding='utf-8', timeout=600)
(evidence / 'pytest_final.txt').write_text(result.stdout + result.stderr, encoding='utf-8')
print(result.stdout, flush=True)
owned = ['app.py', 'services/i18n.py', 'services/logger.py', 'services/device_export.py',
    'services/file_service_client.py', 'transport/file_service_backend.py', 'ui/main_window.py',
    'ui/file_transfer.py', 'ui/maintenance_page.py', 'tests/requirements.txt', 'tests/test_device_export.py',
    'tests/test_file_service_client.py', 'tests/test_file_transfer_ui.py', 'tests/test_ui_workflow.py',
    'tests/validation/port_geometry_probe.py', 'docs/LOG_TRANSFER_20261013.md']
hashes = {f'apps/GSHC/{name}': hashlib.sha256((root/'apps/GSHC'/name).read_bytes()).hexdigest() for name in owned}
record = {'python': sys.version, 'executable': sys.executable,
    'versions': {key: importlib.metadata.version(key) for key in ['PySide6', 'pytest', 'jsonschema', 'pyserial']},
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'dirty_source_sha256': hashes, 'final_scoped': {'command': command, 'exit_code': result.returncode,
    'log': 'pytest_final.txt', 'excluded': []}, 'hardware_access': 'none; mock transports and temporary samples only',
    'prior_evidence': ['../gshc_xfer_evidence/verification.json', '../gshc_xfer_evidence/pytest_transfer.txt'],
    'dpi': 'six current-header cases included; earlier original-header six baseline failures retained separately'}
(evidence/'verification.json').write_text(json.dumps(record, indent=2), encoding='utf-8')
print(json.dumps({'pytest_exit': result.returncode, 'source_files': len(hashes)}), flush=True)
sys.exit(result.returncode)
