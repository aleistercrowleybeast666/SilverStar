from pathlib import Path

source = Path('.work/gshc_xfer_verify_v6.py').read_text(encoding='utf-8').replace('_v6', '_v7')
exec(compile(source, __file__, 'exec'))
