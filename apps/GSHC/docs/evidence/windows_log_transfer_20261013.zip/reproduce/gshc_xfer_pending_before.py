from pathlib import Path

source = Path('.work/gshc_xfer_verify_v3.py').read_text(encoding='utf-8').replace('_v3', '_v6_before')
start = source.index('tests = [')
end = source.index('\ncommand = ', start)
source = source[:start] + "tests = ['test_file_transfer_ui.py::TransferUiTests::test_pending_start_submits_no_logfile_job_or_destination_write']" + source[end:]
source = source.replace("'six current-header cases included; earlier original-header six baseline failures retained separately'", "'not run in this defect reproduction'")
exec(compile(source, __file__, 'exec'))
