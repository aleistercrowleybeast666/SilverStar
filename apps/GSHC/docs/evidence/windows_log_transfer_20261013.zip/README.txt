Windows GSHC log transfer evidence, 2026-10-13.
v4: 129 passed in the 9-file scoped combination, including all six DPI probes.
v5: final focused client/Qt follow-up after only output-location error text, tests and docs changed.
v6_before: real mock reproduction of missing pending-START exclusion, expected FAIL before repair.
v6: 74 passed, two new tests failed because they passed an argument to the existing no-argument render_state API.
v7: final client/Qt/receive-pipeline/Controller START/ACK follow-up after correcting only those test calls.
Read each verification.json for its exact command, exit, source hashes, interpreter and package versions.
Do not combine runs into an unexecuted full-suite result. No actual serial, hub, USB, storage device or flight validation.
Mock screenshot capture ran with fully mocked transport and temporary files/QSettings.
The large-font DPI probe records requested and actual size; small requested windows may expand to existing content minimums.
History retains complete recorded failure logs, the original six baseline failures, and the v3 stale-version assertion failure.
Archive entries preserve original bytes. inventory.json provides per-entry SHA-256; the archive itself is checked separately.
