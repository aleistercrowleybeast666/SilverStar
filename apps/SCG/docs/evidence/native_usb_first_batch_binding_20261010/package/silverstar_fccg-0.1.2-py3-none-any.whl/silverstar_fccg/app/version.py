"""Authoritative SilverStar platform and FCCG product identity."""

from pathlib import Path

PRODUCT_NAME = "SilverStar SCG"
SILVERSTAR_PLATFORM_VERSION = (Path(__file__).resolve().parents[5] / "VERSION").read_text(encoding="ascii").strip()

_VERSION_PARTS = tuple(
    int(part) for part in SILVERSTAR_PLATFORM_VERSION.split(".")
)
if len(_VERSION_PARTS) != 3:
    raise RuntimeError("SilverStar platform version must have three numeric parts")

SILVERSTAR_PLATFORM_VERSION_MAJOR = _VERSION_PARTS[0]
SILVERSTAR_PLATFORM_VERSION_MINOR = _VERSION_PARTS[1]
SILVERSTAR_PLATFORM_VERSION_PATCH = _VERSION_PARTS[2]
SILVERSTAR_PLATFORM_ID_SUFFIX = SILVERSTAR_PLATFORM_VERSION.replace(".", "_")
SILVERSTAR_BUILD_ID = f"SilverStar_{SILVERSTAR_PLATFORM_ID_SUFFIX}"
# The installed core plugin has its own schema/payload version.
SILVERSTAR_CORE_COMPONENT_ID = "silverstar.core.0_1_0"
SILVERSTAR_CORE_PACKAGE_SLUG = SILVERSTAR_CORE_COMPONENT_ID.replace(".", "_")
SILVERSTAR_LOG_BUILD_TAG = (
    "SILV"
    f"{SILVERSTAR_PLATFORM_VERSION_MAJOR}"
    f"{SILVERSTAR_PLATFORM_VERSION_MINOR}"
    f"{SILVERSTAR_PLATFORM_VERSION_PATCH:02d}"
)
# Profile identity is a wire compatibility value, independent of the product release.
SILVERSTAR_SYSTEM_PROFILE_ID = 0x0000000C

__version__ = SILVERSTAR_PLATFORM_VERSION

__all__ = [
    "PRODUCT_NAME",
    "SILVERSTAR_BUILD_ID",
    "SILVERSTAR_CORE_COMPONENT_ID",
    "SILVERSTAR_CORE_PACKAGE_SLUG",
    "SILVERSTAR_LOG_BUILD_TAG",
    "SILVERSTAR_PLATFORM_ID_SUFFIX",
    "SILVERSTAR_PLATFORM_VERSION",
    "SILVERSTAR_PLATFORM_VERSION_MAJOR",
    "SILVERSTAR_PLATFORM_VERSION_MINOR",
    "SILVERSTAR_PLATFORM_VERSION_PATCH",
    "SILVERSTAR_SYSTEM_PROFILE_ID",
    "__version__",
]
