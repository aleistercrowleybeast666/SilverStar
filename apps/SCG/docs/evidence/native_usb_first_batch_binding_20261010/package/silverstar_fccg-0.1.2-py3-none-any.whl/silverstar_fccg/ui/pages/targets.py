from __future__ import annotations

from dataclasses import replace
import re

from PySide6.QtCore import QSignalBlocker, Signal
from PySide6.QtGui import QPalette
from silverstar_fccg.ui.widgets import CollapsibleSection, StandardCheckBox, StandardComboBox
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDoubleSpinBox, QFormLayout, QHBoxLayout, QLabel,
    QPushButton, QSpinBox, QLineEdit,
)

from silverstar_fccg.core.i18n import Translator
from silverstar_fccg.ui.committed_spin import EnterCommittedDoubleSpinBox, EnterCommittedSpinBox
from silverstar_fccg.ui.pages.base import ScrollableLocalizedPage
from silverstar_fccg.ui.pages.components import BoardHardwarePage
from silverstar_fccg.project.ground_activity import (
    GroundActivityLedEnabled_Get, GroundActivityLedIssues_Get,
    GroundActivityLedOutputResources_Get,
)
from silverstar_fccg.ui.ground_radio_instances import GroundRadioInstancesEditor
from silverstar_fccg.core.view_models import BoardCompatibilityView, ResourceRequirementView, PlatformMatchView


def GroundIssues_PresentationGet(issues, translator: Translator) -> tuple[str, str]:
    if not issues:
        return translator.Text_Get("status.ground_ready"), ""
    groups = (
        ("ground.issue.hardware", {"GROUND_HARDWARE_UNBOUND", "GROUND_CUBEMX_GENERATION_REQUIRED"}),
        ("ground.issue.uart", {"GROUND_UART_UNBOUND", "GROUND_PC_INTERFACE_UNBOUND"}),
        ("ground.issue.radio", {"GROUND_RADIO_RESOURCE_UNBOUND"}),
        ("ground.issue.led", {"GROUND_LED_OUTPUT_UNBOUND"}),
    )
    details = []
    handled = set()
    for key, codes in groups:
        matching = [issue for issue in issues if issue.code in codes]
        if not matching:
            continue
        handled.update(codes)
        guidance = translator.Text_Get(key)
        if key == "ground.issue.radio":
            kinds = sorted({match.group(1).upper() for issue in matching
                            if (match := re.search(r"needs a ([a-z_]+) resource", issue.message))})
            if kinds:
                guidance += " (" + ", ".join(kinds) + ")"
        details.append(guidance)
    if any(issue.code not in handled for issue in issues):
        details.append(translator.Text_Get("ground.issue.other"))
    return translator.Text_Get("ground.issue.summary", count=len(issues)), "\n".join(details)


class AirLinkPage(ScrollableLocalizedPage):
    configurationChanged = Signal(str, object)
    endpointPowerChanged = Signal(str, int)

    def __init__(self, translator: Translator) -> None:
        super().__init__(translator, "page.telemetry_configuration", "page.telemetry_configuration.description")
        form = QFormLayout()
        self._air_form = form
        self._nrf24_parameters = None
        self.fields: dict[str, object] = {}
        self._radio_choices: dict[str, tuple[tuple[str, str], ...]] = {}
        self._radio_technologies: set[str] = set()
        self._radio_contracts = ()
        for name, key, minimum, maximum in (
            ("spreading_factor", "field.air_sf", 5, 12),
            ("bandwidth_hz", "field.air_bandwidth", 1000, 2000000),
            ("preamble_symbols", "field.air_preamble", 4, 65535),
            ("packet_mtu", "field.air_mtu", 1, 255),
        ):
            label = QLabel()
            self.Text_Register(label, key)
            value = EnterCommittedSpinBox()
            value.setRange(minimum, maximum)
            value.committed.connect(
                lambda selected, field=name: self.configurationChanged.emit(field, selected)
            )
            form.addRow(label, value)
            self.fields[name] = value
        frequency_label = QLabel()
        self.Text_Register(frequency_label, "field.air_frequency")
        frequency = EnterCommittedDoubleSpinBox()
        frequency.setRange(0.0, 0.0)
        frequency.setEnabled(False)
        frequency.setDecimals(3)
        frequency.setSuffix(" MHz")
        frequency.committed.connect(
            lambda selected: self.configurationChanged.emit(
                "frequency_hz", round(selected * 1000000)
            )
        )
        frequency.rejected.connect(
            lambda _draft: self.status.setText(
                "AIR_LINK_FREQUENCY_OUT_OF_RANGE: " + frequency.toolTip()
            )
        )
        form.insertRow(0, frequency_label, frequency)
        self.fields["frequency_hz"] = frequency
        self.flight_tx_power = EnterCommittedSpinBox()
        self._ground_power_available = False
        self.flight_tx_power.setRange(0, 0)
        self.flight_tx_power.setEnabled(False)
        self.flight_tx_power.setSuffix(" dBm")
        self.flight_tx_power.committed.connect(
            lambda value: self.endpointPowerChanged.emit("flight", value)
        )
        self.flight_tx_power.rejected.connect(
            lambda _draft: self.status.setText(
                "AIR_LINK_TX_POWER_UNSUPPORTED: " + self.flight_tx_power.toolTip()
            )
        )
        flight_power_label = QLabel()
        self.Text_Register(flight_power_label, "field.flight_tx_power")
        form.addRow(flight_power_label, self.flight_tx_power)
        form.setRowVisible(self.flight_tx_power, False)
        self.ground_tx_power = EnterCommittedSpinBox()
        self.ground_tx_power.setRange(0, 0)
        self.ground_tx_power.setEnabled(False)
        self.ground_tx_power.setSuffix(" dBm")
        self.ground_tx_power.committed.connect(
            lambda value: self.endpointPowerChanged.emit("ground", value)
        )
        self.ground_tx_power.rejected.connect(
            lambda _draft: self.status.setText(
                "AIR_LINK_TX_POWER_UNSUPPORTED: " + self.ground_tx_power.toolTip()
            )
        )
        ground_power_label = QLabel()
        self.Text_Register(ground_power_label, "field.ground_tx_power")
        form.addRow(ground_power_label, self.ground_tx_power)
        form.setRowVisible(self.ground_tx_power, False)
        for name, key, choices in (
            ("radio_technology", "field.air_technology",
             (("LoRa", "lora"), ("Packet Radio / Other", "packet"))),
            ("radio_family", "field.air_family", (("SX128x", "sx128x"),)),
            ("phy_mode", "field.air_phy", (("LoRa", "lora"),)),
            ("coding_rate", "field.air_coding_rate", (("4/5", "4/5"),)),
            ("header_mode", "field.air_header", (("Explicit", "explicit"),)),
            ("iq_mode", "field.air_iq", (("Normal", "normal"),)),
        ):
            label = QLabel()
            self.Text_Register(label, key)
            value = QComboBox()
            for title, identity in choices:
                value.addItem(title, identity)
            self._radio_choices[name] = choices
            value.currentIndexChanged.connect(
                lambda _index, field=name, combo=value:
                self.configurationChanged.emit(field, combo.currentData())
            )
            form.addRow(label, value)
            self.fields[name] = value
        crc_label = QLabel()
        self.Text_Register(crc_label, "field.air_crc")
        self.crc = QCheckBox()
        self.crc.setObjectName("standardCheckBox")
        self.crc.toggled.connect(
            lambda checked: self.configurationChanged.emit("crc_enabled", checked)
        )
        form.addRow(crc_label, self.crc)
        self.nrf24_fields = {}
        for name, key in (("data_rate_kbps", "field.nrf24_rate"), ("address", "field.nrf24_address"),
                          ("retry_delay_us", "field.nrf24_delay"), ("retry_count", "field.nrf24_retries")):
            label = QLabel()
            self.Text_Register(label, key)
            widget = QLineEdit() if name == "address" else QComboBox()
            if isinstance(widget, QComboBox):
                options = {"data_rate_kbps": (250, 1000, 2000), "retry_delay_us": range(500, 4001, 250), "retry_count": range(16)}[name]
                for value in options:
                    widget.addItem(str(value), value)
                widget.currentIndexChanged.connect(lambda _index, field=name, combo=widget: self._Nrf24_Change(field, combo.currentData()))
            else:
                widget.setMaxLength(10)
                widget.editingFinished.connect(lambda field=name, line=widget: self._Nrf24_Change(field, line.text()))
            form.addRow(label, widget)
            form.setRowVisible(widget, False)
            self.nrf24_fields[name] = widget
        self.air_link_group = CollapsibleSection(translator.Text_Get("group.air_link"))
        self.air_link_group.BodyLayout_Set(form)
        self.root_layout.addWidget(self.air_link_group)
        self.status = QLabel()
        self.status.setWordWrap(True)
        self.root_layout.addWidget(self.status)
        self.root_layout.addStretch(1)

    def Language_Apply(self, translator: Translator) -> None:
        super().Language_Apply(translator)
        self.air_link_group.Title_Set(translator.Text_Get("group.air_link"))

    def RadioOptions_Set(self, radios: tuple[object, ...]) -> None:
        self._radio_contracts = tuple(radios)
        self._radio_technologies = {radio.technology for radio in radios}

    def _DeclaredChoices_Get(self, name, link):
        if name == "radio_technology":
            original = self._radio_choices[name]
            known = {identity for _title, identity in original}
            return (*original, *((identity, identity) for identity in sorted(self._radio_technologies - known)))
        if name not in {"radio_family", "phy_mode", "coding_rate"}:
            return self._radio_choices[name]
        radios = tuple(radio for radio in self._radio_contracts if radio.technology == link.radio_technology)
        if name == "radio_family":
            values = {radio.family for radio in radios}
        else:
            field = "phy_modes" if name == "phy_mode" else "coding_rates"
            values = {value for radio in radios if radio.family == link.radio_family for value in getattr(radio, field)}
        titles = dict((identity, title) for title, identity in self._radio_choices[name])
        return tuple((titles.get(identity, identity), identity) for identity in sorted(values))

    def Configuration_Set(self, link, issues) -> None:
        nrf24 = link.radio_family == "nrf24"
        self._nrf24_parameters = dict(link.nrf24) if link.nrf24 else None
        for name in ("spreading_factor", "bandwidth_hz", "coding_rate", "preamble_symbols", "header_mode", "iq_mode"):
            self._air_form.setRowVisible(self.fields[name], not nrf24)
        for name, widget in self.nrf24_fields.items():
            self._air_form.setRowVisible(widget, nrf24)
            with QSignalBlocker(widget):
                value = (link.nrf24 or {}).get(name)
                if isinstance(widget, QComboBox):
                    widget.setCurrentIndex(widget.findData(value))
                else:
                    widget.setText(value or "")
        for name, widget in self.fields.items():
            widget.blockSignals(True)
            if isinstance(widget, QDoubleSpinBox):
                widget.CommittedValue_Set(getattr(link, name) / 1000000)
            elif isinstance(widget, QSpinBox):
                widget.CommittedValue_Set(getattr(link, name))
            else:
                widget.clear()
                for title, identity in self._DeclaredChoices_Get(name, link):
                    widget.addItem(title, identity)
                    item = widget.model().item(widget.count() - 1)
                    if (name == "radio_technology" and
                            identity not in self._radio_technologies and item is not None):
                        item.setEnabled(False)
                        item.setToolTip("No installed radio supports this technology")
                selected = getattr(link, name)
                if widget.findData(selected) < 0:
                    widget.addItem(f"{selected} — unavailable", selected)
                    item = widget.model().item(widget.count() - 1)
                    if item is not None:
                        item.setEnabled(False)
                        item.setToolTip("Selected AIR option is unavailable")
                widget.setCurrentIndex(max(0, widget.findData(selected)))
            widget.blockSignals(False)
        self.crc.blockSignals(True)
        self.crc.setChecked(link.crc_enabled)
        self.crc.blockSignals(False)
        self.status.setText(
            "\n".join(f"{issue.code}: {issue.message}" for issue in issues)
            if issues else self._translator.Text_Get("status.air_link_ready")
        )

    def _Nrf24_Change(self, field, value):
        if self._nrf24_parameters is None:
            return
        parameters = {**self._nrf24_parameters, field: value}
        from silverstar_fccg.project.nrf24 import Nrf24Parameters_Validate
        try:
            Nrf24Parameters_Validate(parameters)
        except ValueError as error:
            self.status.setText(str(error))
            return
        self.configurationChanged.emit("nrf24", parameters)

    def EndpointPowers_Set(self, flight_power: int, ground_power: int, ground_enabled: bool) -> None:
        self.flight_tx_power.CommittedValue_Set(flight_power)
        self.ground_tx_power.CommittedValue_Set(ground_power)
        self.ground_tx_power.setEnabled(ground_enabled and self._ground_power_available)

    def RadioConstraints_Set(
        self, frequency_range_hz: tuple[int, int] | None,
        flight_powers_dbm: tuple[int, ...],
        ground_powers_dbm: tuple[int, ...],
        ground_enabled: bool,
    ) -> None:
        self._ground_power_available = bool(ground_powers_dbm)
        frequency = self.fields["frequency_hz"]
        if frequency_range_hz is None:
            frequency.setEnabled(False)
        else:
            low, high = frequency_range_hz
            frequency.setRange(low / 1000000, high / 1000000)
            frequency.setToolTip(f"Validated module frequency: {low / 1000000:g}–{high / 1000000:g} MHz")
            frequency.setEnabled(True)
        for widget, powers, enabled in (
            (self.flight_tx_power, flight_powers_dbm, True),
            (self.ground_tx_power, ground_powers_dbm, ground_enabled),
        ):
            if powers:
                widget.setRange(min(powers), max(powers))
                widget.setToolTip("Validated module TX power: " +
                                  ", ".join(str(value) for value in powers) + " dBm")
            widget.setEnabled(enabled and bool(powers))


class GroundTargetPage(BoardHardwarePage):
    enabledChanged = Signal(bool)
    configurationChanged = Signal(str, object)
    assignmentChanged = Signal(str, str)
    importRequested = Signal(bool)
    saveInstanceRequested = Signal()
    generateRequested = Signal()
    radiosChanged = Signal(object, str)
    activityLedToggled = Signal(bool)

    def __init__(self, translator: Translator) -> None:
        super().__init__(translator, target="ground")
        self.enabled = StandardCheckBox()
        self.enabled.setObjectName("standardCheckBox")
        self.Text_Register(self.enabled, "field.ground_enabled")
        self.enabled.toggled.connect(self.enabledChanged.emit)
        self.root_layout.addWidget(self.enabled)
        self.board = self.board_combo
        self.hardware_summary = self.platform_values["part"]
        self.import_ioc = self.import_ioc_button
        self.import_directory = self.import_directory_button
        self.save_instance = self.export_button
        self.boardChanged.connect(lambda value: self.configurationChanged.emit("board", value))
        self.customSelected.connect(lambda: self.configurationChanged.emit("board", ""))
        self.importIocRequested.connect(lambda: self.importRequested.emit(False))
        self.importDirectoryRequested.connect(lambda: self.importRequested.emit(True))
        self.exportRequested.connect(self.saveInstanceRequested.emit)
        radio_form = QFormLayout()
        self.root_layout.removeWidget(self.enabled)
        radio_form.addRow(self.enabled)
        radio_form.setRowVisible(self.enabled, False)
        label = QLabel()
        self.Text_Register(label, "field.ground_radio")
        self.radio = StandardComboBox()
        self.radio.currentIndexChanged.connect(
            lambda: self.configurationChanged.emit("radio_plugin", self.radio.currentData())
        )
        radio_form.addRow(label, self.radio)
        label = QLabel()
        self.Text_Register(label, "field.ground_module")
        self.module = StandardComboBox()
        self.module.currentIndexChanged.connect(
            lambda: self.configurationChanged.emit("module_variant", self.module.currentData())
        )
        radio_form.addRow(label, self.module)
        self.radio_form = radio_form
        self.radio_instances_editor = GroundRadioInstancesEditor(translator)
        self.radio_instances_editor.configurationChanged.connect(self.radiosChanged.emit)
        radio_form.addRow(self.radio_instances_editor)
        self.assignment_form = QFormLayout()
        self.assignments: dict[str, QComboBox] = {}
        self._assignment_signature: tuple[object, ...] = ()
        self.radio_selection_group = self.Group_Create(
            "group.ground_radio", radio_form
        )
        pc_form = QFormLayout()
        label = QLabel()
        self.Text_Register(label, "field.ground_pc_interface")
        self.pc_interface = StandardComboBox()
        self.pc_interface.addItem("—", "")
        self.pc_interface.addItem("UART Serial", "uart")
        self.pc_interface.addItem("USB CDC Virtual Serial", "usb_cdc")
        self.pc_interface.currentIndexChanged.connect(
            lambda: self.configurationChanged.emit("pc_interface", self.pc_interface.currentData())
        )
        pc_form.addRow(label, self.pc_interface)
        label = QLabel()
        self.Text_Register(label, "field.ground_pc_resource")
        self.pc_resource_label = label
        self.pc_form = pc_form
        self.pc_resource = StandardComboBox()
        self.pc_resource.currentIndexChanged.connect(
            lambda: self.configurationChanged.emit("pc_resource", self.pc_resource.currentData())
        )
        pc_form.addRow(label, self.pc_resource)
        self.pc_resource_source = QLabel()
        self.pc_resource_source.setWordWrap(True)
        pc_form.addRow(self.pc_resource_source)
        self.pc_resource_notice = QLabel()
        self.pc_resource_notice.setWordWrap(True)
        pc_form.addRow(self.pc_resource_notice)
        self.pc_group = self.Group_Create("group.ground_pc", pc_form)
        self.root_layout.addWidget(self.pc_group)
        led_form = QFormLayout()
        self.activity_led_enabled = StandardCheckBox()
        self.Text_Register(self.activity_led_enabled, "ground.activity_led_enable")
        self.activity_led_enabled.toggled.connect(self.activityLedToggled.emit)
        led_form.addRow(self.activity_led_enabled)
        self.activity_led_notice = QLabel()
        self.activity_led_notice.setObjectName("statusPill")
        self.activity_led_notice.setWordWrap(True)
        led_form.addRow(self.activity_led_notice)
        self.activity_led_group = self.Group_Create("group.ground_activity_leds", led_form)
        self.root_layout.addWidget(self.activity_led_group)
        self.resource_scope_notice = QLabel()
        self.resource_scope_notice.setObjectName("statusPill")
        self.resource_scope_notice.setWordWrap(True)
        self.advanced_section.body.layout().addWidget(self.resource_scope_notice)
        build_form = QFormLayout()
        build_label = QLabel()
        self.Text_Register(build_label, "field.ground_build")
        self.build_summary = QLabel("—")
        self.build_summary.setWordWrap(True)
        build_form.addRow(build_label, self.build_summary)
        self.build_group = self.Group_Create("group.ground_build", build_form)
        self.status = QLabel()
        self.status.setWordWrap(True)
        self.root_layout.addStretch(1)

    @staticmethod
    def ActivityLedCandidate_Get(ground) -> tuple[str, bool] | None:
        candidates = []
        for resource in GroundActivityLedOutputResources_Get(ground):
            metadata = resource.metadata
            if (metadata.get("activity_led_shared") is not True
                    or type(metadata.get("activity_led_active_high")) is not bool):
                continue
            active_high = metadata["activity_led_active_high"]
            trial = replace(ground, tx_led_resource=resource.resource_id,
                            rx_led_resource=resource.resource_id,
                            tx_led_active_high=active_high, rx_led_active_high=active_high,
                            activity_led_enabled=True)
            if not GroundActivityLedIssues_Get(trial):
                candidates.append((resource.resource_id, active_high))
        return candidates[0] if len(candidates) == 1 else None

    def Configuration_Set(self, ground, boards, radios, requirements, issues) -> None:
        for widget in (self.enabled, self.board, self.radio, self.module, self.pc_interface,
                       self.pc_resource):
            widget.blockSignals(True)
        self.enabled.setChecked(ground.enabled)
        self.generate_button.setEnabled(ground.enabled)
        self.save_instance.setEnabled(
            ground.hardware.mode == "custom"
            and bool(ground.hardware.snapshot_id)
            and bool(ground.hardware.build_sources)
        )
        self.hardware_summary.setText(
            f"{ground.hardware.mcu or '—'} · {ground.hardware.source_label or ground.hardware.mode}"
        )
        self.Boards_Set((BoardCompatibilityView(identity, title, True) for title, identity in boards),
            ground.board, custom_available=True, custom_selected=ground.hardware.mode == "custom",
            custom_ready=bool(ground.hardware.build_sources), prepared=not issues,
            hardware_mode=ground.hardware.mode, assignment_confirmed=not issues)
        self.Platform_Set(PlatformMatchView(hardware_source=ground.hardware.source_kind,
            detected_part=ground.hardware.mcu or str(ground.hardware.inventory.get("mcu_part", "")),
            detected_family=str(ground.hardware.inventory.get("mcu_family", "")),
            detected_package=str(ground.hardware.inventory.get("package", "")),
            detected_core=str(ground.hardware.inventory.get("core", "")),
            cubemx_version=ground.hardware.cubemx_version, firmware_package=ground.hardware.firmware_package))
        used_resources = set(ground.resource_assignments.values()) | {
            ground.pc_resource, ground.tx_led_resource, ground.rx_led_resource}
        unused_resources = (sorted(resource.resource_id for resource in ground.hardware.resources
                                   if resource.resource_id not in used_resources)
                            if ground.hardware.mode == "board_plugin" else [])
        self.radio.clear()
        self.radio.addItem("—", "")
        for title, identity, available, reason in radios:
            self.radio.addItem(title, identity)
            item = self.radio.model().item(self.radio.count() - 1)
            if item is not None:
                item.setEnabled(available)
                item.setToolTip(reason)
                if not available:
                    item.setForeground(self.radio.palette().color(
                        QPalette.ColorGroup.Disabled, QPalette.ColorRole.Text))
        if ground.radio_plugin and self.radio.findData(ground.radio_plugin) < 0:
            self.radio.addItem(f"{ground.radio_plugin} — unavailable", ground.radio_plugin)
            item = self.radio.model().item(self.radio.count() - 1)
            if item is not None:
                item.setEnabled(False)
                item.setToolTip("AIR_LINK_NO_RADIO: selected radio plugin is unavailable")
        self.radio.setCurrentIndex(max(0, self.radio.findData(ground.radio_plugin)))
        self.module.clear()
        self.module.addItem("—", "")
        for title, identity in requirements.get("modules", ()):
            self.module.addItem(title, identity)
        if ground.module_variant and self.module.findData(ground.module_variant) < 0:
            self.module.addItem(f"{ground.module_variant} — unavailable", ground.module_variant)
            item = self.module.model().item(self.module.count() - 1)
            if item is not None:
                item.setEnabled(False)
                item.setToolTip("AIR_LINK_NO_RADIO: selected module variant is unavailable")
        self.module.setCurrentIndex(max(0, self.module.findData(ground.module_variant)))
        # Keep legacy value bindings without duplicate visible selectors.
        self.radio_form.setRowVisible(self.radio, False)
        self.radio_form.setRowVisible(self.module, False)
        self.radio_instances_editor.Configuration_Set(
            ground, radios, requirements.get("radio_contracts", {}),
            requirements.get("module_availability", {}),
            requirements.get("radio_chipsets", {}))
        if any(issue.code == "GROUND_RADIO_RUNTIME_UNAVAILABLE" for issue in issues):
            self.radio_instances_editor.note.setText(self.radio_instances_editor.note.text() + "\n" +
                self._translator.Text_Get("ground.radio_runtime_pending"))
        self.pc_interface.setCurrentIndex(max(0, self.pc_interface.findData(ground.pc_interface)))
        uart_selected = ground.enabled and ground.pc_interface == "uart"
        self.pc_resource.setEnabled(uart_selected)
        self.pc_resource.clear()
        self.pc_resource.addItem("—", "")
        uarts = tuple(resource for resource in ground.hardware.resources if resource.kind == "uart")
        for resource in uarts:
            physical = resource.metadata.get("physical_resource", resource.resource_id)
            self.pc_resource.addItem(f"{physical} · {resource.resource_id}", resource.resource_id)
        missing = bool(ground.pc_resource) and self.pc_resource.findData(ground.pc_resource) < 0
        if missing:
            self.pc_resource.addItem(
                self._translator.Text_Get("ground.uart_unavailable", resource=ground.pc_resource),
                ground.pc_resource,
            )
            self.pc_resource.model().item(self.pc_resource.count() - 1).setEnabled(False)
        self.pc_resource.setCurrentIndex(max(0, self.pc_resource.findData(ground.pc_resource)))
        reason = ("ground.uart_select_hardware" if not ground.hardware.inventory else
                  "ground.uart_none" if not uarts else
                  "ground.uart_missing_binding" if missing else "")
        self.pc_resource_notice.setVisible(ground.pc_interface == "uart" and bool(reason))
        self.pc_resource_notice.setText(self._translator.Text_Get(reason) if reason else "")
        self.pc_resource.setToolTip(self.pc_resource_notice.text())
        self.pc_resource.setEnabled(uart_selected and bool(uarts))
        selected_uart = next((item for item in uarts if item.resource_id == ground.pc_resource), None)
        redundant = len(uarts) <= 1 and (selected_uart is not None or not uarts)
        self.pc_form.setRowVisible(self.pc_resource, ground.pc_interface == "uart" and not redundant)
        self.pc_resource_source.setVisible(ground.pc_interface == "uart" and selected_uart is not None)
        self.pc_resource_source.setText(self._translator.Text_Get(
            "ground.uart_binding_source",
            physical=selected_uart.metadata.get("physical_resource", selected_uart.resource_id),
            resource=selected_uart.resource_id,
            source=ground.hardware.source_label or ground.board or ground.hardware.source_kind,
        ) if selected_uart is not None else "")
        with QSignalBlocker(self.activity_led_enabled):
            active = GroundActivityLedEnabled_Get(ground)
            self.activity_led_enabled.setChecked(active)
            self.activity_led_enabled.setEnabled(ground.enabled)
        self.activity_led_enabled.setToolTip(
            self._translator.Text_Get(
                "ground.activity_led_hint" if self.activity_led_enabled.isEnabled()
                else "ground.activity_led_unavailable"
            )
        )
        self.build_summary.setText(
            f"{ground.build.make_command} · "
            f"{ground.build.toolchain_prefix}gcc · Ground_Station.code-workspace"
        )
        for widget in (self.enabled, self.board, self.radio, self.module, self.pc_interface,
                       self.pc_resource):
            widget.blockSignals(False)
        required = tuple(requirements.get("resources", ()))
        resource_views = self.ResourceViews_Get(ground, requirements, issues)
        self.Resources_Set(resource_views, not issues, hardware_selected=ground.hardware.mode != "unselected")
        self.assignments = {name: self.resource_table.cellWidget(row, 3) for row, (name, _kind) in enumerate(required)}
        # Ground generation checks the fixed radio/PC contracts; preparation
        # operations requiring flight task ownership do not apply to Ground.
        for button in (self.manual_validation_button, self.auto_button):
            button.setEnabled(False)
        self.prepare_button.setEnabled(bool(boards))
        self.prepare_button.setToolTip("" if boards else self._translator.Text_Get("board.no_provider"))
        self.i2c_pullup_group.setVisible(False)
        issue_summary, issue_details = GroundIssues_PresentationGet(issues, self._translator)
        self.resource_scope_notice.setText("\n".join(filter(None, (
            self._translator.Text_Get("ground.resources_scope"),
            issue_summary if ground.enabled and issues else "",
            issue_details if ground.enabled and issues else ""))))
        self.resource_scope_notice.setProperty("statusLevel", "warning" if ground.enabled and issues else "info")
        led_issues = tuple(issue for issue in issues if issue.code.startswith("GROUND_LED_"))
        self.activity_led_notice.setVisible(bool(led_issues))
        self.activity_led_notice.setText(GroundIssues_PresentationGet(led_issues, self._translator)[1])
        self.activity_led_notice.setToolTip("\n".join(issue.message for issue in led_issues))
        self.activity_led_notice.setProperty("statusLevel", "error" if led_issues else "info")
        for notice in (self.resource_scope_notice, self.activity_led_notice):
            notice.style().unpolish(notice)
            notice.style().polish(notice)
        self.status.setText(self._translator.Text_Get("status.ground_disabled")
                            if not ground.enabled else issue_summary)
        self.status.setToolTip(
            "\n".join(filter(None, (issue_details,
                "\n".join(f"{issue.code}: {issue.message}" for issue in issues),
                self._translator.Text_Get("ground.unused_resources",
                                          resources=", ".join(unused_resources))
                if unused_resources else ""))))
        self.generate_button.setToolTip(self._translator.Text_Get(
            "status.ground_disabled" if not ground.enabled else
            "status.ground_configuration_required" if issues else "status.ground_ready"))
        runtime_pending = any(issue.code in {"GROUND_RADIO_RUNTIME_UNAVAILABLE", "GROUND_LED_RUNTIME_UNAVAILABLE"}
                              for issue in issues)
        multi_pending = len(ground.radio_instances) > 1 and bool(issues)
        self.generate_button.setEnabled(ground.enabled and ground.hardware.mode != "unselected"
                                        and not runtime_pending and not multi_pending)
        self.save_instance.setEnabled(
            ground.hardware.mode == "custom" and bool(ground.hardware.snapshot_id)
            and bool(ground.hardware.build_sources)
        )

    @staticmethod
    def ResourceViews_Get(ground, requirements, issues):
        available = {item.resource_id: item for item in ground.hardware.resources}
        fixed = requirements.get("fixed_resources", {})
        views = []
        for name, kind in requirements.get("resources", ()):
            key = name if ":" in name else f"radio0:{name}"
            assignment = ground.resource_assignments.get(key, "")
            resource = available.get(assignment)
            errors = []
            if ground.enabled:
                if resource is None or resource.kind != kind:
                    errors.append(f"{key}: required {kind} resource is unavailable ({assignment or 'unassigned'})")
                if name in fixed and assignment != fixed[name]:
                    errors.append(f"{key}: Ground PCB fixes this resource to {fixed[name]}")
                errors.extend(issue.message for issue in issues
                              if issue.code in {"GROUND_RADIO_RESOURCE_CONSTRAINT", "GROUND_RESOURCE_CONFLICT"}
                              and re.search(r"(?<![A-Za-z0-9_])" + re.escape(key) + r"(?![A-Za-z0-9_])", issue.message))
            metadata = resource.metadata if resource is not None else {}
            views.append(ResourceRequirementView(
                kind=kind, name=name, key=name, fixed=name in fixed,
                assignment=assignment,
                candidates=tuple(item.resource_id for item in available.values() if item.kind == kind),
                physical_resource=str(metadata.get("physical_resource", metadata.get("physical_pin", ""))),
                validation_error="\n".join(errors)))
        return tuple(views)
