"""Application bootstrap and identity."""

