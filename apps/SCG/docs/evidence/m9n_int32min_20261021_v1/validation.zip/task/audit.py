"""Task-local evidence runner. All outputs stay in this versioned directory."""
from datetime import datetime, timezone
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import shlex
import subprocess
import sys
import time
from unittest.mock import patch

TASK = Path(__file__).resolve().parent
ROOT = TASK.parents[1]
ORIGINAL = ROOT / '.work/dev013_reacq_integration01/offline_acceptance08/eskf_emitted10'
CORE = ROOT / 'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload'
M9 = ROOT / 'apps/SCG/plugins/builtin/silverstar_device_gnss_neo_m9n/payload'
ADAPTER = Path('Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c')


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def write(name, data):
    with (TASK / name).open('x', encoding='utf8') as stream:
        json.dump(data, stream, indent=2)
        stream.write('\n')


def probe(label):
    spec = importlib.util.spec_from_file_location('m9_velocity',
        ROOT / 'apps/SCG/tests/test_neo_m9n_velocity_boundaries.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    raw_run = subprocess.run
    records = []
    for optimization in ['-O0', '-O2']:
        output = TASK / (label + '_' + optimization[1:])
        output.mkdir()

        def run(command, **kwargs):
            command = list(map(str, command))
            if len(command) > 1:
                if label.startswith('before'):
                    command = [str(TASK / 'neo_m9n_system_adapter_before.c')
                        if Path(arg) == M9 / ADAPTER else arg for arg in command]
                if label.endswith('plain'):
                    command.remove('-fsanitize=signed-integer-overflow')
                    command.remove('-fsanitize-undefined-trap-on-error')
                if label.startswith('emitted'):
                    project = TASK / 'emitted'
                    builtin = ROOT / 'apps/SCG/plugins/builtin'
                    rewritten = []
                    for arg in command:
                        if arg.startswith(('-DMISSION_ACTION_OUTPUT_', '-DSYSTEM_INDICATOR_SYSTEM_ENABLE=')):
                            continue
                        prefix = '-I' if arg.startswith('-I') else ''
                        path = Path(arg[len(prefix):])
                        if path.is_relative_to(builtin) and 'payload' in path.parts:
                            relative = Path(*path.parts[path.parts.index('payload') + 1:])
                            if relative.is_relative_to('Tests/Host/Fixtures/MultiInstance'):
                                rewritten.append(arg)
                                continue
                            arg = prefix + str(project / relative)
                        rewritten.append(arg)
                    command = [*rewritten, '-I' + str(project / 'Platform/STM32F4/Inc'), '-include',
                        str(project / 'Generated/Inc/project_flight_config.h')]
            start = time.monotonic()
            result = raw_run(command, **kwargs)
            records.append(dict(command=command, exit_code=result.returncode,
                stdout=result.stdout, stderr=result.stderr,
                elapsed_seconds=time.monotonic() - start,
                input_sha256={str(Path(arg).relative_to(ROOT)): digest(Path(arg))
                    for arg in command if Path(arg).is_file() and Path(arg).is_relative_to(ROOT)}))
            return result

        failure = ''
        with patch.object(module.subprocess, 'run', run):
            try:
                module.test_neo_m9n_velocity_boundaries(output, optimization)
            except AssertionError as error:
                failure = 'AssertionError: ' + str(error)
        records.append(dict(optimization=optimization, assertion=failure))
        print(label, optimization, 'FAIL' if failure else 'PASS', flush=True)
    write(label + '.json', dict(utc=datetime.now(timezone.utc).isoformat(), runs=records))


def generate():
    sys.path.insert(0, str(ROOT / 'apps/SCG/src'))
    from silverstar_fccg.app.service import FccgService
    service = FccgService(ROOT / 'apps/SCG')
    model = service.Project_Open(ORIGINAL / 'SilverStar.ssproject')
    model.component_provenance = {}
    target = TASK / 'emitted'
    assert not target.exists()
    service.Project_Save(model, target, confirm_dangerous=True)
    assert (target / ADAPTER).read_bytes() == (M9 / ADAPTER).read_bytes()
    assert (target / 'Tests/Host/test_neo_m9n_adapter.c').read_bytes() == (
        CORE / 'Tests/Host/test_neo_m9n_adapter.c').read_bytes()
    write('generation.json', dict(utc=datetime.now(timezone.utc).isoformat(),
        model=str(ORIGINAL / 'SilverStar.ssproject'), model_sha256=digest(ORIGINAL / 'SilverStar.ssproject'),
        source_head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        source_status=subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=ROOT, text=True),
        inputs={str(path.relative_to(ROOT)): digest(path)
            for folder in ['apps/SCG/src', 'apps/SCG/plugins/builtin', 'contracts']
            for path in (ROOT / folder).rglob('*')
            if path.is_file() and path.suffix in {'.py', '.c', '.h', '.json', '.mk', '.j2', '.ps1', '.s', '.ld'}},
        emitted={str(path.relative_to(target)): digest(path)
            for path in target.rglob('*') if path.is_file()}))
    print('Fresh emission verified', flush=True)


def gates(actions):
    project = TASK / 'emitted'
    for action in actions:
        command = ['mingw32-make', '-j2', 'TARGET_PROFILE=SilverStar_F407',
            'CONFIG=Release', 'MEMORY_LAYOUT=auto', action]
        start = time.monotonic()
        log = TASK / (action + '.log')
        with log.open('x', encoding='utf8') as output:
            result = subprocess.run(command, cwd=project,
                stdout=output, stderr=subprocess.STDOUT, text=True)
        write(action + '.json', dict(command=command, cwd=str(project),
            utc=datetime.now(timezone.utc).isoformat(), exit_code=result.returncode,
            elapsed_seconds=time.monotonic() - start, log_sha256=digest(log),
            artifacts={str(path.relative_to(project)): digest(path)
                for path in (project / 'build').rglob('*')
                if path.is_file() and path.suffix in {'.elf', '.bin', '.map', '.json', '.su'}},
            versions={tool: subprocess.check_output([tool, '--version'], text=True)
                for tool in ['mingw32-make', 'arm-none-eabi-gcc', 'gcc', 'python']}))
        print(action, 'exit', result.returncode, flush=True)


def arm_compare():
    project = TASK / 'emitted'
    line = next(line for line in (TASK / 'all.log').read_text().splitlines()
        if line.startswith('arm-none-eabi-gcc -c ') and
        (' ' + ADAPTER.as_posix() + ' -o ') in line)
    original = shlex.split(line)
    before = list(original)
    before[before.index(ADAPTER.as_posix())] = str(TASK / 'neo_m9n_system_adapter_before.c')
    before[before.index('-o') + 1] = str(TASK / 'arm_before.o')
    before = ['-MF' + str(TASK / 'arm_before.d') if arg.startswith('-MF') else arg
        for arg in before]
    commands = []
    for command in [before]:
        result = subprocess.run(command, cwd=project, capture_output=True, text=True)
        commands.append(dict(command=command, exit_code=result.returncode,
            stdout=result.stdout, stderr=result.stderr))
        assert result.returncode == 0
    after_object = project / 'build/FCCG/SilverStar_F407/Release/auto' / ADAPTER.with_suffix('.o')
    for label, obj in [('before', TASK / 'arm_before.o'), ('after', after_object)]:
        command = ['arm-none-eabi-objdump', '-dr',
            '--disassemble=NeoM9nGnssInstance_LatestSampleGet', str(obj)]
        result = subprocess.run(command, capture_output=True, text=True)
        commands.append(dict(command=command, exit_code=result.returncode,
            stdout=result.stdout, stderr=result.stderr))
        (TASK / ('arm_' + label + '.disasm.txt')).write_text(result.stdout)
        assert result.returncode == 0
    preprocessor = [arg for arg in original if not arg.startswith('-MF')]
    preprocessor[preprocessor.index('-c')] = '-E'
    preprocessor[preprocessor.index('-o') + 1] = str(TASK / 'arm_after.i')
    preprocessor[1:1] = ['-dD', '-MF' + str(TASK / 'arm_after.d')]
    result = subprocess.run(preprocessor, cwd=project, capture_output=True, text=True)
    commands.append(dict(command=preprocessor, exit_code=result.returncode,
        stdout=result.stdout, stderr=result.stderr))
    assert result.returncode == 0
    write('arm_compare.json', dict(cwd=str(project), commands=commands,
        before_stack=(TASK / 'arm_before.su').read_text(),
        after_stack=after_object.with_suffix('.su').read_text(),
        hashes={str(p.relative_to(ROOT)): digest(p) for p in
            [TASK / 'arm_before.o', after_object, TASK / 'arm_after.i']}))


def protocol():
    records = []
    raw_run = subprocess.run
    def run(command, **kwargs):
        result = raw_run(command, **kwargs)
        records.append(dict(command=list(map(str, command)),
            exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr))
        return result
    spec = importlib.util.spec_from_file_location('m9_startup', ROOT / 'apps/SCG/tests/test_neo_m9n_startup.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    output = TASK / 'protocol'
    output.mkdir()
    with patch.object(module.subprocess, 'run', run):
        module.test_neo_m9n_startup(output)
    command = json.loads((TASK / 'after_sanitizer.json').read_text())['runs'][0]['command']
    command = [arg for arg in command if not arg.endswith('.c')]
    command[command.index('-o') + 1] = str(output / 'multi_instance.exe')
    command += list(map(str, [CORE / 'Tests/Host/test_neo_m9n_multi_instance.c',
        CORE / 'Common/Src/silverstar_assert.c',
        CORE / 'Tests/Host/Fixtures/MultiInstance/multi_instance_resources.c',
        M9 / 'Devices/GNSS/NEO_M9N/Src/neo_m9n_device.c']))
    result = run(command, capture_output=True, text=True, timeout=120)
    assert result.returncode == 0, result.stderr
    result = run([output / 'multi_instance.exe'], capture_output=True, text=True, timeout=30)
    write('protocol.json', dict(commands=records))
    assert result.returncode == 0, result.stdout + result.stderr
    print('Protocol/startup and multi-instance PASS')


if sys.argv[1] == 'generate':
    generate()
elif sys.argv[1] == 'gates':
    gates(sys.argv[2:])
elif sys.argv[1] == 'arm_compare':
    arm_compare()
elif sys.argv[1] == 'protocol':
    protocol()
else:
    probe(sys.argv[1])
