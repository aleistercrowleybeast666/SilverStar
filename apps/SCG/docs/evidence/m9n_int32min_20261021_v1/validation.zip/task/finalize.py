"""Retain task evidence; never delete or modify the original candidate."""
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import zipfile

TASK = Path(__file__).resolve().parent
ROOT = TASK.parents[1]
PROJECT = TASK / 'emitted'
DEST = ROOT / 'apps/SCG/docs/evidence/m9n_int32min_20261021_v1'
ADAPTER = Path('Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c')
ORIGINAL = ROOT / '.work/dev013_reacq_integration01/offline_acceptance08/eskf_emitted10'
OWNER = ROOT / 'apps/SCG/plugins/builtin/silverstar_device_gnss_neo_m9n/payload' / ADAPTER
CORE = ROOT / 'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload'
TEST = CORE / 'Tests/Host/test_neo_m9n_adapter.c'
PYTEST = ROOT / 'apps/SCG/tests/test_neo_m9n_velocity_boundaries.py'


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def write(path, data):
    with path.open('x', encoding='utf8') as stream:
        json.dump(data, stream, indent=2)
        stream.write('\n')


assert digest(ORIGINAL / ADAPTER) == digest(TASK / 'neo_m9n_system_adapter_before.c')
assert digest(PROJECT / ADAPTER) == digest(OWNER)
assert digest(PROJECT / 'Tests/Host/test_neo_m9n_adapter.c') == digest(TEST)
assert (TASK / 'final_pytest.exit').read_text().strip() == '0'
assert (TASK / 'ruff02.exit').read_text().strip() == '0'
expected_gates = {'all': 0, 'static-analysis': 0, 'artifact-check': 0,
    'architecture-check': 0, 'power10-check': 0, 'host-tests': 2, 'stack-report': 2}
for action, code in expected_gates.items():
    assert json.loads((TASK / (action + '.json')).read_text())['exit_code'] == code
for label in ['before_plain', 'before_sanitizer02']:
    runs = json.loads((TASK / (label + '.json')).read_text())['runs']
    assert [r['exit_code'] for r in runs if 'exit_code' in r][::2] == [0, 0]
    assert all(r['exit_code'] != 0 for r in runs if 'exit_code' in r and len(r['command']) == 1)
for label in ['after_plain', 'after_sanitizer', 'emitted_sanitizer03']:
    assert all(r['exit_code'] == 0 for r in json.loads((TASK / (label + '.json')).read_text())['runs'] if 'exit_code' in r)

subprocess.run(['git', 'diff', '--binary', '--output=' + str(TASK / 'dirty_tracked.patch')], cwd=ROOT, check=True, capture_output=True)
sources = []
for line in (PROJECT / 'Generated/project_sources.mk').read_text().splitlines():
    source = line.strip().rstrip('\\').strip()
    if source.endswith('.c') and (PROJECT / source).is_file():
        sources.append(source)
vendor = [p for p in sources if p.startswith(('Drivers/', 'ThirdParty/', 'Middlewares/'))]
write(TASK / 'third_party.json', dict(
    linked_graph_sources={p: digest(PROJECT / p) for p in vendor},
    provenance={'HAL': 'STM32F4 HAL 1.8.5; source header / STM32Cube F4 1.28.3 import',
        'FreeRTOS': '11.3.0; MIT; fixed static task entry pointers retained',
        'FatFs': 'R0.12c; ChaN license retained',
        'SX1280': 'Semtech driver reference; Revised BSD; no invented release tag',
        'CMSIS': 'MCU payload provenance and retained license; no version claim inferred'},
    controlled_exceptions='Existing third-party exclusion, fixed xTaskCreateStatic entry pointers, named permanent loops and existing platform policies only. No exception added.',
    consequences='Vendor callbacks/indirect calls and library stack/timing/recursion remain outside the first-party text gate. Whole-program stack gate failed; ISR/MSP, WCET and hardware safety remain NOT PROVEN.'))
write(TASK / 'INVENTORY.json', dict(
    owner='M9N INT32_MIN专项 / 2026-10-21 / current Codex task',
    purpose='One fresh generated project, host boundary/protocol executables, actual ARM build/analyzer outputs and complete evidence; no cleanup performed or authorized.',
    retained_original=str(ORIGINAL), protected_sha256={str(ORIGINAL / ADAPTER): digest(ORIGINAL / ADAPTER)},
    retained_evidence=str(DEST),
    files={str(p.relative_to(TASK)): dict(sha256=digest(p), bytes=p.stat().st_size,
        purpose='generated task output; retain for audit') for p in TASK.rglob('*') if p.is_file()}))

DEST.mkdir(parents=True, exist_ok=False)
members = {}
with zipfile.ZipFile(DEST / 'validation.zip', 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    def add(path, name):
        if name not in members:
            archive.write(path, name)
            members[name] = digest(path)
    for path in TASK.iterdir():
        if path.is_file():
            add(path, 'task/' + path.name)
    for path in [OWNER, TEST, PYTEST]:
        add(path, 'source/' + path.relative_to(ROOT).as_posix())
    # The first-party generated snapshot is the auditable dirty compilation input.
    # Vendor SDK bytes remain in the single retained generated project, with hashes.
    for path in PROJECT.rglob('*'):
        if not path.is_file():
            continue
        rel = path.relative_to(PROJECT)
        if rel.parts[0] in {'build', 'Drivers', 'ThirdParty', 'Middlewares', '.fccg'}:
            if path.name.lower().startswith('license'):
                add(path, 'emitted/' + rel.as_posix())
            continue
        if path.suffix.lower() in {'.c', '.h', '.py', '.ps1', '.mk', '.ld', '.s', '.ssproject'} or path.name == 'Makefile':
            add(path, 'emitted/' + rel.as_posix())
    release = PROJECT / 'build/FCCG/SilverStar_F407/Release/auto'
    for path in release.rglob('*'):
        if path.is_file() and path.suffix in {'.elf', '.bin', '.map', '.su'}:
            add(path, 'release/' + path.relative_to(release).as_posix())
    detail = PROJECT / 'build/FCCG/Host/Tests/host-tests-detail.log'
    if detail.is_file():
        add(detail, 'task/host-tests-detail.log')
write(DEST / 'results.json', dict(
    date_local='2026-10-21 Asia/Shanghai', utc=datetime.now(timezone.utc).isoformat(),
    base_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    tested_scope='Auditable dirty generated snapshot, not a clean checkout or full firmware acceptance.',
    fix='Cast velD to float before unary negation; all int32 wire values remain convertible and finite.',
    pre_fix={'plain_O0_O2': 'exit 1; each 8340 checks / 3 failures; INT32_MIN wrong negative Up',
        'signed_overflow_sanitizer_O0_O2': 'exit 3221225501 (0xC000001D); trap at INT32_MIN'},
    post_fix={'owner_plain_and_sanitizer_O0_O2': '8340 checks / 0 failures each',
        'fresh_emitted_sanitizer_O0_O2': '8340 checks / 0 failures each; existing MultiInstance resource fixture explicitly used',
        'protocol_startup': '25600 checks / 0 failures', 'multi_instance': '42 checks / 0 failures',
        'pytest': '3 passed', 'ruff': 'passed', 'arm_frame_bytes_before_after': [120, 120]},
    gates=expected_gates,
    blockers={'host-tests': 'capability_jy901b_gravity_mag_rejected also has undeclared generated magnetic profile override errors; suite stopped early.',
        'stack-report': 'Changed or missing reviewed callback compilation input: Generated/Inc/project_flight_config.h',
        'power10': 'Text checks exit 0; critical-contract review remains NOT PROVEN; 970 nonblocking assertion recommendations.'},
    retained_project=str(PROJECT), original_candidate_unchanged=True,
    validation_zip_sha256=digest(DEST / 'validation.zip'), member_sha256=members))
print('Retained', len(members), 'evidence members;', (DEST / 'validation.zip').stat().st_size, 'bytes')
