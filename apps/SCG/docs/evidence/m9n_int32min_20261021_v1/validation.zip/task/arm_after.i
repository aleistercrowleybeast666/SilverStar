# 0 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
# 1 "D:\\python_software\\SilverStar\\.work\\dev013_m9n_int32min_20261021_v1\\emitted//"
# 0 "<built-in>"
#define __STDC__ 1
# 0 "<built-in>"
#define __STDC_VERSION__ 201112L
# 0 "<built-in>"
#define __STDC_UTF_16__ 1
# 0 "<built-in>"
#define __STDC_UTF_32__ 1
# 0 "<built-in>"
#define __STDC_HOSTED__ 1
# 0 "<built-in>"
#define __GNUC__ 14
# 0 "<built-in>"
#define __GNUC_MINOR__ 3
# 0 "<built-in>"
#define __GNUC_PATCHLEVEL__ 1
# 0 "<built-in>"
#define __VERSION__ "14.3.1 20250623"
# 0 "<built-in>"
#define __ATOMIC_RELAXED 0
# 0 "<built-in>"
#define __ATOMIC_SEQ_CST 5
# 0 "<built-in>"
#define __ATOMIC_ACQUIRE 2
# 0 "<built-in>"
#define __ATOMIC_RELEASE 3
# 0 "<built-in>"
#define __ATOMIC_ACQ_REL 4
# 0 "<built-in>"
#define __ATOMIC_CONSUME 1
# 0 "<built-in>"
#define __OPTIMIZE__ 1
# 0 "<built-in>"
#define __FINITE_MATH_ONLY__ 0
# 0 "<built-in>"
#define __SIZEOF_INT__ 4
# 0 "<built-in>"
#define __SIZEOF_LONG__ 4
# 0 "<built-in>"
#define __SIZEOF_LONG_LONG__ 8
# 0 "<built-in>"
#define __SIZEOF_SHORT__ 2
# 0 "<built-in>"
#define __SIZEOF_FLOAT__ 4
# 0 "<built-in>"
#define __SIZEOF_DOUBLE__ 8
# 0 "<built-in>"
#define __SIZEOF_LONG_DOUBLE__ 8
# 0 "<built-in>"
#define __SIZEOF_SIZE_T__ 4
# 0 "<built-in>"
#define __CHAR_BIT__ 8
# 0 "<built-in>"
#define __BIGGEST_ALIGNMENT__ 8
# 0 "<built-in>"
#define __ORDER_LITTLE_ENDIAN__ 1234
# 0 "<built-in>"
#define __ORDER_BIG_ENDIAN__ 4321
# 0 "<built-in>"
#define __ORDER_PDP_ENDIAN__ 3412
# 0 "<built-in>"
#define __BYTE_ORDER__ __ORDER_LITTLE_ENDIAN__
# 0 "<built-in>"
#define __FLOAT_WORD_ORDER__ __ORDER_LITTLE_ENDIAN__
# 0 "<built-in>"
#define __SIZEOF_POINTER__ 4
# 0 "<built-in>"
#define __GNUC_EXECUTION_CHARSET_NAME "UTF-8"
# 0 "<built-in>"
#define __GNUC_WIDE_EXECUTION_CHARSET_NAME "UTF-32LE"
# 0 "<built-in>"
#define __SIZE_TYPE__ unsigned int
# 0 "<built-in>"
#define __PTRDIFF_TYPE__ int
# 0 "<built-in>"
#define __WCHAR_TYPE__ unsigned int
# 0 "<built-in>"
#define __WINT_TYPE__ unsigned int
# 0 "<built-in>"
#define __INTMAX_TYPE__ long long int
# 0 "<built-in>"
#define __UINTMAX_TYPE__ long long unsigned int
# 0 "<built-in>"
#define __CHAR16_TYPE__ short unsigned int
# 0 "<built-in>"
#define __CHAR32_TYPE__ long unsigned int
# 0 "<built-in>"
#define __SIG_ATOMIC_TYPE__ int
# 0 "<built-in>"
#define __INT8_TYPE__ signed char
# 0 "<built-in>"
#define __INT16_TYPE__ short int
# 0 "<built-in>"
#define __INT32_TYPE__ long int
# 0 "<built-in>"
#define __INT64_TYPE__ long long int
# 0 "<built-in>"
#define __UINT8_TYPE__ unsigned char
# 0 "<built-in>"
#define __UINT16_TYPE__ short unsigned int
# 0 "<built-in>"
#define __UINT32_TYPE__ long unsigned int
# 0 "<built-in>"
#define __UINT64_TYPE__ long long unsigned int
# 0 "<built-in>"
#define __INT_LEAST8_TYPE__ signed char
# 0 "<built-in>"
#define __INT_LEAST16_TYPE__ short int
# 0 "<built-in>"
#define __INT_LEAST32_TYPE__ long int
# 0 "<built-in>"
#define __INT_LEAST64_TYPE__ long long int
# 0 "<built-in>"
#define __UINT_LEAST8_TYPE__ unsigned char
# 0 "<built-in>"
#define __UINT_LEAST16_TYPE__ short unsigned int
# 0 "<built-in>"
#define __UINT_LEAST32_TYPE__ long unsigned int
# 0 "<built-in>"
#define __UINT_LEAST64_TYPE__ long long unsigned int
# 0 "<built-in>"
#define __INT_FAST8_TYPE__ int
# 0 "<built-in>"
#define __INT_FAST16_TYPE__ int
# 0 "<built-in>"
#define __INT_FAST32_TYPE__ int
# 0 "<built-in>"
#define __INT_FAST64_TYPE__ long long int
# 0 "<built-in>"
#define __UINT_FAST8_TYPE__ unsigned int
# 0 "<built-in>"
#define __UINT_FAST16_TYPE__ unsigned int
# 0 "<built-in>"
#define __UINT_FAST32_TYPE__ unsigned int
# 0 "<built-in>"
#define __UINT_FAST64_TYPE__ long long unsigned int
# 0 "<built-in>"
#define __INTPTR_TYPE__ int
# 0 "<built-in>"
#define __UINTPTR_TYPE__ unsigned int
# 0 "<built-in>"
#define __GXX_ABI_VERSION 1019
# 0 "<built-in>"
#define __SCHAR_MAX__ 0x7f
# 0 "<built-in>"
#define __SHRT_MAX__ 0x7fff
# 0 "<built-in>"
#define __INT_MAX__ 0x7fffffff
# 0 "<built-in>"
#define __LONG_MAX__ 0x7fffffffL
# 0 "<built-in>"
#define __LONG_LONG_MAX__ 0x7fffffffffffffffLL
# 0 "<built-in>"
#define __WCHAR_MAX__ 0xffffffffU
# 0 "<built-in>"
#define __WCHAR_MIN__ 0U
# 0 "<built-in>"
#define __WINT_MAX__ 0xffffffffU
# 0 "<built-in>"
#define __WINT_MIN__ 0U
# 0 "<built-in>"
#define __PTRDIFF_MAX__ 0x7fffffff
# 0 "<built-in>"
#define __SIZE_MAX__ 0xffffffffU
# 0 "<built-in>"
#define __SCHAR_WIDTH__ 8
# 0 "<built-in>"
#define __SHRT_WIDTH__ 16
# 0 "<built-in>"
#define __INT_WIDTH__ 32
# 0 "<built-in>"
#define __LONG_WIDTH__ 32
# 0 "<built-in>"
#define __LONG_LONG_WIDTH__ 64
# 0 "<built-in>"
#define __WCHAR_WIDTH__ 32
# 0 "<built-in>"
#define __WINT_WIDTH__ 32
# 0 "<built-in>"
#define __PTRDIFF_WIDTH__ 32
# 0 "<built-in>"
#define __SIZE_WIDTH__ 32
# 0 "<built-in>"
#define __INTMAX_MAX__ 0x7fffffffffffffffLL
# 0 "<built-in>"
#define __INTMAX_C(c) c ## LL
# 0 "<built-in>"
#define __UINTMAX_MAX__ 0xffffffffffffffffULL
# 0 "<built-in>"
#define __UINTMAX_C(c) c ## ULL
# 0 "<built-in>"
#define __INTMAX_WIDTH__ 64
# 0 "<built-in>"
#define __SIG_ATOMIC_MAX__ 0x7fffffff
# 0 "<built-in>"
#define __SIG_ATOMIC_MIN__ (-__SIG_ATOMIC_MAX__ - 1)
# 0 "<built-in>"
#define __SIG_ATOMIC_WIDTH__ 32
# 0 "<built-in>"
#define __INT8_MAX__ 0x7f
# 0 "<built-in>"
#define __INT16_MAX__ 0x7fff
# 0 "<built-in>"
#define __INT32_MAX__ 0x7fffffffL
# 0 "<built-in>"
#define __INT64_MAX__ 0x7fffffffffffffffLL
# 0 "<built-in>"
#define __UINT8_MAX__ 0xff
# 0 "<built-in>"
#define __UINT16_MAX__ 0xffff
# 0 "<built-in>"
#define __UINT32_MAX__ 0xffffffffUL
# 0 "<built-in>"
#define __UINT64_MAX__ 0xffffffffffffffffULL
# 0 "<built-in>"
#define __INT_LEAST8_MAX__ 0x7f
# 0 "<built-in>"
#define __INT8_C(c) c
# 0 "<built-in>"
#define __INT_LEAST8_WIDTH__ 8
# 0 "<built-in>"
#define __INT_LEAST16_MAX__ 0x7fff
# 0 "<built-in>"
#define __INT16_C(c) c
# 0 "<built-in>"
#define __INT_LEAST16_WIDTH__ 16
# 0 "<built-in>"
#define __INT_LEAST32_MAX__ 0x7fffffffL
# 0 "<built-in>"
#define __INT32_C(c) c ## L
# 0 "<built-in>"
#define __INT_LEAST32_WIDTH__ 32
# 0 "<built-in>"
#define __INT_LEAST64_MAX__ 0x7fffffffffffffffLL
# 0 "<built-in>"
#define __INT64_C(c) c ## LL
# 0 "<built-in>"
#define __INT_LEAST64_WIDTH__ 64
# 0 "<built-in>"
#define __UINT_LEAST8_MAX__ 0xff
# 0 "<built-in>"
#define __UINT8_C(c) c
# 0 "<built-in>"
#define __UINT_LEAST16_MAX__ 0xffff
# 0 "<built-in>"
#define __UINT16_C(c) c
# 0 "<built-in>"
#define __UINT_LEAST32_MAX__ 0xffffffffUL
# 0 "<built-in>"
#define __UINT32_C(c) c ## UL
# 0 "<built-in>"
#define __UINT_LEAST64_MAX__ 0xffffffffffffffffULL
# 0 "<built-in>"
#define __UINT64_C(c) c ## ULL
# 0 "<built-in>"
#define __INT_FAST8_MAX__ 0x7fffffff
# 0 "<built-in>"
#define __INT_FAST8_WIDTH__ 32
# 0 "<built-in>"
#define __INT_FAST16_MAX__ 0x7fffffff
# 0 "<built-in>"
#define __INT_FAST16_WIDTH__ 32
# 0 "<built-in>"
#define __INT_FAST32_MAX__ 0x7fffffff
# 0 "<built-in>"
#define __INT_FAST32_WIDTH__ 32
# 0 "<built-in>"
#define __INT_FAST64_MAX__ 0x7fffffffffffffffLL
# 0 "<built-in>"
#define __INT_FAST64_WIDTH__ 64
# 0 "<built-in>"
#define __UINT_FAST8_MAX__ 0xffffffffU
# 0 "<built-in>"
#define __UINT_FAST16_MAX__ 0xffffffffU
# 0 "<built-in>"
#define __UINT_FAST32_MAX__ 0xffffffffU
# 0 "<built-in>"
#define __UINT_FAST64_MAX__ 0xffffffffffffffffULL
# 0 "<built-in>"
#define __INTPTR_MAX__ 0x7fffffff
# 0 "<built-in>"
#define __INTPTR_WIDTH__ 32
# 0 "<built-in>"
#define __UINTPTR_MAX__ 0xffffffffU
# 0 "<built-in>"
#define __GCC_IEC_559 0
# 0 "<built-in>"
#define __GCC_IEC_559_COMPLEX 0
# 0 "<built-in>"
#define __FLT_EVAL_METHOD__ 0
# 0 "<built-in>"
#define __FLT_EVAL_METHOD_TS_18661_3__ 0
# 0 "<built-in>"
#define __DEC_EVAL_METHOD__ 2
# 0 "<built-in>"
#define __FLT_RADIX__ 2
# 0 "<built-in>"
#define __FLT_MANT_DIG__ 24
# 0 "<built-in>"
#define __FLT_DIG__ 6
# 0 "<built-in>"
#define __FLT_MIN_EXP__ (-125)
# 0 "<built-in>"
#define __FLT_MIN_10_EXP__ (-37)
# 0 "<built-in>"
#define __FLT_MAX_EXP__ 128
# 0 "<built-in>"
#define __FLT_MAX_10_EXP__ 38
# 0 "<built-in>"
#define __FLT_DECIMAL_DIG__ 9
# 0 "<built-in>"
#define __FLT_MAX__ 3.4028234663852886e+38F
# 0 "<built-in>"
#define __FLT_NORM_MAX__ 3.4028234663852886e+38F
# 0 "<built-in>"
#define __FLT_MIN__ 1.1754943508222875e-38F
# 0 "<built-in>"
#define __FLT_EPSILON__ 1.1920928955078125e-7F
# 0 "<built-in>"
#define __FLT_DENORM_MIN__ 1.4012984643248171e-45F
# 0 "<built-in>"
#define __FLT_HAS_DENORM__ 1
# 0 "<built-in>"
#define __FLT_HAS_INFINITY__ 1
# 0 "<built-in>"
#define __FLT_HAS_QUIET_NAN__ 1
# 0 "<built-in>"
#define __FP_FAST_FMAF 1
# 0 "<built-in>"
#define __FLT_IS_IEC_60559__ 1
# 0 "<built-in>"
#define __DBL_MANT_DIG__ 53
# 0 "<built-in>"
#define __DBL_DIG__ 15
# 0 "<built-in>"
#define __DBL_MIN_EXP__ (-1021)
# 0 "<built-in>"
#define __DBL_MIN_10_EXP__ (-307)
# 0 "<built-in>"
#define __DBL_MAX_EXP__ 1024
# 0 "<built-in>"
#define __DBL_MAX_10_EXP__ 308
# 0 "<built-in>"
#define __DBL_DECIMAL_DIG__ 17
# 0 "<built-in>"
#define __DBL_MAX__ ((double)1.7976931348623157e+308L)
# 0 "<built-in>"
#define __DBL_NORM_MAX__ ((double)1.7976931348623157e+308L)
# 0 "<built-in>"
#define __DBL_MIN__ ((double)2.2250738585072014e-308L)
# 0 "<built-in>"
#define __DBL_EPSILON__ ((double)2.2204460492503131e-16L)
# 0 "<built-in>"
#define __DBL_DENORM_MIN__ ((double)4.9406564584124654e-324L)
# 0 "<built-in>"
#define __DBL_HAS_DENORM__ 1
# 0 "<built-in>"
#define __DBL_HAS_INFINITY__ 1
# 0 "<built-in>"
#define __DBL_HAS_QUIET_NAN__ 1
# 0 "<built-in>"
#define __DBL_IS_IEC_60559__ 1
# 0 "<built-in>"
#define __LDBL_MANT_DIG__ 53
# 0 "<built-in>"
#define __LDBL_DIG__ 15
# 0 "<built-in>"
#define __LDBL_MIN_EXP__ (-1021)
# 0 "<built-in>"
#define __LDBL_MIN_10_EXP__ (-307)
# 0 "<built-in>"
#define __LDBL_MAX_EXP__ 1024
# 0 "<built-in>"
#define __LDBL_MAX_10_EXP__ 308
# 0 "<built-in>"
#define __DECIMAL_DIG__ 17
# 0 "<built-in>"
#define __LDBL_DECIMAL_DIG__ 17
# 0 "<built-in>"
#define __LDBL_MAX__ 1.7976931348623157e+308L
# 0 "<built-in>"
#define __LDBL_NORM_MAX__ 1.7976931348623157e+308L
# 0 "<built-in>"
#define __LDBL_MIN__ 2.2250738585072014e-308L
# 0 "<built-in>"
#define __LDBL_EPSILON__ 2.2204460492503131e-16L
# 0 "<built-in>"
#define __LDBL_DENORM_MIN__ 4.9406564584124654e-324L
# 0 "<built-in>"
#define __LDBL_HAS_DENORM__ 1
# 0 "<built-in>"
#define __LDBL_HAS_INFINITY__ 1
# 0 "<built-in>"
#define __LDBL_HAS_QUIET_NAN__ 1
# 0 "<built-in>"
#define __LDBL_IS_IEC_60559__ 1
# 0 "<built-in>"
#define __FLT32_MANT_DIG__ 24
# 0 "<built-in>"
#define __FLT32_DIG__ 6
# 0 "<built-in>"
#define __FLT32_MIN_EXP__ (-125)
# 0 "<built-in>"
#define __FLT32_MIN_10_EXP__ (-37)
# 0 "<built-in>"
#define __FLT32_MAX_EXP__ 128
# 0 "<built-in>"
#define __FLT32_MAX_10_EXP__ 38
# 0 "<built-in>"
#define __FLT32_DECIMAL_DIG__ 9
# 0 "<built-in>"
#define __FLT32_MAX__ 3.4028234663852886e+38F32
# 0 "<built-in>"
#define __FLT32_NORM_MAX__ 3.4028234663852886e+38F32
# 0 "<built-in>"
#define __FLT32_MIN__ 1.1754943508222875e-38F32
# 0 "<built-in>"
#define __FLT32_EPSILON__ 1.1920928955078125e-7F32
# 0 "<built-in>"
#define __FLT32_DENORM_MIN__ 1.4012984643248171e-45F32
# 0 "<built-in>"
#define __FLT32_HAS_DENORM__ 1
# 0 "<built-in>"
#define __FLT32_HAS_INFINITY__ 1
# 0 "<built-in>"
#define __FLT32_HAS_QUIET_NAN__ 1
# 0 "<built-in>"
#define __FP_FAST_FMAF32 1
# 0 "<built-in>"
#define __FLT32_IS_IEC_60559__ 1
# 0 "<built-in>"
#define __FLT64_MANT_DIG__ 53
# 0 "<built-in>"
#define __FLT64_DIG__ 15
# 0 "<built-in>"
#define __FLT64_MIN_EXP__ (-1021)
# 0 "<built-in>"
#define __FLT64_MIN_10_EXP__ (-307)
# 0 "<built-in>"
#define __FLT64_MAX_EXP__ 1024
# 0 "<built-in>"
#define __FLT64_MAX_10_EXP__ 308
# 0 "<built-in>"
#define __FLT64_DECIMAL_DIG__ 17
# 0 "<built-in>"
#define __FLT64_MAX__ 1.7976931348623157e+308F64
# 0 "<built-in>"
#define __FLT64_NORM_MAX__ 1.7976931348623157e+308F64
# 0 "<built-in>"
#define __FLT64_MIN__ 2.2250738585072014e-308F64
# 0 "<built-in>"
#define __FLT64_EPSILON__ 2.2204460492503131e-16F64
# 0 "<built-in>"
#define __FLT64_DENORM_MIN__ 4.9406564584124654e-324F64
# 0 "<built-in>"
#define __FLT64_HAS_DENORM__ 1
# 0 "<built-in>"
#define __FLT64_HAS_INFINITY__ 1
# 0 "<built-in>"
#define __FLT64_HAS_QUIET_NAN__ 1
# 0 "<built-in>"
#define __FLT64_IS_IEC_60559__ 1
# 0 "<built-in>"
#define __FLT32X_MANT_DIG__ 53
# 0 "<built-in>"
#define __FLT32X_DIG__ 15
# 0 "<built-in>"
#define __FLT32X_MIN_EXP__ (-1021)
# 0 "<built-in>"
#define __FLT32X_MIN_10_EXP__ (-307)
# 0 "<built-in>"
#define __FLT32X_MAX_EXP__ 1024
# 0 "<built-in>"
#define __FLT32X_MAX_10_EXP__ 308
# 0 "<built-in>"
#define __FLT32X_DECIMAL_DIG__ 17
# 0 "<built-in>"
#define __FLT32X_MAX__ 1.7976931348623157e+308F32x
# 0 "<built-in>"
#define __FLT32X_NORM_MAX__ 1.7976931348623157e+308F32x
# 0 "<built-in>"
#define __FLT32X_MIN__ 2.2250738585072014e-308F32x
# 0 "<built-in>"
#define __FLT32X_EPSILON__ 2.2204460492503131e-16F32x
# 0 "<built-in>"
#define __FLT32X_DENORM_MIN__ 4.9406564584124654e-324F32x
# 0 "<built-in>"
#define __FLT32X_HAS_DENORM__ 1
# 0 "<built-in>"
#define __FLT32X_HAS_INFINITY__ 1
# 0 "<built-in>"
#define __FLT32X_HAS_QUIET_NAN__ 1
# 0 "<built-in>"
#define __FLT32X_IS_IEC_60559__ 1
# 0 "<built-in>"
#define __SFRACT_FBIT__ 7
# 0 "<built-in>"
#define __SFRACT_IBIT__ 0
# 0 "<built-in>"
#define __SFRACT_MIN__ (-0.5HR-0.5HR)
# 0 "<built-in>"
#define __SFRACT_MAX__ 0X7FP-7HR
# 0 "<built-in>"
#define __SFRACT_EPSILON__ 0x1P-7HR
# 0 "<built-in>"
#define __USFRACT_FBIT__ 8
# 0 "<built-in>"
#define __USFRACT_IBIT__ 0
# 0 "<built-in>"
#define __USFRACT_MIN__ 0.0UHR
# 0 "<built-in>"
#define __USFRACT_MAX__ 0XFFP-8UHR
# 0 "<built-in>"
#define __USFRACT_EPSILON__ 0x1P-8UHR
# 0 "<built-in>"
#define __FRACT_FBIT__ 15
# 0 "<built-in>"
#define __FRACT_IBIT__ 0
# 0 "<built-in>"
#define __FRACT_MIN__ (-0.5R-0.5R)
# 0 "<built-in>"
#define __FRACT_MAX__ 0X7FFFP-15R
# 0 "<built-in>"
#define __FRACT_EPSILON__ 0x1P-15R
# 0 "<built-in>"
#define __UFRACT_FBIT__ 16
# 0 "<built-in>"
#define __UFRACT_IBIT__ 0
# 0 "<built-in>"
#define __UFRACT_MIN__ 0.0UR
# 0 "<built-in>"
#define __UFRACT_MAX__ 0XFFFFP-16UR
# 0 "<built-in>"
#define __UFRACT_EPSILON__ 0x1P-16UR
# 0 "<built-in>"
#define __LFRACT_FBIT__ 31
# 0 "<built-in>"
#define __LFRACT_IBIT__ 0
# 0 "<built-in>"
#define __LFRACT_MIN__ (-0.5LR-0.5LR)
# 0 "<built-in>"
#define __LFRACT_MAX__ 0X7FFFFFFFP-31LR
# 0 "<built-in>"
#define __LFRACT_EPSILON__ 0x1P-31LR
# 0 "<built-in>"
#define __ULFRACT_FBIT__ 32
# 0 "<built-in>"
#define __ULFRACT_IBIT__ 0
# 0 "<built-in>"
#define __ULFRACT_MIN__ 0.0ULR
# 0 "<built-in>"
#define __ULFRACT_MAX__ 0XFFFFFFFFP-32ULR
# 0 "<built-in>"
#define __ULFRACT_EPSILON__ 0x1P-32ULR
# 0 "<built-in>"
#define __LLFRACT_FBIT__ 63
# 0 "<built-in>"
#define __LLFRACT_IBIT__ 0
# 0 "<built-in>"
#define __LLFRACT_MIN__ (-0.5LLR-0.5LLR)
# 0 "<built-in>"
#define __LLFRACT_MAX__ 0X7FFFFFFFFFFFFFFFP-63LLR
# 0 "<built-in>"
#define __LLFRACT_EPSILON__ 0x1P-63LLR
# 0 "<built-in>"
#define __ULLFRACT_FBIT__ 64
# 0 "<built-in>"
#define __ULLFRACT_IBIT__ 0
# 0 "<built-in>"
#define __ULLFRACT_MIN__ 0.0ULLR
# 0 "<built-in>"
#define __ULLFRACT_MAX__ 0XFFFFFFFFFFFFFFFFP-64ULLR
# 0 "<built-in>"
#define __ULLFRACT_EPSILON__ 0x1P-64ULLR
# 0 "<built-in>"
#define __SACCUM_FBIT__ 7
# 0 "<built-in>"
#define __SACCUM_IBIT__ 8
# 0 "<built-in>"
#define __SACCUM_MIN__ (-0X1P7HK-0X1P7HK)
# 0 "<built-in>"
#define __SACCUM_MAX__ 0X7FFFP-7HK
# 0 "<built-in>"
#define __SACCUM_EPSILON__ 0x1P-7HK
# 0 "<built-in>"
#define __USACCUM_FBIT__ 8
# 0 "<built-in>"
#define __USACCUM_IBIT__ 8
# 0 "<built-in>"
#define __USACCUM_MIN__ 0.0UHK
# 0 "<built-in>"
#define __USACCUM_MAX__ 0XFFFFP-8UHK
# 0 "<built-in>"
#define __USACCUM_EPSILON__ 0x1P-8UHK
# 0 "<built-in>"
#define __ACCUM_FBIT__ 15
# 0 "<built-in>"
#define __ACCUM_IBIT__ 16
# 0 "<built-in>"
#define __ACCUM_MIN__ (-0X1P15K-0X1P15K)
# 0 "<built-in>"
#define __ACCUM_MAX__ 0X7FFFFFFFP-15K
# 0 "<built-in>"
#define __ACCUM_EPSILON__ 0x1P-15K
# 0 "<built-in>"
#define __UACCUM_FBIT__ 16
# 0 "<built-in>"
#define __UACCUM_IBIT__ 16
# 0 "<built-in>"
#define __UACCUM_MIN__ 0.0UK
# 0 "<built-in>"
#define __UACCUM_MAX__ 0XFFFFFFFFP-16UK
# 0 "<built-in>"
#define __UACCUM_EPSILON__ 0x1P-16UK
# 0 "<built-in>"
#define __LACCUM_FBIT__ 31
# 0 "<built-in>"
#define __LACCUM_IBIT__ 32
# 0 "<built-in>"
#define __LACCUM_MIN__ (-0X1P31LK-0X1P31LK)
# 0 "<built-in>"
#define __LACCUM_MAX__ 0X7FFFFFFFFFFFFFFFP-31LK
# 0 "<built-in>"
#define __LACCUM_EPSILON__ 0x1P-31LK
# 0 "<built-in>"
#define __ULACCUM_FBIT__ 32
# 0 "<built-in>"
#define __ULACCUM_IBIT__ 32
# 0 "<built-in>"
#define __ULACCUM_MIN__ 0.0ULK
# 0 "<built-in>"
#define __ULACCUM_MAX__ 0XFFFFFFFFFFFFFFFFP-32ULK
# 0 "<built-in>"
#define __ULACCUM_EPSILON__ 0x1P-32ULK
# 0 "<built-in>"
#define __LLACCUM_FBIT__ 31
# 0 "<built-in>"
#define __LLACCUM_IBIT__ 32
# 0 "<built-in>"
#define __LLACCUM_MIN__ (-0X1P31LLK-0X1P31LLK)
# 0 "<built-in>"
#define __LLACCUM_MAX__ 0X7FFFFFFFFFFFFFFFP-31LLK
# 0 "<built-in>"
#define __LLACCUM_EPSILON__ 0x1P-31LLK
# 0 "<built-in>"
#define __ULLACCUM_FBIT__ 32
# 0 "<built-in>"
#define __ULLACCUM_IBIT__ 32
# 0 "<built-in>"
#define __ULLACCUM_MIN__ 0.0ULLK
# 0 "<built-in>"
#define __ULLACCUM_MAX__ 0XFFFFFFFFFFFFFFFFP-32ULLK
# 0 "<built-in>"
#define __ULLACCUM_EPSILON__ 0x1P-32ULLK
# 0 "<built-in>"
#define __QQ_FBIT__ 7
# 0 "<built-in>"
#define __QQ_IBIT__ 0
# 0 "<built-in>"
#define __HQ_FBIT__ 15
# 0 "<built-in>"
#define __HQ_IBIT__ 0
# 0 "<built-in>"
#define __SQ_FBIT__ 31
# 0 "<built-in>"
#define __SQ_IBIT__ 0
# 0 "<built-in>"
#define __DQ_FBIT__ 63
# 0 "<built-in>"
#define __DQ_IBIT__ 0
# 0 "<built-in>"
#define __TQ_FBIT__ 127
# 0 "<built-in>"
#define __TQ_IBIT__ 0
# 0 "<built-in>"
#define __UQQ_FBIT__ 8
# 0 "<built-in>"
#define __UQQ_IBIT__ 0
# 0 "<built-in>"
#define __UHQ_FBIT__ 16
# 0 "<built-in>"
#define __UHQ_IBIT__ 0
# 0 "<built-in>"
#define __USQ_FBIT__ 32
# 0 "<built-in>"
#define __USQ_IBIT__ 0
# 0 "<built-in>"
#define __UDQ_FBIT__ 64
# 0 "<built-in>"
#define __UDQ_IBIT__ 0
# 0 "<built-in>"
#define __UTQ_FBIT__ 128
# 0 "<built-in>"
#define __UTQ_IBIT__ 0
# 0 "<built-in>"
#define __HA_FBIT__ 7
# 0 "<built-in>"
#define __HA_IBIT__ 8
# 0 "<built-in>"
#define __SA_FBIT__ 15
# 0 "<built-in>"
#define __SA_IBIT__ 16
# 0 "<built-in>"
#define __DA_FBIT__ 31
# 0 "<built-in>"
#define __DA_IBIT__ 32
# 0 "<built-in>"
#define __TA_FBIT__ 63
# 0 "<built-in>"
#define __TA_IBIT__ 64
# 0 "<built-in>"
#define __UHA_FBIT__ 8
# 0 "<built-in>"
#define __UHA_IBIT__ 8
# 0 "<built-in>"
#define __USA_FBIT__ 16
# 0 "<built-in>"
#define __USA_IBIT__ 16
# 0 "<built-in>"
#define __UDA_FBIT__ 32
# 0 "<built-in>"
#define __UDA_IBIT__ 32
# 0 "<built-in>"
#define __UTA_FBIT__ 64
# 0 "<built-in>"
#define __UTA_IBIT__ 64
# 0 "<built-in>"
#define __REGISTER_PREFIX__ 
# 0 "<built-in>"
#define __USER_LABEL_PREFIX__ 
# 0 "<built-in>"
#define __GNUC_STDC_INLINE__ 1
# 0 "<built-in>"
#define __STRICT_ANSI__ 1
# 0 "<built-in>"
#define __CHAR_UNSIGNED__ 1
# 0 "<built-in>"
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_1 1
# 0 "<built-in>"
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_2 1
# 0 "<built-in>"
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_4 1
# 0 "<built-in>"
#define __GCC_ATOMIC_BOOL_LOCK_FREE 2
# 0 "<built-in>"
#define __GCC_ATOMIC_CHAR_LOCK_FREE 2
# 0 "<built-in>"
#define __GCC_ATOMIC_CHAR16_T_LOCK_FREE 2
# 0 "<built-in>"
#define __GCC_ATOMIC_CHAR32_T_LOCK_FREE 2
# 0 "<built-in>"
#define __GCC_ATOMIC_WCHAR_T_LOCK_FREE 2
# 0 "<built-in>"
#define __GCC_ATOMIC_SHORT_LOCK_FREE 2
# 0 "<built-in>"
#define __GCC_ATOMIC_INT_LOCK_FREE 2
# 0 "<built-in>"
#define __GCC_ATOMIC_LONG_LOCK_FREE 2
# 0 "<built-in>"
#define __GCC_ATOMIC_LLONG_LOCK_FREE 1
# 0 "<built-in>"
#define __GCC_ATOMIC_TEST_AND_SET_TRUEVAL 1
# 0 "<built-in>"
#define __GCC_DESTRUCTIVE_SIZE 64
# 0 "<built-in>"
#define __GCC_CONSTRUCTIVE_SIZE 64
# 0 "<built-in>"
#define __GCC_ATOMIC_POINTER_LOCK_FREE 2
# 0 "<built-in>"
#define __HAVE_SPECULATION_SAFE_VALUE 1
# 0 "<built-in>"
#define __GCC_HAVE_DWARF2_CFI_ASM 1
# 0 "<built-in>"
#define __PRAGMA_REDEFINE_EXTNAME 1
# 0 "<built-in>"
#define __SIZEOF_WCHAR_T__ 4
# 0 "<built-in>"
#define __SIZEOF_WINT_T__ 4
# 0 "<built-in>"
#define __SIZEOF_PTRDIFF_T__ 4
# 0 "<built-in>"
#define __ARM_FEATURE_DSP 1
# 0 "<built-in>"
#define __ARM_FEATURE_QBIT 1
# 0 "<built-in>"
#define __ARM_FEATURE_SAT 1
# 0 "<built-in>"
#undef __ARM_FEATURE_CRYPTO
# 0 "<built-in>"
#undef __ARM_FEATURE_AES
# 0 "<built-in>"
#undef __ARM_FEATURE_SHA2
# 0 "<built-in>"
#define __ARM_FEATURE_UNALIGNED 1
# 0 "<built-in>"
#undef __ARM_FEATURE_QRDMX
# 0 "<built-in>"
#undef __ARM_FEATURE_CRC32
# 0 "<built-in>"
#undef __ARM_FEATURE_DOTPROD
# 0 "<built-in>"
#undef __ARM_FEATURE_COMPLEX
# 0 "<built-in>"
#define __ARM_32BIT_STATE 1
# 0 "<built-in>"
#undef __ARM_FEATURE_PAUTH
# 0 "<built-in>"
#undef __ARM_FEATURE_BTI
# 0 "<built-in>"
#undef __ARM_FEATURE_BTI_DEFAULT
# 0 "<built-in>"
#undef __ARM_FEATURE_PAC_DEFAULT
# 0 "<built-in>"
#undef __ARM_FEATURE_MVE
# 0 "<built-in>"
#undef __ARM_FEATURE_CMSE
# 0 "<built-in>"
#undef __ARM_FEATURE_LDREX
# 0 "<built-in>"
#define __ARM_FEATURE_LDREX 7
# 0 "<built-in>"
#define __ARM_FEATURE_CLZ 1
# 0 "<built-in>"
#undef __ARM_FEATURE_NUMERIC_MAXMIN
# 0 "<built-in>"
#define __ARM_FEATURE_SIMD32 1
# 0 "<built-in>"
#define __ARM_SIZEOF_MINIMAL_ENUM 1
# 0 "<built-in>"
#define __ARM_SIZEOF_WCHAR_T 4
# 0 "<built-in>"
#undef __ARM_ARCH_PROFILE
# 0 "<built-in>"
#define __ARM_ARCH_PROFILE 77
# 0 "<built-in>"
#define __arm__ 1
# 0 "<built-in>"
#undef __ARM_ARCH
# 0 "<built-in>"
#define __ARM_ARCH 7
# 0 "<built-in>"
#define __APCS_32__ 1
# 0 "<built-in>"
#define __GCC_ASM_FLAG_OUTPUTS__ 1
# 0 "<built-in>"
#define __thumb__ 1
# 0 "<built-in>"
#define __thumb2__ 1
# 0 "<built-in>"
#define __THUMBEL__ 1
# 0 "<built-in>"
#undef __ARM_ARCH_ISA_THUMB
# 0 "<built-in>"
#define __ARM_ARCH_ISA_THUMB 2
# 0 "<built-in>"
#define __ARMEL__ 1
# 0 "<built-in>"
#define __VFP_FP__ 1
# 0 "<built-in>"
#undef __ARM_FP
# 0 "<built-in>"
#define __ARM_FP 4
# 0 "<built-in>"
#undef __ARM_FP16_FORMAT_IEEE
# 0 "<built-in>"
#undef __ARM_FP16_FORMAT_ALTERNATIVE
# 0 "<built-in>"
#undef __ARM_FP16_ARGS
# 0 "<built-in>"
#undef __ARM_FEATURE_FP16_SCALAR_ARITHMETIC
# 0 "<built-in>"
#undef __ARM_FEATURE_FP16_VECTOR_ARITHMETIC
# 0 "<built-in>"
#undef __ARM_FEATURE_FP16_FML
# 0 "<built-in>"
#define __ARM_FEATURE_FMA 1
# 0 "<built-in>"
#undef __ARM_NEON__
# 0 "<built-in>"
#undef __ARM_NEON
# 0 "<built-in>"
#undef __ARM_NEON_FP
# 0 "<built-in>"
#define __THUMB_INTERWORK__ 1
# 0 "<built-in>"
#define __ARM_ARCH_7EM__ 1
# 0 "<built-in>"
#define __ARM_PCS_VFP 1
# 0 "<built-in>"
#define __ARM_EABI__ 1
# 0 "<built-in>"
#undef __FDPIC__
# 0 "<built-in>"
#define __ARM_ARCH_EXT_IDIV__ 1
# 0 "<built-in>"
#define __ARM_FEATURE_IDIV 1
# 0 "<built-in>"
#define __ARM_ASM_SYNTAX_UNIFIED__ 1
# 0 "<built-in>"
#undef __ARM_FEATURE_COPROC
# 0 "<built-in>"
#define __ARM_FEATURE_COPROC 15
# 0 "<built-in>"
#undef __ARM_FEATURE_CDE
# 0 "<built-in>"
#undef __ARM_FEATURE_CDE_COPROC
# 0 "<built-in>"
#undef __ARM_FEATURE_MATMUL_INT8
# 0 "<built-in>"
#undef __ARM_FEATURE_BF16_SCALAR_ARITHMETIC
# 0 "<built-in>"
#undef __ARM_FEATURE_BF16_VECTOR_ARITHMETIC
# 0 "<built-in>"
#undef __ARM_BF16_FORMAT_ALTERNATIVE
# 0 "<built-in>"
#define __GXX_TYPEINFO_EQUALITY_INLINE 0
# 0 "<built-in>"
#define __ELF__ 1
# 0 "<command-line>"
#define __USES_INITFINI__ 1
# 0 "<command-line>"
#define USE_HAL_DRIVER 1
# 0 "<command-line>"
#define STM32F407xx 1
# 0 "<command-line>"
#define SYSTEM_ALIGNMENT_BUILD_ALGORITHM SYSTEM_ALIGNMENT_VECTOR_CONSTRAINTS
# 0 "<command-line>"
#define SYSTEM_ALIGNMENT_BUILD_SOURCE SYSTEM_ALIGNMENT_ATTITUDE_SOURCE_VECTOR_CONSTRAINTS
# 0 "<command-line>"
#define SYSTEM_ALIGNMENT_BUILD_CAPABILITY_IMU 1U
# 0 "<command-line>"
#define SYSTEM_ALIGNMENT_BUILD_CAPABILITY_MAGNETOMETER SYSTEM_ALIGNMENT_USES_MAGNETIC_CONSTRAINT
# 0 "<command-line>"
#define SYSTEM_ALIGNMENT_BUILD_CAPABILITY_HARDWARE_QUATERNION 0U
# 0 "<command-line>"
#define SYSTEM_ALIGNMENT_BUILD_GUARD_HARDWARE_QUATERNION 0U
# 0 "<command-line>"
#define SYSTEM_BUILD_FUSION_ALGORITHM SYSTEM_FUSION_ESKF15
# 0 "<command-line>"
#define SYSTEM_BUILD_ESTIMATOR_ENABLED 0U
# 0 "<command-line>"
#define SYSTEM_BUILD_ESKF15_ENABLED 1U
# 0 "<command-line>"
#define SYSTEM_BUILD_MECHANIZATION_ALGORITHM SYSTEM_MECHANIZATION_CONING2_SCULLING2
# 0 "<command-line>"
#define SYSTEM_BUILD_LANDING_MODE SYSTEM_LANDING_MODE_STILLNESS
# 0 "<command-line>"
#define SILVERSTAR_AIR_LINK_ENABLED 1
# 0 "<command-line>"
#define SILVERSTAR_MEMORY_LAYOUT_AUTO 1
# 0 "<command-line>"
# 1 "./Targets/SilverStar_F407/Inc/platform_memory_target.h" 1

#define __PLATFORM_MEMORY_TARGET_H 






#define SILVERSTAR_MEMORY_LAYOUT_ESKF_WINDOW_SRAM 0







#define PLATFORM_CPU_FAST_DATA __attribute__((section(".ccmram_data"), aligned(8)))

#define PLATFORM_CPU_FAST_BSS __attribute__((section(".ccmram_bss"), aligned(8)))







#define PLATFORM_DMA_ACCESSIBLE __attribute__((section(".dma_bss"), aligned(8)))
# 41 "./Targets/SilverStar_F407/Inc/platform_memory_target.h"
#define PLATFORM_ESKF_WINDOW_BSS __attribute__((section(".bss.silverstar_auto_eskf_window"), aligned(8)))
# 0 "<command-line>" 2
# 1 "./Generated/Inc/project_flight_config.h" 1

#define __PROJECT_FLIGHT_CONFIG_H 

# 1 "./Generated/Inc/project_algorithm_parameters.h" 1

#define __PROJECT_ALGORITHM_PARAMETERS_H 



#define SYSTEM_INS_GRAVITY_MPS2 9.779999733e+00f


#define SYSTEM_MECHANIZATION_SUBSAMPLE_COUNT 2


#define SYSTEM_ESKF_GRAVITY_MPS2 9.779999733e+00f


#define SYSTEM_ESKF_GYRO_NOISE_DENSITY 3.000000026e-03f


#define SYSTEM_ESKF_ACCEL_NOISE_DENSITY 7.999999821e-02f


#define SYSTEM_ESKF_GYRO_BIAS_RW 9.999999747e-05f


#define SYSTEM_ESKF_ACCEL_BIAS_RW 1.000000047e-03f


#define SYSTEM_ESKF_P0_POSITION_E 4.000000000e+00f


#define SYSTEM_ESKF_P0_POSITION_N 4.000000000e+00f


#define SYSTEM_ESKF_P0_POSITION_U 9.000000000e+00f


#define SYSTEM_ESKF_P0_VELOCITY_E 2.500000000e-01f


#define SYSTEM_ESKF_P0_VELOCITY_N 2.500000000e-01f


#define SYSTEM_ESKF_P0_VELOCITY_U 2.500000000e-01f


#define SYSTEM_ESKF_P0_THETA_X 3.046174161e-02f


#define SYSTEM_ESKF_P0_THETA_Y 3.046174161e-02f


#define SYSTEM_ESKF_P0_THETA_Z 3.046174161e-02f


#define SYSTEM_ESKF_P0_GYRO_BIAS_X 9.999999747e-05f


#define SYSTEM_ESKF_P0_GYRO_BIAS_Y 9.999999747e-05f


#define SYSTEM_ESKF_P0_GYRO_BIAS_Z 9.999999747e-05f


#define SYSTEM_ESKF_P0_ACCEL_BIAS_X 9.999999776e-03f


#define SYSTEM_ESKF_P0_ACCEL_BIAS_Y 9.999999776e-03f


#define SYSTEM_ESKF_P0_ACCEL_BIAS_Z 9.999999776e-03f


#define SYSTEM_ESKF_GNSS_POSITION_STD_HORIZONTAL 1.500000000e+00f


#define SYSTEM_ESKF_GNSS_POSITION_STD_VERTICAL 2.500000000e+00f


#define SYSTEM_ESKF_GNSS_VELOCITY_STD 1.500000060e-01f


#define SYSTEM_ESKF_BARO_STD_M 2.500000000e+00f


#define SYSTEM_ESKF_NIS_1D_SOFT 6.635000229e+00f


#define SYSTEM_ESKF_NIS_1D_HARD 1.082800007e+01f


#define SYSTEM_ESKF_NIS_2D_SOFT 9.210000038e+00f


#define SYSTEM_ESKF_NIS_2D_HARD 1.381599998e+01f


#define SYSTEM_ESKF_NIS_MAX_R_SCALE 4.000000000e+00f


#define SYSTEM_ESKF_LEVER_ARM_BODY_X_M 0.000000000e+00f


#define SYSTEM_ESKF_LEVER_ARM_BODY_Y_M 0.000000000e+00f


#define SYSTEM_ESKF_LEVER_ARM_BODY_Z_M 0.000000000e+00f


#define SYSTEM_ESTIMATOR_GNSS_POSITION_MEASUREMENT_DELAY_MS 0


#define SYSTEM_ESTIMATOR_GNSS_VELOCITY_MEASUREMENT_DELAY_MS 270


#define SYSTEM_ESTIMATOR_BARO_MEASUREMENT_DELAY_MS 0


#define SYSTEM_ESKF_NIS_SOFT_ENABLED 1


#define SYSTEM_ESKF_NIS_HARD_ENABLED 1


#define SYSTEM_FUSION_TIMING_MODE 2


#define SYSTEM_FUSION_HORIZON_MS 300


#define SYSTEM_ESKF_GNSS_RECOVERY_ENABLED 0


#define SYSTEM_ESKF_GNSS_RECOVERY_LOSS_GAP_MS 0


#define SYSTEM_ESKF_GNSS_RECOVERY_STABLE_SPAN_MS 0


#define SYSTEM_ESKF_GNSS_RECOVERY_MAXIMUM_INTERVAL_MS 0


#define SYSTEM_ESKF_GNSS_RECOVERY_COOLDOWN_MS 0


#define SYSTEM_ESKF_GNSS_RECOVERY_STABLE_COUNT 0


#define SYSTEM_ESKF_GNSS_RECOVERY_REJECT_COUNT 0


#define SYSTEM_ESKF_GNSS_RECOVERY_CONFIRMATION_COUNT 0


#define SYSTEM_ESKF_GNSS_RECOVERY_MAXIMUM_ATTEMPTS 0


#define SYSTEM_ESKF_GNSS_RECOVERY_UNIFORM_SCALE 0.000000000e+00f


#define SYSTEM_ESKF_GNSS_RECOVERY_CAP_POSITION_E 0.000000000e+00f


#define SYSTEM_ESKF_GNSS_RECOVERY_CAP_POSITION_N 0.000000000e+00f


#define SYSTEM_ESKF_GNSS_RECOVERY_CAP_POSITION_U 0.000000000e+00f


#define SYSTEM_ESKF_GNSS_RECOVERY_CAP_VELOCITY_E 0.000000000e+00f


#define SYSTEM_ESKF_GNSS_RECOVERY_CAP_VELOCITY_N 0.000000000e+00f


#define SYSTEM_ESKF_GNSS_RECOVERY_CAP_VELOCITY_U 0.000000000e+00f


#define SYSTEM_ESKF_GNSS_RECOVERY_CAP_THETA_X 0.000000000e+00f


#define SYSTEM_ESKF_GNSS_RECOVERY_CAP_THETA_Y 0.000000000e+00f


#define SYSTEM_ESKF_GNSS_RECOVERY_CAP_THETA_Z 0.000000000e+00f


#define SYSTEM_ESKF_GNSS_RECOVERY_CAP_GYRO_BIAS_X 0.000000000e+00f


#define SYSTEM_ESKF_GNSS_RECOVERY_CAP_GYRO_BIAS_Y 0.000000000e+00f


#define SYSTEM_ESKF_GNSS_RECOVERY_CAP_GYRO_BIAS_Z 0.000000000e+00f


#define SYSTEM_ESKF_GNSS_RECOVERY_CAP_ACCEL_BIAS_X 0.000000000e+00f


#define SYSTEM_ESKF_GNSS_RECOVERY_CAP_ACCEL_BIAS_Y 0.000000000e+00f


#define SYSTEM_ESKF_GNSS_RECOVERY_CAP_ACCEL_BIAS_Z 0.000000000e+00f


#define SYSTEM_ESKF_GNSS_RECOVERY_CLOCK_JITTER_MS 0


#define SYSTEM_ESKF_GNSS_RECOVERY_HORIZONTAL_ACCELERATION_LIMIT_MPS2 0.000000000e+00f


#define SYSTEM_ESKF_GNSS_RECOVERY_VERTICAL_ACCELERATION_LIMIT_MPS2 0.000000000e+00f


#define SYSTEM_ESKF_GNSS_RECOVERY_CLOSURE_SIGMA 0.000000000e+00f


#define SYSTEM_ESKF_GNSS_RECOVERY_CONFIGURATION_ID 0xD71F022FUL
# 5 "./Generated/Inc/project_flight_config.h" 2
# 1 "./Generated/Inc/project_device_build_capabilities.h" 1

#define __PROJECT_DEVICE_BUILD_CAPABILITIES_H 


#define SILVERSTAR_PROJECT_DEVICE_CAPABILITIES 1U
#define SILVERSTAR_BUILD_COMPACT_ENABLED 0U

#define SYSTEM_BUILD_IMU_EPOCH_QUALIFICATION_ENABLED 0U


#define SYSTEM_SELECTED_BAROMETER_ALIGNMENT_ORIGIN_QUALIFIED 0U


#define SYSTEM_SELECTED_BAROMETER_DIRECT_ALTITUDE_AVAILABLE 0U


#define SYSTEM_SELECTED_BAROMETER_ESTIMATOR_NOISE_RECOMMENDATION_AVAILABLE 0U


#define SYSTEM_SELECTED_BAROMETER_LANDING_WINDOW_QUALIFIED 0U


#define SYSTEM_SELECTED_BAROMETER_RECOMMENDED_ALTITUDE_STD_M 0.0f


#define SYSTEM_SELECTED_GNSS_ESTIMATOR_NOISE_RECOMMENDATION_AVAILABLE 1U


#define SYSTEM_SELECTED_GNSS_POSITION_AVAILABLE 1U


#define SYSTEM_SELECTED_GNSS_RECOMMENDED_HORIZONTAL_POSITION_STD_FLOOR_M 1.5f


#define SYSTEM_SELECTED_GNSS_RECOMMENDED_VELOCITY_STD_FLOOR_MPS 0.15f


#define SYSTEM_SELECTED_GNSS_RECOMMENDED_VERTICAL_POSITION_STD_FLOOR_M 2.5f


#define SYSTEM_SELECTED_HARDWARE_QUATERNION_AUTHORITATIVE_6AXIS_QUALIFIED 0U


#define SYSTEM_SELECTED_HARDWARE_QUATERNION_AUTHORITATIVE_9AXIS_QUALIFIED 0U


#define SYSTEM_SELECTED_HARDWARE_QUATERNION_OUTPUT_AVAILABLE 1U


#define SYSTEM_SELECTED_HARDWARE_QUATERNION_PREFLIGHT_ALIGNMENT_6AXIS_QUALIFIED 1U


#define SYSTEM_SELECTED_HARDWARE_QUATERNION_PREFLIGHT_ALIGNMENT_9AXIS_QUALIFIED 1U


#define SYSTEM_SELECTED_HARDWARE_QUATERNION_PREFLIGHT_FALLBACK_QUALIFIED 1U


#define SYSTEM_SELECTED_IMU_ACCEL_AVAILABLE 1U


#define SYSTEM_SELECTED_IMU_ESTIMATOR_NOISE_RECOMMENDATION_AVAILABLE 1U


#define SYSTEM_SELECTED_IMU_GYRO_AVAILABLE 1U


#define SYSTEM_SELECTED_IMU_LANDING_IMPACT_QUALIFIED 0U


#define SYSTEM_SELECTED_IMU_LANDING_STILLNESS_QUALIFIED 1U


#define SYSTEM_SELECTED_IMU_RECOMMENDED_PROCESS_ACCEL_E_STD_MPS2 1.5f


#define SYSTEM_SELECTED_IMU_RECOMMENDED_PROCESS_ACCEL_N_STD_MPS2 1.5f


#define SYSTEM_SELECTED_IMU_RECOMMENDED_PROCESS_ACCEL_U_STD_MPS2 2.0f


#define SYSTEM_SELECTED_IMU_SOFTWARE_ALIGNMENT_QUALIFIED 1U


#define SYSTEM_SELECTED_IMU_SOFTWARE_PROPAGATION_QUALIFIED 1U


#define SYSTEM_SELECTED_MAGNETOMETER_ABSOLUTE_VECTOR_QUALIFIED (SYSTEM_USER_MAGNETOMETER_ENABLE * 0U)


#define SYSTEM_SELECTED_MAGNETOMETER_PHYSICAL_UNIT_AVAILABLE (SYSTEM_USER_MAGNETOMETER_ENABLE * 0U)


#define SYSTEM_SELECTED_MAGNETOMETER_RAW_OUTPUT_AVAILABLE (SYSTEM_USER_MAGNETOMETER_ENABLE * 0U)


#define SYSTEM_SELECTED_MISSION_ACTION_PARACHUTE_DEPLOY_AVAILABLE 1U


#define SYSTEM_SELECTED_MISSION_ACTION_START_AVAILABLE 1U
# 6 "./Generated/Inc/project_flight_config.h" 2




#define SILVERSTAR_PROTOCOL_TELEMETRY_ENABLED 1U


#define SILVERSTAR_PROTOCOL_MAINTENANCE_ENABLED 1U


#define SILVERSTAR_PROTOCOL_LOGGING_ENABLED 1U


#define SYSTEM_GNSS_DYNAMIC_MODEL SYSTEM_GNSS_DYNAMIC_MODEL_AIRBORNE_4G


#define SYSTEM_GNSS_NAVIGATION_RATE_HZ 25U


#define SYSTEM_IMU_OUTPUT_RATE_HZ 200U


#define SILVERSTAR_MAINTENANCE_UART_FIELDS " uart_baud=230400 uart_format=8N1 idle_timeout_ms=30000"





#define SYSTEM_FUSION_CONFIGURED_MASK 0x0FU


#define SYSTEM_FUSION_REQUIRED_HEALTH_MASK 0x0FU


#define SYSTEM_USER_ALIGNMENT_SELECTED_MASK (SYSTEM_ALIGNMENT_SOURCE_MASK_ATTITUDE | SYSTEM_ALIGNMENT_SOURCE_MASK_GNSS_ORIGIN)


#define SYSTEM_USER_ALIGNMENT_REQUIRED_MASK (SYSTEM_ALIGNMENT_SOURCE_MASK_ATTITUDE)


#define SYSTEM_BUILD_BAROMETER_COLD_ENABLED 0U


#define SYSTEM_BUILD_BMP280_I2C_ENABLED 0U


#define SYSTEM_BUILD_BMP280_SPI_ENABLED 0U


#define SYSTEM_BUILD_MS5611_I2C_ENABLED 0U


#define SYSTEM_BUILD_MS5611_SPI_ENABLED 0U


#define SYSTEM_ALIGNMENT_CONSTRAINT_COUNT 2U


#define SYSTEM_ALIGNMENT_CONSTRAINTS_INITIALIZER { { ALIGNMENT_CONSTRAINT_GRAVITY, 1.0F, 0.0F, 1, 90.0F }, { ALIGNMENT_CONSTRAINT_REFERENCE_DIRECTION, 1.0F, 0.0F, 1, 90.0F } }


#define SYSTEM_ALIGNMENT_EXTERNAL_YAW_AUTHORITATIVE 0U


#define SYSTEM_ALIGNMENT_USES_MAGNETIC_CONSTRAINT 0U


#define SYSTEM_ALIGNMENT_KNOWN_YAW_DEG 0.0F


#define SILVERSTAR_LOG_TELEMETRY_COMPATIBILITY_TAG {0x41U, 0x49U, 0x52U, 0x2DU, 0x4EU, 0x43U, 0x52U, 0x43U}


#define JY901B_MAGNETOMETER_ADAPTER_ENABLE 0U


#define MISSION_ACTION_OUTPUT_BUILD_PARACHUTE_DEPLOY_AVAILABLE 1U


#define MISSION_ACTION_OUTPUT_BUILD_START_ACTION_AVAILABLE 1U


#define SYSTEM_USER_BAROMETER_ENABLE 0U


#define SYSTEM_USER_CONSOLE_ENABLE 1U


#define SYSTEM_USER_GNSS_ENABLE 1U


#define SYSTEM_USER_HARDWARE_QUATERNION_ENABLE 1U


#define SYSTEM_USER_IMU_ENABLE 1U


#define SYSTEM_USER_LOG_SINK_ENABLE 1U


#define SYSTEM_USER_MAGNETOMETER_ENABLE 0U


#define SYSTEM_USER_MISSION_ACTION_ENABLE 1U


#define SYSTEM_USER_OUTPUT_ENABLE 1U


#define SYSTEM_USER_POWER_ENABLE 1U


#define SYSTEM_USER_STORAGE_ENABLE 1U


#define SYSTEM_USER_TELEMETRY_ENABLE 1U


#define SYSTEM_INDICATOR_GNSS_ENABLE 0U


#define SYSTEM_INDICATOR_SYSTEM_ENABLE 1U


#define SYSTEM_CALIBRATION_BUILD_PROCEDURE_MASK 0U


#define SYSTEM_FLIGHT_DEPLOY_TRIGGER_MASK (SYSTEM_DEPLOY_TRIGGER_APOGEE_VZ | SYSTEM_DEPLOY_TRIGGER_TILT)


#define SYSTEM_FLIGHT_APOGEE_VZ_THRESHOLD_MPS (-2.0f)


#define SYSTEM_FLIGHT_TILT_THRESHOLD_DEG 45.0f


#define SYSTEM_FLIGHT_DEPLOY_DELAY_MS 60000U
# 0 "<command-line>" 2
# 1 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
# 1 "System/Inc/system_version.h" 1

#define __SYSTEM_VERSION_H 

# 1 "System/User/system_user_config.h" 1

#define __SYSTEM_USER_CONFIG_H 
# 18 "System/User/system_user_config.h"
# 1 "System/Inc/system_configuration_types.h" 1

#define __SYSTEM_CONFIGURATION_TYPES_H 

# 1 "D:/Arm GNU Toolchain/14.3 rel1/lib/gcc/arm-none-eabi/14.3.1/include/stdint.h" 1 3 4
# 9 "D:/Arm GNU Toolchain/14.3 rel1/lib/gcc/arm-none-eabi/14.3.1/include/stdint.h" 3 4
# 1 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/stdint.h" 1 3 4
# 10 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/stdint.h" 3 4
#define _STDINT_H 

# 1 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/machine/_default_types.h" 1 3 4





#define _MACHINE__DEFAULT_TYPES_H 

# 1 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/features.h" 1 3 4
# 22 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/features.h" 3 4
#define _SYS_FEATURES_H 





# 1 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/_newlib_version.h" 1 3 4



#define _NEWLIB_VERSION_H__ 1

#define _NEWLIB_VERSION "4.5.0"
#define __NEWLIB__ 4
#define __NEWLIB_MINOR__ 5
#define __NEWLIB_PATCHLEVEL__ 0
# 29 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/features.h" 2 3 4




#define __GNUC_PREREQ(maj,min) ((__GNUC__ << 16) + __GNUC_MINOR__ >= ((maj) << 16) + (min))






#define __GNUC_PREREQ__(ma,mi) __GNUC_PREREQ(ma, mi)
# 273 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/features.h" 3 4
#define __ATFILE_VISIBLE 0





#define __BSD_VISIBLE 0





#define __GNU_VISIBLE 0







#define __ISO_C_VISIBLE 2011
# 304 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/features.h" 3 4
#define __LARGEFILE_VISIBLE 0





#define __MISC_VISIBLE 0
# 328 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/features.h" 3 4
#define __POSIX_VISIBLE 0





#define __SVID_VISIBLE 0
# 348 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/features.h" 3 4
#define __XSI_VISIBLE 0
# 366 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/features.h" 3 4
#define __SSP_FORTIFY_LEVEL 0
# 9 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/machine/_default_types.h" 2 3 4






#define __EXP(x) __ ##x ##__
# 26 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/machine/_default_types.h" 3 4
#define __have_longlong64 1






#define __have_long32 1








# 41 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/machine/_default_types.h" 3 4
typedef signed char __int8_t;

typedef unsigned char __uint8_t;



#define ___int8_t_defined 1







typedef short int __int16_t;

typedef short unsigned int __uint16_t;



#define ___int16_t_defined 1
# 77 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/machine/_default_types.h" 3 4
typedef long int __int32_t;

typedef long unsigned int __uint32_t;



#define ___int32_t_defined 1
# 103 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/machine/_default_types.h" 3 4
typedef long long int __int64_t;

typedef long long unsigned int __uint64_t;



#define ___int64_t_defined 1
# 134 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/machine/_default_types.h" 3 4
typedef signed char __int_least8_t;

typedef unsigned char __uint_least8_t;



#define ___int_least8_t_defined 1
# 160 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/machine/_default_types.h" 3 4
typedef short int __int_least16_t;

typedef short unsigned int __uint_least16_t;



#define ___int_least16_t_defined 1
# 182 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/machine/_default_types.h" 3 4
typedef long int __int_least32_t;

typedef long unsigned int __uint_least32_t;



#define ___int_least32_t_defined 1
# 200 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/machine/_default_types.h" 3 4
typedef long long int __int_least64_t;

typedef long long unsigned int __uint_least64_t;



#define ___int_least64_t_defined 1







typedef long long int __intmax_t;







typedef long long unsigned int __uintmax_t;







typedef int __intptr_t;

typedef unsigned int __uintptr_t;
# 244 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/machine/_default_types.h" 3 4
#undef __EXP
# 13 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/stdint.h" 2 3 4
# 1 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/_intsup.h" 1 3 4
# 10 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/_intsup.h" 3 4
#define _SYS__INTSUP_H 





#define __STDINT_EXP(x) __ ##x ##__
# 35 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/_intsup.h" 3 4
       
       
       
       
       
       
       
       
#undef signed
#undef unsigned
#undef char
#undef short
#undef int
#undef __int20
#undef __int20__
#undef long
#define signed +0
#define unsigned +0
#define char +0
#define short +1
#define __int20 +2
#define __int20__ +2
#define int +2
#define long +4
# 67 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/_intsup.h" 3 4
#define _INTPTR_EQ_INT 






#define _INT32_EQ_LONG 







#define __INT8 "hh"
# 93 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/_intsup.h" 3 4
#define __INT16 "h"
# 104 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/_intsup.h" 3 4
#define __INT32 "l"
# 113 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/_intsup.h" 3 4
#define __INT64 "ll"






#define __FAST8 
# 129 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/_intsup.h" 3 4
#define __FAST16 






#define __FAST32 
# 147 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/_intsup.h" 3 4
#define __FAST64 "ll"



#define __LEAST8 "hh"
# 162 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/_intsup.h" 3 4
#define __LEAST16 "h"
# 173 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/_intsup.h" 3 4
#define __LEAST32 "l"
# 182 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/_intsup.h" 3 4
#define __LEAST64 "ll"

#undef signed
#undef unsigned
#undef char
#undef short
#undef int
#undef long
       
       
       
       
       
# 194 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/_intsup.h" 3 4
#undef __int20
       
# 195 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/_intsup.h" 3 4
#undef __int20__
       
       
# 14 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/stdint.h" 2 3 4
# 1 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/_stdint.h" 1 3 4
# 10 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/_stdint.h" 3 4
#define _SYS__STDINT_H 
# 20 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/_stdint.h" 3 4
typedef __int8_t int8_t ;
#define _INT8_T_DECLARED 


typedef __uint8_t uint8_t ;
#define _UINT8_T_DECLARED 

#define __int8_t_defined 1




typedef __int16_t int16_t ;
#define _INT16_T_DECLARED 


typedef __uint16_t uint16_t ;
#define _UINT16_T_DECLARED 

#define __int16_t_defined 1




typedef __int32_t int32_t ;
#define _INT32_T_DECLARED 


typedef __uint32_t uint32_t ;
#define _UINT32_T_DECLARED 

#define __int32_t_defined 1




typedef __int64_t int64_t ;
#define _INT64_T_DECLARED 


typedef __uint64_t uint64_t ;
#define _UINT64_T_DECLARED 

#define __int64_t_defined 1



typedef __intmax_t intmax_t;
#define _INTMAX_T_DECLARED 



typedef __uintmax_t uintmax_t;
#define _UINTMAX_T_DECLARED 



typedef __intptr_t intptr_t;
#define _INTPTR_T_DECLARED 



typedef __uintptr_t uintptr_t;
#define _UINTPTR_T_DECLARED 
# 15 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/stdint.h" 2 3 4






typedef __int_least8_t int_least8_t;
typedef __uint_least8_t uint_least8_t;
#define __int_least8_t_defined 1



typedef __int_least16_t int_least16_t;
typedef __uint_least16_t uint_least16_t;
#define __int_least16_t_defined 1



typedef __int_least32_t int_least32_t;
typedef __uint_least32_t uint_least32_t;
#define __int_least32_t_defined 1



typedef __int_least64_t int_least64_t;
typedef __uint_least64_t uint_least64_t;
#define __int_least64_t_defined 1
# 51 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/stdint.h" 3 4
  typedef int int_fast8_t;
  typedef unsigned int uint_fast8_t;
#define __int_fast8_t_defined 1







  typedef int int_fast16_t;
  typedef unsigned int uint_fast16_t;
#define __int_fast16_t_defined 1







  typedef int int_fast32_t;
  typedef unsigned int uint_fast32_t;
#define __int_fast32_t_defined 1







  typedef long long int int_fast64_t;
  typedef long long unsigned int uint_fast64_t;
#define __int_fast64_t_defined 1
# 128 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/stdint.h" 3 4
#define INTPTR_MIN (-__INTPTR_MAX__ - 1)
#define INTPTR_MAX (__INTPTR_MAX__)
#define UINTPTR_MAX (__UINTPTR_MAX__)
# 152 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/stdint.h" 3 4
#define INT8_MIN (-__INT8_MAX__ - 1)
#define INT8_MAX (__INT8_MAX__)
#define UINT8_MAX (__UINT8_MAX__)







#define INT_LEAST8_MIN (-__INT_LEAST8_MAX__ - 1)
#define INT_LEAST8_MAX (__INT_LEAST8_MAX__)
#define UINT_LEAST8_MAX (__UINT_LEAST8_MAX__)
# 174 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/stdint.h" 3 4
#define INT16_MIN (-__INT16_MAX__ - 1)
#define INT16_MAX (__INT16_MAX__)
#define UINT16_MAX (__UINT16_MAX__)







#define INT_LEAST16_MIN (-__INT_LEAST16_MAX__ - 1)
#define INT_LEAST16_MAX (__INT_LEAST16_MAX__)
#define UINT_LEAST16_MAX (__UINT_LEAST16_MAX__)
# 196 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/stdint.h" 3 4
#define INT32_MIN (-__INT32_MAX__ - 1)
#define INT32_MAX (__INT32_MAX__)
#define UINT32_MAX (__UINT32_MAX__)
# 212 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/stdint.h" 3 4
#define INT_LEAST32_MIN (-__INT_LEAST32_MAX__ - 1)
#define INT_LEAST32_MAX (__INT_LEAST32_MAX__)
#define UINT_LEAST32_MAX (__UINT_LEAST32_MAX__)
# 230 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/stdint.h" 3 4
#define INT64_MIN (-__INT64_MAX__ - 1)
#define INT64_MAX (__INT64_MAX__)
#define UINT64_MAX (__UINT64_MAX__)
# 246 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/stdint.h" 3 4
#define INT_LEAST64_MIN (-__INT_LEAST64_MAX__ - 1)
#define INT_LEAST64_MAX (__INT_LEAST64_MAX__)
#define UINT_LEAST64_MAX (__UINT_LEAST64_MAX__)
# 262 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/stdint.h" 3 4
#define INT_FAST8_MIN (-__INT_FAST8_MAX__ - 1)
#define INT_FAST8_MAX (__INT_FAST8_MAX__)
#define UINT_FAST8_MAX (__UINT_FAST8_MAX__)
# 278 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/stdint.h" 3 4
#define INT_FAST16_MIN (-__INT_FAST16_MAX__ - 1)
#define INT_FAST16_MAX (__INT_FAST16_MAX__)
#define UINT_FAST16_MAX (__UINT_FAST16_MAX__)
# 294 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/stdint.h" 3 4
#define INT_FAST32_MIN (-__INT_FAST32_MAX__ - 1)
#define INT_FAST32_MAX (__INT_FAST32_MAX__)
#define UINT_FAST32_MAX (__UINT_FAST32_MAX__)
# 310 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/stdint.h" 3 4
#define INT_FAST64_MIN (-__INT_FAST64_MAX__ - 1)
#define INT_FAST64_MAX (__INT_FAST64_MAX__)
#define UINT_FAST64_MAX (__UINT_FAST64_MAX__)
# 326 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/stdint.h" 3 4
#define INTMAX_MAX (__INTMAX_MAX__)
#define INTMAX_MIN (-INTMAX_MAX - 1)







#define UINTMAX_MAX (__UINTMAX_MAX__)







#define SIZE_MAX (__SIZE_MAX__)





#define SIG_ATOMIC_MIN (-__STDINT_EXP(INT_MAX) - 1)
#define SIG_ATOMIC_MAX (__STDINT_EXP(INT_MAX))



#define PTRDIFF_MAX (__PTRDIFF_MAX__)



#define PTRDIFF_MIN (-PTRDIFF_MAX - 1)




#define WCHAR_MIN (__WCHAR_MIN__)
# 374 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/stdint.h" 3 4
#define WCHAR_MAX (__WCHAR_MAX__)
# 384 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/stdint.h" 3 4
#define WINT_MAX (__WINT_MAX__)




#define WINT_MIN (__WINT_MIN__)






#define INT8_C(x) __INT8_C(x)
#define UINT8_C(x) __UINT8_C(x)
# 408 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/stdint.h" 3 4
#define INT16_C(x) __INT16_C(x)
#define UINT16_C(x) __UINT16_C(x)
# 420 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/stdint.h" 3 4
#define INT32_C(x) __INT32_C(x)
#define UINT32_C(x) __UINT32_C(x)
# 433 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/stdint.h" 3 4
#define INT64_C(x) __INT64_C(x)
#define UINT64_C(x) __UINT64_C(x)
# 449 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/stdint.h" 3 4
#define INTMAX_C(x) __INTMAX_C(x)
#define UINTMAX_C(x) __UINTMAX_C(x)
# 10 "D:/Arm GNU Toolchain/14.3 rel1/lib/gcc/arm-none-eabi/14.3.1/include/stdint.h" 2 3 4



#define _GCC_WRAP_STDINT_H 
# 5 "System/Inc/system_configuration_types.h" 2


# 6 "System/Inc/system_configuration_types.h"
typedef enum
{
    SYSTEM_ALIGNMENT_HW_QUAT_6AXIS_KNOWN_YAW = 0,
    SYSTEM_ALIGNMENT_GRAVITY_MAG_TRIAD = 1,
    SYSTEM_ALIGNMENT_HW_QUAT_9AXIS = 2,
    SYSTEM_ALIGNMENT_GRAVITY_KNOWN_YAW = 3,
    SYSTEM_ALIGNMENT_VECTOR_CONSTRAINTS = 4,
    SYSTEM_ALIGNMENT_EXTERNAL_ATTITUDE_SOURCE = 5
} SystemAlignmentAlgorithm;

typedef enum
{
    SYSTEM_ATTITUDE_SOFTWARE_ALWAYS = 0
} SystemAttitudePolicy;

typedef enum
{
    SYSTEM_MECHANIZATION_CONING2_SCULLING2 = 0
} SystemMechanizationAlgorithm;

typedef enum
{
    SYSTEM_FUSION_NONE = 0,
    SYSTEM_FUSION_KF6,
    SYSTEM_FUSION_ESKF15,
    SYSTEM_FUSION_SF6
} SystemFusionAlgorithm;

typedef uint32_t SystemDeployTriggerMask;

#define SYSTEM_DEPLOY_TRIGGER_NONE 0UL
#define SYSTEM_DEPLOY_TRIGGER_TILT (1UL << 0)
#define SYSTEM_DEPLOY_TRIGGER_APOGEE_VZ (1UL << 1)
#define SYSTEM_DEPLOY_TRIGGER_DELAY (1UL << 2)
#define SYSTEM_DEPLOY_TRIGGER_MASK_ALL (SYSTEM_DEPLOY_TRIGGER_TILT | SYSTEM_DEPLOY_TRIGGER_APOGEE_VZ | SYSTEM_DEPLOY_TRIGGER_DELAY)



typedef enum
{
    SYSTEM_TILT_REFERENCE_INITIAL_AXIS = 0,
    SYSTEM_TILT_REFERENCE_NAV_UP
} SystemTiltReference;

typedef enum
{
    SYSTEM_LANDING_MODE_STILLNESS = 0,
    SYSTEM_LANDING_MODE_IMPACT_THEN_STILLNESS,
    SYSTEM_LANDING_MODE_BARO_IMU_WINDOW
} SystemLandingMode;

typedef enum
{
    SYSTEM_BODY_AXIS_X_POSITIVE = 0,
    SYSTEM_BODY_AXIS_X_NEGATIVE,
    SYSTEM_BODY_AXIS_Y_POSITIVE,
    SYSTEM_BODY_AXIS_Y_NEGATIVE,
    SYSTEM_BODY_AXIS_Z_POSITIVE,
    SYSTEM_BODY_AXIS_Z_NEGATIVE
} SystemBodyAxis;
# 19 "System/User/system_user_config.h" 2
# 1 "System/User/system_user_flight_config.h" 1

#define __SYSTEM_USER_FLIGHT_CONFIG_H 


# 1 "Targets/SilverStar_F407/Inc/target_system_config.h" 1

#define __TARGET_SYSTEM_CONFIG_H 

# 1 "System/Inc/system_capabilities.h" 1

#define __SYSTEM_CAPABILITIES_H 



# 1 "Interfaces/Inc/system_device_types.h" 1

#define __SYSTEM_DEVICE_TYPES_H 



# 1 "Common/Inc/silverstar_compiler.h" 1

#define __SILVERSTAR_COMPILER_H 


#define SILVERSTAR_NORETURN __attribute__((noreturn))
#define SILVERSTAR_WARN_UNUSED_RESULT __attribute__((warn_unused_result))
# 7 "Interfaces/Inc/system_device_types.h" 2

#define SYSTEM_WARN_UNUSED_RESULT SILVERSTAR_WARN_UNUSED_RESULT

typedef enum
{
    SYSTEM_DEVICE_OK = 0,
    SYSTEM_DEVICE_ALREADY_MATCHED,
    SYSTEM_DEVICE_NOT_READY,
    SYSTEM_DEVICE_OFFLINE,
    SYSTEM_DEVICE_UNSUPPORTED,
    SYSTEM_DEVICE_INVALID_ARGUMENT,
    SYSTEM_DEVICE_TIMEOUT,
    SYSTEM_DEVICE_IO_ERROR,
    SYSTEM_DEVICE_VERIFY_FAILED,
    SYSTEM_DEVICE_BAD_STATE,
    SYSTEM_DEVICE_VALUE_ADJUSTED,
    SYSTEM_DEVICE_INTERNAL_ERROR,
    SYSTEM_DEVICE_CONFIG_NO_ACTION,
    SYSTEM_DEVICE_CONFIG_DELEGATED,
    SYSTEM_DEVICE_NOT_EXECUTED,
    SYSTEM_DEVICE_BUSY,
    SYSTEM_DEVICE_NOT_PRESENT
} SystemDeviceResult;

typedef struct
{
    const char *device_name;
    const char *model_name;
    const char *driver_version;
    uint32_t capability_mask;
    uint32_t configuration_mask;
} SystemDeviceInfo;

typedef struct
{
    uint64_t last_sample_timestamp_us;
    uint64_t last_receive_timestamp_us;
    uint32_t sample_count;
    uint32_t error_count;
    uint32_t timeout_count;
    uint32_t checksum_error_count;
    uint32_t health_flags;
    uint8_t initialized;
    uint8_t started;
    uint8_t online;
    uint8_t healthy;
} SystemDeviceHealth;

typedef struct
{
    uint32_t requested_mask;
    uint32_t required_mask;
    uint32_t supported_mask;
    uint32_t applied_mask;
    uint32_t matched_mask;
    uint32_t unsupported_optional_mask;
    uint32_t unsupported_required_mask;
    uint32_t verify_failed_mask;
    uint32_t delegated_mask;
    uint32_t failed_mask;
    uint32_t detail_code;
    uint32_t retry_count;
    uint8_t restart_performed;
    uint8_t persisted;
    uint8_t success;
} SystemDeviceConfigReport;

typedef struct
{
    uint32_t passed_mask;
    uint32_t failed_mask;
    uint32_t unsupported_mask;
    uint32_t detail_code;
} SystemDeviceSelfTestResult;

typedef enum
{
    SYSTEM_DEVICE_TRANSPORT_NONE = 0,
    SYSTEM_DEVICE_TRANSPORT_UART,
    SYSTEM_DEVICE_TRANSPORT_SPI
} SystemDeviceTransportType;

typedef enum
{
    SYSTEM_DEVICE_IO_OWNER_SELF = 0,
    SYSTEM_DEVICE_IO_OWNER_IMU,
    SYSTEM_DEVICE_IO_OWNER_GNSS,
    SYSTEM_DEVICE_IO_OWNER_TELEMETRY,
    SYSTEM_DEVICE_IO_OWNER_CONSOLE
} SystemDeviceIoOwner;

#define SYSTEM_DEVICE_IO_VALID_TRANSPORT (1UL << 0)
#define SYSTEM_DEVICE_IO_VALID_RX_BYTES (1UL << 1)
#define SYSTEM_DEVICE_IO_VALID_TX_BYTES (1UL << 2)
#define SYSTEM_DEVICE_IO_VALID_RX_EVENTS (1UL << 3)
#define SYSTEM_DEVICE_IO_VALID_RX_IDLE_EVENTS (1UL << 4)
#define SYSTEM_DEVICE_IO_VALID_RX_TC_EVENTS (1UL << 5)
#define SYSTEM_DEVICE_IO_VALID_RX_DISCARDED (1UL << 6)
#define SYSTEM_DEVICE_IO_VALID_UART_OVERRUN (1UL << 7)
#define SYSTEM_DEVICE_IO_VALID_UART_FRAMING (1UL << 8)
#define SYSTEM_DEVICE_IO_VALID_UART_NOISE (1UL << 9)
#define SYSTEM_DEVICE_IO_VALID_UART_PARITY (1UL << 10)
#define SYSTEM_DEVICE_IO_VALID_DMA_ERRORS (1UL << 11)
#define SYSTEM_DEVICE_IO_VALID_RX_RESTARTS (1UL << 12)
#define SYSTEM_DEVICE_IO_VALID_RX_RESTART_FAILS (1UL << 13)
#define SYSTEM_DEVICE_IO_VALID_DISCONTINUITIES (1UL << 14)
#define SYSTEM_DEVICE_IO_VALID_INTEGRITY_ERRORS (1UL << 15)
#define SYSTEM_DEVICE_IO_VALID_TIMEOUTS (1UL << 16)
#define SYSTEM_DEVICE_IO_VALID_TRANSPORT_ERRORS (1UL << 17)
#define SYSTEM_DEVICE_IO_VALID_SPI_ERRORS (1UL << 18)
#define SYSTEM_DEVICE_IO_VALID_SPI_TIMEOUTS (1UL << 19)
#define SYSTEM_DEVICE_IO_VALID_BUSY_TIMEOUTS (1UL << 20)
#define SYSTEM_DEVICE_IO_VALID_RX_ACTIVE (1UL << 21)

typedef struct
{
    uint32_t supported_mask;
    uint32_t valid_mask;
    SystemDeviceTransportType transport_type;
    SystemDeviceIoOwner owner;
    uint32_t rx_bytes;
    uint32_t tx_bytes;
    uint32_t rx_event_count;
    uint32_t rx_idle_event_count;
    uint32_t rx_transfer_complete_count;
    uint32_t rx_discarded_bytes;
    uint32_t uart_overrun_error_count;
    uint32_t uart_framing_error_count;
    uint32_t uart_noise_error_count;
    uint32_t uart_parity_error_count;
    uint32_t dma_error_count;
    uint32_t rx_restart_count;
    uint32_t rx_restart_failure_count;
    uint32_t rx_discontinuity_count;
    uint32_t integrity_error_count;
    uint32_t timeout_count;
    uint32_t transport_error_count;
    uint32_t spi_error_count;
    uint32_t spi_timeout_count;
    uint32_t busy_timeout_count;
    uint8_t rx_active;
} SystemDeviceIoDiagnostics;

typedef struct
{
    uint64_t timestamp_us;
    uint32_t sequence;
    float dt_s;
    float delta_theta_b_corrected[3];
    float delta_velocity_b_sculling_corrected[3];

    float body_gyro_radps[2][3];
    float body_accel_mps2[2][3];
    uint32_t quality_flags;

} SystemInertialIncrement;
# 7 "System/Inc/system_capabilities.h" 2

#define SYSTEM_CAPABILITY_IMU (1UL << 0)
#define SYSTEM_CAPABILITY_GNSS (1UL << 1)
#define SYSTEM_CAPABILITY_MAGNETOMETER (1UL << 2)
#define SYSTEM_CAPABILITY_BAROMETER (1UL << 3)
#define SYSTEM_CAPABILITY_HARDWARE_QUATERNION (1UL << 4)
#define SYSTEM_CAPABILITY_TELEMETRY (1UL << 5)
#define SYSTEM_CAPABILITY_CONSOLE (1UL << 6)
#define SYSTEM_CAPABILITY_POWER (1UL << 7)
#define SYSTEM_CAPABILITY_STORAGE (1UL << 8)
#define SYSTEM_CAPABILITY_OUTPUT (1UL << 9)

typedef struct
{
    uint32_t compiled_mask;
    uint32_t enabled_mask;
    uint32_t present_mask;
    uint32_t healthy_mask;
} SystemCapabilities;

SystemDeviceResult SystemCapabilities_Refresh(void);
void SystemCapabilities_Get(SystemCapabilities *capabilities);
uint8_t SystemCapabilities_RequiredAvailable(uint32_t required_mask);
# 5 "Targets/SilverStar_F407/Inc/target_system_config.h" 2
# 60 "Targets/SilverStar_F407/Inc/target_system_config.h"
#define SYSTEM_USER_TIME_SOURCE_ENABLE 1U



#define SYSTEM_PROFILE_REQUIRED_CAPABILITIES (SYSTEM_CAPABILITY_IMU | SYSTEM_CAPABILITY_OUTPUT)



#define SYSTEM_PROFILE_OPTIONAL_CAPABILITIES (SYSTEM_CAPABILITY_GNSS | SYSTEM_CAPABILITY_MAGNETOMETER | SYSTEM_CAPABILITY_BAROMETER | SYSTEM_CAPABILITY_HARDWARE_QUATERNION | SYSTEM_CAPABILITY_TELEMETRY | SYSTEM_CAPABILITY_CONSOLE | SYSTEM_CAPABILITY_POWER | SYSTEM_CAPABILITY_STORAGE)
# 208 "Targets/SilverStar_F407/Inc/target_system_config.h"
#define SYSTEM_SELECTED_TIME_MONOTONIC_AVAILABLE 1U
# 221 "Targets/SilverStar_F407/Inc/target_system_config.h"
#define SYSTEM_ESTIMATOR_PROCESS_ACCEL_E_STD_MPS2_VALUE SYSTEM_SELECTED_IMU_RECOMMENDED_PROCESS_ACCEL_E_STD_MPS2






#define SYSTEM_ESTIMATOR_PROCESS_ACCEL_N_STD_MPS2_VALUE SYSTEM_SELECTED_IMU_RECOMMENDED_PROCESS_ACCEL_N_STD_MPS2






#define SYSTEM_ESTIMATOR_PROCESS_ACCEL_U_STD_MPS2_VALUE SYSTEM_SELECTED_IMU_RECOMMENDED_PROCESS_ACCEL_U_STD_MPS2






#define SYSTEM_ESTIMATOR_GNSS_HORIZONTAL_STD_FLOOR_M_VALUE SYSTEM_SELECTED_GNSS_RECOMMENDED_HORIZONTAL_POSITION_STD_FLOOR_M






#define SYSTEM_ESTIMATOR_GNSS_VERTICAL_STD_FLOOR_M_VALUE SYSTEM_SELECTED_GNSS_RECOMMENDED_VERTICAL_POSITION_STD_FLOOR_M






#define SYSTEM_ESTIMATOR_GNSS_VELOCITY_STD_FLOOR_MPS_VALUE SYSTEM_SELECTED_GNSS_RECOMMENDED_VELOCITY_STD_FLOOR_MPS






#define SYSTEM_ESTIMATOR_BAROMETER_ALTITUDE_STD_M_VALUE SYSTEM_SELECTED_BAROMETER_RECOMMENDED_ALTITUDE_STD_M




#define SYSTEM_IMU_CAP_LANDING_IMPACT_DETECTION SYSTEM_SELECTED_IMU_LANDING_IMPACT_QUALIFIED



_Static_assert((0U == 0U) ||
               ((0U * 0U) != 0U),
               "Enabled magnetometer requires a selected physical provider");
# 6 "System/User/system_user_flight_config.h" 2
# 14 "System/User/system_user_flight_config.h"
#define SYSTEM_FLIGHT_ROCKET_LONGITUDINAL_AXIS SYSTEM_BODY_AXIS_Z_POSITIVE




#define SYSTEM_FLIGHT_TILT_REFERENCE SYSTEM_TILT_REFERENCE_INITIAL_AXIS
# 39 "System/User/system_user_flight_config.h"
#define SYSTEM_FLIGHT_DEPLOY_CONFIRM_MS 0U




#define SYSTEM_FLIGHT_LANDING_DETECTION_ENABLE 1U






#define SYSTEM_FLIGHT_LANDING_MODE SYSTEM_BUILD_LANDING_MODE



#define SYSTEM_FLIGHT_LANDING_BARO_TRIGGER_WINDOW_MS 1000U


#define SYSTEM_FLIGHT_LANDING_BARO_TRIGGER_MIN_SAMPLES 10U


#define SYSTEM_FLIGHT_LANDING_BARO_TRIGGER_RATE_MPS 1.0f




#define SYSTEM_FLIGHT_LANDING_CANDIDATE_DURATION_MS 3000U


#define SYSTEM_FLIGHT_LANDING_BARO_CONFIRM_RATE_MPS 0.30f


#define SYSTEM_FLIGHT_LANDING_BARO_MAX_SPAN_M 1.0f


#define SYSTEM_FLIGHT_LANDING_BARO_MIN_SAMPLES 20U


#define SYSTEM_FLIGHT_LANDING_IMU_MIN_SAMPLES 50U


#define SYSTEM_FLIGHT_LANDING_MIN_COVERAGE_PERCENT 80U




#define SYSTEM_FLIGHT_LANDING_IMPACT_INHIBIT_MS 3000U




#define SYSTEM_FLIGHT_LANDING_IMPACT_THRESHOLD_MPS2 15.0f




#define SYSTEM_FLIGHT_LANDING_SAMPLE_MAX_AGE_MS 100U
# 105 "System/User/system_user_flight_config.h"
#define SYSTEM_FLIGHT_LANDING_STILL_GYRO_THRESHOLD_RADPS 0.10f
# 115 "System/User/system_user_flight_config.h"
#define SYSTEM_FLIGHT_LANDING_STILL_ACCEL_TOLERANCE_MPS2 0.50f





#define SYSTEM_FLIGHT_LANDING_GYRO_THRESHOLD_RADPS SYSTEM_FLIGHT_LANDING_STILL_GYRO_THRESHOLD_RADPS



#define SYSTEM_FLIGHT_LANDING_ACCEL_THRESHOLD_MPS2 SYSTEM_FLIGHT_LANDING_STILL_ACCEL_TOLERANCE_MPS2





#define SYSTEM_FLIGHT_LANDING_CONFIRM_MS 5000U
# 20 "System/User/system_user_config.h" 2





#define SILVERSTAR_VERSION_MAJOR 0


#define SILVERSTAR_VERSION_MINOR 1


#define SILVERSTAR_VERSION_PATCH 2


#define SILVERSTAR_VERSION_BUILD 0


#define SILVERSTAR_LOG_BUILD_TAG "SILV0102"

#define SYSTEM_PROFILE_ID 0x0000000CUL
#define SYSTEM_PROFILE_OUTPUT_CHANNEL_COUNT 2U
# 53 "System/User/system_user_config.h"
#define SYSTEM_INDICATOR_SAFETY_ENABLE 0U
#define SYSTEM_INDICATOR_FAST_HALF_PERIOD_US 100000ULL
#define SYSTEM_INDICATOR_SLOW_HALF_PERIOD_US 500000ULL
#define SYSTEM_INDICATOR_EVENT_CONFIRM_US 500000ULL




#define SYSTEM_LOCAL_GRAVITY_MPS2 9.78f

#define SYSTEM_KF_GRAVITY_MPS2 9.78f




#define SYSTEM_ATTITUDE_POLICY SYSTEM_ATTITUDE_SOFTWARE_ALWAYS
# 82 "System/User/system_user_config.h"
#define SYSTEM_MECHANIZATION_ALGORITHM SYSTEM_BUILD_MECHANIZATION_ALGORITHM

#define SYSTEM_FUSION_ALGORITHM SYSTEM_BUILD_FUSION_ALGORITHM

# 1 "System/User/system_user_alignment_config.h" 1

#define __SYSTEM_USER_ALIGNMENT_CONFIG_H 

# 1 "System/Alignment/Inc/system_alignment.h" 1

#define __SYSTEM_ALIGNMENT_H 






#define SYSTEM_ALIGNMENT_SOURCE_COUNT 6U
#define SYSTEM_ALIGNMENT_SOURCE_ATTITUDE_ID 0U
#define SYSTEM_ALIGNMENT_SOURCE_GNSS_ORIGIN_ID 1U
#define SYSTEM_ALIGNMENT_SOURCE_BARO_ORIGIN_ID 2U
#define SYSTEM_ALIGNMENT_SOURCE_MAGNETIC_ID 3U
#define SYSTEM_ALIGNMENT_SOURCE_DUAL_GNSS_HEADING_ID 4U
#define SYSTEM_ALIGNMENT_SOURCE_EXTERNAL_ATTITUDE_ID 5U
#define SYSTEM_ALIGNMENT_SOURCE_BIT(source_id_) (1UL << (source_id_))


typedef uint32_t SystemAlignmentSourceMask;

typedef enum
{
    SYSTEM_ALIGNMENT_SOURCE_ATTITUDE = 0U,
    SYSTEM_ALIGNMENT_SOURCE_GNSS_ORIGIN = 1U,
    SYSTEM_ALIGNMENT_SOURCE_BARO_ORIGIN = 2U,
    SYSTEM_ALIGNMENT_SOURCE_MAGNETIC = 3U,
    SYSTEM_ALIGNMENT_SOURCE_DUAL_GNSS_HEADING =
        4U,
    SYSTEM_ALIGNMENT_SOURCE_EXTERNAL_ATTITUDE =
        5U
} SystemAlignmentSourceId;

#define SYSTEM_ALIGNMENT_SOURCE_MASK_ATTITUDE SYSTEM_ALIGNMENT_SOURCE_BIT(SYSTEM_ALIGNMENT_SOURCE_ATTITUDE_ID)

#define SYSTEM_ALIGNMENT_SOURCE_MASK_GNSS_ORIGIN SYSTEM_ALIGNMENT_SOURCE_BIT(SYSTEM_ALIGNMENT_SOURCE_GNSS_ORIGIN_ID)

#define SYSTEM_ALIGNMENT_SOURCE_MASK_BARO_ORIGIN SYSTEM_ALIGNMENT_SOURCE_BIT(SYSTEM_ALIGNMENT_SOURCE_BARO_ORIGIN_ID)

#define SYSTEM_ALIGNMENT_SOURCE_MASK_MAGNETIC SYSTEM_ALIGNMENT_SOURCE_BIT(SYSTEM_ALIGNMENT_SOURCE_MAGNETIC_ID)

#define SYSTEM_ALIGNMENT_SOURCE_MASK_DUAL_GNSS_HEADING SYSTEM_ALIGNMENT_SOURCE_BIT(SYSTEM_ALIGNMENT_SOURCE_DUAL_GNSS_HEADING_ID)

#define SYSTEM_ALIGNMENT_SOURCE_MASK_EXTERNAL_ATTITUDE SYSTEM_ALIGNMENT_SOURCE_BIT(SYSTEM_ALIGNMENT_SOURCE_EXTERNAL_ATTITUDE_ID)

#define SYSTEM_ALIGNMENT_SOURCE_MASK_DEFINED ((1UL << SYSTEM_ALIGNMENT_SOURCE_COUNT) - 1UL)

#define SYSTEM_ALIGNMENT_AIR_PROFILE_0_SOURCE_MASK (SYSTEM_ALIGNMENT_SOURCE_MASK_ATTITUDE | SYSTEM_ALIGNMENT_SOURCE_MASK_GNSS_ORIGIN | SYSTEM_ALIGNMENT_SOURCE_MASK_BARO_ORIGIN)




#define SYSTEM_ALIGNMENT_GUARD_VALID_ACCEL (1UL << 0)
#define SYSTEM_ALIGNMENT_GUARD_VALID_GYRO (1UL << 1)

typedef enum
{
    SYSTEM_ALIGNMENT_STATE_IDLE = 0,
    SYSTEM_ALIGNMENT_STATE_COLLECTING,
    SYSTEM_ALIGNMENT_STATE_CHECKING,
    SYSTEM_ALIGNMENT_STATE_READY,
    SYSTEM_ALIGNMENT_STATE_FAILED,
    SYSTEM_ALIGNMENT_STATE_STALE
} SystemAlignmentState;

typedef enum
{
    SYSTEM_ALIGNMENT_STALE_REASON_NONE = 0U,
    SYSTEM_ALIGNMENT_STALE_REASON_MOTION
} SystemAlignmentStaleReason;

typedef enum
{
    SYSTEM_ALIGNMENT_COMPONENT_NOT_READY = 0,
    SYSTEM_ALIGNMENT_COMPONENT_COLLECTING,
    SYSTEM_ALIGNMENT_COMPONENT_READY,
    SYSTEM_ALIGNMENT_COMPONENT_FAILED,
    SYSTEM_ALIGNMENT_COMPONENT_DISABLED
} SystemAlignmentComponentState;

typedef enum
{
    SYSTEM_ALIGNMENT_CONFIG_OK = 0U,
    SYSTEM_ALIGNMENT_CONFIG_REQUIRED_NOT_SELECTED,
    SYSTEM_ALIGNMENT_CONFIG_REQUIRED_UNAVAILABLE,
    SYSTEM_ALIGNMENT_CONFIG_ADAPTER_UNAVAILABLE
} SystemAlignmentConfigResult;

typedef enum
{
    SYSTEM_ALIGNMENT_ATTITUDE_SOURCE_NONE = 0,
    SYSTEM_ALIGNMENT_ATTITUDE_SOURCE_HARDWARE_QUATERNION,
    SYSTEM_ALIGNMENT_ATTITUDE_SOURCE_GRAVITY_KNOWN_YAW,
    SYSTEM_ALIGNMENT_ATTITUDE_SOURCE_GRAVITY_MAG_TRIAD,
    SYSTEM_ALIGNMENT_ATTITUDE_SOURCE_VECTOR_CONSTRAINTS
} SystemAlignmentAttitudeSource;

typedef enum
{
    SYSTEM_ALIGNMENT_PREFLIGHT_ATTITUDE_HARDWARE = 0,
    SYSTEM_ALIGNMENT_PREFLIGHT_ATTITUDE_ALIGNMENT
} SystemAlignmentPreflightAttitudeSource;

typedef struct
{
    SystemAlignmentSourceId source_id;
    const char *key;
    SystemAlignmentSourceMask bit;
} SystemAlignmentSourceDescriptor;

typedef struct
{
    uint64_t timestamp_us;
    uint64_t receive_timestamp_us;
    uint32_t sequence;
    const char *device_name;
    SystemAlignmentComponentState state;
    SystemAlignmentAttitudeSource source;
    SystemAlignmentAlgorithm algorithm;
    float quaternion_wxyz[4];
    float acceleration_mean_b_mps2[3];
    float gyro_mean_b_radps[3];
    float magnetic_field_mean_b_uT[3];
    float final_yaw_deg;
    float known_yaw_deg;
    float magnetic_declination_deg;
    uint64_t window_start_timestamp_us;
    uint64_t window_end_timestamp_us;
    uint32_t sample_count;
    uint32_t reject_count;
    uint8_t attitude_ready;
    uint8_t quaternion_valid;
    uint8_t final_quaternion_frozen;
} SystemAlignmentAttitudeStatus;

typedef struct
{
    uint64_t observation_timestamp_us;
    uint64_t inertial_sample_timestamp_us;
    uint64_t inertial_receive_timestamp_us;
    uint32_t inertial_sequence;
    float corrected_accel_b_mps2[3];
    float corrected_gyro_b_radps[3];
    uint32_t valid_mask;
} SystemAlignmentGuardSample;

typedef struct
{
    int32_t origin_lat_e7;
    int32_t origin_lon_e7;
    int32_t origin_height_mm;
    uint32_t sample_count;
    const char *device_name;
    float horizontal_accuracy_m;
    float vertical_accuracy_m;
    SystemAlignmentComponentState state;
    uint8_t supported;
    uint8_t origin_valid;
    uint8_t ready;
} SystemAlignmentGnssStatus;

typedef struct
{
    uint32_t sample_count;
    const char *device_name;
    float origin_pressure_pa;
    float origin_altitude_m;
    SystemAlignmentComponentState state;
    uint8_t supported;
    uint8_t origin_valid;
    uint8_t ready;
} SystemAlignmentBarometerStatus;

typedef union
{
    SystemAlignmentAttitudeStatus attitude;
    SystemAlignmentGnssStatus gnss;
    SystemAlignmentBarometerStatus barometer;
} SystemAlignmentSourceDetail;

typedef struct
{
    SystemAlignmentSourceDetail detail;
    SystemAlignmentComponentState state;
    uint8_t supported;
    uint8_t selected;
    uint8_t required;
    uint8_t ready;
} SystemAlignmentSourceStatus;

typedef struct
{
    SystemAlignmentSourceStatus component[6U];
    uint32_t start_sequence;
    SystemAlignmentSourceMask capability_mask;
    SystemAlignmentSourceMask selected_mask;
    SystemAlignmentSourceMask required_mask;
    SystemAlignmentSourceMask ready_mask;
    SystemAlignmentSourceMask unavailable_mask;
    SystemAlignmentSourceMask missing_adapter_mask;
    SystemAlignmentState state;
    SystemAlignmentStaleReason stale_reason;
    SystemAlignmentConfigResult config_result;
    uint8_t ready;
} SystemAlignmentStatus;

typedef struct
{
    uint32_t start_sequence;
    SystemAlignmentSourceMask selected_mask;
    SystemAlignmentSourceMask required_mask;
    SystemAlignmentSourceMask ready_mask;
    SystemAlignmentState state;
    SystemAlignmentStaleReason stale_reason;
    SystemAlignmentPreflightAttitudeSource preflight_attitude_source;
    uint8_t ready;
} SystemAlignmentSummary;

void SystemAlignment_Init(void);
__attribute__((warn_unused_result)) SystemDeviceResult SystemAlignment_Start(void);
__attribute__((warn_unused_result)) SystemDeviceResult SystemAlignment_Stop(void);
__attribute__((warn_unused_result)) SystemDeviceResult SystemAlignment_Process(void);
__attribute__((warn_unused_result)) SystemDeviceResult SystemAlignment_StatusGet(
    SystemAlignmentStatus *status);
__attribute__((warn_unused_result)) SystemDeviceResult SystemAlignment_DetailGet(
    SystemAlignmentStatus *detail);
__attribute__((warn_unused_result)) SystemDeviceResult SystemAlignment_SummaryGet(
    SystemAlignmentSummary *summary);
uint8_t SystemAlignment_IsReady(void);
__attribute__((warn_unused_result)) SystemDeviceResult
SystemAlignment_PreflightQuaternionGet(
    float quaternion_wxyz[4],
    SystemAlignmentPreflightAttitudeSource *source);
__attribute__((warn_unused_result)) SystemDeviceResult SystemAlignment_Reset(void);
__attribute__((warn_unused_result)) SystemDeviceResult
SystemAlignment_CalibrationInvalidate(void);


__attribute__((warn_unused_result)) SystemDeviceResult SystemAlignment_CalibrationYield(void);
__attribute__((warn_unused_result)) SystemDeviceResult SystemAlignment_PrepareMission(void);
__attribute__((warn_unused_result)) SystemDeviceResult SystemAlignment_OriginsFreeze(void);
void SystemAlignment_MissionPreparationAbort(void);
uint8_t SystemAlignment_IsCollecting(void);
SystemAlignmentSourceMask SystemAlignment_CapabilityMaskGet(void);
SystemAlignmentConfigResult SystemAlignment_MasksValidate(
    SystemAlignmentSourceMask capability_mask,
    SystemAlignmentSourceMask selected_mask,
    SystemAlignmentSourceMask required_mask,
    SystemAlignmentSourceMask *unavailable_mask);
const SystemAlignmentSourceDescriptor *SystemAlignment_SourceDescriptorGet(
    SystemAlignmentSourceId source_id);
const SystemAlignmentSourceStatus *SystemAlignment_SourceStatusGet(
    const SystemAlignmentStatus *status,
    SystemAlignmentSourceId source_id);
__attribute__((warn_unused_result)) SystemDeviceResult SystemAlignment_SourceDetailFormat(
    const SystemAlignmentStatus *status,
    SystemAlignmentSourceId source_id,
    char *text,
    uint16_t capacity);
const char *SystemAlignment_StateText(SystemAlignmentState state);
const char *SystemAlignment_StaleReasonText(
    SystemAlignmentStaleReason reason);
const char *SystemAlignment_ComponentStateText(
    SystemAlignmentComponentState state);
const char *SystemAlignment_ConfigResultText(
    SystemAlignmentConfigResult result);
const char *SystemAlignment_AttitudeSourceText(
    SystemAlignmentAttitudeSource source);
# 5 "System/User/system_user_alignment_config.h" 2
# 28 "System/User/system_user_alignment_config.h"
#define SYSTEM_ALIGNMENT_ALGORITHM SYSTEM_ALIGNMENT_BUILD_ALGORITHM
# 54 "System/User/system_user_alignment_config.h"
#define SYSTEM_ALIGNMENT_KNOWN_YAW_BODY_AXIS 1




#define SYSTEM_ALIGNMENT_MAGNETIC_DECLINATION_DEG 0.0f



#define SYSTEM_ALIGNMENT_WINDOW_MIN_SAMPLES 100U
#define SYSTEM_ALIGNMENT_WINDOW_MAX_SAMPLES 128U
#define SYSTEM_ALIGNMENT_WINDOW_MIN_DURATION_US 500000ULL
#define SYSTEM_ALIGNMENT_WINDOW_MAX_GAP_US 50000ULL
#define SYSTEM_ALIGNMENT_MAX_GYRO_RADPS 0.10f
#define SYSTEM_ALIGNMENT_ACCEL_TOLERANCE_MPS2 0.50f
#define SYSTEM_ALIGNMENT_MAX_QUAT_DEVIATION_RAD 0.0872664626f
#define SYSTEM_ALIGNMENT_MAX_TILT_ERROR_RAD 0.0872664626f


#define SYSTEM_ALIGNMENT_MAG_MIN_UT 10.0f
#define SYSTEM_ALIGNMENT_MAG_MAX_UT 100.0f
#define SYSTEM_ALIGNMENT_MAG_MAX_MAGNITUDE_DEVIATION_RATIO 0.20f
#define SYSTEM_ALIGNMENT_MAG_DIRECTION_MIN_DOT 0.90f
#define SYSTEM_ALIGNMENT_MAG_HORIZONTAL_MIN_RATIO 0.10f
# 95 "System/User/system_user_alignment_config.h"
#define SYSTEM_USER_ALIGNMENT_GUARD_ENABLE 1U
#define SYSTEM_USER_ALIGNMENT_GUARD_GYRO_THRESHOLD_RADPS 0.05f
#define SYSTEM_USER_ALIGNMENT_GUARD_ACCEL_TOLERANCE_MPS2 0.50f
#define SYSTEM_USER_ALIGNMENT_GUARD_ATTITUDE_DELTA_RAD 0.034906585f
#define SYSTEM_USER_ALIGNMENT_GUARD_CONFIRM_DURATION_US 100000ULL
#define SYSTEM_USER_ALIGNMENT_GUARD_SAMPLE_FRESHNESS_US 100000ULL
# 87 "System/User/system_user_config.h" 2




#define SYSTEM_HARDWARE_QUATERNION_OUTPUT_RATE_HZ 200U



#define SYSTEM_GNSS_CONSTELLATION_MASK (SYSTEM_GNSS_CONSTELLATION_GPS | SYSTEM_GNSS_CONSTELLATION_BDS | SYSTEM_GNSS_CONSTELLATION_GALILEO)







#define SYSTEM_GNSS_OUTPUT_PROTOCOL SYSTEM_GNSS_OUTPUT_PROTOCOL_UBX

#define SYSTEM_GNSS_ENABLED_MESSAGE_MASK SYSTEM_GNSS_MESSAGE_NAV_PVT







#define SYSTEM_GNSS_MIN_SATELLITES 6U
#define SYSTEM_GNSS_MAX_HORIZONTAL_ACCURACY_M 5.0f
#define SYSTEM_GNSS_MAX_VERTICAL_ACCURACY_M 10.0f
#define SYSTEM_GNSS_MAX_SPEED_ACCURACY_MPS 2.0f
#define SYSTEM_GNSS_MAX_SAMPLE_AGE_MS 500U

#define SYSTEM_MAGNETOMETER_OUTPUT_RATE_HZ 200U


#define SYSTEM_BAROMETER_OUTPUT_RATE_HZ 200U





#define SYSTEM_MECHANIZATION_SAMPLE_RATE_MIN_HZ 50U
#define SYSTEM_MECHANIZATION_SAMPLE_RATE_MAX_HZ 500U
#define SYSTEM_MECHANIZATION_DT_TOLERANCE_RATIO 0.35f
#define SYSTEM_KF_PREDICTION_DT_MAX_S 0.10f
#define SYSTEM_ESTIMATOR_MEASUREMENT_MAX_AGE_US 500000ULL
#define SYSTEM_IMU_BIAS_SETTLE_TIME_US 1000000ULL
#define SYSTEM_IMU_BIAS_MIN_VALID_SAMPLES 190U
#define SYSTEM_IMU_BIAS_MIN_DURATION_US 900000ULL
#define SYSTEM_IMU_BIAS_MAX_GYRO_RADPS 0.05f
#define SYSTEM_IMU_BIAS_ACCEL_TOLERANCE_MPS2 0.50f
#define SYSTEM_IMU_BIAS_MAX_SAMPLE_GAP_US 50000ULL
#define SYSTEM_IMU_BIAS_ACCEL_VARIANCE_MAX_M2PS4 0.040f
#define SYSTEM_IMU_BIAS_GYRO_VARIANCE_MAX_RAD2PS2 0.0001f
#define SYSTEM_IMU_BIAS_REPORT_PERIOD_US 1000000ULL
#define SYSTEM_IMU_CAL_ACCEL_SCALE_MIN 0.5f
#define SYSTEM_IMU_CAL_ACCEL_SCALE_MAX 1.5f
#define SYSTEM_INS_AUXILIARY_SAMPLE_MAX_AGE_US 50000ULL


#define SYSTEM_ESTIMATOR_P0_POSITION_E_VARIANCE_M2 4.0f


#define SYSTEM_ESTIMATOR_P0_POSITION_N_VARIANCE_M2 4.0f


#define SYSTEM_ESTIMATOR_P0_POSITION_U_VARIANCE_M2 9.0f


#define SYSTEM_ESTIMATOR_P0_VELOCITY_E_VARIANCE_M2PS2 0.25f


#define SYSTEM_ESTIMATOR_P0_VELOCITY_N_VARIANCE_M2PS2 0.25f


#define SYSTEM_ESTIMATOR_P0_VELOCITY_U_VARIANCE_M2PS2 0.25f

#define SYSTEM_ESTIMATOR_GNSS_ACCURACY_SCALE 1.25f


#define SYSTEM_ESTIMATOR_NIS_3D_SOFT_THRESHOLD 11.345f


#define SYSTEM_ESTIMATOR_NIS_3D_HARD_THRESHOLD 16.266f


#define SYSTEM_ESTIMATOR_NIS_2D_SOFT_THRESHOLD 9.210f


#define SYSTEM_ESTIMATOR_NIS_2D_HARD_THRESHOLD 13.816f



#define SYSTEM_ESTIMATOR_NIS_SOFT_ENABLED 1U


#define SYSTEM_ESTIMATOR_NIS_HARD_ENABLED 1U


#define SYSTEM_ESTIMATOR_NIS_1D_SOFT_THRESHOLD 6.635f


#define SYSTEM_ESTIMATOR_NIS_1D_HARD_THRESHOLD 10.828f


#define SYSTEM_ESTIMATOR_NIS_MAX_R_SCALE 10.0f

#define SYSTEM_ESTIMATOR_P_DIAGONAL_MIN 1.0e-8f
#define SYSTEM_ESTIMATOR_MATRIX_EPSILON 1.0e-9f
#define SYSTEM_ESTIMATOR_GNSS_ORIGIN_WINDOW_SAMPLES 100U

#define SYSTEM_BUILD_GNSS_ORIGIN_AVAILABLE 1U


#define SYSTEM_BUILD_POWER_IMPLEMENTATION_AVAILABLE 1U


#define SYSTEM_BUILD_GNSS_ORIGIN_STORAGE_SAMPLES SYSTEM_ESTIMATOR_GNSS_ORIGIN_WINDOW_SAMPLES


#define SYSTEM_ESTIMATOR_BARO_ORIGIN_WINDOW_SAMPLES 100U
#define SYSTEM_ESTIMATOR_ORIGIN_MIN_INLIERS 80U
#define SYSTEM_ESTIMATOR_GNSS_ORIGIN_MAX_AGE_US 1000000ULL
#define SYSTEM_ESTIMATOR_BARO_ORIGIN_MAX_AGE_US 500000ULL
#define SYSTEM_ESTIMATOR_GNSS_FUSION_REQUIRES_PREFLIGHT_ORIGIN 1U
#define SYSTEM_ESTIMATOR_GNSS_HORIZONTAL_OUTLIER_FLOOR_M 3.0f
#define SYSTEM_ESTIMATOR_GNSS_VERTICAL_OUTLIER_FLOOR_M 5.0f
#define SYSTEM_ESTIMATOR_BARO_OUTLIER_FLOOR_M 2.0f
#define SYSTEM_ESTIMATOR_ORIGIN_FREEZE_WAIT_MS 20U




#define SYSTEM_ESTIMATOR_GNSS_REACQUIRE_OUTAGE_MS 300U


#define SYSTEM_ESTIMATOR_GNSS_VELOCITY_VERTICAL_SCALE 1.0f

#define SYSTEM_ESTIMATOR_GNSS_REACQUIRE_ENABLE 1U
#define SYSTEM_ESTIMATOR_GNSS_REACQUIRE_REJECT_COUNT 5U
#define SYSTEM_ESTIMATOR_GNSS_REACQUIRE_CONSISTENT_COUNT 3U
#define SYSTEM_ESTIMATOR_GNSS_REACQUIRE_ACCEPT_COUNT 3U
#define SYSTEM_ESTIMATOR_GNSS_REACQUIRE_INFLATION_FACTOR 2.0f
#define SYSTEM_ESTIMATOR_GNSS_REACQUIRE_INFLATION_INTERVAL_SAMPLES 5U
#define SYSTEM_ESTIMATOR_GNSS_REACQUIRE_MAX_ATTEMPTS 8U
#define SYSTEM_ESTIMATOR_GNSS_REACQUIRE_MIN_DT_MS 10U
#define SYSTEM_ESTIMATOR_GNSS_REACQUIRE_MAX_DT_MS 1000U
#define SYSTEM_ESTIMATOR_GNSS_REACQUIRE_POSITION_HORIZONTAL_FLOOR_M 3.0f
#define SYSTEM_ESTIMATOR_GNSS_REACQUIRE_POSITION_VERTICAL_FLOOR_M 5.0f
#define SYSTEM_ESTIMATOR_GNSS_REACQUIRE_UNCERTAINTY_SCALE 2.0f
#define SYSTEM_ESTIMATOR_GNSS_REACQUIRE_MAX_HORIZONTAL_ACCEL_MPS2 60.0f
#define SYSTEM_ESTIMATOR_GNSS_REACQUIRE_MAX_VERTICAL_ACCEL_MPS2 60.0f
#define SYSTEM_ESTIMATOR_GNSS_REACQUIRE_POSITION_VARIANCE_CAP_M2 1000000.0f
#define SYSTEM_ESTIMATOR_GNSS_REACQUIRE_VELOCITY_VARIANCE_CAP_M2PS2 10000.0f
# 262 "System/User/system_user_config.h"
#define SYSTEM_LOG_PREFLIGHT_NATIVE_ENABLE 0U


#define SYSTEM_LOG_PREFLIGHT_CORRECTED_IMU_ENABLE 0U


#define SYSTEM_POWER_SAMPLE_PERIOD_US 20000ULL
#define SYSTEM_TELEMETRY_STATUS_REPEAT_PERIOD_US 50000ULL
#define SYSTEM_TELEMETRY_COMMAND_POLICY 1U
#define SYSTEM_TELEMETRY_PREFLIGHT_STATE_ENABLE 1U
#define SYSTEM_TELEMETRY_PREFLIGHT_STATE_PERIOD_US 200000ULL
#define SYSTEM_TELEMETRY_CAPABILITY_PERIOD_US 1000000ULL
#define SYSTEM_TELEMETRY_PREFLIGHT_STATUS_PERIOD_US 1000000ULL
#define SYSTEM_TELEMETRY_STREAM_PERIOD_US 200000ULL
#define SYSTEM_LOG_SYNC_PERIOD_US 250000ULL
#define SYSTEM_LOG_RETRY_PERIOD_US 1000000ULL
#define SYSTEM_LOG_POST_LANDING_GRACE_MS 1000U

#define SYSTEM_LOG_AGGREGATION_BUFFER_SIZE 4096U


#define SYSTEM_LOG_RECORD_SLOT_SIZE 200U


#define SYSTEM_LOG_ESTIMATOR_SLOT_SIZE 240U


#define SYSTEM_LOG_RECORD_QUEUE_DEPTH 80U


#define SYSTEM_LOG_ESTIMATOR_QUEUE_DEPTH 48U

#define SYSTEM_LOG_FILE_INDEX_MAX 9999U
#define SYSTEM_LOG_PROFILE_ID 0U



#define SYSTEM_IMU_SAMPLE_BUS_DEPTH 64U

#define SYSTEM_IMU_DRAIN_MAX_SAMPLES_PER_CYCLE 32U
#define SYSTEM_LIFECYCLE_QUEUE_DEPTH 4U
#define SYSTEM_TELEMETRY_STATUS_QUEUE_DEPTH 8U
#define SYSTEM_TELEMETRY_ACK_QUEUE_DEPTH 8U
#define SYSTEM_TELEMETRY_ACK_CACHE_DEPTH 4U
#define SYSTEM_TELEMETRY_STATUS_REPEAT_COUNT 3U




#define SYSTEM_DEBUG_LOG_ENABLE 1U
#define SYSTEM_DEBUG_LOG_LINE_SIZE 320U
#define SYSTEM_DEBUG_LOG_AUTO_CRLF 1U
#define SYSTEM_DEBUG_LOG_PREFIX "LOG INFO SYSTEM "
# 353 "System/User/system_user_config.h"
# 1 "System/User/system_user_capability_validation.h" 1

#define __SYSTEM_USER_CAPABILITY_VALIDATION_H 




# 1 "System/User/system_user_platform_capabilities.h" 1

#define __SYSTEM_USER_PLATFORM_CAPABILITIES_H 



#define SYSTEM_BUILD_NAVIGATION_VERTICAL_VELOCITY_AVAILABLE 1U



#define SYSTEM_BUILD_MISSION_MONOTONIC_TIME_AVAILABLE SYSTEM_SELECTED_TIME_MONOTONIC_AVAILABLE
# 8 "System/User/system_user_capability_validation.h" 2


#define SYSTEM_USER_ENABLE_IS_BOOLEAN(enable_) (((enable_) == 0U) || ((enable_) == 1U))


_Static_assert((((1U) == 0U) || ((1U) == 1U)),
               "IMU enable must be boolean");
_Static_assert((((1U) == 0U) || ((1U) == 1U)),
               "GNSS enable must be boolean");
_Static_assert((((0U) == 0U) || ((0U) == 1U))
                                                   ,
               "Magnetometer enable must be boolean");
_Static_assert((((0U) == 0U) || ((0U) == 1U)),
               "Barometer enable must be boolean");
_Static_assert((((1U) == 0U) || ((1U) == 1U))
                                                          ,
               "Hardware quaternion enable must be boolean");
_Static_assert((((1U) == 0U) || ((1U) == 1U)),
               "Telemetry enable must be boolean");
_Static_assert((((1U) == 0U) || ((1U) == 1U)),
               "Console enable must be boolean");
_Static_assert((((1U) == 0U) || ((1U) == 1U)),
               "Power enable must be boolean");
_Static_assert((((1U) == 0U) || ((1U) == 1U)),
               "Storage enable must be boolean");
_Static_assert((((1U) == 0U) || ((1U) == 1U)),
               "Output enable must be boolean");
_Static_assert((((1U) == 0U) || ((1U) == 1U)),
               "Log sink enable must be boolean");
_Static_assert((1U == 0U) ||
               (1U != 0U),
               "The selected file log sink requires storage");

_Static_assert(1U == 1U,
               "SilverStar requires one selected primary IMU");
_Static_assert(1U == 1U,
               "SilverStar requires one monotonic time source");


#define SYSTEM_BUILD_ESTIMATOR_NOISE_CONTRACT_ENABLED 1U





_Static_assert(
    1U != 0U,
    "Selected IMU needs estimator noise recommendations or all E/N/U overrides");





_Static_assert(
    (1U == 0U) ||
    (1U != 0U),
    "Selected GNSS needs estimator floor recommendations or all floor overrides");



_Static_assert(
    (0U == 0U) ||
    (0U != 0U),
    "Selected Barometer needs an estimator noise recommendation or override");



_Static_assert((SYSTEM_ALIGNMENT_VECTOR_CONSTRAINTS !=
                SYSTEM_ALIGNMENT_GRAVITY_KNOWN_YAW) ||
               ((1U != 0U) &&
                (1U != 0U) &&
                (1U != 0U)),
               "Gravity Known Yaw requires qualified accel/gyro software alignment");

_Static_assert((SYSTEM_ALIGNMENT_VECTOR_CONSTRAINTS !=
                SYSTEM_ALIGNMENT_GRAVITY_MAG_TRIAD) ||
               ((1U != 0U) &&
                (1U != 0U) &&
                (1U != 0U) &&
                (0U != 0U) &&
                ((0U * 0U) != 0U) &&
                ((0U * 0U) != 0U)),
               "TRIAD requires an enabled, absolute-vector-qualified magnetometer");

_Static_assert((SYSTEM_ALIGNMENT_VECTOR_CONSTRAINTS !=
                SYSTEM_ALIGNMENT_VECTOR_CONSTRAINTS) ||
               ((1U != 0U) &&
                (1U != 0U) &&
                (1U != 0U)),
               "Vector Constraints requires qualified inertial samples");
_Static_assert((SYSTEM_ALIGNMENT_VECTOR_CONSTRAINTS !=
                SYSTEM_ALIGNMENT_VECTOR_CONSTRAINTS) ||
               (0U == 0U) ||
               ((0U != 0U) &&
                ((0U * 0U) != 0U) &&
                ((0U * 0U) != 0U)),
               "Magnetic Vector Constraint needs a qualified magnetometer");

_Static_assert((SYSTEM_ALIGNMENT_VECTOR_CONSTRAINTS !=
                SYSTEM_ALIGNMENT_HW_QUAT_6AXIS_KNOWN_YAW) ||
               ((1U != 0U) &&
                (1U != 0U) &&
                (1U != 0U)),
               "HW 6-axis alignment requires a qualified preflight source");

_Static_assert((SYSTEM_ALIGNMENT_VECTOR_CONSTRAINTS !=
                SYSTEM_ALIGNMENT_HW_QUAT_9AXIS) ||
               ((1U != 0U) &&
                (1U != 0U) &&
                (1U != 0U)),
               "HW 9-axis alignment requires a qualified preflight source");

_Static_assert((SYSTEM_ALIGNMENT_VECTOR_CONSTRAINTS !=
                SYSTEM_ALIGNMENT_EXTERNAL_ATTITUDE_SOURCE) ||
               ((1U != 0U) &&
                (1U != 0U) &&
                (((0U == 0U) &&
                  (1U != 0U)) ||
                 ((0U != 0U) &&
                  (1U != 0U)))),
               "External attitude needs a qualified quaternion and yaw mode");
# 142 "System/User/system_user_capability_validation.h"
_Static_assert(((((1UL << (0U))) &
                 (1UL << (2U))) == 0U) ||
               ((0U != 0U) &&
                (0U != 0U) &&
                (0U != 0U)),
               "Required Barometer origin needs a qualified altitude source");


_Static_assert(((((1UL << (0U))) &
                 (1UL << (1U))) == 0U) ||
               ((1U != 0U) &&
                (1U != 0U)),
               "Required GNSS origin needs a selected position source");

_Static_assert((1U == 0U) ||
               (SYSTEM_LANDING_MODE_STILLNESS != SYSTEM_LANDING_MODE_STILLNESS) ||
               ((1U != 0U) &&
                (1U != 0U) &&
                (1U != 0U)),
               "Stillness landing requires a stillness-qualified IMU");

_Static_assert((1U == 0U) ||
               (SYSTEM_LANDING_MODE_STILLNESS !=
                SYSTEM_LANDING_MODE_IMPACT_THEN_STILLNESS) ||
               ((1U != 0U) &&
                (1U != 0U) &&
                (1U != 0U) &&
                (0U != 0U)),
               "Impact landing requires stillness- and impact-qualified IMU data");

_Static_assert((1U == 0U) ||
               (SYSTEM_LANDING_MODE_STILLNESS !=
                SYSTEM_LANDING_MODE_BARO_IMU_WINDOW) ||
               ((1U != 0U) &&
                (1U != 0U) &&
                (1U != 0U) &&
                (0U != 0U) &&
                (0U != 0U) &&
                (0U != 0U)),
               "Baro/IMU landing requires qualified IMU and direct altitude");

_Static_assert(((((1UL << 1) | (1UL << 0)) &
                 (1UL << 0)) == 0U) ||
               ((1U != 0U) &&
                (1U != 0U)),
               "TILT deploy requires selected gyro software propagation");

_Static_assert(((((1UL << 1) | (1UL << 0)) &
                 (1UL << 1)) == 0U) ||
               (1U != 0U),
               "APOGEE_VZ deploy requires navigation vertical velocity");

_Static_assert(((((1UL << 1) | (1UL << 0)) &
                 (1UL << 2)) == 0U) ||
               (1U != 0U),
               "DELAY deploy requires mission monotonic time");

_Static_assert((1U != 0U) &&
               (1U != 0U),
               "The current flight profile requires a START action");
_Static_assert((((1UL << 1) | (1UL << 0)) == 0U) ||
               ((1U != 0U) &&
                (1U != 0U)),
               "Automatic deploy requires a parachute-deploy Mission Action");
# 354 "System/User/system_user_config.h" 2
# 5 "System/Inc/system_version.h" 2

#define SILVERSTAR_STRINGIFY_INNER(x) #x
#define SILVERSTAR_STRINGIFY(x) SILVERSTAR_STRINGIFY_INNER(x)
#define SILVERSTAR_VERSION_STRING SILVERSTAR_STRINGIFY(SILVERSTAR_VERSION_MAJOR) "." SILVERSTAR_STRINGIFY(SILVERSTAR_VERSION_MINOR) "." SILVERSTAR_STRINGIFY(SILVERSTAR_VERSION_PATCH)



#define SILVERSTAR_PRODUCT_STRING "SilverStar " SILVERSTAR_VERSION_STRING



#define SILVERSTAR_BUILD_IDENTITY_FIELDS ""
# 2 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 2
# 1 "Interfaces/Inc/system_gnss_if.h" 1

#define __SYSTEM_GNSS_IF_H 

# 1 "Interfaces/Inc/system_device_types.h" 1
# 5 "Interfaces/Inc/system_gnss_if.h" 2

#define SYSTEM_GNSS_VEL_VALID_E (1U << 0)
#define SYSTEM_GNSS_VEL_VALID_N (1U << 1)
#define SYSTEM_GNSS_VEL_VALID_U (1U << 2)

#define SYSTEM_GNSS_FIELD_FIX_TYPE (1UL << 0)
#define SYSTEM_GNSS_FIELD_FIX_OK (1UL << 1)
#define SYSTEM_GNSS_FIELD_SATELLITE_COUNT (1UL << 2)
#define SYSTEM_GNSS_FIELD_POSITION (1UL << 3)
#define SYSTEM_GNSS_FIELD_HEIGHT (1UL << 4)
#define SYSTEM_GNSS_FIELD_HORIZONTAL_ACCURACY (1UL << 5)
#define SYSTEM_GNSS_FIELD_VERTICAL_ACCURACY (1UL << 6)
#define SYSTEM_GNSS_FIELD_VELOCITY_HORIZONTAL (1UL << 7)
#define SYSTEM_GNSS_FIELD_VELOCITY_VERTICAL (1UL << 8)
#define SYSTEM_GNSS_FIELD_SPEED_ACCURACY (1UL << 9)

#define SYSTEM_GNSS_REJECT_OFFLINE (1UL << 0)
#define SYSTEM_GNSS_REJECT_NO_FIX (1UL << 1)
#define SYSTEM_GNSS_REJECT_FIX_FLAG (1UL << 2)
#define SYSTEM_GNSS_REJECT_FIX_TYPE (1UL << 3)
#define SYSTEM_GNSS_REJECT_SATELLITES (1UL << 4)
#define SYSTEM_GNSS_REJECT_HACC (1UL << 5)
#define SYSTEM_GNSS_REJECT_VACC (1UL << 6)
#define SYSTEM_GNSS_REJECT_SACC (1UL << 7)
#define SYSTEM_GNSS_REJECT_STALE (1UL << 8)
#define SYSTEM_GNSS_REJECT_FIELD_INVALID (1UL << 9)
#define SYSTEM_GNSS_REJECT_FIELD_UNSUPPORTED (1UL << 10)

#define SYSTEM_GNSS_CAP_POSITION (1UL << 0)
#define SYSTEM_GNSS_CAP_VELOCITY_2D (1UL << 1)
#define SYSTEM_GNSS_CAP_VELOCITY_3D (1UL << 2)
#define SYSTEM_GNSS_CAP_ELLIPSOID_HEIGHT (1UL << 3)
#define SYSTEM_GNSS_CAP_MSL_HEIGHT (1UL << 4)
#define SYSTEM_GNSS_CAP_TIME (1UL << 5)
#define SYSTEM_GNSS_CAP_ACCURACY_FIELDS (1UL << 6)
#define SYSTEM_GNSS_CAP_CONFIG_NAV_RATE (1UL << 7)
#define SYSTEM_GNSS_CAP_DYNAMIC_MODEL (1UL << 8)
#define SYSTEM_GNSS_CAP_SATELLITE_DIAGNOSTICS (1UL << 9)
#define SYSTEM_GNSS_CAP_RF_DIAGNOSTICS (1UL << 10)
#define SYSTEM_GNSS_CAP_READ_ONLY (1UL << 11)

#define SYSTEM_GNSS_SAT_DIAG_FIELD_COUNTS (1UL << 0)
#define SYSTEM_GNSS_SAT_DIAG_FIELD_CNO (1UL << 1)
#define SYSTEM_GNSS_SAT_DIAG_FIELD_QUALITY (1UL << 2)

#define SYSTEM_GNSS_RF_DIAG_FIELD_ANTENNA (1UL << 0)
#define SYSTEM_GNSS_RF_DIAG_FIELD_JAMMING (1UL << 1)
#define SYSTEM_GNSS_RF_DIAG_FIELD_NOISE (1UL << 2)
#define SYSTEM_GNSS_RF_DIAG_FIELD_AGC (1UL << 3)

#define SYSTEM_GNSS_CONSTELLATION_GPS (1UL << 0)
#define SYSTEM_GNSS_CONSTELLATION_BDS (1UL << 1)
#define SYSTEM_GNSS_CONSTELLATION_GALILEO (1UL << 2)
#define SYSTEM_GNSS_CONSTELLATION_GLONASS (1UL << 3)

#define SYSTEM_GNSS_CFG_NAVIGATION_RATE (1UL << 0)
#define SYSTEM_GNSS_CFG_CONSTELLATIONS (1UL << 1)
#define SYSTEM_GNSS_CFG_DYNAMIC_MODEL (1UL << 2)
#define SYSTEM_GNSS_CFG_OUTPUT_PROTOCOL (1UL << 3)
#define SYSTEM_GNSS_CFG_ENABLED_MESSAGES (1UL << 4)

#define SYSTEM_GNSS_HW_CONFIG_VALID_BAUD (1UL << 0)
#define SYSTEM_GNSS_HW_CONFIG_VALID_RATE (1UL << 1)
#define SYSTEM_GNSS_HW_CONFIG_VALID_DYNAMIC (1UL << 2)
#define SYSTEM_GNSS_HW_CONFIG_VALID_CONSTELLATIONS (1UL << 3)
#define SYSTEM_GNSS_HW_CONFIG_VALID_PROTOCOL_IN (1UL << 4)
#define SYSTEM_GNSS_HW_CONFIG_VALID_PROTOCOL_OUT (1UL << 5)
#define SYSTEM_GNSS_HW_CONFIG_VALID_NAV_PVT (1UL << 6)


#define SYSTEM_GNSS_MESSAGE_NAV_PVT (1UL << 0)

typedef enum
{
    SYSTEM_GNSS_DYNAMIC_MODEL_PORTABLE = 0,
    SYSTEM_GNSS_DYNAMIC_MODEL_STATIONARY,
    SYSTEM_GNSS_DYNAMIC_MODEL_AIRBORNE_1G,
    SYSTEM_GNSS_DYNAMIC_MODEL_AIRBORNE_2G,
    SYSTEM_GNSS_DYNAMIC_MODEL_AIRBORNE_4G
} SystemGnssDynamicModel;

typedef enum
{
    SYSTEM_GNSS_OUTPUT_PROTOCOL_UBX = 0,
    SYSTEM_GNSS_OUTPUT_PROTOCOL_NMEA,
    SYSTEM_GNSS_OUTPUT_PROTOCOL_UBX_AND_NMEA
} SystemGnssOutputProtocol;

typedef enum
{
    SYSTEM_GNSS_QUALITY_POSITION_HORIZONTAL = 0U,
    SYSTEM_GNSS_QUALITY_POSITION_VERTICAL,
    SYSTEM_GNSS_QUALITY_VELOCITY_HORIZONTAL,
    SYSTEM_GNSS_QUALITY_VELOCITY_VERTICAL,
    SYSTEM_GNSS_QUALITY_GROUP_COUNT
} SystemGnssQualityGroup;

typedef struct
{
    uint64_t sample_timestamp_us;
    uint64_t receive_timestamp_us;

    uint8_t measurement_timestamp_trusted;
    uint32_t sequence;
    uint32_t supported_fields;
    uint32_t valid_fields;
    uint32_t position_reject_mask;
    uint32_t velocity_reject_mask;
    uint32_t group_reject_mask[SYSTEM_GNSS_QUALITY_GROUP_COUNT];
    uint8_t valid_group_mask;
    uint8_t physical_valid_group_mask;
    uint8_t quality_degraded_group_mask;
    int32_t latitude_e7;
    int32_t longitude_e7;
    int32_t ellipsoid_height_mm;
    int32_t msl_height_mm;
    float velocity_enu_mps[3];
    float velocity_variance_m2ps2[3];
    float horizontal_accuracy_m;
    float vertical_accuracy_m;
    float speed_accuracy_mps;
    uint8_t velocity_valid_mask;
    uint8_t fix_type;
    uint8_t fix_ok;
    uint8_t satellite_count;
    uint8_t position_usable;
    uint8_t course_usable;
    uint8_t online;
    uint8_t quality_degraded;
} SystemGnssSample;

typedef struct
{
    uint32_t requested_mask;
    uint32_t required_mask;
    uint16_t navigation_rate_hz;
    uint32_t constellation_mask;
    SystemGnssDynamicModel dynamic_model;
    SystemGnssOutputProtocol output_protocol;
    uint32_t enabled_message_mask;
} SystemGnssConfig;

typedef enum
{
    SYSTEM_GNSS_CONFIG_READ_RESPONSE_OK = 0,
    SYSTEM_GNSS_CONFIG_READ_NAK,
    SYSTEM_GNSS_CONFIG_READ_TX_ERROR,
    SYSTEM_GNSS_CONFIG_READ_CHECKSUM_ERROR,
    SYSTEM_GNSS_CONFIG_READ_MALFORMED_RESPONSE,
    SYSTEM_GNSS_CONFIG_READ_TIMEOUT,
    SYSTEM_GNSS_CONFIG_READ_NOT_READY,
    SYSTEM_GNSS_CONFIG_READ_IO_ERROR
} SystemGnssConfigReadResult;

typedef enum
{
    SYSTEM_GNSS_TRANSACTION_DETAIL_NONE = 0,
    SYSTEM_GNSS_TRANSACTION_DETAIL_RESPONSE_OK,
    SYSTEM_GNSS_TRANSACTION_DETAIL_NAK,
    SYSTEM_GNSS_TRANSACTION_DETAIL_BUSY,
    SYSTEM_GNSS_TRANSACTION_DETAIL_BAD_VERSION,
    SYSTEM_GNSS_TRANSACTION_DETAIL_BAD_LAYER,
    SYSTEM_GNSS_TRANSACTION_DETAIL_BAD_POSITION,
    SYSTEM_GNSS_TRANSACTION_DETAIL_BAD_LENGTH,
    SYSTEM_GNSS_TRANSACTION_DETAIL_KEY_MISMATCH,
    SYSTEM_GNSS_TRANSACTION_DETAIL_VALUE_LENGTH_MISMATCH,
    SYSTEM_GNSS_TRANSACTION_DETAIL_COUNT_OVERFLOW,
    SYSTEM_GNSS_TRANSACTION_DETAIL_CHECKSUM_ERROR,
    SYSTEM_GNSS_TRANSACTION_DETAIL_TX_ERROR,
    SYSTEM_GNSS_TRANSACTION_DETAIL_TIMEOUT,
    SYSTEM_GNSS_TRANSACTION_DETAIL_NOT_READY,
    SYSTEM_GNSS_TRANSACTION_DETAIL_RX_DISCONTINUITY
} SystemGnssTransactionDetail;

typedef enum
{
    SYSTEM_GNSS_CONFIG_READ_GROUP_NONE = 0,
    SYSTEM_GNSS_CONFIG_READ_GROUP_UART,
    SYSTEM_GNSS_CONFIG_READ_GROUP_PROTOCOL,
    SYSTEM_GNSS_CONFIG_READ_GROUP_NAV_PVT,
    SYSTEM_GNSS_CONFIG_READ_GROUP_RATE,
    SYSTEM_GNSS_CONFIG_READ_GROUP_DYNAMIC_MODEL,
    SYSTEM_GNSS_CONFIG_READ_GROUP_SIGNALS
} SystemGnssConfigReadGroup;

typedef struct
{
    uint32_t valid_mask;
    uint32_t baudrate;
    uint32_t constellation_mask;
    uint32_t elapsed_ms;
    uint16_t navigation_rate_hz;
    SystemGnssDynamicModel dynamic_model;
    SystemGnssOutputProtocol output_protocol;
    uint8_t protocol_in;
    uint8_t nav_pvt_rate;
    uint8_t nav_pvt_known;
    SystemGnssConfigReadResult read_result;
    SystemGnssConfigReadGroup failed_group;
    uint32_t failed_key;
    uint16_t response_length;
    uint8_t nak_class;
    uint8_t nak_id;
    uint32_t transaction_id;
    uint32_t unsupported_mask;
    SystemGnssTransactionDetail detailed_result;
    uint8_t expected_class;
    uint8_t expected_id;
    uint8_t received_class;
    uint8_t received_id;
    uint8_t response_version;
} SystemGnssHardwareConfig;

typedef enum
{
    SYSTEM_GNSS_CONFIG_STAGE_NONE = 0,
    SYSTEM_GNSS_CONFIG_STAGE_UART,
    SYSTEM_GNSS_CONFIG_STAGE_UART_SETTLE,
    SYSTEM_GNSS_CONFIG_STAGE_PROTOCOL,
    SYSTEM_GNSS_CONFIG_STAGE_NAV_PVT,
    SYSTEM_GNSS_CONFIG_STAGE_RATE,
    SYSTEM_GNSS_CONFIG_STAGE_DYNAMIC_MODEL,
    SYSTEM_GNSS_CONFIG_STAGE_SIGNALS,
    SYSTEM_GNSS_CONFIG_STAGE_PVT_RECOVERY,
    SYSTEM_GNSS_CONFIG_STAGE_VERIFY
} SystemGnssConfigStage;

typedef struct
{
    SystemDeviceResult uart_baudrate_result;
    SystemDeviceResult uart_settle_result;
    SystemDeviceResult protocol_result;
    SystemDeviceResult nav_pvt_result;
    SystemDeviceResult rate_result;
    SystemDeviceResult dynamic_model_result;
    SystemDeviceResult signals_result;
    SystemDeviceResult pvt_recovery_result;
    SystemDeviceResult verify_result;
    SystemGnssConfigStage failed_stage;
    uint32_t baseline_pvt_sequence;
    uint32_t recovered_pvt_sequence;
    uint64_t signal_complete_timestamp_us;
    uint8_t ack_result;
    uint8_t write_layers;
    SystemGnssConfigReadResult verify_read_result;
    SystemGnssConfigReadGroup verify_failed_group;
    uint32_t verify_failed_key;
    uint32_t verify_valid_mask;
    uint16_t verify_response_length;
    uint8_t verify_nak_class;
    uint8_t verify_nak_id;
    SystemGnssTransactionDetail verify_detailed_result;
    uint8_t verify_expected_class;
    uint8_t verify_expected_id;
    uint8_t verify_received_class;
    uint8_t verify_received_id;
    uint8_t verify_response_version;
} SystemGnssConfigTransactionReport;

typedef struct
{
    uint64_t sample_timestamp_us;
    uint64_t receive_timestamp_us;
    uint32_t sequence;
    uint32_t supported_fields;
    uint32_t valid_fields;
    uint8_t satellite_count;
    uint8_t used_count;
    uint8_t average_cno_dbhz;
    uint8_t maximum_cno_dbhz;
    uint8_t average_quality;
    uint8_t fresh;
    SystemGnssConfigReadResult read_result;
    SystemGnssTransactionDetail detailed_result;
    uint32_t transaction_id;
    uint16_t response_length;
    uint8_t expected_class;
    uint8_t expected_id;
    uint8_t received_class;
    uint8_t received_id;
    uint8_t expected_ck_a;
    uint8_t expected_ck_b;
    uint8_t received_ck_a;
    uint8_t received_ck_b;
} SystemGnssSatelliteDiagnostics;

typedef struct
{
    uint32_t ubx_frame_count;
    uint32_t ubx_checksum_error_count;
    uint32_t nmea_sentence_count;
    uint32_t nmea_checksum_ok_count;
    uint32_t nmea_checksum_error_count;
    uint32_t unknown_byte_count;
    uint32_t parser_resync_count;
} SystemGnssIoDetail;

typedef struct
{
    uint64_t sample_timestamp_us;
    uint64_t receive_timestamp_us;
    uint32_t sequence;
    uint32_t supported_fields;
    uint32_t valid_fields;
    uint16_t noise_per_ms;
    uint16_t agc_count;
    uint8_t rf_block_count;
    uint8_t antenna_status;
    uint8_t antenna_power;
    uint8_t jamming_state;
    uint8_t cw_suppression;

    uint8_t jamming_indicator;
    uint8_t fresh;
    SystemGnssConfigReadResult read_result;
    SystemGnssTransactionDetail detailed_result;
    uint32_t transaction_id;
    uint16_t response_length;
} SystemGnssRfDiagnostics;

typedef struct
{
    uint64_t sample_timestamp_us;
    uint64_t receive_timestamp_us;
    uint32_t sequence;
    uint32_t time_of_week_ms;
    int32_t nanosecond;
    uint32_t time_accuracy_ns;
    uint16_t year;
    uint8_t month;
    uint8_t day;
    uint8_t hour;
    uint8_t minute;
    uint8_t second;
    uint8_t date_valid;
    uint8_t time_valid;
    uint8_t fully_resolved;
} SystemGnssTime;

#define SYSTEM_GNSS_NOISE_VALID_HORIZONTAL_POSITION_STD_FLOOR (1UL << 0)
#define SYSTEM_GNSS_NOISE_VALID_VERTICAL_POSITION_STD_FLOOR (1UL << 1)
#define SYSTEM_GNSS_NOISE_VALID_VELOCITY_STD_FLOOR (1UL << 2)

typedef struct
{
    float recommended_horizontal_position_std_floor_m;
    float recommended_vertical_position_std_floor_m;
    float recommended_velocity_std_floor_mps;
    uint32_t valid_mask;
} SystemGnssNoiseCharacteristics;

const char *SystemGnss_NameGet(void);
SystemDeviceResult SystemGnss_Init(void);
SystemDeviceResult SystemGnss_Start(void);
SystemDeviceResult SystemGnss_Stop(void);
SystemDeviceResult SystemGnss_RuntimeOwnerActivate(void);
void SystemGnss_Process(void);
SystemDeviceResult SystemGnss_InfoGet(SystemDeviceInfo *info);
SystemDeviceResult SystemGnss_CapabilitiesGet(uint32_t *capability_mask);
SystemDeviceResult SystemGnss_HealthGet(SystemDeviceHealth *health);
SystemDeviceResult SystemGnss_IoDiagnosticsGet(
    SystemDeviceIoDiagnostics *diagnostics);
SystemDeviceResult SystemGnss_IoDetailGet(SystemGnssIoDetail *detail);
SystemDeviceResult SystemGnss_LatestSampleGet(SystemGnssSample *sample);
SystemDeviceResult SystemGnss_TimeGet(SystemGnssTime *time);
SystemDeviceResult SystemGnss_SelfTestRun(SystemDeviceSelfTestResult *result);
SystemDeviceResult SystemGnss_ConfigApply(const SystemGnssConfig *config,
                                          SystemDeviceConfigReport *report);
SystemDeviceResult SystemGnss_ConfigVerify(const SystemGnssConfig *config,
                                           SystemDeviceConfigReport *report);
SystemDeviceResult SystemGnss_EffectiveConfigGet(SystemGnssConfig *config);
SystemDeviceResult SystemGnss_NoiseCharacteristicsGet(
    SystemGnssNoiseCharacteristics *noise);
SystemDeviceResult SystemGnss_HardwareConfigRead(
    SystemGnssHardwareConfig *config);
SystemDeviceResult SystemGnss_LastConfigReportGet(
    SystemGnssConfigTransactionReport *report);
SystemDeviceResult SystemGnss_SatelliteDiagnosticsRead(
    SystemGnssSatelliteDiagnostics *diagnostics);
SystemDeviceResult SystemGnss_LatestSatelliteDiagnosticsGet(
    SystemGnssSatelliteDiagnostics *diagnostics);
SystemDeviceResult SystemGnss_RfDiagnosticsRead(
    SystemGnssRfDiagnostics *diagnostics);
SystemDeviceResult SystemGnss_LatestRfDiagnosticsGet(
    SystemGnssRfDiagnostics *diagnostics);
# 3 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 2

# 1 "D:/Arm GNU Toolchain/14.3 rel1/lib/gcc/arm-none-eabi/14.3.1/include/stddef.h" 1 3 4
# 39 "D:/Arm GNU Toolchain/14.3 rel1/lib/gcc/arm-none-eabi/14.3.1/include/stddef.h" 3 4
#define _STDDEF_H 
#define _STDDEF_H_ 

#define _ANSI_STDDEF_H 
# 147 "D:/Arm GNU Toolchain/14.3 rel1/lib/gcc/arm-none-eabi/14.3.1/include/stddef.h" 3 4
#define _PTRDIFF_T 
#define _T_PTRDIFF_ 
#define _T_PTRDIFF 
#define __PTRDIFF_T 
#define _PTRDIFF_T_ 
#define _BSD_PTRDIFF_T_ 
#define ___int_ptrdiff_t_h 
#define _GCC_PTRDIFF_T 
#define _PTRDIFF_T_DECLARED 
#define __DEFINED_ptrdiff_t 




# 160 "D:/Arm GNU Toolchain/14.3 rel1/lib/gcc/arm-none-eabi/14.3.1/include/stddef.h" 3 4
typedef int ptrdiff_t;
# 173 "D:/Arm GNU Toolchain/14.3 rel1/lib/gcc/arm-none-eabi/14.3.1/include/stddef.h" 3 4
#undef __need_ptrdiff_t
# 200 "D:/Arm GNU Toolchain/14.3 rel1/lib/gcc/arm-none-eabi/14.3.1/include/stddef.h" 3 4
#define __size_t__ 
#define __SIZE_T__ 
#define _SIZE_T 
#define _SYS_SIZE_T_H 
#define _T_SIZE_ 
#define _T_SIZE 
#define __SIZE_T 
#define _SIZE_T_ 
#define _BSD_SIZE_T_ 
#define _SIZE_T_DEFINED_ 
#define _SIZE_T_DEFINED 
#define _BSD_SIZE_T_DEFINED_ 
#define _SIZE_T_DECLARED 
#define __DEFINED_size_t 
#define ___int_size_t_h 
#define _GCC_SIZE_T 
#define _SIZET_ 






#define __size_t 





typedef unsigned int size_t;
# 252 "D:/Arm GNU Toolchain/14.3 rel1/lib/gcc/arm-none-eabi/14.3.1/include/stddef.h" 3 4
#undef __need_size_t
# 282 "D:/Arm GNU Toolchain/14.3 rel1/lib/gcc/arm-none-eabi/14.3.1/include/stddef.h" 3 4
#define __wchar_t__ 
#define __WCHAR_T__ 
#define _WCHAR_T 
#define _T_WCHAR_ 
#define _T_WCHAR 
#define __WCHAR_T 
#define _WCHAR_T_ 
#define _BSD_WCHAR_T_ 
#define _WCHAR_T_DEFINED_ 
#define _WCHAR_T_DEFINED 
#define _WCHAR_T_H 
#define ___int_wchar_t_h 
#define __INT_WCHAR_T_H 
#define _GCC_WCHAR_T 
#define _WCHAR_T_DECLARED 
#define __DEFINED_wchar_t 
# 310 "D:/Arm GNU Toolchain/14.3 rel1/lib/gcc/arm-none-eabi/14.3.1/include/stddef.h" 3 4
#undef _BSD_WCHAR_T_
# 344 "D:/Arm GNU Toolchain/14.3 rel1/lib/gcc/arm-none-eabi/14.3.1/include/stddef.h" 3 4
typedef unsigned int wchar_t;
# 364 "D:/Arm GNU Toolchain/14.3 rel1/lib/gcc/arm-none-eabi/14.3.1/include/stddef.h" 3 4
#undef __need_wchar_t
# 414 "D:/Arm GNU Toolchain/14.3 rel1/lib/gcc/arm-none-eabi/14.3.1/include/stddef.h" 3 4
#undef NULL




#define NULL ((void *)0)





#undef __need_NULL




#undef offsetof
#define offsetof(TYPE,MEMBER) __builtin_offsetof (TYPE, MEMBER)




#define _GCC_MAX_ALIGN_T 



typedef struct {
  long long __max_align_ll __attribute__((__aligned__(__alignof__(long long))));
  long double __max_align_ld __attribute__((__aligned__(__alignof__(long double))));
# 451 "D:/Arm GNU Toolchain/14.3 rel1/lib/gcc/arm-none-eabi/14.3.1/include/stddef.h" 3 4
} max_align_t;
# 5 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 2
# 1 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/string.h" 1 3







#define _STRING_H_ 

# 1 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/_ansi.h" 1 3







#define _ANSIDECL_H_ 

# 1 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/newlib.h" 1 3






#define __NEWLIB_H__ 1
# 27 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/newlib.h" 3
#define _ATEXIT_DYNAMIC_ALLOC 1
# 36 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/newlib.h" 3
#define _FSEEK_OPTIMIZATION 1


#define _FVWRITE_IN_STREAMIO 1


#define _HAVE_CC_INHIBIT_LOOP_TO_LIBCALL 1







#define _HAVE_INITFINI_ARRAY 1


#define _HAVE_LONG_DOUBLE 1
# 362 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/newlib.h" 3
#define _LDBL_EQ_DBL 1





#define _MB_CAPABLE 1


#define _MB_LEN_MAX 8
# 382 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/newlib.h" 3
#define _REENT_CHECK_VERIFY 1


#define _RETARGETABLE_LOCKING 1


#define _UNBUF_STREAM_OPT 1



#define _WANT_IO_C99_FORMATS 1







#define _WANT_IO_LONG_LONG 1
# 417 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/newlib.h" 3
#define _WANT_REGISTER_FINI 1


#define _WANT_USE_GDTOA 1





#define _WIDE_ORIENT 1
# 11 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/_ansi.h" 2 3
# 1 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/config.h" 1 3

#define __SYS_CONFIG_H__ 

# 1 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/machine/ieeefp.h" 1 3
# 77 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/machine/ieeefp.h" 3
#define __IEEE_LITTLE_ENDIAN 
# 91 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/machine/ieeefp.h" 3
#define _SUPPORTS_ERREXCEPT 






#define __DOUBLE_TYPE double
#define __FLOAT_TYPE float
# 523 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/machine/ieeefp.h" 3
#define __OBSOLETE_MATH_DEFAULT 1


#define __OBSOLETE_MATH __OBSOLETE_MATH_DEFAULT
# 5 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/config.h" 2 3
# 224 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/config.h" 3
#define _POINTER_INT long





#undef __RAND_MAX



#define __RAND_MAX 0x7fffffff
# 248 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/config.h" 3
#define __EXPORT 



#define __IMPORT 






#define _READ_WRITE_RETURN_TYPE int





#define _READ_WRITE_BUFSIZE_TYPE int
# 290 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/config.h" 3
#define _USE_GDTOA 
# 12 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/_ansi.h" 2 3
# 31 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/_ansi.h" 3
#define _BEGIN_STD_C 
#define _END_STD_C 
#define _NOTHROW 



#define _LONG_DOUBLE long double





#define _ATTRIBUTE(attrs) __attribute__ (attrs)
# 69 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/_ansi.h" 3
#define _ELIDABLE_INLINE static __inline__



#define _NOINLINE __attribute__ ((__noinline__))
#define _NOINLINE_STATIC _NOINLINE static
# 11 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/string.h" 2 3
# 1 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/reent.h" 1 3
# 11 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/reent.h" 3
#define _SYS_REENT_H_ 

# 1 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/_ansi.h" 1 3
# 14 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/reent.h" 2 3
# 1 "D:/Arm GNU Toolchain/14.3 rel1/lib/gcc/arm-none-eabi/14.3.1/include/stddef.h" 1 3 4
# 15 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/reent.h" 2 3
# 1 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/cdefs.h" 1 3
# 43 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/cdefs.h" 3
#define _SYS_CDEFS_H_ 



# 1 "D:/Arm GNU Toolchain/14.3 rel1/lib/gcc/arm-none-eabi/14.3.1/include/stddef.h" 1 3 4
# 48 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/cdefs.h" 2 3

#define __PMT(args) args
#define __DOTS , ...
#define __THROW 


#define __ASMNAME(cname) __XSTRING (__USER_LABEL_PREFIX__) cname


#define __ptr_t void *
#define __long_double_t long double

#define __attribute_malloc__ 
#define __attribute_pure__ 
#define __attribute_format_strfmon__(a,b) 
#define __flexarr [0]


#define __bounded 
#define __unbounded 
#define __ptrvalue 
# 94 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/cdefs.h" 3
#define __BEGIN_DECLS 
#define __END_DECLS 
# 107 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/cdefs.h" 3
#define __GNUCLIKE_ASM 3
#define __GNUCLIKE_MATH_BUILTIN_CONSTANTS 



#define __GNUCLIKE___TYPEOF 1
#define __GNUCLIKE___SECTION 1

#define __GNUCLIKE_CTOR_SECTION_HANDLING 1

#define __GNUCLIKE_BUILTIN_CONSTANT_P 1


#define __GNUCLIKE_BUILTIN_VARARGS 1
#define __GNUCLIKE_BUILTIN_STDARG 1
#define __GNUCLIKE_BUILTIN_VAALIST 1


#define __GNUC_VA_LIST_COMPATIBILITY 1




#define __compiler_membar() __asm __volatile(" " : : : "memory")

#define __GNUCLIKE_BUILTIN_NEXT_ARG 1
#define __GNUCLIKE_MATH_BUILTIN_RELOPS 

#define __GNUCLIKE_BUILTIN_MEMCPY 1


#define __CC_SUPPORTS_INLINE 1
#define __CC_SUPPORTS___INLINE 1
#define __CC_SUPPORTS___INLINE__ 1

#define __CC_SUPPORTS___FUNC__ 1
#define __CC_SUPPORTS_WARNING 1

#define __CC_SUPPORTS_VARADIC_XXX 1

#define __CC_SUPPORTS_DYNAMIC_ARRAY_INIT 1
# 164 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/cdefs.h" 3
#define __P(protos) protos
#define __CONCAT1(x,y) x ## y
#define __CONCAT(x,y) __CONCAT1(x,y)
#define __STRING(x) #x
#define __XSTRING(x) __STRING(x)

#define __const const
#define __signed signed
#define __volatile volatile
# 217 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/cdefs.h" 3
#define __weak_symbol __attribute__((__weak__))
# 230 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/cdefs.h" 3
#define __dead2 __attribute__((__noreturn__))
#define __pure2 __attribute__((__const__))
#define __unused __attribute__((__unused__))
#define __used __attribute__((__used__))
#define __packed __attribute__((__packed__))
#define __aligned(x) __attribute__((__aligned__(x)))
#define __section(x) __attribute__((__section__(x)))


#define __alloc_size(x) __attribute__((__alloc_size__(x)))
#define __alloc_size2(n,x) __attribute__((__alloc_size__(n, x)))





#define __alloc_align(x) __attribute__((__alloc_align__(x)))
# 338 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/cdefs.h" 3
#define __generic(expr,t,yes,no) _Generic(expr, t: yes, default: no)
# 356 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/cdefs.h" 3
#define __min_size(x) static (x)





#define __malloc_like __attribute__((__malloc__))
#define __pure __attribute__((__pure__))






#define __always_inline __inline__ __attribute__((__always_inline__))





#define __noinline __attribute__ ((__noinline__))





#define __nonnull(x) __attribute__((__nonnull__ x))
#define __nonnull_all __attribute__((__nonnull__))






#define __fastcall __attribute__((__fastcall__))
#define __result_use_check __attribute__((__warn_unused_result__))






#define __returns_twice __attribute__((__returns_twice__))





#define __unreachable() __builtin_unreachable()
# 421 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/cdefs.h" 3
#define __restrict restrict
# 434 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/cdefs.h" 3
#define __restrict_arr restrict
# 468 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/cdefs.h" 3
#define __predict_true(exp) __builtin_expect((exp), 1)
#define __predict_false(exp) __builtin_expect((exp), 0)






#define __null_sentinel __attribute__((__sentinel__))
#define __exported __attribute__((__visibility__("default")))


#define __hidden __attribute__((__visibility__("hidden")))
# 490 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/cdefs.h" 3
#define __offsetof(type,field) offsetof(type, field)
#define __rangeof(type,start,end) (__offsetof(type, end) - __offsetof(type, start))
# 501 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/cdefs.h" 3
#define __containerof(x,s,m) ({ const volatile __typeof(((s *)0)->m) *__x = (x); __DEQUALIFY(s *, (const volatile char *)__x - __offsetof(s, m));})
# 523 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/cdefs.h" 3
#define __printflike(fmtarg,firstvararg) __attribute__((__format__ (__printf__, fmtarg, firstvararg)))

#define __scanflike(fmtarg,firstvararg) __attribute__((__format__ (__scanf__, fmtarg, firstvararg)))

#define __format_arg(fmtarg) __attribute__((__format_arg__ (fmtarg)))
#define __strfmonlike(fmtarg,firstvararg) __attribute__((__format__ (__strfmon__, fmtarg, firstvararg)))

#define __strftimelike(fmtarg,firstvararg) __attribute__((__format__ (__strftime__, fmtarg, firstvararg)))
# 540 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/cdefs.h" 3
#define __printf0like(fmtarg,firstvararg) 



#define __strong_reference(sym,aliassym) extern __typeof (sym) aliassym __attribute__ ((__alias__ (#sym)))



#define __weak_reference(sym,alias) __asm__(".weak " #alias); __asm__(".equ " #alias ", " #sym)


#define __warn_references(sym,msg) __asm__(".section .gnu.warning." #sym); __asm__(".asciz \"" msg "\""); __asm__(".previous")



#define __sym_compat(sym,impl,verid) __asm__(".symver " #impl ", " #sym "@" #verid)

#define __sym_default(sym,impl,verid) __asm__(".symver " #impl ", " #sym "@@" #verid)
# 592 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/cdefs.h" 3
#define __FBSDID(s) struct __hack



#define __RCSID(s) struct __hack



#define __RCSID_SOURCE(s) struct __hack



#define __SCCSID(s) struct __hack



#define __COPYRIGHT(s) struct __hack



#define __DECONST(type,var) ((type)(__uintptr_t)(const void *)(var))



#define __DEVOLATILE(type,var) ((type)(__uintptr_t)(volatile void *)(var))



#define __DEQUALIFY(type,var) ((type)(__uintptr_t)(const volatile void *)(var))






#define _Nonnull 
#define _Nullable 
#define _Null_unspecified 
#define __NULLABILITY_PRAGMA_PUSH 
#define __NULLABILITY_PRAGMA_POP 
# 652 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/cdefs.h" 3
#define __arg_type_tag(arg_kind,arg_idx,type_tag_idx) 
#define __datatype_type_tag(kind,type) 
# 671 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/cdefs.h" 3
#define __lock_annotate(x) 





#define __lockable __lock_annotate(lockable)


#define __locks_exclusive(...) __lock_annotate(exclusive_lock_function(__VA_ARGS__))

#define __locks_shared(...) __lock_annotate(shared_lock_function(__VA_ARGS__))



#define __trylocks_exclusive(...) __lock_annotate(exclusive_trylock_function(__VA_ARGS__))

#define __trylocks_shared(...) __lock_annotate(shared_trylock_function(__VA_ARGS__))



#define __unlocks(...) __lock_annotate(unlock_function(__VA_ARGS__))


#define __asserts_exclusive(...) __lock_annotate(assert_exclusive_lock(__VA_ARGS__))

#define __asserts_shared(...) __lock_annotate(assert_shared_lock(__VA_ARGS__))



#define __requires_exclusive(...) __lock_annotate(exclusive_locks_required(__VA_ARGS__))

#define __requires_shared(...) __lock_annotate(shared_locks_required(__VA_ARGS__))

#define __requires_unlocked(...) __lock_annotate(locks_excluded(__VA_ARGS__))



#define __no_lock_analysis __lock_annotate(no_thread_safety_analysis)
# 726 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/cdefs.h" 3
#define __nosanitizeaddress 
#define __nosanitizememory 
#define __nosanitizethread 



#define __guarded_by(x) __lock_annotate(guarded_by(x))
#define __pt_guarded_by(x) __lock_annotate(pt_guarded_by(x))




#define __builtin_is_aligned(x,align) (((__uintptr_t)x & ((align) - 1)) == 0)



#define __builtin_align_up(x,align) ((__typeof__(x))(((__uintptr_t)(x)+((align)-1))&(~((align)-1))))



#define __builtin_align_down(x,align) ((__typeof__(x))((x)&(~((align)-1))))



#define __align_up(x,y) __builtin_align_up(x, y)
#define __align_down(x,y) __builtin_align_down(x, y)
#define __is_aligned(x,y) __builtin_is_aligned(x, y)
# 16 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/reent.h" 2 3
# 1 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/_types.h" 1 3
# 20 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/_types.h" 3
#define _SYS__TYPES_H 

#define __need_size_t 
#define __need_wint_t 
# 1 "D:/Arm GNU Toolchain/14.3 rel1/lib/gcc/arm-none-eabi/14.3.1/include/stddef.h" 1 3 4
# 173 "D:/Arm GNU Toolchain/14.3 rel1/lib/gcc/arm-none-eabi/14.3.1/include/stddef.h" 3 4
#undef __need_ptrdiff_t
# 252 "D:/Arm GNU Toolchain/14.3 rel1/lib/gcc/arm-none-eabi/14.3.1/include/stddef.h" 3 4
#undef __need_size_t
# 364 "D:/Arm GNU Toolchain/14.3 rel1/lib/gcc/arm-none-eabi/14.3.1/include/stddef.h" 3 4
#undef __need_wchar_t




#define _WINT_T 




typedef unsigned int wint_t;

#undef __need_wint_t
# 414 "D:/Arm GNU Toolchain/14.3 rel1/lib/gcc/arm-none-eabi/14.3.1/include/stddef.h" 3 4
#undef NULL




#define NULL ((void *)0)





#undef __need_NULL




#undef offsetof
#define offsetof(TYPE,MEMBER) __builtin_offsetof (TYPE, MEMBER)
# 25 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/_types.h" 2 3


# 1 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/machine/_types.h" 1 3





#define _MACHINE__TYPES_H 
# 28 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/_types.h" 2 3


typedef long __blkcnt_t;



typedef long __blksize_t;



typedef __uint64_t __fsblkcnt_t;



typedef __uint32_t __fsfilcnt_t;



typedef long _off_t;





typedef int __pid_t;



typedef short __dev_t;



typedef unsigned short __uid_t;


typedef unsigned short __gid_t;



typedef __uint32_t __id_t;







typedef unsigned short __ino_t;
# 90 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/_types.h" 3
typedef __uint32_t __mode_t;





__extension__ typedef long long _off64_t;





typedef _off_t __off_t;


typedef _off64_t __loff_t;


typedef long __key_t;







typedef long _fpos_t;
# 127 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/_types.h" 3
#undef __size_t



typedef unsigned int __size_t;
# 146 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/_types.h" 3
#define unsigned signed
typedef signed int _ssize_t;
#undef unsigned
# 158 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/_types.h" 3
typedef _ssize_t __ssize_t;



typedef struct
{
  int __count;
  union
  {
    wint_t __wch;
    unsigned char __wchb[4];
  } __value;
} _mbstate_t;




typedef void *_iconv_t;



#define _CLOCK_T_ unsigned long


typedef unsigned long __clock_t;




#define _TIME_T_ __int_least64_t

typedef __int_least64_t __time_t;


#define _CLOCKID_T_ unsigned long


typedef unsigned long __clockid_t;


typedef long __daddr_t;


#define _TIMER_T_ unsigned long
typedef unsigned long __timer_t;


typedef __uint8_t __sa_family_t;



typedef __uint32_t __socklen_t;


typedef int __nl_item;
typedef unsigned short __nlink_t;
typedef long __suseconds_t;
typedef unsigned long __useconds_t;







typedef __builtin_va_list __va_list;
# 17 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/reent.h" 2 3

#define _NULL 0



#define __Long long
typedef unsigned long __ULong;
# 35 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/reent.h" 3
# 1 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/lock.h" 1 3

#define __SYS_LOCK_H__ 
# 33 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/lock.h" 3
struct __lock;
typedef struct __lock * _LOCK_T;
#define _LOCK_RECURSIVE_T _LOCK_T

#define __LOCK_INIT(class,lock) extern struct __lock __lock_ ## lock; class _LOCK_T lock = &__lock_ ## lock

#define __LOCK_INIT_RECURSIVE(class,lock) __LOCK_INIT(class,lock)

extern void __retarget_lock_init(_LOCK_T *lock);
#define __lock_init(lock) __retarget_lock_init(&lock)
extern void __retarget_lock_init_recursive(_LOCK_T *lock);
#define __lock_init_recursive(lock) __retarget_lock_init_recursive(&lock)
extern void __retarget_lock_close(_LOCK_T lock);
#define __lock_close(lock) __retarget_lock_close(lock)
extern void __retarget_lock_close_recursive(_LOCK_T lock);
#define __lock_close_recursive(lock) __retarget_lock_close_recursive(lock)
extern void __retarget_lock_acquire(_LOCK_T lock);
#define __lock_acquire(lock) __retarget_lock_acquire(lock)
extern void __retarget_lock_acquire_recursive(_LOCK_T lock);
#define __lock_acquire_recursive(lock) __retarget_lock_acquire_recursive(lock)
extern int __retarget_lock_try_acquire(_LOCK_T lock);
#define __lock_try_acquire(lock) __retarget_lock_try_acquire(lock)
extern int __retarget_lock_try_acquire_recursive(_LOCK_T lock);
#define __lock_try_acquire_recursive(lock) __retarget_lock_try_acquire_recursive(lock)

extern void __retarget_lock_release(_LOCK_T lock);
#define __lock_release(lock) __retarget_lock_release(lock)
extern void __retarget_lock_release_recursive(_LOCK_T lock);
#define __lock_release_recursive(lock) __retarget_lock_release_recursive(lock)
# 36 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/reent.h" 2 3
typedef _LOCK_T _flock_t;







struct _reent;

struct __locale_t;






struct _Bigint
{
  struct _Bigint *_next;
  int _k, _maxwds, _sign, _wds;
  __ULong _x[1];
};


struct __tm
{
  int __tm_sec;
  int __tm_min;
  int __tm_hour;
  int __tm_mday;
  int __tm_mon;
  int __tm_year;
  int __tm_wday;
  int __tm_yday;
  int __tm_isdst;
};





#define _ATEXIT_SIZE 32

struct _on_exit_args {
 void * _fnargs[32];
 void * _dso_handle[32];

 __ULong _fntypes;


 __ULong _is_cxa;
};
# 99 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/reent.h" 3
struct _atexit {
 struct _atexit *_next;
 int _ind;

 void (*_fns[32])(void);
        struct _on_exit_args _on_exit_args;
};
#define _ATEXIT_INIT {_NULL, 0, {_NULL}, {{_NULL}, {_NULL}, 0, 0}}
# 116 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/reent.h" 3
struct __sbuf {
 unsigned char *_base;
 int _size;
};
# 146 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/reent.h" 3
#define _REENT_SMALL_CHECK_INIT(ptr) 






struct __sFILE {
  unsigned char *_p;
  int _r;
  int _w;
  short _flags;
  short _file;
  struct __sbuf _bf;
  int _lbfsize;






  void * _cookie;

  int (*_read) (struct _reent *, void *,
        char *, int);
  int (*_write) (struct _reent *, void *,
         const char *,
         int);
  _fpos_t (*_seek) (struct _reent *, void *, _fpos_t, int);
  int (*_close) (struct _reent *, void *);


  struct __sbuf _ub;
  unsigned char *_up;
  int _ur;


  unsigned char _ubuf[3];
  unsigned char _nbuf[1];


  struct __sbuf _lb;


  int _blksize;
  _off_t _offset;


  struct _reent *_data;



  _flock_t _lock;

  _mbstate_t _mbstate;
  int _flags2;
};
# 270 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/reent.h" 3
typedef struct __sFILE __FILE;



extern __FILE __sf[3];

struct _glue
{
  struct _glue *_next;
  int _niobs;
  __FILE *_iobs;
};

extern struct _glue __sglue;
# 299 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/reent.h" 3
#define _RAND48_SEED_0 (0x330e)
#define _RAND48_SEED_1 (0xabcd)
#define _RAND48_SEED_2 (0x1234)
#define _RAND48_MULT_0 (0xe66d)
#define _RAND48_MULT_1 (0xdeec)
#define _RAND48_MULT_2 (0x0005)
#define _RAND48_ADD (0x000b)
struct _rand48 {
  unsigned short _seed[3];
  unsigned short _mult[3];
  unsigned short _add;




};


#define _REENT_EMERGENCY_SIZE 25
#define _REENT_ASCTIME_SIZE 26
#define _REENT_SIGNAL_SIZE 24
# 330 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/reent.h" 3
#define _REENT_INIT_RESERVED_0 
#define _REENT_INIT_RESERVED_1 
#define _REENT_INIT_RESERVED_2 
#define _REENT_INIT_RESERVED_6_7 
#define _REENT_INIT_RESERVED_8 
# 580 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/reent.h" 3
struct _reent
{
  int _errno;




  __FILE *_stdin, *_stdout, *_stderr;

  int _inc;
  char _emergency[25];




  struct __locale_t *_locale;





  void (*__cleanup) (struct _reent *);


  struct _Bigint *_result;
  int _result_k;
  struct _Bigint *_p5s;
  struct _Bigint **_freelist;


  int _cvtlen;
  char *_cvtbuf;

  union
    {
      struct
        {



          char * _strtok_last;
          char _asctime_buf[26];
          struct __tm _localtime_buf;
          int _gamma_signgam;
          __extension__ unsigned long long _rand_next;
          struct _rand48 _r48;
          _mbstate_t _mblen_state;
          _mbstate_t _mbtowc_state;
          _mbstate_t _wctomb_state;
          char _l64a_buf[8];
          char _signal_buf[24];
          int _getdate_err;
          _mbstate_t _mbrlen_state;
          _mbstate_t _mbrtowc_state;
          _mbstate_t _mbsrtowcs_state;
          _mbstate_t _wcrtomb_state;
          _mbstate_t _wcsrtombs_state;
   int _h_errno;
# 650 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/reent.h" 3
   char _getlocalename_l_buf[7
        * 32 ];

        } _reent;







    } _new;







  void (**_sig_func)(int);
};

#define _REENT_INIT(var) { 0, &__sf[0], &__sf[1], &__sf[2], 0, "", _REENT_INIT_RESERVED_1 _NULL, _REENT_INIT_RESERVED_0 _NULL, _NULL, 0, _NULL, _NULL, 0, _NULL, { { _REENT_INIT_RESERVED_2 _NULL, "", {0, 0, 0, 0, 0, 0, 0, 0, 0}, 0, 1, { {_RAND48_SEED_0, _RAND48_SEED_1, _RAND48_SEED_2}, {_RAND48_MULT_0, _RAND48_MULT_1, _RAND48_MULT_2}, _RAND48_ADD }, {0, {0}}, {0, {0}}, {0, {0}}, "", "", 0, {0, {0}}, {0, {0}}, {0, {0}}, {0, {0}}, {0, {0}} } }, _REENT_INIT_RESERVED_6_7 _NULL }
# 719 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/reent.h" 3
#define _REENT_INIT_PTR_ZEROED(var) { (var)->_stdin = &__sf[0]; (var)->_stdout = &__sf[1]; (var)->_stderr = &__sf[2]; (var)->_new._reent._rand_next = 1; (var)->_new._reent._r48._seed[0] = _RAND48_SEED_0; (var)->_new._reent._r48._seed[1] = _RAND48_SEED_1; (var)->_new._reent._r48._seed[2] = _RAND48_SEED_2; (var)->_new._reent._r48._mult[0] = _RAND48_MULT_0; (var)->_new._reent._r48._mult[1] = _RAND48_MULT_1; (var)->_new._reent._r48._mult[2] = _RAND48_MULT_2; (var)->_new._reent._r48._add = _RAND48_ADD; }
# 733 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/reent.h" 3
#define _REENT_CHECK_RAND48(ptr) 
#define _REENT_CHECK_MP(ptr) 
#define _REENT_CHECK_TM(ptr) 
#define _REENT_CHECK_ASCTIME_BUF(ptr) 
#define _REENT_CHECK_EMERGENCY(ptr) 
#define _REENT_CHECK_MISC(ptr) 
#define _REENT_CHECK_SIGNAL_BUF(ptr) 

#define _REENT_SIGNGAM(ptr) ((ptr)->_new._reent._gamma_signgam)
#define _REENT_RAND_NEXT(ptr) ((ptr)->_new._reent._rand_next)
#define _REENT_RAND48_SEED(ptr) ((ptr)->_new._reent._r48._seed)
#define _REENT_RAND48_MULT(ptr) ((ptr)->_new._reent._r48._mult)
#define _REENT_RAND48_ADD(ptr) ((ptr)->_new._reent._r48._add)
#define _REENT_MP_RESULT(ptr) ((ptr)->_result)
#define _REENT_MP_RESULT_K(ptr) ((ptr)->_result_k)
#define _REENT_MP_P5S(ptr) ((ptr)->_p5s)
#define _REENT_MP_FREELIST(ptr) ((ptr)->_freelist)
#define _REENT_ASCTIME_BUF(ptr) ((ptr)->_new._reent._asctime_buf)
#define _REENT_TM(ptr) (&(ptr)->_new._reent._localtime_buf)
#define _REENT_STRTOK_LAST(ptr) ((ptr)->_new._reent._strtok_last)
#define _REENT_MBLEN_STATE(ptr) ((ptr)->_new._reent._mblen_state)
#define _REENT_MBTOWC_STATE(ptr) ((ptr)->_new._reent._mbtowc_state)
#define _REENT_WCTOMB_STATE(ptr) ((ptr)->_new._reent._wctomb_state)
#define _REENT_MBRLEN_STATE(ptr) ((ptr)->_new._reent._mbrlen_state)
#define _REENT_MBRTOWC_STATE(ptr) ((ptr)->_new._reent._mbrtowc_state)
#define _REENT_MBSRTOWCS_STATE(ptr) ((ptr)->_new._reent._mbsrtowcs_state)
#define _REENT_WCRTOMB_STATE(ptr) ((ptr)->_new._reent._wcrtomb_state)
#define _REENT_WCSRTOMBS_STATE(ptr) ((ptr)->_new._reent._wcsrtombs_state)
# 769 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/reent.h" 3
#define _REENT_L64A_BUF(ptr) ((ptr)->_new._reent._l64a_buf)
#define _REENT_SIGNAL_BUF(ptr) ((ptr)->_new._reent._signal_buf)
#define _REENT_GETDATE_ERR_P(ptr) (&((ptr)->_new._reent._getdate_err))

#define _REENT_GETLOCALENAME_L_BUF(ptr) ((ptr)->_new._reent._getlocalename_l_buf)




#define _REENT_CLEANUP(_ptr) ((_ptr)->__cleanup)
#define _REENT_CVTBUF(_ptr) ((_ptr)->_cvtbuf)
#define _REENT_CVTLEN(_ptr) ((_ptr)->_cvtlen)
#define _REENT_EMERGENCY(_ptr) ((_ptr)->_emergency)
#define _REENT_ERRNO(_ptr) ((_ptr)->_errno)
#define _REENT_INC(_ptr) ((_ptr)->_inc)
#define _REENT_LOCALE(_ptr) ((_ptr)->_locale)
#define _REENT_SIG_FUNC(_ptr) ((_ptr)->_sig_func)
#define _REENT_STDIN(_ptr) ((_ptr)->_stdin)
#define _REENT_STDOUT(_ptr) ((_ptr)->_stdout)
#define _REENT_STDERR(_ptr) ((_ptr)->_stderr)

#define _REENT_INIT_PTR(var) { memset((var), 0, sizeof(*(var))); _REENT_INIT_PTR_ZEROED(var); }
# 801 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/reent.h" 3
#define __ATTRIBUTE_IMPURE_PTR__ 


extern struct _reent *_impure_ptr ;


#define __ATTRIBUTE_IMPURE_DATA__ 


extern struct _reent _impure_data ;
# 820 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/reent.h" 3
#define _REENT _impure_ptr


#define _REENT_IS_NULL(_ptr) ((_ptr) == NULL)

#define _GLOBAL_REENT (&_impure_data)
# 922 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/reent.h" 3
#define _Kmax (sizeof (size_t) << 3)

extern struct _atexit *__atexit;
extern struct _atexit __atexit0;

extern void (*__stdio_exit_handler) (void);

void _reclaim_reent (struct _reent *);

extern int _fwalk_sglue (struct _reent *, int (*)(struct _reent *, __FILE *),
    struct _glue *);
# 12 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/string.h" 2 3



#define __need_size_t 
#define __need_NULL 
# 1 "D:/Arm GNU Toolchain/14.3 rel1/lib/gcc/arm-none-eabi/14.3.1/include/stddef.h" 1 3 4
# 173 "D:/Arm GNU Toolchain/14.3 rel1/lib/gcc/arm-none-eabi/14.3.1/include/stddef.h" 3 4
#undef __need_ptrdiff_t
# 252 "D:/Arm GNU Toolchain/14.3 rel1/lib/gcc/arm-none-eabi/14.3.1/include/stddef.h" 3 4
#undef __need_size_t
# 364 "D:/Arm GNU Toolchain/14.3 rel1/lib/gcc/arm-none-eabi/14.3.1/include/stddef.h" 3 4
#undef __need_wchar_t
# 414 "D:/Arm GNU Toolchain/14.3 rel1/lib/gcc/arm-none-eabi/14.3.1/include/stddef.h" 3 4
#undef NULL




#define NULL ((void *)0)





#undef __need_NULL




#undef offsetof
#define offsetof(TYPE,MEMBER) __builtin_offsetof (TYPE, MEMBER)
# 18 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/string.h" 2 3
# 27 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/string.h" 3


void * memchr (const void *, int, size_t);
int memcmp (const void *, const void *, size_t);
void * memcpy (void *restrict, const void *restrict, size_t);
void * memmove (void *, const void *, size_t);
void * memset (void *, int, size_t);
char *strcat (char *restrict, const char *restrict);
char *strchr (const char *, int);
int strcmp (const char *, const char *);
int strcoll (const char *, const char *);
char *strcpy (char *restrict, const char *restrict);
size_t strcspn (const char *, const char *);
char *strerror (int);
size_t strlen (const char *);
char *strncat (char *restrict, const char *restrict, size_t);
int strncmp (const char *, const char *, size_t);
char *strncpy (char *restrict, const char *restrict, size_t);
char *strpbrk (const char *, const char *);
char *strrchr (const char *, int);
size_t strspn (const char *, const char *);
char *strstr (const char *, const char *);

char *strtok (char *restrict, const char *restrict);

size_t strxfrm (char *restrict, const char *restrict, size_t);
# 86 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/string.h" 3
char *_strdup_r (struct _reent *, const char *);



char *_strndup_r (struct _reent *, const char *, size_t);
# 112 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/string.h" 3
char * _strerror_r (struct _reent *, int, int, int *);
# 175 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/string.h" 3
# 1 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/sys/string.h" 1 3
# 176 "D:/Arm GNU Toolchain/14.3 rel1/arm-none-eabi/include/string.h" 2 3


# 6 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 2

# 1 "Generated/Inc/project_resources.h" 1

#define __PROJECT_RESOURCES_H 



# 1 "Platform/Inc/platform_adc.h" 1

#define __PLATFORM_ADC_H 



# 1 "Platform/Inc/platform_types.h" 1

#define __PLATFORM_TYPES_H 




# 6 "Platform/Inc/platform_types.h"
typedef enum
{
    PLATFORM_OK = 0,
    PLATFORM_ALREADY_INITIALIZED,
    PLATFORM_NOT_READY,
    PLATFORM_BUSY,
    PLATFORM_TIMEOUT,
    PLATFORM_INVALID_ARGUMENT,
    PLATFORM_UNSUPPORTED,
    PLATFORM_IO_ERROR
} PlatformResult;
# 7 "Platform/Inc/platform_adc.h" 2

typedef enum
{
    PLATFORM_ADC_1 = 0,
    PLATFORM_ADC_COUNT = 3
} PlatformAdcId;

PlatformResult PlatformAdc_Read(PlatformAdcId id,
                                uint32_t timeout_ms,
                                uint32_t *raw_count);
# 7 "Generated/Inc/project_resources.h" 2
# 1 "Platform/Inc/platform_gpio.h" 1

#define __PLATFORM_GPIO_H 
# 15 "Platform/Inc/platform_gpio.h"
typedef enum
{
    PLATFORM_GPIO_0 = 0,
    PLATFORM_GPIO_1,
    PLATFORM_GPIO_2,
    PLATFORM_GPIO_3,
    PLATFORM_GPIO_4,
    PLATFORM_GPIO_5,
    PLATFORM_GPIO_6,
    PLATFORM_GPIO_7,
    PLATFORM_GPIO_8,
    PLATFORM_GPIO_COUNT = 96
} PlatformGpioId;

PlatformResult PlatformGpio_Write(PlatformGpioId id, uint8_t logical_high);
PlatformResult PlatformGpio_Read(PlatformGpioId id, uint8_t *logical_high);
uint8_t PlatformGpio_IrqConsume(PlatformGpioId id);
# 8 "Generated/Inc/project_resources.h" 2
# 1 "Platform/Inc/platform_uart.h" 1

#define __PLATFORM_UART_H 





typedef enum
{
    PLATFORM_UART_1 = 0,
    PLATFORM_UART_2,
    PLATFORM_UART_3,
    PLATFORM_UART_COUNT = 6
} PlatformUartId;

typedef enum
{
    PLATFORM_UART_TX_NORMAL = 0,
    PLATFORM_UART_TX_PRIORITY
} PlatformUartTxPriority;

typedef struct
{
    uint32_t rx_bytes;
    uint32_t tx_bytes;
    uint32_t rx_event_count;
    uint32_t rx_idle_event_count;
    uint32_t rx_transfer_complete_count;
    uint32_t rx_discarded_bytes;
    uint32_t tx_discarded_bytes;
    uint32_t uart_overrun_error_count;
    uint32_t uart_framing_error_count;
    uint32_t uart_noise_error_count;
    uint32_t uart_parity_error_count;
    uint32_t dma_error_count;
    uint32_t rx_restart_count;
    uint32_t rx_restart_failure_count;
    uint32_t rx_discontinuity_count;
    uint32_t transport_error_count;
    uint8_t rx_active;
    uint8_t tx_active;
} PlatformUartDiagnostics;

PlatformResult PlatformUart_Init(PlatformUartId id);
PlatformResult PlatformUart_Write(PlatformUartId id,
                                  const uint8_t *data,
                                  uint16_t length,
                                  uint32_t timeout_ms);
PlatformResult PlatformUart_WriteAsync(PlatformUartId id,
                                       const uint8_t *data,
                                       uint16_t length,
                                       PlatformUartTxPriority priority,
                                       uint16_t *accepted_length);

PlatformResult PlatformUart_WriteFrameAsync(PlatformUartId id,
                                            const uint8_t *data,
                                            uint16_t length,
                                            PlatformUartTxPriority priority);
PlatformResult PlatformUart_Read(PlatformUartId id,
                                 uint8_t *data,
                                 uint16_t capacity,
                                 uint16_t *read_length);
PlatformResult PlatformUart_RxFlush(PlatformUartId id);
PlatformResult PlatformUart_RxStop(PlatformUartId id);
PlatformResult PlatformUart_RxRestart(PlatformUartId id);
PlatformResult PlatformUart_BaudSet(PlatformUartId id, uint32_t baudrate);
PlatformResult PlatformUart_BaudGet(PlatformUartId id, uint32_t *baudrate);
PlatformResult PlatformUart_RxCountGet(PlatformUartId id, uint16_t *count);
PlatformResult PlatformUart_TxCountGet(PlatformUartId id,
                                       PlatformUartTxPriority priority,
                                       uint16_t *count);
PlatformResult PlatformUart_DiagnosticsGet(
    PlatformUartId id,
    PlatformUartDiagnostics *diagnostics);
void PlatformUart_Process(PlatformUartId id);
# 9 "Generated/Inc/project_resources.h" 2

# 1 "Platform/STM32F4/Inc/platform_stm32f4_resources.h" 1

#define __PLATFORM_STM32F4_RESOURCES_H 




# 1 "Platform/Inc/platform_can.h" 1

#define __PLATFORM_CAN_H 





#define PLATFORM_CAN_DATA_MAX_LENGTH 8U
#define PLATFORM_CAN_SEND_TIMEOUT_MAX_MS 60000U

typedef enum
{
    PLATFORM_CAN_1 = 0,
    PLATFORM_CAN_2,
    PLATFORM_CAN_COUNT
} PlatformCanId;

typedef struct
{
    uint32_t identifier;
    uint8_t length;
    uint8_t extended_id;
    uint8_t data[8U];
} PlatformCanFrame;

typedef struct
{
    uint32_t driver_error;
    uint32_t tx_count;
    uint32_t rx_count;
    uint32_t rx_overrun_count;
    uint32_t bus_off_count;
    uint8_t started;
    uint8_t bus_off;
} PlatformCanDiagnostics;

PlatformResult PlatformCan_Start(PlatformCanId id);
PlatformResult PlatformCan_Stop(PlatformCanId id);
PlatformResult PlatformCan_Send(PlatformCanId id,
                                const PlatformCanFrame *frame,
                                uint32_t timeout_ms);
PlatformResult PlatformCan_ReceivePoll(PlatformCanId id,
                                       PlatformCanFrame *frame);
PlatformResult PlatformCan_DiagnosticsGet(
    PlatformCanId id,
    PlatformCanDiagnostics *diagnostics);
# 8 "Platform/STM32F4/Inc/platform_stm32f4_resources.h" 2

# 1 "Platform/Inc/platform_i2c.h" 1

#define __PLATFORM_I2C_H 





typedef enum
{
    PLATFORM_I2C_1 = 0,
    PLATFORM_I2C_2,
    PLATFORM_I2C_3,
    PLATFORM_I2C_COUNT
} PlatformI2cId;

typedef enum
{
    PLATFORM_I2C_MEMORY_ADDRESS_8_BIT = 0,
    PLATFORM_I2C_MEMORY_ADDRESS_16_BIT
} PlatformI2cMemoryAddressSize;

PlatformResult PlatformI2c_Write(PlatformI2cId id,
                                 uint16_t address_7bit,
                                 const uint8_t *data,
                                 uint16_t length,
                                 uint32_t timeout_ms);
PlatformResult PlatformI2c_Read(PlatformI2cId id,
                                uint16_t address_7bit,
                                uint8_t *data,
                                uint16_t length,
                                uint32_t timeout_ms);
PlatformResult PlatformI2c_MemoryWrite(PlatformI2cId id,
                                       uint16_t address_7bit,
                                       uint16_t memory_address,
                                       PlatformI2cMemoryAddressSize memory_address_size,
                                       const uint8_t *data,
                                       uint16_t length,
                                       uint32_t timeout_ms);
PlatformResult PlatformI2c_MemoryRead(PlatformI2cId id,
                                      uint16_t address_7bit,
                                      uint16_t memory_address,
                                      PlatformI2cMemoryAddressSize memory_address_size,
                                      uint8_t *data,
                                      uint16_t length,
                                      uint32_t timeout_ms);
# 10 "Platform/STM32F4/Inc/platform_stm32f4_resources.h" 2
# 1 "Platform/Inc/platform_pwm.h" 1

#define __PLATFORM_PWM_H 





#define PLATFORM_PWM_DUTY_PERMILLE_MAX 1000U

typedef enum
{
    PLATFORM_PWM_1 = 0,
    PLATFORM_PWM_2,
    PLATFORM_PWM_3,
    PLATFORM_PWM_4,
    PLATFORM_PWM_5,
    PLATFORM_PWM_6,
    PLATFORM_PWM_7,
    PLATFORM_PWM_8,
    PLATFORM_PWM_COUNT = 64
} PlatformPwmId;

typedef enum
{
    PLATFORM_PWM_MODE_1 = 0,
    PLATFORM_PWM_MODE_2
} PlatformPwmMode;

typedef struct
{
    uint32_t frequency_hz;
    uint16_t resolution_bits;
    uint8_t active_high;
    uint8_t started;
    uint16_t duty_permille;
} PlatformPwmDiagnostics;

PlatformResult PlatformPwm_Start(PlatformPwmId id);
PlatformResult PlatformPwm_Stop(PlatformPwmId id);
PlatformResult PlatformPwm_DutyPermilleSet(
    PlatformPwmId id,
    uint16_t duty_permille);
PlatformResult PlatformPwm_SafeInactiveSet(PlatformPwmId id);
PlatformResult PlatformPwm_DiagnosticsGet(
    PlatformPwmId id,
    PlatformPwmDiagnostics *diagnostics);
# 11 "Platform/STM32F4/Inc/platform_stm32f4_resources.h" 2
# 1 "Platform/Inc/platform_spi.h" 1

#define __PLATFORM_SPI_H 





typedef enum
{
    PLATFORM_SPI_1 = 0,
    PLATFORM_SPI_COUNT = 3
} PlatformSpiId;



typedef struct
{
    uint32_t driver_status;
    uint32_t driver_error_code;
    uint32_t driver_state;
    uint32_t spi_sr;
    uint32_t driver_elapsed_ms;
    uint16_t tx_remaining;
    uint16_t rx_remaining;
    uint8_t valid;
} PlatformSpiDriverObservation;

PlatformResult PlatformSpi_WriteObserved(PlatformSpiId id,
    const uint8_t *data, uint16_t length, uint32_t timeout_ms,
    PlatformSpiDriverObservation *observation);
PlatformResult PlatformSpi_TransferObserved(PlatformSpiId id,
    const uint8_t *tx_data, uint8_t *rx_data, uint16_t length,
    uint32_t timeout_ms, PlatformSpiDriverObservation *observation);

PlatformResult PlatformSpi_Write(PlatformSpiId id,
                                 const uint8_t *data,
                                 uint16_t length,
                                 uint32_t timeout_ms);
PlatformResult PlatformSpi_Transfer(PlatformSpiId id,
                                    const uint8_t *tx_data,
                                    uint8_t *rx_data,
                                    uint16_t length,
                                    uint32_t timeout_ms);
# 12 "Platform/STM32F4/Inc/platform_stm32f4_resources.h" 2
# 1 "Platform/Inc/platform_time.h" 1

#define __PLATFORM_TIME_H 





typedef enum
{
    PLATFORM_TIME_1 = 0,
    PLATFORM_TIME_COUNT
} PlatformTimeId;

PlatformResult PlatformTime_Init(void);
uint32_t PlatformTime_Ms(void);
uint64_t PlatformTime_Us(void);
void PlatformTime_DelayMs(uint32_t delay_ms);
# 13 "Platform/STM32F4/Inc/platform_stm32f4_resources.h" 2


typedef struct
{
    void *port;
    uint16_t pin;
    uint8_t irq_enabled;
} PlatformStm32f4GpioResource;

typedef struct
{
    void *handle;
    uint32_t channel;
    uint32_t frequency_hz;
    uint16_t resolution_bits;
    PlatformPwmMode mode;
    uint8_t active_high;
} PlatformStm32f4PwmResource;

typedef struct
{
    void *handle;
    uint32_t counter_frequency_hz;
    uint32_t period_counts;
    uint32_t tick_frequency_hz;
} PlatformStm32f4TimeResource;

void *PlatformStm32f4Resource_UartHandleGet(PlatformUartId id);
void *PlatformStm32f4Resource_SpiHandleGet(PlatformSpiId id);
void *PlatformStm32f4Resource_AdcHandleGet(PlatformAdcId id);
uint8_t PlatformStm32f4Resource_GpioGet(
    PlatformGpioId id,
    PlatformStm32f4GpioResource *resource);
void *PlatformStm32f4Resource_I2cHandleGet(PlatformI2cId id);
void *PlatformStm32f4Resource_CanHandleGet(PlatformCanId id);
uint8_t PlatformStm32f4Resource_PwmGet(
    PlatformPwmId id,
    PlatformStm32f4PwmResource *resource);
uint8_t PlatformStm32f4Resource_TimeGet(
    PlatformTimeId id,
    PlatformStm32f4TimeResource *resource);
# 11 "Generated/Inc/project_resources.h" 2


#define PROJECT_RESOURCE_CONSOLE_UART PLATFORM_UART_3
#define PROJECT_RESOURCE_INPUT_VOLTAGE_ADC PLATFORM_ADC_1
#define PROJECT_RESOURCE_LAUNCH_IGNITION_OUTPUT PLATFORM_GPIO_4
#define PROJECT_RESOURCE_PARACHUTE_PYRO_OUTPUT PLATFORM_GPIO_5
#define PROJECT_RESOURCE_SYSTEM_INDICATOR PLATFORM_GPIO_6
#define PROJECT_FEATURE_LAUNCH_IGNITION_OUTPUT 1U
#define PROJECT_FEATURE_PARACHUTE_PYRO_OUTPUT 1U
#define PROJECT_RESOURCE_GNSS_INDICATOR PLATFORM_GPIO_COUNT
#define PROJECT_FEATURE_GNSS_STATUS_INDICATOR 0U
#define PROJECT_FEATURE_SYSTEM_STATUS_INDICATOR 1U
#define PROJECT_FEATURE_INPUT_VOLTAGE_MONITOR 1U

#define PROJECT_JY901B_INSTANCE_COUNT 1U
#define PROJECT_JY901B_INSTANCE_COUNT_MAX 4U

typedef struct
{
    PlatformUartId uart;
    PlatformTimeId time;
    uint16_t installation_orientation;
    uint8_t module_variant;
} ProjectJy901bResources;

SystemDeviceResult ProjectJy901bResources_Get(
    uint8_t source_instance, ProjectJy901bResources *resources);

#define PROJECT_NEO_M9N_INSTANCE_COUNT 1U
#define PROJECT_NEO_M9N_INSTANCE_COUNT_MAX 4U

typedef struct
{
    PlatformUartId uart;
    PlatformGpioId reset;
    PlatformGpioId timepulse;
    PlatformTimeId time;
} ProjectNeoM9nResources;

SystemDeviceResult ProjectNeoM9nResources_Get(
    uint8_t source_instance, ProjectNeoM9nResources *resources);

#define PROJECT_SX1281_INSTANCE_COUNT 1U
#define PROJECT_SX1281_INSTANCE_COUNT_MAX 4U

typedef struct
{
    PlatformSpiId spi;
    PlatformGpioId nss;
    PlatformGpioId reset;
    PlatformGpioId busy;
    PlatformGpioId dio1;
    PlatformTimeId time;
    PlatformGpioId rx_en;
    PlatformGpioId tx_en;
} ProjectSx1281Resources;

SystemDeviceResult ProjectSx1281Resources_Get(
    uint8_t source_instance, ProjectSx1281Resources *resources);


#define PROJECT_PLATFORM_UART_1_RX_DMA_SIZE 128U
#define PROJECT_PLATFORM_UART_1_RX_RING_SIZE 512U
#define PROJECT_PLATFORM_UART_1_TX_RING_SIZE 192U
#define PROJECT_PLATFORM_UART_1_TX_PRIORITY_SIZE 192U
#define PROJECT_PLATFORM_UART_2_RX_DMA_SIZE 128U
#define PROJECT_PLATFORM_UART_2_RX_RING_SIZE 1024U
#define PROJECT_PLATFORM_UART_2_TX_RING_SIZE 192U
#define PROJECT_PLATFORM_UART_2_TX_PRIORITY_SIZE 192U
#define PROJECT_PLATFORM_UART_3_RX_DMA_SIZE 128U
#define PROJECT_PLATFORM_UART_3_RX_RING_SIZE 1024U
#define PROJECT_PLATFORM_UART_3_TX_RING_SIZE 4096U
#define PROJECT_PLATFORM_UART_3_TX_PRIORITY_SIZE 1024U
#define PROJECT_PLATFORM_UART_4_RX_DMA_SIZE 1U
#define PROJECT_PLATFORM_UART_4_RX_RING_SIZE 1U
#define PROJECT_PLATFORM_UART_4_TX_RING_SIZE 1U
#define PROJECT_PLATFORM_UART_4_TX_PRIORITY_SIZE 1U
#define PROJECT_PLATFORM_UART_5_RX_DMA_SIZE 1U
#define PROJECT_PLATFORM_UART_5_RX_RING_SIZE 1U
#define PROJECT_PLATFORM_UART_5_TX_RING_SIZE 1U
#define PROJECT_PLATFORM_UART_5_TX_PRIORITY_SIZE 1U
#define PROJECT_PLATFORM_UART_6_RX_DMA_SIZE 1U
#define PROJECT_PLATFORM_UART_6_RX_RING_SIZE 1U
#define PROJECT_PLATFORM_UART_6_TX_RING_SIZE 1U
#define PROJECT_PLATFORM_UART_6_TX_PRIORITY_SIZE 1U

typedef enum { ProjectMaintenanceUartResult_Ok = 0, ProjectMaintenanceUartResult_Mismatch } ProjectMaintenanceUartResult;
ProjectMaintenanceUartResult ProjectMaintenanceUart_Validate(void);
# 8 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 2
# 1 "Devices/GNSS/NEO_M9N/Inc/neo_m9n_build_capabilities.h" 1

#define __NEO_M9N_BUILD_CAPABILITIES_H 

#define NEO_M9N_BUILD_POSITION_AVAILABLE 1U


#define NEO_M9N_BUILD_ESTIMATOR_NOISE_RECOMMENDATION_AVAILABLE 1U
#define NEO_M9N_RECOMMENDED_HORIZONTAL_POSITION_STD_FLOOR_M 1.5f
#define NEO_M9N_RECOMMENDED_VERTICAL_POSITION_STD_FLOOR_M 2.5f
#define NEO_M9N_RECOMMENDED_VELOCITY_STD_FLOOR_MPS 0.15f
# 9 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 2
# 1 "Devices/GNSS/NEO_M9N/Inc/neo_m9n_config.h" 1

#define __NEO_M9N_CONFIG_H 



#define GNSS_TIMEOUT_MS 1500U

#define GNSS_UART_BAUD_4800 4800U
#define GNSS_UART_BAUD_9600 9600U
#define GNSS_UART_BAUD_19200 19200U
#define GNSS_UART_BAUD_38400 38400U
#define GNSS_UART_BAUD_57600 57600U
#define GNSS_UART_BAUD_115200 115200U
#define GNSS_UART_BAUD_230400 230400U
#define GNSS_UART_BAUD_460800 460800U
#define GNSS_UART_BAUD_576000 576000U
#define GNSS_UART_BAUD_921600 921600U

#define GNSS_DEFAULT_BAUDRATE GNSS_UART_BAUD_921600
#define GNSS_FACTORY_BAUDRATE GNSS_UART_BAUD_38400
#define GNSS_MAX_BAUDRATE GNSS_UART_BAUD_921600
#define GNSS_DEFAULT_RATE_HZ 1U
#define GNSS_TARGET_RATE_HZ 25U
#define GNSS_MAX_RATE_HZ 25U

#define GNSS_CFG_TIMEOUT_MS 100U
#define GNSS_ACK_TIMEOUT_MS 1500U
#define GNSS_CONFIG_READ_TIMEOUT_MS 3000U
#define GNSS_CONFIG_READ_GROUP_TIMEOUT_MS 300U
#define GNSS_CONFIG_READ_KEY_TIMEOUT_MS 150U
#define GNSS_SAVE_ACK_TIMEOUT_MS 3000U
#define GNSS_UART_CONFIG_SETTLE_MS 100U
#define GNSS_SIGNAL_RESET_WAIT_MS 600U
#define GNSS_SIGNAL_STREAM_RECOVERY_TIMEOUT_MS 1500U

#define GNSS_CFG_LAYER_RAM 0x01U
#define GNSS_CFG_LAYER_BBR 0x02U
#define GNSS_CFG_LAYER_FLASH 0x04U
#define GNSS_CFG_LAYER_RAM_FLASH (GNSS_CFG_LAYER_RAM | GNSS_CFG_LAYER_FLASH)
#define GNSS_CFG_LAYER_ALL (GNSS_CFG_LAYER_RAM | GNSS_CFG_LAYER_BBR | GNSS_CFG_LAYER_FLASH)
#define GNSS_CFG_LAYER_PERSISTENT_DEFAULT GNSS_CFG_LAYER_RAM


#define GNSS_DYNMODEL_PORTABLE 0U
#define GNSS_DYNMODEL_STATIONARY 2U
#define GNSS_DYNMODEL_PEDESTRIAN 3U
#define GNSS_DYNMODEL_AUTOMOTIVE 4U
#define GNSS_DYNMODEL_SEA 5U
#define GNSS_DYNMODEL_AIRBORNE_1G 6U
#define GNSS_DYNMODEL_AIRBORNE_2G 7U
#define GNSS_DYNMODEL_AIRBORNE_4G 8U
#define GNSS_TARGET_DYNMODEL GNSS_DYNMODEL_AIRBORNE_4G

#define GNSS_NAV_MIN_SV 6U
#define GNSS_NAV_MAX_HACC_MM 5000U
#define GNSS_NAV_MAX_VACC_MM 10000U
#define GNSS_NAV_MAX_SACC_MMPS 2000U
#define GNSS_COURSE_MIN_GSPEED_MMPS 2000U
#define GNSS_COURSE_MAX_HEADACC_E5 1500000U
#define GNSS_NAV_MAX_AGE_MS 500U


#define NEO_M9N_LEGACY_STARTUP_ENABLE 0U
# 10 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 2
# 1 "Devices/GNSS/NEO_M9N/Inc/neo_m9n_device.h" 1

#define __NEO_M9N_DEVICE_H 



typedef struct
{
    uint32_t iTOW;
    uint16_t year;
    uint16_t pDOP;
    uint8_t month;
    uint8_t day;
    uint8_t hour;
    uint8_t min;
    uint8_t sec;
    uint8_t validDate;
    uint8_t validTime;
    uint32_t lastUpdate_ms;
    uint64_t lastUpdate_us;
    uint32_t pvtSequence;
    uint8_t online;
    uint8_t fixType;
    uint8_t gnssFixOK;
    uint8_t numSV;
    uint8_t hasValidFix;
    uint8_t positionUsable;
    uint8_t velocityUsable;
    uint8_t courseUsable;
    int32_t lon;
    int32_t lat;
    int32_t height;
    int32_t hMSL;
    uint32_t hAcc;
    uint32_t vAcc;
    int32_t velN;
    int32_t velE;
    int32_t velD;
    int32_t gSpeed;
    int32_t headMot;
    uint32_t sAcc;
    uint32_t headAcc;
} GnssNeoM9nData;

typedef enum
{
    GnssNeoM9nAckNone = 0,
    GnssNeoM9nAckAck,
    GnssNeoM9nAckNak
} GnssNeoM9nAckState;

typedef enum
{
    GnssNeoM9nPersistNone = 0,
    GnssNeoM9nPersistRam,
    GnssNeoM9nPersistBbr,
    GnssNeoM9nPersistFlash,
    GnssNeoM9nPersistAll
} GnssNeoM9nPersistTarget;

typedef enum
{
    GnssProtocolDetectedNone = 0,
    GnssProtocolDetectedUbx,
    GnssProtocolDetectedNmea,
    GnssProtocolDetectedUbxNmea,
    GnssProtocolDetectedUnknown
} GnssProtocolDetected;

typedef enum
{
    GnssOutputProtocolNmeaOnly = 0,
    GnssOutputProtocolUbxOnly,
    GnssOutputProtocolUbxNmea
} GnssOutputProtocol;

#define GNSS_CONFIG_VALID_BAUD (1U << 0)
#define GNSS_CONFIG_VALID_RATE (1U << 1)
#define GNSS_CONFIG_VALID_DYNAMIC (1U << 2)
#define GNSS_CONFIG_VALID_CONSTELLATIONS (1U << 3)
#define GNSS_CONFIG_VALID_PROTOCOL_IN (1U << 4)
#define GNSS_CONFIG_VALID_PROTOCOL_OUT (1U << 5)
#define GNSS_CONFIG_VALID_NAV_PVT (1U << 6)
#define GNSS_CONFIG_VALID_ALL 0x7FU

typedef struct
{
    uint32_t baudrate;
    uint8_t rate_hz;
    uint8_t dynamic_model;
    uint32_t constellations_mask;
    uint8_t protocol_in;
    uint8_t protocol_out;
    uint8_t nav_pvt_rate;
    uint8_t nav_pvt_known;
    uint8_t save_cache_count;
    uint8_t baud_cached;
    uint16_t valid_mask;
    GnssNeoM9nPersistTarget read_layer;
    GnssNeoM9nPersistTarget last_write_layers;
    GnssNeoM9nAckState last_ack;
} GnssNeoM9nConfigSnapshot;

typedef struct
{
    uint8_t initialized;
    uint32_t uart_baudrate;
    uint8_t stream_seen;
    GnssProtocolDetected detected;
    uint8_t ubx_seen;
    uint8_t nmea_seen;
    uint8_t unknown_seen;
    uint8_t pvt_seen;
    uint32_t last_rx_ms;
    uint32_t last_ubx_ms;
    uint32_t last_nmea_ms;
    uint32_t last_unknown_ms;
    uint32_t rx_bytes;
    uint32_t ubx_frames;
    uint32_t ubx_pvt_count;
    uint32_t ubx_ack_count;
    uint32_t ubx_nak_count;
    uint32_t ubx_checksum_error_count;
    uint32_t nmea_sentence_count;
    uint32_t nmea_checksum_ok_count;
    uint32_t nmea_checksum_error_count;
    char last_nmea_type[8];
    uint32_t unknown_bytes;
    uint32_t process_limit_count;
} GnssNeoM9nStatusSnapshot;

#define GNSS_CONSTELLATION_GPS (1UL << 0)
#define GNSS_CONSTELLATION_GALILEO (1UL << 1)
#define GNSS_CONSTELLATION_BDS (1UL << 2)
#define GNSS_CONSTELLATION_GLONASS (1UL << 3)
#define GNSS_CONSTELLATION_QZSS (1UL << 4)
#define GNSS_CONSTELLATION_SBAS (1UL << 5)

typedef enum
{
    GnssNeoM9n_InitOk = 0,
    GnssNeoM9n_InitUartError
} GnssNeoM9nInitResult;

typedef enum
{
    GnssNeoM9nIdentifyOk = 0,
    GnssNeoM9nIdentifyWrongModel,
    GnssNeoM9nIdentifyTimeout,
    GnssNeoM9nIdentifyIoError
} GnssNeoM9nIdentifyResult;

GnssNeoM9nIdentifyResult GnssNeoM9n_Identify(uint8_t instance);



uint32_t GnssNeoM9n_LastValidBaudGet(uint8_t instance);

typedef enum
{
    GnssNeoM9nIdentityNone = 0,
    GnssNeoM9nIdentityOk,
    GnssNeoM9nIdentityBadLength,
    GnssNeoM9nIdentityUnterminatedField,
    GnssNeoM9nIdentityDuplicateConflict,
    GnssNeoM9nIdentityMissingModel,
    GnssNeoM9nIdentityWrongModel,
    GnssNeoM9nIdentityMissingProtocol,
    GnssNeoM9nIdentityUnsupportedProtocol,
    GnssNeoM9nIdentityMissingFirmware,
    GnssNeoM9nIdentityWrongFirmware,
    GnssNeoM9nIdentityChecksumError,
    GnssNeoM9nIdentityTimeout,
    GnssNeoM9nIdentityIoError,
    GnssNeoM9nIdentityDiscontinuity,
    GnssNeoM9nIdentityUnsupportedHardware,
    GnssNeoM9nIdentityCapabilitiesPending
} GnssNeoM9nIdentityResult;




typedef struct
{
    GnssNeoM9nIdentityResult identity_result;
    GnssNeoM9nIdentityResult probe_result;
    GnssNeoM9nIdentityResult last_rejection;
    uint32_t sequence;
    uint32_t baudrate;
    uint16_t signal_settle_ms;
    uint8_t protocol_major;
    uint8_t protocol_minor;
    uint8_t fields_seen;
    uint32_t capability_read_mask;
    uint8_t profile;
} GnssNeoM9nIdentityDiagnostics;

GnssNeoM9nIdentityResult GnssNeoM9n_IdentityDiagnosticsGet(
    uint8_t instance, GnssNeoM9nIdentityDiagnostics *out);


typedef enum
{
    GnssNeoM9nProbeStartResult_Ok = 0,
    GnssNeoM9nProbeStartResult_Busy,
    GnssNeoM9nProbeStartResult_NotReady,
    GnssNeoM9nProbeStartResult_IoError
} GnssNeoM9nProbeStartResult;

typedef enum
{
    GnssNeoM9nProbePollResult_Pending = 0,
    GnssNeoM9nProbePollResult_Identified,
    GnssNeoM9nProbePollResult_WrongModel,
    GnssNeoM9nProbePollResult_NotReady
} GnssNeoM9nProbePollResult;

GnssNeoM9nProbeStartResult GnssNeoM9n_ProbeStart(
    uint8_t instance, uint32_t baudrate);
GnssNeoM9nProbePollResult GnssNeoM9n_ProbePoll(uint8_t instance);

typedef struct
{
    uint32_t key;
    uint64_t value;
    uint8_t value_len;
} GnssNeoM9nConfigItem;

typedef enum
{
    GnssNeoM9nItemStartResult_Ok = 0,
    GnssNeoM9nItemStartResult_Busy,
    GnssNeoM9nItemStartResult_InvalidArgument,
    GnssNeoM9nItemStartResult_NotReady,
    GnssNeoM9nItemStartResult_IoError
} GnssNeoM9nItemStartResult;

typedef enum
{
    GnssNeoM9nItemPollResult_Pending = 0,
    GnssNeoM9nItemPollResult_Complete,
    GnssNeoM9nItemPollResult_Nak,
    GnssNeoM9nItemPollResult_Timeout,
    GnssNeoM9nItemPollResult_IoError,
    GnssNeoM9nItemPollResult_NotReady
} GnssNeoM9nItemPollResult;

GnssNeoM9nItemStartResult GnssNeoM9n_ItemReadStart(
    uint8_t instance, uint32_t key);
GnssNeoM9nItemPollResult GnssNeoM9n_ItemReadPoll(
    uint8_t instance, GnssNeoM9nConfigItem *item);
GnssNeoM9nItemStartResult GnssNeoM9n_ItemWriteStart(
    uint8_t instance, const GnssNeoM9nConfigItem *item);
GnssNeoM9nItemPollResult GnssNeoM9n_ItemWritePoll(uint8_t instance);

typedef enum
{
    GnssNeoM9n_UpdateOk = 0,
    GnssNeoM9n_UpdateNoData
} GnssNeoM9nUpdateResult;

typedef enum
{
    GnssNeoM9nAsyncStartOk = 0,
    GnssNeoM9nAsyncStartBusy,
    GnssNeoM9nAsyncStartInvalidArgument,
    GnssNeoM9nAsyncStartNotReady,
    GnssNeoM9nAsyncStartTxError
} GnssNeoM9nAsyncStartResult;

typedef enum
{
    GnssNeoM9nAsyncPollPending = 0,
    GnssNeoM9nAsyncPollComplete
} GnssNeoM9nAsyncPollResult;

typedef enum
{
    GnssNeoM9nConfigReadResponseOk = 0,
    GnssNeoM9nConfigReadNak,
    GnssNeoM9nConfigReadTxError,
    GnssNeoM9nConfigReadChecksumError,
    GnssNeoM9nConfigReadMalformedResponse,
    GnssNeoM9nConfigReadTimeout,
    GnssNeoM9nConfigReadNotReady,
    GnssNeoM9nConfigReadIoError
} GnssNeoM9nConfigReadResult;

typedef enum
{
    GnssNeoM9nTransactionDetailNone = 0,
    GnssNeoM9nTransactionDetailResponseOk,
    GnssNeoM9nTransactionDetailNak,
    GnssNeoM9nTransactionDetailBusy,
    GnssNeoM9nTransactionDetailBadVersion,
    GnssNeoM9nTransactionDetailBadLayer,
    GnssNeoM9nTransactionDetailBadPosition,
    GnssNeoM9nTransactionDetailBadLength,
    GnssNeoM9nTransactionDetailKeyMismatch,
    GnssNeoM9nTransactionDetailValueLengthMismatch,
    GnssNeoM9nTransactionDetailCountOverflow,
    GnssNeoM9nTransactionDetailChecksumError,
    GnssNeoM9nTransactionDetailTxError,
    GnssNeoM9nTransactionDetailTimeout,
    GnssNeoM9nTransactionDetailNotReady,
    GnssNeoM9nTransactionDetailRxDiscontinuity
} GnssNeoM9nTransactionDetail;

typedef enum
{
    GnssNeoM9nConfigReadGroupNone = 0,
    GnssNeoM9nConfigReadGroupUart,
    GnssNeoM9nConfigReadGroupProtocol,
    GnssNeoM9nConfigReadGroupNavPvt,
    GnssNeoM9nConfigReadGroupRate,
    GnssNeoM9nConfigReadGroupDynamicModel,
    GnssNeoM9nConfigReadGroupSignals
} GnssNeoM9nConfigReadGroup;

typedef struct
{
    GnssNeoM9nConfigReadResult result;
    GnssNeoM9nConfigReadGroup failed_group;
    uint32_t failed_key;
    uint16_t response_length;
    uint8_t nak_class;
    uint8_t nak_id;
    GnssNeoM9nTransactionDetail detailed_result;
    uint8_t expected_class;
    uint8_t expected_id;
    uint8_t received_class;
    uint8_t received_id;
    uint8_t response_version;
} GnssNeoM9nConfigReadDiagnostics;

typedef struct
{
    uint64_t timestamp_us;
    uint32_t sequence;
    uint8_t satellite_count;
    uint8_t used_count;
    uint8_t average_cno_dbhz;
    uint8_t maximum_cno_dbhz;
    uint8_t average_quality;
    uint8_t valid;
    GnssNeoM9nConfigReadResult read_result;
    GnssNeoM9nTransactionDetail detailed_result;
    uint16_t response_length;
    uint8_t expected_class;
    uint8_t expected_id;
    uint8_t received_class;
    uint8_t received_id;
    uint8_t expected_ck_a;
    uint8_t expected_ck_b;
    uint8_t received_ck_a;
    uint8_t received_ck_b;
} GnssNeoM9nSatelliteDiagnostics;

typedef struct
{
    uint32_t ubx_frame_count;
    uint32_t ubx_checksum_error_count;
    uint32_t nmea_sentence_count;
    uint32_t nmea_checksum_ok_count;
    uint32_t nmea_checksum_error_count;
    uint32_t unknown_byte_count;
    uint32_t parser_resync_count;
} GnssNeoM9nStreamDiagnostics;

typedef struct
{
    uint64_t timestamp_us;
    uint32_t sequence;
    uint16_t noise_per_ms;
    uint16_t agc_count;
    uint8_t rf_block_count;
    uint8_t antenna_status;
    uint8_t antenna_power;
    uint8_t jamming_state;
    uint8_t cw_suppression;
    uint8_t jamming_indicator;
    uint8_t valid;
    GnssNeoM9nConfigReadResult read_result;
    GnssNeoM9nTransactionDetail detailed_result;
    uint16_t response_length;
} GnssNeoM9nRfDiagnostics;

GnssNeoM9nInitResult GnssNeoM9n_Init(uint8_t instance);
int GnssNeoM9n_ApplyDefaultConfig(uint8_t instance);
GnssNeoM9nUpdateResult GnssNeoM9n_Process(uint8_t instance, uint32_t now_ms);
uint8_t GnssNeoM9n_GetData(uint8_t instance, GnssNeoM9nData *out);
uint8_t GnssNeoM9n_IsInitialized(uint8_t instance);
void GnssNeoM9n_GetConfigSnapshot(uint8_t instance, GnssNeoM9nConfigSnapshot *out);
void GnssNeoM9n_GetStatusSnapshot(uint8_t instance, GnssNeoM9nStatusSnapshot *out);
GnssNeoM9nAckState GnssNeoM9n_GetLastAck(uint8_t instance);


int GnssNeoM9n_SendUbx(uint8_t instance, uint8_t cls, uint8_t id, const uint8_t *payload, uint16_t len);
int GnssNeoM9n_ConfigOutputUbxOnly(uint8_t instance, uint8_t layers);
int GnssNeoM9n_ConfigOutputProtocol(uint8_t instance, uint8_t layers, GnssOutputProtocol output);
int GnssNeoM9n_ConfigNavPvtOutput(uint8_t instance, uint8_t layers, uint8_t rate);
int GnssNeoM9n_ConfigNavRate(uint8_t instance, uint8_t layers, uint8_t hz);
int GnssNeoM9n_ConfigUartBaudrate(uint8_t instance, uint8_t layers, uint32_t baudrate);
int GnssNeoM9n_WaitUartConfigSettle(uint8_t instance, uint32_t minimum_wait_ms,
                                    uint32_t stream_timeout_ms);
int GnssNeoM9n_ConfigDynamicModel(uint8_t instance, uint8_t layers, uint8_t dyn_model);
int GnssNeoM9n_ConfigSignals(uint8_t instance, uint8_t layers, uint32_t constellation_mask);
int GnssNeoM9n_ConfigSignalsGpsBdsGal(uint8_t instance, uint8_t layers);
int GnssNeoM9n_WaitForNewNavPvt(uint8_t instance, uint32_t baseline_sequence,
                                uint64_t minimum_receive_timestamp_us,
                                uint32_t timeout_ms);
int GnssNeoM9n_ConfigPreset(uint8_t instance, uint8_t layers, uint32_t baudrate, uint8_t nav_rate_hz);
GnssNeoM9nConfigReadResult GnssNeoM9n_ReadHardwareConfig(uint8_t instance,
    GnssNeoM9nConfigSnapshot *out,
    uint32_t *elapsed_ms,
    GnssNeoM9nConfigReadDiagnostics *diagnostics);

GnssNeoM9nAsyncStartResult GnssNeoM9n_ConfigReadAsyncStart(uint8_t instance);
GnssNeoM9nAsyncPollResult GnssNeoM9n_ConfigReadAsyncPoll(uint8_t instance,
    GnssNeoM9nConfigSnapshot *out,
    uint32_t *elapsed_ms,
    GnssNeoM9nConfigReadDiagnostics *diagnostics,
    GnssNeoM9nConfigReadResult *result);
void GnssNeoM9n_ConfigReadAsyncCancel(uint8_t instance,
    GnssNeoM9nConfigReadResult result,
    GnssNeoM9nTransactionDetail detail);

GnssNeoM9nConfigReadResult GnssNeoM9n_ValgetRead(uint8_t instance,
    const uint32_t *keys,
    uint8_t count,
    GnssNeoM9nConfigReadDiagnostics *diagnostics);
int GnssNeoM9n_ReadSatelliteDiagnostics(uint8_t instance,
    GnssNeoM9nSatelliteDiagnostics *diagnostics);
GnssNeoM9nAsyncStartResult GnssNeoM9n_SatelliteDiagnosticsAsyncStart(uint8_t instance);
GnssNeoM9nAsyncPollResult GnssNeoM9n_SatelliteDiagnosticsAsyncPoll(uint8_t instance,
    GnssNeoM9nSatelliteDiagnostics *diagnostics);
void GnssNeoM9n_SatelliteDiagnosticsAsyncCancel(uint8_t instance,
    GnssNeoM9nConfigReadResult result,
    GnssNeoM9nTransactionDetail detail);
uint8_t GnssNeoM9n_GetSatelliteDiagnostics(uint8_t instance,
    GnssNeoM9nSatelliteDiagnostics *diagnostics);
int GnssNeoM9n_ReadRfDiagnostics(uint8_t instance, GnssNeoM9nRfDiagnostics *diagnostics);
GnssNeoM9nAsyncStartResult GnssNeoM9n_RfDiagnosticsAsyncStart(uint8_t instance);
GnssNeoM9nAsyncPollResult GnssNeoM9n_RfDiagnosticsAsyncPoll(uint8_t instance,
    GnssNeoM9nRfDiagnostics *diagnostics);
void GnssNeoM9n_RfDiagnosticsAsyncCancel(uint8_t instance,
    GnssNeoM9nConfigReadResult result,
    GnssNeoM9nTransactionDetail detail);
uint8_t GnssNeoM9n_GetRfDiagnostics(uint8_t instance,
    GnssNeoM9nRfDiagnostics *diagnostics);
int GnssNeoM9n_SaveConfig(uint8_t instance, uint8_t layers, uint8_t *saved_count);
uint8_t GnssNeoM9n_GetSaveCacheCount(uint8_t instance);
uint8_t GnssNeoM9n_IsBaudCached(uint8_t instance);
void GnssNeoM9n_StreamDiagnosticsGet(uint8_t instance,
    GnssNeoM9nStreamDiagnostics *diagnostics);
# 11 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 2
# 1 "Devices/GNSS/NEO_M9N/Adapter/Inc/neo_m9n_instance.h" 1

#define __NEO_M9N_INSTANCE_H 





const char *NeoM9nGnssInstance_NameGet(uint8_t instance);
SystemDeviceResult NeoM9nGnssInstance_Init(uint8_t instance);
SystemDeviceResult NeoM9nGnssInstance_Start(uint8_t instance);
SystemDeviceResult NeoM9nGnssInstance_Stop(uint8_t instance);
SystemDeviceResult NeoM9nGnssInstance_RuntimeOwnerActivate(uint8_t instance);
SystemDeviceResult NeoM9nGnssInstance_Process(uint8_t instance);
SystemDeviceResult NeoM9nGnssInstance_InfoGet(
    uint8_t instance, SystemDeviceInfo *info);
SystemDeviceResult NeoM9nGnssInstance_CapabilitiesGet(
    uint8_t instance, uint32_t *capability_mask);
SystemDeviceResult NeoM9nGnssInstance_HealthGet(
    uint8_t instance, SystemDeviceHealth *health);
SystemDeviceResult NeoM9nGnssInstance_RecoveryBusyGet(
    uint8_t instance, uint8_t *busy);
SystemDeviceResult NeoM9nGnssInstance_IoDiagnosticsGet(
    uint8_t instance, SystemDeviceIoDiagnostics *diagnostics);
SystemDeviceResult NeoM9nGnssInstance_IoDetailGet(
    uint8_t instance, SystemGnssIoDetail *detail);
SystemDeviceResult NeoM9nGnssInstance_LatestSampleGet(
    uint8_t instance, SystemGnssSample *sample);
SystemDeviceResult NeoM9nGnssInstance_TimeGet(
    uint8_t instance, SystemGnssTime *time);
SystemDeviceResult NeoM9nGnssInstance_SelfTestRun(
    uint8_t instance, SystemDeviceSelfTestResult *result);
SystemDeviceResult NeoM9nGnssInstance_ConfigApply(
    uint8_t instance, const SystemGnssConfig *config,
    SystemDeviceConfigReport *report);
SystemDeviceResult NeoM9nGnssInstance_ConfigVerify(
    uint8_t instance, const SystemGnssConfig *config,
    SystemDeviceConfigReport *report);
SystemDeviceResult NeoM9nGnssInstance_EffectiveConfigGet(
    uint8_t instance, SystemGnssConfig *config);
SystemDeviceResult NeoM9nGnssInstance_NoiseCharacteristicsGet(
    uint8_t instance, SystemGnssNoiseCharacteristics *noise);
SystemDeviceResult NeoM9nGnssInstance_HardwareConfigRead(
    uint8_t instance, SystemGnssHardwareConfig *config);
SystemDeviceResult NeoM9nGnssInstance_LastConfigReportGet(
    uint8_t instance, SystemGnssConfigTransactionReport *report);
SystemDeviceResult NeoM9nGnssInstance_SatelliteDiagnosticsRead(
    uint8_t instance, SystemGnssSatelliteDiagnostics *diagnostics);
SystemDeviceResult NeoM9nGnssInstance_LatestSatelliteDiagnosticsGet(
    uint8_t instance, SystemGnssSatelliteDiagnostics *diagnostics);
SystemDeviceResult NeoM9nGnssInstance_RfDiagnosticsRead(
    uint8_t instance, SystemGnssRfDiagnostics *diagnostics);
SystemDeviceResult NeoM9nGnssInstance_LatestRfDiagnosticsGet(
    uint8_t instance, SystemGnssRfDiagnostics *diagnostics);
# 12 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 2
# 1 "Devices/GNSS/NEO_M9N/Adapter/Inc/neo_m9n_startup.h" 1

#define __NEO_M9N_STARTUP_H 



# 1 "System/Inc/system_device_startup.h" 1

#define __SYSTEM_DEVICE_STARTUP_H 



#define SYSTEM_DEVICE_STARTUP_MAX_CANDIDATES 10U
#define SYSTEM_DEVICE_STARTUP_MAX_PROBE_PASSES 2U

typedef enum
{
    SystemDeviceStartupState_Uninitialized = 0,
    SystemDeviceStartupState_Probing,
    SystemDeviceStartupState_Identified,
    SystemDeviceStartupState_ReadingConfig,
    SystemDeviceStartupState_ApplyingConfig,
    SystemDeviceStartupState_Reconnecting,
    SystemDeviceStartupState_VerifyingConfig,
    SystemDeviceStartupState_WaitingSample,
    SystemDeviceStartupState_Ready,
    SystemDeviceStartupState_Failed
} SystemDeviceStartupState;

typedef enum
{
    SystemDeviceStartupPersistence_None = 0,
    SystemDeviceStartupPersistence_Persistent
} SystemDeviceStartupPersistence;

typedef enum
{
    SystemDeviceStartupStep_Pending = 0,
    SystemDeviceStartupStep_Ok,
    SystemDeviceStartupStep_Failed
} SystemDeviceStartupStepResult;

typedef enum
{
    SystemDeviceStartupResult_Ok = 0,
    SystemDeviceStartupResult_InvalidArgument,
    SystemDeviceStartupResult_CandidateLimit
} SystemDeviceStartupResult;

typedef enum
{
    SystemDeviceStartupFailure_None = 0,
    SystemDeviceStartupFailure_NotPresent,
    SystemDeviceStartupFailure_ConfigRead,
    SystemDeviceStartupFailure_ConfigApply,
    SystemDeviceStartupFailure_Reconnect,
    SystemDeviceStartupFailure_ConfigVerify,
    SystemDeviceStartupFailure_SampleTimeout
} SystemDeviceStartupFailure;

typedef struct
{
    uint32_t baudrate;
    uint32_t protocol;
} SystemDeviceStartupCandidate;

typedef struct
{
    SystemDeviceStartupStepResult (*probe_start)(void *owner,
        const SystemDeviceStartupCandidate *candidate);
    SystemDeviceStartupStepResult (*probe_poll)(void *owner);
    SystemDeviceStartupStepResult (*config_read)(void *owner,
        uint32_t *difference_mask);
    SystemDeviceStartupStepResult (*config_apply)(void *owner,
        uint32_t difference_mask, uint8_t *reconnect_required);
    SystemDeviceStartupStepResult (*reconnect)(void *owner);
    SystemDeviceStartupStepResult (*config_verify)(void *owner);
    SystemDeviceStartupStepResult (*sample_poll)(void *owner);
} SystemDeviceStartupOperations;

typedef struct
{
    SystemDeviceStartupPersistence persistence;
    SystemDeviceStartupCandidate target;
    SystemDeviceStartupCandidate factory;
    const SystemDeviceStartupCandidate *supported_candidates;
    uint8_t supported_candidate_count;

    uint8_t probe_pass_count;
    uint32_t probe_timeout_ms;
    uint32_t stage_timeout_ms;
    uint32_t sample_timeout_ms;
    const SystemDeviceStartupOperations *operations;
    void *owner;
} SystemDeviceStartupConfig;

typedef struct
{
    SystemDeviceStartupState state;
    SystemDeviceStartupFailure failure;
    SystemDeviceStartupCandidate candidates[10U];
    uint8_t candidate_count;
    uint8_t candidate_index;
    uint8_t probe_pass_index;
    uint8_t probe_started;
    uint8_t reconnect_required;
    uint32_t state_entered_ms;
    uint32_t difference_mask;
    SystemDeviceStartupConfig config;
} SystemDeviceStartup;

SystemDeviceStartupResult SystemDeviceStartup_Init(
    SystemDeviceStartup *startup, const SystemDeviceStartupConfig *config);
void SystemDeviceStartup_Tick(SystemDeviceStartup *startup, uint32_t now_ms);
# 7 "Devices/GNSS/NEO_M9N/Adapter/Inc/neo_m9n_startup.h" 2


typedef enum
{
    NeoM9nStartupResult_Ok = 0,
    NeoM9nStartupResult_InvalidArgument,
    NeoM9nStartupResult_ControllerError
} NeoM9nStartupResult;

NeoM9nStartupResult NeoM9nStartup_Init(
    uint8_t instance, const SystemGnssConfig *target);
void NeoM9nStartup_Tick(uint8_t instance, uint32_t now_ms);

typedef enum
{
    NeoM9nStartupRecoveryState_None = 0,
    NeoM9nStartupRecoveryState_Backoff,
    NeoM9nStartupRecoveryState_Probing,
    NeoM9nStartupRecoveryState_Exhausted,
    NeoM9nStartupRecoveryState_Rejected,
    NeoM9nStartupRecoveryState_RestoreFailed,
    NeoM9nStartupRecoveryState_NoStream,
    NeoM9nStartupRecoveryState_Ready
} NeoM9nStartupRecoveryState;



typedef struct
{
    NeoM9nStartupRecoveryState state;
    uint8_t attempt_count;
    uint8_t last_probe_result;
    uint32_t last_confirmed_baudrate;
    uint32_t backoff_started_ms;
    uint32_t backoff_ms;
} NeoM9nStartupRecoveryDiagnostics;

uint8_t NeoM9nStartup_RecoveryPending(uint8_t instance);

NeoM9nStartupResult NeoM9nStartup_RecoveryDiagnosticsGet(
    uint8_t instance, NeoM9nStartupRecoveryDiagnostics *out);
SystemDeviceStartupState NeoM9nStartup_StateGet(uint8_t instance);
SystemDeviceStartupFailure NeoM9nStartup_FailureGet(uint8_t instance);
# 13 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 2
# 1 "Common/Inc/debug_log.h" 1

#define __DEBUG_LOG_H 



void DebugLog_Init(void);


uint16_t DebugLog_Write(const uint8_t *data, uint16_t len);
uint16_t DebugLog_WritePriority(const uint8_t *data, uint16_t len);


void DebugLog_Print(const char *fmt, ...);


uint16_t DebugLog_Read(uint8_t *data, uint16_t len);
uint16_t DebugLog_GetRxCount(void);


uint16_t DebugLog_GetDiscarded(void);


void DebugLog_ResetDiscarded(void);
# 14 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 2
# 1 "Platform/Inc/platform_critical.h" 1

#define __PLATFORM_CRITICAL_H 



typedef uint32_t PlatformCriticalState;

PlatformCriticalState PlatformCritical_Enter(void);
void PlatformCritical_Exit(PlatformCriticalState state);
# 15 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 2


# 1 "System/Inc/system_gnss_quality.h" 1

#define __SYSTEM_GNSS_QUALITY_H 





SystemDeviceResult SystemGnssQuality_Evaluate(SystemGnssSample *sample,
                                               uint64_t now_us);
# 18 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 2
# 1 "Common/Inc/silverstar_assert.h" 1

#define __SILVERSTAR_ASSERT_H 



# 1 "Common/Inc/silverstar_compiler.h" 1
# 7 "Common/Inc/silverstar_assert.h" 2

typedef enum
{
    SILVERSTAR_ASSERT_MODULE_APP = 1U,
    SILVERSTAR_ASSERT_MODULE_ALGORITHM,
    SILVERSTAR_ASSERT_MODULE_BOARD,
    SILVERSTAR_ASSERT_MODULE_COMMON,
    SILVERSTAR_ASSERT_MODULE_DEVICE,
    SILVERSTAR_ASSERT_MODULE_FLIGHT_LOGIC,
    SILVERSTAR_ASSERT_MODULE_GENERATED,
    SILVERSTAR_ASSERT_MODULE_INTERFACE,
    SILVERSTAR_ASSERT_MODULE_MODULES,
    SILVERSTAR_ASSERT_MODULE_PLATFORM,
    SILVERSTAR_ASSERT_MODULE_PROTOCOL,
    SILVERSTAR_ASSERT_MODULE_SYSTEM,
    SILVERSTAR_ASSERT_MODULE_OS
} SilverStarAssertModuleId;

typedef enum
{
    SILVERSTAR_ASSERT_REASON_NULL_POINTER = 1U,
    SILVERSTAR_ASSERT_REASON_ENUM_RANGE,
    SILVERSTAR_ASSERT_REASON_INDEX_RANGE,
    SILVERSTAR_ASSERT_REASON_LENGTH_RANGE,
    SILVERSTAR_ASSERT_REASON_STATE_INVARIANT,
    SILVERSTAR_ASSERT_REASON_SEQUENCE_INVARIANT,
    SILVERSTAR_ASSERT_REASON_TIME_INVARIANT,
    SILVERSTAR_ASSERT_REASON_FLOAT_NOT_FINITE,
    SILVERSTAR_ASSERT_REASON_LOOP_BOUND,
    SILVERSTAR_ASSERT_REASON_BUFFER_CAPACITY,
    SILVERSTAR_ASSERT_REASON_POSTCONDITION
} SilverStarAssertReasonId;

#define SILVERSTAR_FAULT_TASK_NAME_SIZE 16U
#define SILVERSTAR_FAULT_TASK_UNKNOWN UINT32_MAX

typedef enum
{
    SILVERSTAR_FAULT_ASSERT = 0U,
    SILVERSTAR_FAULT_STACK_OVERFLOW
} SilverStarFaultType;

typedef struct
{
    const char *file_name;
    uint64_t timestamp_us;
    uint32_t line;
    uint32_t sequence;
    SilverStarAssertModuleId module_id;
    SilverStarAssertReasonId reason_id;
    SilverStarFaultType fault_type;
    uintptr_t task_handle;
    uintptr_t task_name_address;
    uint32_t task_id;
    uint32_t system_state;
    uint32_t high_water_mark_words;
    char task_name[16U];
    uint8_t high_water_mark_valid;
    uint8_t timestamp_valid;
    uint8_t active;
} SilverStarAssertFaultRecord;

#define SILVERSTAR_ASSERT(expression_,module_id_,reason_id_) SilverStarAssert_Check((uint8_t)((expression_) != 0), (module_id_), __FILE__, (uint32_t)__LINE__, (reason_id_))






#define SILVERSTAR_ASSERT_OBJECT(object_,type_,module_id_) SilverStarAssert_ObjectCheck((object_), (uint32_t)_Alignof(type_), (module_id_), __FILE__, (uint32_t)__LINE__)




void SilverStarAssert_Check(uint8_t condition,
                            SilverStarAssertModuleId module_id,
                            const char *file_name,
                            uint32_t line,
                            SilverStarAssertReasonId reason_id);
void SilverStarAssert_ObjectCheck(const volatile void *object,
                                  uint32_t alignment,
                                  SilverStarAssertModuleId module_id,
                                  const char *file_name,
                                  uint32_t line);
__attribute__((noreturn)) void SilverStarAssert_Fail(
    SilverStarAssertModuleId module_id,
    const char *file_name,
    uint32_t line,
    SilverStarAssertReasonId reason_id);
uint8_t SilverStarAssert_FaultedGet(void);
void SilverStarAssert_StackOverflowContextSet(
    uintptr_t task_handle, uintptr_t task_name_address,
    uint32_t task_id, const char *stable_name, uint32_t system_state,
    uint32_t high_water_mark_words, uint8_t high_water_mark_valid);
__attribute__((warn_unused_result)) uint8_t SilverStarAssert_FaultRecordGet(
    SilverStarAssertFaultRecord *record);
# 19 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 2

typedef struct
{
    volatile uint8_t initialized;
    volatile uint8_t started;
    SystemDeviceHealth health;
    SystemGnssConfig effective_config;
    SystemGnssConfig startup_target;
    SystemGnssConfigTransactionReport config_transaction;
    uint8_t startup_active;
    uint8_t startup_reported;
} NeoM9nAdapterContext;

static NeoM9nAdapterContext
    s_contexts[1U];

#define s_initialized (s_contexts[instance].initialized)
#define s_started (s_contexts[instance].started)
#define s_health (s_contexts[instance].health)
#define s_effective_config (s_contexts[instance].effective_config)
#define s_config_transaction (s_contexts[instance].config_transaction)

typedef enum
{
    NeoM9nRuntimeRequestNone = 0,
    NeoM9nRuntimeRequestHardwareConfig,
    NeoM9nRuntimeRequestNavSat,
    NeoM9nRuntimeRequestMonRf
} NeoM9nRuntimeRequest;

typedef enum
{
    NeoM9nRuntimeTransactionIdle = 0,
    NeoM9nRuntimeTransactionSubmitted,
    NeoM9nRuntimeTransactionSendRequest,
    NeoM9nRuntimeTransactionWaitResponse,
    NeoM9nRuntimeTransactionProcessResponse,
    NeoM9nRuntimeTransactionNextStep,
    NeoM9nRuntimeTransactionComplete,
    NeoM9nRuntimeTransactionFailed
} NeoM9nRuntimeTransactionState;

typedef union
{
    SystemGnssHardwareConfig hardware_config;
    SystemGnssSatelliteDiagnostics satellite;
    SystemGnssRfDiagnostics rf;
} NeoM9nRuntimeTransactionOutput;

typedef struct
{
    NeoM9nRuntimeTransactionState state;
    NeoM9nRuntimeRequest request;
    uint32_t transaction_id;
    uint32_t next_transaction_id;
    uint32_t start_ms;
    uint32_t timeout_ms;
    uint32_t expected_key;
    SystemDeviceResult result;
    uint8_t expected_class;
    uint8_t expected_id;
    uint8_t abandoned;
    GnssNeoM9nConfigSnapshot device_config;
    GnssNeoM9nConfigReadDiagnostics device_config_diagnostics;
    GnssNeoM9nConfigReadResult device_config_result;
    uint32_t device_config_elapsed_ms;
    GnssNeoM9nSatelliteDiagnostics device_satellite;
    GnssNeoM9nRfDiagnostics device_rf;
    NeoM9nRuntimeTransactionOutput output;
} NeoM9nRuntimeTransaction;


typedef struct
{
    NeoM9nRuntimeTransactionState state;
    NeoM9nRuntimeRequest request;
    uint32_t transaction_id;
    uint32_t start_ms;
    uint32_t timeout_ms;
    uint8_t abandoned;
} NeoM9nRuntimeTransactionSnapshot;

static volatile uint8_t
    s_runtime_owner_active_contexts[1U];
static NeoM9nRuntimeTransaction
    s_runtime_transactions[1U];

#define s_runtime_owner_active (s_runtime_owner_active_contexts[instance])

#define s_runtime_transaction (s_runtime_transactions[instance])

static PlatformUartId NeoM9nAdapter_UartGet(uint8_t instance)
{
    ProjectNeoM9nResources resources;

    if (ProjectNeoM9nResources_Get(instance, &resources) != SYSTEM_DEVICE_OK)
    {
        return (PlatformUartId)PLATFORM_UART_COUNT;
    }
    return resources.uart;
}

#define NEO_M9N_RUNTIME_TRANSACTION_TIMEOUT_MS (2U * GNSS_CONFIG_READ_TIMEOUT_MS)

#define NEO_M9N_RUNTIME_WAIT_MAX_POLLS 8192U

#define NEO_M9N_SUPPORTED_CONFIG_MASK (SYSTEM_GNSS_CFG_NAVIGATION_RATE | SYSTEM_GNSS_CFG_CONSTELLATIONS | SYSTEM_GNSS_CFG_DYNAMIC_MODEL | SYSTEM_GNSS_CFG_OUTPUT_PROTOCOL | SYSTEM_GNSS_CFG_ENABLED_MESSAGES)




static uint32_t NeoM9nGnssAdapter_IrqLock(void)
{
    return PlatformCritical_Enter();
}

static void NeoM9nGnssAdapter_IrqUnlock(uint32_t primask)
{
    PlatformCritical_Exit(primask);
}

static SystemDeviceResult NeoM9nGnssAdapter_ReadHardwareConfigDirect(uint8_t instance,
    SystemGnssHardwareConfig *config);
static SystemDeviceResult NeoM9nGnssAdapter_ReadSatelliteDiagnosticsDirect(uint8_t instance,
    SystemGnssSatelliteDiagnostics *diagnostics);
static SystemDeviceResult NeoM9nGnssAdapter_ReadRfDiagnosticsDirect(uint8_t instance,
    SystemGnssRfDiagnostics *diagnostics);
static void NeoM9nGnssAdapter_RuntimeTransactionProcess(uint8_t instance);

static void NeoM9nGnssAdapter_TransactionReset(uint8_t instance)
{
    (void)memset(&(s_contexts[instance].config_transaction), 0, sizeof((s_contexts[instance].config_transaction)));
    (s_contexts[instance].config_transaction).uart_baudrate_result = SYSTEM_DEVICE_NOT_EXECUTED;
    (s_contexts[instance].config_transaction).uart_settle_result = SYSTEM_DEVICE_NOT_EXECUTED;
    (s_contexts[instance].config_transaction).protocol_result = SYSTEM_DEVICE_NOT_EXECUTED;
    (s_contexts[instance].config_transaction).nav_pvt_result = SYSTEM_DEVICE_NOT_EXECUTED;
    (s_contexts[instance].config_transaction).rate_result = SYSTEM_DEVICE_NOT_EXECUTED;
    (s_contexts[instance].config_transaction).dynamic_model_result = SYSTEM_DEVICE_NOT_EXECUTED;
    (s_contexts[instance].config_transaction).signals_result = SYSTEM_DEVICE_NOT_EXECUTED;
    (s_contexts[instance].config_transaction).pvt_recovery_result = SYSTEM_DEVICE_NOT_EXECUTED;
    (s_contexts[instance].config_transaction).verify_result = SYSTEM_DEVICE_NOT_EXECUTED;
    (s_contexts[instance].config_transaction).verify_read_result =
        SYSTEM_GNSS_CONFIG_READ_NOT_READY;
}

static SystemDeviceResult NeoM9nGnssAdapter_Init(uint8_t instance)
{
    SilverStarAssert_ObjectCheck((&(s_contexts[instance].health)), (uint32_t)_Alignof(SystemDeviceHealth), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)166)
                                        ;
    if ((s_contexts[instance].initialized) != 0U) { return SYSTEM_DEVICE_ALREADY_MATCHED; }
    (void)memset(&(s_contexts[instance].health), 0, sizeof((s_contexts[instance].health)));
    (void)memset(&(s_contexts[instance].effective_config), 0, sizeof((s_contexts[instance].effective_config)));
    (void)memset(&s_contexts[instance].startup_target, 0,
        sizeof(s_contexts[instance].startup_target));
    (void)memset(&(s_runtime_transactions[instance]), 0,
                 sizeof((s_runtime_transactions[instance])));
    (s_runtime_owner_active_contexts[instance]) = 0U;
    s_contexts[instance].startup_active = 0U;
    s_contexts[instance].startup_reported = 0xFFU;
    NeoM9nGnssAdapter_TransactionReset(instance);
    (s_contexts[instance].effective_config).navigation_rate_hz = 1U;
    (s_contexts[instance].effective_config).constellation_mask = (1UL << 0) |
        (1UL << 1) | (1UL << 2);
    (s_contexts[instance].effective_config).dynamic_model = SYSTEM_GNSS_DYNAMIC_MODEL_PORTABLE;
    (s_contexts[instance].effective_config).output_protocol = SYSTEM_GNSS_OUTPUT_PROTOCOL_UBX;
    (s_contexts[instance].effective_config).enabled_message_mask = 0U;
    (s_contexts[instance].effective_config).requested_mask = 0U;
    if (GnssNeoM9n_Init(instance) != GnssNeoM9n_InitOk)
    {
        (s_contexts[instance].health).error_count++;
        return SYSTEM_DEVICE_IO_ERROR;
    }
    (s_contexts[instance].initialized) = 1U;
    (s_contexts[instance].health).initialized = 1U;
    return SYSTEM_DEVICE_OK;
}

static SystemDeviceResult NeoM9nGnssAdapter_Start(uint8_t instance)
{
    uint32_t primask;

    if ((s_contexts[instance].initialized) == 0U) { return SYSTEM_DEVICE_NOT_READY; }
    if ((s_contexts[instance].started) != 0U) { return SYSTEM_DEVICE_ALREADY_MATCHED; }
    primask = NeoM9nGnssAdapter_IrqLock();
    (s_contexts[instance].started) = 1U;
    (s_contexts[instance].health).started = 1U;
    NeoM9nGnssAdapter_IrqUnlock(primask);
    return SYSTEM_DEVICE_OK;
}

static SystemDeviceResult NeoM9nGnssAdapter_Stop(uint8_t instance)
{
    uint32_t primask = NeoM9nGnssAdapter_IrqLock();

    (s_contexts[instance].started) = 0U;
    (s_contexts[instance].health).started = 0U;
    NeoM9nGnssAdapter_IrqUnlock(primask);
    return SYSTEM_DEVICE_OK;
}

static SystemDeviceResult NeoM9nGnssAdapter_RuntimeOwnerActivate(uint8_t instance)
{
    uint32_t primask;

    if ((s_contexts[instance].started) == 0U) { return SYSTEM_DEVICE_NOT_READY; }
    primask = NeoM9nGnssAdapter_IrqLock();
    if ((s_runtime_owner_active_contexts[instance]) != 0U)
    {
        NeoM9nGnssAdapter_IrqUnlock(primask);
        return SYSTEM_DEVICE_ALREADY_MATCHED;
    }
    (s_runtime_owner_active_contexts[instance]) = 1U;
    NeoM9nGnssAdapter_IrqUnlock(primask);
    return SYSTEM_DEVICE_OK;
}

static uint8_t NeoM9nGnssAdapter_StartupProcess(
    uint8_t instance, uint32_t now_ms)
{
    SystemDeviceStartupState state;

    SilverStarAssert_Check((uint8_t)((instance < 1U) != 0), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)240, (SILVERSTAR_ASSERT_REASON_INDEX_RANGE))

                                             ;
    SilverStarAssert_ObjectCheck((&s_contexts[instance]), (uint32_t)_Alignof(NeoM9nAdapterContext), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)243)
                                        ;
    if ((s_contexts[instance].startup_active == 0U) &&
        (NeoM9nStartup_RecoveryPending(instance) == 0U)) { return 1U; }
    NeoM9nStartup_Tick(instance, now_ms);
    state = NeoM9nStartup_StateGet(instance);
    if (s_contexts[instance].startup_reported != (uint8_t)state)
    {
        DebugLog_Print("NEO-M9N startup state=%u failure=%u",
            (unsigned int)state,
            (unsigned int)NeoM9nStartup_FailureGet(instance));
        s_contexts[instance].startup_reported = (uint8_t)state;
    }
    if (state == SystemDeviceStartupState_Ready)
    {
        (s_contexts[instance].effective_config) = s_contexts[instance].startup_target;
        (s_contexts[instance].config_transaction).verify_result = SYSTEM_DEVICE_OK;
        (s_contexts[instance].config_transaction).verify_read_result =
            SYSTEM_GNSS_CONFIG_READ_RESPONSE_OK;
        s_contexts[instance].startup_active = 0U;
        return 1U;
    }
    if ((state == SystemDeviceStartupState_Failed) &&
        (s_contexts[instance].startup_active != 0U))
    {
        (s_contexts[instance].health).error_count++;
        (s_contexts[instance].config_transaction).verify_result = SYSTEM_DEVICE_VERIFY_FAILED;
        (s_contexts[instance].config_transaction).failed_stage = SYSTEM_GNSS_CONFIG_STAGE_VERIFY;
        s_contexts[instance].startup_active = 0U;
    }
    return 0U;
}

static void NeoM9nGnssAdapter_Process(uint8_t instance)
{
    GnssNeoM9nData data;
    GnssNeoM9nStatusSnapshot status;
    PlatformUartDiagnostics io_diagnostics;
    SystemDeviceHealth health;
    uint64_t now_us;
    uint32_t now_ms;
    uint8_t recent_ubx;
    uint8_t recent_unknown;
    uint8_t startup_ready;
    uint32_t primask;

    SilverStarAssert_ObjectCheck((&(s_contexts[instance].health)), (uint32_t)_Alignof(SystemDeviceHealth), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)289)
                                        ;
    if ((s_contexts[instance].started) == 0U) { return; }
    now_us = PlatformTime_Us();
    now_ms = (uint32_t)(now_us / 1000ULL);
    (void)GnssNeoM9n_Process(instance, now_ms);
    startup_ready = NeoM9nGnssAdapter_StartupProcess(instance, now_ms);
    if ((startup_ready != 0U) &&
        (NeoM9nStartup_RecoveryPending(instance) == 0U))
    { NeoM9nGnssAdapter_RuntimeTransactionProcess(instance); }
    (void)GnssNeoM9n_GetData(instance, &data);
    GnssNeoM9n_GetStatusSnapshot(instance, &status);
    (void)PlatformUart_DiagnosticsGet(NeoM9nAdapter_UartGet(instance), &io_diagnostics);
    primask = NeoM9nGnssAdapter_IrqLock();
    health = (s_contexts[instance].health);
    NeoM9nGnssAdapter_IrqUnlock(primask);
    health.last_sample_timestamp_us = data.lastUpdate_us;
    health.last_receive_timestamp_us = data.lastUpdate_us;
    health.sample_count = data.pvtSequence;
    health.checksum_error_count = status.ubx_checksum_error_count +
                                  status.nmea_checksum_error_count;
    recent_ubx = (uint8_t)((status.last_ubx_ms != 0U) &&
                           ((now_ms - status.last_ubx_ms) <= 1500U));
    recent_unknown = (uint8_t)((status.last_unknown_ms != 0U) &&
        ((now_ms - status.last_unknown_ms) <= 1500U));



    health.online = (uint8_t)(((s_contexts[instance].started) != 0U) && (data.online != 0U) &&
        ((s_contexts[instance].startup_target.navigation_rate_hz == 0U) ||
         (NeoM9nStartup_StateGet(instance) == SystemDeviceStartupState_Ready)));
    health.healthy = (uint8_t)((health.online != 0U) &&
                               (recent_ubx != 0U) &&
                               (recent_unknown == 0U) &&
                               (io_diagnostics.rx_active != 0U) &&
                               ((s_contexts[instance].startup_target.navigation_rate_hz == 0U) ||
                                (NeoM9nStartup_StateGet(instance) == SystemDeviceStartupState_Ready)));
    primask = NeoM9nGnssAdapter_IrqLock();
    (s_contexts[instance].health) = health;
    NeoM9nGnssAdapter_IrqUnlock(primask);
}

static SystemDeviceResult NeoM9nGnssAdapter_GetInfo(SystemDeviceInfo *info)
{
    if (info == 
# 333 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
               ((void *)0)
# 333 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                   ) { return SYSTEM_DEVICE_INVALID_ARGUMENT; }
    info->device_name = "NEO-M9N GNSS Adapter";
    info->model_name = "NEO-M9N";
    info->driver_version = "SilverStar " "0" "." "1" "." "2";
    info->capability_mask = (1UL << 0) |
                            (1UL << 1) |
                            (1UL << 2) |
                            (1UL << 3) |
                            (1UL << 4) |
                            (1UL << 5) |
                            (1UL << 6) |
                            (1UL << 7) |
                            (1UL << 8) |
                            (1UL << 9) |
                            (1UL << 10);
    info->configuration_mask = ((1UL << 0) | (1UL << 1) | (1UL << 2) | (1UL << 3) | (1UL << 4));
    return SYSTEM_DEVICE_OK;
}

static SystemDeviceResult NeoM9nGnssAdapter_GetCapabilities(uint32_t *mask)
{
    SystemDeviceInfo info;

    if (mask == 
# 356 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
               ((void *)0)
# 356 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                   ) { return SYSTEM_DEVICE_INVALID_ARGUMENT; }
    (void)NeoM9nGnssAdapter_GetInfo(&info);
    *mask = info.capability_mask;
    return SYSTEM_DEVICE_OK;
}

static SystemDeviceResult NeoM9nGnssAdapter_GetHealth(uint8_t instance, SystemDeviceHealth *health)
{
    uint32_t primask;

    if (health == 
# 366 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                 ((void *)0)
# 366 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                     ) { return SYSTEM_DEVICE_INVALID_ARGUMENT; }
    primask = NeoM9nGnssAdapter_IrqLock();
    *health = (s_contexts[instance].health);
    NeoM9nGnssAdapter_IrqUnlock(primask);
    return SYSTEM_DEVICE_OK;
}

static void NeoM9nGnssAdapter_SampleValiditySet(
    const GnssNeoM9nData *data,
    SystemGnssSample *sample)
{
    if ((data == 
# 377 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                ((void *)0)
# 377 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                    ) || (sample == 
# 377 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                                    ((void *)0)
# 377 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                                        )) { return; }
    SilverStarAssert_ObjectCheck((data), (uint32_t)_Alignof(GnssNeoM9nData), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)378)
                                        ;
    SilverStarAssert_ObjectCheck((sample), (uint32_t)_Alignof(SystemGnssSample), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)380)
                                        ;
    sample->supported_fields = (1UL << 0) |
        (1UL << 1) | (1UL << 2) |
        (1UL << 3) | (1UL << 4) |
        (1UL << 5) |
        (1UL << 6) |
        (1UL << 7) |
        (1UL << 8) |
        (1UL << 9);
    sample->valid_fields = (1UL << 0) |
        (1UL << 1) | (1UL << 2);
    if ((data->gnssFixOK != 0U) && (data->fixType >= 2U))
    {
        sample->valid_fields |= (1UL << 3) |
            (1UL << 5) |
            (1UL << 7) |
            (1UL << 9);
    }
    if ((data->gnssFixOK != 0U) &&
        ((data->fixType == 3U) || (data->fixType == 4U)))
    {
        sample->valid_fields |= (1UL << 4) |
            (1UL << 6) |
            (1UL << 8);
    }
}

static SystemDeviceResult NeoM9nGnssAdapter_GetSample(uint8_t instance, SystemGnssSample *sample)
{
    GnssNeoM9nData data;
    float speed_std_mps;
    float speed_variance;
    uint8_t index;

    if (sample == 
# 415 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                 ((void *)0)
# 415 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                     ) { return SYSTEM_DEVICE_INVALID_ARGUMENT; }
    SilverStarAssert_ObjectCheck((sample), (uint32_t)_Alignof(SystemGnssSample), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)416)
                                        ;

    if ((s_contexts[instance].startup_target.navigation_rate_hz != 0U) &&
        (NeoM9nStartup_StateGet(instance) != SystemDeviceStartupState_Ready))
    { return SYSTEM_DEVICE_NOT_READY; }
    if (GnssNeoM9n_GetData(instance, &data) == 0U) { return SYSTEM_DEVICE_NOT_READY; }
    (void)memset(sample, 0, sizeof(*sample));
    sample->sample_timestamp_us = data.lastUpdate_us;
    sample->receive_timestamp_us = data.lastUpdate_us;
    sample->sequence = data.pvtSequence;
    NeoM9nGnssAdapter_SampleValiditySet(&data, sample);
    sample->latitude_e7 = data.lat;
    sample->longitude_e7 = data.lon;
    sample->ellipsoid_height_mm = data.height;
    sample->msl_height_mm = data.hMSL;
    sample->velocity_enu_mps[0] = (float)data.velE * 0.001f;
    sample->velocity_enu_mps[1] = (float)data.velN * 0.001f;

    sample->velocity_enu_mps[2] = -(float)data.velD * 0.001f;
    speed_std_mps = (float)data.sAcc * 0.001f;
    speed_variance = speed_std_mps * speed_std_mps;
    for (index = 0U; index < 3U; index++)
    {
        sample->velocity_variance_m2ps2[index] = speed_variance;
    }
    sample->horizontal_accuracy_m = (float)data.hAcc * 0.001f;
    sample->vertical_accuracy_m = (float)data.vAcc * 0.001f;
    sample->speed_accuracy_mps = speed_std_mps;
    sample->fix_type = data.fixType;
    sample->fix_ok = data.gnssFixOK;
    sample->satellite_count = data.numSV;
    sample->course_usable = data.courseUsable;
    sample->online = data.online;
    return SystemGnssQuality_Evaluate(sample, PlatformTime_Us());
}

static SystemDeviceResult NeoM9nGnssAdapter_GetIoDiagnostics(uint8_t instance,
    SystemDeviceIoDiagnostics *diagnostics)
{
    PlatformUartDiagnostics source;

    if (diagnostics == 
# 458 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                      ((void *)0)
# 458 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                          ) { return SYSTEM_DEVICE_INVALID_ARGUMENT; }
    SilverStarAssert_ObjectCheck((diagnostics), (uint32_t)_Alignof(SystemDeviceIoDiagnostics), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)459)
                                        ;
    (void)PlatformUart_DiagnosticsGet(NeoM9nAdapter_UartGet(instance), &source);
    (void)memset(diagnostics, 0, sizeof(*diagnostics));
    diagnostics->supported_mask = (1UL << 0) |
        (1UL << 1) |
        (1UL << 2) |
        (1UL << 3) |
        (1UL << 4) |
        (1UL << 5) |
        (1UL << 6) |
        (1UL << 7) |
        (1UL << 8) |
        (1UL << 9) |
        (1UL << 10) |
        (1UL << 11) |
        (1UL << 12) |
        (1UL << 13) |
        (1UL << 14) |
        (1UL << 17) |
        (1UL << 21);
    diagnostics->valid_mask = diagnostics->supported_mask;
    diagnostics->transport_type = SYSTEM_DEVICE_TRANSPORT_UART;
    diagnostics->owner = SYSTEM_DEVICE_IO_OWNER_SELF;
    diagnostics->rx_bytes = source.rx_bytes;
    diagnostics->tx_bytes = source.tx_bytes;
    diagnostics->rx_event_count = source.rx_event_count;
    diagnostics->rx_idle_event_count = source.rx_idle_event_count;
    diagnostics->rx_transfer_complete_count =
        source.rx_transfer_complete_count;
    diagnostics->rx_discarded_bytes = source.rx_discarded_bytes;
    diagnostics->uart_overrun_error_count =
        source.uart_overrun_error_count;
    diagnostics->uart_framing_error_count =
        source.uart_framing_error_count;
    diagnostics->uart_noise_error_count = source.uart_noise_error_count;
    diagnostics->uart_parity_error_count = source.uart_parity_error_count;
    diagnostics->dma_error_count = source.dma_error_count;
    diagnostics->rx_restart_count = source.rx_restart_count;
    diagnostics->rx_restart_failure_count = source.rx_restart_failure_count;
    diagnostics->rx_discontinuity_count = source.rx_discontinuity_count;
    diagnostics->transport_error_count = source.transport_error_count;
    diagnostics->rx_active = source.rx_active;
    return SYSTEM_DEVICE_OK;
}

static SystemDeviceResult NeoM9nGnssAdapter_GetIoDetail(uint8_t instance,
    SystemGnssIoDetail *detail)
{
    GnssNeoM9nStreamDiagnostics source;

    if (detail == 
# 510 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                 ((void *)0)
# 510 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                     ) { return SYSTEM_DEVICE_INVALID_ARGUMENT; }
    GnssNeoM9n_StreamDiagnosticsGet(instance, &source);
    detail->ubx_frame_count = source.ubx_frame_count;
    detail->ubx_checksum_error_count = source.ubx_checksum_error_count;
    detail->nmea_sentence_count = source.nmea_sentence_count;
    detail->nmea_checksum_ok_count = source.nmea_checksum_ok_count;
    detail->nmea_checksum_error_count = source.nmea_checksum_error_count;
    detail->unknown_byte_count = source.unknown_byte_count;
    detail->parser_resync_count = source.parser_resync_count;
    return SYSTEM_DEVICE_OK;
}

static SystemDeviceResult NeoM9nGnssAdapter_GetTime(uint8_t instance, SystemGnssTime *time)
{
    GnssNeoM9nData data;

    if (time == 
# 526 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
               ((void *)0)
# 526 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                   ) { return SYSTEM_DEVICE_INVALID_ARGUMENT; }
    SilverStarAssert_ObjectCheck((time), (uint32_t)_Alignof(SystemGnssTime), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)527)
                                        ;
    if (GnssNeoM9n_GetData(instance, &data) == 0U) { return SYSTEM_DEVICE_NOT_READY; }
    (void)memset(time, 0, sizeof(*time));
    time->sample_timestamp_us = data.lastUpdate_us;
    time->receive_timestamp_us = data.lastUpdate_us;
    time->sequence = data.pvtSequence;
    time->time_of_week_ms = data.iTOW;
    time->year = data.year;
    time->month = data.month;
    time->day = data.day;
    time->hour = data.hour;
    time->minute = data.min;
    time->second = data.sec;
    time->date_valid = data.validDate;
    time->time_valid = data.validTime;
    time->fully_resolved = (uint8_t)(data.validDate && data.validTime);
    return (time->time_valid != 0U) ? SYSTEM_DEVICE_OK : SYSTEM_DEVICE_NOT_READY;
}

static SystemDeviceResult NeoM9nGnssAdapter_SelfTest(
    SystemDeviceSelfTestResult *result)
{
    if (result == 
# 550 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                 ((void *)0)
# 550 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                     ) { return SYSTEM_DEVICE_INVALID_ARGUMENT; }
    (void)memset(result, 0, sizeof(*result));
    result->unsupported_mask = 1U;
    return SYSTEM_DEVICE_UNSUPPORTED;
}

static SystemDeviceResult NeoM9nGnssAdapter_ConfigCheck(
    const SystemGnssConfig *config,
    SystemDeviceConfigReport *report)
{
    if ((config == 
# 560 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                  ((void *)0)
# 560 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                      ) || (report == 
# 560 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                                      ((void *)0)
# 560 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                                          ))
    {
        return SYSTEM_DEVICE_INVALID_ARGUMENT;
    }
    SilverStarAssert_ObjectCheck((config), (uint32_t)_Alignof(SystemGnssConfig), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)564)
                                        ;
    SilverStarAssert_ObjectCheck((report), (uint32_t)_Alignof(SystemDeviceConfigReport), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)566)
                                        ;
    (void)memset(report, 0, sizeof(*report));
    report->requested_mask = config->requested_mask;
    report->required_mask = config->required_mask;
    report->supported_mask = ((1UL << 0) | (1UL << 1) | (1UL << 2) | (1UL << 3) | (1UL << 4));
    report->unsupported_required_mask = config->required_mask &
                                        ~((1UL << 0) | (1UL << 1) | (1UL << 2) | (1UL << 3) | (1UL << 4));
    report->unsupported_optional_mask = (config->requested_mask &
        ~((1UL << 0) | (1UL << 1) | (1UL << 2) | (1UL << 3) | (1UL << 4))) & ~config->required_mask;
    if ((report->unsupported_required_mask != 0U) ||
        (((config->requested_mask & (1UL << 0)) != 0U) &&
         ((config->navigation_rate_hz == 0U) ||
          (config->navigation_rate_hz > 25U))) ||
        (((config->requested_mask & (1UL << 2)) != 0U) &&
         (config->dynamic_model > SYSTEM_GNSS_DYNAMIC_MODEL_AIRBORNE_4G)) ||
        (((config->requested_mask & (1UL << 3)) != 0U) &&
         (config->output_protocol >
          SYSTEM_GNSS_OUTPUT_PROTOCOL_UBX_AND_NMEA)) ||
        (((config->requested_mask & (1UL << 1)) != 0U) &&
         ((config->constellation_mask == 0U) ||
          ((config->constellation_mask &
            ~((1UL << 0) |
              (1UL << 1) |
              (1UL << 2) |
              (1UL << 3))) != 0U))) ||
        (((config->requested_mask & (1UL << 4)) != 0U) &&
         ((config->enabled_message_mask &
           ~(1UL << 0)) != 0U)))
    {
        report->verify_failed_mask = config->requested_mask;
        return SYSTEM_DEVICE_VERIFY_FAILED;
    }
    report->matched_mask = config->requested_mask &
                           ((1UL << 0) | (1UL << 1) | (1UL << 2) | (1UL << 3) | (1UL << 4));
    report->success = 1U;
    return (report->unsupported_optional_mask != 0U) ?
        SYSTEM_DEVICE_UNSUPPORTED : SYSTEM_DEVICE_OK;
}


static SystemGnssConfigReadResult NeoM9nGnssAdapter_ConfigReadResultMap(uint8_t instance,
    GnssNeoM9nConfigReadResult result)
{
    SilverStarAssert_ObjectCheck((&(s_contexts[instance].config_transaction)), (uint32_t)_Alignof(SystemGnssConfigTransactionReport), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)610)
                                                                           ;
    switch (result)
    {
        case GnssNeoM9nConfigReadResponseOk:
            return SYSTEM_GNSS_CONFIG_READ_RESPONSE_OK;
        case GnssNeoM9nConfigReadNak:
            return SYSTEM_GNSS_CONFIG_READ_NAK;
        case GnssNeoM9nConfigReadTxError:
            return SYSTEM_GNSS_CONFIG_READ_TX_ERROR;
        case GnssNeoM9nConfigReadChecksumError:
            return SYSTEM_GNSS_CONFIG_READ_CHECKSUM_ERROR;
        case GnssNeoM9nConfigReadMalformedResponse:
            return SYSTEM_GNSS_CONFIG_READ_MALFORMED_RESPONSE;
        case GnssNeoM9nConfigReadTimeout:
            return SYSTEM_GNSS_CONFIG_READ_TIMEOUT;
        case GnssNeoM9nConfigReadIoError:
            return SYSTEM_GNSS_CONFIG_READ_IO_ERROR;
        case GnssNeoM9nConfigReadNotReady:
        default:
            return SYSTEM_GNSS_CONFIG_READ_NOT_READY;
    }
}

static SystemDeviceResult NeoM9nGnssAdapter_ConfigReadDeviceResultMap(
    GnssNeoM9nConfigReadResult result)
{
    switch (result)
    {
        case GnssNeoM9nConfigReadResponseOk: return SYSTEM_DEVICE_OK;
        case GnssNeoM9nConfigReadTimeout: return SYSTEM_DEVICE_TIMEOUT;
        case GnssNeoM9nConfigReadNotReady: return SYSTEM_DEVICE_NOT_READY;
        case GnssNeoM9nConfigReadIoError: return SYSTEM_DEVICE_IO_ERROR;
        case GnssNeoM9nConfigReadNak:
        case GnssNeoM9nConfigReadTxError:
        case GnssNeoM9nConfigReadChecksumError:
        case GnssNeoM9nConfigReadMalformedResponse:
        default: return SYSTEM_DEVICE_IO_ERROR;
    }
}

static SystemGnssConfigReadGroup NeoM9nGnssAdapter_ConfigReadGroupMap(
    GnssNeoM9nConfigReadGroup group)
{
    return (SystemGnssConfigReadGroup)group;
}

static SystemGnssTransactionDetail NeoM9nGnssAdapter_DetailMap(
    GnssNeoM9nTransactionDetail detail)
{
    return (SystemGnssTransactionDetail)detail;
}

static SystemGnssDynamicModel NeoM9nGnssAdapter_DynamicModelMap(
    uint8_t model)
{
    switch (model)
    {
        case 2U:
            return SYSTEM_GNSS_DYNAMIC_MODEL_STATIONARY;
        case 6U:
            return SYSTEM_GNSS_DYNAMIC_MODEL_AIRBORNE_1G;
        case 7U:
            return SYSTEM_GNSS_DYNAMIC_MODEL_AIRBORNE_2G;
        case 8U:
            return SYSTEM_GNSS_DYNAMIC_MODEL_AIRBORNE_4G;
        default:
            return SYSTEM_GNSS_DYNAMIC_MODEL_PORTABLE;
    }
}

static SystemGnssOutputProtocol NeoM9nGnssAdapter_OutputProtocolMap(
    uint8_t protocol)
{
    if (protocol == 0x02U) { return SYSTEM_GNSS_OUTPUT_PROTOCOL_NMEA; }
    if (protocol == 0x03U) { return SYSTEM_GNSS_OUTPUT_PROTOCOL_UBX_AND_NMEA; }
    return SYSTEM_GNSS_OUTPUT_PROTOCOL_UBX;
}


static SystemDeviceResult NeoM9nGnssAdapter_ApplyConfig(uint8_t instance,
    const SystemGnssConfig *config,
    SystemDeviceConfigReport *report)
{
    SystemDeviceResult validation =
        NeoM9nGnssAdapter_ConfigCheck(config, report);

    if ((validation != SYSTEM_DEVICE_OK) &&
        (validation != SYSTEM_DEVICE_UNSUPPORTED))
    { return validation; }
    if (instance >= 1U)
    { return SYSTEM_DEVICE_INVALID_ARGUMENT; }
    SilverStarAssert_ObjectCheck((config), (uint32_t)_Alignof(SystemGnssConfig), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)702)
                                        ;
    SilverStarAssert_ObjectCheck((report), (uint32_t)_Alignof(SystemDeviceConfigReport), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)704)
                                        ;
    if ((s_runtime_owner_active_contexts[instance]) != 0U) { return SYSTEM_DEVICE_BUSY; }
    if (NeoM9nStartup_Init(instance, config) != NeoM9nStartupResult_Ok)
    {
        report->failed_mask = config->requested_mask;
        return SYSTEM_DEVICE_VERIFY_FAILED;
    }
    s_contexts[instance].startup_active = 1U;
    s_contexts[instance].startup_reported = 0xFFU;
    s_contexts[instance].startup_target = *config;
    NeoM9nGnssAdapter_TransactionReset(instance);
    (s_contexts[instance].config_transaction).write_layers = 0x01U;
    report->delegated_mask = report->matched_mask;
    report->applied_mask = 0U;
    report->persisted = 0U;
    return SYSTEM_DEVICE_CONFIG_DELEGATED;
}

static SystemDeviceResult NeoM9nGnssAdapter_GetConfig(uint8_t instance, SystemGnssConfig *config)
{
    if (config == 
# 725 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                 ((void *)0)
# 725 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                     ) { return SYSTEM_DEVICE_INVALID_ARGUMENT; }
    *config = (s_contexts[instance].effective_config);
    return (config->requested_mask != 0U) ? SYSTEM_DEVICE_OK : SYSTEM_DEVICE_NOT_READY;
}

static SystemDeviceResult NeoM9nGnssAdapter_NoiseCharacteristicsGet(
    SystemGnssNoiseCharacteristics *noise)
{
    if (noise == 
# 733 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                ((void *)0)
# 733 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                    ) { return SYSTEM_DEVICE_INVALID_ARGUMENT; }
    (void)memset(noise, 0, sizeof(*noise));
    noise->recommended_horizontal_position_std_floor_m =
        1.5f;
    noise->recommended_vertical_position_std_floor_m =
        2.5f;
    noise->recommended_velocity_std_floor_mps =
        0.15f;
    noise->valid_mask =
        (1UL << 0) |
        (1UL << 1) |
        (1UL << 2);
    return SYSTEM_DEVICE_OK;
}

static SystemDeviceResult NeoM9nGnssAdapter_HardwareConfigMap(uint8_t instance,
    const GnssNeoM9nConfigSnapshot *snapshot,
    uint32_t elapsed_ms,
    const GnssNeoM9nConfigReadDiagnostics *diagnostics,
    GnssNeoM9nConfigReadResult result,
    SystemGnssHardwareConfig *config)
{
    if ((snapshot == 
# 755 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                    ((void *)0)
# 755 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                        ) || (diagnostics == 
# 755 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                                             ((void *)0)
# 755 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                                                 ) || (config == 
# 755 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                                                                 ((void *)0)
# 755 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                                                                     ))
    {
        return SYSTEM_DEVICE_INVALID_ARGUMENT;
    }
    SilverStarAssert_ObjectCheck((snapshot), (uint32_t)_Alignof(GnssNeoM9nConfigSnapshot), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)759)
                                        ;
    SilverStarAssert_ObjectCheck((config), (uint32_t)_Alignof(SystemGnssHardwareConfig), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)761)
                                        ;
    (void)memset(config, 0, sizeof(*config));
    config->elapsed_ms = elapsed_ms;
    config->valid_mask = snapshot->valid_mask;
    config->baudrate = snapshot->baudrate;
    config->constellation_mask = snapshot->constellations_mask;
    config->navigation_rate_hz = snapshot->rate_hz;
    config->dynamic_model = NeoM9nGnssAdapter_DynamicModelMap(
        snapshot->dynamic_model);
    config->output_protocol = NeoM9nGnssAdapter_OutputProtocolMap(
        snapshot->protocol_out);
    config->protocol_in = snapshot->protocol_in;
    config->nav_pvt_rate = snapshot->nav_pvt_rate;
    config->nav_pvt_known = snapshot->nav_pvt_known;
    config->read_result =
        NeoM9nGnssAdapter_ConfigReadResultMap(instance, result);
    config->failed_group = NeoM9nGnssAdapter_ConfigReadGroupMap(
        diagnostics->failed_group);
    config->failed_key = diagnostics->failed_key;
    config->response_length = diagnostics->response_length;
    config->nak_class = diagnostics->nak_class;
    config->nak_id = diagnostics->nak_id;
    config->detailed_result = NeoM9nGnssAdapter_DetailMap(
        diagnostics->detailed_result);
    config->expected_class = diagnostics->expected_class;
    config->expected_id = diagnostics->expected_id;
    config->received_class = diagnostics->received_class;
    config->received_id = diagnostics->received_id;
    config->response_version = diagnostics->response_version;
    return NeoM9nGnssAdapter_ConfigReadDeviceResultMap(result);
}

static SystemDeviceResult NeoM9nGnssAdapter_ReadHardwareConfigDirect(uint8_t instance,
    SystemGnssHardwareConfig *config)
{
    GnssNeoM9nConfigSnapshot snapshot;
    GnssNeoM9nConfigReadDiagnostics diagnostics;
    uint32_t elapsed_ms = 0U;
    GnssNeoM9nConfigReadResult result;

    if (config == 
# 802 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                 ((void *)0)
# 802 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                     ) { return SYSTEM_DEVICE_INVALID_ARGUMENT; }
    (void)memset(&snapshot, 0, sizeof(snapshot));
    (void)memset(&diagnostics, 0, sizeof(diagnostics));
    result = GnssNeoM9n_ReadHardwareConfig(instance, &snapshot, &elapsed_ms,
                                            &diagnostics);
    return NeoM9nGnssAdapter_HardwareConfigMap(instance,
        &snapshot, elapsed_ms, &diagnostics, result, config);
}

static SystemDeviceResult NeoM9nGnssAdapter_GetLastConfigReport(uint8_t instance,
    SystemGnssConfigTransactionReport *report)
{
    if (report == 
# 814 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                 ((void *)0)
# 814 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                     ) { return SYSTEM_DEVICE_INVALID_ARGUMENT; }
    *report = (s_contexts[instance].config_transaction);
    return SYSTEM_DEVICE_OK;
}

static SystemDeviceResult NeoM9nGnssAdapter_DiagnosticResultMap(int result)
{
    if (result == 0) { return SYSTEM_DEVICE_OK; }
    if (result == -2) { return SYSTEM_DEVICE_TIMEOUT; }
    if (result == -3) { return SYSTEM_DEVICE_NOT_READY; }
    if (result == -4) { return SYSTEM_DEVICE_INVALID_ARGUMENT; }
    return SYSTEM_DEVICE_IO_ERROR;
}

static SystemDeviceResult NeoM9nGnssAdapter_SatelliteDiagnosticsMap(uint8_t instance,
    const GnssNeoM9nSatelliteDiagnostics *source,
    SystemGnssSatelliteDiagnostics *destination)
{
    uint64_t now_us;
    uint64_t age_us;

    if ((source == 
# 835 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                  ((void *)0)
# 835 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                      ) || (destination == 
# 835 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                                           ((void *)0)
# 835 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                                               ))
    {
        return SYSTEM_DEVICE_INVALID_ARGUMENT;
    }
    SilverStarAssert_ObjectCheck((source), (uint32_t)_Alignof(GnssNeoM9nSatelliteDiagnostics), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)839)
                                        ;
    SilverStarAssert_ObjectCheck((destination), (uint32_t)_Alignof(SystemGnssSatelliteDiagnostics), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)841)
                                        ;
    (void)memset(destination, 0, sizeof(*destination));
    destination->sample_timestamp_us = source->timestamp_us;
    destination->receive_timestamp_us = source->timestamp_us;
    destination->sequence = source->sequence;
    destination->supported_fields = (1UL << 0) |
        (1UL << 1) |
        (1UL << 2);
    destination->satellite_count = source->satellite_count;
    destination->used_count = source->used_count;
    destination->average_cno_dbhz = source->average_cno_dbhz;
    destination->maximum_cno_dbhz = source->maximum_cno_dbhz;
    destination->average_quality = source->average_quality;
    destination->read_result = NeoM9nGnssAdapter_ConfigReadResultMap(instance,
        source->read_result);
    destination->detailed_result = NeoM9nGnssAdapter_DetailMap(
        source->detailed_result);
    destination->response_length = source->response_length;
    destination->expected_class = source->expected_class;
    destination->expected_id = source->expected_id;
    destination->received_class = source->received_class;
    destination->received_id = source->received_id;
    destination->expected_ck_a = source->expected_ck_a;
    destination->expected_ck_b = source->expected_ck_b;
    destination->received_ck_a = source->received_ck_a;
    destination->received_ck_b = source->received_ck_b;
    now_us = PlatformTime_Us();
    age_us = (now_us >= source->timestamp_us) ?
        (now_us - source->timestamp_us) : 
# 870 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                                         (0xffffffffffffffffULL)
# 870 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                                                   ;
    destination->fresh = (uint8_t)((source->valid != 0U) &&
        (age_us <= ((uint64_t)1500U * 1000ULL)));
    destination->valid_fields = (destination->fresh != 0U) ?
        destination->supported_fields : 0U;
    return (destination->fresh != 0U) ?
        SYSTEM_DEVICE_OK : SYSTEM_DEVICE_NOT_READY;
}

static SystemDeviceResult NeoM9nGnssAdapter_RfDiagnosticsMap(uint8_t instance,
    const GnssNeoM9nRfDiagnostics *source,
    SystemGnssRfDiagnostics *destination)
{
    uint64_t now_us;
    uint64_t age_us;

    if ((source == 
# 886 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                  ((void *)0)
# 886 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                      ) || (destination == 
# 886 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                                           ((void *)0)
# 886 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                                               ))
    {
        return SYSTEM_DEVICE_INVALID_ARGUMENT;
    }
    SilverStarAssert_ObjectCheck((source), (uint32_t)_Alignof(GnssNeoM9nRfDiagnostics), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)890)
                                        ;
    SilverStarAssert_ObjectCheck((destination), (uint32_t)_Alignof(SystemGnssRfDiagnostics), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)892)
                                        ;
    (void)memset(destination, 0, sizeof(*destination));
    destination->sample_timestamp_us = source->timestamp_us;
    destination->receive_timestamp_us = source->timestamp_us;
    destination->sequence = source->sequence;
    destination->supported_fields = (1UL << 0) |
        (1UL << 1) |
        (1UL << 2) |
        (1UL << 3);
    destination->noise_per_ms = source->noise_per_ms;
    destination->agc_count = source->agc_count;
    destination->rf_block_count = source->rf_block_count;
    destination->antenna_status = source->antenna_status;
    destination->antenna_power = source->antenna_power;
    destination->jamming_state = source->jamming_state;
    destination->cw_suppression = source->cw_suppression;
    destination->jamming_indicator = source->jamming_indicator;
    destination->read_result = NeoM9nGnssAdapter_ConfigReadResultMap(instance,
        source->read_result);
    destination->detailed_result = NeoM9nGnssAdapter_DetailMap(
        source->detailed_result);
    destination->response_length = source->response_length;
    now_us = PlatformTime_Us();
    age_us = (now_us >= source->timestamp_us) ?
        (now_us - source->timestamp_us) : 
# 917 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                                         (0xffffffffffffffffULL)
# 917 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                                                   ;
    destination->fresh = (uint8_t)((source->valid != 0U) &&
        (age_us <= ((uint64_t)1500U * 1000ULL)));
    destination->valid_fields = (destination->fresh != 0U) ?
        destination->supported_fields : 0U;
    return (destination->fresh != 0U) ?
        SYSTEM_DEVICE_OK : SYSTEM_DEVICE_NOT_READY;
}

static SystemDeviceResult NeoM9nGnssAdapter_ReadSatelliteDiagnosticsDirect(uint8_t instance,
    SystemGnssSatelliteDiagnostics *diagnostics)
{
    GnssNeoM9nSatelliteDiagnostics source;
    int result;

    if (diagnostics == 
# 932 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                      ((void *)0)
# 932 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                          ) { return SYSTEM_DEVICE_INVALID_ARGUMENT; }
    result = GnssNeoM9n_ReadSatelliteDiagnostics(instance, &source);
    if (result != 0)
    {
        (void)NeoM9nGnssAdapter_SatelliteDiagnosticsMap(instance, &source,
                                                         diagnostics);
        diagnostics->supported_fields =
            (1UL << 0) |
            (1UL << 1) |
            (1UL << 2);
        return NeoM9nGnssAdapter_DiagnosticResultMap(result);
    }
    return NeoM9nGnssAdapter_SatelliteDiagnosticsMap(instance, &source, diagnostics);
}

static SystemDeviceResult NeoM9nGnssAdapter_GetSatelliteDiagnostics(uint8_t instance,
    SystemGnssSatelliteDiagnostics *diagnostics)
{
    GnssNeoM9nSatelliteDiagnostics source;

    if (diagnostics == 
# 952 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                      ((void *)0)
# 952 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                          ) { return SYSTEM_DEVICE_INVALID_ARGUMENT; }
    if (GnssNeoM9n_GetSatelliteDiagnostics(instance, &source) == 0U)
    {
        (void)memset(diagnostics, 0, sizeof(*diagnostics));
        diagnostics->supported_fields =
            (1UL << 0) |
            (1UL << 1) |
            (1UL << 2);
        return SYSTEM_DEVICE_NOT_READY;
    }
    return NeoM9nGnssAdapter_SatelliteDiagnosticsMap(instance, &source, diagnostics);
}

static SystemDeviceResult NeoM9nGnssAdapter_ReadRfDiagnosticsDirect(uint8_t instance,
    SystemGnssRfDiagnostics *diagnostics)
{
    GnssNeoM9nRfDiagnostics source;
    int result;

    if (diagnostics == 
# 971 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                      ((void *)0)
# 971 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                          ) { return SYSTEM_DEVICE_INVALID_ARGUMENT; }
    result = GnssNeoM9n_ReadRfDiagnostics(instance, &source);
    if (result != 0)
    {
        (void)NeoM9nGnssAdapter_RfDiagnosticsMap(instance, &source, diagnostics);
        diagnostics->supported_fields =
            (1UL << 0) |
            (1UL << 1) |
            (1UL << 2) |
            (1UL << 3);
        return NeoM9nGnssAdapter_DiagnosticResultMap(result);
    }
    return NeoM9nGnssAdapter_RfDiagnosticsMap(instance, &source, diagnostics);
}

static void NeoM9nGnssAdapter_RuntimeOutputIdSet(
    NeoM9nRuntimeRequest request,
    NeoM9nRuntimeTransactionOutput *output,
    uint32_t transaction_id)
{
    if (output == 
# 991 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                 ((void *)0)
# 991 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                     ) { return; }
    if (request == NeoM9nRuntimeRequestHardwareConfig)
    {
        output->hardware_config.transaction_id = transaction_id;
    }
    else if (request == NeoM9nRuntimeRequestNavSat)
    {
        output->satellite.transaction_id = transaction_id;
    }
    else if (request == NeoM9nRuntimeRequestMonRf)
    {
        output->rf.transaction_id = transaction_id;
    }
}

static void NeoM9nGnssAdapter_RuntimeOutputErrorSet(
    NeoM9nRuntimeRequest request,
    NeoM9nRuntimeTransactionOutput *output,
    uint32_t transaction_id,
    SystemGnssTransactionDetail detail)
{
    if (output == 
# 1012 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                 ((void *)0)
# 1012 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                     ) { return; }
    SilverStarAssert_ObjectCheck((output), (uint32_t)_Alignof(NeoM9nRuntimeTransactionOutput), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)1013)
                                        ;
    (void)memset(output, 0, sizeof(*output));
    NeoM9nGnssAdapter_RuntimeOutputIdSet(request, output, transaction_id);
    if (request == NeoM9nRuntimeRequestHardwareConfig)
    {
        output->hardware_config.read_result =
            (detail == SYSTEM_GNSS_TRANSACTION_DETAIL_TIMEOUT) ?
                SYSTEM_GNSS_CONFIG_READ_TIMEOUT :
                SYSTEM_GNSS_CONFIG_READ_NOT_READY;
        output->hardware_config.detailed_result = detail;
    }
    else if (request == NeoM9nRuntimeRequestNavSat)
    {
        output->satellite.supported_fields =
            (1UL << 0) |
            (1UL << 1) |
            (1UL << 2);
        output->satellite.read_result =
            (detail == SYSTEM_GNSS_TRANSACTION_DETAIL_TIMEOUT) ?
                SYSTEM_GNSS_CONFIG_READ_TIMEOUT :
                SYSTEM_GNSS_CONFIG_READ_NOT_READY;
        output->satellite.detailed_result = detail;
    }
    else if (request == NeoM9nRuntimeRequestMonRf)
    {
        output->rf.supported_fields =
            (1UL << 0) |
            (1UL << 1) |
            (1UL << 2) |
            (1UL << 3);
        output->rf.read_result =
            (detail == SYSTEM_GNSS_TRANSACTION_DETAIL_TIMEOUT) ?
                SYSTEM_GNSS_CONFIG_READ_TIMEOUT :
                SYSTEM_GNSS_CONFIG_READ_NOT_READY;
        output->rf.detailed_result = detail;
    }
}

static SystemDeviceResult NeoM9nGnssAdapter_RuntimeRequestSubmit(uint8_t instance,
    NeoM9nRuntimeRequest request,
    NeoM9nRuntimeTransactionOutput *output,
    uint32_t start_ms,
    uint32_t timeout_ms,
    uint32_t *transaction_id)
{
    uint32_t primask;

    if ((output == 
# 1061 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                  ((void *)0)
# 1061 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                      ) || (transaction_id == 
# 1061 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                                              ((void *)0)
# 1061 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                                                  ))
    { return SYSTEM_DEVICE_INVALID_ARGUMENT; }
    SilverStarAssert_ObjectCheck((output), (uint32_t)_Alignof(NeoM9nRuntimeTransactionOutput), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)1063)
                                        ;
    SilverStarAssert_ObjectCheck((transaction_id), (uint32_t)_Alignof(uint32_t), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)1065)
                                        ;
    primask = NeoM9nGnssAdapter_IrqLock();
    if (((s_runtime_transactions[instance]).state != NeoM9nRuntimeTransactionIdle) ||
        (NeoM9nStartup_RecoveryPending(instance) != 0U))
    {
        *transaction_id = (s_runtime_transactions[instance]).transaction_id;
        NeoM9nGnssAdapter_IrqUnlock(primask);
        NeoM9nGnssAdapter_RuntimeOutputErrorSet(
            request, output, *transaction_id,
            SYSTEM_GNSS_TRANSACTION_DETAIL_BUSY);
        return SYSTEM_DEVICE_BUSY;
    }
    (s_runtime_transactions[instance]).next_transaction_id++;
    if ((s_runtime_transactions[instance]).next_transaction_id == 0U)
    {
        (s_runtime_transactions[instance]).next_transaction_id = 1U;
    }
    *transaction_id = (s_runtime_transactions[instance]).next_transaction_id;
    (s_runtime_transactions[instance]).transaction_id = *transaction_id;
    (s_runtime_transactions[instance]).request = request;
    (s_runtime_transactions[instance]).start_ms = start_ms;
    (s_runtime_transactions[instance]).timeout_ms = timeout_ms;
    (s_runtime_transactions[instance]).expected_key = 0U;
    (s_runtime_transactions[instance]).expected_class =
        (request == NeoM9nRuntimeRequestMonRf) ? 0x0AU :
        (request == NeoM9nRuntimeRequestNavSat) ? 0x01U : 0x06U;
    (s_runtime_transactions[instance]).expected_id =
        (request == NeoM9nRuntimeRequestMonRf) ? 0x38U :
        (request == NeoM9nRuntimeRequestNavSat) ? 0x35U : 0x8BU;
    (s_runtime_transactions[instance]).abandoned = 0U;
    (void)memset(&(s_runtime_transactions[instance]).output, 0,
                 sizeof((s_runtime_transactions[instance]).output));
    (void)memset(&(s_runtime_transactions[instance]).device_config, 0,
                 sizeof((s_runtime_transactions[instance]).device_config));
    (void)memset(&(s_runtime_transactions[instance]).device_config_diagnostics, 0,
                 sizeof((s_runtime_transactions[instance]).device_config_diagnostics));
    (void)memset(&(s_runtime_transactions[instance]).device_satellite, 0,
                 sizeof((s_runtime_transactions[instance]).device_satellite));
    (void)memset(&(s_runtime_transactions[instance]).device_rf, 0,
                 sizeof((s_runtime_transactions[instance]).device_rf));
    (s_runtime_transactions[instance]).state = NeoM9nRuntimeTransactionSubmitted;
    NeoM9nGnssAdapter_IrqUnlock(primask);
    return SYSTEM_DEVICE_OK;
}

static uint8_t NeoM9nGnssAdapter_RuntimeCompletionTake(uint8_t instance,
    uint32_t transaction_id,
    NeoM9nRuntimeTransactionOutput *output,
    SystemDeviceResult *result)
{
    uint32_t primask;

    if ((output == 
# 1118 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                  ((void *)0)
# 1118 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                      ) || (result == 
# 1118 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                                      ((void *)0)
# 1118 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                                          )) { return 0U; }
    SilverStarAssert_ObjectCheck((output), (uint32_t)_Alignof(NeoM9nRuntimeTransactionOutput), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)1119)
                                        ;
    SilverStarAssert_ObjectCheck((result), (uint32_t)_Alignof(SystemDeviceResult), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)1121)
                                        ;
    primask = NeoM9nGnssAdapter_IrqLock();
    if ((((s_runtime_transactions[instance]).state == NeoM9nRuntimeTransactionComplete) ||
         ((s_runtime_transactions[instance]).state == NeoM9nRuntimeTransactionFailed)) &&
        ((s_runtime_transactions[instance]).transaction_id == transaction_id))
    {
        *result = (s_runtime_transactions[instance]).result;
        *output = (s_runtime_transactions[instance]).output;
        (s_runtime_transactions[instance]).state = NeoM9nRuntimeTransactionIdle;
        NeoM9nGnssAdapter_IrqUnlock(primask);
        return 1U;
    }
    NeoM9nGnssAdapter_IrqUnlock(primask);
    return 0U;
}

static void NeoM9nGnssAdapter_RuntimeRequestAbandon(uint8_t instance, uint32_t transaction_id)
{
    uint32_t primask = NeoM9nGnssAdapter_IrqLock();

    SilverStarAssert_ObjectCheck((&(s_runtime_transactions[instance])), (uint32_t)_Alignof(NeoM9nRuntimeTransaction), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)1142)
                                                                  ;
    if (((s_runtime_transactions[instance]).transaction_id == transaction_id) &&
        ((s_runtime_transactions[instance]).state == NeoM9nRuntimeTransactionSubmitted))
    {
        (s_runtime_transactions[instance]).state = NeoM9nRuntimeTransactionIdle;
    }
    else if ((s_runtime_transactions[instance]).transaction_id == transaction_id)
    {
        (s_runtime_transactions[instance]).abandoned = 1U;
    }
    NeoM9nGnssAdapter_IrqUnlock(primask);
}

static SystemDeviceResult NeoM9nGnssAdapter_RuntimeRequestWait(uint8_t instance,
    NeoM9nRuntimeRequest request,
    NeoM9nRuntimeTransactionOutput *output)
{
    SystemDeviceResult result;
    uint32_t transaction_id;
    uint32_t start_ms;
    uint32_t timeout_ms;
    uint32_t wait_timeout_ms;
    uint32_t poll;

    if (output == 
# 1167 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                 ((void *)0)
# 1167 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                     ) { return SYSTEM_DEVICE_INVALID_ARGUMENT; }
    SilverStarAssert_ObjectCheck((output), (uint32_t)_Alignof(NeoM9nRuntimeTransactionOutput), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)1168)
                                        ;
    start_ms = PlatformTime_Ms();
    timeout_ms = (request == NeoM9nRuntimeRequestHardwareConfig) ?
        (2U * 3000U) : 3000U;
    wait_timeout_ms = timeout_ms + 150U;
    result = NeoM9nGnssAdapter_RuntimeRequestSubmit(instance,
        request, output, start_ms, timeout_ms, &transaction_id);
    if (result != SYSTEM_DEVICE_OK) { return result; }

    for (poll = 0U; poll < 8192U; poll++)
    {
        if ((PlatformTime_Ms() - start_ms) >= wait_timeout_ms)
        {
            break;
        }
        if (NeoM9nGnssAdapter_RuntimeCompletionTake(instance,
                transaction_id, output, &result) != 0U)
        {
            return result;
        }
        PlatformTime_DelayMs(1U);
    }
    if (NeoM9nGnssAdapter_RuntimeCompletionTake(instance,
            transaction_id, output, &result) != 0U)
    {
        return result;
    }
    NeoM9nGnssAdapter_RuntimeRequestAbandon(instance, transaction_id);
    NeoM9nGnssAdapter_RuntimeOutputErrorSet(
        request, output, transaction_id,
        SYSTEM_GNSS_TRANSACTION_DETAIL_TIMEOUT);
    return SYSTEM_DEVICE_TIMEOUT;
}

static void NeoM9nGnssAdapter_RuntimeTransactionCancel(uint8_t instance,
    NeoM9nRuntimeRequest request,
    SystemGnssTransactionDetail detail)
{
    GnssNeoM9nConfigReadResult result =
        (detail == SYSTEM_GNSS_TRANSACTION_DETAIL_TIMEOUT) ?
            GnssNeoM9nConfigReadTimeout :
            GnssNeoM9nConfigReadIoError;
    GnssNeoM9nTransactionDetail device_detail =
        (detail == SYSTEM_GNSS_TRANSACTION_DETAIL_TIMEOUT) ?
            GnssNeoM9nTransactionDetailTimeout :
            GnssNeoM9nTransactionDetailRxDiscontinuity;

    SilverStarAssert_ObjectCheck((&(s_runtime_transactions[instance])), (uint32_t)_Alignof(NeoM9nRuntimeTransaction), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)1216)
                                                                  ;
    if (request == NeoM9nRuntimeRequestHardwareConfig)
    {
        GnssNeoM9n_ConfigReadAsyncCancel(instance, result, device_detail);
    }
    else if (request == NeoM9nRuntimeRequestNavSat)
    {
        GnssNeoM9n_SatelliteDiagnosticsAsyncCancel(instance, result, device_detail);
    }
    else if (request == NeoM9nRuntimeRequestMonRf)
    {
        GnssNeoM9n_RfDiagnosticsAsyncCancel(instance, result, device_detail);
    }
}

static SystemDeviceResult NeoM9nGnssAdapter_RuntimeStartResultMap(
    GnssNeoM9nAsyncStartResult result)
{
    if ((result == GnssNeoM9nAsyncStartOk) ||
        (result == GnssNeoM9nAsyncStartTxError))
    {
        return SYSTEM_DEVICE_OK;
    }
    if (result == GnssNeoM9nAsyncStartBusy) { return SYSTEM_DEVICE_BUSY; }
    if (result == GnssNeoM9nAsyncStartNotReady)
    {
        return SYSTEM_DEVICE_NOT_READY;
    }
    return SYSTEM_DEVICE_INVALID_ARGUMENT;
}

static uint8_t NeoM9nGnssAdapter_RuntimeSnapshotGet(uint8_t instance,
    NeoM9nRuntimeTransactionSnapshot *snapshot)
{
    uint32_t primask;

    if (snapshot == 
# 1253 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                   ((void *)0)
# 1253 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                       ) { return 0U; }
    SilverStarAssert_ObjectCheck((snapshot), (uint32_t)_Alignof(NeoM9nRuntimeTransactionSnapshot), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)1254)
                                        ;
    primask = NeoM9nGnssAdapter_IrqLock();
    snapshot->state = (s_runtime_transactions[instance]).state;
    snapshot->request = (s_runtime_transactions[instance]).request;
    snapshot->transaction_id = (s_runtime_transactions[instance]).transaction_id;
    snapshot->start_ms = (s_runtime_transactions[instance]).start_ms;
    snapshot->timeout_ms = (s_runtime_transactions[instance]).timeout_ms;
    snapshot->abandoned = (s_runtime_transactions[instance]).abandoned;
    NeoM9nGnssAdapter_IrqUnlock(primask);
    return (uint8_t)((snapshot->state != NeoM9nRuntimeTransactionIdle) &&
        (snapshot->state != NeoM9nRuntimeTransactionComplete) &&
        (snapshot->state != NeoM9nRuntimeTransactionFailed));
}

static uint8_t NeoM9nGnssAdapter_RuntimeAbandonedProcess(uint8_t instance,
    const NeoM9nRuntimeTransactionSnapshot *snapshot)
{
    uint32_t primask;

    if ((snapshot == 
# 1274 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                    ((void *)0)
# 1274 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                        ) || (snapshot->abandoned == 0U)) { return 0U; }
    SilverStarAssert_ObjectCheck((snapshot), (uint32_t)_Alignof(NeoM9nRuntimeTransactionSnapshot), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)1275)
                                        ;
    NeoM9nGnssAdapter_RuntimeTransactionCancel(instance,
        snapshot->request, SYSTEM_GNSS_TRANSACTION_DETAIL_TIMEOUT);
    primask = NeoM9nGnssAdapter_IrqLock();
    if ((s_runtime_transactions[instance]).transaction_id == snapshot->transaction_id)
    {
        (s_runtime_transactions[instance]).state = NeoM9nRuntimeTransactionIdle;
    }
    NeoM9nGnssAdapter_IrqUnlock(primask);
    return 1U;
}

static uint8_t NeoM9nGnssAdapter_RuntimeTimeoutProcess(uint8_t instance,
    const NeoM9nRuntimeTransactionSnapshot *snapshot)
{
    NeoM9nRuntimeTransactionOutput output;
    uint32_t primask;

    if (snapshot == 
# 1294 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                   ((void *)0)
# 1294 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                       ) { return 0U; }
    SilverStarAssert_ObjectCheck((snapshot), (uint32_t)_Alignof(NeoM9nRuntimeTransactionSnapshot), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)1295)
                                        ;
    if ((PlatformTime_Ms() - snapshot->start_ms) < snapshot->timeout_ms)
    { return 0U; }
    NeoM9nGnssAdapter_RuntimeTransactionCancel(instance,
        snapshot->request, SYSTEM_GNSS_TRANSACTION_DETAIL_TIMEOUT);
    (void)memset(&output, 0, sizeof(output));
    NeoM9nGnssAdapter_RuntimeOutputErrorSet(
        snapshot->request, &output, snapshot->transaction_id,
        SYSTEM_GNSS_TRANSACTION_DETAIL_TIMEOUT);
    primask = NeoM9nGnssAdapter_IrqLock();
    if ((s_runtime_transactions[instance]).transaction_id == snapshot->transaction_id)
    {
        (s_runtime_transactions[instance]).output = output;
        (s_runtime_transactions[instance]).result = SYSTEM_DEVICE_TIMEOUT;
        (s_runtime_transactions[instance]).state = NeoM9nRuntimeTransactionFailed;
    }
    NeoM9nGnssAdapter_IrqUnlock(primask);
    return 1U;
}

static uint8_t NeoM9nGnssAdapter_RuntimeSubmittedProcess(uint8_t instance,
    const NeoM9nRuntimeTransactionSnapshot *snapshot)
{
    uint32_t primask;

    if ((snapshot == 
# 1321 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                    ((void *)0)
# 1321 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                        ) ||
        (snapshot->state != NeoM9nRuntimeTransactionSubmitted))
    { return 0U; }
    SilverStarAssert_ObjectCheck((snapshot), (uint32_t)_Alignof(NeoM9nRuntimeTransactionSnapshot), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)1324)
                                        ;
    primask = NeoM9nGnssAdapter_IrqLock();
    if (((s_runtime_transactions[instance]).transaction_id == snapshot->transaction_id) &&
        ((s_runtime_transactions[instance]).state == NeoM9nRuntimeTransactionSubmitted))
    {
        (s_runtime_transactions[instance]).state = NeoM9nRuntimeTransactionSendRequest;
    }
    NeoM9nGnssAdapter_IrqUnlock(primask);
    return 1U;
}

static GnssNeoM9nAsyncStartResult NeoM9nGnssAdapter_RuntimeRequestStart(uint8_t instance,
    NeoM9nRuntimeRequest request)
{
    if (request == NeoM9nRuntimeRequestHardwareConfig)
    { return GnssNeoM9n_ConfigReadAsyncStart(instance); }
    if (request == NeoM9nRuntimeRequestNavSat)
    { return GnssNeoM9n_SatelliteDiagnosticsAsyncStart(instance); }
    if (request == NeoM9nRuntimeRequestMonRf)
    { return GnssNeoM9n_RfDiagnosticsAsyncStart(instance); }
    return GnssNeoM9nAsyncStartInvalidArgument;
}

static uint8_t NeoM9nGnssAdapter_RuntimeSendProcess(uint8_t instance,
    const NeoM9nRuntimeTransactionSnapshot *snapshot)
{
    SystemDeviceResult result;
    uint32_t primask;

    if ((snapshot == 
# 1354 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                    ((void *)0)
# 1354 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                        ) ||
        (snapshot->state != NeoM9nRuntimeTransactionSendRequest))
    { return 0U; }
    SilverStarAssert_ObjectCheck((snapshot), (uint32_t)_Alignof(NeoM9nRuntimeTransactionSnapshot), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)1357)
                                        ;
    result = NeoM9nGnssAdapter_RuntimeStartResultMap(
        NeoM9nGnssAdapter_RuntimeRequestStart(instance, snapshot->request));
    primask = NeoM9nGnssAdapter_IrqLock();
    if ((s_runtime_transactions[instance]).transaction_id == snapshot->transaction_id)
    {
        if (result == SYSTEM_DEVICE_OK)
        {
            (s_runtime_transactions[instance]).state = NeoM9nRuntimeTransactionWaitResponse;
        }
        else
        {
            NeoM9nGnssAdapter_RuntimeOutputErrorSet(
                snapshot->request, &(s_runtime_transactions[instance]).output,
                snapshot->transaction_id,
                (result == SYSTEM_DEVICE_BUSY) ?
                    SYSTEM_GNSS_TRANSACTION_DETAIL_BUSY :
                    SYSTEM_GNSS_TRANSACTION_DETAIL_NOT_READY);
            (s_runtime_transactions[instance]).result = result;
            (s_runtime_transactions[instance]).state = NeoM9nRuntimeTransactionFailed;
        }
    }
    NeoM9nGnssAdapter_IrqUnlock(primask);
    return 1U;
}

static GnssNeoM9nAsyncPollResult NeoM9nGnssAdapter_RuntimeResponsePoll(uint8_t instance,
    NeoM9nRuntimeRequest request,
    NeoM9nRuntimeTransactionOutput *output,
    SystemDeviceResult *result)
{
    GnssNeoM9nAsyncPollResult poll_result;

    if ((output == 
# 1391 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                  ((void *)0)
# 1391 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                      ) || (result == 
# 1391 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                                      ((void *)0)
# 1391 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                                          ))
    { return GnssNeoM9nAsyncPollPending; }
    SilverStarAssert_ObjectCheck((output), (uint32_t)_Alignof(NeoM9nRuntimeTransactionOutput), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)1393)
                                        ;
    SilverStarAssert_ObjectCheck((result), (uint32_t)_Alignof(SystemDeviceResult), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)1395)
                                        ;
    if (request == NeoM9nRuntimeRequestHardwareConfig)
    {
        poll_result = GnssNeoM9n_ConfigReadAsyncPoll(instance,
            &(s_runtime_transactions[instance]).device_config,
            &(s_runtime_transactions[instance]).device_config_elapsed_ms,
            &(s_runtime_transactions[instance]).device_config_diagnostics,
            &(s_runtime_transactions[instance]).device_config_result);
        if (poll_result == GnssNeoM9nAsyncPollComplete)
        {
            *result = NeoM9nGnssAdapter_HardwareConfigMap(instance,
                &(s_runtime_transactions[instance]).device_config,
                (s_runtime_transactions[instance]).device_config_elapsed_ms,
                &(s_runtime_transactions[instance]).device_config_diagnostics,
                (s_runtime_transactions[instance]).device_config_result,
                &output->hardware_config);
        }
    }
    else if (request == NeoM9nRuntimeRequestNavSat)
    {
        poll_result = GnssNeoM9n_SatelliteDiagnosticsAsyncPoll(instance,
            &(s_runtime_transactions[instance]).device_satellite);
        if (poll_result == GnssNeoM9nAsyncPollComplete)
        {
            (void)NeoM9nGnssAdapter_SatelliteDiagnosticsMap(instance,
                &(s_runtime_transactions[instance]).device_satellite, &output->satellite);
            *result = NeoM9nGnssAdapter_ConfigReadDeviceResultMap(
                (s_runtime_transactions[instance]).device_satellite.read_result);
        }
    }
    else
    {
        poll_result = GnssNeoM9n_RfDiagnosticsAsyncPoll(instance,
            &(s_runtime_transactions[instance]).device_rf);
        if (poll_result == GnssNeoM9nAsyncPollComplete)
        {
            (void)NeoM9nGnssAdapter_RfDiagnosticsMap(instance,
                &(s_runtime_transactions[instance]).device_rf, &output->rf);
            *result = NeoM9nGnssAdapter_ConfigReadDeviceResultMap(
                (s_runtime_transactions[instance]).device_rf.read_result);
        }
    }
    return poll_result;
}

static uint8_t NeoM9nGnssAdapter_RuntimeWaitResponseProcess(uint8_t instance,
    const NeoM9nRuntimeTransactionSnapshot *snapshot)
{
    NeoM9nRuntimeTransactionOutput output;
    SystemDeviceResult result = SYSTEM_DEVICE_INVALID_ARGUMENT;
    GnssNeoM9nAsyncPollResult poll_result;
    uint32_t primask;

    if ((snapshot == 
# 1449 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                    ((void *)0)
# 1449 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                        ) ||
        (snapshot->state != NeoM9nRuntimeTransactionWaitResponse))
    { return 0U; }
    SilverStarAssert_ObjectCheck((snapshot), (uint32_t)_Alignof(NeoM9nRuntimeTransactionSnapshot), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)1452)
                                        ;
    (void)memset(&output, 0, sizeof(output));
    poll_result = NeoM9nGnssAdapter_RuntimeResponsePoll(instance,
        snapshot->request, &output, &result);
    if (poll_result == GnssNeoM9nAsyncPollPending) { return 1U; }
    NeoM9nGnssAdapter_RuntimeOutputIdSet(
        snapshot->request, &output, snapshot->transaction_id);
    primask = NeoM9nGnssAdapter_IrqLock();
    if ((s_runtime_transactions[instance]).transaction_id == snapshot->transaction_id)
    {
        (s_runtime_transactions[instance]).output = output;
        (s_runtime_transactions[instance]).result = result;
        (s_runtime_transactions[instance]).state =
            NeoM9nRuntimeTransactionProcessResponse;
    }
    NeoM9nGnssAdapter_IrqUnlock(primask);
    return 1U;
}

static void NeoM9nGnssAdapter_RuntimeResponseFinalize(uint8_t instance,
    const NeoM9nRuntimeTransactionSnapshot *snapshot)
{
    uint32_t primask;

    if ((snapshot == 
# 1477 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                    ((void *)0)
# 1477 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                        ) ||
        (snapshot->state != NeoM9nRuntimeTransactionProcessResponse))
    { return; }
    SilverStarAssert_ObjectCheck((snapshot), (uint32_t)_Alignof(NeoM9nRuntimeTransactionSnapshot), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)1480)
                                        ;
    primask = NeoM9nGnssAdapter_IrqLock();
    if (((s_runtime_transactions[instance]).state ==
         NeoM9nRuntimeTransactionProcessResponse) &&
        ((s_runtime_transactions[instance]).transaction_id == snapshot->transaction_id))
    {
        (s_runtime_transactions[instance]).state =
            ((s_runtime_transactions[instance]).result == SYSTEM_DEVICE_OK) ?
                NeoM9nRuntimeTransactionComplete :
                NeoM9nRuntimeTransactionFailed;
    }
    NeoM9nGnssAdapter_IrqUnlock(primask);
}

static void NeoM9nGnssAdapter_RuntimeTransactionProcess(uint8_t instance)
{
    NeoM9nRuntimeTransactionSnapshot snapshot;

    SilverStarAssert_ObjectCheck((&(s_runtime_transactions[instance])), (uint32_t)_Alignof(NeoM9nRuntimeTransaction), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)1499)
                                                                  ;
    if (NeoM9nGnssAdapter_RuntimeSnapshotGet(instance, &snapshot) == 0U) { return; }
    if (NeoM9nGnssAdapter_RuntimeAbandonedProcess(instance, &snapshot) != 0U)
    { return; }
    if (NeoM9nGnssAdapter_RuntimeTimeoutProcess(instance, &snapshot) != 0U)
    { return; }
    if (NeoM9nGnssAdapter_RuntimeSubmittedProcess(instance, &snapshot) != 0U)
    { return; }
    if (NeoM9nGnssAdapter_RuntimeSendProcess(instance, &snapshot) != 0U)
    { return; }
    if (NeoM9nGnssAdapter_RuntimeWaitResponseProcess(instance, &snapshot) != 0U)
    { return; }
    NeoM9nGnssAdapter_RuntimeResponseFinalize(instance, &snapshot);
}

static SystemDeviceResult NeoM9nGnssAdapter_ReadHardwareConfig(uint8_t instance,
    SystemGnssHardwareConfig *config)
{
    NeoM9nRuntimeTransactionOutput output;
    SystemDeviceResult result;

    if (config == 
# 1521 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                 ((void *)0)
# 1521 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                     ) { return SYSTEM_DEVICE_INVALID_ARGUMENT; }
    if ((s_runtime_owner_active_contexts[instance]) == 0U)
    {
        return NeoM9nGnssAdapter_ReadHardwareConfigDirect(instance, config);
    }
    result = NeoM9nGnssAdapter_RuntimeRequestWait(instance,
        NeoM9nRuntimeRequestHardwareConfig, &output);
    *config = output.hardware_config;
    return result;
}

static SystemDeviceResult NeoM9nGnssAdapter_ReadSatelliteDiagnostics(uint8_t instance,
    SystemGnssSatelliteDiagnostics *diagnostics)
{
    NeoM9nRuntimeTransactionOutput output;
    SystemDeviceResult result;

    if (diagnostics == 
# 1538 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                      ((void *)0)
# 1538 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                          ) { return SYSTEM_DEVICE_INVALID_ARGUMENT; }
    if ((s_runtime_owner_active_contexts[instance]) == 0U)
    {
        return NeoM9nGnssAdapter_ReadSatelliteDiagnosticsDirect(instance, diagnostics);
    }
    result = NeoM9nGnssAdapter_RuntimeRequestWait(instance,
        NeoM9nRuntimeRequestNavSat, &output);
    *diagnostics = output.satellite;
    return result;
}

static SystemDeviceResult NeoM9nGnssAdapter_ReadRfDiagnostics(uint8_t instance,
    SystemGnssRfDiagnostics *diagnostics)
{
    NeoM9nRuntimeTransactionOutput output;
    SystemDeviceResult result;

    if (diagnostics == 
# 1555 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                      ((void *)0)
# 1555 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                          ) { return SYSTEM_DEVICE_INVALID_ARGUMENT; }
    if ((s_runtime_owner_active_contexts[instance]) == 0U)
    {
        return NeoM9nGnssAdapter_ReadRfDiagnosticsDirect(instance, diagnostics);
    }
    result = NeoM9nGnssAdapter_RuntimeRequestWait(instance,
        NeoM9nRuntimeRequestMonRf, &output);
    *diagnostics = output.rf;
    return result;
}

static SystemDeviceResult NeoM9nGnssAdapter_GetRfDiagnostics(uint8_t instance,
    SystemGnssRfDiagnostics *diagnostics)
{
    GnssNeoM9nRfDiagnostics source;

    if (diagnostics == 
# 1571 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                      ((void *)0)
# 1571 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                          ) { return SYSTEM_DEVICE_INVALID_ARGUMENT; }
    if (GnssNeoM9n_GetRfDiagnostics(instance, &source) == 0U)
    {
        (void)memset(diagnostics, 0, sizeof(*diagnostics));
        diagnostics->supported_fields =
            (1UL << 0) |
            (1UL << 1) |
            (1UL << 2) |
            (1UL << 3);
        return SYSTEM_DEVICE_NOT_READY;
    }
    return NeoM9nGnssAdapter_RfDiagnosticsMap(instance, &source, diagnostics);
}


static SystemDeviceResult NeoM9nGnssAdapter_VerifyConfig(uint8_t instance,
    const SystemGnssConfig *config,
    SystemDeviceConfigReport *report)
{
    SystemDeviceResult validation =
        NeoM9nGnssAdapter_ConfigCheck(config, report);
    SystemDeviceStartupState state;

    if ((validation != SYSTEM_DEVICE_OK) &&
        (validation != SYSTEM_DEVICE_UNSUPPORTED))
    { return validation; }
    if (instance >= 1U)
    { return SYSTEM_DEVICE_INVALID_ARGUMENT; }
    SilverStarAssert_ObjectCheck((config), (uint32_t)_Alignof(SystemGnssConfig), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)1599)
                                        ;
    SilverStarAssert_ObjectCheck((report), (uint32_t)_Alignof(SystemDeviceConfigReport), (SILVERSTAR_ASSERT_MODULE_DEVICE), "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c", (uint32_t)1601)
                                        ;
    state = NeoM9nStartup_StateGet(instance);
    if (state == SystemDeviceStartupState_Failed)
    {
        report->failed_mask = config->requested_mask;
        report->verify_failed_mask = config->requested_mask;
        report->detail_code = (uint32_t)NeoM9nStartup_FailureGet(instance);
        report->success = 0U;
        return SYSTEM_DEVICE_TIMEOUT;
    }
    if (state != SystemDeviceStartupState_Ready)
    { return SYSTEM_DEVICE_BUSY; }
    report->applied_mask = report->matched_mask;
    report->success = 1U;
    return validation;
}

const char *NeoM9nGnssInstance_NameGet(uint8_t instance)
{
    (void)instance;
    return "NEO-M9N GNSS";
}
SystemDeviceResult NeoM9nGnssInstance_Init(uint8_t instance) { return NeoM9nGnssAdapter_Init(instance); }
SystemDeviceResult NeoM9nGnssInstance_Start(uint8_t instance) { return NeoM9nGnssAdapter_Start(instance); }
SystemDeviceResult NeoM9nGnssInstance_Stop(uint8_t instance) { return NeoM9nGnssAdapter_Stop(instance); }
SystemDeviceResult NeoM9nGnssInstance_RuntimeOwnerActivate(uint8_t instance)
{ return NeoM9nGnssAdapter_RuntimeOwnerActivate(instance); }
SystemDeviceResult NeoM9nGnssInstance_Process(uint8_t instance)
{
    NeoM9nGnssAdapter_Process(instance);
    return SYSTEM_DEVICE_OK;
}
SystemDeviceResult NeoM9nGnssInstance_InfoGet(
    uint8_t instance, SystemDeviceInfo *info)
{
    (void)instance;
    return NeoM9nGnssAdapter_GetInfo(info);
}
SystemDeviceResult NeoM9nGnssInstance_CapabilitiesGet(
    uint8_t instance, uint32_t *mask)
{
    (void)instance;
    return NeoM9nGnssAdapter_GetCapabilities(mask);
}
SystemDeviceResult NeoM9nGnssInstance_HealthGet(uint8_t instance, SystemDeviceHealth *health)
{ return NeoM9nGnssAdapter_GetHealth(instance, health); }
SystemDeviceResult NeoM9nGnssInstance_RecoveryBusyGet(uint8_t instance, uint8_t *busy)
{
    if ((instance >= 1U) || (busy == 
# 1650 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c" 3 4
                                                                ((void *)0)
# 1650 "Devices/GNSS/NEO_M9N/Adapter/Src/neo_m9n_system_adapter.c"
                                                                    ))
    { return SYSTEM_DEVICE_INVALID_ARGUMENT; }
    *busy = (uint8_t)((s_contexts[instance].startup_active != 0U) ||
        (NeoM9nStartup_RecoveryPending(instance) != 0U));
    return SYSTEM_DEVICE_OK;
}
SystemDeviceResult NeoM9nGnssInstance_IoDiagnosticsGet(uint8_t instance,
    SystemDeviceIoDiagnostics *diagnostics)
{ return NeoM9nGnssAdapter_GetIoDiagnostics(instance, diagnostics); }
SystemDeviceResult NeoM9nGnssInstance_IoDetailGet(uint8_t instance, SystemGnssIoDetail *detail)
{ return NeoM9nGnssAdapter_GetIoDetail(instance, detail); }
SystemDeviceResult NeoM9nGnssInstance_LatestSampleGet(uint8_t instance, SystemGnssSample *sample)
{ return NeoM9nGnssAdapter_GetSample(instance, sample); }
SystemDeviceResult NeoM9nGnssInstance_TimeGet(uint8_t instance, SystemGnssTime *time)
{ return NeoM9nGnssAdapter_GetTime(instance, time); }
SystemDeviceResult NeoM9nGnssInstance_SelfTestRun(
    uint8_t instance, SystemDeviceSelfTestResult *result)
{
    (void)instance;
    return NeoM9nGnssAdapter_SelfTest(result);
}
SystemDeviceResult NeoM9nGnssInstance_ConfigApply(uint8_t instance,
    const SystemGnssConfig *config, SystemDeviceConfigReport *report)
{ return NeoM9nGnssAdapter_ApplyConfig(instance, config, report); }
SystemDeviceResult NeoM9nGnssInstance_ConfigVerify(uint8_t instance,
    const SystemGnssConfig *config, SystemDeviceConfigReport *report)
{ return NeoM9nGnssAdapter_VerifyConfig(instance, config, report); }
SystemDeviceResult NeoM9nGnssInstance_EffectiveConfigGet(uint8_t instance, SystemGnssConfig *config)
{ return NeoM9nGnssAdapter_GetConfig(instance, config); }
SystemDeviceResult NeoM9nGnssInstance_NoiseCharacteristicsGet(
    uint8_t instance, SystemGnssNoiseCharacteristics *noise)
{
    (void)instance;
    return NeoM9nGnssAdapter_NoiseCharacteristicsGet(noise);
}
SystemDeviceResult NeoM9nGnssInstance_HardwareConfigRead(uint8_t instance,
    SystemGnssHardwareConfig *config)
{ return NeoM9nGnssAdapter_ReadHardwareConfig(instance, config); }
SystemDeviceResult NeoM9nGnssInstance_LastConfigReportGet(uint8_t instance,
    SystemGnssConfigTransactionReport *report)
{ return NeoM9nGnssAdapter_GetLastConfigReport(instance, report); }
SystemDeviceResult NeoM9nGnssInstance_SatelliteDiagnosticsRead(uint8_t instance,
    SystemGnssSatelliteDiagnostics *diagnostics)
{ return NeoM9nGnssAdapter_ReadSatelliteDiagnostics(instance, diagnostics); }
SystemDeviceResult NeoM9nGnssInstance_LatestSatelliteDiagnosticsGet(uint8_t instance,
    SystemGnssSatelliteDiagnostics *diagnostics)
{ return NeoM9nGnssAdapter_GetSatelliteDiagnostics(instance, diagnostics); }
SystemDeviceResult NeoM9nGnssInstance_RfDiagnosticsRead(uint8_t instance,
    SystemGnssRfDiagnostics *diagnostics)
{ return NeoM9nGnssAdapter_ReadRfDiagnostics(instance, diagnostics); }
SystemDeviceResult NeoM9nGnssInstance_LatestRfDiagnosticsGet(uint8_t instance,
    SystemGnssRfDiagnostics *diagnostics)
{ return NeoM9nGnssAdapter_GetRfDiagnostics(instance, diagnostics); }
