# Read-only validation; ordinary firmware builds do not require Python.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$profile = Get-Content -Raw -Encoding UTF8 -LiteralPath (Join-Path $PSScriptRoot 'maintenance_uart.json') | ConvertFrom-Json
$sources = @(Get-ChildItem -LiteralPath $root -Filter usart.c -Recurse -File | Where-Object {
    $_.FullName.Substring($root.Length) -notmatch '[/\\](build|\.work|Tests)[/\\]'
})
if ($sources.Count -ne 1) { throw 'Maintenance UART check requires one explicit CubeMX usart.c' }
$text = Get-Content -Raw -Encoding UTF8 -LiteralPath $sources[0].FullName
$text = [regex]::Replace($text, '(?s)/\*.*?\*/|//[^\n]*', '')
$handle = '\b' + [regex]::Escape($profile.handle)
$fields = @{ BaudRate = [string]$profile.baudrate; WordLength = 'UART_WORDLENGTH_8B'
    Parity = 'UART_PARITY_NONE'; StopBits = 'UART_STOPBITS_1'
    HwFlowCtl = 'UART_HWCONTROL_NONE'; Mode = 'UART_MODE_TX_RX' }
foreach ($name in $fields.Keys) {
    $found = [regex]::Matches($text, $handle + '\.Init\.' + $name + '\s*=\s*([^;]+);')
    if ($found.Count -ne 1 -or $found[0].Groups[1].Value.Trim().TrimEnd('u', 'U') -cne $fields[$name]) {
        throw ('Maintenance UART mismatch in actual CubeMX source: ' + $name)
    }
}
$iocs = @(Get-ChildItem -LiteralPath $root -Filter '*.ioc' -File)
if ($iocs.Count -ne 1) { throw 'Maintenance UART check requires one explicit project IOC' }
$lines = Get-Content -Encoding UTF8 -LiteralPath $iocs[0].FullName
$prefix = $profile.peripheral + '.BaudRate='
$values = @($lines | Where-Object { $_.StartsWith($prefix) } | ForEach-Object { $_.Substring($prefix.Length).Trim() })
if ($values.Count -ne 1 -or $values[0] -cne [string]$profile.baudrate) {
    throw 'Maintenance UART mismatch in CubeMX IOC baud'
}
$instances = [regex]::Matches($text, $handle + '\.Instance\s*=\s*([^;]+);')
if ($instances.Count -ne 1 -or $instances[0].Groups[1].Value.Trim() -cne $profile.peripheral) {
    throw 'Maintenance UART mismatch in actual CubeMX Instance'
}
# F1 uses 16x; F4 may explicitly select 8x. Unknown expressions fail closed.
$sampling = [regex]::Matches($text, $handle + '\.Init\.OverSampling\s*=\s*([^;]+);')
$mode = 'UART_OVERSAMPLING_16'
if ($sampling.Count -eq 1) { $mode = $sampling[0].Groups[1].Value.Trim() }
if ($sampling.Count -gt 1 -or $mode -cnotin @('UART_OVERSAMPLING_8', 'UART_OVERSAMPLING_16')) {
    throw 'Maintenance UART oversampling is not explicit'
}
$minimum = 16; $maximum = 65535
if ($mode -ceq 'UART_OVERSAMPLING_8') { $minimum = 8; $maximum = 32767 }
$clockKey = 'RCC.APB1Freq_Value='
if ($profile.peripheral -cin @('USART1', 'USART6')) { $clockKey = 'RCC.APB2Freq_Value=' }
$clocks = @($lines | Where-Object { $_.StartsWith($clockKey) } | ForEach-Object { $_.Substring($clockKey.Length).Trim() })
if ($clocks.Count -ne 1 -or $clocks[0] -notmatch '^\d+$') {
    throw 'Maintenance UART requires the imported CubeMX peripheral clock'
}
[long]$clock = $clocks[0]; [long]$baud = $profile.baudrate
if ($baud -lt 1200 -or $baud -gt 2000000) { throw 'Maintenance UART baud outside software deadline bounds' }
[long]$divisor = [math]::Floor(($clock + [math]::Floor($baud / 2)) / $baud)
if ($divisor -lt $minimum -or $divisor -gt $maximum -or
    [math]::Abs($clock - $baud * $divisor) * 100 -gt $baud * $divisor * 2) {
    throw 'Maintenance UART baud is not representable within 2 percent at the imported clock'
}
Write-Output ('Maintenance UART source/IOC matched ' + $baud + '/8N1; no source overwritten')
