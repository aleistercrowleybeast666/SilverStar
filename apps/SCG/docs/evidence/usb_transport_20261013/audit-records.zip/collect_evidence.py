"""Collect only this task's small audit records; never delete or copy SDK trees."""
from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import sys
import zipfile

repo = Path(__file__).resolve().parents[2]
work = repo / '.work/usb013'
dest = repo / 'apps/SCG/docs/evidence/usb_transport_20261013'
dest.mkdir(parents=True, exist_ok=False)
sys.path.insert(0, str(repo / 'apps/SCG/src'))
from silverstar_fccg.generator.usb_cdc_transport import UsbCdcTransport_Render
from silverstar_fccg.hardware import native_machine_contract
sys.modules['native_machine_contract'] = native_machine_contract

def sha(data):
    return hashlib.sha256(data).hexdigest()

entries = {}
archive_index = {}
def add(path, name):
    data = path.read_bytes()
    entries[name] = data
    archive_index[name] = {'original_path': str(path), 'size': len(data), 'sha256': sha(data)}

for run in ('final01', 'final02', 'final03', 'export04'):
    for path in sorted((work / run).iterdir()):
        if path.is_file() and path.suffix in ('.json', '.jsonl', '.log'):
            add(path, run + '/' + path.name)
for path in sorted(work.glob('*.log')):
    add(path, 'history/' + path.name)
for path in sorted((work / 'baseline01').iterdir()):
    if path.is_file() and path.suffix != '.exe':
        add(path, 'baseline01/' + path.name)
add(Path(__file__), 'collect_evidence.py')

final = json.loads((work / 'final03/source-snapshot.json').read_text(encoding='utf8'))
host = json.loads((work / 'export04/source-snapshot.json').read_text(encoding='utf8'))
bindings = {}
for name, record in host['source_files'].items():
    current = (repo / name).read_bytes()
    assert sha(current) == record['sha256'], name
    bindings[name] = {'current_sha256': sha(current), 'export04_match': True,
                     'final03_match': final['source_files'][name]['sha256'] == sha(current)}
generator = next(name for name in bindings if name.endswith('generator\\usb_cdc_transport.py'))
assert bindings[generator]['final03_match']

native = []
for line in (work / 'final03/native-index.jsonl').read_text().splitlines():
    row = json.loads(line)
    part, root = row['part'], Path(row['output'])
    receipt = json.loads((root / 'receipt.json').read_text(encoding='utf8'))
    inventory = json.loads((work / ('final03/' + part + '-inventory.json')).read_text())
    assert all(sha((root / path).read_bytes()) == digest for path, digest in inventory.items())
    scope = json.loads((root / 'Generated/usb_transport_abi_graph.json').read_text())['scope']
    generated = {}
    for relative, data in UsbCdcTransport_Render(indexed=part == 'STM32F407VET6').items():
        file = root / 'Generated/UsbTransport' / relative
        assert file.read_bytes() == data, file
        generated[relative] = sha(data)
        add(file, 'native/' + part + '/Generated/UsbTransport/' + relative)
    for relative in ('receipt.json', 'source-snapshot.json', 'commands.log', 'backend-receipt.json',
                     'candidate_config.ssproject', 'Makefile', 'Generated/usb_transport_abi_graph.json',
                     'Generated/ground_source_graph.json', 'Generated/native_ground_contract.json',
                     'build/native-artifact-report.json', 'Tools/check_power_of_ten.ps1',
                     'Tools/check_native_ground.py', 'Tools/native_machine_contract.py'):
        add(root / relative, 'native/' + part + '/' + relative)
    licenses = {name: digest for name, digest in inventory.items()
                if any(word in name.lower() for word in ('license', 'copying', 'release_notes'))}
    for name in licenses:
        add(root / name, 'native/' + part + '/' + name)
    spec = importlib.util.spec_from_file_location('usb_evidence_native_gate', root / 'Tools/check_native_ground.py')
    gate = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(gate)
    builds = []
    for build in ('build', 'build/analysis'):
        map_path = root / build / 'usb-transport-abi.map'
        libraries = gate.NativeLinkedLibraries_Inspect(map_path.read_text(), receipt['facts']['regions'])
        frames = {}
        for path in sorted((root / build / 'Generated/UsbTransport').rglob('*.su')):
            frames[path.relative_to(root).as_posix()] = path.read_text()
            add(path, 'native/' + part + '/' + path.relative_to(root).as_posix())
        artifacts = {name: sha((root / build / name).read_bytes())
                     for name in ('usb-transport-abi.elf', 'usb-transport-abi.map', 'usb-transport-abi-vectors.bin')}
        builds.append({'build': build, 'artifact_sha256': artifacts, 'retained_libraries': libraries,
                       'transport_function_frames': frames, 'whole_program_stack': 'NOT_PROVEN'})
    native.append({'part': part, 'root': str(root), 'scope': scope, 'source_commit': receipt['source_commit'],
                   'original_command_count': len(receipt['commands']), 'warnings': receipt['warning_diagnostics'],
                   'generated_current_match_sha256': generated, 'license_and_release_files': licenses,
                   'input_sha256': receipt['input_sha256'], 'all_retained_files_rehashed': len(inventory),
                   'builds': builds, 'limits': receipt['limits']})

archive = dest / 'audit-records.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name, data in sorted(entries.items()):
        output.writestr(name, data)
index = {
    'schema': 'silverstar-usb-transport-audit-v1',
    'recorded_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
    'frozen_v0_1_2_tag_object': subprocess.check_output(['git', 'rev-parse', 'v0.1.2'], cwd=repo, text=True).strip(),
    'scope': 'Experimental additive kit; ABI_ONLY_NOT_HOOKED_TO_NATIVE_CALLBACKS; no hardware actions',
    'source_bindings': bindings, 'native': native,
    'runs': {
        'baseline01': 'Frozen c31c13c feature-gap reproduction: compile 0; requested capacity512 gives actual511/drop1; expected run exit1. Not a regression against old drop-policy contract.',
        'version01': 'Failed: pre-existing stale independent plugin version assertions; manifests unchanged by USB writer.',
        'version02': '1 passed; one existing cache_dir config warning.',
        'tests01': '13 passed, 2 failed: DMA/cache heuristic matched CMSIS declarations.',
        'tests02': '13 passed, 2 failed: redirected Documents ancestor rejected.',
        'tests03': '15 passed; one existing cache_dir config warning.',
        'final01': '17 host passed; 2 native failed during evidence snapshot: default GBK decoding of git diff. Fixed by explicit PYTHONUTF8=1/PYTHONIOENCODING=utf8; no ignored bytes.',
        'final02': '17 host and 2 native passed, strict compile/analyzer/link, emitted project gates passed. Historical earlier revision.',
        'final03': '20 host and 2 native passed (26 deselected); all recorded compile/analyzer/link and gates exit0. Includes real Cube/HAL/stack inputs, both adapter ABIs, no callback integration. Critical review NOT_PROVEN.',
        'export04': '21 host passed; no target build requested. Python publication/read limits changed; current target renderer and emitted files match final03 exactly.'},
    'full_output_policy': 'All .work/usb013 run directories retained. Native source trees, binaries/maps and full .su remain there; archive contains compact records. No existing .work content cleaned.',
    'archive_sha256': sha(archive.read_bytes()), 'archive_entries': archive_index,
    'limits': ['No integrated generic callback execution or board evidence', 'Unknown LL failure propagation and confirmed cancellation block acceptance',
               'No full-repository test run claimed', 'No whole-program task/MSP/ISR stack or timing proof',
               'New ST code not downloaded; input license/version files and exact source hashes govern native code']}
(dest / 'index.json').write_text(json.dumps(index, indent=2), encoding='utf8')
print(json.dumps({'archive_bytes': archive.stat().st_size, 'records': len(entries),
                  'source_bindings': bindings, 'native_parts': [r['part'] for r in native]}, indent=2))
