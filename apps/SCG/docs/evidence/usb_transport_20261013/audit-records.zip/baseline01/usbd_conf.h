/* Host substitute; no hardware. */
