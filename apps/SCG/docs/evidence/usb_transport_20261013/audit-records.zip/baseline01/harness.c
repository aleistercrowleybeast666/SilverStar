#include <stdio.h>
#include <assert.h>
#include "pc_byte_stream.c"
uint32_t usb_test_mask;
USBD_HandleTypeDef hUsbDeviceFS;
uint8_t CDC_Transmit_FS(uint8_t *data, uint16_t length)
{ (void)data; (void)length; return USBD_OK; }
void SilverStarAssert_Check(uint8_t ok, SilverStarAssertModuleId module,
    const char *file, uint32_t line, SilverStarAssertReasonId reason)
{ (void)module; (void)file; (void)line; (void)reason; assert(ok); }
int main(void)
{
    uint8_t data[512] = {0};
    uint16_t actual;
    unsigned index;
    assert(PcByteStream_Init() == PC_BYTE_STREAM_INIT_OK);
    for (index = 0U; index < 8U; index++) { PcByteStream_OnUsbReceive(data, 64U); }
    actual = PcByteStream_Read(data, sizeof(data));
    printf("requested=512, actual=%u, dropped=%lu\n", (unsigned)actual,
        (unsigned long)PcByteStream_OverflowCount_Get());
    return actual == 512U ? 0 : 1;
}
