"""Inventory unresolved stack binding inputs without altering or bypassing the gate."""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[2]
PROJECT = ROOT / ".work/lf13final5"
TOOL = ROOT / "apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tools/check_task_stacks.py"
spec = importlib.util.spec_from_file_location("stack_checker_inventory", TOOL)
checker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checker)
build = PROJECT / "build/FCCG/SilverStar_F407/Release"
manifest = (PROJECT / "Generated/project_sources.mk").read_text(encoding="utf8")
block = re.search(r"(?ms)^C_SOURCES \+= \\\n(.*?)(?:\n\n|\Z)", manifest)
sources = [line.strip().removesuffix("\\").strip() for line in block[1].splitlines()]
graphs = [value for key, value in vars(checker).items() if key.startswith("BINDING_DEPENDENCIES")]
changed_inputs = {}
changed_graphs = {}
all_inputs = set()
for source in sources:
    dependency = build / Path(source).with_suffix(".d")
    names = dependency.read_text(encoding="utf8").split(":", 1)[1].replace("\\\n", " ").split("\n", 1)[0].split()
    graph_hash = hashlib.sha256("\n".join(names).encode()).hexdigest()
    if not any(graph_hash in graph.get(source, []) for graph in graphs):
        changed_graphs[source] = {"sha256": graph_hash, "dependencies": names}
    all_inputs.update(names)
    all_inputs.add(source)
for name in sorted(all_inputs):
    text = (PROJECT / name).read_text(encoding="utf8")
    digest = checker.BindingSourceHash_Get(text)
    if digest not in checker.BindingSourceVersions_Get(name):
        changed_inputs[name] = {"normalized_sha256": digest, "source": name in sources,
                                "bytes": (PROJECT / name).stat().st_size}
elf = next(build.glob("*.elf"))
result = {
    "purpose": "Read-only inventory; no production checker or binding modified; no stack PASS claim",
    "head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
    "project": str(PROJECT.relative_to(ROOT)),
    "elf_sha256": hashlib.sha256(elf.read_bytes()).hexdigest(),
    "checker_sha256": hashlib.sha256(TOOL.read_bytes()).hexdigest(),
    "compiled_sources": len(sources), "project_inputs": len(all_inputs),
    "unreviewed_inputs": changed_inputs, "unreviewed_dependency_graphs": changed_graphs,
    "acceptance": "NOT PROVEN; unknown-input rejection remains active",
}
destination = Path(__file__).with_name("stack_inventory_before.json")
destination.write_text(json.dumps(result, indent=2) + "\n", encoding="utf8")
print(json.dumps({key: result[key] for key in ("compiled_sources", "project_inputs", "unreviewed_inputs")}, indent=2))
print("changed_dependency_graphs", list(changed_graphs))
