"""Root-owned evidence packaging; reads files, never deletes or cleans a project."""
from pathlib import Path
import datetime, hashlib, json, subprocess, sys, zipfile
root = Path(__file__).resolve().parents[2]
work = Path(__file__).resolve().parent
target = root/'apps/SCG/docs/evidence/uart_maintenance_20261013/evidence.zip'
assert not target.exists()
target.parent.mkdir(parents=True,exist_ok=True)
entries = {}
def add(path, name=None):
    if path.is_file(): entries[name or str(path.relative_to(root)).replace('\\','/')] = path.read_bytes()
changed = subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
new = subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines()
for name in changed+new:
    if name.startswith(('apps/GSHC/','apps/SCG/','contracts/','docs/public/SCG/')):
        add(root/name, 'source/'+name)
for path in work.iterdir():
    if path.suffix in {'.log','.json','.py','.md','.diff'}: add(path)
for path in (work/'log_resource').rglob('*'):
    if path.suffix in {'.json','.log','.py','.c','.h','.md'} and 'pytest1' not in path.parts: add(path)
for path in (work/'scg_pytest03').rglob('run.json'): add(path)
for path in (work/'gshc_qa09').glob('*.png'): add(path)
project = work/'uart_project01'
for name in ['Makefile','SilverStar.ssproject','Generated/source_graph.json']:
    add(project/name)
for kind in ['Release','StaticAnalysis/Release']:
    build = project/'build/FCCG/SilverStar_F407'/kind
    for path in build.rglob('*'):
        if path.suffix in {'.elf','.bin','.map','.su','.d'} or path.name=='stack-budget.json': add(path)
versions = {}
for command in ([sys.executable,'--version'],['gcc','--version'],['arm-none-eabi-gcc','--version'],['mingw32-make','--version']):
    run = subprocess.run(command,capture_output=True,text=True)
    versions[' '.join(command)] = {'exit_code':run.returncode,'stdout':run.stdout,'stderr':run.stderr}
manifest = {'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope':'UART/GSHC verified dirty snapshot; USB drafts excluded; no hardware acceptance',
    'versions':versions,
    'gshc_command':'python -m pytest apps/GSHC/tests/test_file_service_client.py apps/GSHC/tests/test_file_transfer_ui.py apps/GSHC/tests/test_firmware_status.py apps/GSHC/tests/test_legacy_firmware_status.py apps/GSHC/tests/test_port_gui.py -q --basetemp=.work/dev013_safety2/gshc_tmp09',
    'gshc_exit':0,'gshc_environment':{'PYTHONPATH':'apps/GSHC;apps/GSHC/tests','QT_QPA_PLATFORM':'offscreen','GSHC_TRANSFER_QA_DIR':str(work/'gshc_qa09')},
    'scg_command':'python -m pytest apps/SCG/tests/test_log_file_service.py apps/SCG/tests/test_stack_budget.py -q --basetemp=.work/dev013_safety2/scg_pytest03',
    'scg_exit':0,'scg_environment':{'PYTHONPATH':'apps/SCG/src'},
    'files':{name:{'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)} for name,data in sorted(entries.items())}}
entries['manifest.json'] = json.dumps(manifest,indent=2).encode()
with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for name,data in sorted(entries.items()): archive.writestr(name,data)
digest = hashlib.sha256(target.read_bytes()).hexdigest()
(target.parent/'sha256.txt').write_text(digest+'  evidence.zip\n')
print('Packaged',len(entries),'files',target.stat().st_size,'bytes',digest)
