"""Root-owned sequential build runner; retains full output and exact exits."""
from pathlib import Path
import subprocess
import sys
import json
import datetime
import hashlib

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
name = sys.argv[1]
assert name.replace('_', '').replace('-', '').isalnum()
command = sys.argv[2:]
log = out / (name + '.log')
record = out / (name + '.json')
if log.exists() or record.exists():
    raise RuntimeError('Refusing to overwrite earlier evidence')
project = out / 'uart_project01'
inputs = {}
for path in project.rglob('*'):
    if path.is_file() and not str(path.relative_to(project)).startswith('build'):
        inputs[str(path.relative_to(project))] = hashlib.sha256(path.read_bytes()).hexdigest()
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
with log.open('wb') as stream:
    completed = subprocess.run(command, cwd=project, stdout=stream, stderr=subprocess.STDOUT)
record.write_text(json.dumps({'command': command, 'cwd': str(project), 'started_utc': start,
    'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'exit_code': completed.returncode, 'inputs': inputs}, indent=2))
print(name, 'exit', completed.returncode, 'log', log, flush=True)
sys.exit(completed.returncode)
