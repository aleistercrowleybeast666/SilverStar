"""Reproduce the retained pre-fix failure without replacing historical evidence."""
from pathlib import Path
import hashlib, json, shutil, subprocess
root = Path(__file__).resolve().parents[3]
out = Path(__file__).resolve().parent
record = out / 'baseline-reproduced02.json'
assert not record.exists()
core = root / 'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload'
old = out / 'baseline/apps/SCG/plugins/builtin'
fixture = out / 'baseline-probe-fixture.c'
source = old / 'silverstar_core_0_1_0/payload/System/Src/system_log_file.c'
adapter = old / 'silverstar_device_storage_sd_sdio_fatfs/payload/Devices/Storage/SdSdioFatFs/Adapter/Src/log_file_storage.c'
includes = [old / 'silverstar_core_0_1_0/payload/System/Inc',
    root / 'apps/SCG/tests/log_file_service', core / 'System/Inc', core / 'Interfaces/Inc', core / 'Common/Inc',
    root / 'apps/SCG/plugins/builtin/silverstar_platform_api/payload/Platform/Inc']
binary = out / 'baseline-probe02.exe'
command = [shutil.which('gcc'), '-std=c11','-O2','-Wall','-Wextra','-Werror','-fanalyzer']
command += ['-I'+str(p) for p in includes]
command += [str(p) for p in (fixture, source, core/'Common/Src/common_format.c',adapter)] + ['-o',str(binary)]
results = []
for cmd in [command, [str(binary)], [str(binary),'start-window'], [str(binary),'full-chunk']]:
    run = subprocess.run(cmd,capture_output=True,text=True,timeout=90)
    results.append(dict(command=cmd,exit_code=run.returncode,stdout=run.stdout,stderr=run.stderr))
    if cmd == command and run.returncode != 0: break
record.write_text(json.dumps({'fixture_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),
    'baseline':'f2ce541382589cb606e1f5b21f6fd982357eaa54','results':results},indent=2))
print([(r['exit_code'],r['stderr'][:150]) for r in results])
assert len(results)==4 and results[0]['exit_code']==0 and results[1]['exit_code']==0
assert results[2]['exit_code']!=0 and 'code=LOCKED' in results[2]['stderr']
assert results[3]['exit_code']==0
