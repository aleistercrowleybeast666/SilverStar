# Stack binding review in progress

Scope: original `lf13final5` F407 Release ELF, current code checkpoint
`f2ce541382589cb606e1f5b21f6fd982357eaa54`. This is a review input, not a
registration, gate pass, whole-program stack proof or firmware acceptance.

The unmodified emitted checker fails on the first unknown complete source.
The separate inventory examined every selected C source and every actual GCC
`-MMD` dependency. Of 157 translation units and 391 unique project inputs,
seven inputs are not present in the historical exact-source versions:

| Input | Change requiring review |
| --- | --- |
| `System/Src/system_log_file.c` | New SerialTask parser/mailbox and LoggerTask worker. No callback field, registry, indirect call, allocation or recursion in this source. Internal transitions, cancellation and publication need runtime-contract tests independently of stack accounting. |
| `System/Inc/system_log_file.h` | New fixed-capacity buffers, enum results and direct storage operations. No function-pointer or callback type. |
| `Devices/Storage/SdSdioFatFs/Adapter/Src/log_file_storage.c` | New private FIL/DIR and direct FatFs calls, reaching existing reviewed disk dispatch. No SD_Driver reference or registration. READ open/seek/read/close timing remains unproven. |
| `APP/Src/logger_task.c` | At this checkpoint, only the new header and a direct `SystemLogFile_Process()` call before finalization handling differ from v0.1.2. This adds a real LoggerTask call path, which must be budgeted. |
| `System/Src/system_console.c` | New header and direct LOGFILE dispatch before the old parser. Existing branches are unchanged. SerialTask nesting must include both the console frame and file parser frame. |
| `Generated/Src/project_metadata.c` | Full diff against the exact v15 fixture changes only `SILVERSTAR_PROJECT_CONFIG_DIGEST` from `0x871692B0` to `0x5CEC898C`. No generic metadata exemption is permitted. |
| `Generated/Src/project_log_decoder_profile.c` | Full diff against the exact v15 fixture changes only two 16-byte identity arrays, not their types, lengths or copying code. No generic decoder exemption is permitted. |

Four compiled dependency graphs changed: system_log_file, logger_task,
log_file_storage and system_console. Their exact ordered dependency lists are
in `stack_inventory_before.json`. All old dependency inputs outside the seven
above still match a previously registered complete-source fingerprint. The
new header brings existing console/interface types into the logger and storage
graphs. Coverage must remain compiler-derived and include all suffixes.

The original checker reaches its full-source verifier only after its concrete
linked FatFs/SD, selected device-startup and MPU binding checks. Those checks
did not throw for this ELF. That does not waive the full-source review or prove
unknown calls/recursion absent from newly reachable task closures; the original
budget traversal remains required after any justified exact-source revision.

`project_metadata.c.diff` and `project_log_decoder_profile.c.diff` retain those
complete identity comparisons. `indirect_sites_before.json` inventories all
21 raw linked indirect instructions; none is in a LogFile function. The raw
inventory does not resolve or exempt any instruction.

No changes to minimum margin (256 bytes), context reserve (256 bytes), task
stack sizes, source coverage, indirect-call restrictions, allocation rules or
existing exceptions are proposed here. Main/MSP/ISR nesting and hardware
margins remain a separate NOT PROVEN claim even if a task budget later passes.
