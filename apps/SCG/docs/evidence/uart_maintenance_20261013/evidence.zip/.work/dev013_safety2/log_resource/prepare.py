from pathlib import Path
import hashlib, json, subprocess
root = Path(__file__).resolve().parents[3]
out = Path(__file__).resolve().parent
owned = [
 'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/System/Src/system_log_file.c',
 'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/System/Inc/system_log_file.h',
 'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/APP/Src/logger_task.c',
 'apps/SCG/plugins/builtin/silverstar_device_storage_sd_sdio_fatfs/payload/Devices/Storage/SdSdioFatFs/Adapter/Src/log_file_storage.c',
 'apps/SCG/plugins/builtin/silverstar_device_storage_sd_sdio_fatfs_f1/payload/Devices/Storage/SdSdioFatFs/Adapter/Src/log_file_storage.c',
 'apps/SCG/tests/test_log_file_service.py',
 'apps/SCG/tests/log_file_service/test_log_file_service.c',
 'contracts/log_file_service_v1.json',
 'docs/public/SCG/LOG_FILE_SERVICE_V1.md',
]
manifest = {}
for rel in owned:
    data = subprocess.check_output(['git','show','f2ce541382589cb606e1f5b21f6fd982357eaa54:'+rel],cwd=root)
    path = out/'baseline'/rel
    path.parent.mkdir(parents=True,exist_ok=True)
    assert not path.exists()
    path.write_bytes(data)
    manifest[rel] = hashlib.sha256(data).hexdigest()
(out/'baseline-source.json').write_text(json.dumps(manifest,indent=2))
print('saved baseline',len(manifest))
