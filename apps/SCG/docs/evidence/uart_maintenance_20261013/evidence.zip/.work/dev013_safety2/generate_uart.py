"""Root-owned fresh UART maintenance verification project; no user output touched."""
from pathlib import Path
import sys
import json
import hashlib

root = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(root / 'apps/SCG/src'))
from silverstar_fccg.app.service import FccgService

destination = root / '.work/dev013_safety2/uart_project01'
if destination.exists():
    raise RuntimeError('Fresh destination required')
service = FccgService(root / 'apps/SCG')
model = service.ReferenceProject_Create('uart013s2')
service.Project_Save(model, destination, confirm_dangerous=True)
files = []
for path in destination.rglob('*'):
    if path.is_file():
        data = path.read_bytes()
        files.append({'path': str(path.relative_to(destination)), 'bytes': len(data),
                      'sha256': hashlib.sha256(data).hexdigest()})
(destination.parent / 'uart_project01-generated-inventory.json').write_text(json.dumps(
    {'owner': 'root', 'purpose': 'Fresh F407 UART maintenance Host/ARM/analyzer validation',
     'generated_root': str(destination), 'files': files}, indent=2))
print('generated', destination, len(files), 'files', sum(f['bytes'] for f in files), 'bytes')
