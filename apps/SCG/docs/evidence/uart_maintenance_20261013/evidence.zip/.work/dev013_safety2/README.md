# Development 0.1.3 safety follow-up

Owner: root integrator. Created for the authorized 2026-10-13 follow-up to
`f2ce541382589cb606e1f5b21f6fd982357eaa54`. No hardware is accessed.

This directory holds small diagnostic scripts, source-binding inventories and
command logs. It contains no cloned checkout, environment, SDK or device data.
The retained original `.work/lf13final5` project is read-only analysis input.
The original evidence under `apps/SCG/docs/evidence/log_file_service_20261013`
and frozen v0.1.2 files remain untouched.

* `stack_inventory.py` reads every selected source and GCC dependency input;
  it never registers fingerprints or bypasses the emitted checker.
* `stack_inventory_before.json`: 157 C sources, 391 inputs, seven unknown full
  inputs and four changed dependency graphs. No stack acceptance claim.
* `stack-before.log` and its command record: sandbox strict-path denial before
  checker execution; exit 2 retained separately.
* `stack-before-unrestricted.log` and its command record: actual emitted stack
  failure for `System/Src/system_log_file.c`; exit 2.
* `v012-f407-artifact-check.log`: exact Git bytes of the frozen evidence at
  `v0.1.2:apps/SCG/docs/evidence/scg-freeze-contract-repair-20261010/baseline/fzlegacy-Flight-artifact-check.log`.
  SHA-256 `ba798be505e7428eb5aefe031136ef56d38060375d76f11f3c34f13420924c6f`.

The recorded v0.1.2 configuration used 102388 main SRAM bytes, 57128 CCM bytes,
and 330808 FLASH bytes. `lf13final5` used 102388, 59400, and 337848 respectively.
Thus the 12-byte remaining main-SRAM project budget already existed in that
frozen configuration; the file-service increment was 2272 CCM and 7040 FLASH
bytes. This comparison does not assert all v0.1.2 variants have that usage.

No cleanup is authorized by this inventory. Logs and evidence are retained.
