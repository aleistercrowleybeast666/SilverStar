"""Update only inventoried, root-generated validation payloads from their owners.
Normal Generate preservation is unchanged. Never runs on a user project.
"""
from pathlib import Path
import hashlib
import json
import subprocess

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
project = (out / 'uart_project01').resolve()
assert project.parent == out.resolve()
inventory = json.loads((out / 'uart_project01-generated-inventory.json').read_text())
if (out / 'uart-current-inventory.json').exists():
    inventory = json.loads((out / 'uart-current-inventory.json').read_text())
owned = {x['path'].replace('\\', '/'): x for x in inventory['files']}
updates = {}
for name in subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines():
    if '/payload/' not in name:
        continue
    relative = name.split('/payload/',1)[1]
    if relative not in owned:
        raise ValueError('Not a generated owned payload: ' + relative)
    content = (root / name).read_bytes()
    if relative in updates and updates[relative][1] != content:
        raise ValueError('Conflicting owners: ' + relative)
    updates[relative] = (name, content)
changes = []
for relative, (name, content) in updates.items():
    target = project / relative
    before = hashlib.sha256(target.read_bytes()).hexdigest()
    after = hashlib.sha256(content).hexdigest()
    if before == after:
        continue
    if before != owned[relative]['sha256']:
        raise ValueError('Unexpected modification: ' + relative)
    target.write_bytes(content)
    changes.append({'owner':name,'path':relative,'before':before,'after':after})
    owned[relative]['sha256'] = after
    owned[relative]['bytes'] = len(content)
number = len(list(out.glob('uart-refresh-*.json'))) + 1
(out / f'uart-refresh-{number:02}.json').write_text(json.dumps(changes,indent=2))
# Separate current ownership index; the initial generation inventory is immutable.
(out / 'uart-current-inventory.json').write_text(json.dumps({'files':list(owned.values())},indent=2))
print('refreshed',len(changes),'root-generated files')
