"""Preserve only this task's four unverified USB drafts, then isolate them."""
from pathlib import Path
import hashlib, json, subprocess

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent / 'usb_deferred_20261013'
out.mkdir(exist_ok=False)
tracked = ['apps/SCG/src/silverstar_fccg/build/native_compile.py',
           'apps/SCG/src/silverstar_fccg/generator/usb_cdc_transport.py']
untracked = ['apps/SCG/src/silverstar_fccg/app/usb_transport_project.py',
             'apps/SCG/src/silverstar_fccg/generator/usb_cdc_hooks.py']
items = []
for name in tracked + untracked:
    source = (root / name).resolve()
    assert source.is_relative_to(root)
    content = source.read_bytes()
    target = out / name
    target.parent.mkdir(parents=True, exist_ok=True)
    if name in untracked:
        # These two new files were created by this task. Move only exact files,
        # with verified source/destination containment; no recursive cleanup.
        assert target.resolve().is_relative_to(out.resolve())
        assert not target.exists()
        source.replace(target)
    else:
        target.write_bytes(content)
        source.write_bytes(subprocess.check_output(['git','show','HEAD:' + name],cwd=root))
    assert target.read_bytes() == content
    items.append({'path':name,'sha256':hashlib.sha256(content).hexdigest(),'bytes':len(content)})
(out / 'inventory.json').write_text(json.dumps({'owner':'root',
    'purpose':'User deferred USB to the next session. NOT VALIDATED; not part of UART delivery.',
    'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    'known_blockers':['PMA retirement does not prove interrupt/event quiescence',
                      'DeInit must never call Quiesced after failed retirement',
                      'Real callback project integration and compilation not verified'],
    'files':items},indent=2))
print('Preserved and isolated', len(items), 'USB draft files:', out)
