from pathlib import Path
import json, os, shutil, subprocess, sys
root = Path(__file__).resolve().parents[3]
out = Path(__file__).resolve().parent
base = root/'apps/SCG/plugins/builtin'
core = base/'silverstar_core_0_1_0/payload'
fixture = root/'apps/SCG/tests/log_file_service'
old = out/'baseline'
source = old/'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/System/Src/system_log_file.c'
adapter = old/'apps/SCG/plugins/builtin/silverstar_device_storage_sd_sdio_fatfs/payload/Devices/Storage/SdSdioFatFs/Adapter/Src/log_file_storage.c'
includes = [fixture,core/'System/Inc',core/'Interfaces/Inc',core/'Common/Inc',base/'silverstar_platform_api/payload/Platform/Inc']
binary = out/'baseline-probe.exe'
command = [shutil.which('gcc'),'-std=c11','-O2','-Wall','-Wextra','-Werror','-fanalyzer']
command += ['-I'+str(p) for p in includes]
command += [str(fixture/'test_log_file_service.c'),str(source),str(core/'Common/Src/common_format.c'),str(adapter),'-o',str(binary)]
results=[]
shutil.copyfile(fixture/'test_log_file_service.c',out/'baseline-probe-fixture.c')
for cmd in [command,[str(binary)],[str(binary),'start-window'],[str(binary),'full-chunk']]:
    run=subprocess.run(cmd,cwd=root,capture_output=True,text=True,timeout=90)
    results.append(dict(command=cmd,exit_code=run.returncode,stdout=run.stdout,stderr=run.stderr))
    (out/'baseline-probe.json').write_text(json.dumps(results,indent=2))
    print(run.returncode,run.stdout,run.stderr,flush=True)
