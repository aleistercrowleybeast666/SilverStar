# Log resource and lifecycle follow-up

Owner: `/root/astra_log_service`. Baseline: `f2ce541382589cb606e1f5b21f6fd982357eaa54`.
This small directory is reserved for fresh generated/reference builds and auditable
baseline/post-change evidence. It does not authorize deletion of historical work.

Read-only finding: frozen v0.1.2 `fzlegacy-Flight-artifact-check.log` records main
SRAM 102388 bytes, CCM 57128 bytes and FLASH 330808 bytes. The previous final5
candidate records the same main SRAM, CCM 59400 and FLASH 337848. New file-service
objects therefore account for 2272 bytes of CCM section growth, not main SRAM.

Implementation and validation are pending. No hardware validation is implied.
