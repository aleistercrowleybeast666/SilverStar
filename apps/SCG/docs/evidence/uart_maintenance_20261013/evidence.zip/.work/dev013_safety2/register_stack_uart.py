"""Register only the reviewed 2026-10-13 UART input snapshot, not arbitrary input.
The input inventory and review note are retained with the task evidence.
"""
from pathlib import Path
import json
import pprint

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
inventory = json.loads((out / 'stack_inventory_uart01.json').read_text())
expected = {
 'APP/Inc/logger_bus.h', 'APP/Src/logger_bus.c', 'APP/Src/logger_task.c',
 'Devices/Storage/SdSdioFatFs/Adapter/Src/log_file_storage.c',
 'FlightLogic/FlightCycle/Src/silverstar_flight_cycle.c',
 'Generated/Src/project_log_decoder_profile.c', 'Generated/Src/project_metadata.c',
 'System/Inc/system_lifecycle.h', 'System/Inc/system_log_file.h',
 'System/Src/system_console.c', 'System/Src/system_log_file.c'}
assert set(inventory['unreviewed_inputs']) == expected
assert set(inventory['unreviewed_dependency_graphs']) == {
 'System/Src/system_log_file.c', 'APP/Src/logger_task.c',
 'Devices/Storage/SdSdioFatFs/Adapter/Src/log_file_storage.c', 'System/Src/system_console.c'}
source = {k:[v['normalized_sha256']] for k,v in inventory['unreviewed_inputs'].items()}
deps = {k:[v['sha256']] for k,v in inventory['unreviewed_dependency_graphs'].items()}
tool = root / 'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tools/check_task_stacks.py'
text = tool.read_text(encoding='utf-8')
assert 'BINDING_SOURCE_UART_MAINTENANCE_V16' not in text
block = '''# Exact UART maintenance review v16, 2026-10-13 development task.
# Eleven complete inputs and four compiler dependency graphs are registered.
# New service/lifecycle/status paths have direct calls only; linked FatFs SD and
# startup callback proofs still run unchanged. No callback target, threshold,
# unknown-source/dependency/indirect/recursion rejection or source scope changes.
# Scope and unresolved whole-firmware MSP/ISR obligations are recorded in
# docs/public/SCG/UART_MAINTENANCE_20261013.md and its evidence inventory.
'''
block += 'BINDING_SOURCE_UART_MAINTENANCE_V16 = ' + pprint.pformat(source,sort_dicts=True) + '\n\n'
block += 'BINDING_DEPENDENCIES_UART_MAINTENANCE_V16 = ' + pprint.pformat(deps,sort_dicts=True) + '\n\n\n'
text = text.replace('def BindingSourceVersions_Get(path):', block + 'def BindingSourceVersions_Get(path):')
text = text.replace('BINDING_SOURCE_INTEGRATION_IDENTITIES_V15.get(path, []))',
 'BINDING_SOURCE_INTEGRATION_IDENTITIES_V15.get(path, []) +\n            BINDING_SOURCE_UART_MAINTENANCE_V16.get(path, []))')
text = text.replace('BINDING_DEPENDENCIES_RF_QUEUE_V9.get(path, []))',
 'BINDING_DEPENDENCIES_RF_QUEUE_V9.get(path, []) +\n                          BINDING_DEPENDENCIES_UART_MAINTENANCE_V16.get(path, []))')
text = text.replace('BINDING_REVIEW_REVISION = "rf_four_provider_queue_20261007_v9"',
 'BINDING_REVIEW_REVISION = "uart_maintenance_20261013_v16"')
tool.write_text(text,encoding='utf-8',newline='\n')
(root / 'apps/SCG/tools/reference_overlays/check_task_stacks.py').write_bytes(tool.read_bytes())
print('Registered 11 exact source/header inputs and 4 dependency graphs; bounds unchanged')
