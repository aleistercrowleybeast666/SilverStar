"""Register only reviewed full inputs; preserve all prior gates and revisions."""
from pathlib import Path
import json,pprint
root=Path(__file__).resolve().parents[2]
out=Path(__file__).resolve().parent
data=json.loads((out/'stack_inventory01.json').read_text())
expected={'APP/Src/logger_task.c','Generated/Src/project_log_decoder_profile.c',
          'Generated/Src/project_metadata.c','System/Inc/system_log_file.h',
          'System/Src/system_console.c','System/Src/system_log_file.c'}
assert set(data['unreviewed_inputs'])==expected
assert not data['unreviewed_dependency_graphs']
table={key:[value['normalized_sha256']] for key,value in data['unreviewed_inputs'].items()}
tool=root/'apps/SCG/plugins/builtin/silverstar_core_0_1_0/payload/Tools/check_task_stacks.py'
text=tool.read_text(encoding='utf-8')
assert 'BINDING_SOURCE_MAINTENANCE_DIAGNOSTICS_V17' not in text
block='''# Maintenance 0.1 diagnostic review v17: six exact complete inputs.
# RAM snapshot copy, completed-write observations, bounded direct diagnostic
# readers and two generated identity sources; no new indirect edges or graphs.
# Existing callback proofs, unknown-source rejection and stack margins unchanged.
# See docs/public/SCG/MAINTENANCE_0_1_20261013.md for evidence and unresolved bounds.
'''
block+='BINDING_SOURCE_MAINTENANCE_DIAGNOSTICS_V17 = '+pprint.pformat(table,sort_dicts=True)+'\n\n\n'
text=text.replace('def BindingSourceVersions_Get(path):',block+'def BindingSourceVersions_Get(path):')
text=text.replace('BINDING_SOURCE_UART_MAINTENANCE_V16.get(path, []))',
    'BINDING_SOURCE_UART_MAINTENANCE_V16.get(path, []) +\n            BINDING_SOURCE_MAINTENANCE_DIAGNOSTICS_V17.get(path, []))')
text=text.replace('BINDING_REVIEW_REVISION = "uart_maintenance_20261013_v16"',
                  'BINDING_REVIEW_REVISION = "maintenance_diagnostics_20261013_v17"')
tool.write_text(text,encoding='utf-8',newline='\n')
(root/'apps/SCG/tools/reference_overlays/check_task_stacks.py').write_bytes(tool.read_bytes())
print('Registered six exact complete inputs; no dependency graph or gate exception changes')
