"""Root-owned, append-only command evidence; never opens hardware."""
from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys
root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
name = sys.argv[1]
assert name.replace('-', '').replace('_', '').isalnum()
assert not (out / (name + '.json')).exists() and not (out / (name + '.log')).exists()
inputs = {}
for folder in ('apps/GSHC', 'apps/SCG/src', 'apps/SCG/tests', 'contracts'):
    for p in (root / folder).rglob('*'):
        if p.is_file() and '.work' not in p.parts and p.suffix in {'.py', '.json'}:
            inputs[p.relative_to(root).as_posix()] = hashlib.sha256(p.read_bytes()).hexdigest()
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out / (name + '.log')).open('xb') as stream:
    run = subprocess.run(sys.argv[2:], cwd=root, stdout=stream, stderr=subprocess.STDOUT)
(out / (name + '.json')).write_text(json.dumps(dict(command=sys.argv[2:], cwd=str(root),
    started=started, finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    exit_code=run.returncode, environment={k: os.environ.get(k) for k in
    ('PYTHONPATH','QT_QPA_PLATFORM','GSHC_TRANSFER_QA_DIR','PSExecutionPolicyPreference')},
    inputs=inputs), indent=2))
print(name, 'exit', run.returncode)
sys.exit(run.returncode)
