# Maintenance 0.1 lightweight diagnostics

Owner: root integrator. Base: e1c40c5. Purpose: user-authorized bounded runtime
diagnostics and maintenance 0.1 compatibility. No arbitrary variable directory,
watch expressions, symbol/memory access or SWD. USB remains deferred.
This directory owns only its new scripts, generated validation project and logs.
No cleanup is authorized. Formal evidence and existing inputs are retained.
