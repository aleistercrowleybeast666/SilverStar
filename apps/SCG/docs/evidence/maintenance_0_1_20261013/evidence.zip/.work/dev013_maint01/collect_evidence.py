"""Package exact local evidence; no deletion, network or hardware operations."""
from pathlib import Path
import datetime, hashlib, importlib.metadata, json, subprocess, sys, zipfile
root = Path(__file__).resolve().parents[2]
work = Path(__file__).resolve().parent
target = root/'apps/SCG/docs/evidence/maintenance_0_1_20261013/evidence.zip'
assert not target.exists()
expected = ('arm02','analyzer02','gates04','host05','gshc_tests04','scg_tests08')
for name in expected:
    record = json.loads((work/(name+'.json')).read_text())
    assert record['exit_code'] == 0, name
reuse = json.loads((work/'compiled-reuse.json').read_text())
assert all(not run['mismatches'] for run in reuse['runs'].values())
entries = {}
def add(path, name=None):
    if path.is_file(): entries[name or path.relative_to(root).as_posix()] = path.read_bytes()
changed = subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
new = subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines()
for name in changed+new:
    if name.startswith(('apps/GSHC/','apps/SCG/','contracts/','docs/public/SCG/')):
        add(root/name, 'source/'+name)
for p in work.iterdir():
    if p.suffix in {'.py','.json','.md','.log','.diff'}: add(p)
for p in (work/'gshc_qa04').glob('*.png'): add(p)
project = work/'project01'
for name in ('Makefile','SilverStar.ssproject','Generated/source_graph.json','uart013m01.ssdecoder'):
    add(project/name)
for kind in ('Release','StaticAnalysis/Release'):
    build = project/'build/FCCG/SilverStar_F407'/kind
    for p in build.rglob('*'):
        if p.suffix in {'.elf','.bin','.map','.su','.d'} or p.name=='stack-budget.json': add(p)
for p in (project/'build/FCCG/Host/Tests/StorageIntegrity').glob('*.json'): add(p)
versions = {}
for command in ([sys.executable,'--version'],['D:/msys64/ucrt64/bin/python.exe','--version'],['gcc','--version'],['arm-none-eabi-gcc','--version'],['mingw32-make','--version']):
    run = subprocess.run(command,capture_output=True,text=True)
    versions[' '.join(command)] = dict(exit_code=run.returncode,stdout=run.stdout,stderr=run.stderr)
manifest = dict(base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    scope='Maintenance 0.1 exact dirty source snapshot; UART/GSHC; no hardware or USB expansion acceptance',
    final_runs=list(expected), versions=versions,
    python_packages={name:importlib.metadata.version(name) for name in ('PySide6','pytest','pyserial')},
    frozen_v012_tag=subprocess.check_output(['git','rev-parse','v0.1.2','v0.1.2^{}'],cwd=root,text=True).splitlines(),
    files={name:dict(sha256=hashlib.sha256(data).hexdigest(),bytes=len(data)) for name,data in sorted(entries.items())})
entries['manifest.json'] = json.dumps(manifest,indent=2).encode()
target.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for name,data in sorted(entries.items()): archive.writestr(name,data)
digest = hashlib.sha256(target.read_bytes()).hexdigest()
(target.parent/'sha256.txt').write_text(digest+'  evidence.zip\n')
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    for name, item in manifest['files'].items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == item['sha256'], name
print('Verified',len(entries),'entries',target.stat().st_size,'bytes',digest)
