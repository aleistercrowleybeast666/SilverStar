from pathlib import Path
import sys,json,datetime,hashlib,subprocess
out=Path(__file__).resolve().parent
project=out/'project01'
name=sys.argv[1]
assert name.replace('-','').isalnum()
assert not (out/(name+'.json')).exists() and not (out/(name+'.log')).exists()
inputs={str(p.relative_to(project)):hashlib.sha256(p.read_bytes()).hexdigest() for p in project.rglob('*') if p.is_file() and not str(p.relative_to(project)).startswith('build')}
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out/(name+'.log')).open('wb') as stream:
    result=subprocess.run(sys.argv[2:],cwd=project,stdout=stream,stderr=subprocess.STDOUT)
(out/(name+'.json')).write_text(json.dumps({'command':sys.argv[2:],'cwd':str(project),'started':started,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':result.returncode,'inputs':inputs},indent=2))
print(name,'exit',result.returncode)
sys.exit(result.returncode)
