from pathlib import Path
import sys, json, hashlib
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root/'apps/SCG/src'))
from silverstar_fccg.app.service import FccgService
out=Path(__file__).resolve().parent
project=out/'project01'
assert not project.exists()
service=FccgService(root/'apps/SCG')
model=service.ReferenceProject_Create('uart013m01')
assert model.ProtocolProfiles_Get()['maintenance']=='maintenance.serial.0_1'
service.Project_Save(model,project,confirm_dangerous=True)
files=[{'path':str(p.relative_to(project)).replace('\\','/'),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in project.rglob('*') if p.is_file()]
(out/'generated-inventory.json').write_text(json.dumps({'owner':'root','purpose':'Fresh maintenance 0.1 validation only','files':files},indent=2))
print('generated',len(files),'files',sum(p['bytes'] for p in files),'bytes')
