"""Prove that every actual compiled dependency still matches its recorded build."""
from pathlib import Path
import difflib, hashlib, json, re
out = Path(__file__).resolve().parent
project = out / 'project01'
build = project / 'build/FCCG/SilverStar_F407/Release'
manifest = (project / 'Generated/project_sources.mk').read_text()
block = re.search(r'(?ms)^C_SOURCES \+= \\\n(.*?)(?:\n\n|\Z)', manifest)
sources = [line.strip().removesuffix('\\').strip() for line in block[1].splitlines()]
inputs = set(sources)
for source in sources:
    dependency = (build / Path(source).with_suffix('.d')).read_text()
    inputs.update(dependency.split(':',1)[1].replace('\\\n',' ').split('\n',1)[0].split())
result = {'compiled_sources': len(sources), 'compiled_inputs':len(inputs), 'runs':{}}
for name in ('arm02','analyzer02','gates04'):
    record = json.loads((out / (name+'.json')).read_text())
    mismatch = [p for p in sorted(inputs) if record['inputs'].get(p.replace('/','\\')) != hashlib.sha256((project/p).read_bytes()).hexdigest()]
    result['runs'][name] = {'exit_code':record['exit_code'], 'mismatches':mismatch}
    assert record['exit_code'] == 0 and not mismatch, result
elf = next(build.glob('*.elf'))
result['elf_sha256'] = hashlib.sha256(elf.read_bytes()).hexdigest()
old = out.parent/'dev013_safety2/uart_project01'
identity_diffs = []
for name in ('Generated/Src/project_metadata.c','Generated/Src/project_log_decoder_profile.c'):
    identity_diffs.extend(difflib.unified_diff((old/name).read_text().splitlines(True), (project/name).read_text().splitlines(True), fromfile='v16/'+name,tofile='v17/'+name))
(out/'identity-review.diff').write_text(''.join(identity_diffs))
(out/'compiled-reuse.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
