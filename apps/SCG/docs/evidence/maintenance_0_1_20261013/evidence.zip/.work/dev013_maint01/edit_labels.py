from pathlib import Path
import json
p = Path('apps/GSHC/services/i18n.py')
lines = p.read_text(encoding='utf-8').splitlines(keepends=True)
matches = [i for i,line in enumerate(lines) if '"page.maintenance":' in line]
assert len(matches) == 2
for index,value in zip(matches, ('运行诊断 / 日志', 'Runtime / Logs')):
    lines[index] = '    "page.maintenance": ' + json.dumps(value,ensure_ascii=False) + ',\n'
p.write_text(''.join(lines),encoding='utf-8')
