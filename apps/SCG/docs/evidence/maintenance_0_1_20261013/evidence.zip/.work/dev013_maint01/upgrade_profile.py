from pathlib import Path
import json
root=Path(__file__).resolve().parents[2]
directory=root/'apps/SCG/plugins/builtin/silverstar_protocol_maintenance_serial_0_0'
path=directory/'plugin.json'
data=json.loads(path.read_text(encoding='utf-8'))
data['version']='0.1.1'
data['name']='Serial Maintenance Protocol 0.0 / 0.1'
data['description']='Backward-compatible serial maintenance, bounded read-only diagnostics and separately versioned log file service.'
data['protocol']['maintenance_protocol_version']='0.1'
profile=json.loads(json.dumps(data['protocol']['profiles']['maintenance'][0]))
profile.update(id='maintenance.serial.0_1',version='0.1',decoder_metadata='Protocol/metadata/maintenance_serial_0_1.json',
    display_names={'zh_CN':'串口维护协议 0.1','en_US':'Serial Maintenance Protocol 0.1'})
profile['documentation']=['docs/MAINTENANCE_PROTOCOL_0_1.md']
data['protocol']['profiles']['maintenance'].append(profile)
data['payload']['roots'].append('Protocol/metadata/maintenance_serial_0_1.json')
path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
metadata=json.loads((directory/'payload/Protocol/metadata/maintenance_serial_0_0.json').read_text())
metadata.update(profile_id='maintenance.serial.0_1',maintenance_version='0.1',compatible_versions=['0.0'],
    diagnostic_schema_version=1,file_service_version=1,diagnostic_command='SYSTEM DIAG [cursor]')
(directory/'payload/Protocol/metadata/maintenance_serial_0_1.json').write_text(json.dumps(metadata,indent=2)+'\n')
for name in ['apps/SCG/src/silverstar_fccg/project/model.py','apps/SCG/src/silverstar_fccg/project/reference.py']:
    p=root/name
    text=p.read_text(encoding='utf-8')
    text=text.replace('"maintenance": "maintenance.serial.0_0"','"maintenance": "maintenance.serial.0_1"',1)
    p.write_text(text,encoding='utf-8')
# These assertions are explicitly about the newly-created reference defaults.
for name in ['test_generation_feature_completion.py','test_current_prompt_round.py']:
    p=root/'apps/SCG/tests'/name
    text=p.read_text(encoding='utf-8').replace('maintenance.serial.0_0','maintenance.serial.0_1')
    text=text.replace('Serial Maintenance Protocol 0.0 (`maintenance.serial.0_1`)','Serial Maintenance Protocol 0.1 (`maintenance.serial.0_1`)')
    p.write_text(text,encoding='utf-8')
