from pathlib import Path
import datetime, hashlib, json
root = Path(__file__).resolve().parents[2]
work = Path(__file__).resolve().parent
files = {}
for folder in (work,root/'apps/SCG/.work/dev013_maint01'):
    for p in folder.rglob('*'):
        if p.is_file() and p.name != 'retained-inventory.json':
            files[p.relative_to(root).as_posix()] = dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
result = dict(owner='root integrator',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    purpose='Maintenance 0.1 generated validation, tests and exact source/build evidence',
    retained_evidence='apps/SCG/docs/evidence/maintenance_0_1_20261013/evidence.zip',
    cleanup_authorized=False, files=files)
(work/'retained-inventory.json').write_text(json.dumps(result,indent=2))
print(len(files),'inventoried files;',sum(x['bytes'] for x in files.values()),'bytes; no deletion')
