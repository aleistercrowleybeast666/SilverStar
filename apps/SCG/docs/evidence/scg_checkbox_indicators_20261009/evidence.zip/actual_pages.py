"""Own offscreen SCG window; never connects to or saves a user project."""
from pathlib import Path
from copy import deepcopy
from uuid import uuid4
import json, os, sys
ROOT = Path('D:/python_software/SilverStar')
SCG = ROOT / '.work/qint/apps/SCG'
sys.path.insert(0, str(SCG / 'src'))
os.environ['QT_QPA_PLATFORM'] = 'offscreen'
from PySide6.QtWidgets import QApplication, QCheckBox
from PySide6.QtGui import QFontDatabase, QFont
from silverstar_fccg.app.service import FccgService
from silverstar_fccg.core.settings import SettingsStore
from silverstar_fccg.ui.main_window import MainWindow
from silverstar_fccg.ui.widgets import CollapsibleSection
from silverstar_fccg.ui.theme import Theme_Apply
from silverstar_fccg.core.i18n import Translator
from silverstar_fccg.ui.pages.navigation_alignment import AlignmentConfigurationEditor
app = QApplication([])
font = QFontDatabase.addApplicationFont('C:/Windows/Fonts/segoeui.ttf')
app.setFont(QFont(QFontDatabase.applicationFontFamilies(font)[0], 11))
theme = sys.argv[1]
settings = SettingsStore(SCG / '.work/gui_checkbox_preview' / uuid4().hex / 'scg.ini')
window = MainWindow(settings, service=FccgService(SCG), language='en_US', theme=theme)
window.resize(1250, 950)
window.show()
app.processEvents()
model = deepcopy(window._model.Dictionary_Get())
choices = tuple((box.isChecked(), box.isEnabled()) for box in window.findChildren(QCheckBox))
Theme_Apply(app, theme)
assert window._model.Dictionary_Get() == model
assert choices == tuple((box.isChecked(), box.isEnabled()) for box in window.findChildren(QCheckBox))
assert window.build_page.QualityTargets_Get() == ('flight',)
out = ROOT / '.work/checkbox_20261009/actual'
out.mkdir(parents=True, exist_ok=True)
inventory = []
for box in window.findChildren(QCheckBox):
    parents = []
    parent = box.parentWidget()
    while parent is not None and parent is not window:
        parents.append(type(parent).__name__ + ':' + parent.objectName())
        parent = parent.parentWidget()
    inventory.append(dict(type=type(box).__name__, name=box.objectName(), text=box.text(),
                          checked=box.isChecked(), enabled=box.isEnabled(), parents=parents))
(out / f'{theme}-inventory.json').write_text(json.dumps(inventory, indent=2), encoding='utf-8')
window.pages.setCurrentWidget(window.build_page)
window.build_page.advanced_section.toggle_button.setChecked(True)
app.processEvents()
for target, box in window.build_page.quality_target_checks.items():
    assert box.parentWidget().grab().save(str(out / f'{theme}-build-{target}.png'))
window.pages.setCurrentWidget(window.air_link_page)
for section in window.air_link_page.findChildren(CollapsibleSection):
    section.toggle_button.setChecked(True)
app.processEvents()
assert window.air_link_page.air_link_group.grab().save(str(out / f'{theme}-air-crc.png'))
assert window.ground_target_page.activity_led_group.grab().save(str(out / f'{theme}-ground-led.png'))
window.pages.setCurrentWidget(window.flight_configuration_page)
app.processEvents()
assert window.flight_configuration_page.logging_table.grab().save(str(out / f'{theme}-logging.png'))
editor = AlignmentConfigurationEditor(Translator('en_US'))
editor.DraftStrategy_Set('silverstar.algorithm.alignment.external_attitude_source')
editor.resize(700, 300)
editor.show()
app.processEvents()
assert editor.grab().save(str(out / f'{theme}-alignment.png'))
editor.deleteLater()
assert window._model.Dictionary_Get() == model
print(theme, len(inventory), 'actual checkboxes; model and default selections preserved', flush=True)
window._dirty = False
window.deleteLater()
app.processEvents()
