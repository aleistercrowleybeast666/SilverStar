from pathlib import Path
import sys,importlib.util
base=Path(__file__).resolve().parents[2]
repo=base/'.work/qint'
sys.path.append(str(base/'.venv/Lib/site-packages'))
sys.path[:0]=[str(repo/'apps/SCG/src'),str(base/'apps/FLP/src'),str(base/'apps/FLP')]
import pytest
plugins=[]
for name in ('normal_test_paths','closeout_test_paths'):
 spec=importlib.util.spec_from_file_location(name,base/('docs/evidence/nightly_software_20261008/'+name+'.py'))
 module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);plugins.append(module)
raise SystemExit(pytest.main(['-p','no:cacheprovider',*sys.argv[1:]],plugins=plugins))
