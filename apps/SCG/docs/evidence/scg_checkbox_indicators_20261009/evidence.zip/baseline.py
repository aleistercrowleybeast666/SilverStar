"""Run the new pixel regression against the original QSS, in memory only."""
import ast, subprocess, sys, runpy
from pathlib import Path
from string import Template
root = Path('D:/python_software/SilverStar')
repo = root / '.work/qint'
sys.path.insert(0, str(repo / 'apps/SCG/src'))
from silverstar_fccg.ui import theme
source = subprocess.check_output(['git', '-C', str(repo), 'show',
    '1534120e02a28d98b83e7d7cdc99849d52189d67:apps/SCG/src/silverstar_fccg/ui/theme.py'],
    text=True, encoding='utf-8')
node = next(n for n in ast.parse(source).body if isinstance(n, ast.Assign) and
    any(isinstance(t, ast.Name) and t.id == '_STYLESHEET' for t in n.targets))
theme._STYLESHEET = Template(ast.literal_eval(node.value.args[0]))
sys.argv = ['run_pytest.py', '-q', str(repo / 'apps/SCG/tests/test_checkbox_indicators.py'),
    '-k', 'every_checkbox', '--basetemp=' + str(repo / 'apps/SCG/.work/checkbox_baseline_v2')]
runpy.run_path(str(root / '.work/qint_run/run_pytest.py'), run_name='__main__')
