from pathlib import Path
import os,sys,json
ROOT=Path('D:/python_software/SilverStar');SCG=ROOT/'.work/qint/apps/SCG'
sys.path[:0]=[str(SCG/'src')]
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
from PySide6.QtWidgets import QApplication,QWidget,QGridLayout,QLabel,QCheckBox,QStyleOptionButton,QStyle
from PySide6.QtGui import QPainter,QFont,QFontDatabase
from PySide6.QtCore import Qt
from silverstar_fccg.ui.theme import Theme_Apply
app=QApplication([])
font_id=QFontDatabase.addApplicationFont('C:/Windows/Fonts/segoeui.ttf')
assert font_id >= 0
app.setFont(QFont(QFontDatabase.applicationFontFamilies(font_id)[0],11))
phase,theme=sys.argv[1:3]
if phase=='before':
    import ast,subprocess
    from string import Template
    from silverstar_fccg.ui import theme as theme_module
    source=subprocess.check_output(['git','-C',str(SCG.parents[1]),'show','1534120e02a28d98b83e7d7cdc99849d52189d67:apps/SCG/src/silverstar_fccg/ui/theme.py'],text=True,encoding='utf-8')
    node=next(n for n in ast.parse(source).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='_STYLESHEET' for t in n.targets))
    theme_module._STYLESHEET=Template(ast.literal_eval(node.value.args[0]))
Theme_Apply(app,theme)
class PreviewCheckBox(QCheckBox):
    def paintEvent(self,event):
        option=QStyleOptionButton();self.initStyleOption(option)
        if self.property('previewHover'):option.state|=QStyle.StateFlag.State_MouseOver
        if self.property('previewFocus'):option.state|=QStyle.StateFlag.State_HasFocus
        painter=QPainter(self);self.style().drawControl(QStyle.ControlElement.CE_CheckBox,option,painter,self)
window=QWidget();window.setObjectName('centralRoot');layout=QGridLayout(window);layout.setContentsMargins(24,24,24,24);layout.setHorizontalSpacing(24);layout.setVerticalSpacing(15)
for col,text in enumerate(('State','Raw: targets / yaw','Standard: devices / CRC','Standard: logging')):layout.addWidget(QLabel(text),0,col)
rows=[('Unchecked',False,True,False,False),('Checked',True,True,False,False),('Disabled unchecked',False,False,False,False),('Disabled checked',True,False,False,False),('Hover unchecked',False,True,True,False),('Hover checked',True,True,True,False),('Focus unchecked',False,True,False,True),('Focus checked',True,True,False,True)]
for row,(name,checked,enabled,hover,focus) in enumerate(rows,1):
    layout.addWidget(QLabel(name),row,0)
    for col in range(1,4):
        box=PreviewCheckBox('Include / Enable');box.setChecked(checked);box.setEnabled(enabled);box.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        if col>1:box.setObjectName('standardCheckBox')
        if col==3:box.setProperty('logStreamControl',True)
        box.setProperty('previewHover',hover);box.setProperty('previewFocus',focus);layout.addWidget(box,row,col)
window.resize(970,480);window.show();app.processEvents()
scale=os.environ.get('QT_SCALE_FACTOR','1')
out=ROOT/'.work/checkbox_20261009'/phase;out.mkdir(parents=True,exist_ok=True)
path=out/f'{theme}-{scale}.png';assert window.grab().save(str(path))
print(path,flush=True);window.close();app.processEvents()
